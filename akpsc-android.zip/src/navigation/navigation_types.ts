export type RootStackParamList = {
  Login: undefined;
  App: undefined;
  Attendance: undefined;
  Notices: undefined;
  Settings: undefined;
  ChangePassword: undefined;
  AddStudent: undefined;
  AddExpense: undefined;
  TakeAttendance: { classId: number; className: string; subject: string };
  EnterMarks: { classId: number; className: string; subject: string };
  StudentDetail: { studentId: number };
};

export type StudentTabParamList = {
  Home: undefined;
  Timetable: undefined;
  Results: undefined;
  Fees: undefined;
  Profile: undefined;
};

export type TeacherTabParamList = {
  Home: undefined;
  Classes: undefined;
  Profile: undefined;
};

export type AdminTabParamList = {
  Home: undefined;
  Students: undefined;
  Fees: undefined;
  Expenses: undefined;
  Profile: undefined;
};
