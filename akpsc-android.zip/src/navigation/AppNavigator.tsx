import React from 'react';
import { Ionicons } from '@expo/vector-icons';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useAuth } from '../auth/AuthContext';
import { colors } from '../theme';
import { Loading } from '../components/Screen';
import type {
  RootStackParamList,
  StudentTabParamList,
  TeacherTabParamList,
  AdminTabParamList,
} from './types';

import LoginScreen from '../screens/LoginScreen';
import NoticesScreen from '../screens/shared/NoticesScreen';
import SettingsScreen from '../screens/shared/SettingsScreen';
import ChangePasswordScreen from '../screens/shared/ChangePasswordScreen';
import StudentHomeScreen from '../screens/student/StudentHomeScreen';
import StudentTimetableScreen from '../screens/student/StudentTimetableScreen';
import StudentAttendanceScreen from '../screens/student/StudentAttendanceScreen';
import StudentMarksScreen from '../screens/student/StudentMarksScreen';
import StudentFeesScreen from '../screens/student/StudentFeesScreen';
import StudentProfileScreen from '../screens/student/StudentProfileScreen';
import TeacherHomeScreen from '../screens/teacher/TeacherHomeScreen';
import TeacherClassesScreen from '../screens/teacher/TeacherClassesScreen';
import TeacherProfileScreen from '../screens/teacher/TeacherProfileScreen';
import TakeAttendanceScreen from '../screens/teacher/TakeAttendanceScreen';
import EnterMarksScreen from '../screens/teacher/EnterMarksScreen';
import AdminHomeScreen from '../screens/admin/AdminHomeScreen';
import AdminStudentsScreen from '../screens/admin/AdminStudentsScreen';
import AdminStaffScreen from '../screens/admin/AdminStaffScreen';
import AdminFeesScreen from '../screens/admin/AdminFeesScreen';
import AdminProfileScreen from '../screens/admin/AdminProfileScreen';
import StudentDetailScreen from '../screens/admin/StudentDetailScreen';
import AddStudentScreen from '../screens/admin/AddStudentScreen';
import AdminExpensesScreen from '../screens/admin/AdminExpensesScreen';
import AddExpenseScreen from '../screens/admin/AddExpenseScreen';
import AdminMenuScreen from '../screens/admin/AdminMenuScreen';
import AdminAttendanceScreen from '../screens/admin/AdminAttendanceScreen';
import ComingSoonScreen from '../screens/shared/ComingSoonScreen';

const Stack = createNativeStackNavigator<RootStackParamList>();
const StudentTabs = createBottomTabNavigator<StudentTabParamList>();
const TeacherTabs = createBottomTabNavigator<TeacherTabParamList>();
const AdminTabs = createBottomTabNavigator<AdminTabParamList>();

const tabIcon = (focused: boolean, name: keyof typeof Ionicons.glyphMap, outline: keyof typeof Ionicons.glyphMap) => (
  <Ionicons name={focused ? name : outline} size={22} color={focused ? colors.primary : colors.textSecondary} />
);

const screenOptions = {
  headerShown: false,
  tabBarActiveTintColor: colors.primary,
  tabBarInactiveTintColor: colors.textSecondary,
  tabBarStyle: { backgroundColor: colors.card, borderTopColor: colors.border },
  tabBarLabelStyle: { fontSize: 11, fontWeight: '600' as const },
};

function StudentNavigator() {
  return (
    <StudentTabs.Navigator screenOptions={screenOptions}>
      <StudentTabs.Screen name="Home" component={StudentHomeScreen} options={{ tabBarIcon: ({ focused }) => tabIcon(focused, 'home', 'home-outline') }} />
      <StudentTabs.Screen name="Timetable" component={StudentTimetableScreen} options={{ tabBarIcon: ({ focused }) => tabIcon(focused, 'calendar', 'calendar-outline') }} />
      <StudentTabs.Screen name="Results" component={StudentMarksScreen} options={{ tabBarIcon: ({ focused }) => tabIcon(focused, 'stats-chart', 'stats-chart-outline') }} />
      <StudentTabs.Screen name="Fees" component={StudentFeesScreen} options={{ tabBarIcon: ({ focused }) => tabIcon(focused, 'wallet', 'wallet-outline') }} />
      <StudentTabs.Screen name="Profile" component={StudentProfileScreen} options={{ tabBarIcon: ({ focused }) => tabIcon(focused, 'person', 'person-outline') }} />
    </StudentTabs.Navigator>
  );
}

function TeacherNavigator() {
  return (
    <TeacherTabs.Navigator screenOptions={screenOptions}>
      <TeacherTabs.Screen name="Home" component={TeacherHomeScreen} options={{ tabBarIcon: ({ focused }) => tabIcon(focused, 'home', 'home-outline') }} />
      <TeacherTabs.Screen name="Classes" component={TeacherClassesScreen} options={{ tabBarIcon: ({ focused }) => tabIcon(focused, 'school', 'school-outline') }} />
      <TeacherTabs.Screen name="Profile" component={TeacherProfileScreen} options={{ tabBarIcon: ({ focused }) => tabIcon(focused, 'person', 'person-outline') }} />
    </TeacherTabs.Navigator>
  );
}

function AdminNavigator() {
  const { user } = useAuth();
  // Only show Expenses to roles actually granted `expenses.view` in the web
  // admin's Users & Roles page — this list comes straight from the login
  // response's `permissions` array, so changes there take effect on next login.
  const canViewExpenses = !!user?.permissions?.includes('expenses.view');

  return (
    <AdminTabs.Navigator screenOptions={screenOptions}>
      <AdminTabs.Screen name="Home" component={AdminHomeScreen} options={{ tabBarIcon: ({ focused }) => tabIcon(focused, 'home', 'home-outline') }} />
      <AdminTabs.Screen name="Students" component={AdminStudentsScreen} options={{ tabBarIcon: ({ focused }) => tabIcon(focused, 'people', 'people-outline') }} />
      <AdminTabs.Screen name="Fees" component={AdminFeesScreen} options={{ tabBarIcon: ({ focused }) => tabIcon(focused, 'wallet', 'wallet-outline') }} />
      {canViewExpenses ? (
        <AdminTabs.Screen name="Expenses" component={AdminExpensesScreen} options={{ tabBarIcon: ({ focused }) => tabIcon(focused, 'receipt', 'receipt-outline') }} />
      ) : null}
      <AdminTabs.Screen name="Menu" component={AdminMenuScreen} options={{ tabBarIcon: ({ focused }) => tabIcon(focused, 'menu', 'menu-outline') }} />
      <AdminTabs.Screen name="Profile" component={AdminProfileScreen} options={{ tabBarIcon: ({ focused }) => tabIcon(focused, 'person', 'person-outline') }} />
    </AdminTabs.Navigator>
  );
}

function AppNavigatorContent() {
  const { user, loading } = useAuth();

  if (loading) return <Loading />;

  const tabsForRole = () => {
    if (user?.role === 'teacher') return <TeacherNavigator />;
    if (user?.role === 'admin' || user?.role === 'accountant') return <AdminNavigator />;
    return <StudentNavigator />; // student & parent
  };

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {!user ? (
        <Stack.Screen name="Login" component={LoginScreen} />
      ) : (
        <>
          <Stack.Screen name="App" children={tabsForRole} />
          <Stack.Screen name="Attendance" component={StudentAttendanceScreen} options={{ presentation: 'modal' }} />
          <Stack.Screen name="Notices" component={NoticesScreen} options={{ presentation: 'modal' }} />
          <Stack.Screen name="Settings" component={SettingsScreen} options={{ presentation: 'card' }} />
          <Stack.Screen name="ChangePassword" component={ChangePasswordScreen} options={{ presentation: 'card' }} />
          <Stack.Screen name="AddStudent" component={AddStudentScreen} options={{ presentation: 'card' }} />
          <Stack.Screen name="AddExpense" component={AddExpenseScreen} options={{ presentation: 'card' }} />
          <Stack.Screen name="AdminAttendance" component={AdminAttendanceScreen} options={{ presentation: 'card' }} />
          <Stack.Screen name="TakeAttendance" component={TakeAttendanceScreen} options={{ presentation: 'modal' }} />
          <Stack.Screen name="EnterMarks" component={EnterMarksScreen} options={{ presentation: 'modal' }} />
          <Stack.Screen name="StudentDetail" component={StudentDetailScreen} options={{ presentation: 'card' }} />
          <Stack.Screen name="ComingSoon" component={ComingSoonScreen} options={{ presentation: 'card' }} />
        </>
      )}
    </Stack.Navigator>
  );
}

export default function AppNavigator() {
  return (
    <NavigationContainer>
      <AppNavigatorContent />
    </NavigationContainer>
  );
}
