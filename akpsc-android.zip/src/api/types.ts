export type Role = 'admin' | 'teacher' | 'student' | 'parent' | 'accountant';

export interface User {
  id: number;
  username: string;
  role: Role;
  name: string;
  email: string;
  student_id?: number | null;
  permissions: string[];
}

export interface ExpenseCategory {
  id: number;
  name: string;
}

export interface Expense {
  id: number;
  category_id: number;
  category_name: string;
  description: string;
  amount: number;
  expense_date: string;
  created_at: string;
}

export interface ExpensesResponse {
  expenses: Expense[];
  categories: ExpenseCategory[];
  total: number;
  month: number;
  year: number;
}

export interface Guardian {
  name: string;
  relation: string;
  phone: string;
}

export interface StudentProfile {
  id: number;
  admission_no: string;
  first_name: string;
  last_name: string;
  full_name: string;
  father_name?: string;
  cnic_no?: string;
  board_registration_no?: string;
  roll_number: number;
  gender: string;
  dob: string;
  phone: string;
  email: string;
  class_name: string;
  section: string;
  status: string;
  guardian: Guardian;
  transport: boolean;
}

export interface AttendanceSummary {
  total: number;
  present: number;
  absent: number;
  late: number;
  percentage: number;
}

export interface AttendanceRecord {
  id: number;
  student_id: number;
  date: string;
  status: 'Present' | 'Absent' | 'Late';
}

export interface SubjectMark {
  subject: string;
  marks_obtained: number;
  total_marks: number;
  grade: string;
}

export interface MarksExam {
  exam_id: number;
  exam_name: string;
  exam_type: string;
  percentage: number;
  grade: string;
  subjects: SubjectMark[];
}

export interface FeePayment {
  id: number;
  invoice_id: number;
  student_id: number;
  amount: number;
  method: string;
  date: string;
}

export interface FeeInvoice {
  id: number;
  invoice_no: string;
  student_id: number;
  category: string;
  description: string;
  month: string | null;
  amount: number;
  fine: number;
  discount: number;
  total: number;
  paid_amount: number;
  balance: number;
  status: 'Paid' | 'Partial' | 'Unpaid';
  due_date: string;
  created_at: string;
  payments: FeePayment[];
}

export interface FeeSummary {
  totalBilled: number;
  totalPaid: number;
  totalDue: number;
  unpaidCount: number;
}

export interface TimetableEntry {
  id: number;
  class_section_id: number;
  class_name: string;
  section: string;
  day: string;
  period: number;
  time: string;
  subject: string;
  teacher: string;
}

export interface Notice {
  id: number;
  title: string;
  body: string;
  date: string;
}

export interface ClassInfo {
  id: number;
  class_name: string;
  section: string;
  subject?: string;
  studentCount: number;
}

export interface DashboardStudent {
  student: StudentProfile;
  attendance: AttendanceSummary;
  lastExam: MarksExam | null;
  feeDue: number;
  notices: Notice[];
}

export interface DashboardTeacher {
  teacher: { name: string; designation: string; subject: string };
  myClasses: ClassInfo[];
  notices: Notice[];
}

export interface DashboardAdmin {
  stats: {
    totalStudents: number;
    activeStudents: number;
    totalStaff: number;
    monthlyCollected: number;
    yearlyCollected: number;
    yearlyExpenses: number;
    netBalance: number;
    pendingDues: number;
    pendingInvoices: number;
    classes: number;
    attendanceToday: number | null;
  };
  notices: Notice[];
}

export interface AdminStaff {
  id: number;
  name: string;
  designation: string;
  phone: string;
  email: string;
  subject: string;
  join_date: string;
  salary: number;
}

export interface PendingInvoice extends FeeInvoice {
  student_name: string;
}

export interface CollectionsReport {
  totalCollected: number;
  monthCollected: number;
  categoryBreakdown: Record<string, number>;
  pending: PendingInvoice[];
}
