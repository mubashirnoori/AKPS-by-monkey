import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';

const KEY = 'sms_api_base_url';

export function defaultBaseUrl(): string {
  const explicit = process.env.EXPO_PUBLIC_API_URL;
  if (explicit) return explicit.replace(/\/$/, '');
  if (Platform.OS === 'web') return '/api';
  return 'http://localhost:4000/api';
}

export async function getApiBaseUrl(): Promise<string> {
  try {
    const stored = await AsyncStorage.getItem(KEY);
    if (stored) return stored.replace(/\/$/, '');
  } catch {
    // ignore
  }
  return defaultBaseUrl();
}

export async function setApiBaseUrl(url: string): Promise<void> {
  const clean = url.trim().replace(/\/+$/, '');
  await AsyncStorage.setItem(KEY, clean);
}

export async function resetApiBaseUrl(): Promise<void> {
  await AsyncStorage.removeItem(KEY);
}
