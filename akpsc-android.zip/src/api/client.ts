import AsyncStorage from '@react-native-async-storage/async-storage';
import type { User } from './types';
import { getApiBaseUrl } from './config';

const TOKEN_KEY = 'sms_token';
const USER_KEY = 'sms_user';

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

let authToken: string | null = null;

export const setAuthToken = (token: string | null) => {
  authToken = token;
};

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };
  if (authToken) headers.Authorization = `Bearer ${authToken}`;

  const baseUrl = await getApiBaseUrl();
  let res: Response;
  try {
    res = await fetch(`${baseUrl}${path}`, { ...options, headers });
  } catch {
    throw new ApiError('Cannot reach the server. Check the server URL and your connection.', 0);
  }

  if (!res.ok) {
    let message = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      if (body?.error) message = body.error;
    } catch {
      // ignore
    }
    throw new ApiError(message, res.status);
  }
  return (await res.json()) as T;
}

export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'POST', body: JSON.stringify(body ?? {}) }),
};

export async function persistSession(token: string, user: User) {
  setAuthToken(token);
  await AsyncStorage.multiSet([
    [TOKEN_KEY, token],
    [USER_KEY, JSON.stringify(user)],
  ]);
}

export async function loadSession(): Promise<{ token: string | null; user: User | null }> {
  const entries = await AsyncStorage.multiGet([TOKEN_KEY, USER_KEY]);
  const token = entries[0][1];
  const user = entries[1][1] ? (JSON.parse(entries[1][1]!) as User) : null;
  if (token) setAuthToken(token);
  return { token, user };
}

export async function clearSession() {
  setAuthToken(null);
  await AsyncStorage.multiRemove([TOKEN_KEY, USER_KEY]);
}
