export const currency = (amount: number): string =>
  `Rs ${amount.toLocaleString('en-PK', { minimumFractionDigits: 0 })}`;

export const formatDate = (iso: string): string => {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
};

export const today = (): string => {
  const d = new Date();
  return d.toISOString().slice(0, 10);
};
