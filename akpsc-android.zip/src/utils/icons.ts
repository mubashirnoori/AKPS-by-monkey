import type { Ionicons } from '@expo/vector-icons';

type IoniconName = keyof typeof Ionicons.glyphMap;

// Every icon prop across the app was originally a raw emoji string. Rather
// than touch every call site individually, StatCard/InfoRow/ListItem look
// the emoji up here and render a proper Ionicons glyph instead — any emoji
// not in this table just falls back to being rendered as text, so nothing
// breaks if a new one shows up before this list is updated.
export const EMOJI_TO_IONICON: Record<string, IoniconName> = {
  '⏰': 'alarm-outline',
  '⏳': 'hourglass-outline',
  '▶️': 'play-circle-outline',
  '☁️': 'cloud-outline',
  '⚙️': 'settings-outline',
  '⚠️': 'warning-outline',
  '✅': 'checkmark-circle-outline',
  '❌': 'close-circle-outline',
  '❓': 'help-circle-outline',
  '➕': 'add-circle-outline',
  '⬆️': 'arrow-up-circle-outline',
  '⭐': 'star-outline',
  '🎂': 'gift-outline',
  '🎓': 'school-outline',
  '🎨': 'color-palette-outline',
  '🏆': 'trophy-outline',
  '🏠': 'home-outline',
  '🏫': 'business-outline',
  '🏷️': 'pricetag-outline',
  '👤': 'person-outline',
  '👥': 'people-outline',
  '💰': 'cash-outline',
  '💳': 'card-outline',
  '📃': 'document-text-outline',
  '📄': 'document-outline',
  '📅': 'calendar-outline',
  '📆': 'calendar-outline',
  '📇': 'id-card-outline',
  '📊': 'stats-chart-outline',
  '📋': 'clipboard-outline',
  '📖': 'book-outline',
  '📚': 'library-outline',
  '📝': 'create-outline',
  '📞': 'call-outline',
  '📢': 'megaphone-outline',
  '📤': 'trending-down-outline',
  '📦': 'cube-outline',
  '📧': 'mail-outline',
  '📱': 'phone-portrait-outline',
  '🔑': 'key-outline',
  '🔔': 'notifications-outline',
  '🔗': 'link-outline',
  '🔧': 'construct-outline',
  '🕐': 'time-outline',
  '🗂️': 'folder-open-outline',
  '🚌': 'bus-outline',
  '🚩': 'flag-outline',
  '🛡️': 'shield-checkmark-outline',
  '🧑\u200d⚕️': 'person-outline',
  '🧑\u200d🏫': 'school-outline',
  '🧑\u200d💼': 'briefcase-outline',
  '🧹': 'sparkles-outline',
  '🧾': 'receipt-outline',
  '🪪': 'id-card-outline',
};

export function resolveIcon(icon?: string): IoniconName | null {
  if (!icon) return null;
  return EMOJI_TO_IONICON[icon] ?? null;
}
