import React, { useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { ScreenHeader } from '../../components/Screen';
import { Card } from '../../components/Card';
import { SafeAreaView } from 'react-native-safe-area-context';
import { api, ApiError } from '../../api/client';
import { colors, spacing, typography, radius } from '../../theme';

export default function ChangePasswordScreen() {
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const submit = async () => {
    setSaving(true);
    setMessage(null);
    setError(null);
    try {
      await api.post('/auth/change-password', {
        current_password: current,
        new_password: next,
        confirm_password: confirm,
      });
      setMessage('Password updated successfully.');
      setCurrent('');
      setNext('');
      setConfirm('');
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Could not change password.');
    } finally {
      setSaving(false);
    }
  };

  const valid = current && next && confirm && next === confirm && next.length >= 6;

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <ScreenHeader title="Change Password" subtitle="Minimum 6 characters" />
      <View style={styles.content}>
        <Card style={styles.card}>
          <Text style={[typography.label, styles.label]}>Current Password</Text>
          <TextInput style={styles.input} value={current} onChangeText={setCurrent} secureTextEntry placeholder="Enter current password" placeholderTextColor={colors.textSecondary} />
          <Text style={[typography.label, styles.label]}>New Password</Text>
          <TextInput style={styles.input} value={next} onChangeText={setNext} secureTextEntry placeholder="Enter new password" placeholderTextColor={colors.textSecondary} />
          <Text style={[typography.label, styles.label]}>Confirm New Password</Text>
          <TextInput style={styles.input} value={confirm} onChangeText={setConfirm} secureTextEntry placeholder="Re-enter new password" placeholderTextColor={colors.textSecondary} />

          {next.length > 0 && next.length < 6 ? <Text style={styles.hint}>Password must be at least 6 characters.</Text> : null}
          {confirm.length > 0 && next !== confirm ? <Text style={styles.hint}>Passwords do not match.</Text> : null}
          {message ? <Text style={styles.success}>{message}</Text> : null}
          {error ? <Text style={styles.error}>{error}</Text> : null}

          <Pressable style={({ pressed }) => [styles.btn, (!valid || pressed || saving) && { opacity: 0.8 }]} onPress={submit} disabled={!valid || saving}>
            {saving ? <ActivityIndicator color={colors.white} /> : <Text style={styles.btnText}>Update Password</Text>}
          </Pressable>
        </Card>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.lg },
  card: { paddingVertical: spacing.lg },
  label: { color: colors.text, marginBottom: 6, marginTop: 4 },
  input: {
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    color: colors.text,
    marginBottom: spacing.md,
  },
  hint: { color: colors.warning, fontSize: 13, marginBottom: spacing.sm },
  success: { color: colors.success, fontSize: 13, marginBottom: spacing.sm },
  error: { color: colors.danger, fontSize: 13, marginBottom: spacing.sm },
  btn: {
    backgroundColor: colors.primary,
    borderRadius: radius.md,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: spacing.sm,
  },
  btnText: { color: colors.white, fontWeight: '700', fontSize: 16 },
});
