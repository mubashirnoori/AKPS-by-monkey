import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { ScreenHeader, Loading } from '../../components/Screen';
import { Card, SectionHeader } from '../../components/Card';
import { InfoRow } from '../../components/List';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { getApiBaseUrl, setApiBaseUrl, resetApiBaseUrl, defaultBaseUrl } from '../../api/config';
import { useApi } from '../../hooks/useApi';
import { useAuth } from '../../auth/AuthContext';
import { colors, spacing, typography, radius } from '../../theme';
import type { RootStackParamList } from '../../navigation/types';

const APP_VERSION = '1.0.0';

export default function SettingsScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { user } = useAuth();
  const [url, setUrl] = useState('');
  const [loaded, setLoaded] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { data } = useApi<{ school_name?: string }>('/settings');

  useEffect(() => {
    (async () => {
      setUrl(await getApiBaseUrl());
      setLoaded(true);
    })();
  }, []);

  const save = async () => {
    setSaving(true);
    setMessage(null);
    setError(null);
    try {
      await setApiBaseUrl(url);
      setMessage('Saved. The app now talks to: ' + url.replace(/\/+$/, ''));
    } catch (e) {
      setError('Could not save URL');
    } finally {
      setSaving(false);
    }
  };

  const reset = async () => {
    await resetApiBaseUrl();
    setUrl(defaultBaseUrl());
    setMessage('Reset to default server URL.');
    setError(null);
  };

  if (!loaded) return <Loading />;

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <ScreenHeader title="Settings" subtitle="Connection, account and about" />

      <View style={styles.content}>
        <SectionHeader title="Server Connection" />
        <Card style={styles.card}>
          <Text style={[typography.label, styles.label]}>API Server URL</Text>
          <TextInput
            style={styles.input}
            value={url}
            onChangeText={setUrl}
            autoCapitalize="none"
            autoCorrect={false}
            placeholder="https://your-site.com/api"
            placeholderTextColor={colors.textSecondary}
          />
          <Text style={[typography.caption, styles.hint]}>
            Point this at your live API. Example: https://your-site.com/api
          </Text>
          {message ? <Text style={styles.success}>{message}</Text> : null}
          {error ? <Text style={styles.error}>{error}</Text> : null}
          <View style={styles.btnRow}>
            <Pressable style={({ pressed }) => [styles.btn, pressed && { opacity: 0.8 }]} onPress={save} disabled={saving}>
              {saving ? <ActivityIndicator color={colors.white} size="small" /> : <Text style={styles.btnText}>Save</Text>}
            </Pressable>
            <Pressable style={({ pressed }) => [styles.btnGhost, pressed && { opacity: 0.8 }]} onPress={reset}>
              <Text style={styles.btnGhostText}>Reset</Text>
            </Pressable>
          </View>
        </Card>

        <SectionHeader title="Account" />
        <Card style={styles.card}>
          <Pressable onPress={() => navigation.navigate('ChangePassword')}>
            <InfoRow label="Change Password" value="Update your login password" icon="🔑" />
          </Pressable>
        </Card>

        <SectionHeader title="About" />
        <Card style={styles.card}>
          <InfoRow label="Institute" value={data?.school_name ?? '—'} icon="🏫" />
          <InfoRow label="App Version" value={APP_VERSION} icon="📱" />
          <InfoRow label="Role" value={user?.role ?? '—'} icon="🏷️" />
        </Card>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.lg, paddingBottom: spacing.xxl },
  card: { paddingTop: spacing.xs, paddingBottom: spacing.xs },
  label: { color: colors.text, marginBottom: 6 },
  input: {
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 15,
    color: colors.text,
  },
  hint: { color: colors.textSecondary, marginTop: 6 },
  success: { color: colors.success, marginTop: 8, fontSize: 13 },
  error: { color: colors.danger, marginTop: 8, fontSize: 13 },
  btnRow: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.md },
  btn: {
    flex: 1,
    backgroundColor: colors.primary,
    borderRadius: radius.md,
    paddingVertical: 12,
    alignItems: 'center',
  },
  btnText: { color: colors.white, fontWeight: '700' },
  btnGhost: {
    flex: 1,
    backgroundColor: colors.primaryLight,
    borderRadius: radius.md,
    paddingVertical: 12,
    alignItems: 'center',
  },
  btnGhostText: { color: colors.primaryDark, fontWeight: '700' },
});
