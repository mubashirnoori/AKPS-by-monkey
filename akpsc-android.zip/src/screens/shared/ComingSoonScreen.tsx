import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useRoute, RouteProp } from '@react-navigation/native';
import { Screen, ScreenHeader } from '../../components/Screen';
import { colors, spacing, typography } from '../../theme';
import type { RootStackParamList } from '../../navigation/types';

export default function ComingSoonScreen() {
  const route = useRoute<RouteProp<RootStackParamList, 'ComingSoon'>>();
  const { title } = route.params;

  return (
    <Screen>
      <ScreenHeader title={title} />
      <View style={styles.wrap}>
        <Text style={styles.icon}>🚧</Text>
        <Text style={[typography.title, styles.heading]}>Coming soon</Text>
        <Text style={[typography.caption, styles.body]}>
          {title} isn't built into the app yet — it's still available on the web portal.
        </Text>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center', paddingTop: spacing.xxl, paddingHorizontal: spacing.lg },
  icon: { fontSize: 40, marginBottom: spacing.md },
  heading: { color: colors.text, marginBottom: spacing.sm },
  body: { color: colors.textSecondary, textAlign: 'center' },
});
