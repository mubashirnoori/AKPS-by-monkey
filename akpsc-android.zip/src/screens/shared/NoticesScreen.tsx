import React from 'react';
import { StyleSheet, Text } from 'react-native';
import { Screen, ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { NoticeCard } from '../../components/NoticeCard';
import { useApi } from '../../hooks/useApi';
import { colors, spacing } from '../../theme';
import type { Notice } from '../../api/types';

export default function NoticesScreen() {
  const { data, loading, error, refetch } = useApi<{ notices: Notice[] }>('/notices');

  if (loading) return <Loading />;
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={refetch} />;

  return (
    <Screen refreshing={loading} onRefresh={refetch}>
      <ScreenHeader title="Announcements" subtitle="Latest notices from the institute" />
      {data.notices.map((n) => (
        <NoticeCard key={n.id} notice={n} />
      ))}
      {data.notices.length === 0 ? <Text style={styles.empty}>No announcements.</Text> : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  empty: { color: colors.textSecondary, textAlign: 'center', padding: spacing.xl },
});
