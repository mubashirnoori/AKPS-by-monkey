import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { CompositeNavigationProp } from '@react-navigation/native';
import type { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Screen, ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { Card, StatCard, SectionHeader, ProgressBar } from '../../components/Card';
import { Avatar } from '../../components/List';
import { NoticeCard } from '../../components/NoticeCard';
import { useAuth } from '../../auth/AuthContext';
import { useApi } from '../../hooks/useApi';
import { colors, spacing, typography, radius, shadow } from '../../theme';
import { currency } from '../../utils/format';
import type { DashboardStudent } from '../../api/types';
import type { StudentTabParamList, RootStackParamList } from '../../navigation/types';

type HomeNav = CompositeNavigationProp<
  BottomTabNavigationProp<StudentTabParamList, 'Home'>,
  NativeStackNavigationProp<RootStackParamList>
>;

export default function StudentHomeScreen() {
  const navigation = useNavigation<HomeNav>();
  const { user } = useAuth();
  const sid = user?.student_id ?? 1;
  const { data, loading, error, refetch } = useApi<DashboardStudent>('/dashboard');

  if (loading) return <Loading />;
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={refetch} />;

  const { student, attendance, lastExam, feeDue, notices } = data;

  return (
    <Screen refreshing={loading} onRefresh={refetch}>
      <ScreenHeader title={`Assalam-o-Alaikum,`} subtitle={student.full_name} />

      <Card style={styles.profileCard}>
        <View style={styles.profileRow}>
          <Avatar name={student.full_name} size={52} />
          <View style={styles.profileText}>
            <Text style={[typography.subheading, styles.profileName]}>{student.full_name}</Text>
            <Text style={[typography.caption, styles.profileSub]}>
              {student.class_name} - Section {student.section} | Roll #{student.roll_number}
            </Text>
          </View>
          <View style={styles.statusChip}>
            <Text style={styles.statusText}>{student.status}</Text>
          </View>
        </View>
      </Card>

      <View style={styles.statsRow}>
        <StatCard label="Attendance" value={`${attendance.percentage}%`} icon="📋" color={colors.info} />
        <StatCard label="Last Exam" value={lastExam ? lastExam.grade : '—'} icon="🏆" color={colors.primary} />
        <StatCard label="Fee Due" value={currency(feeDue)} icon="💳" color={colors.danger} />
      </View>

      <Pressable onPress={() => navigation.navigate('Attendance')} style={({ pressed }) => [styles.attCard, pressed && { opacity: 0.8 }]}>
        <View style={styles.attTop}>
          <Text style={[typography.subheading, styles.attTitle]}>Attendance Overview</Text>
          <Text style={[typography.label, styles.attPct]}>{attendance.percentage}%</Text>
        </View>
        <ProgressBar value={attendance.percentage} color={colors.info} />
        <Text style={[typography.caption, styles.attSub]}>
          {attendance.present} present · {attendance.absent} absent · {attendance.late} late
        </Text>
      </Pressable>

      <View style={styles.quickRow}>
        {[
          { label: 'Timetable', icon: '📅', screen: 'Timetable' as const },
          { label: 'Results', icon: '📊', screen: 'Results' as const },
          { label: 'Fees', icon: '💰', screen: 'Fees' as const },
          { label: 'Notices', icon: '📢', screen: 'Notices' as const },
        ].map((q) => (
          <Pressable key={q.screen} onPress={() => navigation.navigate(q.screen)} style={({ pressed }) => [styles.quick, pressed && { opacity: 0.7 }]}>
            <Text style={styles.quickIcon}>{q.icon}</Text>
            <Text style={styles.quickLabel}>{q.label}</Text>
          </Pressable>
        ))}
      </View>

      <SectionHeader title="Announcements" />
      {notices.map((n) => (
        <NoticeCard key={n.id} notice={n} />
      ))}
    </Screen>
  );
}

const styles = StyleSheet.create({
  profileCard: { marginBottom: spacing.lg },
  profileRow: { flexDirection: 'row', alignItems: 'center' },
  profileText: { flex: 1, marginLeft: spacing.md },
  profileName: { color: colors.text },
  profileSub: { color: colors.textSecondary, marginTop: 2 },
  statusChip: { backgroundColor: colors.successLight, borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 4 },
  statusText: { color: colors.success, fontSize: 12, fontWeight: '700' },
  statsRow: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.lg },
  attCard: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.lg,
    ...shadow.card,
  },
  attTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.sm },
  attTitle: { color: colors.text },
  attPct: { color: colors.info },
  attSub: { color: colors.textSecondary, marginTop: spacing.sm },
  quickRow: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.xl },
  quick: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    paddingVertical: spacing.md,
    alignItems: 'center',
    ...shadow.card,
  },
  quickIcon: { fontSize: 22, marginBottom: 6 },
  quickLabel: { fontSize: 12, fontWeight: '600', color: colors.text },
});
