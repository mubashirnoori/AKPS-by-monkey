import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Screen, ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { Card, StatusBadge } from '../../components/Card';
import { useAuth } from '../../auth/AuthContext';
import { useApi } from '../../hooks/useApi';
import { colors, spacing, typography, radius, shadow } from '../../theme';
import type { MarksExam } from '../../api/types';

export default function StudentMarksScreen() {
  const { user } = useAuth();
  const sid = user?.student_id ?? 1;
  const { data, loading, error, refetch } = useApi<{ exams: MarksExam[] }>(`/students/${sid}/marks`);
  const [selected, setSelected] = useState<number | null>(null);

  if (loading) return <Loading />;
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={refetch} />;

  const { exams } = data;

  return (
    <Screen refreshing={loading} onRefresh={refetch}>
      <ScreenHeader title="Results" subtitle="Examination performance" />

      {exams.map((exam) => {
        const open = selected === exam.exam_id;
        return (
          <Card key={exam.exam_id} style={styles.examCard}>
            <Pressable onPress={() => setSelected(open ? null : exam.exam_id)}>
              <View style={styles.examHeader}>
                <View style={styles.examTitleWrap}>
                  <Text style={[typography.subheading, styles.examName]}>{exam.exam_name}</Text>
                  <Text style={[typography.caption, styles.examType]}>{exam.exam_type}</Text>
                </View>
                <View style={styles.examRight}>
                  <Text style={[typography.subheading, styles.pct]}>{exam.percentage}%</Text>
                  <StatusBadge status={`Grade ${exam.grade}`} />
                </View>
              </View>
            </Pressable>

            {open ? (
              <View style={styles.subjects}>
                {exam.subjects.map((s, i) => (
                  <View key={i} style={[styles.subjectRow, i === exam.subjects.length - 1 && styles.lastSubject]}>
                    <Text style={[typography.body, styles.subjectName]}>{s.subject}</Text>
                    <View style={styles.subjectRight}>
                      <Text style={[typography.caption, styles.subjectMarks]}>
                        {s.marks_obtained}/{s.total_marks}
                      </Text>
                      <Text style={[styles.subjectGrade, { color: gradeColor(s.grade) }]}>{s.grade}</Text>
                    </View>
                  </View>
                ))}
              </View>
            ) : null}
          </Card>
        );
      })}
      {exams.length === 0 ? <Text style={styles.empty}>No exam results published yet.</Text> : null}
    </Screen>
  );
}

const gradeColor = (grade: string): string => {
  if (grade.startsWith('A')) return colors.success;
  if (grade.startsWith('B')) return colors.info;
  if (grade.startsWith('C')) return colors.warning;
  return colors.danger;
};

const styles = StyleSheet.create({
  examCard: { marginBottom: spacing.md, paddingVertical: 6 },
  examHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 8 },
  examTitleWrap: { flex: 1, marginRight: spacing.sm },
  examName: { color: colors.text },
  examType: { color: colors.textSecondary, marginTop: 2 },
  examRight: { alignItems: 'flex-end', gap: 4 },
  pct: { color: colors.primary },
  subjects: { borderTopWidth: 1, borderTopColor: colors.border, marginTop: 6, paddingTop: 4 },
  subjectRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  lastSubject: { borderBottomWidth: 0 },
  subjectName: { color: colors.text, flex: 1 },
  subjectRight: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  subjectMarks: { color: colors.textSecondary },
  subjectGrade: { fontSize: 14, fontWeight: '700', width: 24, textAlign: 'center' },
  empty: { color: colors.textSecondary, textAlign: 'center', padding: spacing.xl },
});
