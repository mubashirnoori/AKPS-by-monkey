import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Screen, ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { Card, StatCard, ProgressBar } from '../../components/Card';
import { StatusBadge } from '../../components/Card';
import { useAuth } from '../../auth/AuthContext';
import { useApi } from '../../hooks/useApi';
import { colors, spacing, typography } from '../../theme';
import { formatDate } from '../../utils/format';
import type { AttendanceRecord, AttendanceSummary } from '../../api/types';

export default function StudentAttendanceScreen() {
  const { user } = useAuth();
  const sid = user?.student_id ?? 1;
  const { data, loading, error, refetch } = useApi<{ summary: AttendanceSummary; records: AttendanceRecord[] }>(
    `/students/${sid}/attendance`
  );

  if (loading) return <Loading />;
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={refetch} />;

  const { summary, records } = data;

  return (
    <Screen refreshing={loading} onRefresh={refetch}>
      <ScreenHeader title="Attendance" subtitle="Last 30 school days" />

      <View style={styles.statsRow}>
        <StatCard label="Present" value={summary.present} icon="✅" color={colors.success} />
        <StatCard label="Absent" value={summary.absent} icon="❌" color={colors.danger} />
        <StatCard label="Late" value={summary.late} icon="⏰" color={colors.warning} />
      </View>

      <Card style={styles.overall}>
        <View style={styles.overallTop}>
          <Text style={[typography.subheading, styles.overallTitle]}>Overall</Text>
          <Text style={[typography.subheading, { color: colors.primary }]}>{summary.percentage}%</Text>
        </View>
        <ProgressBar value={summary.percentage} color={colors.primary} />
      </Card>

      <Card style={styles.list}>
        {records.map((r, i) => (
          <View key={r.id} style={[styles.record, i === records.length - 1 && styles.lastRecord]}>
            <View style={styles.dateWrap}>
              <Text style={[typography.body, styles.date]}>{formatDate(r.date)}</Text>
            </View>
            <StatusBadge status={r.status} />
          </View>
        ))}
        {records.length === 0 ? <Text style={styles.empty}>No attendance records yet.</Text> : null}
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  statsRow: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.lg },
  overall: { marginBottom: spacing.lg },
  overallTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.sm },
  overallTitle: { color: colors.text },
  list: { paddingVertical: spacing.xs },
  record: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  lastRecord: { borderBottomWidth: 0 },
  dateWrap: { flexDirection: 'row', alignItems: 'center' },
  date: { color: colors.text },
  empty: { color: colors.textSecondary, paddingVertical: spacing.lg, textAlign: 'center' },
});
