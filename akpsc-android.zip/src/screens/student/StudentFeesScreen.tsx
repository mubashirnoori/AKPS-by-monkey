import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Screen, ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { Card, StatCard, StatusBadge } from '../../components/Card';
import { useAuth } from '../../auth/AuthContext';
import { useApi } from '../../hooks/useApi';
import { colors, spacing, typography } from '../../theme';
import { currency, formatDate } from '../../utils/format';
import type { FeeInvoice, FeeSummary } from '../../api/types';

export default function StudentFeesScreen() {
  const { user } = useAuth();
  const sid = user?.student_id ?? 1;
  const { data, loading, error, refetch } = useApi<{ summary: FeeSummary; invoices: FeeInvoice[] }>(
    `/students/${sid}/fees`
  );
  const [expanded, setExpanded] = useState<number | null>(null);

  if (loading) return <Loading />;
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={refetch} />;

  const { summary, invoices } = data;

  return (
    <Screen refreshing={loading} onRefresh={refetch}>
      <ScreenHeader title="Fees" subtitle="Invoices and payments" />

      <View style={styles.statsRow}>
        <StatCard label="Billed" value={currency(summary.totalBilled)} icon="🧾" color={colors.info} />
        <StatCard label="Paid" value={currency(summary.totalPaid)} icon="✅" color={colors.success} />
        <StatCard label="Due" value={currency(summary.totalDue)} icon="⏳" color={colors.danger} />
      </View>

      {invoices.map((inv) => {
        const open = expanded === inv.id;
        return (
          <Card key={inv.id} style={styles.invCard}>
            <Pressable onPress={() => setExpanded(open ? null : inv.id)}>
              <View style={styles.invTop}>
                <View style={styles.invTitleWrap}>
                  <Text style={[typography.subheading, styles.invTitle]}>{inv.description}</Text>
                  <Text style={[typography.caption, styles.invMeta]}>
                    {inv.invoice_no} · Due {formatDate(inv.due_date)}
                  </Text>
                </View>
                <StatusBadge status={inv.status} />
              </View>
              <View style={styles.amountRow}>
                <Text style={[typography.caption, styles.invMeta]}>Total</Text>
                <Text style={[typography.subheading, { color: inv.balance > 0 ? colors.danger : colors.success }]}>
                  {currency(inv.total)}
                </Text>
              </View>
              {inv.balance > 0 ? (
                <View style={styles.amountRow}>
                  <Text style={[typography.caption, styles.invMeta]}>Balance</Text>
                  <Text style={[typography.subheading, { color: colors.danger }]}>{currency(inv.balance)}</Text>
                </View>
              ) : null}
            </Pressable>

            {open && (
              <View style={styles.details}>
                <View style={styles.detailGrid}>
                  <DetailCell label="Amount" value={currency(inv.amount)} />
                  <DetailCell label="Fine" value={inv.fine > 0 ? currency(inv.fine) : '—'} highlight={inv.fine > 0} />
                  <DetailCell label="Discount" value={inv.discount > 0 ? `-${currency(inv.discount)}` : '—'} />
                  <DetailCell label="Paid" value={currency(inv.paid_amount)} />
                </View>
                {inv.payments.length > 0 ? (
                  <View style={styles.payments}>
                    <Text style={[typography.label, styles.payTitle]}>Payments</Text>
                    {inv.payments.map((p) => (
                      <View key={p.id} style={styles.payRow}>
                        <Text style={[typography.caption, styles.payMeta]}>{formatDate(p.date)} · {p.method}</Text>
                        <Text style={[typography.body, styles.payAmt]}>{currency(p.amount)}</Text>
                      </View>
                    ))}
                  </View>
                ) : null}
              </View>
            )}
          </Card>
        );
      })}
      {invoices.length === 0 ? <Text style={styles.empty}>No invoices yet.</Text> : null}
    </Screen>
  );
}

function DetailCell({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <View style={styles.detailCell}>
      <Text style={[typography.caption, styles.invMeta]}>{label}</Text>
      <Text style={[typography.body, { color: highlight ? colors.danger : colors.text, fontWeight: '600' }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  statsRow: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.lg },
  invCard: { marginBottom: spacing.md, paddingVertical: 6 },
  invTop: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  invTitleWrap: { flex: 1, marginRight: spacing.sm },
  invTitle: { color: colors.text },
  invMeta: { color: colors.textSecondary, marginTop: 2 },
  amountRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: spacing.sm,
  },
  details: { borderTopWidth: 1, borderTopColor: colors.border, marginTop: spacing.md, paddingTop: spacing.sm },
  detailGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  detailCell: { flexBasis: '46%', flexGrow: 1 },
  payments: { marginTop: spacing.md, backgroundColor: colors.background, borderRadius: 8, padding: spacing.sm },
  payTitle: { color: colors.textSecondary, marginBottom: 4 },
  payRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6 },
  payMeta: { color: colors.textSecondary },
  payAmt: { color: colors.text },
  empty: { color: colors.textSecondary, textAlign: 'center', padding: spacing.xl },
});
