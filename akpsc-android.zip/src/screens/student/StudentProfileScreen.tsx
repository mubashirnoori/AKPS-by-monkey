import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Screen, ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { Card, SectionHeader } from '../../components/Card';
import { Avatar, InfoRow } from '../../components/List';
import { useAuth } from '../../auth/AuthContext';
import { useApi } from '../../hooks/useApi';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../../navigation/types';
import { colors, spacing, typography, radius } from '../../theme';
import { formatDate } from '../../utils/format';
import type { StudentProfile } from '../../api/types';

export default function StudentProfileScreen() {
  const { user, logout } = useAuth();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const sid = user?.student_id ?? 1;
  const { data, loading, error, refetch } = useApi<{ student: StudentProfile }>(`/students/${sid}`);

  if (loading) return <Loading />;
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={refetch} />;

  const s = data.student;

  return (
    <Screen refreshing={loading} onRefresh={refetch}>
      <ScreenHeader title="Profile" />

      <Card style={styles.hero}>
        <Avatar name={s.full_name} size={72} />
        <Text style={[typography.title, styles.name]}>{s.full_name}</Text>
        <Text style={[typography.caption, styles.sub]}>
          {s.class_name} - Section {s.section} · Roll #{s.roll_number}
        </Text>
      </Card>

      <SectionHeader title="Personal Information" />
      <Card style={styles.card}>
        <InfoRow label="Admission No" value={s.admission_no} icon="🎓" />
        <InfoRow label="Date of Birth" value={formatDate(s.dob)} icon="🎂" />
        <InfoRow label="Gender" value={s.gender} icon="👤" />
        <InfoRow label="Phone" value={s.phone} icon="📞" />
        <InfoRow label="Email" value={s.email} icon="📧" />
        <InfoRow label="Transport" value={s.transport ? 'Yes' : 'No'} icon="🚌" />
      </Card>

      <SectionHeader title="Guardian" />
      <Card style={styles.card}>
        <InfoRow label="Name" value={s.guardian.name} icon="🧑‍⚕️" />
        <InfoRow label="Relation" value={s.guardian.relation} icon="🔗" />
        <InfoRow label="Phone" value={s.guardian.phone} icon="📞" />
      </Card>

      <Pressable style={({ pressed }) => [styles.settings, pressed && { opacity: 0.8 }]} onPress={() => navigation.navigate('Settings')}>
        <Text style={styles.settingsText}>⚙️ Settings</Text>
      </Pressable>

      <Pressable style={({ pressed }) => [styles.logout, pressed && { opacity: 0.8 }]} onPress={logout}>
        <Text style={styles.logoutText}>Sign Out</Text>
      </Pressable>
    </Screen>
  );
}

const styles = StyleSheet.create({
  hero: { alignItems: 'center', marginBottom: spacing.lg },
  name: { color: colors.text, marginTop: spacing.md },
  sub: { color: colors.textSecondary, marginTop: 4 },
  card: { paddingTop: spacing.xs, paddingBottom: spacing.xs },
  settings: {
    marginTop: spacing.xl,
    backgroundColor: colors.primaryLight,
    borderRadius: radius.md,
    paddingVertical: 14,
    alignItems: 'center',
  },
  settingsText: { color: colors.primaryDark, fontWeight: '700', fontSize: 15 },
  logout: {
    marginTop: spacing.sm,
    backgroundColor: colors.dangerLight,
    borderRadius: radius.md,
    paddingVertical: 14,
    alignItems: 'center',
  },
  logoutText: { color: colors.danger, fontWeight: '700', fontSize: 15 },
});
