import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Screen, ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { SectionHeader } from '../../components/Card';
import { useAuth } from '../../auth/AuthContext';
import { useApi } from '../../hooks/useApi';
import { colors, spacing, typography } from '../../theme';
import type { TimetableEntry } from '../../api/types';

const DAY_ORDER = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export default function StudentTimetableScreen() {
  const { user } = useAuth();
  const sid = user?.student_id ?? 1;
  const { data, loading, error, refetch } = useApi<{ timetable: TimetableEntry[]; byDay: Record<string, TimetableEntry[]> }>(
    `/students/${sid}/timetable`
  );

  if (loading) return <Loading />;
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={refetch} />;

  const todayIdx = (new Date().getDay() + 6) % 7; // Mon=0
  const todayName = DAY_ORDER[todayIdx];

  return (
    <Screen refreshing={loading} onRefresh={refetch}>
      <ScreenHeader title="Timetable" subtitle="Weekly class schedule" />
      {DAY_ORDER.map((day) => {
        const periods = data.byDay[day] ?? [];
        const isToday = day === todayName;
        return (
          <View key={day} style={styles.dayBlock}>
            <SectionHeader
              title={day}
              right={isToday ? <Text style={styles.todayTag}>Today</Text> : undefined}
            />
            <View style={styles.dayCard}>
              {periods.map((p, i) => (
                <View key={p.id} style={[styles.periodRow, i === periods.length - 1 && styles.lastRow]}>
                  <View style={styles.timeWrap}>
                    <Text style={styles.periodNum}>P{p.period}</Text>
                    <Text style={styles.time}>{p.time}</Text>
                  </View>
                  <View style={styles.subjectWrap}>
                    <Text style={[typography.body, styles.subject]}>{p.subject}</Text>
                    <Text style={[typography.caption, styles.teacher]}>{p.teacher}</Text>
                  </View>
                </View>
              ))}
              {periods.length === 0 ? <Text style={styles.noClass}>No classes scheduled</Text> : null}
            </View>
          </View>
        );
      })}
    </Screen>
  );
}

const styles = StyleSheet.create({
  dayBlock: { marginBottom: spacing.lg },
  dayCard: { backgroundColor: colors.card, borderRadius: 12, paddingHorizontal: spacing.md, paddingVertical: spacing.xs },
  periodRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  lastRow: { borderBottomWidth: 0 },
  timeWrap: { width: 76 },
  periodNum: { fontSize: 11, fontWeight: '700', color: colors.primary },
  time: { fontSize: 12, color: colors.textSecondary, marginTop: 2 },
  subjectWrap: { flex: 1 },
  subject: { color: colors.text },
  teacher: { color: colors.textSecondary, marginTop: 2 },
  todayTag: { color: colors.primary, fontSize: 12, fontWeight: '700' },
  noClass: { color: colors.textSecondary, paddingVertical: spacing.md, fontSize: 13 },
});
