import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Screen, ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { Card } from '../../components/Card';
import { Avatar } from '../../components/List';
import { useApi } from '../../hooks/useApi';
import { colors, spacing, typography } from '../../theme';
import { currency } from '../../utils/format';
import type { AdminStaff } from '../../api/types';

export default function AdminStaffScreen() {
  const { data, loading, error, refetch } = useApi<{ staff: AdminStaff[] }>('/admin/staff');

  if (loading) return <Loading />;
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={refetch} />;

  return (
    <Screen refreshing={loading} onRefresh={refetch}>
      <ScreenHeader title="Staff" subtitle={`${data.staff.length} members`} />

      {data.staff.map((s) => (
        <Card key={s.id} style={styles.card}>
          <Avatar name={s.name} size={44} />
          <View style={styles.info}>
            <Text style={[typography.body, styles.name]}>{s.name}</Text>
            <Text style={[typography.caption, styles.meta]}>{s.designation} · {s.subject}</Text>
            <Text style={[typography.caption, styles.meta]}>{s.phone} · {s.email}</Text>
          </View>
          <Text style={[typography.subheading, styles.salary]}>{currency(s.salary)}</Text>
        </Card>
      ))}
    </Screen>
  );
}

const styles = StyleSheet.create({
  card: { flexDirection: 'row', alignItems: 'center', marginBottom: spacing.sm, paddingVertical: 10 },
  info: { flex: 1, marginLeft: spacing.md, marginRight: spacing.sm },
  name: { color: colors.text },
  meta: { color: colors.textSecondary, marginTop: 2 },
  salary: { color: colors.primary },
});
