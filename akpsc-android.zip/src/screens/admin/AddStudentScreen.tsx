import React, { useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { Card, SectionHeader } from '../../components/Card';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { api, ApiError } from '../../api/client';
import { useApi } from '../../hooks/useApi';
import { colors, spacing, typography, radius } from '../../theme';
import type { ClassInfo } from '../../api/types';

export default function AddStudentScreen() {
  const navigation = useNavigation();
  const { data, loading, error, refetch } = useApi<{ classes: ClassInfo[] }>('/classes');

  const [form, setForm] = useState({
    first_name: '',
    last_name: '',
    father_name: '',
    cnic_no: '',
    board_registration_no: '',
    roll_number: '',
    admission_no: '',
    gender: 'M',
    dob: '',
    phone: '',
    address: '',
    class_section_id: '',
    guardian_name: '',
    guardian_relation: '',
    guardian_phone: '',
  });
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  if (loading) return <Loading />;
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={refetch} />;

  const set = (key: keyof typeof form) => (value: string) => setForm((f) => ({ ...f, [key]: value }));
  const selected = data.classes.find((c) => String(c.id) === form.class_section_id);

  const submit = async () => {
    setSaving(true);
    setErr(null);
    setMsg(null);
    try {
      const res = await api.post<{ student: { full_name: string } }>('/students', {
        ...form,
        class_section_id: Number(form.class_section_id),
      });
      setMsg(`${res.student.full_name} added successfully.`);
      setTimeout(() => navigation.goBack(), 900);
    } catch (e) {
      setErr(e instanceof ApiError ? e.message : 'Could not add student.');
    } finally {
      setSaving(false);
    }
  };

  const canSubmit =
    form.first_name && form.last_name && form.class_section_id && !saving;

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <ScreenHeader title="Add Student" subtitle="Register a new student" />
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <SectionHeader title="Personal Details" />
        <Card style={styles.card}>
          <Field label="First Name *" value={form.first_name} onChangeText={set('first_name')} />
          <Field label="Last Name *" value={form.last_name} onChangeText={set('last_name')} />
          <Field label="Father Name" value={form.father_name} onChangeText={set('father_name')} />
          <Field label="CNIC / B-Form No" value={form.cnic_no} onChangeText={set('cnic_no')} keyboardType="default" />
          <Field label="Board Registration No" value={form.board_registration_no} onChangeText={set('board_registration_no')} />
          <Field label="Roll Number" value={form.roll_number} onChangeText={set('roll_number')} keyboardType="number-pad" />
          <Field label="Admission No (optional)" value={form.admission_no} onChangeText={set('admission_no')} autoCapitalize="characters" />

          <Text style={[typography.label, styles.label]}>Gender</Text>
          <View style={styles.genderRow}>
            {[
              { v: 'M', l: 'Male' },
              { v: 'F', l: 'Female' },
              { v: 'Other', l: 'Other' },
            ].map((g) => (
              <Pressable
                key={g.v}
                onPress={() => set('gender')(g.v)}
                style={[styles.genderChip, form.gender === g.v && { backgroundColor: colors.primary }]}
              >
                <Text style={[styles.genderText, form.gender === g.v && { color: colors.white }]}>{g.l}</Text>
              </Pressable>
            ))}
          </View>

          <Field label="Date of Birth (YYYY-MM-DD)" value={form.dob} onChangeText={set('dob')} placeholder="2010-05-15" />
          <Field label="Phone" value={form.phone} onChangeText={set('phone')} keyboardType="phone-pad" />
          <Field label="Address" value={form.address} onChangeText={set('address')} multiline />
        </Card>

        <SectionHeader title="Guardian (optional)" />
        <Card style={styles.card}>
          <Field label="Guardian Name" value={form.guardian_name} onChangeText={set('guardian_name')} />
          <Field label="Relation" value={form.guardian_relation} onChangeText={set('guardian_relation')} placeholder="Father / Mother / Uncle..." />
          <Field label="Guardian Phone" value={form.guardian_phone} onChangeText={set('guardian_phone')} keyboardType="phone-pad" />
        </Card>

        <SectionHeader title="Class Assignment *" />
        <Card style={styles.card}>
          <Text style={[typography.label, styles.label]}>Class / Section</Text>
          <ScrollView horizontal style={styles.classBar} contentContainerStyle={styles.classBarContent}>
            {data.classes.map((c) => (
              <Pressable
                key={c.id}
                onPress={() => set('class_section_id')(String(c.id))}
                style={[styles.classChip, form.class_section_id === String(c.id) && { backgroundColor: colors.primary }]}
              >
                <Text style={[styles.classText, form.class_section_id === String(c.id) && { color: colors.white }]}>
                  {c.class_name} - {c.section}
                </Text>
              </Pressable>
            ))}
          </ScrollView>
          {selected ? <Text style={[typography.caption, styles.hint]}>{selected.studentCount} students currently enrolled</Text> : null}
        </Card>

        {msg ? <Text style={styles.success}>{msg}</Text> : null}
        {err ? <Text style={styles.error}>{err}</Text> : null}

        <Pressable style={({ pressed }) => [styles.submit, (!canSubmit || pressed) && { opacity: 0.8 }]} onPress={submit} disabled={!canSubmit}>
          {saving ? <ActivityIndicator color={colors.white} /> : <Text style={styles.submitText}>Add Student</Text>}
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

function Field({
  label,
  value,
  onChangeText,
  placeholder,
  keyboardType,
  multiline,
  autoCapitalize,
}: {
  label: string;
  value: string;
  onChangeText: (t: string) => void;
  placeholder?: string;
  keyboardType?: 'default' | 'phone-pad' | 'number-pad';
  multiline?: boolean;
  autoCapitalize?: 'none' | 'words' | 'characters';
}) {
  return (
    <>
      <Text style={[typography.label, styles.label]}>{label}</Text>
      <TextInput
        style={[styles.input, multiline && styles.inputMultiline]}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.textSecondary}
        keyboardType={keyboardType ?? 'default'}
        multiline={multiline}
        autoCapitalize={autoCapitalize}
      />
    </>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  scroll: { flex: 1 },
  content: { padding: spacing.lg, paddingBottom: spacing.xxl },
  card: { paddingVertical: spacing.md },
  label: { color: colors.text, marginBottom: 6, marginTop: 4 },
  input: {
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 15,
    color: colors.text,
    marginBottom: spacing.md,
  },
  inputMultiline: { minHeight: 64, textAlignVertical: 'top' },
  genderRow: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.md },
  genderChip: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: radius.md,
    alignItems: 'center',
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
  },
  genderText: { fontWeight: '600', color: colors.textSecondary },
  classBar: { maxHeight: 44, marginBottom: spacing.sm },
  classBarContent: { gap: spacing.sm },
  classChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: radius.pill,
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
  },
  classText: { fontSize: 13, fontWeight: '600', color: colors.textSecondary },
  hint: { color: colors.textSecondary, marginTop: 4 },
  success: { color: colors.success, fontSize: 14, fontWeight: '600', marginTop: spacing.lg, textAlign: 'center' },
  error: { color: colors.danger, fontSize: 14, marginTop: spacing.lg, textAlign: 'center' },
  submit: {
    backgroundColor: colors.primary,
    borderRadius: radius.md,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: spacing.lg,
  },
  submitText: { color: colors.white, fontWeight: '700', fontSize: 16 },
});
