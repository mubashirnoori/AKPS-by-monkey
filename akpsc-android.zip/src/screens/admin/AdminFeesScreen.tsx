import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Screen, ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { Card, StatCard, SectionHeader, StatusBadge } from '../../components/Card';
import { useApi } from '../../hooks/useApi';
import { colors, spacing, typography } from '../../theme';
import { currency, formatDate } from '../../utils/format';
import type { CollectionsReport } from '../../api/types';

export default function AdminFeesScreen() {
  const { data, loading, error, refetch } = useApi<CollectionsReport>('/admin/collections');

  if (loading) return <Loading />;
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={refetch} />;

  const breakdown = Object.entries(data.categoryBreakdown);

  return (
    <Screen refreshing={loading} onRefresh={refetch}>
      <ScreenHeader title="Fees & Collections" subtitle="Financial overview" />

      <View style={styles.statsRow}>
        <StatCard label="Total Collected" value={currency(data.totalCollected)} icon="💰" color={colors.success} />
        <StatCard label="This Month" value={currency(data.monthCollected)} icon="📅" color={colors.info} />
      </View>

      <SectionHeader title="By Category" />
      <Card style={styles.catCard}>
        {breakdown.map(([cat, amount], i) => (
          <View key={cat} style={[styles.catRow, i === breakdown.length - 1 && styles.last]}>
            <Text style={[typography.body, styles.catName]}>{cat}</Text>
            <Text style={[typography.body, styles.catAmt]}>{currency(amount)}</Text>
          </View>
        ))}
      </Card>

      <SectionHeader title="Pending Dues" />
      {data.pending.map((p) => (
        <Card key={p.id} style={styles.pendingCard}>
          <View style={styles.pendingTop}>
            <View style={styles.pendingInfo}>
              <Text style={[typography.body, styles.pendingName]} numberOfLines={1}>{p.student_name}</Text>
              <Text style={[typography.caption, styles.pendingMeta]}>
                {p.description} · due {formatDate(p.due_date)}
              </Text>
            </View>
            <StatusBadge status={p.balance > 0 ? 'Unpaid' : 'Paid'} />
          </View>
          <View style={styles.pendingAmt}>
            <Text style={[typography.caption, { color: colors.textSecondary }]}>Balance</Text>
            <Text style={[typography.subheading, { color: colors.danger }]}>{currency(p.balance)}</Text>
          </View>
        </Card>
      ))}
      {data.pending.length === 0 ? <Text style={styles.empty}>No pending dues.</Text> : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  statsRow: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.lg },
  catCard: { paddingTop: 4, paddingBottom: 4, marginBottom: spacing.lg },
  catRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  last: { borderBottomWidth: 0 },
  catName: { color: colors.text },
  catAmt: { color: colors.text, fontWeight: '600' },
  pendingCard: { marginBottom: spacing.sm },
  pendingTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  pendingInfo: { flex: 1, marginRight: spacing.sm },
  pendingName: { color: colors.text },
  pendingMeta: { color: colors.textSecondary, marginTop: 2 },
  pendingAmt: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: spacing.sm },
  empty: { color: colors.textSecondary, textAlign: 'center', padding: spacing.xl },
});
