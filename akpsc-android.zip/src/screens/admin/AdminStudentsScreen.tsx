import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Screen, ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { Card, StatusBadge } from '../../components/Card';
import { Avatar } from '../../components/List';
import { useApi } from '../../hooks/useApi';
import { colors, spacing, typography, radius } from '../../theme';
import type { RootStackParamList } from '../../navigation/types';
import type { StudentProfile } from '../../api/types';

export default function AdminStudentsScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const [search, setSearch] = useState('');
  const [classFilter, setClassFilter] = useState<string>('');
  const { data, loading, error, refetch } = useApi<{ students: StudentProfile[] }>(
    `/students${classFilter ? `?class_id=${classFilter}` : ''}`
  );

  const filtered = data?.students.filter((s) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (s.full_name + s.admission_no).toLowerCase().includes(q);
  });

  if (loading) return <Loading />;
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={refetch} />;

  return (
    <Screen refreshing={loading} onRefresh={refetch}>
      <ScreenHeader
        title="Students"
        subtitle={`${data.students.length} records`}
        right={
          <Pressable style={({ pressed }) => [styles.addBtn, pressed && { opacity: 0.8 }]} onPress={() => navigation.navigate('AddStudent')}>
            <Text style={styles.addBtnText}>+ Add</Text>
          </Pressable>
        }
      />

      <TextInput
        style={styles.search}
        value={search}
        onChangeText={setSearch}
        placeholder="Search by name or admission no"
        placeholderTextColor={colors.textSecondary}
      />
      <View style={styles.filters}>
        {['', '1', '2'].map((cid) => (
          <Pressable
            key={cid}
            onPress={() => setClassFilter(cid)}
            style={[styles.filterChip, classFilter === cid && styles.filterActive]}
          >
            <Text style={[styles.filterText, classFilter === cid && { color: colors.white }]}>
              {cid === '' ? 'All' : cid === '1' ? 'Class 10' : 'Class 9'}
            </Text>
          </Pressable>
        ))}
      </View>

      {filtered?.map((s) => (
        <Pressable key={s.id} onPress={() => navigation.navigate('StudentDetail', { studentId: s.id })}>
          <Card style={styles.card}>
            <Avatar name={s.full_name} size={44} />
            <View style={styles.info}>
              <Text style={[typography.body, styles.name]} numberOfLines={1}>{s.full_name}</Text>
              <Text style={[typography.caption, styles.meta]}>
                {s.class_name}-{s.section} · {s.admission_no}
              </Text>
            </View>
            <StatusBadge status={s.status} />
          </Card>
        </Pressable>
      ))}
    </Screen>
  );
}

const styles = StyleSheet.create({
  search: {
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 15,
    color: colors.text,
    marginBottom: spacing.sm,
  },
  filters: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.md },
  addBtn: {
    backgroundColor: colors.primary,
    borderRadius: radius.pill,
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  addBtnText: { color: colors.white, fontWeight: '700', fontSize: 13 },
  filterChip: {
    paddingHorizontal: 16,
    paddingVertical: 7,
    borderRadius: radius.pill,
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
  },
  filterActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  filterText: { fontSize: 13, fontWeight: '600', color: colors.textSecondary },
  card: { flexDirection: 'row', alignItems: 'center', marginBottom: spacing.sm, paddingVertical: 10 },
  info: { flex: 1, marginLeft: spacing.md, marginRight: spacing.sm },
  name: { color: colors.text },
  meta: { color: colors.textSecondary, marginTop: 2 },
});
