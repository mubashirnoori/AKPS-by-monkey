import React, { useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { Card, SectionHeader } from '../../components/Card';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { api, ApiError } from '../../api/client';
import { useApi } from '../../hooks/useApi';
import { colors, spacing, typography, radius } from '../../theme';
import type { ExpenseCategory } from '../../api/types';

function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

export default function AddExpenseScreen() {
  const navigation = useNavigation();
  const { data, loading, error, refetch } = useApi<{ categories: ExpenseCategory[] }>('/expenses/categories');

  const [categoryId, setCategoryId] = useState<number | null>(null);
  const [newCategory, setNewCategory] = useState('');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [expenseDate, setExpenseDate] = useState(todayIso());
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  if (loading) return <Loading />;
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={refetch} />;

  const addCategory = async () => {
    const name = newCategory.trim();
    if (!name) return;
    try {
      const res = await api.post<{ category: ExpenseCategory }>('/expenses/categories', { name });
      setNewCategory('');
      setCategoryId(res.category.id);
      refetch();
    } catch (e) {
      setErr(e instanceof ApiError ? e.message : 'Could not add category.');
    }
  };

  const submit = async () => {
    setSaving(true);
    setErr(null);
    setMsg(null);
    try {
      await api.post('/expenses', {
        expense_category_id: categoryId,
        description: description.trim(),
        amount: Number(amount),
        expense_date: expenseDate,
      });
      setMsg('Expense recorded.');
      setTimeout(() => navigation.goBack(), 700);
    } catch (e) {
      setErr(e instanceof ApiError ? e.message : 'Could not record expense.');
    } finally {
      setSaving(false);
    }
  };

  const parsedAmount = Number(amount);
  const canSubmit = !!categoryId && parsedAmount > 0 && !saving;

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <ScreenHeader title="Add Expense" subtitle="Record a school expense" />
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <SectionHeader title="Category *" />
        <Card style={styles.card}>
          <ScrollView horizontal contentContainerStyle={styles.chipRow}>
            {data.categories.map((c) => (
              <Pressable
                key={c.id}
                onPress={() => setCategoryId(c.id)}
                style={[styles.chip, categoryId === c.id && { backgroundColor: colors.primary }]}
              >
                <Text style={[styles.chipText, categoryId === c.id && { color: colors.white }]}>{c.name}</Text>
              </Pressable>
            ))}
          </ScrollView>

          <Text style={[typography.label, styles.label]}>Add new category</Text>
          <View style={styles.newCatRow}>
            <TextInput
              style={[styles.input, styles.newCatInput]}
              value={newCategory}
              onChangeText={setNewCategory}
              placeholder="e.g. Furniture"
              placeholderTextColor={colors.textSecondary}
            />
            <Pressable style={styles.newCatBtn} onPress={addCategory} disabled={!newCategory.trim()}>
              <Text style={styles.newCatBtnText}>Add</Text>
            </Pressable>
          </View>
        </Card>

        <SectionHeader title="Details" />
        <Card style={styles.card}>
          <Text style={[typography.label, styles.label]}>Amount (Rs) *</Text>
          <TextInput
            style={styles.input}
            value={amount}
            onChangeText={setAmount}
            keyboardType="numeric"
            placeholder="0"
            placeholderTextColor={colors.textSecondary}
          />

          <Text style={[typography.label, styles.label]}>Description</Text>
          <TextInput
            style={[styles.input, styles.inputMultiline]}
            value={description}
            onChangeText={setDescription}
            placeholder="What was this expense for?"
            placeholderTextColor={colors.textSecondary}
            multiline
          />

          <Text style={[typography.label, styles.label]}>Date (YYYY-MM-DD)</Text>
          <TextInput
            style={styles.input}
            value={expenseDate}
            onChangeText={setExpenseDate}
            placeholder={todayIso()}
            placeholderTextColor={colors.textSecondary}
          />
        </Card>

        {msg ? <Text style={styles.success}>{msg}</Text> : null}
        {err ? <Text style={styles.error}>{err}</Text> : null}

        <Pressable style={({ pressed }) => [styles.submit, (!canSubmit || pressed) && { opacity: 0.8 }]} onPress={submit} disabled={!canSubmit}>
          {saving ? <ActivityIndicator color={colors.white} /> : <Text style={styles.submitText}>Save Expense</Text>}
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  scroll: { flex: 1 },
  content: { padding: spacing.lg, paddingBottom: spacing.xxl },
  card: { paddingVertical: spacing.md },
  label: { color: colors.text, marginBottom: 6, marginTop: 4 },
  input: {
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 15,
    color: colors.text,
    marginBottom: spacing.md,
  },
  inputMultiline: { minHeight: 64, textAlignVertical: 'top' },
  chipRow: { gap: spacing.sm, paddingBottom: spacing.sm },
  chip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: radius.pill,
    backgroundColor: colors.background,
    borderWidth: 1,
    borderColor: colors.border,
  },
  chipText: { fontSize: 13, fontWeight: '600', color: colors.textSecondary },
  newCatRow: { flexDirection: 'row', gap: spacing.sm, alignItems: 'center' },
  newCatInput: { flex: 1, marginBottom: 0 },
  newCatBtn: {
    backgroundColor: colors.primaryLight,
    borderRadius: radius.md,
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  newCatBtnText: { color: colors.primaryDark, fontWeight: '700', fontSize: 13 },
  success: { color: colors.success, fontSize: 14, fontWeight: '600', marginTop: spacing.lg, textAlign: 'center' },
  error: { color: colors.danger, fontSize: 14, marginTop: spacing.lg, textAlign: 'center' },
  submit: {
    backgroundColor: colors.primary,
    borderRadius: radius.md,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: spacing.lg,
  },
  submitText: { color: colors.white, fontWeight: '700', fontSize: 16 },
});
