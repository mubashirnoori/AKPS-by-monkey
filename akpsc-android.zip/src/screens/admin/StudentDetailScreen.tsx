import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { Card, StatCard, SectionHeader, StatusBadge } from '../../components/Card';
import { Avatar, InfoRow } from '../../components/List';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useApi } from '../../hooks/useApi';
import { colors, spacing, typography, radius } from '../../theme';
import { currency, formatDate } from '../../utils/format';
import type { RouteProp } from '@react-navigation/native';
import type { RootStackParamList } from '../../navigation/types';
import type { StudentProfile, AttendanceSummary, FeeSummary } from '../../api/types';

export default function StudentDetailScreen({ route }: { route: RouteProp<RootStackParamList, 'StudentDetail'> }) {
  const { studentId } = route.params;
  const profile = useApi<{ student: StudentProfile }>(`/students/${studentId}`);
  const attendance = useApi<{ summary: AttendanceSummary }>(`/students/${studentId}/attendance`);
  const fees = useApi<{ summary: FeeSummary }>(`/students/${studentId}/fees`);

  if (profile.loading || attendance.loading || fees.loading) return <Loading />;
  if (profile.error) return <ErrorState message={profile.error} onRetry={profile.refetch} />;
  if (!profile.data) return null;

  const s = profile.data.student;
  const att = attendance.data?.summary;
  const fee = fees.data?.summary;

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <ScreenHeader title={s.full_name} subtitle={`${s.admission_no} · ${s.class_name}-${s.section}`} />
      <View style={styles.content}>
        <Card style={styles.hero}>
          <Avatar name={s.full_name} size={64} />
          <View style={styles.heroText}>
            <Text style={[typography.subheading, styles.heroName]}>{s.full_name}</Text>
            <Text style={[typography.caption, styles.heroMeta]}>
              Roll #{s.roll_number} · {s.gender} · {formatDate(s.dob)}
            </Text>
            <Text style={[typography.caption, styles.heroMeta]}>{s.phone} · {s.email}</Text>
          </View>
          <StatusBadge status={s.status} />
        </Card>

        <View style={styles.statsRow}>
          <StatCard label="Attendance" value={att ? `${att.percentage}%` : '—'} icon="📋" color={colors.info} />
          <StatCard label="Total Paid" value={fee ? currency(fee.totalPaid) : '—'} icon="✅" color={colors.success} />
          <StatCard label="Due" value={fee ? currency(fee.totalDue) : '—'} icon="⏳" color={colors.danger} />
        </View>

        <SectionHeader title="Guardian" />
        <Card style={styles.card}>
          <InfoRow label="Name" value={s.guardian.name} icon="🧑‍⚕️" />
          <InfoRow label="Relation" value={s.guardian.relation} icon="🔗" />
          <InfoRow label="Phone" value={s.guardian.phone} icon="📞" />
        </Card>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  content: { padding: spacing.lg, paddingBottom: spacing.xxl },
  hero: { flexDirection: 'row', alignItems: 'center', marginBottom: spacing.lg },
  heroText: { flex: 1, marginLeft: spacing.md, marginRight: spacing.sm },
  heroName: { color: colors.text },
  heroMeta: { color: colors.textSecondary, marginTop: 2 },
  statsRow: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.lg },
  card: { paddingTop: spacing.xs, paddingBottom: spacing.xs },
});
