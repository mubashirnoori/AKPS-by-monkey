import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Screen, ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { StatCard, SectionHeader } from '../../components/Card';
import { NoticeCard } from '../../components/NoticeCard';
import { useApi } from '../../hooks/useApi';
import { colors, spacing } from '../../theme';
import { currency } from '../../utils/format';
import type { DashboardAdmin } from '../../api/types';

export default function AdminHomeScreen() {
  const { data, loading, error, refetch } = useApi<DashboardAdmin>('/dashboard');

  if (loading) return <Loading />;
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={refetch} />;

  const { stats, notices } = data;

  return (
    <Screen refreshing={loading} onRefresh={refetch}>
      <ScreenHeader title="Overview" subtitle="Institute at a glance" />

      <SectionHeader title="Students" />
      <View style={styles.row}>
        <StatCard label="Total Students" value={stats.totalStudents} icon="👥" color={colors.primary} />
        <StatCard label="Active" value={stats.activeStudents} icon="✅" color={colors.success} />
      </View>

      <SectionHeader title="Finance" />
      <View style={styles.row}>
        <StatCard label="Monthly Collected" value={currency(stats.monthlyCollected)} icon="💰" color={colors.info} />
        <StatCard label="Pending Dues" value={currency(stats.pendingDues)} icon="⏳" color={colors.danger} />
      </View>
      <View style={styles.row}>
        <StatCard label="Collected (Year)" value={currency(stats.yearlyCollected)} icon="🧾" color={colors.success} />
        <StatCard label="Expenses (Year)" value={currency(stats.yearlyExpenses)} icon="📤" color={colors.warning} />
      </View>
      <View style={styles.row}>
        <StatCard label="Net Balance" value={currency(stats.netBalance)} icon="📊" color={colors.primary} />
      </View>

      <SectionHeader title="Institute" />
      <View style={styles.row}>
        <StatCard label="Staff" value={stats.totalStaff} icon="🧑‍🏫" color={colors.warning} />
        <StatCard label="Classes" value={stats.classes} icon="🏫" color={colors.info} />
      </View>

      <SectionHeader title="Announcements" />
      {notices.map((n) => (
        <NoticeCard key={n.id} notice={n} />
      ))}
    </Screen>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.md },
});
