import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Screen, ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { Card, StatCard, SectionHeader } from '../../components/Card';
import { useApi } from '../../hooks/useApi';
import { colors, spacing, typography, radius } from '../../theme';
import { currency, formatDate } from '../../utils/format';
import type { RootStackParamList } from '../../navigation/types';
import type { ExpensesResponse } from '../../api/types';

const MONTH_NAMES = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

export default function AdminExpensesScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year] = useState(now.getFullYear());

  const { data, loading, error, refetch } = useApi<ExpensesResponse>(`/expenses?month=${month}&year=${year}`);

  if (loading) return <Loading />;
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={refetch} />;

  // Group this month's expenses by category for a quick breakdown, same as the web dashboard.
  const byCategory = data.expenses.reduce<Record<string, number>>((acc, e) => {
    acc[e.category_name] = (acc[e.category_name] ?? 0) + e.amount;
    return acc;
  }, {});

  return (
    <Screen refreshing={loading} onRefresh={refetch}>
      <ScreenHeader
        title="Expenses"
        subtitle="Other school expenses"
        right={
          <Pressable style={({ pressed }) => [styles.addBtn, pressed && { opacity: 0.8 }]} onPress={() => navigation.navigate('AddExpense')}>
            <Text style={styles.addBtnText}>+ Add</Text>
          </Pressable>
        }
      />

      <View style={styles.statsRow}>
        <StatCard label={`${MONTH_NAMES[month - 1]} ${year}`} value={currency(data.total)} icon="🧾" color={colors.danger} />
      </View>

      <View style={styles.monthBar}>
        {MONTH_NAMES.map((m, i) => (
          <Pressable
            key={m}
            onPress={() => setMonth(i + 1)}
            style={[styles.monthChip, month === i + 1 && styles.monthChipActive]}
          >
            <Text style={[styles.monthText, month === i + 1 && { color: colors.white }]}>{m}</Text>
          </Pressable>
        ))}
      </View>

      {Object.keys(byCategory).length > 0 ? (
        <>
          <SectionHeader title="By Category" />
          <Card style={styles.catCard}>
            {Object.entries(byCategory).map(([cat, amount], i, arr) => (
              <View key={cat} style={[styles.catRow, i === arr.length - 1 && styles.last]}>
                <Text style={[typography.body, styles.catName]}>{cat}</Text>
                <Text style={[typography.body, styles.catAmt]}>{currency(amount)}</Text>
              </View>
            ))}
          </Card>
        </>
      ) : null}

      <SectionHeader title="Entries" />
      {data.expenses.map((e) => (
        <Card key={e.id} style={styles.expCard}>
          <View style={styles.expTop}>
            <View style={styles.expInfo}>
              <Text style={[typography.body, styles.expDesc]} numberOfLines={1}>
                {e.description || e.category_name}
              </Text>
              <Text style={[typography.caption, styles.expMeta]}>
                {e.category_name} · {formatDate(e.expense_date)}
              </Text>
            </View>
            <Text style={[typography.subheading, styles.expAmt]}>{currency(e.amount)}</Text>
          </View>
        </Card>
      ))}
      {data.expenses.length === 0 ? <Text style={styles.empty}>No expenses recorded for this month.</Text> : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  statsRow: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.lg },
  addBtn: {
    backgroundColor: colors.primary,
    borderRadius: radius.pill,
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  addBtnText: { color: colors.white, fontWeight: '700', fontSize: 13 },
  monthBar: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs, marginBottom: spacing.lg },
  monthChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: radius.pill,
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
  },
  monthChipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  monthText: { fontSize: 12, fontWeight: '600', color: colors.textSecondary },
  catCard: { paddingTop: 4, paddingBottom: 4, marginBottom: spacing.lg },
  catRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  last: { borderBottomWidth: 0 },
  catName: { color: colors.text },
  catAmt: { color: colors.text, fontWeight: '600' },
  expCard: { marginBottom: spacing.sm },
  expTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  expInfo: { flex: 1, marginRight: spacing.sm },
  expDesc: { color: colors.text },
  expMeta: { color: colors.textSecondary, marginTop: 2 },
  expAmt: { color: colors.danger },
  empty: { color: colors.textSecondary, textAlign: 'center', padding: spacing.xl },
});
