import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { Screen, ScreenHeader } from '../../components/Screen';
import { Card } from '../../components/Card';
import { ListItem, Divider } from '../../components/List';
import { colors, spacing, typography, radius } from '../../theme';
import { resolveIcon } from '../../utils/icons';
import type { RootStackParamList } from '../../navigation/types';

type Nav = NativeStackNavigationProp<RootStackParamList>;

// Each entry mirrors one item in the web sidebar. `screen` means it already
// exists in the app; omit it and it opens ComingSoon with this label instead.
type MenuLeaf = { label: string; icon: string; screen?: keyof RootStackParamList };
type MenuSection = { label: string; icon: string; color: string; items: MenuLeaf[] };

const SECTIONS: MenuSection[] = [
  {
    label: 'Students',
    icon: '🎓',
    color: colors.primary,
    items: [
      { label: 'All Students', icon: '📋' },
      { label: 'Add Student', icon: '➕', screen: 'AddStudent' },
      { label: 'Attendance', icon: '✅', screen: 'AdminAttendance' },
      { label: 'Promotions', icon: '⬆️' },
      { label: 'Leave Requests', icon: '📆' },
      { label: 'Inquiries', icon: '❓' },
      { label: 'Complaints', icon: '🚩' },
    ],
  },
  {
    label: 'Academic',
    icon: '📖',
    color: colors.info,
    items: [
      { label: 'Academic Overview', icon: '🏠' },
      { label: 'Marks Entry', icon: '📝' },
      { label: 'Exams', icon: '📄' },
      { label: 'Date Sheet', icon: '📅' },
      { label: 'Timetable', icon: '🕐' },
      { label: 'Subjects', icon: '📚' },
      { label: 'Classes & Sections', icon: '🏫' },
      { label: 'Report Cards', icon: '📃' },
      { label: 'School Topper', icon: '🏆' },
      { label: 'Bulk Exports', icon: '📦' },
      { label: 'ID Cards', icon: '🪪' },
      { label: 'Online Courses', icon: '▶️' },
    ],
  },
  {
    label: 'Fees',
    icon: '💳',
    color: colors.success,
    items: [
      { label: 'Cash Collection', icon: '🗂️' },
      { label: 'Invoices', icon: '📃' },
      { label: 'Generate Invoices', icon: '➕' },
      { label: 'Pending Dues', icon: '⚠️' },
      { label: 'Bulk Exports', icon: '📦' },
      { label: 'Fee Categories', icon: '🏷️' },
      { label: 'Fee Assignments', icon: '🔗' },
      { label: 'Fee Settings', icon: '⚙️' },
    ],
  },
  {
    label: 'Staff & HR',
    icon: '👥',
    color: colors.warning,
    items: [
      { label: 'Staff Profiles', icon: '🧑‍💼' },
      { label: 'Payroll', icon: '📇' },
      { label: 'Staff Attendance', icon: '✅' },
      { label: 'Leave Requests', icon: '📆' },
      { label: 'Performance', icon: '⭐' },
      { label: 'Fee Collection Assignments', icon: '🔗' },
    ],
  },
  {
    label: 'Users & Roles',
    icon: '👤',
    color: colors.purple,
    items: [
      { label: 'Users', icon: '👥' },
      { label: 'Roles & Permissions', icon: '🛡️' },
      { label: 'Custom Fields', icon: '🏷️' },
      { label: 'My Attendance', icon: '✅' },
    ],
  },
  {
    label: 'Reports',
    icon: '📊',
    color: colors.teal,
    items: [
      { label: 'Student Attendance', icon: '👤' },
      { label: 'Exam Marks', icon: '📄' },
      { label: 'Fee Collections', icon: '💳' },
      { label: 'Staff Attendance', icon: '🧑‍💼' },
      { label: 'Custom Generator', icon: '⚙️' },
    ],
  },
  {
    label: 'Settings',
    icon: '⚙️',
    color: colors.textSecondary,
    items: [
      { label: 'Global Settings', icon: '🔧' },
      { label: 'Academic Years', icon: '📅' },
      { label: 'Institute Info', icon: '🏫' },
      { label: 'Branding', icon: '🎨' },
      { label: 'Label Management', icon: '🏷️' },
      { label: 'Notifications', icon: '🔔' },
      { label: 'Clean Data', icon: '🧹' },
      { label: 'Backup & Restore', icon: '☁️' },
    ],
  },
];

export default function AdminMenuScreen() {
  const navigation = useNavigation<Nav>();
  const [open, setOpen] = useState<Record<string, boolean>>({ Students: true });
  const [query, setQuery] = useState('');

  const toggle = (label: string) => setOpen((o) => ({ ...o, [label]: !o[label] }));

  const goTo = (item: MenuLeaf) => {
    if (item.screen) {
      navigation.navigate(item.screen as never);
    } else {
      navigation.navigate('ComingSoon', { title: item.label });
    }
  };

  const q = query.trim().toLowerCase();
  const isSearching = q.length > 0;

  // While searching, only show sections that have a match, with only the
  // matching rows inside — no need to tap through 7 collapsed accordions to
  // find one thing. Clear the search and it's back to normal browsing.
  const visibleSections = useMemo(() => {
    if (!isSearching) return SECTIONS;
    return SECTIONS.map((s) => ({
      ...s,
      items: s.items.filter((i) => i.label.toLowerCase().includes(q) || s.label.toLowerCase().includes(q)),
    })).filter((s) => s.items.length > 0);
  }, [q, isSearching]);

  return (
    <Screen>
      <ScreenHeader title="Menu" subtitle="Everything on the web portal" />

      <View style={styles.searchWrap}>
        <Ionicons name="search" size={18} color={colors.textSecondary} style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          value={query}
          onChangeText={setQuery}
          placeholder="Search the menu…"
          placeholderTextColor={colors.textSecondary}
          autoCapitalize="none"
          autoCorrect={false}
        />
        {query.length > 0 ? (
          <Pressable onPress={() => setQuery('')} hitSlop={8}>
            <Ionicons name="close-circle" size={18} color={colors.textSecondary} />
          </Pressable>
        ) : null}
      </View>

      {visibleSections.length === 0 ? (
        <View style={styles.emptyWrap}>
          <Ionicons name="search-outline" size={32} color={colors.textSecondary} />
          <Text style={styles.emptyText}>No matches for "{query}"</Text>
        </View>
      ) : (
        visibleSections.map((section) => {
          const expanded = isSearching || open[section.label];
          return (
            <View key={section.label} style={styles.section}>
              <Card style={styles.card} accentColor={section.color}>
                <Pressable
                  onPress={() => toggle(section.label)}
                  style={styles.sectionHeader}
                  disabled={isSearching}
                >
                  <View style={[styles.sectionIconWrap, { backgroundColor: section.color + '17' }]}>
                    {resolveIcon(section.icon) ? (
                      <Ionicons name={resolveIcon(section.icon)!} size={18} color={section.color} />
                    ) : (
                      <Text style={styles.sectionIcon}>{section.icon}</Text>
                    )}
                  </View>
                  <Text style={[typography.body, styles.sectionLabel]}>{section.label}</Text>
                  <View style={[styles.countBadge, { backgroundColor: section.color + '17' }]}>
                    <Text style={[styles.countText, { color: section.color }]}>{section.items.length}</Text>
                  </View>
                  {!isSearching ? (
                    <Ionicons
                      name={expanded ? 'chevron-down' : 'chevron-forward'}
                      size={18}
                      color={colors.textSecondary}
                      style={styles.chevron}
                    />
                  ) : null}
                </Pressable>
                {expanded ? (
                  <View>
                    <Divider />
                    {section.items.map((item, i) => (
                      <ListItem
                        key={item.label}
                        icon={item.icon}
                        title={item.label}
                        onPress={() => goTo(item)}
                        last={i === section.items.length - 1}
                        accentColor={section.color}
                      />
                    ))}
                  </View>
                ) : null}
              </Card>
            </View>
          );
        })
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  searchWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: spacing.md,
    height: 46,
    marginBottom: spacing.lg,
  },
  searchIcon: { marginRight: spacing.sm },
  searchInput: { flex: 1, color: colors.text, fontSize: 15, paddingVertical: 0 },
  emptyWrap: { alignItems: 'center', paddingTop: spacing.xxl },
  emptyText: { color: colors.textSecondary, marginTop: spacing.sm },
  section: { marginBottom: spacing.md },
  card: { paddingVertical: 0, paddingHorizontal: 0, overflow: 'hidden' },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
  },
  sectionIconWrap: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.sm,
  },
  sectionIcon: { fontSize: 16 },
  sectionLabel: { flex: 1, fontWeight: '700', color: colors.text },
  countBadge: {
    minWidth: 24,
    paddingHorizontal: 7,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.sm,
  },
  countText: { fontSize: 12, fontWeight: '700' },
  chevron: { marginLeft: 2 },
});
