import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Screen, ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { Card, StatCard, SectionHeader } from '../../components/Card';
import { NoticeCard } from '../../components/NoticeCard';
import { useAuth } from '../../auth/AuthContext';
import { useApi } from '../../hooks/useApi';
import { colors, spacing, typography, radius, shadow } from '../../theme';
import type { RootStackParamList } from '../../navigation/types';
import type { DashboardTeacher } from '../../api/types';

export default function TeacherHomeScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { user } = useAuth();
  const { data, loading, error, refetch } = useApi<DashboardTeacher>('/dashboard');

  if (loading) return <Loading />;
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={refetch} />;

  const { teacher, myClasses, notices } = data;
  const studentCount = myClasses.reduce((s, c) => s + c.studentCount, 0);

  return (
    <Screen refreshing={loading} onRefresh={refetch}>
      <ScreenHeader title={`Welcome,`} subtitle={teacher.name} />

      <View style={styles.statsRow}>
        <StatCard label="My Classes" value={myClasses.length} icon="🏫" color={colors.primary} />
        <StatCard label="Students" value={studentCount} icon="👥" color={colors.info} />
        <StatCard label="Subject" value={teacher.subject} icon="📚" color={colors.success} />
      </View>

      <SectionHeader title="Quick Actions" />
      <View style={styles.quickRow}>
        {myClasses.slice(0, 2).map((c) => (
          <Pressable
            key={c.id}
            style={({ pressed }) => [styles.quickCard, pressed && { opacity: 0.8 }]}
            onPress={() => navigation.navigate('TakeAttendance', { classId: c.id, className: `${c.class_name}-${c.section}`, subject: c.subject ?? '' })}
          >
            <Text style={styles.quickIcon}>📋</Text>
            <Text style={[typography.subheading, styles.quickTitle]}>{c.class_name}-{c.section}</Text>
            <Text style={[typography.caption, styles.quickSub]}>{c.subject}</Text>
            <Text style={[typography.caption, styles.quickSub]}>{c.studentCount} students</Text>
          </Pressable>
        ))}
        {myClasses.length === 0 ? (
          <Card style={styles.noClass}>
            <Text style={[typography.body, { color: colors.textSecondary }]}>No classes assigned yet.</Text>
          </Card>
        ) : null}
      </View>

      <SectionHeader title="Announcements" />
      {notices.map((n) => (
        <NoticeCard key={n.id} notice={n} />
      ))}
    </Screen>
  );
}

const styles = StyleSheet.create({
  statsRow: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.xl },
  quickRow: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.xl },
  quickCard: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.lg,
    ...shadow.card,
  },
  quickIcon: { fontSize: 24, marginBottom: 8 },
  quickTitle: { color: colors.text },
  quickSub: { color: colors.textSecondary, marginTop: 2 },
  noClass: { flex: 1 },
});
