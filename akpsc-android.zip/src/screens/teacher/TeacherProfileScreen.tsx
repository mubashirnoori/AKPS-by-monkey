import React from 'react';
import { Pressable, StyleSheet, Text } from 'react-native';
import { Screen, ScreenHeader } from '../../components/Screen';
import { Card, SectionHeader } from '../../components/Card';
import { Avatar, InfoRow } from '../../components/List';
import { useAuth } from '../../auth/AuthContext';
import { useApi } from '../../hooks/useApi';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../../navigation/types';
import { colors, spacing, typography, radius } from '../../theme';

export default function TeacherProfileScreen() {
  const { user, logout } = useAuth();
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { data } = useApi<{ teacher: { name: string; designation: string; subject: string } }>('/dashboard');

  const teacher = data?.teacher;

  return (
    <Screen>
      <ScreenHeader title="Profile" />

      <Card style={styles.hero}>
        <Avatar name={user?.name ?? 'Teacher'} size={72} />
        <Text style={[typography.title, styles.name]}>{user?.name}</Text>
        <Text style={[typography.caption, styles.sub]}>{teacher?.designation ?? 'Teacher'}</Text>
      </Card>

      <SectionHeader title="Account" />
      <Card style={styles.card}>
        <InfoRow label="Username" value={user?.username} icon="👤" />
        <InfoRow label="Email" value={user?.email} icon="📧" />
        <InfoRow label="Subject" value={teacher?.subject ?? '—'} icon="📚" />
        <InfoRow label="Role" value="Teacher" icon="🏷️" />
      </Card>

      <SectionHeader title="Preferences" />
      <Card style={styles.card}>
        <Pressable onPress={() => navigation.navigate('Settings')}>
          <InfoRow label="Settings" value="Connection, password" icon="⚙️" />
        </Pressable>
      </Card>

      <Pressable style={({ pressed }) => [styles.logout, pressed && { opacity: 0.8 }]} onPress={logout}>
        <Text style={styles.logoutText}>Sign Out</Text>
      </Pressable>
    </Screen>
  );
}

const styles = StyleSheet.create({
  hero: { alignItems: 'center', marginBottom: spacing.lg },
  name: { color: colors.text, marginTop: spacing.md },
  sub: { color: colors.textSecondary, marginTop: 4 },
  card: { paddingTop: spacing.xs, paddingBottom: spacing.xs },
  logout: {
    marginTop: spacing.xl,
    backgroundColor: colors.dangerLight,
    borderRadius: radius.md,
    paddingVertical: 14,
    alignItems: 'center',
  },
  logoutText: { color: colors.danger, fontWeight: '700', fontSize: 15 },
});
