import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { Card } from '../../components/Card';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useApi } from '../../hooks/useApi';
import { api } from '../../api/client';
import { colors, spacing, typography, radius } from '../../theme';
import type { RouteProp } from '@react-navigation/native';
import type { RootStackParamList } from '../../navigation/types';

type MarksRow = { student_id: number; name: string; roll_number: number; marks: { subject: string; marks_obtained: number | null }[] };
type MarksResponse = { exam_id: number; subjects: string[]; rows: MarksRow[] };

export default function EnterMarksScreen({ route }: { route: RouteProp<RootStackParamList, 'EnterMarks'> }) {
  const { classId, className, subject } = route.params;
  const exams = useApi<{ exams: { id: number; name: string }[] }>('/exams');
  const [examId, setExamId] = useState<number>(1);
  const marks = useApi<MarksResponse>(`/teacher/class/${classId}/marks?exam_id=${examId}`);
  const [values, setValues] = useState<Record<number, string>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (marks.data) {
      const init: Record<number, string> = {};
      marks.data.rows.forEach((r) => {
        const m = r.marks.find((x) => x.subject === subject);
        init[r.student_id] = m?.marks_obtained != null ? String(m.marks_obtained) : '';
      });
      setValues(init);
      setSaved(false);
    }
  }, [marks.data, subject]);

  if (exams.loading || marks.loading) return <Loading />;
  if (exams.error) return <ErrorState message={exams.error} onRetry={exams.refetch} />;
  if (marks.error) return <ErrorState message={marks.error} onRetry={marks.refetch} />;
  if (!exams.data || !marks.data) return null;

  const save = async () => {
    setSaving(true);
    try {
      const rows = Object.entries(values)
        .filter(([, v]) => v.trim() !== '')
        .map(([sid, v]) => ({ student_id: Number(sid), marks_obtained: Math.min(100, Math.max(0, Number(v) || 0)) }));
      await api.post('/teacher/marks', { exam_id: examId, subject, rows });
      setSaved(true);
    } finally {
      setSaving(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <ScreenHeader title={`Enter Marks - ${className}`} subtitle={`${subject} · out of 100`} />

      <ScrollView horizontal style={styles.examBar} contentContainerStyle={styles.examBarContent}>
        {exams.data.exams.map((e) => (
          <Pressable
            key={e.id}
            onPress={() => {
              setExamId(e.id);
              setSaved(false);
            }}
            style={[styles.examChip, e.id === examId && { backgroundColor: colors.primary }]}
          >
            <Text style={[styles.examChipText, e.id === examId && { color: colors.white }]}>{e.name}</Text>
          </Pressable>
        ))}
      </ScrollView>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.content}>
        {saved ? <Text style={styles.saved}>Marks saved.</Text> : null}

        {marks.data.rows.map((r) => {
          const val = values[r.student_id] ?? '';
          const invalid = val !== '' && (Number(val) < 0 || Number(val) > 100);
          return (
            <Card key={r.student_id} style={styles.row}>
              <View style={styles.info}>
                <Text style={[typography.body, styles.name]} numberOfLines={1}>{r.name}</Text>
                <Text style={[typography.caption, styles.meta]}>Roll #{r.roll_number}</Text>
              </View>
              <TextInput
                style={[styles.input, invalid && styles.inputInvalid]}
                value={val}
                onChangeText={(t) => {
                  setValues((prev) => ({ ...prev, [r.student_id]: t.replace(/[^0-9]/g, '') }));
                  setSaved(false);
                }}
                keyboardType="number-pad"
                placeholder="—"
                placeholderTextColor={colors.textSecondary}
                maxLength={3}
              />
            </Card>
          );
        })}

        <Pressable style={({ pressed }) => [styles.saveBtn, (pressed || saving) && { opacity: 0.8 }]} onPress={save} disabled={saving}>
          {saving ? <ActivityIndicator color={colors.white} /> : <Text style={styles.saveText}>Save Marks</Text>}
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  scroll: { flex: 1 },
  content: { padding: spacing.lg, paddingBottom: spacing.xxl },
  examBar: { maxHeight: 48, marginBottom: spacing.md, paddingHorizontal: spacing.lg },
  examBarContent: { gap: spacing.sm, alignItems: 'center' },
  examChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: radius.pill,
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
  },
  examChipText: { fontSize: 13, fontWeight: '600', color: colors.textSecondary },
  saved: { color: colors.success, textAlign: 'center', marginBottom: spacing.sm, fontWeight: '600' },
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: spacing.sm, paddingVertical: 10 },
  info: { flex: 1, marginRight: spacing.md },
  name: { color: colors.text },
  meta: { color: colors.textSecondary, marginTop: 2 },
  input: {
    width: 64,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: 10,
    paddingVertical: 8,
    fontSize: 16,
    textAlign: 'center',
    color: colors.text,
    backgroundColor: colors.background,
  },
  inputInvalid: { borderColor: colors.danger },
  saveBtn: {
    backgroundColor: colors.primary,
    borderRadius: radius.md,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: spacing.lg,
  },
  saveText: { color: colors.white, fontWeight: '700', fontSize: 16 },
});
