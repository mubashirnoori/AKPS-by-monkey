import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Screen, ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { Card, SectionHeader } from '../../components/Card';
import { useApi } from '../../hooks/useApi';
import { colors, spacing, typography, radius, shadow } from '../../theme';
import type { RootStackParamList } from '../../navigation/types';
import type { ClassInfo } from '../../api/types';

export default function TeacherClassesScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const { data, loading, error, refetch } = useApi<{ myClasses: ClassInfo[] }>('/teacher/classes');

  if (loading) return <Loading />;
  if (error || !data) return <ErrorState message={error ?? 'No data'} onRetry={refetch} />;

  return (
    <Screen refreshing={loading} onRefresh={refetch}>
      <ScreenHeader title="My Classes" subtitle="Select a class to take action" />

      {data.myClasses.map((c) => (
        <Card key={c.id} style={styles.card}>
          <View style={styles.cardHeader}>
            <View style={styles.titleWrap}>
              <Text style={[typography.subheading, styles.title]}>
                {c.class_name} - {c.section}
              </Text>
              <Text style={[typography.caption, styles.sub]}>{c.subject}</Text>
              <Text style={[typography.caption, styles.sub]}>{c.studentCount} students</Text>
            </View>
          </View>
          <View style={styles.actions}>
            <Pressable
              style={({ pressed }) => [styles.actionBtn, styles.primary, pressed && { opacity: 0.8 }]}
              onPress={() => navigation.navigate('TakeAttendance', { classId: c.id, className: `${c.class_name}-${c.section}`, subject: c.subject ?? '' })}
            >
              <Text style={styles.primaryText}>Attendance</Text>
            </Pressable>
            <Pressable
              style={({ pressed }) => [styles.actionBtn, styles.secondary, pressed && { opacity: 0.8 }]}
              onPress={() => navigation.navigate('EnterMarks', { classId: c.id, className: `${c.class_name}-${c.section}`, subject: c.subject ?? '' })}
            >
              <Text style={styles.secondaryText}>Enter Marks</Text>
            </Pressable>
          </View>
        </Card>
      ))}
      {data.myClasses.length === 0 ? (
        <Text style={styles.empty}>No classes assigned yet.</Text>
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  card: { marginBottom: spacing.md },
  cardHeader: { marginBottom: spacing.md },
  titleWrap: { flex: 1 },
  title: { color: colors.text },
  sub: { color: colors.textSecondary, marginTop: 2 },
  actions: { flexDirection: 'row', gap: spacing.sm },
  actionBtn: { flex: 1, borderRadius: radius.md, paddingVertical: 12, alignItems: 'center' },
  primary: { backgroundColor: colors.primary },
  secondary: { backgroundColor: colors.primaryLight, borderWidth: 1, borderColor: colors.primary },
  primaryText: { color: colors.white, fontWeight: '700' },
  secondaryText: { color: colors.primaryDark, fontWeight: '700' },
  empty: { color: colors.textSecondary, textAlign: 'center', padding: spacing.xl },
});
