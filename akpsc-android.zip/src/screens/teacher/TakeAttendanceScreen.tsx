import React, { useMemo, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { ScreenHeader, Loading, ErrorState } from '../../components/Screen';
import { Card } from '../../components/Card';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useApi } from '../../hooks/useApi';
import { api } from '../../api/client';
import { colors, spacing, typography, radius } from '../../theme';
import { today } from '../../utils/format';
import type { RouteProp } from '@react-navigation/native';
import type { RootStackParamList } from '../../navigation/types';

type AttendanceRow = { student_id: number; name: string; roll_number: number; status: 'Present' | 'Absent' | 'Late' };

const STATUSES = ['Present', 'Absent', 'Late'] as const;

function shiftDate(dateStr: string, delta: number): string {
  const d = new Date(dateStr + 'T00:00:00');
  d.setDate(d.getDate() + delta);
  return d.toISOString().slice(0, 10);
}

export default function TakeAttendanceScreen({ route }: { route: RouteProp<RootStackParamList, 'TakeAttendance'> }) {
  const { classId, className, subject } = route.params;
  const [date, setDate] = useState(today());
  const [rows, setRows] = useState<AttendanceRow[] | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const path = `/teacher/class/${classId}/attendance?date=${date}`;
  const { data, loading, error, refetch } = useApi<{ date: string; rows: AttendanceRow[] }>(path);

  const initialized = useMemo(() => {
    if (data && rows === null) {
      setRows(data.rows);
      return true;
    }
    return false;
  }, [data, rows]);

  void initialized;

  const updateStatus = (studentId: number, status: AttendanceRow['status']) => {
    setRows((prev) => prev?.map((r) => (r.student_id === studentId ? { ...r, status } : r)) ?? null);
    setSaved(false);
  };

  const changeDate = (delta: number) => {
    setRows(null);
    setSaved(false);
    setDate((d) => shiftDate(d, delta));
  };

  const save = async () => {
    if (!rows) return;
    setSaving(true);
    try {
      await api.post('/teacher/attendance', { date, rows });
      setSaved(true);
    } finally {
      setSaving(false);
    }
  };

  const presentCount = rows?.filter((r) => r.status === 'Present').length ?? 0;
  const absentCount = rows?.filter((r) => r.status === 'Absent').length ?? 0;
  const lateCount = rows?.filter((r) => r.status === 'Late').length ?? 0;

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <ScreenHeader title={`Attendance - ${className}`} subtitle={`${subject} · ${date}`} />

      <View style={styles.dateBar}>
        <Pressable style={styles.dateBtn} onPress={() => changeDate(-1)}>
          <Text style={styles.dateBtnText}>◀</Text>
        </Pressable>
        <Pressable style={styles.todayBtn} onPress={() => { setRows(null); setSaved(false); setDate(today()); }}>
          <Text style={styles.todayText}>Today</Text>
        </Pressable>
        <Pressable style={styles.dateBtn} onPress={() => changeDate(1)}>
          <Text style={styles.dateBtnText}>▶</Text>
        </Pressable>
      </View>

      {loading && !rows ? <Loading /> : null}
      {error && !rows ? <ErrorState message={error} onRetry={refetch} /> : null}

      {rows ? (
        <ScrollView style={styles.scroll} contentContainerStyle={styles.content}>
          {saved ? <Text style={styles.saved}>Attendance saved.</Text> : null}
          <Card style={styles.summary}>
            <SummaryChip label="Present" count={presentCount} color={colors.success} />
            <SummaryChip label="Absent" count={absentCount} color={colors.danger} />
            <SummaryChip label="Late" count={lateCount} color={colors.warning} />
          </Card>

          {rows.map((r) => (
            <Card key={r.student_id} style={styles.studentCard}>
              <View style={styles.studentInfo}>
                <Text style={[typography.body, styles.studentName]} numberOfLines={1}>{r.name}</Text>
                <Text style={[typography.caption, styles.studentMeta]}>Roll #{r.roll_number}</Text>
              </View>
              <View style={styles.statusGroup}>
                {STATUSES.map((s) => (
                  <Pressable
                    key={s}
                    onPress={() => updateStatus(r.student_id, s)}
                    style={[styles.statusChip, r.status === s && { backgroundColor: statusColor(s) }]}
                  >
                    <Text style={[styles.statusChipText, r.status === s && { color: colors.white }]}>{s}</Text>
                  </Pressable>
                ))}
              </View>
            </Card>
          ))}

          <Pressable style={({ pressed }) => [styles.saveBtn, (pressed || saving) && { opacity: 0.8 }]} onPress={save} disabled={saving}>
            {saving ? <ActivityIndicator color={colors.white} /> : <Text style={styles.saveText}>Save Attendance</Text>}
          </Pressable>
        </ScrollView>
      ) : null}
    </SafeAreaView>
  );
}

const statusColor = (s: string) =>
  s === 'Present' ? colors.success : s === 'Absent' ? colors.danger : colors.warning;

function SummaryChip({ label, count, color }: { label: string; count: number; color: string }) {
  return (
    <View style={styles.summaryChip}>
      <Text style={[typography.label, { color }]}>{label}</Text>
      <Text style={[typography.subheading, { color }]}>{count}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  scroll: { flex: 1 },
  content: { padding: spacing.lg, paddingBottom: spacing.xxl },
  dateBar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.md, marginBottom: spacing.md },
  dateBtn: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    backgroundColor: colors.card,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  dateBtnText: { color: colors.primary, fontSize: 16 },
  todayBtn: {
    backgroundColor: colors.primaryLight,
    borderRadius: radius.pill,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  todayText: { color: colors.primaryDark, fontWeight: '700' },
  saved: { color: colors.success, textAlign: 'center', marginBottom: spacing.sm, fontWeight: '600' },
  summary: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: spacing.md },
  summaryChip: { alignItems: 'center' },
  studentCard: { marginBottom: spacing.sm, paddingVertical: 12 },
  studentInfo: { marginBottom: spacing.sm },
  studentName: { color: colors.text },
  studentMeta: { color: colors.textSecondary, marginTop: 2 },
  statusGroup: { flexDirection: 'row', gap: spacing.sm },
  statusChip: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: radius.md,
    backgroundColor: colors.background,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  statusChipText: { fontSize: 13, fontWeight: '600', color: colors.textSecondary },
  saveBtn: {
    backgroundColor: colors.primary,
    borderRadius: radius.md,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: spacing.lg,
  },
  saveText: { color: colors.white, fontWeight: '700', fontSize: 16 },
});
