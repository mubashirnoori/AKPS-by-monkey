import React, { useState } from 'react';
import { ActivityIndicator, KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useAuth } from '../auth/AuthContext';
import { colors, radius, spacing, typography } from '../theme';
import { ApiError } from '../api/client';

const DEMO_ACCOUNTS = [
  { label: 'Student', username: 'student', password: 'student123' },
  { label: 'Teacher', username: 'teacher', password: 'teacher123' },
  { label: 'Admin', username: 'admin', password: 'admin123' },
  { label: 'Parent', username: 'parent', password: 'parent123' },
];

export default function LoginScreen() {
  const { login } = useAuth();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (u?: string, p?: string) => {
    setLoading(true);
    setError(null);
    try {
      await login(u ?? username, p ?? password);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.flex}>
        <View style={styles.container}>
          <View style={styles.brand}>
            <View style={styles.logo}>
              <Text style={styles.logoText}>S</Text>
            </View>
            <Text style={[typography.title, styles.title]}>Institute App</Text>
            <Text style={[typography.caption, styles.tagline]}>School Management System</Text>
          </View>

          <View style={styles.form}>
            <Text style={[typography.label, styles.label]}>Username</Text>
            <TextInput
              style={styles.input}
              value={username}
              onChangeText={setUsername}
              autoCapitalize="none"
              autoCorrect={false}
              placeholder="Enter your username"
              placeholderTextColor={colors.textSecondary}
            />
            <Text style={[typography.label, styles.label]}>Password</Text>
            <TextInput
              style={styles.input}
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              placeholder="Enter your password"
              placeholderTextColor={colors.textSecondary}
              onSubmitEditing={() => submit()}
            />

            {error ? <Text style={styles.error}>{error}</Text> : null}

            <Pressable style={({ pressed }) => [styles.button, pressed && styles.buttonPressed]} onPress={() => submit()} disabled={loading}>
              {loading ? <ActivityIndicator color={colors.white} /> : <Text style={styles.buttonText}>Sign In</Text>}
            </Pressable>
          </View>

          <View style={styles.demo}>
            <Text style={[typography.label, styles.demoLabel]}>Try a demo account</Text>
            <View style={styles.demoRow}>
              {DEMO_ACCOUNTS.map((acc) => (
                <Pressable
                  key={acc.username}
                  style={({ pressed }) => [styles.demoChip, pressed && styles.buttonPressed]}
                  onPress={() => {
                    setUsername(acc.username);
                    setPassword(acc.password);
                    submit(acc.username, acc.password);
                  }}
                >
                  <Text style={styles.demoChipText}>{acc.label}</Text>
                </Pressable>
              ))}
            </View>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  flex: { flex: 1 },
  container: { flex: 1, justifyContent: 'center', padding: spacing.xl },
  brand: { alignItems: 'center', marginBottom: spacing.xxl },
  logo: {
    width: 72,
    height: 72,
    borderRadius: 20,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.md,
  },
  logoText: { color: colors.white, fontSize: 36, fontWeight: '800' },
  title: { color: colors.text },
  tagline: { color: colors.textSecondary, marginTop: 4 },
  form: { width: '100%' },
  label: { color: colors.text, marginBottom: 6, marginTop: 4 },
  input: {
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    color: colors.text,
    marginBottom: spacing.md,
  },
  error: { color: colors.danger, fontSize: 13, marginBottom: spacing.sm },
  button: {
    backgroundColor: colors.primary,
    borderRadius: radius.md,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
  },
  buttonPressed: { opacity: 0.8 },
  buttonText: { color: colors.white, fontSize: 16, fontWeight: '700' },
  demo: { marginTop: spacing.xxl, alignItems: 'center' },
  demoLabel: { color: colors.textSecondary, marginBottom: spacing.sm },
  demoRow: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 8 },
  demoChip: {
    backgroundColor: colors.primaryLight,
    borderRadius: radius.pill,
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  demoChipText: { color: colors.primaryDark, fontWeight: '600', fontSize: 13 },
});
