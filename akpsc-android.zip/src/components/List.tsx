import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, typography, radius, spacing } from '../theme';
import { resolveIcon } from '../utils/icons';

const AVATAR_COLORS = ['#4F46E5', '#0284C7', '#059669', '#D97706', '#DB2777', '#7C3AED'];

function hash(str: string): number {
  let h = 0;
  for (let i = 0; i < str.length; i += 1) {
    h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
  }
  return h;
}

export function Avatar({ name, size = 48 }: { name: string; size?: number }) {
  const initials = name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join('');
  const color = AVATAR_COLORS[Math.abs(hash(name)) % AVATAR_COLORS.length];
  return (
    <View style={[styles.avatar, { width: size, height: size, borderRadius: size / 2, backgroundColor: color }]}>
      <Text style={[styles.initials, { fontSize: size * 0.36 }]}>{initials}</Text>
    </View>
  );
}

export function InfoRow({ label, value, icon }: { label: string; value?: string | number | null; icon?: string }) {
  const ionicon = resolveIcon(icon);
  return (
    <View style={styles.row}>
      {icon ? (
        ionicon ? (
          <Ionicons name={ionicon} size={16} color={colors.textSecondary} style={styles.rowIconOutline} />
        ) : (
          <Text style={styles.rowIcon}>{icon}</Text>
        )
      ) : null}
      <Text style={[typography.caption, styles.rowLabel]}>{label}</Text>
      <Text style={[typography.body, styles.rowValue]} numberOfLines={2}>
        {value ?? '—'}
      </Text>
    </View>
  );
}

export function ListItem({
  icon,
  title,
  subtitle,
  right,
  onPress,
  last,
  accentColor,
}: {
  icon?: string;
  title: string;
  subtitle?: string;
  right?: React.ReactNode;
  onPress?: () => void;
  last?: boolean;
  accentColor?: string;
}) {
  const ionicon = resolveIcon(icon);
  const tint = accentColor ?? colors.primary;
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [stylesListItem.row, last && stylesListItem.last, pressed && stylesListItem.pressed]}>
      {icon ? (
        <View style={[stylesListItem.iconWrap, { backgroundColor: tint + '17' }]}>
          {ionicon ? (
            <Ionicons name={ionicon} size={18} color={tint} />
          ) : (
            <Text style={stylesListItem.icon}>{icon}</Text>
          )}
        </View>
      ) : null}
      <View style={stylesListItem.textWrap}>
        <Text style={[typography.body, stylesListItem.title]} numberOfLines={1}>
          {title}
        </Text>
        {subtitle ? (
          <Text style={[typography.caption, stylesListItem.sub]} numberOfLines={2}>
            {subtitle}
          </Text>
        ) : null}
      </View>
      {right ? (
        <View style={stylesListItem.right}>{right}</View>
      ) : onPress ? (
        <Ionicons name="chevron-forward" size={18} color={colors.textSecondary} />
      ) : null}
    </Pressable>
  );
}

export function Divider() {
  return <View style={styles.divider} />;
}

const styles = StyleSheet.create({
  avatar: { alignItems: 'center', justifyContent: 'center' },
  initials: { color: colors.white, fontWeight: '700' },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  rowIcon: { fontSize: 16, marginRight: 10, width: 22, textAlign: 'center' },
  rowIconOutline: { marginRight: 10, width: 22, textAlign: 'center' },
  rowLabel: { color: colors.textSecondary, flex: 1 },
  rowValue: { color: colors.text, flex: 2, textAlign: 'right', fontWeight: '500' },
  divider: { height: 1, backgroundColor: colors.border },
});

const stylesListItem = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  last: { borderBottomWidth: 0 },
  pressed: { backgroundColor: colors.background },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  icon: { fontSize: 18 },
  textWrap: { flex: 1 },
  title: { color: colors.text },
  sub: { color: colors.textSecondary, marginTop: 2 },
  right: { marginLeft: 8 },
});
