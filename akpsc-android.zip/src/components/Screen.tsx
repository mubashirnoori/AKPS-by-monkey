import React from 'react';
import { ActivityIndicator, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { colors, typography, spacing } from '../theme';

export function Screen({
  children,
  scroll = true,
  refreshing = false,
  onRefresh,
  contentStyle,
}: {
  children: React.ReactNode;
  scroll?: boolean;
  refreshing?: boolean;
  onRefresh?: () => void;
  contentStyle?: object;
}) {
  if (!scroll) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <View style={[styles.content, contentStyle]}>{children}</View>
      </SafeAreaView>
    );
  }
  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.content, contentStyle]}
        refreshControl={onRefresh ? <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} /> : undefined}
      >
        {children}
      </ScrollView>
    </SafeAreaView>
  );
}

export function ScreenHeader({ title, subtitle, right }: { title: string; subtitle?: string; right?: React.ReactNode }) {
  return (
    <View style={styles.header}>
      <View style={styles.headerTextWrap}>
        <Text style={[typography.title, styles.headerTitle]}>{title}</Text>
        {subtitle ? <Text style={[typography.caption, styles.headerSub]}>{subtitle}</Text> : null}
      </View>
      {right}
    </View>
  );
}

export function Loading({ label = 'Loading…' }: { label?: string }) {
  return (
    <View style={styles.center}>
      <ActivityIndicator size="large" color={colors.primary} />
      <Text style={[typography.caption, styles.loadingText]}>{label}</Text>
    </View>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <View style={styles.center}>
      <Text style={styles.errorIcon}>!</Text>
      <Text style={[typography.body, styles.errorText]}>{message}</Text>
      {onRetry ? (
        <Text style={styles.retry} onPress={onRetry}>
          Tap to retry
        </Text>
      ) : null}
    </View>
  );
}

export function EmptyState({ icon = '📭', title, subtitle }: { icon?: string; title: string; subtitle?: string }) {
  return (
    <View style={styles.center}>
      <Text style={styles.emptyIcon}>{icon}</Text>
      <Text style={[typography.subheading, styles.emptyTitle]}>{title}</Text>
      {subtitle ? <Text style={[typography.caption, styles.emptySub]}>{subtitle}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  scroll: { flex: 1 },
  content: { padding: spacing.lg, paddingBottom: spacing.xxl },
  header: { marginBottom: spacing.lg, flexDirection: 'row', alignItems: 'center' },
  headerTextWrap: { flex: 1, paddingRight: spacing.sm },
  headerTitle: { color: colors.text },
  headerSub: { color: colors.textSecondary, marginTop: 2 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xl, minHeight: 200 },
  loadingText: { color: colors.textSecondary, marginTop: spacing.sm },
  errorIcon: {
    fontSize: 34,
    width: 56,
    height: 56,
    textAlign: 'center',
    lineHeight: 56,
    borderRadius: 28,
    backgroundColor: colors.dangerLight,
    color: colors.danger,
    fontWeight: '700',
    marginBottom: spacing.md,
  },
  errorText: { color: colors.textSecondary, textAlign: 'center' },
  retry: { color: colors.primary, marginTop: spacing.sm, fontWeight: '600' },
  emptyIcon: { fontSize: 40, marginBottom: spacing.sm },
  emptyTitle: { color: colors.text },
  emptySub: { color: colors.textSecondary, textAlign: 'center', marginTop: 4 },
});
