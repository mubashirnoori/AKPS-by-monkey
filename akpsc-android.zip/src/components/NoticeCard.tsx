import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Card } from './Card';
import { colors, typography } from '../theme';
import { formatDate } from '../utils/format';
import type { Notice } from '../api/types';

export function NoticeCard({ notice }: { notice: Notice }) {
  return (
    <Card style={styles.card}>
      <View style={styles.row}>
        <View style={styles.dot} />
        <Text style={[typography.subheading, styles.title]}>{notice.title}</Text>
      </View>
      <Text style={[typography.body, styles.body]} numberOfLines={3}>
        {notice.body}
      </Text>
      <Text style={[typography.caption, styles.date]}>{formatDate(notice.date)}</Text>
    </Card>
  );
}

const styles = StyleSheet.create({
  card: { marginBottom: 12 },
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: 6 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.primary, marginRight: 8 },
  title: { color: colors.text, flex: 1 },
  body: { color: colors.textSecondary },
  date: { color: colors.textSecondary, marginTop: 8, fontSize: 12 },
});
