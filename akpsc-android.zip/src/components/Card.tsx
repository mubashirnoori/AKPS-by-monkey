import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, typography, radius, shadow } from '../theme';
import { resolveIcon } from '../utils/icons';

export function Card({
  children,
  style,
  accentColor,
}: {
  children: React.ReactNode;
  style?: object;
  accentColor?: string;
}) {
  return (
    <View style={[styles.card, accentColor && { borderLeftWidth: 3, borderLeftColor: accentColor }, style]}>
      {children}
    </View>
  );
}

export function StatCard({
  label,
  value,
  icon,
  color = colors.primary,
}: {
  label: string;
  value: string | number;
  icon: string;
  color?: string;
}) {
  return (
    <View style={styles.stat}>
      <View style={[styles.iconWrap, { backgroundColor: color + '17' }]}>
        {resolveIcon(icon) ? (
          <Ionicons name={resolveIcon(icon)!} size={20} color={color} />
        ) : (
          <Text style={[styles.iconText, { color }]}>{icon}</Text>
        )}
      </View>
      <Text style={[styles.statValue, { color }]} numberOfLines={1} adjustsFontSizeToFit>
        {value}
      </Text>
      <Text style={styles.statLabel} numberOfLines={2}>
        {label}
      </Text>
    </View>
  );
}

export function SectionHeader({ title, right }: { title: string; right?: React.ReactNode }) {
  return (
    <View style={styles.sectionRow}>
      <Text style={[styles.sectionTitle, typography.heading]}>{title}</Text>
      {right}
    </View>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { bg: string; fg: string; label: string }> = {
    Paid: { bg: colors.successLight, fg: colors.success, label: 'Paid' },
    Partial: { bg: colors.warningLight, fg: colors.warning, label: 'Partial' },
    Unpaid: { bg: colors.dangerLight, fg: colors.danger, label: 'Unpaid' },
    Present: { bg: colors.successLight, fg: colors.success, label: 'Present' },
    Absent: { bg: colors.dangerLight, fg: colors.danger, label: 'Absent' },
    Late: { bg: colors.warningLight, fg: colors.warning, label: 'Late' },
    Active: { bg: colors.successLight, fg: colors.success, label: 'Active' },
    Inactive: { bg: colors.dangerLight, fg: colors.danger, label: 'Inactive' },
  };
  const s = map[status] || { bg: colors.infoLight, fg: colors.info, label: status };
  return (
    <View style={[styles.badge, { backgroundColor: s.bg }]}>
      <Text style={[styles.badgeText, { color: s.fg }]}>{s.label}</Text>
    </View>
  );
}

export function ProgressBar({ value, color = colors.primary }: { value: number; color?: string }) {
  return (
    <View style={styles.progressTrack}>
      <View style={[styles.progressFill, { width: `${Math.min(100, Math.max(0, value))}%`, backgroundColor: color }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.border,
    ...shadow.card,
  },
  stat: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: 14,
    borderWidth: 1,
    borderColor: colors.border,
    ...shadow.card,
  },
  iconWrap: {
    width: 40,
    height: 40,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  iconText: { fontSize: 18, fontWeight: '700' },
  statValue: { fontSize: 21, fontWeight: '800', marginBottom: 3, letterSpacing: -0.3 },
  statLabel: { color: colors.textSecondary, ...typography.label },
  sectionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
    marginTop: 4,
  },
  sectionTitle: { color: colors.text },
  badge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: radius.pill },
  badgeText: { fontSize: 12, fontWeight: '700' },
  progressTrack: {
    height: 8,
    borderRadius: radius.pill,
    backgroundColor: colors.border,
    overflow: 'hidden',
  },
  progressFill: { height: '100%', borderRadius: radius.pill },
});
