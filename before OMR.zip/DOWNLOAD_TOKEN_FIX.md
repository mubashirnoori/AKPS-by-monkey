# Signed download-token fix (mobile export downloads)

## Problem

Exports (`results.xlsx`, invoice CSVs, backups, etc.) worked fine from a
desktop browser but came out "corrupted" on the mobile app, which is a
WebView wrapper of this site. Root cause: WebView-wrapped apps typically hand
downloads off to the OS's native download manager, which does **not**
forward the WebView's session cookie. The server then saw an unauthenticated
request, redirected to `/login`, and the wrapper saved that login page's
HTML with a `.xlsx`/`.csv` extension.

## Fix

Export links now carry a short-lived (10 minute), HMAC-signed `dl_token`
query parameter, generated server-side at page-render time (while the user
is genuinely logged in). The export action accepts this token as an
alternative to the session cookie, so the download works regardless of
whether the client forwards cookies. Every real permission check
(`RBAC::requirePermission`) is unchanged — the token only proves identity,
not authorization; the user's actual current role/permissions are always
re-checked against the database.

## New file

- `app/core/DownloadToken.php` — generate/verify signed tokens. Secret key:
  prefers `DOWNLOAD_TOKEN_KEY` env var; otherwise auto-generates once and
  persists to `config/download_token.key` (not web-accessible; **add this
  file to your deploy-exclude / `.gitignore`** — it's a generated secret,
  not something to version-control).

## Changed files

- `public/index.php` — requires the new `DownloadToken.php`.
- `app/core/Auth.php` — added `requireLoginOrToken()` (session OR valid
  token); `currentUser()` also checks a request-scoped token-user override.
  Deliberately **not** written to `$_SESSION` — a token grants one download,
  not a persistent login.
- `app/core/helpers.php` — added `download_token()` for views.
- Controllers — swapped `Auth::requireLogin()` → `Auth::requireLoginOrToken()`
  on export/download actions only (all other actions unchanged):
  - `AcademicController`: `bulkReportCardsDownloadAction`,
    `bulkResultsXlsDownloadAction`, `bulkResultsCsvDownloadAction`
  - `ActivityLogController`: `exportCsvAction`
  - `FeesController`: `invoicesExportCsvAction`, `bulkInvoicesDownloadAction`,
    `bulkInvoicesXlsDownloadAction`, `bulkInvoicesCsvDownloadAction`
  - `StudentsController`: `exportCsvAction`
  - `ReportsController`: `studentAttendanceAction`, `examMarksAction`,
    `feeCollectionsAction`, `invoicesAction`, `staffAttendanceAction`,
    `customGeneratorAction`
  - `SettingsController`: `backupAction`
- Views — added `dl_token` to the relevant export links/forms:
  - `app/views/academic/bulk_exports.php`
  - `app/views/fees/bulk_exports.php`, `app/views/fees/invoices.php`
  - `app/views/activity_log/index.php`
  - `app/views/students/index.php`
  - `app/views/reports/exam_marks.php`, `fee_collections.php`,
    `invoices.php`, `staff_attendance.php`, `student_attendance.php`,
    `custom_generator.php`
  - `app/views/settings/backup.php`

## Deploy checklist

1. Run `php -l` on the changed files (or just load the pages once) before
   going live — this was written and reviewed without a local PHP install.
2. Add `config/download_token.key` to your `.gitignore`/deploy excludes.
3. Consider a shorter TTL for the SQL backup link specifically — pass a
   second argument to `DownloadToken::generate((int)$user['id'], 120)` in
   `download_token()` if you want a stricter window for that one case.
4. Test end-to-end from the actual mobile wrapper app, not just a desktop
   browser with cookies cleared — the token flow is exactly what closes the
   gap the wrapper's native downloader was hitting.
