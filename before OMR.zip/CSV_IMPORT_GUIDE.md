# CSV Import Guide - Students Module

## Overview
The CSV import feature allows you to bulk import students with automatic class assignment and roll number tracking.

---

## ✅ CSV Format Requirements

### Required Columns (Must Have)
- **admission_no** (aliases: admission_number, admission)
  - Unique identifier for each student
  - Example: STU001, S001, etc.

- **full_name** (aliases: student_name, name)
  - Student's full name
  - Will be split into first and last name
  - Example: "Ahmed Ali"

- **roll_number** (aliases: roll_no, roll)
  - Roll number in class
  - Optional (can be left blank)
  - Must be unique within each class
  - Example: 1, 2, 3, etc.

### Class Assignment (At Least One Method Required)

#### Method 1: Using Class + Section Columns
- **class** (alias: class_name)
  - Class name from database
  - Example: "Class 10", "Class 9", "10A", etc.

- **section** (alias: section_name)
  - Section name from database
  - Example: "A", "B", "C", etc.

#### Method 2: Using class_section_id Directly
- **class_section_id** (alias: classsectionid)
  - Exact ID from database class_sections table
  - Example: 1, 2, 3, etc.
  - Use if you know exact IDs

#### Method 3: Using Default Class from Form
- Select "Default Class / Section" from dropdown in UI
- Used when CSV has no class information
- Applied to all students in CSV

### Optional Columns
- **gender** - M, F, Other (default: M)
- **dob** - Date of birth (format: YYYY-MM-DD)
- **phone** - Phone number
- **address** - Student address

---

## 📋 CSV Format Examples

### Example 1: With Class + Section Names
```csv
admission_no,full_name,roll_number,class,section,gender,dob,phone
STU001,Ahmed Ali,1,Class 10,A,M,2010-05-15,03001234567
STU002,Fatima Khan,2,Class 10,A,F,2010-06-20,03109876543
STU003,Hassan Ahmad,3,Class 10,B,M,2010-07-10,03201111111
```

### Example 2: With class_section_id
```csv
admission_no,full_name,roll_number,class_section_id,gender
STU001,Ahmed Ali,1,5,M
STU002,Fatima Khan,2,5,F
STU003,Hassan Ahmad,3,6,M
```

### Example 3: Minimal (With Default Class)
```csv
admission_no,full_name,roll_number
STU001,Ahmed Ali,1
STU002,Fatima Khan,2
STU003,Hassan Ahmad,3
```
Then select "Default Class / Section" from the form.

### Example 4: Alternative Column Names
```csv
admission,student_name,roll_no,class_name,section_name
STU001,Ahmed Ali,1,Class 10,A
STU002,Fatima Khan,2,Class 10,A
```

---

## 🔧 How Import Works

### Process Flow
```
1. Upload CSV file
2. Read and parse headers (case-insensitive)
3. For each row:
   a. Extract required fields (admission_no, full_name, roll_number)
   b. Validate required fields (skip if missing)
   c. Determine class assignment:
      - Check class_section_id in CSV
      - Check class + section in CSV
      - Use default if provided
   d. Create/update student:
      - If admission_no exists: UPDATE student
      - If new: CREATE student
   e. Assign class with roll_number if class found
4. Report: X imported, Y skipped
```

### Update vs Create
- **CREATE**: If admission_no is new → Creates fresh student record
- **UPDATE**: If admission_no exists → Updates existing student data
  - Keeps old data unless overwritten
  - Useful for updating class/roll number

---

## ⚠️ Common Issues & Solutions

### Issue 1: "Roll Number Not Imported"
**Cause**: Roll number column missing or misnamed

**Solution**:
- Use exact column name: `roll_number`
- Or use alias: `roll_no` or `roll`
- Column names are case-insensitive
- Leave blank if unknown

### Issue 2: "Class Section Not Assigned"
**Cause**: Class information missing or incorrect

**Solution Options**:
1. Add `class` + `section` columns with exact names from database
2. Add `class_section_id` column with database ID
3. Select "Default Class / Section" from dropdown
4. Check class names match exactly (e.g., "Class 10" not "10")

**Example**:
```
❌ Wrong:
class_name,section_name
10,A

✅ Correct:
class,section
Class 10,A
```

### Issue 3: "Students Not Importing"
**Cause**: Missing required columns or invalid data

**Solution**:
- Ensure CSV has `admission_no` column
- Ensure CSV has `full_name` column
- No blank admission numbers
- Check for extra spaces or special characters
- Validate data types (roll_number should be numeric)

### Issue 4: "Admission Number Already Exists"
**Cause**: Duplicate admission numbers in CSV

**Solution**:
- Each admission_no must be unique
- System will UPDATE existing if duplicate found
- Remove duplicates or use different numbers

### Issue 5: "Phone/Address Not Importing"
**Cause**: Column names don't match

**Solution**:
- Use exact column names: `phone`, `address`
- Optional columns are case-insensitive
- If column missing, field left blank
- These columns are NOT required

---

## 🎯 Best Practices

### Column Order
Not required but recommended:
```csv
admission_no,full_name,roll_number,class,section,gender,dob,phone,address
```

### Data Validation
Before importing:
1. ✅ Check admission_no is unique
2. ✅ Check full_name is complete
3. ✅ Check class names match database
4. ✅ Check roll numbers are numeric
5. ✅ Check date format is YYYY-MM-DD
6. ✅ Check phone format is valid

### Class Name Verification
Find exact class names in database:
1. Go to Admin → Classes & Sections
2. Note exact class and section names
3. Use same names in CSV (case-sensitive for matching)

### Testing
1. Start with small CSV (5-10 students)
2. Verify import success
3. Check students appear in list
4. Verify class assignments correct
5. Check roll numbers present
6. Then import full dataset

---

## 📝 Preparing CSV in Excel

### Step 1: Create Headers
Row 1 with column names:
```
admission_no | full_name | roll_number | class | section | gender | dob | phone
```

### Step 2: Enter Data
```
STU001 | Ahmed Ali | 1 | Class 10 | A | M | 2010-05-15 | 03001234567
STU002 | Fatima Khan | 2 | Class 10 | A | F | 2010-06-20 | 03109876543
```

### Step 3: Save as CSV
- File → Save As
- Format: CSV (Comma delimited) (*.csv)
- Click Save
- Choose "Yes" if prompted about format

### Step 4: Import
- Go to Students → Import
- Upload the CSV file
- Select default class (if needed)
- Click Import

---

## 🔍 Verification After Import

### In Student List
- [ ] Students appear in list
- [ ] Correct admission numbers
- [ ] Correct names
- [ ] Status is "Active"

### In Student Details
- Click student to view
- [ ] Roll number populated
- [ ] Class assignment correct
- [ ] Gender, DOB, phone correct
- [ ] Address populated

### In Class Management
- Go to Classes & Sections
- Click a class to see students
- [ ] Correct students listed
- [ ] Roll numbers visible
- [ ] Names match

---

## 📊 Sample CSV File

A sample CSV is provided: `samples/sample_students_import.csv`

Contains:
- 10 sample students
- Multiple classes and sections
- Complete information
- Ready to use as template

---

## 🚨 Error Handling

### Import Errors Are Logged
- Check: "Imported: X | Skipped: Y"
- X = Successfully imported/updated
- Y = Skipped (missing required fields)

### Rows Are Skipped If:
- admission_no is missing or blank
- full_name is missing or blank
- Database error (rare)

### Data That's Never Deleted:
- Existing student records kept
- Only updated if admission_no matches
- Safe to re-import same file

---

## 💡 Tips & Tricks

### Batch Updates
- Re-import with updated roll numbers to update existing students
- System automatically detects duplicates and updates

### Class Changes
- To change student class: Re-import with new class info
- Old class assignment will be replaced

### Flexible Column Names
All of these work:
- admission_no, admission_number, admission
- full_name, student_name, name
- roll_number, roll_no, roll
- class, class_name
- section, section_name
- gender, sex
- dob, date_of_birth, dateofbirth
- phone, phone_number, phonenumber

---

## 🔐 Security

- CSV parsing is safe (no SQL injection)
- File is validated (CSV only)
- CSRF protection enabled
- Requires permission: students.manage
- All data sanitized before database

---

## 📞 Troubleshooting

**Q: Roll numbers are blank after import**
A: Check `roll_number` column exists and has values

**Q: Class not assigned**
A: Ensure class + section names match database exactly

**Q: Students updated instead of created**
A: admission_no already exists - use UPDATE feature intentionally

**Q: Some students skipped**
A: Check for blank admission_no or full_name in those rows

**Q: File too large**
A: Maximum 10 MB, import in batches if needed

---

**Version**: 1.0
**Last Updated**: March 28, 2024
