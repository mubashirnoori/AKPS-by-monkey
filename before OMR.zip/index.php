<?php
declare(strict_types=1);

header('Location: https://school.akhoonzadaholdings.com/public/', true, 302);
exit;
