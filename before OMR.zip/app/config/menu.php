<?php
/**
 * Central navigation config for the app shell (sidebar rail + flyout submenus).
 *
 * Each top-level entry:
 *   - key         : unique slug, used for CSS state + JS targeting
 *   - label       : text shown under the icon in the rail
 *   - icon        : bootstrap-icons class
 *   - permission  : string|array<string>|null. Array = OR (any one grants access). Null = always visible.
 *   - route       : route to navigate to directly when this item has NO children.
 *   - prefix      : route prefix used to decide "is this section active" (defaults to key + '/').
 *   - children    : list of ['label','route','icon'] shown in the flyout panel when clicked.
 *                   A child may add 'href' => 'index.php?route=...&extra=...' to override the
 *                   plain route_url() link when it needs extra query params (route_url() encodes
 *                   the whole route string, so '&' can't go through it).
 *                   A child may also add 'permission' => string|array<string>|null to require a
 *                   permission narrower than its parent section's (array = OR, same as above; a
 *                   missing/null key means "visible to anyone who can see the parent section",
 *                   same as before this key existed). Used e.g. so a Teacher who holds
 *                   'academic.manage' (for Marks Entry) doesn't also see "Bulk Exports", which
 *                   needs the separate 'academic.bulk_export' permission — see layout.php.
 *
 * A top-level item with children never navigates on click — it opens the flyout instead.
 * The whole point: no more "tile grid" index pages as the way to reach a module's sub-pages.
 */

// Portal dashboards (Student/Parent/Teacher/Accountant) used to show their detail
// tables (subjects, classes, results, salary, leave history, etc.) directly on the
// dashboard page, then later as a flyout under "My Portal". Both are gone now: the
// dashboard/portal rail item is a plain, direct link (no flyout of its own), renamed
// per role, and each of those detail pages instead gets its own rail icon, sitting
// right below "Academic". Admin is unaffected — it already has full top-level
// sections for everything and keeps the generic "Dashboard" label.
$portalDashboardLabel = null; // null => layout.php falls back to "Dashboard" (admin) / "My Portal" (unhandled role)
$portalOwnMenuItems = [];
if (class_exists('RBAC') && !RBAC::isAdmin()) {
    switch (RBAC::roleName()) {
        case 'teacher':
        case 'principal':
            $portalDashboardLabel = 'Teachers Dashboard';
            $portalOwnMenuItems = [
                ['key' => 'portalMySubjects', 'label' => 'My Subjects & Classes', 'icon' => 'bi-journal-bookmark', 'permission' => null, 'route' => 'portal/mySubjects', 'prefix' => 'portal/mySubjects', 'children' => []],
                ['key' => 'portalMyTimetable', 'label' => 'My Timetable', 'icon' => 'bi-calendar-week', 'permission' => null, 'route' => 'portal/myTimetable', 'prefix' => 'portal/myTimetable', 'children' => []],
                ['key' => 'portalFeeClasses', 'label' => 'Fee Collection Classes', 'icon' => 'bi-cash-coin', 'permission' => null, 'route' => 'portal/myFeeClasses', 'prefix' => 'portal/myFeeClasses', 'children' => []],
                ['key' => 'portalFeeLedger', 'label' => 'My Fee Ledger', 'icon' => 'bi-arrow-left-right', 'permission' => null, 'route' => 'portal/myFeeLedger', 'prefix' => 'portal/myFeeLedger', 'children' => []],
                ['key' => 'portalMySalary', 'label' => 'My Salary', 'icon' => 'bi-cash-stack', 'permission' => null, 'route' => 'portal/mySalary', 'prefix' => 'portal/mySalary', 'children' => []],
                ['key' => 'portalMyPerformance', 'label' => 'My Performance', 'icon' => 'bi-star', 'permission' => null, 'route' => 'portal/myPerformance', 'prefix' => 'portal/myPerformance', 'children' => []],
                ['key' => 'portalMyLeaves', 'label' => 'My Leaves', 'icon' => 'bi-calendar-x', 'permission' => null, 'route' => 'portal/myLeaves', 'prefix' => 'portal/myLeaves', 'children' => []],
            ];
            break;
        case 'student':
            $portalDashboardLabel = 'Student Dashboard';
            $portalOwnMenuItems = [
                ['key' => 'portalMyResults', 'label' => 'My Results', 'icon' => 'bi-clipboard-data', 'permission' => null, 'route' => 'portal/myResults', 'prefix' => 'portal/myResults', 'children' => []],
                ['key' => 'portalMyReportCard', 'label' => 'My Report Card', 'icon' => 'bi-file-earmark-text', 'permission' => null, 'route' => 'portal/myReportCard', 'prefix' => 'portal/myReportCard', 'children' => []],
                ['key' => 'portalMyTimetable', 'label' => 'My Timetable', 'icon' => 'bi-calendar-week', 'permission' => null, 'route' => 'portal/myTimetable', 'prefix' => 'portal/myTimetable', 'children' => []],
                ['key' => 'portalMyDateSheet', 'label' => 'My Date Sheet', 'icon' => 'bi-calendar3', 'permission' => 'academic.date_sheet_view', 'route' => 'portal/myDateSheet', 'prefix' => 'portal/myDateSheet', 'children' => []],
                ['key' => 'portalMyFees', 'label' => 'My Fees', 'icon' => 'bi-receipt', 'permission' => null, 'route' => 'portal/myFees', 'prefix' => 'portal/myFees', 'children' => []],
                ['key' => 'portalMyCourses', 'label' => 'My Courses', 'icon' => 'bi-play-btn', 'permission' => null, 'route' => 'portal/myCourses', 'prefix' => 'portal/myCourses', 'children' => []],
                ['key' => 'portalMyLeaves', 'label' => 'My Leaves', 'icon' => 'bi-calendar-x', 'permission' => null, 'route' => 'portal/myLeaves', 'prefix' => 'portal/myLeaves', 'children' => []],
            ];
            break;
        case 'parent':
            $portalDashboardLabel = 'Parent Dashboard';
            $portalOwnMenuItems = [
                ['key' => 'portalChildResults', 'label' => "Child's Results", 'icon' => 'bi-clipboard-data', 'permission' => null, 'route' => 'portal/myResults', 'prefix' => 'portal/myResults', 'children' => []],
                ['key' => 'portalChildReportCard', 'label' => "Child's Report Card", 'icon' => 'bi-file-earmark-text', 'permission' => null, 'route' => 'portal/myReportCard', 'prefix' => 'portal/myReportCard', 'children' => []],
                ['key' => 'portalChildDateSheet', 'label' => "Child's Date Sheet", 'icon' => 'bi-calendar3', 'permission' => 'academic.date_sheet_view', 'route' => 'portal/myDateSheet', 'prefix' => 'portal/myDateSheet', 'children' => []],
                ['key' => 'portalChildFees', 'label' => "Child's Fees", 'icon' => 'bi-receipt', 'permission' => null, 'route' => 'portal/myFees', 'prefix' => 'portal/myFees', 'children' => []],
                ['key' => 'portalChildCourses', 'label' => "Child's Courses", 'icon' => 'bi-play-btn', 'permission' => null, 'route' => 'portal/myCourses', 'prefix' => 'portal/myCourses', 'children' => []],
            ];
            break;
        case 'accountant':
            $portalDashboardLabel = 'Accountant Dashboard';
            $portalOwnMenuItems = [
                ['key' => 'portalCashCollection', 'label' => 'Cash Collection', 'icon' => 'bi-wallet2', 'permission' => null, 'route' => 'fees/collect', 'prefix' => 'fees/collect', 'children' => []],
                ['key' => 'portalInvoices', 'label' => 'Invoices', 'icon' => 'bi-receipt-cutoff', 'permission' => null, 'route' => 'fees/invoices', 'prefix' => 'fees/invoices', 'children' => []],
                ['key' => 'portalPendingDues', 'label' => 'Pending Dues', 'icon' => 'bi-exclamation-circle', 'permission' => null, 'route' => 'fees/pendingDues', 'prefix' => 'fees/pendingDues', 'children' => []],
            ];
            break;
    }
}

$menu = [
    [
        'key' => 'dashboard',
        'label' => $portalDashboardLabel, // null => "Dashboard" (admin) / "My Portal" (unhandled role), resolved in layout.php
        'icon' => 'bi-grid-1x2-fill',
        'permission' => null,
        'route' => 'dashboard/index',
        'prefix' => null, // resolved at render time (dashboard/ or portal/)
        'children' => [], // plain direct link now — no flyout of its own
    ],
    [
        'key' => 'students',
        'label' => 'Students',
        'icon' => 'bi-mortarboard-fill',
        'permission' => ['students.view', 'students.manage', 'students.leave_approve'],
        'route' => 'students/index',
        'prefix' => 'students/',
        'children' => [
            ['label' => 'All Students', 'route' => 'students/index', 'icon' => 'bi-list-ul', 'permission' => ['students.view', 'students.manage']],
            ['label' => 'Add Student', 'route' => 'students/create', 'icon' => 'bi-person-plus-fill', 'permission' => ['students.manage']],
            ['label' => 'Attendance', 'route' => 'students/attendance', 'icon' => 'bi-calendar2-check', 'permission' => ['students.view', 'students.manage']],
            ['label' => 'Promotions', 'route' => 'students/promotions', 'icon' => 'bi-arrow-up-circle', 'permission' => ['students.manage']],
            // Visible to Admin/Principal (full access) AND to a Teacher who's a Class Teacher
            // (scoped to their own class, 2-day-or-fewer leaves only — enforced in
            // StudentsController::approveLeaveAction(), not just here).
            ['label' => 'Leave Requests', 'route' => 'students/leaves', 'icon' => 'bi-calendar2-x', 'permission' => ['students.view', 'students.manage', 'students.leave_approve']],
            ['label' => 'Inquiries', 'route' => 'students/inquiries', 'icon' => 'bi-question-circle', 'permission' => ['students.view', 'students.manage']],
            ['label' => 'Complaints', 'route' => 'students/complaints', 'icon' => 'bi-flag', 'permission' => ['students.view', 'students.manage']],
        ],
    ],
    [
        'key' => 'academic',
        'label' => 'Academic',
        'icon' => 'bi-journal-bookmark-fill',
        'permission' => ['academic.view', 'academic.manage', 'academic.marks_entry', 'academic.report_cards', 'academic.bulk_export'],
        'route' => 'academic/index',
        'prefix' => 'academic/',
        'children' => array_values(array_filter([
            ['label' => 'Academic Overview', 'route' => 'academic/index', 'icon' => 'bi-house-gear', 'permission' => ['academic.view', 'academic.manage']],
            ['label' => 'Admission Form', 'route' => 'academic/admissionForm', 'icon' => 'bi-file-earmark-person', 'permission' => ['academic.view', 'academic.manage'], 'target' => '_blank'],
            ['label' => 'Marks Entry', 'route' => 'academic/marksEntry', 'icon' => 'bi-pencil-square', 'permission' => ['academic.manage', 'academic.marks_entry']],
            // Exams, Timetable, Subjects, Classes & Sections, and ID Cards are hard
            // admin-only in the controller (RBAC::requireAdmin(), not a permission
            // check) — no role_permissions grant can open them for anyone else, so
            // there's no point showing the link to non-admins; it would just 403.
            (class_exists('RBAC') && RBAC::isAdmin()) ? ['label' => 'Exams', 'route' => 'academic/exams', 'icon' => 'bi-journal-check'] : null,
            ['label' => 'Date Sheet', 'route' => 'academic/dateSheet', 'icon' => 'bi-calendar3', 'permission' => ['academic.view', 'academic.manage']],
            (class_exists('RBAC') && RBAC::isAdmin()) ? ['label' => 'Timetable', 'route' => 'academic/timetable', 'icon' => 'bi-clock-history'] : null,
            (class_exists('RBAC') && RBAC::isAdmin()) ? ['label' => 'Subjects', 'route' => 'academic/subjects', 'icon' => 'bi-journal-text'] : null,
            (class_exists('RBAC') && RBAC::isAdmin()) ? ['label' => 'Classes & Sections', 'route' => 'academic/classes', 'icon' => 'bi-diagram-3'] : null,
            ['label' => 'Report Cards', 'route' => 'academic/certificate', 'icon' => 'bi-file-earmark-text', 'permission' => ['academic.manage', 'academic.report_cards']],
            ['label' => 'Position Holders', 'route' => 'academic/positionHolders', 'icon' => 'bi-trophy', 'permission' => ['academic.view', 'academic.manage', 'academic.school_topper']],
            ['label' => 'Bulk Exports', 'route' => 'academic/bulkExports', 'icon' => 'bi-file-earmark-zip', 'permission' => ['academic.bulk_export']],
            (class_exists('RBAC') && RBAC::isAdmin()) ? ['label' => 'ID Cards', 'route' => 'academic/idCard', 'icon' => 'bi-person-vcard'] : null,
            ['label' => 'Online Courses', 'route' => 'academic/courses', 'icon' => 'bi-play-btn', 'permission' => ['academic.manage']],
        ])),
    ],
];

// Portal shortcut pages (My Subjects & Classes, My Salary, My Results, etc.) sit
// right below Academic in the rail, each as its own icon — see the switch above.
foreach ($portalOwnMenuItems as $portalItem) {
    $menu[] = $portalItem;
}

// "Overdue Fee Reminders" is Admin-only — not shown to Accountant/other staff
// who may also hold fees.manage, per explicit instruction. Built as a
// conditional append (same pattern as $portalOwnMenuItems above) rather than
// a 'permission' key, since permission keys are role_permissions-driven and
// there's no permission scoped to "Admin the role" specifically.
$feesChildren = [
    ['label' => 'Cash Collection', 'route' => 'fees/collect', 'icon' => 'bi-wallet2', 'permission' => ['fees.manage']],
    ['label' => 'Invoices', 'route' => 'fees/invoices', 'icon' => 'bi-receipt-cutoff', 'permission' => ['fees.manage']],
    ['label' => 'Generate Invoices', 'route' => 'fees/generateInvoices', 'icon' => 'bi-file-earmark-plus', 'permission' => ['fees.manage']],
    ['label' => 'Pending Dues', 'route' => 'fees/pendingDues', 'icon' => 'bi-exclamation-circle', 'permission' => ['fees.view', 'fees.manage']],
    ['label' => 'Bulk Exports', 'route' => 'fees/bulkExports', 'icon' => 'bi-file-earmark-zip', 'permission' => ['fees.manage']],
    ['label' => 'Fee Categories', 'route' => 'fees/categories', 'icon' => 'bi-tags', 'permission' => ['fees.manage']],
    ['label' => 'Fee Assignments', 'route' => 'fees/assignments', 'icon' => 'bi-diagram-2', 'permission' => ['fees.manage']],
    ['label' => 'Fee Settings', 'route' => 'fees/feeSettings', 'icon' => 'bi-sliders', 'permission' => ['fees.manage']],
    ['label' => 'Teacher Collections', 'route' => 'fees/teacherLedger', 'icon' => 'bi-arrow-left-right', 'permission' => 'fees.handover_confirm'],
];
if (class_exists('RBAC') && RBAC::isAdmin()) {
    $feesChildren[] = ['label' => 'Overdue Fee Reminders', 'route' => 'fees/overdueReminders', 'icon' => 'bi-bell'];
}

$menu[] = [
    'key' => 'fees',
    'label' => 'Fees',
    'icon' => 'bi-cash-coin',
    'permission' => ['fees.view', 'fees.manage'],
    'route' => 'fees/invoices',
    'prefix' => 'fees/',
    'children' => $feesChildren,
];

$menu[] = [
    'key' => 'staff',
    'label' => 'Staff & HR',
    'icon' => 'bi-people-fill',
    'permission' => ['staff.view', 'staff.manage'],
    'route' => 'staff/staffProfiles',
    'prefix' => 'staff/',
    'children' => [
        ['label' => 'Staff Profiles', 'route' => 'staff/staffProfiles', 'icon' => 'bi-person-badge', 'permission' => ['staff.manage']],
        ['label' => 'Payroll', 'route' => 'staff/payroll', 'icon' => 'bi-cash-stack', 'permission' => ['staff.manage']],
        ['label' => 'Staff Attendance', 'route' => 'staff/staffAttendance', 'icon' => 'bi-calendar2-check', 'permission' => ['staff.manage']],
        ['label' => 'Leave Requests', 'route' => 'staff/leaves', 'icon' => 'bi-calendar2-x', 'permission' => ['staff.manage']],
        ['label' => 'Performance', 'route' => 'staff/performance', 'icon' => 'bi-star', 'permission' => ['staff.manage']],
        ['label' => 'Fee Collection Assignments', 'route' => 'staff/feeCollectors', 'icon' => 'bi-person-check', 'permission' => ['staff.manage']],
    ],
];

$menu[] = [
    'key' => 'expenses',
    'label' => 'Expenses',
    'icon' => 'bi-receipt',
    'permission' => ['expenses.view', 'expenses.manage'],
    'route' => 'expenses/index',
    'prefix' => 'expenses/',
    'children' => [],
];

$menu[] = [
    'key' => 'users',
    'label' => 'Users & Roles',
    'icon' => 'bi-person-badge-fill',
    'permission' => ['users.view', 'users.manage'],
    'route' => 'users/users',
    'prefix' => 'users/',
    'children' => [
        ['label' => 'Users', 'route' => 'users/users', 'icon' => 'bi-people', 'permission' => ['users.manage']],
        ['label' => 'Roles & Permissions', 'route' => 'users/roles', 'icon' => 'bi-shield-lock', 'permission' => ['users.manage']],
        ['label' => 'Custom Fields', 'route' => 'users/customFields', 'href' => 'index.php?route=users/customFields&scope=user', 'icon' => 'bi-input-cursor-text', 'permission' => ['users.manage']],
        ['label' => 'My Attendance', 'route' => 'users/attendance', 'icon' => 'bi-calendar2-check', 'permission' => ['users.view', 'users.manage']],
    ],
];

$menu[] = [
    'key' => 'sendSms',
    'label' => 'Send SMS',
    'icon' => 'bi-chat-dots-fill',
    'permission' => ['sms.direct_send'],
    'route' => 'portal/sendSms',
    'prefix' => 'portal/sendSms',
    'children' => [],
];

$menu[] = [
    'key' => 'smsHistory',
    'label' => 'SMS History',
    'icon' => 'bi-clock-history',
    'permission' => ['sms.history_view'],
    'route' => 'portal/smsHistory',
    'prefix' => 'portal/smsHistory',
    'children' => [],
];

$menu[] = [
    'key' => 'announcements',
    'label' => 'Announcements',
    'icon' => 'bi-megaphone-fill',
    'permission' => ['notifications.announce'],
    'route' => 'notifications/announcements',
    'prefix' => 'notifications/announcements',
    'children' => [],
];

$menu[] = [
    'key' => 'reports',
    'label' => 'Reports',
    'icon' => 'bi-bar-chart-fill',
    'permission' => ['reports.view'],
    'route' => 'reports/studentAttendance',
    'prefix' => 'reports/',
    'children' => [
        ['label' => 'Student Attendance', 'route' => 'reports/studentAttendance', 'icon' => 'bi-person-check'],
        ['label' => 'Exam Marks', 'route' => 'reports/examMarks', 'icon' => 'bi-clipboard-data'],
        ['label' => 'Fee Collections', 'route' => 'reports/feeCollections', 'icon' => 'bi-cash-coin'],
        // Every invoice issued in a date range, any status (open/paid/cancelled) —
        // a proper report page (filters + table + its own Export CSV button), same
        // pattern as Fee Collections above, not a bare download link.
        ['label' => 'Invoices', 'route' => 'reports/invoices', 'icon' => 'bi-receipt-cutoff'],
        ['label' => 'Staff Attendance', 'route' => 'reports/staffAttendance', 'icon' => 'bi-person-badge'],
        // Other Expenses + Salary Payments, combined — separate permission-less
        // (same 'reports.view'/'reports.export' as the rest of this section) so it
        // doesn't need the 'expenses'/'staff.manage' sections to be visible.
        ['label' => 'Expenses', 'route' => 'reports/expenses', 'icon' => 'bi-cash-stack'],
        ['label' => 'Custom Generator', 'route' => 'reports/customGenerator', 'icon' => 'bi-gear-wide-connected'],
        // Direct CSV download (no report page of its own — clicking starts the
        // download immediately, same as "Export CSV" on the Students list page).
        // Permission narrowed to match what StudentsController::exportCsvAction() enforces.
        ['label' => 'Students Register Export (CSV)', 'route' => 'students/exportCsv', 'icon' => 'bi-download', 'permission' => ['students.view', 'students.manage']],
        // Shortcuts to the existing bulk-export pages so every export is reachable from
        // Reports. Each keeps the permission its own page enforces, so nobody sees a
        // link that would only 403.
        ['label' => 'Fee Bulk Export', 'route' => 'fees/bulkExports', 'icon' => 'bi-file-earmark-zip', 'permission' => ['fees.manage', 'fees.bulk_exports']],
        ['label' => 'Report Cards Bulk Export', 'route' => 'academic/bulkExports', 'icon' => 'bi-file-earmark-zip', 'permission' => ['academic.bulk_export']],
    ],
];

$menu[] = [
    'key' => 'activityLog',
    'label' => 'Activity Log',
    'icon' => 'bi-clock-history',
    'permission' => ['activity_log.view'],
    'route' => 'activityLog/index',
    'prefix' => 'activityLog/',
    'children' => [],
];

$menu[] = [
    'key' => 'settings',
    'label' => 'Settings',
    'icon' => 'bi-gear-fill',
    'permission' => ['settings.view', 'settings.manage'],
    'route' => 'settings/global',
    'prefix' => 'settings/',
    'children' => [
        ['label' => 'Global Settings', 'route' => 'settings/global', 'icon' => 'bi-sliders', 'permission' => ['settings.manage']],
        ['label' => 'Academic Years', 'route' => 'settings/academicYears', 'icon' => 'bi-calendar-range', 'permission' => ['settings.manage']],
        ['label' => 'Institute Info', 'route' => 'settings/institute', 'icon' => 'bi-building', 'permission' => ['settings.manage']],
        ['label' => 'Branding', 'route' => 'settings/branding', 'icon' => 'bi-palette', 'permission' => ['settings.manage']],
        ['label' => 'Label Management', 'route' => 'settings/labels', 'icon' => 'bi-tag', 'permission' => ['settings.manage']],
        ['label' => 'Notifications', 'route' => 'settings/notifications', 'icon' => 'bi-bell', 'permission' => ['settings.manage']],
        ['label' => 'SMS Gateway Devices', 'route' => 'settings/smsDevices', 'icon' => 'bi-phone', 'permission' => ['settings.manage', 'settings.sms_gateway_devices']],
        ['label' => 'Clean Data', 'route' => 'settings/cleanData', 'icon' => 'bi-eraser', 'permission' => ['settings.manage']],
        ['label' => 'Backup & Restore', 'route' => 'settings/backup', 'icon' => 'bi-cloud-arrow-down', 'permission' => ['settings.manage']],
    ],
];

return $menu;