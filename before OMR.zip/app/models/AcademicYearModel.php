<?php

/**
 * Resolves "the current academic year" consistently across the app.
 *
 * Preferred source of truth is the calendar: a year whose start_date/end_date
 * span contains today automatically becomes "current" the moment its dates
 * begin, with no admin action needed when a new year rolls around (e.g.
 * 2027-2028 becomes current on 2027-03-01 without anyone flipping a flag).
 *
 * The manual `is_active` flag (set from Settings > Academic Years) is kept
 * only as a fallback for years that don't have both dates set yet, so admins
 * can still force a choice while a new year is being configured.
 */
class AcademicYearModel
{
    /** Returns the id of the current academic year, or null if none can be determined. */
    public static function currentId(): ?int
    {
        $today = date('Y-m-d');

        $byDate = Database::fetchOne(
            'SELECT id FROM academic_years
             WHERE start_date IS NOT NULL AND end_date IS NOT NULL
               AND start_date <= ? AND end_date >= ?
             ORDER BY start_date DESC
             LIMIT 1',
            'ss',
            [$today, $today]
        );
        if ($byDate && !empty($byDate['id'])) {
            return (int)$byDate['id'];
        }

        // Fallback: no year's date range covers today (dates not set yet, or
        // a gap between years) — fall back to whichever is manually marked active.
        $byFlag = Database::fetchOne(
            'SELECT id FROM academic_years WHERE is_active = 1 ORDER BY id DESC LIMIT 1'
        );
        if ($byFlag && !empty($byFlag['id'])) {
            return (int)$byFlag['id'];
        }

        return null;
    }
}
