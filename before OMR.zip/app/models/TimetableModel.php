<?php

class TimetableModel
{
    /** Lazily add teacher_id if the migration hasn't been run yet (mirrors SubjectModel's pattern). */
    public static function ensureTeacherIdColumn(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        try {
            $col = Database::fetchOne("SHOW COLUMNS FROM timetable_entries LIKE 'teacher_id'");
            if (!$col) {
                Database::execute('ALTER TABLE timetable_entries ADD COLUMN teacher_id INT NULL AFTER subject_id');
                try {
                    Database::execute(
                        'ALTER TABLE timetable_entries
                         ADD CONSTRAINT fk_timetable_teacher
                         FOREIGN KEY (teacher_id) REFERENCES staff_profiles(id) ON DELETE SET NULL'
                    );
                } catch (Throwable $e) {
                    // FK may already exist or lack permission — column alone is enough
                }
            }
        } catch (Throwable $e) {
            // ignore — run db/migrate_timetable_teacher.sql manually if needed
        }
        $done = true;
    }

    public static function listByClassSection(int $classSectionId, ?int $dayOfWeek = null): array
    {
        self::ensureTeacherIdColumn();
        $sql = 'SELECT te.*,
                    s.subject_name,
                    cs.id AS class_section_row_id,
                    c.name AS class_name,
                    sec.name AS section_name,
                    sp.full_name AS teacher_name
             FROM timetable_entries te
             JOIN subjects s ON s.id = te.subject_id
             JOIN class_sections cs ON cs.id = te.class_section_id
             JOIN classes c ON c.id = cs.class_id
             JOIN sections sec ON sec.id = cs.section_id
             LEFT JOIN staff_profiles sp ON sp.id = te.teacher_id
             WHERE te.class_section_id = ?';
        $types = 'i';
        $params = [$classSectionId];

        if ($dayOfWeek !== null && $dayOfWeek > 0) {
            $sql .= ' AND te.day_of_week = ?';
            $types .= 'i';
            $params[] = $dayOfWeek;
        }

        $sql .= ' ORDER BY te.day_of_week, te.start_time';

        return Database::fetchAll($sql, $types, $params
        );
    }

    /** Every period this teacher is assigned to, across all classes/sections — for the Teacher Portal's "My Timetable" page. */
    public static function listByTeacher(int $teacherId): array
    {
        self::ensureTeacherIdColumn();
        return Database::fetchAll(
            'SELECT te.*,
                    s.subject_name,
                    cs.id AS class_section_row_id,
                    c.name AS class_name,
                    sec.name AS section_name,
                    sp.full_name AS teacher_name
             FROM timetable_entries te
             JOIN subjects s ON s.id = te.subject_id
             JOIN class_sections cs ON cs.id = te.class_section_id
             JOIN classes c ON c.id = cs.class_id
             JOIN sections sec ON sec.id = cs.section_id
             LEFT JOIN staff_profiles sp ON sp.id = te.teacher_id
             WHERE te.teacher_id = ?
             ORDER BY te.day_of_week, te.start_time',
            'i',
            [$teacherId]
        );
    }

    private static function normalizeTime(string $time): string
    {
        $time = trim($time);
        if ($time === '') {
            return $time;
        }
        // HTML time inputs often send HH:MM; MySQL TIME prefers HH:MM:SS
        if (preg_match('/^\d{1,2}:\d{2}$/', $time)) {
            return $time . ':00';
        }
        return $time;
    }

    public static function create(array $data, ?int $createdByUserId): int
    {
        self::ensureTeacherIdColumn();
        $room = trim((string)($data['room'] ?? ''));
        $teacherId = !empty($data['teacher_id']) ? (int)$data['teacher_id'] : null;
        Database::execute(
            'INSERT INTO timetable_entries (class_section_id, day_of_week, start_time, end_time, subject_id, teacher_id, room, created_by_user_id)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            'iissiisi',
            [
                (int)$data['class_section_id'],
                (int)$data['day_of_week'],
                self::normalizeTime((string)$data['start_time']),
                self::normalizeTime((string)$data['end_time']),
                (int)$data['subject_id'],
                $teacherId,
                $room !== '' ? $room : null,
                $createdByUserId ? (int)$createdByUserId : null,
            ]
        );
        self::syncTeacherSubjectAssignment($teacherId, (int)$data['subject_id']);
        return (int)Database::lastInsertId();
    }

    public static function update(int $id, array $data, ?int $updatedByUserId): void
    {
        self::ensureTeacherIdColumn();
        $room = trim((string)($data['room'] ?? ''));
        $teacherId = !empty($data['teacher_id']) ? (int)$data['teacher_id'] : null;
        Database::execute(
            'UPDATE timetable_entries
             SET class_section_id = ?,
                 day_of_week = ?,
                 start_time = ?,
                 end_time = ?,
                 subject_id = ?,
                 teacher_id = ?,
                 room = ?,
                 updated_at = NOW()
             WHERE id = ?',
            'iissiisi',
            [
                (int)$data['class_section_id'],
                (int)$data['day_of_week'],
                self::normalizeTime((string)$data['start_time']),
                self::normalizeTime((string)$data['end_time']),
                (int)$data['subject_id'],
                $teacherId,
                $room !== '' ? $room : null,
                $id
            ]
        );
        self::syncTeacherSubjectAssignment($teacherId, (int)$data['subject_id']);
    }

    /**
     * Whenever a timetable entry links a teacher to a subject, make sure that same
     * link exists in staff_subject_assignments — the table the Teacher Portal, Marks
     * Entry access, and RBAC scoping actually read from. Without this, filling in the
     * Timetable would not be enough on its own; "Teacher Assignments" would still need
     * to be filled in separately for the same information.
     *
     * This only ever ADDS an assignment, never removes one — so deleting or reassigning
     * a timetable slot can't accidentally revoke a teacher's access to marks they've
     * already started entering. Removing a teacher-subject link is still a deliberate
     * action on the Teacher Assignments page.
     */
    private static function syncTeacherSubjectAssignment(?int $teacherId, int $subjectId): void
    {
        if (!$teacherId || $subjectId <= 0) {
            return;
        }
        try {
            require_once __DIR__ . '/StaffSubjectAssignmentModel.php';
            StaffSubjectAssignmentModel::assignTeacher($subjectId, $teacherId);
        } catch (Throwable $e) {
            // Non-fatal — the timetable entry itself already saved successfully.
        }
    }

    public static function delete(int $id): void
    {
        Database::execute('DELETE FROM timetable_entries WHERE id = ?', 'i', [$id]);
    }
}