<?php

class StudentModel
{
    public static function ensureCnicColumn(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        try {
            $col = Database::fetchOne("SHOW COLUMNS FROM students LIKE 'cnic_no'");
            if (!$col) {
                Database::execute(
                    'ALTER TABLE students ADD COLUMN cnic_no VARCHAR(25) NULL AFTER board_registration_no'
                );
            }
        } catch (Throwable $e) {
            // ignore — run migrate_student_cnic.sql manually if needed
        }
        $done = true;
    }

    public static function list(string $search, ?int $classSectionId, int $limit, int $offset, ?int $statusFilter = null, bool $onlyPublishedExamClasses = false, bool $orderByRoll = false): array
    {
        self::ensureCnicColumn();
        $search = trim($search);

        $params = [];
        $types = '';

        $sql = '
            SELECT s.*,
                   cs.id AS current_class_section_id,
                   c.name AS current_class_name,
                   sec.name AS current_section_name,
                   sca.roll_number AS roll_number
            FROM students s
            LEFT JOIN student_class_assignments sca
              ON sca.id = (
                SELECT sca2.id
                FROM student_class_assignments sca2
                WHERE sca2.student_id = s.id
                ORDER BY sca2.assigned_at DESC, sca2.id DESC
                LIMIT 1
              )
            LEFT JOIN class_sections cs ON cs.id = sca.class_section_id
            LEFT JOIN classes c ON c.id = cs.class_id
            LEFT JOIN sections sec ON sec.id = cs.section_id
            WHERE 1=1
        ';

        // Used by the report-card search box for non-admin users: a class whose
        // only exam(s) are unpublished has nothing a teacher/parent may see, so
        // its students shouldn't be findable there either — same rule the exam
        // dropdown already applies, just enforced on the student list too.
        if ($onlyPublishedExamClasses) {
            $sql .= ' AND cs.id IN (SELECT DISTINCT class_section_id FROM exams WHERE results_published = 1)';
        }

        if (!empty($search)) {
            // Split first/last name mean a full "First Last" search string never
            // matches either column alone (e.g. "Iram Fatima" against a row where
            // first_name='Iram', last_name='Fatima') — only single-word searches
            // worked. Matching the concatenated full name too fixes that without
            // touching the existing single-column matches.
            $sql .= " AND (s.admission_no LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ?
                      OR CONCAT(s.first_name, ' ', s.last_name) LIKE ?
                      OR s.father_name LIKE ? OR s.board_registration_no LIKE ?
                      OR CAST(s.id AS CHAR) LIKE ? OR IFNULL(s.cnic_no,'') LIKE ?)";
            $like = "%$search%";
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $types .= 'ssssssss';
        }

        if ($classSectionId && $classSectionId > 0) {
            $sql .= " AND cs.id = ?";
            $params[] = $classSectionId;
            $types .= 'i';
        }

        if ($statusFilter !== null) {
            $sql .= ' AND IFNULL(s.status, 1) = ?';
            $params[] = $statusFilter;
            $types .= 'i';
        }

        // Browsing a whole class (no typed search) reads better sorted by roll
        // number than by newest-added; typed searches keep the old newest-first
        // order since roll number isn't meaningful across a mixed result set.
        $sql .= $orderByRoll
            ? " ORDER BY sca.roll_number ASC, s.first_name ASC LIMIT ? OFFSET ?"
            : " ORDER BY s.id DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        $types .= 'ii';

        return Database::fetchAll($sql, $types, $params);
    }

    /**
     * Students currently enrolled in a class/section (latest assignment only).
     * Extra optional args kept for backward compatibility with older call sites.
     */
    public static function getStudentsForClassSection(
        int $classSectionId,
        string $search = '',
        int $limit = 500,
        int $offset = 0
    ): array {
        $search = trim($search);
        $limit = max(1, min(2000, $limit));
        $offset = max(0, $offset);

        $sql = "SELECT s.*, sca.roll_number
                FROM students s
                INNER JOIN student_class_assignments sca
                  ON sca.id = (
                    SELECT sca2.id
                    FROM student_class_assignments sca2
                    WHERE sca2.student_id = s.id
                    ORDER BY sca2.assigned_at DESC, sca2.id DESC
                    LIMIT 1
                  )
                WHERE sca.class_section_id = ?
                  AND IFNULL(s.status, 1) = 1";
        $types = 'i';
        $params = [$classSectionId];

        if ($search !== '') {
            $like = '%' . $search . '%';
            $sql .= ' AND (s.admission_no LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ?)';
            $types .= 'sss';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $sql .= ' ORDER BY sca.roll_number ASC, s.first_name ASC LIMIT ? OFFSET ?';
        $types .= 'ii';
        $params[] = $limit;
        $params[] = $offset;

        return Database::fetchAll($sql, $types, $params);
    }

    public static function count(string $search, ?int $classSectionId, ?int $statusFilter = null): int
    {
        self::ensureCnicColumn();
        $search = trim($search);
        $searchLike = "%$search%";

        $params = [];
        $types = '';

        $where = 'WHERE ( ? = "" OR s.admission_no LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ?
                   OR CONCAT(s.first_name, " ", s.last_name) LIKE ?
                   OR IFNULL(s.father_name, "") LIKE ? OR IFNULL(s.board_registration_no, "") LIKE ?
                   OR CAST(s.id AS CHAR) LIKE ? OR IFNULL(s.cnic_no, "") LIKE ?)';
        $params[] = $search;
        $params[] = $searchLike;
        $params[] = $searchLike;
        $params[] = $searchLike;
        $params[] = $searchLike;
        $params[] = $searchLike;
        $params[] = $searchLike;
        $params[] = $searchLike;
        $params[] = $searchLike;
        $types .= 'sssssssss';

        if ($classSectionId && $classSectionId > 0) {
            $where .= ' AND cs.id = ?';
            $params[] = $classSectionId;
            $types .= 'i';
        }

        if ($statusFilter !== null) {
            $where .= ' AND IFNULL(s.status, 1) = ?';
            $params[] = $statusFilter;
            $types .= 'i';
        }

        $sql = "
            SELECT COUNT(*) AS cnt
            FROM students s
            LEFT JOIN student_class_assignments sca
              ON sca.id = (
                SELECT sca2.id
                FROM student_class_assignments sca2
                WHERE sca2.student_id = s.id
                ORDER BY sca2.assigned_at DESC, sca2.id DESC
                LIMIT 1
              )
            LEFT JOIN class_sections cs ON cs.id = sca.class_section_id
            $where
        ";

        $row = Database::fetchOne($sql, $types, $params);
        return (int)($row['cnt'] ?? 0);
    }

    public static function getById(int $studentId): ?array
    {
        return Database::fetchOne(
            'SELECT s.*,
                    cs.id AS current_class_section_id,
                    c.name AS current_class_name,
                    sec.name AS current_section_name,
                    sca.roll_number AS roll_number
             FROM students s
             LEFT JOIN student_class_assignments sca
               ON sca.id = (
                 SELECT sca2.id
                 FROM student_class_assignments sca2
                 WHERE sca2.student_id = s.id
                 ORDER BY sca2.assigned_at DESC, sca2.id DESC
                 LIMIT 1
               )
             LEFT JOIN class_sections cs ON cs.id = sca.class_section_id
             LEFT JOIN classes c ON c.id = cs.class_id
             LEFT JOIN sections sec ON sec.id = cs.section_id
             WHERE s.id = ?',
            'i',
            [$studentId]
        );
    }

    public static function getCurrentClassSectionId(int $studentId): ?int
    {
        $row = Database::fetchOne(
            'SELECT class_section_id
             FROM student_class_assignments
             WHERE student_id = ?
             ORDER BY assigned_at DESC, id DESC
             LIMIT 1',
            'i',
            [$studentId]
        );

        return $row ? (int)$row['class_section_id'] : null;
    }

    /** Empty / 0 roll is stored as NULL so it does not block unique (class, roll). */
    public static function normalizeRoll($roll): ?int
    {
        $r = (int)$roll;
        return $r > 0 ? $r : null;
    }

    /**
     * Free roll numbers that should not block reuse:
     * - old (non-latest) class assignments after a move/promotion
     * - Left school students (status = 0)
     */
    public static function releaseStaleRollNumbers(): void
    {
        try {
            // Old assignment history must not keep a unique roll
            Database::execute(
                'UPDATE student_class_assignments sca
                 INNER JOIN (
                     SELECT student_id, MAX(id) AS latest_id
                     FROM student_class_assignments
                     GROUP BY student_id
                 ) cur ON cur.student_id = sca.student_id
                 SET sca.roll_number = NULL
                 WHERE sca.roll_number IS NOT NULL
                   AND sca.id <> cur.latest_id'
            );
            // Left students free their roll for the class
            Database::execute(
                'UPDATE student_class_assignments sca
                 INNER JOIN students s ON s.id = sca.student_id
                 SET sca.roll_number = NULL
                 WHERE sca.roll_number IS NOT NULL
                   AND IFNULL(s.status, 1) = 0'
            );
        } catch (Throwable $e) {
            // ignore — unique constraint still enforced below
        }
    }

    /**
     * Who currently holds this roll in the class (latest assignment only, active students).
     */
    public static function findActiveRollHolder(int $classSectionId, int $rollNumber, ?int $excludeStudentId = null): ?array
    {
        self::releaseStaleRollNumbers();
        $sql = 'SELECT s.id, s.admission_no, s.first_name, s.last_name, IFNULL(s.status, 1) AS status
                FROM student_class_assignments sca
                INNER JOIN students s ON s.id = sca.student_id
                WHERE sca.class_section_id = ?
                  AND sca.roll_number = ?
                  AND sca.id = (
                      SELECT MAX(sca2.id) FROM student_class_assignments sca2
                      WHERE sca2.student_id = sca.student_id
                  )
                  AND IFNULL(s.status, 1) = 1';
        $types = 'ii';
        $params = [$classSectionId, $rollNumber];
        if ($excludeStudentId && $excludeStudentId > 0) {
            $sql .= ' AND s.id <> ?';
            $types .= 'i';
            $params[] = $excludeStudentId;
        }
        $sql .= ' LIMIT 1';
        return Database::fetchOne($sql, $types, $params);
    }

    public static function assertRollAvailable(int $classSectionId, ?int $rollNumber, ?int $excludeStudentId = null): void
    {
        if ($rollNumber === null || $rollNumber <= 0 || $classSectionId <= 0) {
            return;
        }
        $holder = self::findActiveRollHolder($classSectionId, $rollNumber, $excludeStudentId);
        if ($holder) {
            $name = trim(($holder['first_name'] ?? '') . ' ' . ($holder['last_name'] ?? ''));
            $adm = (string)($holder['admission_no'] ?? '');
            throw new RuntimeException(
                'Roll number ' . $rollNumber . ' is already used in this class by '
                . ($name !== '' ? $name : 'another student')
                . ($adm !== '' ? ' (Admission: ' . $adm . ')' : '')
                . '. Change that student\'s roll, mark them Left, or delete them first.'
            );
        }
    }

    public static function create(array $data, ?int $assignedClassSectionId, ?int $assignedByUserId): int
    {
        self::ensureCnicColumn();
        $roll = self::normalizeRoll($data['roll_number'] ?? null);
        if ($assignedClassSectionId && $assignedClassSectionId > 0) {
            self::assertRollAvailable((int)$assignedClassSectionId, $roll, null);
        }

        $conn = Database::connection();
        $conn->begin_transaction();

        try {
            $stmt = $conn->prepare(
                'INSERT INTO students
                 (user_id, admission_no, roll_number, first_name, last_name, father_name, board_registration_no, cnic_no,
                  gender, dob, phone, address, fee_discount_percent, fee_discount_is_percent, status)
                 VALUES
                 (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)'
            );

            $rollForStudentsTable = $roll ?? 0;
            $fatherName = (string)($data['father_name'] ?? '');
            $boardReg = (string)($data['board_registration_no'] ?? '');
            $cnic = (string)($data['cnic_no'] ?? '');
            $feeIsPercent = ((int)($data['fee_discount_is_percent'] ?? 1) === 1) ? 1 : 0;
            $feeDiscount = (float)($data['fee_discount_percent'] ?? 0);
            if ($feeDiscount < 0) { $feeDiscount = 0; }
            if ($feeIsPercent && $feeDiscount > 100) { $feeDiscount = 100; }

            $stmt->bind_param(
                'sisssssssssdi',
                $data['admission_no'],
                $rollForStudentsTable,
                $data['first_name'],
                $data['last_name'],
                $fatherName,
                $boardReg,
                $cnic,
                $data['gender'],
                $data['dob'],
                $data['phone'],
                $data['address'],
                $feeDiscount,
                $feeIsPercent
            );

            $stmt->execute();
            $insertId = (int)$conn->insert_id;

            if ($assignedClassSectionId && $assignedClassSectionId > 0) {
                Database::execute(
                    'INSERT INTO student_class_assignments (student_id, class_section_id, assigned_by_user_id, note, roll_number)
                     VALUES (?, ?, ?, ?, ?)',
                    'iiisi',
                    [
                        $insertId,
                        $assignedClassSectionId,
                        $assignedByUserId,
                        (string)($data['note'] ?? ''),
                        $roll
                    ]
                );
            }

            $conn->commit();
            return $insertId;

        } catch (Throwable $e) {
            $conn->rollback();
            $msg = $e->getMessage();
            if (stripos($msg, 'uq_roll_class') !== false || stripos($msg, 'Duplicate entry') !== false) {
                throw new RuntimeException(
                    'Roll number ' . ($roll ?? '') . ' is already taken in this class. '
                    . 'It may belong to a Left student or an old class record — try again, or pick another roll.'
                );
            }
            throw $e;
        }
    }

    /**
     * Promote / move a student to a different class section.
     * Used by bulk class assignment and the promotions screen.
     */
    public static function promote(int $studentId, int $toClassSectionId, ?int $byUserId, string $note = ''): void
    {
        if ($studentId <= 0 || $toClassSectionId <= 0) {
            return;
        }

        $currentClassSectionId = self::getCurrentClassSectionId($studentId);
        if ($currentClassSectionId && (int)$currentClassSectionId === $toClassSectionId) {
            // Already assigned to this class section; nothing to do
            return;
        }

        // Free roll numbers on previous assignment rows so history cannot block reuse
        Database::execute(
            'UPDATE student_class_assignments SET roll_number = NULL WHERE student_id = ?',
            'i',
            [$studentId]
        );

        Database::execute(
            'INSERT INTO student_class_assignments (student_id, class_section_id, assigned_by_user_id, note, roll_number)
             VALUES (?, ?, ?, ?, NULL)',
            'iiis',
            [
                $studentId,
                $toClassSectionId,
                $byUserId,
                $note
            ]
        );
    }

    public static function update(int $studentId, array $data, ?int $assignedClassSectionId, ?int $assignedByUserId): void
    {
        self::ensureCnicColumn();
        $feeIsPercent = ((int)($data['fee_discount_is_percent'] ?? 1) === 1) ? 1 : 0;
        $feeDiscount = (float)($data['fee_discount_percent'] ?? 0);
        if ($feeDiscount < 0) { $feeDiscount = 0; }
        if ($feeIsPercent && $feeDiscount > 100) { $feeDiscount = 100; }

        $status = ((int)($data['status'] ?? 1) === 1) ? 1 : 0;
        $roll = self::normalizeRoll($data['roll_number'] ?? null);
        $currentClassSectionId = self::getCurrentClassSectionId($studentId);
        $targetClassSectionId = ($assignedClassSectionId && $assignedClassSectionId > 0)
            ? (int)$assignedClassSectionId
            : ($currentClassSectionId ? (int)$currentClassSectionId : null);

        // Leaving school frees the roll immediately
        if ($status === 0) {
            Database::execute(
                'UPDATE student_class_assignments SET roll_number = NULL WHERE student_id = ?',
                'i',
                [$studentId]
            );
            $roll = null;
        } elseif ($targetClassSectionId) {
            self::assertRollAvailable($targetClassSectionId, $roll, $studentId);
        }

        Database::execute(
            'UPDATE students
             SET admission_no = ?,
                 first_name = ?,
                 last_name = ?,
                 father_name = ?,
                 board_registration_no = ?,
                 cnic_no = ?,
                 gender = ?,
                 dob = ?,
                 phone = ?,
                 address = ?,
                 fee_discount_percent = ?,
                 fee_discount_is_percent = ?,
                 status = ?
             WHERE id = ?',
            'ssssssssssdiii',
            [
                $data['admission_no'],
                $data['first_name'],
                $data['last_name'],
                (string)($data['father_name'] ?? ''),
                (string)($data['board_registration_no'] ?? ''),
                (string)($data['cnic_no'] ?? ''),
                $data['gender'],
                $data['dob'],
                $data['phone'],
                $data['address'],
                $feeDiscount,
                $feeIsPercent,
                $status,
                $studentId
            ]
        );

        // New class assignment (move / first assign)
        if ($assignedClassSectionId && $assignedClassSectionId > 0
            && (!$currentClassSectionId || (int)$currentClassSectionId !== (int)$assignedClassSectionId)) {
            // Free roll on previous rows for this student so history cannot block reuse
            Database::execute(
                'UPDATE student_class_assignments SET roll_number = NULL WHERE student_id = ?',
                'i',
                [$studentId]
            );
            Database::execute(
                'INSERT INTO student_class_assignments (student_id, class_section_id, assigned_by_user_id, note, roll_number)
                 VALUES (?, ?, ?, ?, ?)',
                'iiisi',
                [
                    $studentId,
                    (int)$assignedClassSectionId,
                    $assignedByUserId,
                    (string)($data['note'] ?? ''),
                    $roll
                ]
            );
            return;
        }

        // Same class: update roll on the latest assignment
        if ($currentClassSectionId && $status === 1) {
            $latest = Database::fetchOne(
                'SELECT id FROM student_class_assignments
                 WHERE student_id = ?
                 ORDER BY assigned_at DESC, id DESC
                 LIMIT 1',
                'i',
                [$studentId]
            );
            if ($latest) {
                Database::execute(
                    'UPDATE student_class_assignments SET roll_number = ? WHERE id = ?',
                    'ii',
                    [$roll, (int)$latest['id']]
                );
            }
        }
    }

    /**
     * Full class/section history for a student, most recent first — one row per
     * promotion or class move. This data has always been preserved (promote()
     * inserts a new row rather than overwriting), it just wasn't surfaced in the
     * UI before. Includes who made the move and their note, when available.
     */
    public static function getClassHistory(int $studentId): array
    {
        return Database::fetchAll(
            'SELECT sca.id, sca.class_section_id, sca.assigned_at, sca.note, sca.roll_number,
                    c.name AS class_name, sec.name AS section_name,
                    u.username AS assigned_by_username
             FROM student_class_assignments sca
             LEFT JOIN class_sections cs ON cs.id = sca.class_section_id
             LEFT JOIN classes c ON c.id = cs.class_id
             LEFT JOIN sections sec ON sec.id = cs.section_id
             LEFT JOIN users u ON u.id = sca.assigned_by_user_id
             WHERE sca.student_id = ?
             ORDER BY sca.assigned_at DESC, sca.id DESC',
            'i',
            [$studentId]
        );
    }

    public static function delete(int $studentId): void
    {
        // Was previously a hard DELETE FROM students, which — via ON DELETE CASCADE —
        // permanently destroyed the student's attendance, fee invoices/payments, exam
        // marks, and guardian links. Deactivating instead reuses the existing
        // status=0 mechanism (already used by update(), already excluded from
        // default active lists, already reversible from the Edit Student screen)
        // and preserves all historical records.
        Database::execute(
            'UPDATE student_class_assignments SET roll_number = NULL WHERE student_id = ?',
            'i',
            [$studentId]
        );
        Database::execute(
            'UPDATE students SET status = 0 WHERE id = ?',
            'i',
            [$studentId]
        );
    }

    public static function upsertByAdmissionNo(array $row, ?int $assignedClassSectionId, ?int $assignedByUserId): int
    {
        $existing = Database::fetchOne(
            'SELECT id FROM students WHERE admission_no = ?',
            's',
            [$row['admission_no']]
        );

        $data = [
            'admission_no' => (string)$row['admission_no'],
            'roll_number' => isset($row['roll_number']) && $row['roll_number'] !== ''
                ? (int)$row['roll_number']
                : null,
            'first_name' => (string)($row['first_name'] ?? ''),
            'last_name' => (string)($row['last_name'] ?? ''),
            'gender' => (string)($row['gender'] ?? 'M'),
            'dob' => $row['dob'] ?? null,
            'phone' => (string)($row['phone'] ?? ''),
            'address' => (string)($row['address'] ?? ''),
            'note' => (string)($row['note'] ?? ''),
        ];

        if ($existing) {
            self::update((int)$existing['id'], $data, $assignedClassSectionId, $assignedByUserId);
            return (int)$existing['id'];
        }

        return self::create($data, $assignedClassSectionId, $assignedByUserId);
    }
}