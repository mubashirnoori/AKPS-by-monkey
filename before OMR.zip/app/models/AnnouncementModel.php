<?php

class AnnouncementModel
{
    public const AUDIENCES = ['everyone', 'staff', 'parents', 'students', 'class'];

    /**
     * Resolve an audience choice into the concrete list of active user IDs
     * who should receive it. Role names ('Student', 'Parent') come from the
     * `roles` table rather than being hard-coded IDs, since role IDs can
     * differ between installs.
     */
    public static function resolveAudienceUserIds(string $audience, ?int $classSectionId): array
    {
        switch ($audience) {
            case 'everyone':
                $rows = Database::fetchAll('SELECT id FROM users WHERE status = 1');
                return array_map(static fn($r) => (int)$r['id'], $rows);

            case 'staff':
                $rows = Database::fetchAll(
                    "SELECT u.id FROM users u
                     JOIN roles r ON r.id = u.role_id
                     WHERE u.status = 1 AND r.name NOT IN ('Student', 'Parent')"
                );
                return array_map(static fn($r) => (int)$r['id'], $rows);

            case 'parents':
                $rows = Database::fetchAll(
                    "SELECT u.id FROM users u
                     JOIN roles r ON r.id = u.role_id
                     WHERE u.status = 1 AND r.name = 'Parent'"
                );
                return array_map(static fn($r) => (int)$r['id'], $rows);

            case 'students':
                $rows = Database::fetchAll(
                    "SELECT u.id FROM users u
                     JOIN roles r ON r.id = u.role_id
                     WHERE u.status = 1 AND r.name = 'Student'"
                );
                return array_map(static fn($r) => (int)$r['id'], $rows);

            case 'class':
                if (!$classSectionId) {
                    return [];
                }
                // Every currently-assigned student in the class (their own login,
                // if any) plus every guardian linked to them (if any) — the same
                // "student + parents" fan-out used elsewhere for class-wide events.
                $rows = Database::fetchAll(
                    "SELECT s.user_id
                     FROM students s
                     INNER JOIN student_class_assignments sca
                        ON sca.id = (
                            SELECT sca2.id FROM student_class_assignments sca2
                            WHERE sca2.student_id = s.id
                            ORDER BY sca2.assigned_at DESC, sca2.id DESC LIMIT 1
                        )
                     WHERE sca.class_section_id = ? AND s.user_id IS NOT NULL AND IFNULL(s.status, 1) = 1
                     UNION
                     SELECT g.user_id
                     FROM guardians g
                     JOIN student_guardians sg ON sg.guardian_id = g.id
                     JOIN students s ON s.id = sg.student_id
                     INNER JOIN student_class_assignments sca
                        ON sca.id = (
                            SELECT sca2.id FROM student_class_assignments sca2
                            WHERE sca2.student_id = s.id
                            ORDER BY sca2.assigned_at DESC, sca2.id DESC LIMIT 1
                        )
                     WHERE sca.class_section_id = ? AND g.user_id IS NOT NULL AND IFNULL(s.status, 1) = 1",
                    'ii',
                    [$classSectionId, $classSectionId]
                );
                return array_values(array_unique(array_map(static fn($r) => (int)$r['user_id'], $rows)));

            default:
                return [];
        }
    }

    public static function create(
        string $title,
        string $message,
        string $audience,
        ?int $classSectionId,
        int $recipientCount,
        int $pushSentCount,
        ?int $createdByUserId
    ): int {
        Database::execute(
            'INSERT INTO announcements
                (title, message, audience, class_section_id, recipient_count, push_sent_count, created_by_user_id)
             VALUES (?, ?, ?, ?, ?, ?, ?)',
            'sssiiii',
            [$title, $message, $audience, $classSectionId, $recipientCount, $pushSentCount, $createdByUserId]
        );
        return (int)Database::lastInsertId();
    }

    /** Records how many recipients were actually reached via SMS and email (run once, after sending). */
    public static function recordChannelCounts(int $announcementId, int $smsSentCount, int $emailSentCount): void
    {
        Database::execute(
            'UPDATE announcements SET sms_sent_count = ?, email_sent_count = ? WHERE id = ?',
            'iii',
            [$smsSentCount, $emailSentCount, $announcementId]
        );
    }

    public static function delete(int $id): void
    {
        Database::execute('DELETE FROM announcements WHERE id = ?', 'i', [$id]);
    }

    public static function find(int $id): ?array
    {
        return Database::fetchOne('SELECT id, title FROM announcements WHERE id = ?', 'i', [$id]);
    }

    public static function recent(int $limit = 30): array
    {
        return Database::fetchAll(
            "SELECT a.id, a.title, a.message, a.audience, a.recipient_count,
                    a.push_sent_count, a.sms_sent_count, a.email_sent_count, a.created_at,
                    u.username AS created_by_username,
                    c.name AS class_name, sec.name AS section_name
             FROM announcements a
             LEFT JOIN users u ON u.id = a.created_by_user_id
             LEFT JOIN class_sections cs ON cs.id = a.class_section_id
             LEFT JOIN classes c ON c.id = cs.class_id
             LEFT JOIN sections sec ON sec.id = cs.section_id
             ORDER BY a.created_at DESC, a.id DESC
             LIMIT ?",
            'i',
            [$limit]
        );
    }
}
