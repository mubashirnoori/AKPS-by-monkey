<?php

class AttendanceModel
{
    /**
     * Get all students CURRENTLY assigned to a class section,
     * with their attendance status for the given date.
     *
     * Only the student's latest assignment is considered.
     *
     * This prevents:
     * - Students appearing twice because of duplicate assignment rows
     * - Students appearing in an old class after being moved
     * - Students appearing in both their old and current class
     */
    public static function getStudentsWithStatus(
        int $classSectionId,
        string $attendanceDate,
        ?int $subjectId
    ): array {
        return Database::fetchAll(
            'SELECT
                s.id,
                s.admission_no,
                s.first_name,
                s.last_name,
                s.father_name,
                ar.status AS attendance_status
             FROM students s
             INNER JOIN student_class_assignments sca
                ON sca.id = (
                    SELECT sca2.id
                    FROM student_class_assignments sca2
                    WHERE sca2.student_id = s.id
                    ORDER BY sca2.assigned_at DESC, sca2.id DESC
                    LIMIT 1
                )
             LEFT JOIN attendance_records ar
                ON ar.student_id       = s.id
               AND ar.class_section_id = ?
               AND ar.attendance_date  = ?
               AND ar.subject_id <=> ?
             WHERE sca.class_section_id = ?
               AND IFNULL(s.status, 1) = 1
             ORDER BY s.first_name ASC, s.last_name ASC',
            'isii',
            [
                $classSectionId,
                $attendanceDate,
                $subjectId,
                $classSectionId
            ]
        );
    }

    /** Marks every currently-assigned student in a class as 'holiday' for one date (replacing whatever was there). */
    public static function markClassHoliday(int $classSectionId, string $attendanceDate, ?int $subjectId, ?int $createdByUserId): int
    {
        $studentIds = Database::fetchAll(
            'SELECT s.id FROM students s
             INNER JOIN student_class_assignments sca
                ON sca.id = (
                    SELECT sca2.id FROM student_class_assignments sca2
                    WHERE sca2.student_id = s.id
                    ORDER BY sca2.assigned_at DESC, sca2.id DESC LIMIT 1
                )
             WHERE sca.class_section_id = ?
               AND IFNULL(s.status, 1) = 1',
            'i',
            [$classSectionId]
        );
        $statusByStudentId = [];
        foreach ($studentIds as $row) {
            $statusByStudentId[(int)$row['id']] = 'holiday';
        }
        self::save($classSectionId, $attendanceDate, $subjectId, $statusByStudentId, $createdByUserId);
        return count($statusByStudentId);
    }

    /**
     * Save attendance for all students in a class for a given date.
     *
     * Uses DELETE followed by INSERT rather than
     * INSERT ... ON DUPLICATE KEY UPDATE.
     *
     * This is important because subject_id can be NULL.
     *
     * MySQL UNIQUE indexes allow multiple NULL values, so a normal
     * UNIQUE KEY does not reliably prevent duplicate whole-day
     * attendance records when subject_id IS NULL.
     *
     * The NULL-safe <=> operator ensures that NULL subject IDs
     * are correctly matched.
     */
    public static function save(
        int $classSectionId,
        string $attendanceDate,
        ?int $subjectId,
        array $statusByStudentId,
        ?int $createdByUserId
    ): void {
        if (empty($statusByStudentId)) {
            return;
        }

        $conn = Database::connection();

        $conn->begin_transaction();

        try {
            foreach ($statusByStudentId as $studentId => $status) {

                $studentId = (int) $studentId;
                $status = (string) $status;

                /*
                 * Validate student ID.
                 */
                if ($studentId <= 0) {
                    continue;
                }

                /*
                 * Validate attendance status.
                 */
                if (!in_array(
                    $status,
                    ['present', 'absent', 'late', 'excused', 'holiday'],
                    true
                )) {
                    continue;
                }

                /*
                 * Remove any existing attendance record(s)
                 * for this exact student/class/date/subject.
                 *
                 * <=> is NULL-safe, so this works for:
                 *
                 * subject_id = 5
                 *
                 * and also:
                 *
                 * subject_id IS NULL
                 */
                Database::execute(
                    'DELETE FROM attendance_records
                     WHERE student_id = ?
                       AND class_section_id = ?
                       AND subject_id <=> ?
                       AND attendance_date = ?',
                    'iiis',
                    [
                        $studentId,
                        $classSectionId,
                        $subjectId,
                        $attendanceDate
                    ]
                );

                /*
                 * Insert the new attendance record.
                 */
                Database::execute(
                    'INSERT INTO attendance_records
                        (
                            student_id,
                            class_section_id,
                            subject_id,
                            attendance_date,
                            status,
                            created_by_user_id
                        )
                     VALUES (?, ?, ?, ?, ?, ?)',
                    'iiissi',
                    [
                        $studentId,
                        $classSectionId,
                        $subjectId,
                        $attendanceDate,
                        $status,
                        $createdByUserId
                    ]
                );
            }

            /*
             * Everything succeeded.
             */
            $conn->commit();

        } catch (Throwable $e) {

            /*
             * Something failed.
             * Undo all changes from this save operation.
             */
            $conn->rollback();

            throw $e;
        }
    }
}