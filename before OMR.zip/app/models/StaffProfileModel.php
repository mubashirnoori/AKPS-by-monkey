<?php

class StaffProfileModel
{
    public static function listOptions(string $search = '', int $limit = 200, int $offset = 0): array
    {
        $search = trim($search);
        $like = '%' . $search . '%';
        return Database::fetchAll(
            'SELECT sp.id,
                    sp.full_name,
                    sp.title
             FROM staff_profiles sp
             WHERE (? = \'\' OR sp.full_name LIKE ?)
             ORDER BY sp.full_name
             LIMIT ? OFFSET ?',
            'ssii',
            [$search, $like, $limit, $offset]
        );
    }
}

