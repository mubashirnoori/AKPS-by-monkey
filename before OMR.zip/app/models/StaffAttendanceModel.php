<?php

class StaffAttendanceModel
{
    public static function listByDate(string $attendanceDate, string $search = '', int $limit = 200, int $offset = 0): array
    {
        $search = trim($search);
        $like = '%' . $search . '%';
        return Database::fetchAll(
            'SELECT sp.id AS staff_profile_id,
                    sp.full_name,
                    sp.title,
                    sar.status AS attendance_status
             FROM staff_profiles sp
             LEFT JOIN staff_attendance_records sar
               ON sar.staff_profile_id = sp.id
              AND sar.attendance_date = ?
             WHERE (? = \'\' OR sp.full_name LIKE ?)
             ORDER BY sp.full_name
             LIMIT ? OFFSET ?',
            'sssii',
            [$attendanceDate, $search, $like, $limit, $offset]
        );
    }

    public static function save(string $attendanceDate, array $statusByStaffId, ?int $byUserId): void
    {
        $conn = Database::connection();
        $conn->begin_transaction();
        try {
            foreach ($statusByStaffId as $staffId => $status) {
                $staffId = (int)$staffId;
                $status = (string)$status;
                if ($staffId <= 0) {
                    continue;
                }
                if (!in_array($status, ['present', 'absent', 'late', 'excused', 'holiday'], true)) {
                    $status = 'present';
                }
                Database::execute(
                    'INSERT INTO staff_attendance_records (staff_profile_id, attendance_date, status, created_by_user_id)
                     VALUES (?, ?, ?, ?)
                     ON DUPLICATE KEY UPDATE status = VALUES(status), created_by_user_id = VALUES(created_by_user_id)',
                    'issi',
                    [$staffId, $attendanceDate, $status, $byUserId]
                );
            }
            $conn->commit();
        } catch (Throwable $e) {
            $conn->rollback();
            throw $e;
        }
    }

    /** Marks every staff member currently listed for this date's search as 'holiday' (replacing whatever was there). */
    public static function markAllHoliday(string $attendanceDate, string $search, ?int $byUserId): int
    {
        $rows = self::listByDate($attendanceDate, $search, 2000, 0);
        $statusByStaffId = [];
        foreach ($rows as $r) {
            $statusByStaffId[(int)$r['staff_profile_id']] = 'holiday';
        }
        self::save($attendanceDate, $statusByStaffId, $byUserId);
        return count($statusByStaffId);
    }
}

