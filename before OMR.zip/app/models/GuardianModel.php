<?php

class GuardianModel
{
    public static function listByStudent(int $studentId): array
    {
        return Database::fetchAll(
            'SELECT g.*
             FROM guardians g
             JOIN student_guardians sg ON sg.guardian_id = g.id
             WHERE sg.student_id = ?
             ORDER BY sg.is_primary DESC, g.full_name',
            'i',
            [$studentId]
        );
    }

    /**
     * Batch version of listByStudent() for list/report pages that show many
     * students at once (e.g. the attendance report's "Send via WhatsApp"
     * column) — one query instead of one-per-row. Returns
     * [student_id => [guardian rows...]], same row shape and ordering
     * (primary guardian first) as listByStudent().
     *
     * @param int[] $studentIds
     * @return array<int, array<int, array>>
     */
    public static function listByStudents(array $studentIds): array
    {
        $studentIds = array_values(array_unique(array_map('intval', $studentIds)));
        if (empty($studentIds)) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($studentIds), '?'));
        $rows = Database::fetchAll(
            "SELECT g.*, sg.student_id AS __student_id
             FROM guardians g
             JOIN student_guardians sg ON sg.guardian_id = g.id
             WHERE sg.student_id IN ($placeholders)
             ORDER BY sg.is_primary DESC, g.full_name",
            str_repeat('i', count($studentIds)),
            $studentIds
        );
        $byStudent = [];
        foreach ($rows as $row) {
            $sid = (int)$row['__student_id'];
            unset($row['__student_id']);
            $byStudent[$sid][] = $row;
        }
        return $byStudent;
    }

    public static function addAndLink(
        int $studentId,
        array $guardian,
        bool $isPrimary = false
    ): int {
        $fullName = trim((string)($guardian['full_name'] ?? ''));
        if ($fullName === '') {
            return 0;
        }

        $phone = trim((string)($guardian['phone'] ?? ''));
        $email = trim((string)($guardian['email'] ?? ''));
        $relation = trim((string)($guardian['relation'] ?? ''));

        $existingId = null;

        // Only auto-merge when BOTH phone and email match an existing record.
        // Matching on a single field (phone OR email alone) is too weak — two
        // unrelated guardians can end up with the same phone number on file
        // (typo, shared landline, reused contact number) and that used to be
        // enough to silently fuse them into one guardian row and overwrite
        // their name. Requiring both fields to match makes an accidental
        // collision extremely unlikely, while still catching true duplicates
        // (e.g. re-adding the same parent for a sibling with identical
        // contact details typed in again).
        if ($email !== '' && $phone !== '') {
            $row = Database::fetchOne(
                'SELECT id FROM guardians WHERE email = ? AND phone = ? LIMIT 1',
                'ss',
                [$email, $phone]
            );
            $existingId = $row ? (int)$row['id'] : null;
        }

        $guardianId = null;
        if ($existingId) {
            Database::execute(
                'UPDATE guardians
                 SET full_name = ?, relation = ?, phone = ?, email = ?
                 WHERE id = ?',
                'ssssi',
                [$fullName, $relation ?: null, $phone ?: null, $email ?: null, $existingId]
            );
            $guardianId = $existingId;
        } else {
            Database::execute(
                'INSERT INTO guardians (user_id, full_name, relation, phone, email, address)
                 VALUES (NULL, ?, ?, ?, ?, ?)',
                'sssss',
                [
                    $fullName,
                    $relation ?: null,
                    $phone ?: null,
                    $email ?: null,
                    (string)($guardian['address'] ?? '')
                ]
            );
            $guardianId = (int)Database::lastInsertId();
            // Database::execute returns affected_rows; we need insert_id differently.
        }

        if (!$guardianId) {
            // Fallback: fetch id by unique matching
            if ($email !== '') {
                $row = Database::fetchOne('SELECT id FROM guardians WHERE email = ? LIMIT 1', 's', [$email]);
                $guardianId = $row ? (int)$row['id'] : null;
            } elseif ($phone !== '') {
                $row = Database::fetchOne('SELECT id FROM guardians WHERE phone = ? LIMIT 1', 's', [$phone]);
                $guardianId = $row ? (int)$row['id'] : null;
            }
        }

        if (!$guardianId) {
            throw new RuntimeException('Failed to resolve guardian id.');
        }

        Database::execute(
            'INSERT INTO student_guardians (student_id, guardian_id, is_primary)
             VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE is_primary = VALUES(is_primary)',
            'iii',
            [$studentId, $guardianId, $isPrimary ? 1 : 0]
        );

        return $guardianId;
    }

    /**
     * Link an already-existing guardian record to another student — used by
     * the "Link Existing Guardian" picker so siblings can share one guardian
     * row (and therefore one parent login) instead of getting a fresh
     * guardian record each time, which is what addAndLink() does whenever
     * the phone/email typed in doesn't exactly match what's on file.
     */
    public static function linkExisting(int $studentId, int $guardianId, bool $isPrimary = false): void
    {
        Database::execute(
            'INSERT INTO student_guardians (student_id, guardian_id, is_primary)
             VALUES (?, ?, ?)
             ON DUPLICATE KEY UPDATE is_primary = VALUES(is_primary)',
            'iii',
            [$studentId, $guardianId, $isPrimary ? 1 : 0]
        );
    }

    public static function removeLink(int $studentId, int $guardianId): void
    {
        Database::execute(
            'DELETE FROM student_guardians WHERE student_id = ? AND guardian_id = ?',
            'ii',
            [$studentId, $guardianId]
        );
    }

    /**
     * Used when linking a Parent-role login: find the student's existing
     * primary guardian, or — since most students already have a Father's
     * Name on file even without a separate guardian record — auto-create
     * one from that instead of forcing the admin to hunt through a
     * disconnected guardians list.
     */
    public static function resolvePrimaryOrCreateFromFather(int $studentId): int
    {
        $existing = Database::fetchOne(
            'SELECT guardian_id FROM student_guardians WHERE student_id = ? ORDER BY is_primary DESC, guardian_id LIMIT 1',
            'i',
            [$studentId]
        );
        if ($existing) {
            return (int)$existing['guardian_id'];
        }

        $student = Database::fetchOne(
            'SELECT first_name, last_name, father_name FROM students WHERE id = ?',
            'i',
            [$studentId]
        );
        if (!$student) {
            throw new RuntimeException('Student not found');
        }

        $fatherName = trim((string)($student['father_name'] ?? ''));
        $studentName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
        $fullName = $fatherName !== '' ? $fatherName : ('Parent of ' . $studentName);

        self::addAndLink($studentId, ['full_name' => $fullName, 'relation' => 'Father'], true);

        $row = Database::fetchOne(
            'SELECT guardian_id FROM student_guardians WHERE student_id = ? ORDER BY is_primary DESC, guardian_id LIMIT 1',
            'i',
            [$studentId]
        );
        if (!$row) {
            throw new RuntimeException('Failed to create guardian record');
        }
        return (int)$row['guardian_id'];
    }

    /**
     * The single student a guardian is (primarily) attached to, if any —
     * used to pre-fill the "search student" picker when editing a login
     * that's already linked to a guardian.
     */
    public static function primaryStudentForGuardian(int $guardianId): ?array
    {
        return Database::fetchOne(
            'SELECT s.id, s.first_name, s.last_name, s.admission_no
             FROM student_guardians sg
             JOIN students s ON s.id = sg.student_id
             WHERE sg.guardian_id = ?
             ORDER BY sg.is_primary DESC, s.id
             LIMIT 1',
            'i',
            [$guardianId]
        );
    }
}

