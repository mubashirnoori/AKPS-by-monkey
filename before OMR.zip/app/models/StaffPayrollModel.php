<?php

class StaffPayrollModel
{
    public static function listSalaryDetails(int $month, int $year, string $search = ''): array
    {
        $search = trim($search);
        $like = '%' . $search . '%';

        return Database::fetchAll(
            'SELECT sd.*,
                    sp.full_name,
                    sp.title
             FROM staff_salary_details sd
             JOIN staff_profiles sp ON sp.id = sd.staff_profile_id
             WHERE sd.salary_month = ?
               AND sd.salary_year = ?
               AND (? = "" OR sp.full_name LIKE ?)
             ORDER BY sp.full_name
             LIMIT 200',
            'iiss',
            [$month, $year, $search, $like]
        );
    }

    /**
     * Create OR update a salary detail for a given staff+month+year.
     * Returns the salary_detail id.
     */
    public static function createSalaryDetail(
        int $staffProfileId,
        int $month,
        int $year,
        float $grossAmount,
        float $deductions,
        float $netAmount,
        ?int $createdByUserId,
        string $salaryCreatedDate
    ): int {
        // Check if already exists for this staff+month+year
        $existing = Database::fetchOne(
            'SELECT id FROM staff_salary_details
             WHERE staff_profile_id = ? AND salary_month = ? AND salary_year = ?',
            'iii',
            [$staffProfileId, $month, $year]
        );

        if ($existing) {
            // Update existing — but only amounts, not payment history
            Database::execute(
                'UPDATE staff_salary_details
                 SET gross_amount = ?,
                     deductions = ?,
                     net_amount = ?,
                     salary_created_date = ?,
                     created_by_user_id = ?
                 WHERE id = ?',
                'dddsii',
                [$grossAmount, $deductions, $netAmount, $salaryCreatedDate, $createdByUserId, (int)$existing['id']]
            );
            return (int)$existing['id'];
        }

        // Insert new
        Database::execute(
            'INSERT INTO staff_salary_details
             (staff_profile_id, salary_month, salary_year, gross_amount, deductions, net_amount, created_by_user_id, salary_created_date)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            'iiidddis',
            [$staffProfileId, $month, $year, $grossAmount, $deductions, $netAmount, $createdByUserId, $salaryCreatedDate]
        );
        return (int)Database::lastInsertId();
    }

    /**
     * Get all payment records for a salary detail (full history)
     */
    public static function getPayments(int $salaryDetailId): array
    {
        return Database::fetchAll(
            'SELECT ssp.*,
                    u.username AS paid_by_name
             FROM staff_salary_payments ssp
             LEFT JOIN users u ON u.id = ssp.created_by
             WHERE ssp.staff_salary_detail_id = ?
             ORDER BY ssp.paid_date DESC, ssp.id DESC',
            'i',
            [$salaryDetailId]
        );
    }

    /**
     * Get total paid amount for a salary detail
     */
    public static function getTotalPaid(int $salaryDetailId): float
    {
        $row = Database::fetchOne(
            'SELECT COALESCE(SUM(amount), 0) AS paid
             FROM staff_salary_payments
             WHERE staff_salary_detail_id = ?',
            'i',
            [$salaryDetailId]
        );
        return (float)($row['paid'] ?? 0);
    }

    /**
     * Record a salary payment — always inserts a new row (never overwrites)
     */
    public static function recordPayment(
        int $salaryDetailId,
        float $amount,
        string $method,
        string $note,
        int $byUserId,
        string $paidDate
    ): void {
        Database::execute(
            'INSERT INTO staff_salary_payments
             (staff_salary_detail_id, amount, paid_date, method, note, created_by, created_at)
             VALUES (?, ?, ?, ?, ?, ?, NOW())',
            'idsssi',
            [$salaryDetailId, $amount, $paidDate, $method, $note, $byUserId]
        );
    }

    /**
     * Recent salary records for one staff member's own portal view (most recent first).
     * Used for the compact "My Salary" summary card — callers wanting the full
     * history should use listSalaryHistoryForStaff() with pagination instead.
     */
    public static function recentSalaryForStaff(int $staffProfileId, int $limit = 3): array
    {
        $rows = Database::fetchAll(
            'SELECT sd.*
             FROM staff_salary_details sd
             WHERE sd.staff_profile_id = ?
             ORDER BY sd.salary_year DESC, sd.salary_month DESC
             LIMIT ?',
            'ii',
            [$staffProfileId, $limit]
        );
        foreach ($rows as &$r) {
            $r['total_paid'] = self::getTotalPaid((int)$r['id']);
        }
        unset($r);
        return $rows;
    }

    /** Total count of salary records for one staff member (for "View all N" links / pagination). */
    public static function countSalaryForStaff(int $staffProfileId): int
    {
        $row = Database::fetchOne(
            'SELECT COUNT(*) AS cnt FROM staff_salary_details WHERE staff_profile_id = ?',
            'i',
            [$staffProfileId]
        );
        return (int)($row['cnt'] ?? 0);
    }

    /** Full, paginated salary history for one staff member's own portal view. */
    public static function listSalaryHistoryForStaff(int $staffProfileId, int $perPage = 20, int $offset = 0): array
    {
        $rows = Database::fetchAll(
            'SELECT sd.*
             FROM staff_salary_details sd
             WHERE sd.staff_profile_id = ?
             ORDER BY sd.salary_year DESC, sd.salary_month DESC
             LIMIT ? OFFSET ?',
            'iii',
            [$staffProfileId, $perPage, $offset]
        );
        foreach ($rows as &$r) {
            $r['total_paid'] = self::getTotalPaid((int)$r['id']);
        }
        unset($r);
        return $rows;
    }

    /** One salary detail row, only if it belongs to the given staff member (ownership check). */
    public static function getSalaryDetailForStaff(int $salaryDetailId, int $staffProfileId): ?array
    {
        $row = Database::fetchOne(
            'SELECT sd.*
             FROM staff_salary_details sd
             WHERE sd.id = ? AND sd.staff_profile_id = ?',
            'ii',
            [$salaryDetailId, $staffProfileId]
        );
        return $row ?: null;
    }

    /**
     * Every staff member for a month, with their salary record (if any) and totals paid.
     * Staff without a record for the month come back with detail_id = NULL ("not generated").
     */
    public static function listPayroll(int $month, int $year, string $search = ''): array
    {
        $search = trim($search);
        $like = '%' . $search . '%';

        return Database::fetchAll(
            'SELECT sp.id AS staff_profile_id, sp.full_name, sp.title, sp.basic_salary,
                    sd.id AS detail_id, sd.gross_amount, sd.deductions, sd.net_amount, sd.salary_created_date,
                    COALESCE(pay.paid, 0) AS total_paid, pay.last_paid
             FROM staff_profiles sp
             LEFT JOIN staff_salary_details sd
                    ON sd.staff_profile_id = sp.id AND sd.salary_month = ? AND sd.salary_year = ?
             LEFT JOIN (SELECT staff_salary_detail_id, SUM(amount) AS paid, MAX(paid_date) AS last_paid
                        FROM staff_salary_payments GROUP BY staff_salary_detail_id) pay
                    ON pay.staff_salary_detail_id = sd.id
             WHERE (? = "" OR sp.full_name LIKE ?)
             ORDER BY sp.full_name
             LIMIT 500',
            'iiss',
            [$month, $year, $search, $like]
        );
    }

    /** Payment rows for many salary details at once, keyed by salary detail id. */
    public static function paymentsForDetails(array $detailIds): array
    {
        $detailIds = array_values(array_filter(array_map('intval', $detailIds)));
        if (!$detailIds) {
            return [];
        }
        $rows = Database::fetchAll(
            'SELECT ssp.staff_salary_detail_id, ssp.amount, ssp.paid_date, ssp.method, ssp.note, ssp.created_at
             FROM staff_salary_payments ssp
             WHERE ssp.staff_salary_detail_id IN (' . implode(',', array_fill(0, count($detailIds), '?')) . ')
             ORDER BY ssp.paid_date DESC, ssp.id DESC',
            str_repeat('i', count($detailIds)),
            $detailIds
        );
        $out = [];
        foreach ($rows as $r) {
            $out[(int)$r['staff_salary_detail_id']][] = $r;
        }
        return $out;
    }

    /** Per-month totals for one year: staff with a record, net, paid, and how many are fully paid. */
    public static function yearOverview(int $year): array
    {
        $rows = Database::fetchAll(
            'SELECT sd.salary_month,
                    COUNT(*) AS staff_count,
                    SUM(sd.net_amount) AS net_total,
                    SUM(COALESCE(pay.paid, 0)) AS paid_total,
                    SUM(CASE WHEN COALESCE(pay.paid, 0) >= sd.net_amount THEN 1 ELSE 0 END) AS paid_count
             FROM staff_salary_details sd
             LEFT JOIN (SELECT staff_salary_detail_id, SUM(amount) AS paid
                        FROM staff_salary_payments GROUP BY staff_salary_detail_id) pay
                    ON pay.staff_salary_detail_id = sd.id
             WHERE sd.salary_year = ?
             GROUP BY sd.salary_month',
            'i',
            [$year]
        );
        $out = [];
        foreach ($rows as $r) {
            $out[(int)$r['salary_month']] = $r;
        }
        return $out;
    }

    /**
     * Create salary records for every staff member who has none for this month.
     * Amounts are copied from their most recent earlier record, else from their basic salary.
     * Staff with neither are skipped. Returns [created, skipped].
     */
    public static function generateForMonth(int $month, int $year, ?int $createdByUserId, string $salaryDate): array
    {
        $missing = Database::fetchAll(
            'SELECT sp.id, sp.basic_salary
             FROM staff_profiles sp
             WHERE NOT EXISTS (SELECT 1 FROM staff_salary_details sd
                               WHERE sd.staff_profile_id = sp.id AND sd.salary_month = ? AND sd.salary_year = ?)',
            'ii',
            [$month, $year]
        );

        $created = 0;
        $skipped = 0;
        foreach ($missing as $st) {
            $prev = Database::fetchOne(
                'SELECT gross_amount, deductions FROM staff_salary_details
                 WHERE staff_profile_id = ? AND (salary_year * 12 + salary_month) < ?
                 ORDER BY salary_year DESC, salary_month DESC LIMIT 1',
                'ii',
                [(int)$st['id'], $year * 12 + $month]
            );
            if ($prev && (float)$prev['gross_amount'] > 0) {
                $gross = (float)$prev['gross_amount'];
                $deductions = (float)$prev['deductions'];
            } elseif ((float)$st['basic_salary'] > 0) {
                $gross = (float)$st['basic_salary'];
                $deductions = 0.0;
            } else {
                $skipped++;
                continue;
            }
            self::createSalaryDetail((int)$st['id'], $month, $year, $gross, $deductions, $gross - $deductions, $createdByUserId, $salaryDate);
            $created++;
        }
        return [$created, $skipped];
    }
}
