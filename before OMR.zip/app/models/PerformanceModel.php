<?php

class PerformanceModel
{
    public static function list(string $search = '', int $limit = 200, int $offset = 0): array
    {
        $search = trim($search);
        $like = '%' . $search . '%';
        return Database::fetchAll(
            'SELECT pr.*,
                    sp.full_name,
                    sp.title
             FROM performance_reports pr
             JOIN staff_profiles sp ON sp.id = pr.staff_profile_id
             WHERE (? = \'\' OR sp.full_name LIKE ?)
             ORDER BY pr.id DESC
             LIMIT ? OFFSET ?',
            'ssii',
            [$search, $like, $limit, $offset]
        );
    }

    public static function create(array $data, ?int $createdByUserId): int
    {
        Database::execute(
            'INSERT INTO performance_reports (staff_profile_id, period_start, period_end, rating, summary, created_by_user_id)
             VALUES (?, ?, ?, ?, ?, ?)',
            'issisi',
            [
                (int)$data['staff_profile_id'],
                trim((string)($data['period_start'] ?? '')) ?: null,
                trim((string)($data['period_end'] ?? '')) ?: null,
                (int)($data['rating'] ?? 0) ?: null,
                trim((string)($data['summary'] ?? '')),
                $createdByUserId
            ]
        );
        return (int)Database::lastInsertId();
    }

    // ------------------------------------------------------------------
    // Monthly scorecard
    //
    // One report per staff member per month. Each indicator is scored 1-5 by the
    // admin (or marked N/A when it does not apply to that person). Most indicators
    // come with "evidence" pulled from what the staff member actually did in the
    // portal that month, so the admin scores from facts instead of memory.
    // ------------------------------------------------------------------

    /** key => [label, what it measures]. Order is the order shown on the form. */
    public const INDICATORS = [
        'own_attendance'     => ['Own attendance',            'Days present at school (excused leave is not counted against them).'],
        'punctuality'        => ['Punctuality',               'Arriving on time: late days in the month.'],
        'student_attendance' => ['Daily student attendance',  'Submits the class attendance on the portal every working day.'],
        'marks_entry'        => ['Marks entry',               'Enters and submits marks for each assessment on time.'],
        'portal_activity'    => ['Daily portal activity',     'Uses the portal on the working days of the month.'],
        'fee_handover'       => ['Fee collection & handover', 'Records fees correctly and hands cash to the Coordinator on time (only if assigned).'],
        'teaching'           => ['Teaching & classroom',      'Prepares lessons, gives and checks classwork/homework, keeps order. Judged by visits, not the portal.'],
        'conduct'            => ['Conduct & teamwork',        'Follows instructions, reports concerns to the Vice Principal, follows leave procedure, deals well with parents.'],
    ];

    public static function ensureTables(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        Database::execute(
            'CREATE TABLE IF NOT EXISTS performance_report_scores (
                id INT AUTO_INCREMENT PRIMARY KEY,
                report_id INT NOT NULL,
                indicator_key VARCHAR(40) NOT NULL,
                score TINYINT NULL,
                note VARCHAR(255) NULL,
                UNIQUE KEY uq_report_indicator (report_id, indicator_key),
                KEY idx_report (report_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
        );
        $done = true;
    }

    /** Working days of $ym (YYYY-MM) up to yesterday: not a Sunday, not a configured holiday. @return string[] Y-m-d */
    private static function workingDays(string $ym): array
    {
        $first = new DateTime($ym . '-01');
        $last = new DateTime($first->format('Y-m-t'));
        // Today is still in progress, so it is not counted against anyone.
        $yesterday = new DateTime(date('Y-m-d', strtotime('-1 day')));
        if ($last > $yesterday) {
            $last = $yesterday;
        }
        $row = Database::fetchOne("SELECT `value` FROM settings WHERE `key` = 'holidays'");
        $holidays = array_flip(array_map('trim', explode(',', (string)($row['value'] ?? ''))));
        $days = [];
        for ($d = clone $first; $d <= $last; $d->modify('+1 day')) {
            if ($d->format('w') !== '0' && !isset($holidays[$d->format('Y-m-d')])) {
                $days[] = $d->format('Y-m-d');
            }
        }
        return $days;
    }

    /** Suggested 1-5 from a 0..1 rate. */
    private static function scoreFromRate(float $rate): int
    {
        return $rate >= 0.95 ? 5 : ($rate >= 0.90 ? 4 : ($rate >= 0.80 ? 3 : ($rate >= 0.70 ? 2 : 1)));
    }

    /**
     * What the staff member did in $ym, per indicator, plus a day-by-day table.
     * suggested = a starting score the admin may change; na = the indicator probably
     * does not apply to this person (e.g. no fee class), so it starts as N/A.
     */
    public static function evidence(int $staffProfileId, string $ym): array
    {
        $staff = Database::fetchOne('SELECT id, user_id, full_name, title FROM staff_profiles WHERE id = ? LIMIT 1', 'i', [$staffProfileId]);
        if (!$staff) {
            return [];
        }
        $uid = (int)($staff['user_id'] ?? 0);
        $from = $ym . '-01';
        $to = date('Y-m-t', strtotime($from));
        $work = self::workingDays($ym);
        $workSet = array_flip($work);
        $nWork = count($work);

        // --- own attendance
        $own = [];
        foreach (Database::fetchAll(
            'SELECT attendance_date, status FROM staff_attendance_records WHERE staff_profile_id = ? AND attendance_date BETWEEN ? AND ?',
            'iss', [$staffProfileId, $from, $to]
        ) as $r) {
            $own[$r['attendance_date']] = $r['status'];
        }
        $cnt = ['present' => 0, 'late' => 0, 'absent' => 0, 'excused' => 0];
        foreach ($own as $d => $st) {
            if (isset($workSet[$d]) && isset($cnt[$st])) {
                $cnt[$st]++;
            }
        }
        $counted = $cnt['present'] + $cnt['late'] + $cnt['absent'];
        $recorded = $counted + $cnt['excused'];
        // Staff attendance is only a fair measure if it was actually taken on most days;
        // days nobody recorded are unknown, not absences.
        $coverageOk = $nWork > 0 && $recorded / $nWork >= 0.6;
        $ind = [];
        $ownText = sprintf('Present %d · Late %d · Absent %d · Excused %d', $cnt['present'], $cnt['late'], $cnt['absent'], $cnt['excused']);
        $cover = sprintf(' Attendance was recorded on %d of %d working days.', $recorded, $nWork);
        if (!$coverageOk) {
            $cover .= ' Too many days are missing to score this fairly: record staff attendance daily, or score by judgement.';
        }
        $ind['own_attendance'] = ['evidence' => $ownText . '.' . $cover,
            'suggested' => ($coverageOk && $counted) ? self::scoreFromRate(($cnt['present'] + $cnt['late']) / $counted) : null, 'na' => false];
        $late = $cnt['late'];
        $ind['punctuality'] = ['evidence' => ($late === 0 ? 'No late arrivals' : $late . ' late day' . ($late === 1 ? '' : 's')) . ' among the days recorded.' . ($coverageOk ? '' : ' Attendance is missing for many days.'),
            'suggested' => ($coverageOk && $counted) ? ($late === 0 ? 5 : ($late === 1 ? 4 : ($late === 2 ? 3 : ($late <= 4 ? 2 : 1)))) : null, 'na' => false];

        // --- activity by this user
        $att = $marks = $fees = $active = [];
        $isTeaching = false;
        $usesPortal = false;
        if ($uid > 0) {
            foreach (Database::fetchAll(
                "SELECT attendance_date d, COUNT(DISTINCT class_section_id) classes FROM attendance_records
                 WHERE created_by_user_id = ? AND attendance_date BETWEEN ? AND ? AND status <> 'holiday' GROUP BY attendance_date",
                'iss', [$uid, $from, $to]) as $r) {
                $att[$r['d']] = (int)$r['classes'];
            }
            foreach (Database::fetchAll(
                'SELECT DATE(entered_at) d, COUNT(*) n, COUNT(DISTINCT exam_id) exams FROM marks
                 WHERE entered_by_user_id = ? AND DATE(entered_at) BETWEEN ? AND ? GROUP BY DATE(entered_at)',
                'iss', [$uid, $from, $to]) as $r) {
                $marks[$r['d']] = (int)$r['n'];
            }
            foreach (Database::fetchAll(
                'SELECT DATE(collected_at) d, COUNT(*) n, SUM(amount) amt FROM fee_collections
                 WHERE collected_by_user_id = ? AND DATE(collected_at) BETWEEN ? AND ? GROUP BY DATE(collected_at)',
                'iss', [$uid, $from, $to]) as $r) {
                $fees[$r['d']] = ['n' => (int)$r['n'], 'amt' => (float)$r['amt']];
            }
            foreach (Database::fetchAll(
                "SELECT DISTINCT DATE(created_at) d FROM activity_log WHERE user_id = ? AND action <> 'auth.login_failed' AND DATE(created_at) BETWEEN ? AND ?",
                'iss', [$uid, $from, $to]) as $r) {
                $active[$r['d']] = true;
            }
            $ever = Database::fetchOne('SELECT COUNT(*) c FROM attendance_records WHERE created_by_user_id = ?', 'i', [$uid]);
            $isTeaching = (int)($ever['c'] ?? 0) > 0;
            $any = Database::fetchOne("SELECT COUNT(*) c FROM activity_log WHERE user_id = ? AND action <> 'auth.login_failed'", 'i', [$uid]);
            $usesPortal = (int)($any['c'] ?? 0) > 0;
        }
        $subj = Database::fetchOne('SELECT COUNT(*) c FROM staff_subject_assignments WHERE staff_profile_id = ?', 'i', [$staffProfileId]);
        $isTeaching = $isTeaching || (int)($subj['c'] ?? 0) > 0;

        // student attendance
        $submitted = array_values(array_filter(array_keys($att), fn($d) => isset($workSet[$d])));
        $missed = array_values(array_diff($work, $submitted));
        $txt = sprintf('Submitted student attendance on %d of %d working days.', count($submitted), $nWork);
        if ($missed && count($missed) <= 8) {
            $txt .= ' Missed: ' . implode(', ', array_map(fn($d) => date('j M', strtotime($d)), $missed)) . '.';
        }
        $ind['student_attendance'] = ['evidence' => $txt, 'suggested' => ($nWork && $isTeaching) ? self::scoreFromRate(count($submitted) / $nWork) : null, 'na' => !$isTeaching];

        // marks
        $mrow = $uid > 0 ? Database::fetchOne(
            'SELECT COUNT(*) n, COUNT(DISTINCT exam_id) exams FROM marks WHERE entered_by_user_id = ? AND DATE(entered_at) BETWEEN ? AND ?',
            'iss', [$uid, $from, $to]) : ['n' => 0, 'exams' => 0];
        $ind['marks_entry'] = ['evidence' => (int)$mrow['n'] > 0
            ? sprintf('%d marks entered for %d exam(s) on %d day(s).', $mrow['n'], $mrow['exams'], count($marks))
            : 'No marks entered this month.', 'suggested' => null, 'na' => !$isTeaching];

        // portal activity
        $activeWork = count(array_filter(array_keys($active), fn($d) => isset($workSet[$d])));
        $ind['portal_activity'] = ['evidence' => sprintf('Active on the portal on %d of %d working days.', $activeWork, $nWork),
            'suggested' => ($nWork && $usesPortal) ? ($activeWork / $nWork >= 0.90 ? 5 : ($activeWork / $nWork >= 0.75 ? 4 : ($activeWork / $nWork >= 0.60 ? 3 : ($activeWork / $nWork >= 0.40 ? 2 : 1)))) : null, 'na' => !$usesPortal];

        // fees
        require_once __DIR__ . '/FeeHandoverModel.php';
        $led = FeeHandoverModel::ledgerForStaff($staffProfileId);
        $hand = Database::fetchOne(
            "SELECT COALESCE(SUM(amount),0) a FROM fee_handovers WHERE staff_profile_id = ? AND status = 'confirmed' AND DATE(confirmed_at) BETWEEN ? AND ?",
            'iss', [$staffProfileId, $from, $to]);
        $monthFee = array_sum(array_column($fees, 'amt'));
        $monthRcpt = array_sum(array_column($fees, 'n'));
        $hasFee = Database::fetchOne('SELECT COUNT(*) c FROM staff_fee_classes WHERE staff_profile_id = ?', 'i', [$staffProfileId]);
        $feeApplies = (int)($hasFee['c'] ?? 0) > 0 || $led['collected'] > 0;
        $ind['fee_handover'] = ['evidence' => sprintf('This month: collected Rs %s (%d receipts), handed over and confirmed Rs %s. Still holding Rs %s overall%s.',
            number_format($monthFee), $monthRcpt, number_format((float)$hand['a']), number_format($led['net_balance']),
            $led['pending_handover'] > 0 ? ' (Rs ' . number_format($led['pending_handover']) . ' awaiting confirmation)' : ''),
            'suggested' => null, 'na' => !$feeApplies];

        // manual indicators
        $lv = Database::fetchOne(
            "SELECT COUNT(*) n, SUM(status='approved') ok FROM leave_requests WHERE applicant_type='staff' AND staff_profile_id = ? AND from_date <= ? AND to_date >= ?",
            'iss', [$staffProfileId, $to, $from]);
        $ind['teaching'] = ['evidence' => 'Not tracked in the portal: score from classroom visits and what the Vice Principal reports.', 'suggested' => null, 'na' => (bool)preg_match('/boy|clean|helper|admin/i', (string)$staff['title'])];
        $ind['conduct'] = ['evidence' => 'Leave requests overlapping this month: ' . (int)$lv['n'] . ' (' . (int)$lv['ok'] . ' approved). Score the rest from what you observe.', 'suggested' => null, 'na' => false];

        // day-by-day table
        $days = [];
        $end = min($to, date('Y-m-d'));
        for ($d = new DateTime($from); $d->format('Y-m-d') <= $end; $d->modify('+1 day')) {
            $k = $d->format('Y-m-d');
            $days[] = [
                'date' => $k, 'dow' => $d->format('D'), 'off' => !isset($workSet[$k]),
                'own' => $own[$k] ?? null, 'classes' => $att[$k] ?? 0, 'marks' => $marks[$k] ?? 0,
                'fees' => $fees[$k]['n'] ?? 0, 'active' => isset($active[$k]),
            ];
        }
        return ['staff' => $staff, 'month' => $ym, 'indicators' => $ind, 'days' => $days];
    }

    /** Overall 0-100 and 1-5 rating from scores [key => ?int]. null when nothing was scored. */
    public static function overall(array $scores): ?array
    {
        $vals = array_filter($scores, fn($v) => $v !== null);
        if (!$vals) {
            return null;
        }
        $avg = array_sum($vals) / count($vals);
        return ['percent' => (int)round($avg / 5 * 100), 'rating' => max(1, min(5, (int)round($avg))), 'scored' => count($vals)];
    }

    /**
     * Save the month's scorecard. A staff member has one per month: saving again
     * replaces the earlier scores. $scores = [key => ['score' => ?int, 'note' => string]].
     * @return bool true if an existing report was updated
     */
    public static function saveMonthly(int $staffProfileId, string $ym, array $scores, string $summary, ?int $byUserId): bool
    {
        self::ensureTables();
        $from = $ym . '-01';
        $to = date('Y-m-t', strtotime($from));
        $clean = [];
        foreach (array_keys(self::INDICATORS) as $key) {
            $sc = $scores[$key]['score'] ?? null;
            $sc = ($sc === null || $sc === '') ? null : max(1, min(5, (int)$sc));
            $clean[$key] = ['score' => $sc, 'note' => mb_substr(trim((string)($scores[$key]['note'] ?? '')), 0, 255)];
        }
        $ov = self::overall(array_map(fn($c) => $c['score'], $clean));

        $existing = Database::fetchOne(
            'SELECT id FROM performance_reports WHERE staff_profile_id = ? AND period_start = ? ORDER BY id DESC LIMIT 1',
            'is', [$staffProfileId, $from]);
        if ($existing) {
            $id = (int)$existing['id'];
            Database::execute('UPDATE performance_reports SET period_end = ?, rating = ?, summary = ?, created_by_user_id = ? WHERE id = ?',
                'sisii', [$to, $ov['rating'] ?? null, $summary, $byUserId, $id]);
            Database::execute('DELETE FROM performance_report_scores WHERE report_id = ?', 'i', [$id]);
        } else {
            Database::execute('INSERT INTO performance_reports (staff_profile_id, period_start, period_end, rating, summary, created_by_user_id) VALUES (?, ?, ?, ?, ?, ?)',
                'issisi', [$staffProfileId, $from, $to, $ov['rating'] ?? null, $summary, $byUserId]);
            $id = (int)Database::lastInsertId();
        }
        foreach ($clean as $key => $c) {
            Database::execute('INSERT INTO performance_report_scores (report_id, indicator_key, score, note) VALUES (?, ?, ?, ?)',
                'isis', [$id, $key, $c['score'], $c['note'] !== '' ? $c['note'] : null]);
        }
        return (bool)$existing;
    }

    /** Delete a report and its indicator scores. */
    public static function delete(int $reportId): void
    {
        self::ensureTables();
        Database::execute('DELETE FROM performance_report_scores WHERE report_id = ?', 'i', [$reportId]);
        Database::execute('DELETE FROM performance_reports WHERE id = ?', 'i', [$reportId]);
    }

    /** Scores for a set of report ids: [report_id => [indicator_key => ['score','note']]]. */
    public static function scoresFor(array $reportIds): array
    {
        if (!$reportIds) {
            return [];
        }
        self::ensureTables();
        $in = implode(',', array_map('intval', $reportIds));
        $out = [];
        foreach (Database::fetchAll("SELECT report_id, indicator_key, score, note FROM performance_report_scores WHERE report_id IN ($in)") as $r) {
            $out[(int)$r['report_id']][$r['indicator_key']] = ['score' => $r['score'] === null ? null : (int)$r['score'], 'note' => (string)$r['note']];
        }
        return $out;
    }
}
