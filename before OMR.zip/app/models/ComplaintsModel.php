<?php

class ComplaintsModel
{
    public static function list(string $search, ?string $status, int $limit, int $offset): array
    {
        $search = trim($search);
        $searchLike = '%' . $search . '%';
        $statusVal = $status ? (string)$status : '';

        return Database::fetchAll(
            'SELECT c.*,
                    s.first_name AS student_first_name,
                    s.last_name AS student_last_name,
                    u.username AS submitted_by_username
             FROM complaints c
             LEFT JOIN students s ON s.id = c.student_id
             LEFT JOIN users u ON u.id = c.submitted_by_user_id
             WHERE ( ? = \'\' OR c.title LIKE ? OR c.complaint_text LIKE ? )
               AND ( ? = \'\' OR c.status = ? )
             ORDER BY c.id DESC
             LIMIT ? OFFSET ?',
            'sssssii',
            [
                $search,
                $searchLike,
                $searchLike,
                $statusVal,
                $statusVal,
                $limit,
                $offset
            ]
        );
    }

    public static function count(string $search, ?string $status): int
    {
        $search = trim($search);
        $searchLike = '%' . $search . '%';
        $statusVal = $status ? (string)$status : '';

        $row = Database::fetchOne(
            'SELECT COUNT(*) AS cnt
             FROM complaints c
             WHERE ( ? = \'\' OR c.title LIKE ? OR c.complaint_text LIKE ? )
               AND ( ? = \'\' OR c.status = ? )',
            'sssss',
            [$search, $searchLike, $searchLike, $statusVal, $statusVal]
        );

        return (int)($row['cnt'] ?? 0);
    }

    public static function create(array $data, ?int $submittedByUserId): int
    {
        Database::execute(
            'INSERT INTO complaints (student_id, submitted_by_user_id, title, complaint_text, status, resolution_text, resolved_at)
             VALUES (?, ?, ?, ?, ?, NULL, NULL)',
            'iisss',
            [
                $data['student_id'] ? (int)$data['student_id'] : null,
                $submittedByUserId,
                (string)$data['title'],
                (string)$data['complaint_text'],
                (string)($data['status'] ?? 'open')
            ]
        );

        return (int)Database::lastInsertId();
    }

    public static function resolve(int $complaintId, string $resolutionText, ?int $resolvedByUserId): void
    {
        Database::execute(
            'UPDATE complaints
             SET status = \'resolved\',
                 resolution_text = ?,
                 resolved_at = NOW(),
                 updated_at = NOW()
             WHERE id = ?',
            'si',
            [$resolutionText, $complaintId]
        );
    }
}

