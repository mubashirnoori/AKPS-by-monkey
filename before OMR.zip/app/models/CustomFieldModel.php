<?php

class CustomFieldModel
{
    public static function listByScope(string $scope): array
    {
        return Database::fetchAll(
            'SELECT * FROM custom_fields WHERE scope = ? ORDER BY id ASC',
            's',
            [$scope]
        );
    }

    public static function create(string $scope, array $data): void
    {
        Database::execute(
            'INSERT INTO custom_fields (scope, field_key, label_text, field_type, options_text, is_required)
             VALUES (?, ?, ?, ?, ?, ?)',
            'sssssi',
            [
                $scope,
                (string)$data['field_key'],
                (string)$data['label_text'],
                (string)$data['field_type'],
                (string)($data['options_text'] ?? ''),
                (int)($data['is_required'] ?? 0)
            ]
        );
    }

    public static function update(int $fieldId, array $data): void
    {
        Database::execute(
            'UPDATE custom_fields
             SET label_text = ?, field_type = ?, options_text = ?, is_required = ?
             WHERE id = ?',
            'ssssi',
            [
                (string)$data['label_text'],
                (string)$data['field_type'],
                (string)($data['options_text'] ?? ''),
                (int)($data['is_required'] ?? 0),
                $fieldId
            ]
        );
    }

    public static function delete(int $fieldId): void
    {
        Database::execute('DELETE FROM custom_fields WHERE id = ?', 'i', [$fieldId]);
    }

    public static function getValuesForStudent(int $studentId, string $scope = 'student'): array
    {
        return Database::fetchAll(
            'SELECT cf.field_key, cf.label_text, cf.field_type, cf.is_required, cf.options_text,
                    cfv.value_text
             FROM custom_fields cf
             LEFT JOIN custom_field_values cfv
               ON cfv.custom_field_id = cf.id
              AND cfv.student_id = ?
             WHERE cf.scope = ?
             ORDER BY cf.id ASC',
            'is',
            [$studentId, $scope]
        );
    }

    public static function saveValuesForStudent(int $studentId, array $valuesByFieldKey, string $scope = 'student'): void
    {
        // Persist by deleting then re-inserting to avoid duplicates.
        $fields = self::listByScope($scope);

        $conn = Database::connection();
        $conn->begin_transaction();
        try {
            foreach ($fields as $field) {
                $fieldId = (int)$field['id'];
                $fieldKey = (string)$field['field_key'];
                $value = isset($valuesByFieldKey[$fieldKey]) ? (string)$valuesByFieldKey[$fieldKey] : '';

                Database::execute(
                    'DELETE FROM custom_field_values
                     WHERE custom_field_id = ? AND student_id = ?',
                    'ii',
                    [$fieldId, $studentId]
                );

                Database::execute(
                    'INSERT INTO custom_field_values (custom_field_id, student_id, value_text, updated_at)
                     VALUES (?, ?, ?, NULL)',
                    'iis',
                    [$fieldId, $studentId, $value]
                );
            }
            $conn->commit();
        } catch (Throwable $e) {
            $conn->rollback();
            throw $e;
        }
    }
}

