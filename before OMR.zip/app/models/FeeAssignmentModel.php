<?php

class FeeAssignmentModel
{
    public static function create(array $data): int
    {
        $studentId = !empty($data['student_id']) ? (int)$data['student_id'] : null;
        $classSectionId = !empty($data['class_section_id']) ? (int)$data['class_section_id'] : null;
        $academicYearId = !empty($data['academic_year_id']) ? (int)$data['academic_year_id'] : null;

        Database::execute(
            'INSERT INTO fee_assignments
            (fee_category_id, academic_year_id, student_id, class_section_id, amount, description)
            VALUES (?, ?, ?, ?, ?, ?)',
            'iiiids',
            [
                (int)$data['fee_category_id'],
                $academicYearId,
                $studentId,
                $classSectionId,
                (float)($data['amount'] ?? 0),
                trim((string)($data['description'] ?? ''))
            ]
        );

        return (int)Database::lastInsertId();
    }

    public static function delete(int $id): void
    {
        Database::execute('DELETE FROM fee_assignments WHERE id = ?', 'i', [$id]);
    }

    public static function list(string $search = '', int $limit = 50, int $offset = 0): array
    {
        $search = trim($search);
        $like = '%' . $search . '%';
        return Database::fetchAll(
            "SELECT fa.*,
                    fc.name AS fee_category_name,
                    ay.academic_year_label,
                    CASE
                        WHEN fa.student_id IS NOT NULL
                            THEN CONCAT(s.first_name, ' ', s.last_name, ' (', s.admission_no, ')')
                        ELSE NULL
                    END AS student_name,
                    CASE
                        WHEN fa.class_section_id IS NOT NULL
                            THEN CONCAT(cl.name, ' - ', sec.name)
                        ELSE NULL
                    END AS class_section_name
             FROM fee_assignments fa
             JOIN fee_categories fc ON fc.id = fa.fee_category_id
             LEFT JOIN students s ON s.id = fa.student_id
             LEFT JOIN class_sections cs ON cs.id = fa.class_section_id
             LEFT JOIN classes cl ON cl.id = cs.class_id
             LEFT JOIN sections sec ON sec.id = cs.section_id
             LEFT JOIN academic_years ay ON ay.id = fa.academic_year_id
             WHERE (? = '' OR fc.name LIKE ?)
             ORDER BY fa.id DESC
             LIMIT ? OFFSET ?",
            'ssii',
            [$search, $like, $limit, $offset]
        );
    }

    /**
     * Resolve the amount to charge for one fee category against one student,
     * preferring the most specific assignment: a student-specific assignment
     * beats a class-wide one, which beats a global (all-students) one.
     * Returns null if no matching assignment exists at all.
     */
    public static function resolveAmountForCategory(int $feeCategoryId, int $studentId, int $classSectionId, ?int $academicYearId): ?float
    {
        $row = Database::fetchOne(
            'SELECT amount FROM fee_assignments
             WHERE fee_category_id = ? AND student_id = ?
               AND (academic_year_id = ? OR academic_year_id IS NULL)
             ORDER BY academic_year_id IS NULL, id DESC LIMIT 1',
            'iii',
            [$feeCategoryId, $studentId, $academicYearId]
        );
        if ($row) {
            return (float)$row['amount'];
        }

        if ($classSectionId > 0) {
            $row = Database::fetchOne(
                'SELECT amount FROM fee_assignments
                 WHERE fee_category_id = ? AND class_section_id = ?
                   AND (academic_year_id = ? OR academic_year_id IS NULL)
                 ORDER BY academic_year_id IS NULL, id DESC LIMIT 1',
                'iii',
                [$feeCategoryId, $classSectionId, $academicYearId]
            );
            if ($row) {
                return (float)$row['amount'];
            }
        }

        $row = Database::fetchOne(
            'SELECT amount FROM fee_assignments
             WHERE fee_category_id = ? AND student_id IS NULL AND class_section_id IS NULL
               AND (academic_year_id = ? OR academic_year_id IS NULL)
             ORDER BY academic_year_id IS NULL, id DESC LIMIT 1',
            'ii',
            [$feeCategoryId, $academicYearId]
        );
        return $row ? (float)$row['amount'] : null;
    }

    /**
     * The assignment to bill for one fee category: the most specific scope wins
     * (student-specific, then class-wide, then all-students), and within that scope
     * the MOST RECENT assignment (highest id) wins — so if a class's monthly fee was
     * changed from 275 to 2800, new invoices use 2800. A year-specific assignment is
     * preferred over a year-less one. $billingMonth is accepted for callers that pass
     * it but does not change the pick. Returns the assignment row, or null if none.
     */
    public static function pickAssignmentForCategory(
        int $feeCategoryId,
        int $studentId,
        int $classSectionId,
        ?int $academicYearId,
        ?int $billingMonth = null
    ): ?array {
        $row = Database::fetchOne(
            'SELECT * FROM fee_assignments
             WHERE fee_category_id = ? AND student_id = ?
               AND (academic_year_id <=> ? OR academic_year_id IS NULL)
             ORDER BY academic_year_id IS NULL, id DESC LIMIT 1',
            'iii',
            [$feeCategoryId, $studentId, $academicYearId]
        );
        if ($row) {
            return $row;
        }

        if ($classSectionId > 0) {
            $row = Database::fetchOne(
                'SELECT * FROM fee_assignments
                 WHERE fee_category_id = ? AND class_section_id = ? AND student_id IS NULL
                   AND (academic_year_id <=> ? OR academic_year_id IS NULL)
                 ORDER BY academic_year_id IS NULL, id DESC LIMIT 1',
                'iii',
                [$feeCategoryId, $classSectionId, $academicYearId]
            );
            if ($row) {
                return $row;
            }
        }

        $row = Database::fetchOne(
            'SELECT * FROM fee_assignments
             WHERE fee_category_id = ? AND student_id IS NULL AND class_section_id IS NULL
               AND (academic_year_id <=> ? OR academic_year_id IS NULL)
             ORDER BY academic_year_id IS NULL, id DESC LIMIT 1',
            'ii',
            [$feeCategoryId, $academicYearId]
        );
        return $row ?: null;
    }

    /**
     * Like resolveAmountForCategory(), but only looks at assignments carrying this label
     * (fee_assignments.description). The label is what tells several fees of ONE category
     * apart: "First Term Exam Fee" vs "Final Term Exam Fee", "Late Fee", ... An empty label
     * matches assignments that have no label. The most specific scope wins (student, then
     * class, then everyone); inside a scope a year-specific assignment beats a year-less
     * one, then the newest wins. Returns null if there is no matching assignment.
     */
    public static function resolveAmountForLabel(
        int $feeCategoryId,
        int $studentId,
        int $classSectionId,
        ?int $academicYearId,
        string $label
    ): ?float {
        $label = trim($label);
        // Compared in SQL on both sides, so letter case never matters (and PHP/SQL can't disagree).
        $match = "fee_category_id = ? AND LOWER(TRIM(COALESCE(description, ''))) = LOWER(?)
                  AND (academic_year_id <=> ? OR academic_year_id IS NULL)
                  ORDER BY academic_year_id IS NULL, id DESC LIMIT 1";

        $row = Database::fetchOne(
            "SELECT amount FROM fee_assignments WHERE student_id = ? AND $match",
            'iisi',
            [$studentId, $feeCategoryId, $label, $academicYearId]
        );
        if (!$row && $classSectionId > 0) {
            $row = Database::fetchOne(
                "SELECT amount FROM fee_assignments WHERE class_section_id = ? AND student_id IS NULL AND $match",
                'iisi',
                [$classSectionId, $feeCategoryId, $label, $academicYearId]
            );
        }
        if (!$row) {
            $row = Database::fetchOne(
                "SELECT amount FROM fee_assignments WHERE student_id IS NULL AND class_section_id IS NULL AND $match",
                'isi',
                [$feeCategoryId, $label, $academicYearId]
            );
        }
        return $row ? (float)$row['amount'] : null;
    }

    /**
     * One-time fees that can be applied from the Generate Invoices screen: one entry per
     * (class or everyone, fee, label) with the amount that would be charged. Student-specific
     * assignments are left out; they are picked up per student when the fee is applied.
     *
     * @return array<int,array{class_section_id:?int,fee_category_id:int,label:string,amount:float}>
     */
    public static function listOneTimeFeeOptions(?int $academicYearId): array
    {
        $rows = Database::fetchAll(
            "SELECT fa.fee_category_id, fa.class_section_id, fa.amount, TRIM(COALESCE(fa.description, '')) AS label
             FROM fee_assignments fa
             JOIN fee_categories fc ON fc.id = fa.fee_category_id
             WHERE fc.is_one_time = 1 AND fa.student_id IS NULL
               AND (fa.academic_year_id <=> ? OR fa.academic_year_id IS NULL)
             ORDER BY fa.academic_year_id IS NULL DESC, fa.id ASC",
            'i',
            [$academicYearId]
        );

        // Later rows overwrite earlier ones: year-specific beats year-less, newer beats older.
        $best = [];
        foreach ($rows as $r) {
            $key = (int)($r['class_section_id'] ?? 0) . '|' . (int)$r['fee_category_id'] . '|' . mb_strtolower((string)$r['label']);
            $best[$key] = [
                'class_section_id' => $r['class_section_id'] !== null ? (int)$r['class_section_id'] : null,
                'fee_category_id'  => (int)$r['fee_category_id'],
                'label'            => (string)$r['label'],
                'amount'           => (float)$r['amount'],
            ];
        }
        return array_values($best);
    }

    public static function getAssignmentsForStudent(int $studentId, ?int $academicYearId): array
    {
        require_once __DIR__ . '/StudentModel.php';

        $classSectionId = StudentModel::getCurrentClassSectionId($studentId);
        $classSectionId = $classSectionId ? (int)$classSectionId : 0;

        // Prefer the current academic year when none selected (avoids "0 invoices")
        if (!$academicYearId || $academicYearId <= 0) {
            require_once __DIR__ . '/AcademicYearModel.php';
            $currentYearId = AcademicYearModel::currentId();
            if ($currentYearId) {
                $academicYearId = $currentYearId;
            }
        }

        if ($academicYearId && $academicYearId > 0) {
            return Database::fetchAll(
                'SELECT fa.*, fc.name AS fee_category_name, fc.is_one_time
                 FROM fee_assignments fa
                 JOIN fee_categories fc ON fc.id = fa.fee_category_id
                 WHERE (fa.student_id = ?
                        OR (fa.class_section_id = ? AND ? > 0)
                        OR (fa.student_id IS NULL AND fa.class_section_id IS NULL))
                   AND (fa.academic_year_id = ? OR fa.academic_year_id IS NULL)
                 ORDER BY fc.name, fa.id',
                'iiii',
                [$studentId, $classSectionId, $classSectionId, $academicYearId]
            );
        }

        // No year configured: return all matching assignments (year-tagged or not)
        return Database::fetchAll(
            'SELECT fa.*, fc.name AS fee_category_name, fc.is_one_time
             FROM fee_assignments fa
             JOIN fee_categories fc ON fc.id = fa.fee_category_id
             WHERE (fa.student_id = ?
                    OR (fa.class_section_id = ? AND ? > 0)
                    OR (fa.student_id IS NULL AND fa.class_section_id IS NULL))
             ORDER BY fc.name, fa.id',
            'iii',
            [$studentId, $classSectionId, $classSectionId]
        );
    }
}
