<?php

class StaffSubjectAssignmentModel
{
    public static function getTeacherForSubject(int $subjectId): array
    {
        return Database::fetchAll(
            'SELECT ssa.id,
                    sp.id AS staff_profile_id,
                    sp.full_name,
                    sp.title
             FROM staff_subject_assignments ssa
             JOIN staff_profiles sp ON sp.id = ssa.staff_profile_id
             WHERE ssa.subject_id = ?
             ORDER BY sp.full_name',
            'i',
            [$subjectId]
        );
    }

    /**
     * subject_id => staff_profile_id for the first-assigned teacher of each subject,
     * so forms like Timetable can auto-fill Teacher once Subject is picked. Subjects
     * with no assignment, or with more than one teacher, are simply left out of the
     * map (caller falls back to "— Unassigned —" / manual pick).
     */
    public static function getPrimaryTeacherMapForSubjects(array $subjectIds): array
    {
        $subjectIds = array_values(array_unique(array_filter(array_map('intval', $subjectIds), fn($id) => $id > 0)));
        if (empty($subjectIds)) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($subjectIds), '?'));
        $rows = Database::fetchAll(
            "SELECT ssa.subject_id, ssa.staff_profile_id
             FROM staff_subject_assignments ssa
             WHERE ssa.subject_id IN ($placeholders)
             ORDER BY ssa.id ASC",
            str_repeat('i', count($subjectIds)),
            $subjectIds
        );
        $map = [];
        foreach ($rows as $row) {
            $sid = (int)$row['subject_id'];
            if (!isset($map[$sid])) {
                $map[$sid] = (int)$row['staff_profile_id'];
            }
        }
        return $map;
    }

    public static function assignTeacher(int $subjectId, int $staffProfileId): void
    {
        if ($subjectId <= 0 || $staffProfileId <= 0) {
            return;
        }
        Database::execute(
            'INSERT INTO staff_subject_assignments (staff_profile_id, subject_id, active_from, active_to)
             VALUES (?, ?, NULL, NULL)
             ON DUPLICATE KEY UPDATE staff_profile_id = VALUES(staff_profile_id)',
            'ii',
            [$staffProfileId, $subjectId]
        );
    }

    public static function unassignTeacher(int $subjectId, int $staffProfileId): void
    {
        Database::execute(
            'DELETE FROM staff_subject_assignments WHERE subject_id = ? AND staff_profile_id = ?',
            'ii',
            [$subjectId, $staffProfileId]
        );
    }
}