<?php

/**
 * Per-user notifications shown in the bell dropdown (web portal) and in the
 * mobile app. A notification always belongs to exactly one user_id — for
 * events that concern a group (e.g. "anyone who can approve leave"), the
 * caller fans the event out into one row per recipient at creation time
 * (see notifyByPermission()) rather than storing a group reference, so
 * read/unread state is always per-person and reads stay a simple indexed
 * lookup.
 */
class NotificationModel
{
    /** Create a single notification for one user. Returns the new row id. */
    public static function create(int $userId, string $type, string $title, ?string $message = null, ?string $link = null, ?int $announcementId = null): int
    {
        if ($userId <= 0 || $title === '') {
            return 0;
        }
        Database::execute(
            'INSERT INTO notifications (user_id, announcement_id, type, title, message, link) VALUES (?, ?, ?, ?, ?, ?)',
            'iissss',
            [$userId, $announcementId, $type, $title, $message, $link]
        );
        return (int)Database::lastInsertId();
    }

    /** Create the same notification for a list of user ids (duplicates in the list are ignored). */
    public static function notifyUsers(array $userIds, string $type, string $title, ?string $message = null, ?string $link = null): void
    {
        $seen = [];
        foreach ($userIds as $uid) {
            $uid = (int)$uid;
            if ($uid <= 0 || isset($seen[$uid])) {
                continue;
            }
            $seen[$uid] = true;
            self::create($uid, $type, $title, $message, $link);
        }
    }

    /**
     * Notify every active user whose role holds ANY of the given permission
     * key(s) — the same "who can act on this" check used by
     * RBAC::requirePermission(), applied to a whole role instead of the
     * current user. Use this for "someone with permission X needs to do
     * something" events (approve leave, review an inquiry, etc.).
     *
     * @param string|array<string> $permissionKeys
     */
    public static function notifyByPermission($permissionKeys, string $type, string $title, ?string $message = null, ?string $link = null, ?int $excludeUserId = null): void
    {
        $keys = is_array($permissionKeys) ? $permissionKeys : [$permissionKeys];
        $keys = array_values(array_filter(array_map('strval', $keys)));
        if (empty($keys)) {
            return;
        }

        $placeholders = implode(',', array_fill(0, count($keys), '?'));
        $types = str_repeat('s', count($keys));

        $rows = Database::fetchAll(
            "SELECT DISTINCT u.id
             FROM users u
             JOIN role_permissions rp ON rp.role_id = u.role_id
             JOIN permissions p ON p.id = rp.permission_id
             WHERE u.status = 1 AND p.permission_key IN ($placeholders)",
            $types,
            $keys
        );

        $userIds = array_map(static fn($r) => (int)$r['id'], $rows);
        if ($excludeUserId) {
            $userIds = array_values(array_filter($userIds, static fn($id) => $id !== $excludeUserId));
        }
        self::notifyUsers($userIds, $type, $title, $message, $link);
    }

    /**
     * Resolve every recipient user_id for a set of students: each student's
     * own portal login (if any) plus every guardian linked to them who also
     * has a login (if any). Used to fan an event (fee invoice, payment,
     * published result, etc.) out to "the student and their parents" in one
     * shot, however many of those logins actually exist.
     */
    private static function studentAndGuardianUserIds(array $studentIds): array
    {
        $studentIds = array_values(array_unique(array_filter(array_map('intval', $studentIds), static fn($id) => $id > 0)));
        if (empty($studentIds)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($studentIds), '?'));
        $types = str_repeat('i', count($studentIds));

        $rows = Database::fetchAll(
            "SELECT user_id FROM students WHERE id IN ($placeholders) AND user_id IS NOT NULL
             UNION
             SELECT g.user_id
             FROM guardians g
             JOIN student_guardians sg ON sg.guardian_id = g.id
             WHERE sg.student_id IN ($placeholders) AND g.user_id IS NOT NULL",
            $types . $types,
            array_merge($studentIds, $studentIds)
        );

        return array_map(static fn($r) => (int)$r['user_id'], $rows);
    }

    /** Notify one student's own login and every guardian login linked to them. */
    public static function notifyStudentAndGuardians(int $studentId, string $type, string $title, ?string $message = null, ?string $link = null): void
    {
        self::notifyUsers(self::studentAndGuardianUserIds([$studentId]), $type, $title, $message, $link);
    }

    /**
     * Same as notifyStudentAndGuardians() but for many students at once with
     * one shared title/message — e.g. "results published for the whole
     * class". For events where the message differs per student (an
     * invoice amount, a payment amount), call notifyStudentAndGuardians()
     * once per student instead so the text stays accurate.
     */
    public static function notifyStudentsAndGuardians(array $studentIds, string $type, string $title, ?string $message = null, ?string $link = null): void
    {
        self::notifyUsers(self::studentAndGuardianUserIds($studentIds), $type, $title, $message, $link);
    }

    /** Most recent notifications for one user, newest first. */
    public static function listForUser(int $userId, int $limit = 20, int $offset = 0): array
    {
        return Database::fetchAll(
            'SELECT id, type, title, message, link, is_read, created_at
             FROM notifications WHERE user_id = ?
             ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?',
            'iii',
            [$userId, $limit, $offset]
        );
    }

    public static function unreadCount(int $userId): int
    {
        $row = Database::fetchOne(
            'SELECT COUNT(*) AS c FROM notifications WHERE user_id = ? AND is_read = 0',
            'i',
            [$userId]
        );
        return (int)($row['c'] ?? 0);
    }

    /** Marks one notification read — scoped to $userId so a user can't mark someone else's as read. */
    public static function markRead(int $id, int $userId): void
    {
        Database::execute(
            'UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?',
            'ii',
            [$id, $userId]
        );
    }

    public static function markAllRead(int $userId): void
    {
        Database::execute(
            'UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0',
            'i',
            [$userId]
        );
    }
}
