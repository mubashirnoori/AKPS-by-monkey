<?php

/**
 * Per-subject scheduling for an exam — lets an Exam (e.g. "First Term Exam Nursery")
 * carry a different date/time/total-marks for each subject, so the printed
 * Date Sheet can list every subject the class will be tested on.
 */
class ExamSubjectScheduleModel
{
    /** Lazily create the table if the migration hasn't been run yet. */
    public static function ensureTable(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        try {
            Database::execute(
                'CREATE TABLE IF NOT EXISTS exam_subject_schedule (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    exam_id INT NOT NULL,
                    subject_id INT NOT NULL,
                    scheduled_date DATE NULL,
                    start_time TIME NULL,
                    end_time TIME NULL,
                    total_marks INT NULL,
                    sort_order INT NOT NULL DEFAULT 0,
                    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME NULL,
                    UNIQUE KEY uq_exam_subject (exam_id, subject_id),
                    CONSTRAINT fk_ess_exam FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE,
                    CONSTRAINT fk_ess_subject FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
            );
        } catch (Throwable $e) {
            // ignore — run db/migrate_exam_subject_schedule.sql manually if needed
        }
        $done = true;
    }

    /**
     * All scheduled rows for an exam, joined with subject names, ordered the way a
     * printed date sheet should read: earliest date/time first, unscheduled subjects last.
     */
    public static function listForExam(int $examId): array
    {
        self::ensureTable();
        return Database::fetchAll(
            'SELECT ess.*, s.subject_name
             FROM exam_subject_schedule ess
             JOIN subjects s ON s.id = ess.subject_id
             WHERE ess.exam_id = ?
             ORDER BY (ess.scheduled_date IS NULL), ess.scheduled_date, ess.start_time, s.subject_name',
            'i',
            [$examId]
        );
    }

    /** Existing rows keyed by subject_id, for pre-filling the edit form. */
    public static function mapForExam(int $examId): array
    {
        $rows = self::listForExam($examId);
        $map = [];
        foreach ($rows as $row) {
            $map[(int)$row['subject_id']] = $row;
        }
        return $map;
    }

    public static function upsert(int $examId, int $subjectId, ?string $date, ?string $start, ?string $end, ?int $totalMarks, int $sortOrder = 0): void
    {
        self::ensureTable();
        Database::execute(
            'INSERT INTO exam_subject_schedule (exam_id, subject_id, scheduled_date, start_time, end_time, total_marks, sort_order)
             VALUES (?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
                scheduled_date = VALUES(scheduled_date),
                start_time = VALUES(start_time),
                end_time = VALUES(end_time),
                total_marks = VALUES(total_marks),
                sort_order = VALUES(sort_order),
                updated_at = NOW()',
            'iisssii',
            [$examId, $subjectId, $date, $start, $end, $totalMarks, $sortOrder]
        );
    }

    public static function clearForSubject(int $examId, int $subjectId): void
    {
        self::ensureTable();
        Database::execute(
            'DELETE FROM exam_subject_schedule WHERE exam_id = ? AND subject_id = ?',
            'ii',
            [$examId, $subjectId]
        );
    }
}
