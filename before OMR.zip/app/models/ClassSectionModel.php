<?php

class ClassSectionModel
{
    public static function allOptions(): array
    {
        return Database::fetchAll(
            'SELECT cs.id,
                    c.name AS class_name,
                    s.name AS section_name
             FROM class_sections cs
             JOIN classes c ON c.id = cs.class_id
             JOIN sections s ON s.id = cs.section_id
             ORDER BY c.name, s.name'
        );
    }

    public static function listWithClassAndSection(string $search = '', int $limit = 200, int $offset = 0): array
    {
        $searchLike = '%' . $search . '%';
        return Database::fetchAll(
            'SELECT cs.id,
                    c.name AS class_name,
                    s.name AS section_name
             FROM class_sections cs
             JOIN classes c ON c.id = cs.class_id
             JOIN sections s ON s.id = cs.section_id
             WHERE (? = \'\' OR c.name LIKE ? OR s.name LIKE ?)
             ORDER BY c.name, s.name
             LIMIT ? OFFSET ?',
            'sssii',
            [$search, $searchLike, $searchLike, $limit, $offset]
        );
    }

    public static function getById(int $classSectionId): ?array
    {
        return Database::fetchOne(
            'SELECT cs.*,
                    c.name AS class_name,
                    s.name AS section_name
             FROM class_sections cs
             JOIN classes c ON c.id = cs.class_id
             JOIN sections s ON s.id = cs.section_id
             WHERE cs.id = ?',
            'i',
            [$classSectionId]
        );
    }

    /** All class sections with class/section names and their assigned class teacher (if any). */
    public static function listWithClassTeacher(): array
    {
        return Database::fetchAll(
            'SELECT cs.id, c.name AS class_name, s.name AS section_name,
                    cs.class_teacher_staff_id, sp.full_name AS class_teacher_name
             FROM class_sections cs
             JOIN classes c ON c.id = cs.class_id
             JOIN sections s ON s.id = cs.section_id
             LEFT JOIN staff_profiles sp ON sp.id = cs.class_teacher_staff_id
             ORDER BY c.name, s.name'
        );
    }

    public static function setClassTeacher(int $classSectionId, ?int $staffProfileId): void
    {
        Database::execute(
            'UPDATE class_sections SET class_teacher_staff_id = ? WHERE id = ?',
            'ii',
            [$staffProfileId, $classSectionId]
        );
    }
}

