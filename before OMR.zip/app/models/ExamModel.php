<?php

class ExamModel
{
    public static function listExamTypes(): array
    {
        return Database::fetchAll(
            'SELECT * FROM exam_types ORDER BY name'
        );
    }

    public static function getExamType(int $id): ?array
    {
        return Database::fetchOne('SELECT * FROM exam_types WHERE id = ?', 'i', [$id]);
    }

    public static function createExamType(string $name, ?string $description): int
    {
        Database::execute(
            'INSERT INTO exam_types (name, description) VALUES (?, ?)',
            'ss',
            [trim($name), $description !== null ? trim($description) : null]
        );
        return (int)Database::lastInsertId();
    }

    public static function updateExamType(int $id, string $name, ?string $description): void
    {
        Database::execute(
            'UPDATE exam_types SET name = ?, description = ? WHERE id = ?',
            'ssi',
            [trim($name), $description !== null ? trim($description) : null, $id]
        );
    }

    public static function deleteExamType(int $id): void
    {
        Database::execute('DELETE FROM exam_types WHERE id = ?', 'i', [$id]);
    }

    public static function ensureExamRuleColumns(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        $cols = [
            'max_failed_subjects' => 'INT NOT NULL DEFAULT 1 COMMENT \'Fail if failed subjects > this (0 = must pass every subject)\'',
            'require_overall_pass' => 'TINYINT NOT NULL DEFAULT 1 COMMENT \'1 = overall % must also meet overall_passing_percentage\'',
            'overall_passing_percentage' => 'DECIMAL(5,2) NULL COMMENT \'NULL = use subject passing_percentage\'',
            'no_marks_is_fail' => 'TINYINT NOT NULL DEFAULT 1 COMMENT \'1 = no marks recorded => FAIL\'',
            'force_grade_f_on_fail' => 'TINYINT NOT NULL DEFAULT 1 COMMENT \'1 = set final grade F when result is FAIL\'',
        ];
        try {
            foreach ($cols as $name => $def) {
                $exists = Database::fetchOne("SHOW COLUMNS FROM exam_rules LIKE '" . str_replace("'", "''", $name) . "'");
                if (!$exists) {
                    Database::execute('ALTER TABLE exam_rules ADD COLUMN `' . $name . '` ' . $def);
                }
            }
        } catch (Throwable $e) {
            // run db/migrate_exam_pass_criteria.sql manually if needed
        }
        $done = true;
    }

    /**
     * "Combine with" support for cumulative exams — e.g. a "Final Term" exam
     * whose result is First Term's marks + this exam's own marks added
     * together, per subject, before pass/fail and position are worked out.
     * Stores the *base* exam name (the part before any " — Class Section"
     * tag createExamForClasses() adds), so one selection works whether the
     * source exam was created for a single class or several at once — see
     * resolveCumulativeSourceExamId().
     */
    public static function ensureCumulativeColumn(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        try {
            $exists = Database::fetchOne("SHOW COLUMNS FROM exams LIKE 'cumulative_source_exam_name'");
            if (!$exists) {
                Database::execute(
                    "ALTER TABLE exams ADD COLUMN cumulative_source_exam_name VARCHAR(150) NULL " .
                    "COMMENT 'Base exam name to add this exam\\'s marks on top of, e.g. Final Term combines with First Term'"
                );
            }
        } catch (Throwable $e) {
            // run db/migrate_exam_cumulative.sql manually if needed
        }
        $done = true;
    }

    public static function listExamGroups(?int $examTypeId = null): array
    {
        self::ensureExamRuleColumns();
        if ($examTypeId && $examTypeId > 0) {
            return Database::fetchAll(
                'SELECT eg.*, et.name AS exam_type_name,
                        er.passing_percentage, er.passing_description,
                        er.max_failed_subjects, er.require_overall_pass,
                        er.overall_passing_percentage, er.no_marks_is_fail, er.force_grade_f_on_fail
                 FROM exam_groups eg
                 JOIN exam_types et ON et.id = eg.exam_type_id
                 LEFT JOIN exam_rules er ON er.exam_group_id = eg.id
                 WHERE eg.exam_type_id = ?
                 ORDER BY eg.sort_order, eg.name',
                'i',
                [$examTypeId]
            );
        }

        return Database::fetchAll(
            'SELECT eg.*, et.name AS exam_type_name,
                    er.passing_percentage, er.passing_description,
                    er.max_failed_subjects, er.require_overall_pass,
                    er.overall_passing_percentage, er.no_marks_is_fail, er.force_grade_f_on_fail
             FROM exam_groups eg
             JOIN exam_types et ON et.id = eg.exam_type_id
             LEFT JOIN exam_rules er ON er.exam_group_id = eg.id
             ORDER BY et.name, eg.sort_order, eg.name'
        );
    }

    public static function getExamGroup(int $id): ?array
    {
        self::ensureExamRuleColumns();
        return Database::fetchOne(
            'SELECT eg.*, et.name AS exam_type_name,
                    er.passing_percentage, er.passing_description,
                    er.max_failed_subjects, er.require_overall_pass,
                    er.overall_passing_percentage, er.no_marks_is_fail, er.force_grade_f_on_fail
             FROM exam_groups eg
             JOIN exam_types et ON et.id = eg.exam_type_id
             LEFT JOIN exam_rules er ON er.exam_group_id = eg.id
             WHERE eg.id = ?',
            'i',
            [$id]
        );
    }

    public static function createExamGroup(int $examTypeId, string $name, int $sortOrder = 0): int
    {
        Database::execute(
            'INSERT INTO exam_groups (exam_type_id, name, sort_order) VALUES (?, ?, ?)',
            'isi',
            [$examTypeId, trim($name), $sortOrder]
        );
        return (int)Database::lastInsertId();
    }

    public static function updateExamGroup(int $id, int $examTypeId, string $name, int $sortOrder = 0): void
    {
        Database::execute(
            'UPDATE exam_groups SET exam_type_id = ?, name = ?, sort_order = ? WHERE id = ?',
            'isii',
            [$examTypeId, trim($name), $sortOrder, $id]
        );
    }

    public static function deleteExamGroup(int $id): void
    {
        Database::execute('DELETE FROM exam_groups WHERE id = ?', 'i', [$id]);
    }

    public static function upsertExamRule(int $examGroupId, array $rule): void
    {
        self::ensureExamRuleColumns();
        $passingPercentage = (float)($rule['passing_percentage'] ?? 50);
        if ($passingPercentage < 0) {
            $passingPercentage = 0;
        }
        if ($passingPercentage > 100) {
            $passingPercentage = 100;
        }
        $passingDescription = isset($rule['passing_description']) && trim((string)$rule['passing_description']) !== ''
            ? trim((string)$rule['passing_description'])
            : null;
        $maxFailed = (int)($rule['max_failed_subjects'] ?? 2);
        if ($maxFailed < 0) {
            $maxFailed = 0;
        }
        $requireOverall = !empty($rule['require_overall_pass']) ? 1 : 0;
        $overallPct = $rule['overall_passing_percentage'] ?? null;
        if ($overallPct === '' || $overallPct === null) {
            $overallPct = null;
        } else {
            $overallPct = (float)$overallPct;
            if ($overallPct < 0) {
                $overallPct = 0;
            }
            if ($overallPct > 100) {
                $overallPct = 100;
            }
        }
        $noMarksFail = !empty($rule['no_marks_is_fail']) ? 1 : 0;
        $forceF = !empty($rule['force_grade_f_on_fail']) ? 1 : 0;

        Database::execute(
            'INSERT INTO exam_rules
             (exam_group_id, passing_percentage, passing_description,
              max_failed_subjects, require_overall_pass, overall_passing_percentage,
              no_marks_is_fail, force_grade_f_on_fail)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
               passing_percentage = VALUES(passing_percentage),
               passing_description = VALUES(passing_description),
               max_failed_subjects = VALUES(max_failed_subjects),
               require_overall_pass = VALUES(require_overall_pass),
               overall_passing_percentage = VALUES(overall_passing_percentage),
               no_marks_is_fail = VALUES(no_marks_is_fail),
               force_grade_f_on_fail = VALUES(force_grade_f_on_fail)',
            'idsiidii',
            [
                $examGroupId,
                $passingPercentage,
                $passingDescription,
                $maxFailed,
                $requireOverall,
                $overallPct,
                $noMarksFail,
                $forceF,
            ]
        );
    }

    public static function getPassingPercentageForExam(int $examId): float
    {
        $rule = self::getPassRuleForExam($examId);
        return (float)($rule['passing_percentage'] ?? 50);
    }

    /** Full pass criteria for an exam (from its exam group rule). */
    public static function getPassRuleForExam(int $examId): array
    {
        self::ensureExamRuleColumns();
        $row = Database::fetchOne(
            'SELECT er.passing_percentage,
                    er.passing_description,
                    er.max_failed_subjects,
                    er.require_overall_pass,
                    er.overall_passing_percentage,
                    er.no_marks_is_fail,
                    er.force_grade_f_on_fail
             FROM exams e
             JOIN exam_groups eg ON eg.id = e.exam_group_id
             LEFT JOIN exam_rules er ON er.exam_group_id = eg.id
             WHERE e.id = ?',
            'i',
            [$examId]
        );

        $subjectPct = $row && $row['passing_percentage'] !== null ? (float)$row['passing_percentage'] : 50.0;
        $overallPct = ($row && $row['overall_passing_percentage'] !== null && $row['overall_passing_percentage'] !== '')
            ? (float)$row['overall_passing_percentage']
            : $subjectPct;

        return [
            'passing_percentage' => $subjectPct,
            'passing_description' => $row['passing_description'] ?? null,
            'max_failed_subjects' => $row && $row['max_failed_subjects'] !== null ? (int)$row['max_failed_subjects'] : 2,
            'require_overall_pass' => $row ? ((int)($row['require_overall_pass'] ?? 1) === 1) : true,
            'overall_passing_percentage' => $overallPct,
            'no_marks_is_fail' => $row ? ((int)($row['no_marks_is_fail'] ?? 1) === 1) : true,
            'force_grade_f_on_fail' => $row ? ((int)($row['force_grade_f_on_fail'] ?? 1) === 1) : true,
        ];
    }

    /**
     * Evaluate PASS / FAIL from marks + custom criteria.
     *
     * @param array $marksRows Each row needs score, total_marks (or percentage / is_pass already set)
     * @return array{result:string,failed_subjects:int,overall_pct:float,reasons:string[],force_grade_f:bool}
     */
    /**
     * Evaluate PASS / PROMOTE / FAIL from marks + custom criteria.
     *
     * Three tiers, not two:
     *   - PASS     : every subject cleared (and overall % requirement met, if any).
     *   - PROMOTE  : failed at least one subject, but fewer than the exam's
     *                "fail at N+ failed subjects" threshold — a common school
     *                leniency (e.g. failing exactly one subject still moves
     *                the student up a grade). NOT eligible for class/school
     *                position — only a full PASS is.
     *   - FAIL     : failed subjects reached the threshold, or the overall %
     *                requirement wasn't met (overall failure is always an
     *                outright FAIL, never just a PROMOTE).
     *
     * @param array $marksRows Each row needs score, total_marks (or percentage / is_pass already set)
     * @return array{result:string,failed_subjects:int,overall_pct:float,reasons:string[],force_grade_f:bool}
     */
    public static function evaluateResult(array $rule, array $marksRows, float $overallPct): array
    {
        $subjectPct = (float)($rule['passing_percentage'] ?? 50);
        $overallNeed = (float)($rule['overall_passing_percentage'] ?? $subjectPct);
        $maxFailed = (int)($rule['max_failed_subjects'] ?? 2);
        $requireOverall = !empty($rule['require_overall_pass']);
        $noMarksFail = !array_key_exists('no_marks_is_fail', $rule) || !empty($rule['no_marks_is_fail']);
        $forceF = !array_key_exists('force_grade_f_on_fail', $rule) || !empty($rule['force_grade_f_on_fail']);

        $reasons = [];
        $failed = 0;
        $markCount = count($marksRows);

        if ($markCount === 0) {
            if ($noMarksFail) {
                return [
                    'result' => 'FAIL',
                    'failed_subjects' => 0,
                    'overall_pct' => 0.0,
                    'reasons' => ['No marks recorded for this exam'],
                    'force_grade_f' => $forceF,
                ];
            }
            return [
                'result' => 'INCOMPLETE',
                'failed_subjects' => 0,
                'overall_pct' => 0.0,
                'reasons' => ['No marks recorded'],
                'force_grade_f' => false,
            ];
        }

        foreach ($marksRows as $m) {
            if (array_key_exists('is_pass', $m)) {
                if (!$m['is_pass']) {
                    $failed++;
                }
                continue;
            }
            $subTotal = (float)($m['total_marks'] ?? 100);
            $subTotal = $subTotal > 0 ? $subTotal : 100.0;
            $score = (float)($m['score'] ?? 0);
            $pct = $subTotal > 0 ? ($score / $subTotal * 100) : 0.0;
            if ($pct < $subjectPct) {
                $failed++;
            }
        }

        $tier = 'PASS';
        // "Fail if failed subjects reach N" — e.g. N=2 means 2 or more failed subjects = FAIL.
        // N=0 means any failed subject = FAIL (must pass all, no promote tier possible).
        // Anywhere in between (1 or more failed, but below N) = PROMOTE.
        if ($maxFailed <= 0) {
            if ($failed > 0) {
                $tier = 'FAIL';
                $reasons[] = 'Failed ' . $failed . ' subject(s); must pass every subject';
            }
        } elseif ($failed >= $maxFailed) {
            $tier = 'FAIL';
            $reasons[] = 'Failed ' . $failed . ' subject(s) (fail at ' . $maxFailed . '+)';
        } elseif ($failed > 0) {
            $tier = 'PROMOTE';
            $reasons[] = 'Failed ' . $failed . ' subject(s); promoted (below the fail threshold of ' . $maxFailed . ') — not eligible for class/school position';
        }

        // Overall % failure is always an outright FAIL, even if the per-subject
        // count alone would only have earned a PROMOTE.
        if ($requireOverall && $overallPct < $overallNeed) {
            $tier = 'FAIL';
            $reasons[] = 'Overall ' . round($overallPct, 1) . '% is below required ' . round($overallNeed, 1) . '%';
        }

        if ($tier === 'PASS' && $reasons === []) {
            $reasons[] = 'Met pass criteria';
        }

        return [
            'result' => $tier,
            'failed_subjects' => $failed,
            'overall_pct' => $overallPct,
            'reasons' => $reasons,
            'force_grade_f' => $tier === 'FAIL' && $forceF,
        ];
    }

    /**
     * Paginated exam list for the Create Exam management page. Kept separate
     * from listExams() so the many other unpaginated callers (marks entry,
     * dropdown filters, etc.) are unaffected.
     *
     * @return array{rows: array, total: int}
     */
    public static function listExamsPaginated(int $page = 1, int $perPage = 15): array
    {
        self::ensureCumulativeColumn();
        $page = max(1, $page);
        $perPage = $perPage > 0 ? $perPage : 15;
        $offset = ($page - 1) * $perPage;

        $totalRow = Database::fetchOne('SELECT COUNT(*) AS cnt FROM exams');
        $total = (int)($totalRow['cnt'] ?? 0);

        $rows = Database::fetchAll(
            'SELECT e.*,
                    et.name AS exam_type_name,
                    eg.name AS exam_group_name,
                    cs.id AS class_section_row_id,
                    c.name AS class_name,
                    sec.name AS section_name
             FROM exams e
             JOIN exam_groups eg ON eg.id = e.exam_group_id
             JOIN exam_types et ON et.id = eg.exam_type_id
             LEFT JOIN class_sections cs ON cs.id = e.class_section_id
             LEFT JOIN classes c ON c.id = cs.class_id
             LEFT JOIN sections sec ON sec.id = cs.section_id
             ORDER BY e.id DESC
             LIMIT ? OFFSET ?',
            'ii',
            [$perPage, $offset]
        );

        return ['rows' => $rows, 'total' => $total];
    }

    public static function listExams(?int $classSectionId = null): array
    {
        self::ensureCumulativeColumn();
        if ($classSectionId && $classSectionId > 0) {
            return Database::fetchAll(
                'SELECT e.*,
                        et.name AS exam_type_name,
                        eg.name AS exam_group_name,
                        cs.id AS class_section_row_id,
                        c.name AS class_name,
                        sec.name AS section_name
                 FROM exams e
                 JOIN exam_groups eg ON eg.id = e.exam_group_id
                 JOIN exam_types et ON et.id = eg.exam_type_id
                 LEFT JOIN class_sections cs ON cs.id = e.class_section_id
                 LEFT JOIN classes c ON c.id = cs.class_id
                 LEFT JOIN sections sec ON sec.id = cs.section_id
                 WHERE e.class_section_id = ?
                 ORDER BY e.id DESC',
                'i',
                [$classSectionId]
            );
        }

        return Database::fetchAll(
            'SELECT e.*,
                    et.name AS exam_type_name,
                    eg.name AS exam_group_name,
                    cs.id AS class_section_row_id,
                    c.name AS class_name,
                    sec.name AS section_name
             FROM exams e
             JOIN exam_groups eg ON eg.id = e.exam_group_id
             JOIN exam_types et ON et.id = eg.exam_type_id
             LEFT JOIN class_sections cs ON cs.id = e.class_section_id
             LEFT JOIN classes c ON c.id = cs.class_id
             LEFT JOIN sections sec ON sec.id = cs.section_id
             ORDER BY e.id DESC'
        );
    }

    public static function getExam(int $examId): ?array
    {
        self::ensureCumulativeColumn();
        return Database::fetchOne(
            'SELECT e.*,
                    eg.name AS exam_group_name,
                    et.name AS exam_type_name,
                    c.name AS class_name,
                    sec.name AS section_name,
                    ay.academic_year_label
             FROM exams e
             JOIN exam_groups eg ON eg.id = e.exam_group_id
             JOIN exam_types et ON et.id = eg.exam_type_id
             LEFT JOIN class_sections cs ON cs.id = e.class_section_id
             LEFT JOIN classes c ON c.id = cs.class_id
             LEFT JOIN sections sec ON sec.id = cs.section_id
             LEFT JOIN academic_years ay ON ay.id = e.academic_year_id
             WHERE e.id = ?',
            'i',
            [$examId]
        );
    }

    public static function createExam(array $data, ?int $createdByUserId): int
    {
        self::ensureCumulativeColumn();
        Database::execute(
            'INSERT INTO exams
             (exam_group_id, academic_year_id, class_section_id, exam_name, scheduled_date, start_time, end_time, total_marks, cumulative_source_exam_name, created_by_user_id)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            'iiissssisi',
            [
                (int)$data['exam_group_id'],
                $data['academic_year_id'] ? (int)$data['academic_year_id'] : null,
                $data['class_section_id'] ? (int)$data['class_section_id'] : null,
                trim((string)$data['exam_name']),
                trim((string)($data['scheduled_date'] ?? '')) ?: null,
                trim((string)($data['start_time'] ?? '')) ?: null,
                trim((string)($data['end_time'] ?? '')) ?: null,
                isset($data['total_marks']) && (int)$data['total_marks'] > 0 ? (int)$data['total_marks'] : null,
                trim((string)($data['cumulative_source_exam_name'] ?? '')) ?: null,
                $createdByUserId
            ]
        );
        return (int)Database::lastInsertId();
    }

    /**
     * Create the same exam across several classes at once (one `exams` row per class,
     * all sharing the same name/group/date/time/total-marks defaults). This is what
     * powers the "All Classes / Multiple Classes / Single Class" picker on the Create
     * Exam form, so the admin doesn't have to repeat the whole form per class.
     *
     * Each per-class exam can still be edited individually afterwards (different date,
     * different total marks, etc.) — this only saves the initial repetitive entry.
     *
     * @param int[] $classSectionIds
     * @return array{created:int[], errors:string[]}
     */
    public static function createExamForClasses(array $classSectionIds, array $data, ?int $createdByUserId): array
    {
        $classSectionIds = array_values(array_unique(array_filter(array_map('intval', $classSectionIds))));
        $created = [];
        $errors = [];

        // When creating for more than one class, tag each exam's name with its class
        // so they're distinguishable in the Exam List, Date Sheet, and Report Cards —
        // e.g. "First Term Exam" -> "First Term Exam — 6th A".
        $tagWithClass = count($classSectionIds) > 1;
        $baseName = trim((string)$data['exam_name']);

        foreach ($classSectionIds as $classSectionId) {
            $classSection = Database::fetchOne(
                'SELECT cs.id, c.name AS class_name, sec.name AS section_name
                 FROM class_sections cs
                 JOIN classes c ON c.id = cs.class_id
                 JOIN sections sec ON sec.id = cs.section_id
                 WHERE cs.id = ?',
                'i',
                [$classSectionId]
            );
            if (!$classSection) {
                $errors[] = "Class/section id $classSectionId not found — skipped.";
                continue;
            }

            $examName = $baseName;
            if ($tagWithClass) {
                $examName .= ' — ' . trim($classSection['class_name'] . ' ' . $classSection['section_name']);
            }

            $rowData = $data;
            $rowData['class_section_id'] = $classSectionId;
            $rowData['exam_name'] = $examName;

            try {
                $created[] = self::createExam($rowData, $createdByUserId);
            } catch (Throwable $e) {
                $errors[] = 'Could not create exam for ' . $classSection['class_name'] . ' ' . $classSection['section_name'] . ': ' . $e->getMessage();
            }
        }

        return ['created' => $created, 'errors' => $errors];
    }

    public static function updateExam(int $id, array $data): void
    {
        self::ensureCumulativeColumn();
        Database::execute(
            'UPDATE exams
             SET exam_group_id = ?,
                 academic_year_id = ?,
                 class_section_id = ?,
                 exam_name = ?,
                 scheduled_date = ?,
                 start_time = ?,
                 end_time = ?,
                 total_marks = ?,
                 cumulative_source_exam_name = ?,
                 updated_at = NOW()
             WHERE id = ?',
            'iiissssisi',
            [
                (int)$data['exam_group_id'],
                $data['academic_year_id'] ? (int)$data['academic_year_id'] : null,
                $data['class_section_id'] ? (int)$data['class_section_id'] : null,
                trim((string)$data['exam_name']),
                trim((string)($data['scheduled_date'] ?? '')) ?: null,
                trim((string)($data['start_time'] ?? '')) ?: null,
                trim((string)($data['end_time'] ?? '')) ?: null,
                isset($data['total_marks']) && (int)$data['total_marks'] > 0 ? (int)$data['total_marks'] : null,
                trim((string)($data['cumulative_source_exam_name'] ?? '')) ?: null,
                $id
            ]
        );
    }

    public static function deleteExam(int $id): void
    {
        Database::execute('DELETE FROM exams WHERE id = ?', 'i', [$id]);
    }

    public static function publishResults(int $examId): void
    {
        Database::execute(
            'UPDATE exams SET results_published = 1, results_published_at = NOW() WHERE id = ?',
            'i',
            [$examId]
        );
    }

    public static function unpublishResults(int $examId): void
    {
        Database::execute(
            'UPDATE exams SET results_published = 0, results_published_at = NULL WHERE id = ?',
            'i',
            [$examId]
        );
    }

    /**
     * Distinct "base" exam names (the part before any " — Class Section" tag
     * createExamForClasses() adds) across the whole school, newest first —
     * for the "Combine with" picker on the Create/Edit Exam form.
     */
    public static function distinctExamBaseNames(): array
    {
        self::ensureCumulativeColumn();
        $rows = Database::fetchAll(
            "SELECT exam_name, id FROM exams ORDER BY id DESC"
        );
        $seen = [];
        foreach ($rows as $r) {
            $base = trim((string)explode(' — ', (string)$r['exam_name'], 2)[0]);
            if ($base !== '') {
                $seen[$base] = true;
            }
        }
        return array_keys($seen);
    }

    /**
     * Resolve the actual source `exams` row an exam should add its marks on
     * top of (e.g. Final Term -> the matching First Term exam for the SAME
     * academic year + class/section), given the exam's stored
     * cumulative_source_exam_name (a base name — see distinctExamBaseNames()).
     * Matches the base name exactly, or tagged as "<base> — <class section>",
     * so one selection works whether that source exam was created for a
     * single class or several at once.
     */
    public static function resolveCumulativeSourceExamId(array $exam): ?int
    {
        $base = trim((string)($exam['cumulative_source_exam_name'] ?? ''));
        if ($base === '' || empty($exam['class_section_id'])) {
            return null;
        }
        $row = Database::fetchOne(
            "SELECT id FROM exams
             WHERE class_section_id = ?
               AND id != ?
               AND (academic_year_id <=> ?)
               AND (exam_name = ? OR exam_name LIKE CONCAT(?, ' — %'))
             ORDER BY id DESC
             LIMIT 1",
            'iiiss',
            [
                (int)$exam['class_section_id'],
                (int)($exam['id'] ?? 0),
                $exam['academic_year_id'] ?? null,
                $base,
                $base,
            ]
        );
        return $row ? (int)$row['id'] : null;
    }

    /**
     * Raw per-subject marks for one exam, no combination applied yet.
     * Keyed as a flat list of ['student_id','subject_id','subject_name','score','total_marks'].
     */
    private static function rawMarksForExam(int $examId): array
    {
        return Database::fetchAll(
            'SELECT m.student_id, m.subject_id, sub.subject_name, m.score, COALESCE(m.total_marks, 100) AS total_marks
             FROM marks m
             JOIN subjects sub ON sub.id = m.subject_id
             WHERE m.exam_id = ?',
            'i',
            [$examId]
        );
    }

    /**
     * One student's own raw marks for one exam, subject_id => marks — no
     * cumulative combination applied, even if the exam has a
     * cumulative_source_exam_name set. Used for the term-by-term breakdown
     * (report card "own marks" view, bulk export per-term folders/columns).
     */
    private static function ownMarksForStudent(int $examId, int $studentId): array
    {
        $rows = Database::fetchAll(
            'SELECT m.subject_id, sub.subject_name, m.score, COALESCE(m.total_marks, 100) AS total_marks
             FROM marks m
             JOIN subjects sub ON sub.id = m.subject_id
             WHERE m.exam_id = ? AND m.student_id = ?',
            'ii',
            [$examId, $studentId]
        );
        $out = [];
        foreach ($rows as $r) {
            $out[(int)$r['subject_id']] = [
                'subject_name' => (string)$r['subject_name'],
                'score' => (float)$r['score'],
                'total_marks' => (float)$r['total_marks'],
            ];
        }
        return $out;
    }

    /**
     * Effective per-subject marks for an exam — its own marks, plus (if it's
     * set up to combine with an earlier exam, e.g. Final Term with First
     * Term) that source exam's effective marks added on top, per student per
     * subject. A subject missing from one side just contributes whatever the
     * other side has (e.g. a subject only introduced in the second term isn't
     * penalised for "missing" first-term marks that were never possible).
     * $visited guards against a combination loop (A combines with B combines
     * with A) — extremely unlikely to be configured, but must never hang.
     *
     * @return array<int, array<int, array{subject_name:string, score:float, total_marks:float}>> student_id => subject_id => marks
     */
    public static function effectiveMarksForExam(int $examId, array $visited = []): array
    {
        if (isset($visited[$examId])) {
            return [];
        }
        $visited[$examId] = true;

        $merged = [];
        foreach (self::rawMarksForExam($examId) as $r) {
            $sid = (int)$r['student_id'];
            $subId = (int)$r['subject_id'];
            $merged[$sid][$subId] = [
                'subject_name' => (string)$r['subject_name'],
                'score' => (float)$r['score'],
                'total_marks' => (float)$r['total_marks'],
            ];
        }

        $exam = self::getExam($examId);
        $sourceId = $exam ? self::resolveCumulativeSourceExamId($exam) : null;
        if ($sourceId) {
            $sourceMarks = self::effectiveMarksForExam($sourceId, $visited);
            foreach ($sourceMarks as $sid => $subjects) {
                foreach ($subjects as $subId => $m) {
                    if (isset($merged[$sid][$subId])) {
                        $merged[$sid][$subId]['score'] += $m['score'];
                        $merged[$sid][$subId]['total_marks'] += $m['total_marks'];
                    } else {
                        $merged[$sid][$subId] = $m;
                    }
                }
            }
        }

        return $merged;
    }

    /** Base name of the exam(s) this exam's result is combined with, or null if it isn't a combined exam. */
    public static function combinedWithLabel(array $exam): ?string
    {
        $base = trim((string)($exam['cumulative_source_exam_name'] ?? ''));
        return $base !== '' ? $base : null;
    }

    /**
     * Class ranking for one exam: every student who has marks for this exam,
     * sorted by overall percentage (desc), with dense ranking — equal
     * percentages (and equal total marks obtained) share the same position,
     * and the next distinct score continues immediately after (1, 1, 2 …)
     * rather than skipping the positions the tied students used up.
     */
    /**
     * Every student who has marks in this exam, with their totals, unrounded
     * percentage, and PASS/PROMOTE/FAIL result — no ranking or filtering applied yet.
     * Shared by classRankings() (single class), schoolTopper() (across
     * several classes' exams for the same test), and the bulk exports.
     */
    /** rawMarksForExam(), but grouped by student like effectiveMarksForExam() returns — for batch "own totals only" lookups (examStudentPool($id, true)). */
    private static function rawMarksGroupedByStudent(int $examId): array
    {
        $grouped = [];
        foreach (self::rawMarksForExam($examId) as $r) {
            $sid = (int)$r['student_id'];
            $subId = (int)$r['subject_id'];
            $grouped[$sid][$subId] = [
                'subject_name' => (string)$r['subject_name'],
                'score' => (float)$r['score'],
                'total_marks' => (float)$r['total_marks'],
            ];
        }
        return $grouped;
    }

    /** Public wrapper for rawMarksGroupedByStudent() — this exam's own per-subject marks, student_id => subject_id => [subject_name, score, total_marks]. Used for the per-subject columns on the bulk-export results workbook. */
    public static function ownMarksGroupedByStudent(int $examId): array
    {
        return self::rawMarksGroupedByStudent($examId);
    }

    /**
     * Ordered list of subjects with recorded marks for one exam — id, name,
     * and each subject's max marks (for the per-subject column headers on
     * the bulk-export results workbook). Ordered alphabetically by subject
     * name so column order is predictable across sheets/exams.
     */
    public static function subjectListForExam(int $examId): array
    {
        return Database::fetchAll(
            'SELECT m.subject_id AS id, sub.subject_name AS name, MAX(COALESCE(m.total_marks, 100)) AS total_marks
             FROM marks m
             JOIN subjects sub ON sub.id = m.subject_id
             WHERE m.exam_id = ?
             GROUP BY m.subject_id, sub.subject_name
             ORDER BY sub.subject_name',
            'i',
            [$examId]
        );
    }

    /**
     * @param bool $ownMarksOnly When the exam combines with an earlier exam,
     *   pass true to total up ONLY this exam's own marks (no combination) —
     *   used for the per-term breakdown columns/folders in bulk exports.
     *   PASS/FAIL/PROMOTE is still evaluated on whatever totals are used, but
     *   callers using $ownMarksOnly should treat 'result'/ranking as informal
     *   (not the official one) — same rule as studentReportCard()'s $ownMarksOnly.
     */
    public static function examStudentPool(int $examId, bool $ownMarksOnly = false): array
    {
        $passRule = self::getPassRuleForExam($examId);
        $effective = $ownMarksOnly ? self::rawMarksGroupedByStudent($examId) : self::effectiveMarksForExam($examId);

        if (empty($effective)) {
            return [];
        }

        $studentIds = array_keys($effective);
        $placeholders = implode(',', array_fill(0, count($studentIds), '?'));
        $studentRows = Database::fetchAll(
            "SELECT id, first_name, last_name, father_name, admission_no FROM students WHERE id IN ($placeholders)",
            str_repeat('i', count($studentIds)),
            $studentIds
        );
        $studentInfo = [];
        foreach ($studentRows as $sr) {
            $studentInfo[(int)$sr['id']] = $sr;
        }

        // Group (already-combined, unless $ownMarksOnly) subject marks by
        // student so pass/fail can be evaluated exactly the same way the
        // report card evaluates it.
        $students = [];
        foreach ($effective as $sid => $subjects) {
            $marks = [];
            $totalObtained = 0.0;
            $totalMax = 0.0;
            foreach ($subjects as $m) {
                $subTotal = $m['total_marks'] > 0 ? $m['total_marks'] : 100.0;
                $score = $m['score'];
                $pct = $subTotal > 0 ? ($score / $subTotal * 100) : 0.0;
                $marks[] = [
                    'score' => $score,
                    'total_marks' => $subTotal,
                    'is_pass' => $pct >= (float)($passRule['passing_percentage'] ?? 50),
                ];
                $totalObtained += $score;
                $totalMax += $subTotal;
            }

            $overallPct = $totalMax > 0 ? ($totalObtained / $totalMax * 100) : 0.0;
            $eval = self::evaluateResult($passRule, $marks, $overallPct);
            $info = $studentInfo[$sid] ?? null;
            $students[] = [
                'student_id' => $sid,
                'name' => $info ? trim(($info['first_name'] ?? '') . ' ' . ($info['last_name'] ?? '')) : '',
                'father_name' => $info['father_name'] ?? '',
                'admission_no' => $info['admission_no'] ?? '',
                'total_obtained' => $totalObtained,
                'total_max' => $totalMax,
                'percentage' => $overallPct, // unrounded — used for exact tie comparison
                'result' => $eval['result'],
            ];
        }

        return $students;
    }

    /**
     * @param bool $topThreeOnly true (default) keeps only 1st–3rd — used by the position-holder
     *   lists and exports. false returns every passing student with their rank — used by the
     *   report card so any student can show their own class position.
     */
    public static function classRankings(int $examId, bool $topThreeOnly = true): array
    {
        // A failing (or merely promoted) student can never hold a class
        // position, no matter how high their marks are — only students who
        // fully passed (PASS, not PROMOTE) compete.
        $eligible = array_values(array_filter(self::examStudentPool($examId), static function ($r) {
            return $r['result'] === 'PASS';
        }));

        // Primary sort: percentage (desc). When two students land on the exact
        // same percentage — which can happen even with different total marks if
        // they sat different total-mark subject combinations — total marks
        // obtained (desc) breaks the tie, since a higher raw score is the more
        // intuitive "did better" for anyone comparing report cards side by side.
        // Only a match on BOTH numbers is a genuine tie that shares a position.
        usort($eligible, function ($a, $b) {
            $byPct = $b['percentage'] <=> $a['percentage'];
            if ($byPct !== 0) {
                return $byPct;
            }
            return $b['total_obtained'] <=> $a['total_obtained'];
        });

        $rank = 0;
        $prevPct = null;
        $prevObtained = null;
        foreach ($eligible as $i => &$r) {
            $samePct = $prevPct !== null && abs($r['percentage'] - $prevPct) <= 0.0001;
            $sameObtained = $prevObtained !== null && abs($r['total_obtained'] - $prevObtained) <= 0.0001;
            if (!($samePct && $sameObtained)) {
                $rank++;
            }
            $r['rank'] = $rank;
            $prevPct = $r['percentage'];
            $prevObtained = $r['total_obtained'];
        }
        unset($r);

        // Only 1st, 2nd, and 3rd are meaningful "positions" — anything past
        // that isn't reported as a class position at all.
        if (!$topThreeOnly) {
            return $eligible;
        }
        return array_values(array_filter($eligible, static function ($r) {
            return $r['rank'] <= 3;
        }));
    }

    /** Classes eligible for the whole-school topper (by class name). */
    public static function schoolTopperClassNames(): array
    {
        return ['5th', '6th', '7th', '8th'];
    }

    /**
     * Distinct exam names in the eligible classes — for the picker.
     * @param bool $includeUnpublished Admin-only (see schoolTopper() gating note).
     */
    public static function schoolTopperExamNames(bool $includeUnpublished = false): array
    {
        $classNames = self::schoolTopperClassNames();
        $placeholders = implode(',', array_fill(0, count($classNames), '?'));
        $publishedClause = $includeUnpublished ? '' : ' AND e.results_published = 1';
        return Database::fetchAll(
            "SELECT DISTINCT e.exam_name
             FROM exams e
             JOIN class_sections cs ON cs.id = e.class_section_id
             JOIN classes c ON c.id = cs.class_id
             WHERE 1=1{$publishedClause} AND c.name IN ($placeholders)
             ORDER BY e.exam_name",
            str_repeat('s', count($classNames)),
            $classNames
        );
    }

    /**
     * Whole-school topper (classes 5th–8th only) for one exam name: ALWAYS
     * exactly one student (never a joint/tied list) — highest percentage
     * across all of those classes' sections; if two or more students share
     * the exact same percentage, the one with the higher total marks
     * obtained wins; if that also matches exactly, a final deterministic
     * tiebreak (admission no, then student id) picks a single winner so the
     * result is always one person, never a "tie" the school has to resolve.
     */
    /**
     * @param bool $includeUnpublished Also consider exams whose results haven't
     *   been published yet. Callers MUST gate this the same way examsForName()
     *   and allExamNamesIncludingUnpublished() are gated — Admin only for bulk
     *   export (canBulkExportUnpublished()), Admin/'academic.unpublished_results'
     *   for the review-before-announcing screens (canSeeUnpublishedResults()) —
     *   so a draft school topper never leaks to anyone else.
     */
    public static function schoolTopper(string $examName, bool $includeUnpublished = false): array
    {
        $classNames = self::schoolTopperClassNames();
        if ($examName === '') {
            return ['exams' => [], 'toppers' => []];
        }

        $publishedClause = $includeUnpublished ? '' : ' AND e.results_published = 1';
        $placeholders = implode(',', array_fill(0, count($classNames), '?'));
        $exams = Database::fetchAll(
            "SELECT e.id, e.exam_name, c.name AS class_name, s.name AS section_name
             FROM exams e
             JOIN class_sections cs ON cs.id = e.class_section_id
             JOIN classes c ON c.id = cs.class_id
             JOIN sections s ON s.id = cs.section_id
             WHERE e.exam_name = ?{$publishedClause} AND c.name IN ($placeholders)
             ORDER BY c.name, s.name",
            's' . str_repeat('s', count($classNames)),
            array_merge([$examName], $classNames)
        );

        $pool = [];
        foreach ($exams as $ex) {
            foreach (self::examStudentPool((int)$ex['id']) as $st) {
                if ($st['result'] !== 'PASS') {
                    continue; // a failing student can never be the topper
                }
                $st['class_name'] = $ex['class_name'];
                $st['section_name'] = $ex['section_name'];
                $st['exam_id'] = (int)$ex['id'];
                $pool[] = $st;
            }
        }

        if (empty($pool)) {
            return ['exams' => $exams, 'toppers' => []];
        }

        // Percentage first (desc), then total marks obtained (desc) as the
        // tiebreak. If both of those still match exactly, fall back to
        // admission no. and finally student id — purely so the sort is fully
        // deterministic. The school topper is always ONE person: whoever
        // sorts first, full stop, never a shared/joint list.
        usort($pool, function ($a, $b) {
            $byPct = $b['percentage'] <=> $a['percentage'];
            if ($byPct !== 0) {
                return $byPct;
            }
            $byObtained = $b['total_obtained'] <=> $a['total_obtained'];
            if ($byObtained !== 0) {
                return $byObtained;
            }
            $byAdmission = strcmp((string)($a['admission_no'] ?? ''), (string)($b['admission_no'] ?? ''));
            if ($byAdmission !== 0) {
                return $byAdmission;
            }
            return $a['student_id'] <=> $b['student_id'];
        });

        // Exactly one topper — the rest of this exam's passing students are
        // still available in classRankings() for their own class position.
        $toppers = [$pool[0]];

        return ['exams' => $exams, 'toppers' => $toppers];
    }

    /** Every distinct exam name in the school with announced results — for the bulk-export picker. */
    public static function allPublishedExamNames(): array
    {
        return Database::fetchAll(
            'SELECT DISTINCT exam_name FROM exams WHERE results_published = 1 ORDER BY exam_name'
        );
    }

    /**
     * Every distinct exam name in the school regardless of publish status — Admin-only
     * bulk-export picker, so Admin can pull reports/CSV for results that haven't been
     * published yet. Callers MUST gate use of this with RBAC::isAdmin(); every other
     * role must keep using allPublishedExamNames() so unpublished results never leak
     * to a non-admin portal (teacher/student/parent/accountant) via bulk export.
     */
    public static function allExamNamesIncludingUnpublished(): array
    {
        return Database::fetchAll(
            'SELECT DISTINCT exam_name FROM exams ORDER BY exam_name'
        );
    }

    /**
     * All exams (any class/section, whole school) matching this exam name.
     * By default only exams with announced (published) results are returned.
     * $includeUnpublished=true also returns draft/unpublished exams — callers
     * MUST gate that with RBAC::isAdmin() so unpublished results are only ever
     * reachable by Admin, never by any other portal.
     */
    public static function examsForName(string $examName, bool $includeUnpublished = false): array
    {
        self::ensureCumulativeColumn();
        $publishedClause = $includeUnpublished ? '' : ' AND e.results_published = 1';
        return Database::fetchAll(
            'SELECT e.id, e.exam_name, e.class_section_id, e.academic_year_id, e.cumulative_source_exam_name,
                    c.id AS class_id, c.name AS class_name, s.name AS section_name,
                    et.name AS exam_type_name, ay.academic_year_label
             FROM exams e
             JOIN class_sections cs ON cs.id = e.class_section_id
             JOIN classes c ON c.id = cs.class_id
             JOIN sections s ON s.id = cs.section_id
             JOIN exam_groups eg ON eg.id = e.exam_group_id
             JOIN exam_types et ON et.id = eg.exam_type_id
             LEFT JOIN academic_years ay ON ay.id = e.academic_year_id
             WHERE e.exam_name = ?' . $publishedClause . '
             ORDER BY c.name, s.name',
            's',
            [$examName]
        );
    }

    /**
     * Full report-card data for one student in one exam.
     *
     * @param bool $ownMarksOnly When the exam is set up to combine with an
     *   earlier exam (e.g. Final Term = First Term + Final Term), pass true
     *   to get ONLY this exam's own marks — no combination, and no
     *   ranking/position (position is only ever meaningful for the actual
     *   combined result). Used for the "this term's marks on their own"
     *   breakdown view/folder in report cards and bulk exports. Has no effect
     *   on a plain, non-combined exam (own marks IS the whole result there).
     * @param bool $includeUnpublishedForSchoolTopper Whether the whole-school
     *   topper badge may be computed against a not-yet-published exam — the
     *   report card's OWN class position already ignores publish status
     *   (it's computed directly off this known $examId), but the school-wide
     *   topper check calls schoolTopper() for other classes too, which
     *   defaults to published-only. Callers MUST gate this the same way
     *   the exam itself was gated to reach this point — Admin-only for bulk
     *   export (canBulkExportUnpublished()), canSeeUnpublishedResults() for
     *   the admin/teacher Report Card screen, and always false for the
     *   student/parent portal (which only ever reaches a published exam).
     */
    public static function studentReportCard(int $studentId, int $examId, bool $ownMarksOnly = false, bool $includeUnpublishedForSchoolTopper = false): array
    {
        require_once __DIR__ . '/MarkModel.php';

        $result = [
            'studentMarks' => [],
            'average' => null,
            'overallGrade' => null,
            'failedSubjects' => 0,
            'passingPercentage' => 50.0,
            'resultStatus' => null,
            'resultReasons' => [],
            'passRule' => null,
            'classRankings' => [],
            'classToppers' => [],
            'studentRank' => null,
            'classSize' => 0,
            'isSchoolTopper' => false,
            'combinedWith' => null,
            'breakdown' => [], // subject_id => ['source'=>['score','total_marks'],'own'=>['score','total_marks']] — only set on the combined (non-ownMarksOnly) view of a combined exam
        ];

        if ($studentId <= 0 || $examId <= 0) {
            return $result;
        }

        $examRow = self::getExam($examId);
        $isCombinedExam = self::combinedWithLabel($examRow ?? []) !== null;
        $result['combinedWith'] = ($isCombinedExam && !$ownMarksOnly) ? self::combinedWithLabel($examRow ?? []) : null;

        $passRule = self::getPassRuleForExam($examId);
        $result['passRule'] = $passRule;
        $passingPercentage = (float)($passRule['passing_percentage'] ?? 50);
        $result['passingPercentage'] = $passingPercentage;

        if ($ownMarksOnly) {
            // Just this exam's own raw marks — deliberately ignores
            // cumulative_source_exam_name even if set, since this view exists
            // specifically to show "what this term alone looked like".
            $subjectsForStudent = self::ownMarksForStudent($examId, $studentId);
        } else {
            // effectiveMarksForExam() already adds this exam's marks on top of a
            // combined-with exam's marks (e.g. Final Term = First Term + Final
            // Term), per subject, when the exam is set up that way — so the rest
            // of this function doesn't need to know or care whether it's looking
            // at a single exam's marks or a combined total.
            $subjectsForStudent = self::effectiveMarksForExam($examId)[$studentId] ?? [];
        }

        // For a combined exam's non-own view, also work out the source-vs-own
        // split per subject, purely for display (the totals above already use
        // the combined numbers regardless).
        if ($isCombinedExam && !$ownMarksOnly) {
            $ownOnly = self::ownMarksForStudent($examId, $studentId);
            $sourceId = self::resolveCumulativeSourceExamId($examRow);
            $sourceOnly = $sourceId ? self::ownMarksForStudent($sourceId, $studentId) : [];
            foreach ($subjectsForStudent as $subId => $m) {
                $result['breakdown'][$subId] = [
                    'subject_name' => $m['subject_name'],
                    'own' => [
                        'score' => $ownOnly[$subId]['score'] ?? 0.0,
                        'total_marks' => $ownOnly[$subId]['total_marks'] ?? 0.0,
                    ],
                    'source' => [
                        'score' => $sourceOnly[$subId]['score'] ?? 0.0,
                        'total_marks' => $sourceOnly[$subId]['total_marks'] ?? 0.0,
                    ],
                ];
            }
        }

        $studentMarks = [];
        foreach ($subjectsForStudent as $subId => $m) {
            $studentMarks[] = [
                'subject_id' => $subId,
                'subject_name' => $m['subject_name'],
                'score' => $m['score'],
                'total_marks' => $m['total_marks'] > 0 ? $m['total_marks'] : 100.0,
            ];
        }
        usort($studentMarks, static function ($a, $b) {
            return strcmp((string)$a['subject_name'], (string)$b['subject_name']);
        });

        $totalObtained = 0.0;
        $totalMaxMarks = 0.0;
        foreach ($studentMarks as &$m) {
            $subTotal = (float)($m['total_marks'] ?? 100);
            $subTotal = $subTotal > 0 ? $subTotal : 100.0;
            $score    = (float)($m['score'] ?? 0);
            $pct      = $subTotal > 0 ? ($score / $subTotal * 100) : 0.0;
            // Re-resolve grade from percentage
            $gRow = MarkModel::gradeIdForScore($pct);
            if ($gRow) {
                $gLetter = Database::fetchOne('SELECT grade_letter FROM grades WHERE id = ?', 'i', [$gRow]);
                $m['grade_letter'] = $gLetter ? $gLetter['grade_letter'] : ($m['grade_letter'] ?? '—');
            }
            $m['percentage'] = $pct;
            $m['is_pass'] = $pct >= $passingPercentage;
            if (!$m['is_pass']) {
                $result['failedSubjects']++;
            }
            $totalObtained += $score;
            $totalMaxMarks += $subTotal;
        }
        unset($m);
        $result['studentMarks'] = $studentMarks;

        $overallPct = $totalMaxMarks > 0 ? ($totalObtained / $totalMaxMarks * 100) : 0.0;
        $result['average'] = $overallPct;
        $overallGradeId = MarkModel::gradeIdForScore($overallPct);
        $gradeRow = $overallGradeId ? Database::fetchOne('SELECT grade_letter FROM grades WHERE id = ?', 'i', [$overallGradeId]) : null;
        $overallGrade = $gradeRow ? (string)($gradeRow['grade_letter'] ?? '') : null;

        $eval = self::evaluateResult($passRule, $studentMarks, $overallPct);
        $result['resultStatus'] = $eval['result'];
        $result['failedSubjects'] = (int)$eval['failed_subjects'];
        $result['resultReasons'] = $eval['reasons'] ?? [];
        if (!empty($eval['force_grade_f'])) {
            $overallGrade = 'F';
        }
        if ($result['resultStatus'] === 'INCOMPLETE' || ($result['resultStatus'] === 'FAIL' && empty($studentMarks))) {
            $overallGrade = $overallGrade ?: 'F';
        }
        $result['overallGrade'] = $overallGrade;

        // Position/ranking is only meaningful for the real (combined, where
        // applicable) result — an "own marks only" partial-term view never
        // carries a class position or topper badge.
        if ($ownMarksOnly) {
            return $result;
        }

        if (!empty($studentMarks)) {
            $classRankings = self::classRankings($examId, false);
            $result['classRankings'] = $classRankings;
            $result['classSize'] = count($classRankings);
            $result['classToppers'] = array_values(array_filter($classRankings, function ($r) {
                return (int)$r['rank'] <= 3;
            }));
            foreach ($classRankings as $r) {
                if ((int)$r['student_id'] === $studentId) {
                    $result['studentRank'] = (int)$r['rank'];
                    break;
                }
            }
        }

        // A student can only be the whole-school topper if they fully passed
        // (PASS, not PROMOTE) and are in one of the eligible grades — check
        // school-wide, not just within their own class.
        if ($result['resultStatus'] === 'PASS' && $examRow) {
            if (in_array($examRow['class_name'], self::schoolTopperClassNames(), true)) {
                $schoolTop = self::schoolTopper((string)$examRow['exam_name'], $includeUnpublishedForSchoolTopper);
                foreach ($schoolTop['toppers'] as $t) {
                    if ((int)$t['student_id'] === $studentId) {
                        $result['isSchoolTopper'] = true;
                        break;
                    }
                }
            }
        }

        return $result;
    }
}