<?php

class SubjectModel
{
    public static function ensureClassIdColumn(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        try {
            $col = Database::fetchOne("SHOW COLUMNS FROM subjects LIKE 'class_id'");
            if (!$col) {
                Database::execute(
                    'ALTER TABLE subjects ADD COLUMN class_id INT NULL AFTER subject_name'
                );
                try {
                    Database::execute(
                        'ALTER TABLE subjects
                         ADD CONSTRAINT fk_subjects_class
                         FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE SET NULL'
                    );
                } catch (Throwable $e) {
                    // FK may already exist or lack permission — column alone is enough
                }
            }
            self::backfillClassIdsFromNames();
        } catch (Throwable $e) {
            // ignore — run db/migrate_subject_class_id.sql manually if needed
        }
        self::ensureUniquePerClass();
        $done = true;
    }

    /**
     * Subject names used to be globally unique (one "Urdu" for the whole school),
     * which blocked every class from having its own Urdu subject. Now uniqueness
     * is scoped per class: "Urdu" can exist once per class, but not twice in the
     * same class. Drops the old global unique key and adds the composite one.
     */
    private static function ensureUniquePerClass(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        $done = true;
        try {
            $old = Database::fetchOne("SHOW INDEX FROM subjects WHERE Key_name = 'uq_subject_name'");
            if ($old) {
                Database::execute('ALTER TABLE subjects DROP INDEX uq_subject_name');
            }
        } catch (Throwable $e) {
            // ignore — lacks ALTER privilege, or already dropped
        }
        try {
            $new = Database::fetchOne("SHOW INDEX FROM subjects WHERE Key_name = 'uq_subject_class_name'");
            if (!$new) {
                Database::execute(
                    'ALTER TABLE subjects ADD UNIQUE KEY uq_subject_class_name (class_id, subject_name)'
                );
            }
        } catch (Throwable $e) {
            // ignore — e.g. duplicates already exist and must be cleaned up manually first
        }
    }

    /**
     * True if another subject with this name already exists in this class.
     * Pass $excludeId when editing so the subject being saved doesn't match itself.
     * class_id <=> ? (null-safe equals) so an unassigned subject only collides
     * with other unassigned subjects of the same name, not with every class.
     */
    public static function existsInClass(string $subjectName, ?int $classId, int $excludeId = 0): bool
    {
        self::ensureClassIdColumn();
        $subjectName = trim($subjectName);
        if ($subjectName === '') {
            return false;
        }
        $row = Database::fetchOne(
            'SELECT id FROM subjects
             WHERE subject_name = ?
               AND class_id <=> ?
               AND id <> ?
             LIMIT 1',
            'sii',
            [$subjectName, $classId, $excludeId]
        );
        return (bool)$row;
    }

    /** Best-effort: match existing subject names like "Urdu Nursery" to class "Nursery". */
    private static function backfillClassIdsFromNames(): void
    {
        try {
            $classes = Database::fetchAll(
                'SELECT id, name FROM classes WHERE name IS NOT NULL AND name <> \'\' ORDER BY CHAR_LENGTH(name) DESC'
            );
            foreach ($classes as $c) {
                $name = trim((string)($c['name'] ?? ''));
                if ($name === '' || mb_strlen($name) < 2) {
                    continue;
                }
                $like = '%' . $name . '%';
                Database::execute(
                    'UPDATE subjects
                     SET class_id = ?
                     WHERE class_id IS NULL
                       AND (subject_name LIKE ? OR IFNULL(subject_code, \'\') LIKE ?)',
                    'iss',
                    [(int)$c['id'], $like, $like]
                );
            }
        } catch (Throwable $e) {
            // ignore
        }
    }

    public static function allOptions(): array
    {
        self::ensureClassIdColumn();
        return Database::fetchAll(
            'SELECT s.id, s.subject_name, s.class_id, c.name AS class_name
             FROM subjects s
             LEFT JOIN classes c ON c.id = s.class_id
             ORDER BY (c.name IS NULL), c.name, s.subject_name'
        );
    }

    /**
     * Subjects for a class/section: only subjects assigned to that class.
     * Unassigned subjects (class_id NULL) are excluded so Prep won't see Nursery subjects.
     */
    public static function optionsForClassSection(int $classSectionId): array
    {
        self::ensureClassIdColumn();
        if ($classSectionId <= 0) {
            return self::allOptions();
        }
        return Database::fetchAll(
            'SELECT s.id, s.subject_name, s.class_id
             FROM subjects s
             JOIN class_sections cs ON cs.id = ?
             WHERE s.class_id = cs.class_id
             ORDER BY s.subject_name',
            'i',
            [$classSectionId]
        );
    }

    public static function optionsForClass(int $classId): array
    {
        self::ensureClassIdColumn();
        if ($classId <= 0) {
            return self::allOptions();
        }
        return Database::fetchAll(
            'SELECT id, subject_name, class_id
             FROM subjects
             WHERE class_id = ?
             ORDER BY subject_name',
            'i',
            [$classId]
        );
    }

    public static function list(string $search = '', int $limit = 20, int $offset = 0): array
    {
        self::ensureClassIdColumn();
        $search = trim($search);
        $like = '%' . $search . '%';
        return Database::fetchAll(
            'SELECT s.*, c.name AS class_name
             FROM subjects s
             LEFT JOIN classes c ON c.id = s.class_id
             WHERE (? = \'\' OR s.subject_name LIKE ? OR s.subject_code LIKE ? OR c.name LIKE ?)
             ORDER BY s.id DESC
             LIMIT ? OFFSET ?',
            'ssssii',
            [$search, $like, $like, $like, $limit, $offset]
        );
    }

    public static function count(string $search = ''): int
    {
        self::ensureClassIdColumn();
        $search = trim($search);
        $like = '%' . $search . '%';
        $row = Database::fetchOne(
            'SELECT COUNT(*) AS cnt
             FROM subjects s
             LEFT JOIN classes c ON c.id = s.class_id
             WHERE (? = \'\' OR s.subject_name LIKE ? OR s.subject_code LIKE ? OR c.name LIKE ?)',
            'ssss',
            [$search, $like, $like, $like]
        );
        return (int)($row['cnt'] ?? 0);
    }

    public static function getById(int $id): ?array
    {
        self::ensureClassIdColumn();
        return Database::fetchOne(
            'SELECT s.*, c.name AS class_name
             FROM subjects s
             LEFT JOIN classes c ON c.id = s.class_id
             WHERE s.id = ?',
            'i',
            [$id]
        );
    }

    public static function create(array $data): int
    {
        self::ensureClassIdColumn();
        try {
            Database::execute(
                'INSERT INTO subjects (subject_code, subject_name, class_id)
                 VALUES (?, ?, ?)',
                'ssi',
                [
                    trim((string)($data['subject_code'] ?? '')) ?: null,
                    trim((string)($data['subject_name'] ?? '')),
                    !empty($data['class_id']) ? (int)$data['class_id'] : null,
                ]
            );
        } catch (mysqli_sql_exception $e) {
            throw self::friendlyDuplicateError($e);
        }
        return (int)Database::lastInsertId();
    }

    public static function update(int $id, array $data): void
    {
        self::ensureClassIdColumn();
        try {
            Database::execute(
                'UPDATE subjects
                 SET subject_code = ?, subject_name = ?, class_id = ?
                 WHERE id = ?',
                'ssii',
                [
                    trim((string)($data['subject_code'] ?? '')) ?: null,
                    trim((string)($data['subject_name'] ?? '')),
                    !empty($data['class_id']) ? (int)$data['class_id'] : null,
                    $id
                ]
            );
        } catch (mysqli_sql_exception $e) {
            throw self::friendlyDuplicateError($e);
        }
    }

    /**
     * Translates the raw MySQL duplicate-key error (1062) into a message a user
     * can actually read. This is a safety net for a race condition (two admins
     * saving the same subject at the same instant) — the normal path is the
     * controller's own existsInClass() check before it ever reaches here.
     */
    private static function friendlyDuplicateError(mysqli_sql_exception $e): Throwable
    {
        if ((int)$e->getCode() === 1062) {
            if (str_contains($e->getMessage(), 'uq_subject_class_name')) {
                return new InvalidArgumentException('This subject name already exists in the selected class.');
            }
            if (str_contains($e->getMessage(), 'uq_subject_code')) {
                return new InvalidArgumentException('This subject code is already in use.');
            }
        }
        return $e;
    }

    /**
     * Merge a duplicate subject into another: reassigns every timetable entry, exam
     * date-sheet row, mark, staff assignment, and attendance record from $fromId to
     * $intoId (dropping any row that would otherwise collide with an existing unique
     * row under $intoId), then deletes $fromId. Safe to re-run if interrupted.
     */
    public static function merge(int $fromId, int $intoId): void
    {
        self::ensureClassIdColumn();
        if ($fromId <= 0 || $intoId <= 0 || $fromId === $intoId) {
            throw new InvalidArgumentException('Choose two different subjects to merge.');
        }
        if (class_exists('ExamSubjectScheduleModel')) {
            ExamSubjectScheduleModel::ensureTable();
        }

        $conn = Database::connection();
        $conn->begin_transaction();
        try {
            // Timetable entries: no uniqueness on subject, so a plain reassign is safe.
            Database::execute('UPDATE timetable_entries SET subject_id = ? WHERE subject_id = ?', 'ii', [$intoId, $fromId]);

            // exam_subject_schedule: unique (exam_id, subject_id) — drop from-rows that would collide.
            Database::execute(
                'DELETE ess1 FROM exam_subject_schedule ess1
                 JOIN exam_subject_schedule ess2 ON ess2.exam_id = ess1.exam_id AND ess2.subject_id = ?
                 WHERE ess1.subject_id = ?',
                'ii', [$intoId, $fromId]
            );
            Database::execute('UPDATE exam_subject_schedule SET subject_id = ? WHERE subject_id = ?', 'ii', [$intoId, $fromId]);

            // marks: unique (exam_id, student_id, subject_id) — keep the existing mark under $intoId if both exist.
            Database::execute(
                'DELETE m1 FROM marks m1
                 JOIN marks m2 ON m2.exam_id = m1.exam_id AND m2.student_id = m1.student_id AND m2.subject_id = ?
                 WHERE m1.subject_id = ?',
                'ii', [$intoId, $fromId]
            );
            Database::execute('UPDATE marks SET subject_id = ? WHERE subject_id = ?', 'ii', [$intoId, $fromId]);

            // staff_subject_assignments: unique (staff_profile_id, subject_id).
            Database::execute(
                'DELETE a1 FROM staff_subject_assignments a1
                 JOIN staff_subject_assignments a2 ON a2.staff_profile_id = a1.staff_profile_id AND a2.subject_id = ?
                 WHERE a1.subject_id = ?',
                'ii', [$intoId, $fromId]
            );
            Database::execute('UPDATE staff_subject_assignments SET subject_id = ? WHERE subject_id = ?', 'ii', [$intoId, $fromId]);

            // attendance_records: unique (student_id, class_section_id, subject_id, attendance_date).
            Database::execute(
                'DELETE r1 FROM attendance_records r1
                 JOIN attendance_records r2 ON r2.student_id = r1.student_id
                      AND r2.class_section_id = r1.class_section_id
                      AND r2.subject_id = ? AND r2.attendance_date = r1.attendance_date
                 WHERE r1.subject_id = ?',
                'ii', [$intoId, $fromId]
            );
            Database::execute('UPDATE attendance_records SET subject_id = ? WHERE subject_id = ?', 'ii', [$intoId, $fromId]);

            Database::execute('DELETE FROM subjects WHERE id = ?', 'i', [$fromId]);

            $conn->commit();
        } catch (Throwable $e) {
            $conn->rollback();
            throw $e;
        }
    }

    public static function delete(int $id): void
    {
        Database::execute('DELETE FROM subjects WHERE id = ?', 'i', [$id]);
    }
}