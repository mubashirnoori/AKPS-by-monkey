<?php

/**
 * All queries here are deliberately scoped by a specific student_id / staff_profile_id /
 * guardian_id — never a blanket "all students" or "all staff" query. This is what keeps
 * the Student / Teacher / Parent / Accountant portals limited to each person's own data.
 */
class PortalModel
{
    // -----------------------------------------------------------------
    // Student
    // -----------------------------------------------------------------

    public static function studentProfile(int $studentId): ?array
    {
        require_once __DIR__ . '/StudentModel.php';
        return StudentModel::getById($studentId);
    }

    public static function studentAttendanceSummary(int $studentId, int $days = 30): array
    {
        $row = Database::fetchOne(
            "SELECT
                SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) AS present_count,
                SUM(CASE WHEN status = 'absent' THEN 1 ELSE 0 END) AS absent_count,
                SUM(CASE WHEN status = 'late' THEN 1 ELSE 0 END) AS late_count,
                SUM(CASE WHEN status = 'excused' THEN 1 ELSE 0 END) AS excused_count,
                COUNT(*) AS total_count
             FROM attendance_records
             WHERE student_id = ?
               AND attendance_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY)",
            'ii',
            [$studentId, $days]
        );
        $total = (int)($row['total_count'] ?? 0);
        $present = (int)($row['present_count'] ?? 0);
        return [
            'present' => $present,
            'absent' => (int)($row['absent_count'] ?? 0),
            'late' => (int)($row['late_count'] ?? 0),
            'excused' => (int)($row['excused_count'] ?? 0),
            'total' => $total,
            'percentage' => $total > 0 ? round(($present / $total) * 100, 1) : null,
        ];
    }

    /** Exam results for one student only — never other students' marks. */
    public static function studentResults(int $studentId, int $limit = 30): array
    {
        return Database::fetchAll(
            "SELECT m.score, m.subject_id, s.subject_name, m.exam_id, e.exam_name, e.scheduled_date,
                    g.grade_letter, et.name AS exam_type_name
             FROM marks m
             JOIN subjects s ON s.id = m.subject_id
             JOIN exams e ON e.id = m.exam_id
             JOIN exam_groups eg ON eg.id = e.exam_group_id
             JOIN exam_types et ON et.id = eg.exam_type_id
             LEFT JOIN grades g ON g.id = m.grade_id
             WHERE m.student_id = ?
               AND e.results_published = 1
             ORDER BY e.scheduled_date DESC, e.id DESC
             LIMIT ?",
            'ii',
            [$studentId, $limit]
        );
    }

    /** Exams with officially announced results that this student has marks for — for the portal Report Card exam picker. */
    public static function studentPublishedExams(int $studentId): array
    {
        require_once __DIR__ . '/ExamModel.php';

        $rows = Database::fetchAll(
            "SELECT DISTINCT e.id, e.exam_name, e.scheduled_date, e.cumulative_source_exam_name,
                    e.class_section_id, e.academic_year_id
             FROM marks m
             JOIN exams e ON e.id = m.exam_id
             WHERE m.student_id = ? AND e.results_published = 1",
            'i',
            [$studentId]
        );

        $byId = [];
        foreach ($rows as $r) {
            $byId[(int)$r['id']] = $r;
        }

        // If a published exam combines with an earlier exam (e.g. Final Term
        // with First Term), also surface that earlier exam — even if it
        // wasn't separately published — so a parent/student isn't stuck
        // seeing only the combined result with no way to see the term-by-term
        // breakdown behind it. (If the source WAS independently published
        // already, it's already in $byId and this is a no-op.)
        foreach ($rows as $r) {
            $sourceId = ExamModel::resolveCumulativeSourceExamId($r);
            if ($sourceId && !isset($byId[$sourceId])) {
                $hasMarks = Database::fetchOne(
                    'SELECT 1 FROM marks WHERE exam_id = ? AND student_id = ? LIMIT 1',
                    'ii',
                    [$sourceId, $studentId]
                );
                if ($hasMarks) {
                    $src = ExamModel::getExam($sourceId);
                    if ($src) {
                        $byId[$sourceId] = $src;
                    }
                }
            }
        }

        $out = array_values($byId);
        usort($out, static function ($a, $b) {
            $byDate = strcmp((string)($b['scheduled_date'] ?? ''), (string)($a['scheduled_date'] ?? ''));
            return $byDate !== 0 ? $byDate : ((int)$b['id'] <=> (int)$a['id']);
        });

        return $out;
    }

    /** Count of exams this student has marks in that aren't announced yet — shown as a status note, never scores. */
    public static function studentPendingResultsCount(int $studentId): int
    {
        $row = Database::fetchOne(
            "SELECT COUNT(DISTINCT m.exam_id) AS c
             FROM marks m
             JOIN exams e ON e.id = m.exam_id
             WHERE m.student_id = ? AND e.results_published = 0",
            'i',
            [$studentId]
        );
        return (int)($row['c'] ?? 0);
    }

    /** Fee invoices for one student only, with amount paid / pending. */
    /** Recent invoices for the dashboard summary card — full history lives on its own page. */
    public static function studentFeeInvoices(int $studentId, int $limit = 5): array
    {
        require_once __DIR__ . '/FeeInvoiceModel.php';
        return FeeInvoiceModel::getStudentInvoices($studentId, null, $limit);
    }

    public static function studentFeeInvoicesCount(int $studentId): int
    {
        require_once __DIR__ . '/FeeInvoiceModel.php';
        return FeeInvoiceModel::countStudentInvoices($studentId);
    }

    public static function studentFeeInvoicesPage(int $studentId, int $perPage, int $offset): array
    {
        require_once __DIR__ . '/FeeInvoiceModel.php';
        return FeeInvoiceModel::getStudentInvoices($studentId, null, $perPage, $offset);
    }

    public static function studentTimetable(int $classSectionId): array
    {
        require_once __DIR__ . '/TimetableModel.php';
        return TimetableModel::listByClassSection($classSectionId);
    }

    public static function studentCourses(int $studentId): array
    {
        require_once __DIR__ . '/OnlineCourseModel.php';
        $courses = OnlineCourseModel::listForStudent($studentId);
        foreach ($courses as &$course) {
            $resources = OnlineCourseModel::listResources((int)$course['id']);
            foreach ($resources as &$resource) {
                if ($resource['resource_type'] === 'video' && $resource['source_type'] === 'upload') {
                    $progress = OnlineCourseModel::getProgressForStudent((int)$resource['id'], $studentId);
                    $resource['my_progress_percent'] = $progress ? round((float)$progress['progress_percent'], 1) : 0;
                    $resource['my_last_position'] = $progress ? (int)$progress['last_position_seconds'] : 0;
                } else {
                    $resource['my_progress_percent'] = null;
                    $resource['my_last_position'] = 0;
                }
            }
            unset($resource);
            $course['resources'] = $resources;
        }
        unset($course);
        return $courses;
    }

    /**
     * One course + its ordered resources (with this student's watch progress
     * attached), for the per-course "curriculum" page. Returns null if the
     * course isn't actually assigned to this student — callers must check.
     */
    public static function studentCourseDetail(int $studentId, int $courseId): ?array
    {
        require_once __DIR__ . '/OnlineCourseModel.php';

        if (!OnlineCourseModel::isAssignedToStudent($courseId, $studentId)) {
            return null;
        }

        $course = OnlineCourseModel::getById($courseId);
        if (!$course) {
            return null;
        }

        $resources = OnlineCourseModel::listResources($courseId);
        foreach ($resources as &$resource) {
            if ($resource['resource_type'] === 'video' && $resource['source_type'] === 'upload') {
                $progress = OnlineCourseModel::getProgressForStudent((int)$resource['id'], $studentId);
                $resource['my_progress_percent'] = $progress ? round((float)$progress['progress_percent'], 1) : 0;
                $resource['my_last_position'] = $progress ? (int)$progress['last_position_seconds'] : 0;
            } else {
                $resource['my_progress_percent'] = null;
                $resource['my_last_position'] = 0;
            }
        }
        unset($resource);

        $course['resources'] = $resources;
        return $course;
    }

    public static function studentOwnLeaveRequests(int $studentId, int $limit = 10): array
    {
        require_once __DIR__ . '/LeaveRequestModel.php';
        return LeaveRequestModel::listForStudent($studentId, $limit);
    }

    // -----------------------------------------------------------------
    // Parent / Guardian
    // -----------------------------------------------------------------

    /** Children linked to a guardian, with their current class label. */
    public static function guardianChildren(int $guardianId): array
    {
        return Database::fetchAll(
            'SELECT s.id, s.first_name, s.last_name, s.admission_no,
                    c.name AS class_name, sec.name AS section_name
             FROM student_guardians sg
             JOIN students s ON s.id = sg.student_id
             LEFT JOIN student_class_assignments sca
               ON sca.id = (
                 SELECT sca2.id FROM student_class_assignments sca2
                 WHERE sca2.student_id = s.id
                 ORDER BY sca2.assigned_at DESC, sca2.id DESC LIMIT 1
               )
             LEFT JOIN class_sections cs ON cs.id = sca.class_section_id
             LEFT JOIN classes c ON c.id = cs.class_id
             LEFT JOIN sections sec ON sec.id = cs.section_id
             WHERE sg.guardian_id = ?
             ORDER BY sg.is_primary DESC, s.first_name',
            'i',
            [$guardianId]
        );
    }

    // -----------------------------------------------------------------
    // Teacher
    // -----------------------------------------------------------------

    public static function teacherProfile(int $staffProfileId): ?array
    {
        return Database::fetchOne(
            'SELECT id, full_name, title, staff_code FROM staff_profiles WHERE id = ?',
            'i',
            [$staffProfileId]
        );
    }

    /** Subjects + class assigned to the logged-in teacher only. */
    public static function teacherSubjects(int $staffProfileId): array
    {
        return Database::fetchAll(
            'SELECT s.id AS subject_id, s.subject_name, c.id AS class_id, c.name AS class_name
             FROM staff_subject_assignments ssa
             JOIN subjects s ON s.id = ssa.subject_id
             LEFT JOIN classes c ON c.id = s.class_id
             WHERE ssa.staff_profile_id = ?
             ORDER BY c.name, s.subject_name',
            'i',
            [$staffProfileId]
        );
    }

    /** Head-count of students in the teacher's classes (not full student records). */
    public static function teacherClassStudentCounts(array $classSectionIds): array
    {
        if (empty($classSectionIds)) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($classSectionIds), '?'));
        $types = str_repeat('i', count($classSectionIds));
        return Database::fetchAll(
            "SELECT cs.id AS class_section_id, c.name AS class_name, sec.name AS section_name,
                    COUNT(sca.student_id) AS student_count
             FROM class_sections cs
             LEFT JOIN classes c ON c.id = cs.class_id
             LEFT JOIN sections sec ON sec.id = cs.section_id
             LEFT JOIN student_class_assignments sca ON sca.class_section_id = cs.id
             WHERE cs.id IN ($placeholders)
             GROUP BY cs.id, c.name, sec.name
             ORDER BY c.name, sec.name",
            $types,
            $classSectionIds
        );
    }

    /** Own attendance history — a teacher may only see their own, never other staff. */
    /** This teacher's own weekly schedule, across every class/section they're assigned to teach. */
    public static function teacherTimetable(int $staffProfileId): array
    {
        require_once __DIR__ . '/TimetableModel.php';
        return TimetableModel::listByTeacher($staffProfileId);
    }

    public static function teacherOwnAttendance(int $staffProfileId, int $days = 30): array
    {
        return Database::fetchAll(
            'SELECT attendance_date, status
             FROM staff_attendance_records
             WHERE staff_profile_id = ?
               AND attendance_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
             ORDER BY attendance_date DESC',
            'ii',
            [$staffProfileId, $days]
        );
    }

    public static function teacherOwnLeaveRequests(int $staffProfileId, int $limit = 10): array
    {
        require_once __DIR__ . '/LeaveRequestModel.php';
        return LeaveRequestModel::listForStaff($staffProfileId, $limit);
    }

    public static function teacherOwnPerformanceReports(int $staffProfileId): array
    {
        return Database::fetchAll(
            'SELECT * FROM performance_reports WHERE staff_profile_id = ? ORDER BY period_end DESC, id DESC',
            'i',
            [$staffProfileId]
        );
    }

    /** This teacher's own recent actions (attendance taken, marks entered, leave applied, etc.) — never other staff's. */
    public static function teacherOwnRecentActivities(int $userId, int $limit = 8): array
    {
        return Database::fetchAll(
            'SELECT action, description, created_at FROM activity_log WHERE user_id = ? ORDER BY id DESC LIMIT ?',
            'ii',
            [$userId, $limit]
        );
    }

    // -----------------------------------------------------------------
    // Accountant (fee data across students — but never HR / payroll / settings)
    // -----------------------------------------------------------------

    public static function accountantTodayCollections(): float
    {
        $row = Database::fetchOne(
            "SELECT COALESCE(SUM(amount),0) AS s FROM fee_collections WHERE DATE(collected_at) = CURDATE()"
        );
        return (float)($row['s'] ?? 0);
    }

    public static function accountantMonthCollections(): float
    {
        $row = Database::fetchOne(
            "SELECT COALESCE(SUM(amount),0) AS s FROM fee_collections
             WHERE YEAR(collected_at) = YEAR(CURDATE()) AND MONTH(collected_at) = MONTH(CURDATE())"
        );
        return (float)($row['s'] ?? 0);
    }

    public static function accountantPendingDuesTotal(): float
    {
        $row = Database::fetchOne('SELECT COALESCE(SUM(pending_amount),0) AS s FROM pending_dues_view WHERE pending_amount > 0');
        return (float)($row['s'] ?? 0);
    }

    public static function accountantRecentCollections(int $limit = 15): array
    {
        return Database::fetchAll(
            'SELECT fc.collected_at, fc.amount, fc.method, s.first_name, s.last_name, s.admission_no
             FROM fee_collections fc
             JOIN fee_invoices fi ON fi.id = fc.fee_invoice_id
             JOIN students s ON s.id = fi.student_id
             ORDER BY fc.collected_at DESC
             LIMIT ?',
            'i',
            [$limit]
        );
    }

    public static function accountantTopPendingDues(int $limit = 15): array
    {
        return Database::fetchAll(
            'SELECT pdv.pending_amount, s.first_name, s.last_name, s.admission_no, fi.invoice_no
             FROM pending_dues_view pdv
             JOIN fee_invoices fi ON fi.id = pdv.fee_invoice_id
             JOIN students s ON s.id = pdv.student_id
             WHERE pdv.pending_amount > 0
             ORDER BY pdv.pending_amount DESC
             LIMIT ?',
            'i',
            [$limit]
        );
    }
}
