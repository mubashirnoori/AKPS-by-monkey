<?php

class InquiriesModel
{
    public static function generateInquiryNo(): string
    {
        return 'INQ-' . date('Ymd') . '-' . substr(uniqid((string)mt_rand(), true), -6);
    }

    public static function list(string $search, ?string $status, int $limit, int $offset): array
    {
        $search = trim($search);
        $searchLike = '%' . $search . '%';
        $statusVal = $status ? (string)$status : '';

        return Database::fetchAll(
            'SELECT i.*,
                    c.name AS class_name,
                    s.name AS section_name,
                    u.username AS reviewed_by_username
             FROM inquiries i
             LEFT JOIN classes c ON c.id = i.requested_class_id
             LEFT JOIN sections s ON s.id = i.requested_section_id
             LEFT JOIN users u ON u.id = i.reviewed_by_user_id
             WHERE ( ? = \'\' OR i.inquiry_no LIKE ? OR i.requested_first_name LIKE ? OR i.requested_last_name LIKE ? OR i.phone LIKE ? )
               AND ( ? = \'\' OR i.status = ? )
             ORDER BY i.id DESC
             LIMIT ? OFFSET ?',
            'sssssssii',
            [
                $search,
                $searchLike,
                $searchLike,
                $searchLike,
                $searchLike,
                $statusVal,
                $statusVal,
                $limit,
                $offset
            ]
        );
    }

    public static function count(string $search, ?string $status): int
    {
        $search = trim($search);
        $searchLike = '%' . $search . '%';
        $statusVal = $status ? (string)$status : '';

        $row = Database::fetchOne(
            'SELECT COUNT(*) AS cnt
             FROM inquiries i
             WHERE ( ? = \'\' OR i.inquiry_no LIKE ? OR i.requested_first_name LIKE ? OR i.requested_last_name LIKE ? OR i.phone LIKE ? )
               AND ( ? = \'\' OR i.status = ? )',
            'sssssss',
            [
                $search,
                $searchLike,
                $searchLike,
                $searchLike,
                $searchLike,
                $statusVal,
                $statusVal
            ]
        );
        return (int)($row['cnt'] ?? 0);
    }

    public static function create(array $data, ?int $reviewedByUserId = null): int
    {
        $inquiryNo = (string)($data['inquiry_no'] ?? self::generateInquiryNo());

        Database::execute(
            'INSERT INTO inquiries
             (inquiry_no, requested_first_name, requested_last_name, phone, email, requested_class_id, requested_section_id, status, notes, reviewed_by_user_id)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            'sssssiissi',
            [
                $inquiryNo,
                (string)$data['requested_first_name'],
                (string)$data['requested_last_name'],
                (string)($data['phone'] ?? ''),
                (string)($data['email'] ?? ''),
                $data['requested_class_id'] ? (int)$data['requested_class_id'] : null,
                $data['requested_section_id'] ? (int)$data['requested_section_id'] : null,
                (string)($data['status'] ?? 'new'),
                (string)($data['notes'] ?? ''),
                $reviewedByUserId
            ]
        );

        return (int)Database::lastInsertId();
    }

    public static function updateStatus(int $inquiryId, string $status, ?string $notes, ?int $reviewedByUserId): void
    {
        Database::execute(
            'UPDATE inquiries
             SET status = ?, notes = ?, reviewed_by_user_id = ?, updated_at = NOW()
             WHERE id = ?',
            'ssii',
            [$status, $notes ?: null, $reviewedByUserId, $inquiryId]
        );
    }
}

