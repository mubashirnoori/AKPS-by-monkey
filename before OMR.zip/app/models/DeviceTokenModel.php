<?php

class DeviceTokenModel
{
    /**
     * Register (or refresh) a device token for a user. A token belongs to
     * exactly one device install, so if it was previously registered to a
     * different user (e.g. app reinstalled and a different person logged
     * in), it's re-pointed to the new user rather than duplicated.
     */
    public static function register(int $userId, string $fcmToken, string $platform = 'android'): void
    {
        if ($userId <= 0 || $fcmToken === '') {
            return;
        }
        Database::execute(
            'INSERT INTO device_tokens (user_id, fcm_token, platform, created_at, last_seen_at)
             VALUES (?, ?, ?, NOW(), NOW())
             ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), platform = VALUES(platform), last_seen_at = NOW()',
            'iss',
            [$userId, $fcmToken, $platform]
        );
    }

    public static function unregister(string $fcmToken): void
    {
        if ($fcmToken === '') {
            return;
        }
        Database::execute('DELETE FROM device_tokens WHERE fcm_token = ?', 's', [$fcmToken]);
    }

    /** All FCM tokens registered to a single user (they may have more than one device). */
    public static function tokensForUser(int $userId): array
    {
        $rows = Database::fetchAll('SELECT fcm_token FROM device_tokens WHERE user_id = ?', 'i', [$userId]);
        return array_map(static fn($r) => (string)$r['fcm_token'], $rows);
    }

    /** All FCM tokens registered to any of the given users, deduplicated. */
    public static function tokensForUsers(array $userIds): array
    {
        $userIds = array_values(array_unique(array_filter(array_map('intval', $userIds), static fn($id) => $id > 0)));
        if (empty($userIds)) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($userIds), '?'));
        $rows = Database::fetchAll(
            "SELECT DISTINCT fcm_token FROM device_tokens WHERE user_id IN ($placeholders)",
            str_repeat('i', count($userIds)),
            $userIds
        );
        return array_map(static fn($r) => (string)$r['fcm_token'], $rows);
    }
}
