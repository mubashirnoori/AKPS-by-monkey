<?php

class MarkModel
{
    public static function gradeIdForScore(float $score): ?int
    {
        $row = Database::fetchOne(
            'SELECT id
             FROM grades
             WHERE min_score <= ? AND max_score >= ?
             ORDER BY sort_order ASC
             LIMIT 1',
            'dd',
            [$score, $score]
        );
        return $row ? (int)$row['id'] : null;
    }

    public static function getExamClassSectionId(int $examId): ?int
    {
        $row = Database::fetchOne(
            'SELECT class_section_id FROM exams WHERE id = ?',
            'i',
            [$examId]
        );
        return $row ? ($row['class_section_id'] !== null ? (int)$row['class_section_id'] : null) : null;
    }

    public static function getMarksForExamSubject(int $examId, int $subjectId): array
    {
        return Database::fetchAll(
            'SELECT m.*,
                    s.admission_no,
                    s.first_name,
                    s.last_name
             FROM marks m
             JOIN students s ON s.id = m.student_id
             WHERE m.exam_id = ? AND m.subject_id = ?
             ORDER BY s.admission_no',
            'ii',
            [$examId, $subjectId]
        );
    }

    /**
     * Who most recently saved marks for this exam+subject, and when — shown
     * above the entry grid so admins/HOD can see who touched a subject's
     * marks last, without adding a name/timestamp column to every row (all
     * rows from one save share the same saver and near-identical timestamp).
     */
    public static function getLastSavedInfo(int $examId, int $subjectId): ?array
    {
        $row = Database::fetchOne(
            'SELECT u.username AS saved_by_name, m.updated_at
             FROM marks m
             LEFT JOIN users u ON u.id = m.updated_by_user_id
             WHERE m.exam_id = ? AND m.subject_id = ?
             ORDER BY m.updated_at DESC
             LIMIT 1',
            'ii',
            [$examId, $subjectId]
        );
        return $row ?: null;
    }

    public static function saveMarks(
        int $examId,
        int $subjectId,
        array $scoreByStudentId,
        ?int $savedByUserId,
        float $totalMarks = 100.0
    ): void {
        $classSectionId = self::getExamClassSectionId($examId);
        if (!$classSectionId) {
            throw new RuntimeException('Exam does not have a class section assigned.');
        }

        $exam = Database::fetchOne('SELECT results_published FROM exams WHERE id = ?', 'i', [$examId]);
        if ($exam && (int)($exam['results_published'] ?? 0) === 1) {
            throw new RuntimeException('Results for this exam are published and locked. Unpublish first to make corrections.');
        }

        $totalMarks = $totalMarks > 0 ? $totalMarks : 100.0;

        $conn = Database::connection();
        $conn->begin_transaction();
        try {
            foreach ($scoreByStudentId as $studentId => $scoreVal) {
                $studentId = (int)$studentId;
                if ($studentId <= 0) {
                    continue;
                }

                $scoreVal = trim((string)$scoreVal);
                $score = $scoreVal === '' ? 0.0 : (float)$scoreVal;
                // Grade is based on percentage of total_marks
                $percentage = $totalMarks > 0 ? ($score / $totalMarks * 100) : 0.0;
                $gradeId = self::gradeIdForScore($percentage);

                Database::execute(
                    'INSERT INTO marks (exam_id, student_id, class_section_id, subject_id, score, total_marks, grade_id, is_locked, entered_by_user_id, updated_by_user_id, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, NOW())
                     ON DUPLICATE KEY UPDATE
                       score = VALUES(score),
                       total_marks = VALUES(total_marks),
                       grade_id = VALUES(grade_id),
                       updated_by_user_id = VALUES(updated_by_user_id),
                       updated_at = NOW()',
                    'iiiiddiii',
                    [
                        $examId,
                        $studentId,
                        $classSectionId,
                        $subjectId,
                        $score,
                        $totalMarks,
                        $gradeId,
                        $savedByUserId,
                        $savedByUserId
                    ]
                );
            }
            $conn->commit();
        } catch (Throwable $e) {
            $conn->rollback();
            throw $e;
        }
    }
}

