<?php

/**
 * Teacher/Principal fee-collection handover ledger.
 *
 * The underlying source of truth for "how much a teacher collected" is
 * fee_collections.collected_by_user_id (already recorded by every payment,
 * whether taken from the admin Fees screen or the teacher portal's own fee
 * collection screen). This model adds the other half: how much of that
 * they've actually handed over to Admin/Principal, and what they're still
 * holding — the fee_handovers table it manages.
 */
class FeeHandoverModel
{
    /** Create a pending handover claim. Only counts toward "handed over" once confirmed. */
    public static function create(int $staffProfileId, float $amount, int $handedOverToUserId, ?string $note, int $submittedByUserId): int
    {
        Database::execute(
            'INSERT INTO fee_handovers (staff_profile_id, handed_over_by_user_id, amount, handed_over_to_user_id, note, status, created_at)
             VALUES (?, ?, ?, ?, ?, \'pending\', NOW())',
            'iidis',
            [$staffProfileId, $submittedByUserId, $amount, $handedOverToUserId, $note]
        );
        return (int)Database::connection()->insert_id;
    }

    public static function find(int $id): ?array
    {
        $row = Database::fetchOne('SELECT * FROM fee_handovers WHERE id = ? LIMIT 1', 'i', [$id]);
        return $row ?: null;
    }

    public static function confirm(int $id, int $confirmedByUserId): void
    {
        Database::execute(
            "UPDATE fee_handovers SET status = 'confirmed', confirmed_by_user_id = ?, confirmed_at = NOW(), rejection_reason = NULL
             WHERE id = ? AND status = 'pending'",
            'ii',
            [$confirmedByUserId, $id]
        );
    }

    public static function reject(int $id, int $confirmedByUserId, ?string $reason): void
    {
        Database::execute(
            "UPDATE fee_handovers SET status = 'rejected', confirmed_by_user_id = ?, confirmed_at = NOW(), rejection_reason = ?
             WHERE id = ? AND status = 'pending'",
            'isi',
            [$confirmedByUserId, $reason, $id]
        );
    }

    /**
     * Admin-only correction: change the amount and/or note on an existing handover
     * record (any status) — for fixing a typo or wrong figure after the fact. Does
     * not touch status/confirmation, so a corrected amount on a confirmed handover
     * immediately flows through to every ledger total, which is computed live.
     */
    public static function update(int $id, float $amount, ?string $note): void
    {
        Database::execute(
            'UPDATE fee_handovers SET amount = ?, note = ? WHERE id = ?',
            'dsi',
            [$amount, $note, $id]
        );
    }

    /** Admin-only: permanently remove a handover record entered in error. */
    public static function delete(int $id): void
    {
        Database::execute('DELETE FROM fee_handovers WHERE id = ?', 'i', [$id]);
    }

    /** Total count of on-behalf collections for a staff member (see onBehalfCollectionsForStaff below). */
    public static function onBehalfCollectionsCountForStaff(int $staffProfileId): int
    {
        $staff = Database::fetchOne('SELECT user_id FROM staff_profiles WHERE id = ? LIMIT 1', 'i', [$staffProfileId]);
        $userId = $staff ? (int)($staff['user_id'] ?? 0) : 0;
        if ($userId <= 0) {
            return 0;
        }

        $countRow = Database::fetchOne(
            'SELECT COUNT(*) AS total
             FROM fee_collections fc
             WHERE fc.collected_by_user_id = ? AND fc.entered_by_user_id IS NOT NULL',
            'i',
            [$userId]
        );
        return (int)($countRow['total'] ?? 0);
    }

    /**
     * Payments that were collected under this staff member's name (so they
     * count toward their ledger/net balance) but were physically taken by
     * someone else -- e.g. Admin collecting cash at the counter on behalf
     * of this teacher. Surfaced separately on "My Fee Ledger" so a teacher
     * isn't left wondering why their balance moved without them touching
     * any cash.
     *
     * Paginated — call onBehalfCollectionsCountForStaff() first to work out
     * how many pages there are.
     */
    public static function onBehalfCollectionsForStaff(int $staffProfileId, int $limit = 20, int $page = 1): array
    {
        $staff = Database::fetchOne('SELECT user_id FROM staff_profiles WHERE id = ? LIMIT 1', 'i', [$staffProfileId]);
        $userId = $staff ? (int)($staff['user_id'] ?? 0) : 0;
        if ($userId <= 0) {
            return [];
        }

        $page = max(1, $page);
        $offset = ($page - 1) * $limit;

        return Database::fetchAll(
            'SELECT fc.id, fc.amount, fc.collected_at, fc.method,
                    eu.username AS entered_by_name,
                    fi.invoice_no, s.first_name, s.last_name, s.admission_no
             FROM fee_collections fc
             JOIN users eu ON eu.id = fc.entered_by_user_id
             JOIN fee_invoices fi ON fi.id = fc.fee_invoice_id
             JOIN students s ON s.id = fi.student_id
             WHERE fc.collected_by_user_id = ? AND fc.entered_by_user_id IS NOT NULL
             ORDER BY fc.collected_at DESC, fc.id DESC
             LIMIT ? OFFSET ?',
            'iii',
            [$userId, $limit, $offset]
        );
    }

    /** Every handover a staff member has submitted, newest first, with recipient/confirmer names resolved. */
    public static function getForStaff(int $staffProfileId): array
    {
        return Database::fetchAll(
            'SELECT fh.*,
                    uto.username AS handed_to_name,
                    uconf.username AS confirmed_by_name
             FROM fee_handovers fh
             LEFT JOIN users uto ON uto.id = fh.handed_over_to_user_id
             LEFT JOIN users uconf ON uconf.id = fh.confirmed_by_user_id
             WHERE fh.staff_profile_id = ?
             ORDER BY fh.created_at DESC',
            'i',
            [$staffProfileId]
        );
    }

    /**
     * Collected / handed-over / net-balance totals for one staff member.
     * Collected is summed from fee_collections via that staff member's own
     * login (staff_profiles.user_id), since that's what every payment they
     * record is actually stamped with.
     */
    public static function ledgerForStaff(int $staffProfileId): array
    {
        $staff = Database::fetchOne('SELECT user_id FROM staff_profiles WHERE id = ? LIMIT 1', 'i', [$staffProfileId]);
        $userId = $staff ? (int)($staff['user_id'] ?? 0) : 0;

        $collected = 0.0;
        if ($userId > 0) {
            $row = Database::fetchOne(
                'SELECT COALESCE(SUM(amount), 0) AS total FROM fee_collections WHERE collected_by_user_id = ?',
                'i',
                [$userId]
            );
            $collected = (float)($row['total'] ?? 0);
        }

        $handedOver = Database::fetchOne(
            "SELECT COALESCE(SUM(amount), 0) AS total FROM fee_handovers WHERE staff_profile_id = ? AND status = 'confirmed'",
            'i',
            [$staffProfileId]
        );
        $handedOverTotal = (float)($handedOver['total'] ?? 0);

        $pending = Database::fetchOne(
            "SELECT COALESCE(SUM(amount), 0) AS total FROM fee_handovers WHERE staff_profile_id = ? AND status = 'pending'",
            'i',
            [$staffProfileId]
        );
        $pendingTotal = (float)($pending['total'] ?? 0);

        return [
            'collected' => $collected,
            'handed_over' => $handedOverTotal,
            'pending_handover' => $pendingTotal,
            // Net balance only credits CONFIRMED handovers, not pending ones --
            // an unconfirmed claim shouldn't quietly clear what a teacher is
            // shown as still holding.
            'net_balance' => $collected - $handedOverTotal,
        ];
    }

    /**
     * One row per staff member who has ever collected a fee payment or
     * submitted a handover, with their ledger totals — for the Admin/
     * Principal overview screen. Every number is computed with the same
     * logic as ledgerForStaff() so the two screens can never disagree.
     */
    /**
     * @return array{rows: array, total: int}
     */
    public static function ledgerForAllStaff(?int $academicYearId = null, int $page = 1, int $perPage = 20): array
    {
        $rows = Database::fetchAll(
            "SELECT sp.id AS staff_profile_id, sp.full_name, sp.title, u.id AS user_id
             FROM staff_profiles sp
             JOIN users u ON u.id = sp.user_id
             WHERE sp.user_id IN (SELECT DISTINCT collected_by_user_id FROM fee_collections WHERE collected_by_user_id IS NOT NULL)
                OR sp.id IN (SELECT DISTINCT staff_profile_id FROM fee_handovers)
             ORDER BY sp.full_name"
        );

        if (empty($rows)) {
            return ['rows' => [], 'total' => 0];
        }

        // Handovers are lump-sum cash movements with no invoice/academic-year
        // link of their own, so when a specific year is selected we scope
        // them by that year's date range instead.
        $handoverDateClause = '';
        $handoverDateParams = [];
        $handoverDateTypes = '';
        if ($academicYearId && $academicYearId > 0) {
            $ay = Database::fetchOne('SELECT start_date, end_date FROM academic_years WHERE id = ? LIMIT 1', 'i', [$academicYearId]);
            if ($ay && !empty($ay['start_date'])) {
                $handoverDateClause = ' AND fh.created_at >= ?';
                $handoverDateParams[] = $ay['start_date'] . ' 00:00:00';
                $handoverDateTypes .= 's';
                if (!empty($ay['end_date'])) {
                    $handoverDateClause .= ' AND fh.created_at <= ?';
                    $handoverDateParams[] = $ay['end_date'] . ' 23:59:59';
                    $handoverDateTypes .= 's';
                }
            }
        }

        $userIds = array_map(static fn($r) => (int)$r['user_id'], $rows);
        $staffIds = array_map(static fn($r) => (int)$r['staff_profile_id'], $rows);

        $collectedByUser = [];
        $uPh = implode(',', array_fill(0, count($userIds), '?'));
        $ayClause = '';
        $ayParams = [];
        $ayTypes = '';
        if ($academicYearId && $academicYearId > 0) {
            $ayClause = ' JOIN fee_invoices fi ON fi.id = fc.fee_invoice_id AND fi.academic_year_id = ?';
            $ayParams = [$academicYearId];
            $ayTypes = 'i';
        }
        $collectedRows = Database::fetchAll(
            "SELECT fc.collected_by_user_id, COALESCE(SUM(fc.amount), 0) AS total
             FROM fee_collections fc{$ayClause}
             WHERE fc.collected_by_user_id IN ($uPh) GROUP BY fc.collected_by_user_id",
            $ayTypes . str_repeat('i', count($userIds)),
            array_merge($ayParams, $userIds)
        );
        foreach ($collectedRows as $r) {
            $collectedByUser[(int)$r['collected_by_user_id']] = (float)$r['total'];
        }

        $handedOverByStaff = [];
        $pendingByStaff = [];
        $sPh = implode(',', array_fill(0, count($staffIds), '?'));
        $handoverRows = Database::fetchAll(
            "SELECT fh.staff_profile_id, fh.status, COALESCE(SUM(fh.amount), 0) AS total
             FROM fee_handovers fh
             WHERE fh.staff_profile_id IN ($sPh){$handoverDateClause}
             GROUP BY fh.staff_profile_id, fh.status",
            str_repeat('i', count($staffIds)) . $handoverDateTypes,
            array_merge($staffIds, $handoverDateParams)
        );
        foreach ($handoverRows as $r) {
            if ($r['status'] === 'confirmed') {
                $handedOverByStaff[(int)$r['staff_profile_id']] = (float)$r['total'];
            } elseif ($r['status'] === 'pending') {
                $pendingByStaff[(int)$r['staff_profile_id']] = (float)$r['total'];
            }
        }

        foreach ($rows as &$r) {
            $sid = (int)$r['staff_profile_id'];
            $uid = (int)$r['user_id'];
            $collected = $collectedByUser[$uid] ?? 0.0;
            $handedOver = $handedOverByStaff[$sid] ?? 0.0;
            $r['collected'] = $collected;
            $r['handed_over'] = $handedOver;
            $r['pending_handover'] = $pendingByStaff[$sid] ?? 0.0;
            $r['net_balance'] = $collected - $handedOver;
        }
        unset($r);

        // When filtered to a specific academic year, drop staff with zero
        // activity in that year entirely rather than showing an all-zero row.
        if ($academicYearId && $academicYearId > 0) {
            $rows = array_values(array_filter($rows, static function ($r) {
                return (float)$r['collected'] > 0 || (float)$r['handed_over'] > 0 || (float)$r['pending_handover'] > 0;
            }));
        }

        $total = count($rows);
        $page = max(1, $page);
        $perPage = $perPage > 0 ? $perPage : 20;
        $offset = ($page - 1) * $perPage;
        $pageRows = array_slice($rows, $offset, $perPage);

        return ['rows' => $pageRows, 'total' => $total];
    }

    /** Pending handovers awaiting a decision, newest first — for the confirm/reject queue. */
    public static function getPending(): array
    {
        return Database::fetchAll(
            "SELECT fh.*, sp.full_name AS staff_name, uto.username AS handed_to_name
             FROM fee_handovers fh
             JOIN staff_profiles sp ON sp.id = fh.staff_profile_id
             LEFT JOIN users uto ON uto.id = fh.handed_over_to_user_id
             WHERE fh.status = 'pending'
             ORDER BY fh.created_at ASC"
        );
    }

    /** Admin/Principal users a teacher can hand cash over to, for the recipient dropdown. */
    public static function possibleRecipients(): array
    {
        return Database::fetchAll(
            "SELECT u.id, u.username, r.name AS role_name
             FROM users u
             JOIN roles r ON r.id = u.role_id
             WHERE r.name IN ('Admin','Principal') AND u.status = 1
             ORDER BY r.name, u.username"
        );
    }
}
