<?php

class ExpenseModel
{
    public static function listCategories(): array
    {
        return Database::fetchAll('SELECT id, name FROM expense_categories ORDER BY name');
    }

    public static function createCategory(string $name): int
    {
        Database::execute(
            'INSERT INTO expense_categories (name) VALUES (?) ON DUPLICATE KEY UPDATE name = name',
            's',
            [$name]
        );
        $row = Database::fetchOne('SELECT id FROM expense_categories WHERE name = ?', 's', [$name]);
        return $row ? (int)$row['id'] : 0;
    }

    public static function renameCategory(int $id, string $name): void
    {
        Database::execute('UPDATE expense_categories SET name = ? WHERE id = ?', 'si', [$name, $id]);
    }

    /** Throws (FK constraint) if the category is still used by an expense; caller should show a friendly message. */
    public static function deleteCategory(int $id): void
    {
        Database::execute('DELETE FROM expense_categories WHERE id = ?', 'i', [$id]);
    }

    /** category_id => how many expenses use it, so the UI can warn before deleting. */
    public static function categoryUsageCounts(): array
    {
        $rows = Database::fetchAll('SELECT expense_category_id, COUNT(*) AS c FROM expenses GROUP BY expense_category_id');
        $map = [];
        foreach ($rows as $r) {
            $map[(int)$r['expense_category_id']] = (int)$r['c'];
        }
        return $map;
    }

    public static function getExpense(int $id): ?array
    {
        return Database::fetchOne('SELECT * FROM expenses WHERE id = ?', 'i', [$id]);
    }

    public static function create(int $categoryId, string $description, float $amount, string $expenseDate, ?int $byUserId): void
    {
        Database::execute(
            'INSERT INTO expenses (expense_category_id, description, amount, expense_date, added_by_user_id, created_at)
             VALUES (?, ?, ?, ?, ?, NOW())',
            'isdsi',
            [$categoryId, $description, $amount, $expenseDate, $byUserId]
        );
    }

    public static function update(int $id, int $categoryId, string $description, float $amount, string $expenseDate): void
    {
        Database::execute(
            'UPDATE expenses SET expense_category_id = ?, description = ?, amount = ?, expense_date = ? WHERE id = ?',
            'isdsi',
            [$categoryId, $description, $amount, $expenseDate, $id]
        );
    }

    public static function delete(int $id): void
    {
        Database::execute('DELETE FROM expenses WHERE id = ?', 'i', [$id]);
    }

    public static function list(int $month, int $year, int $categoryId = 0, string $search = ''): array
    {
        $sql = 'SELECT e.*, ec.name AS category_name
                FROM expenses e
                JOIN expense_categories ec ON ec.id = e.expense_category_id
                WHERE MONTH(e.expense_date) = ? AND YEAR(e.expense_date) = ?';
        $types = 'ii';
        $params = [$month, $year];

        if ($categoryId > 0) {
            $sql .= ' AND e.expense_category_id = ?';
            $types .= 'i';
            $params[] = $categoryId;
        }
        if (trim($search) !== '') {
            $sql .= ' AND e.description LIKE ?';
            $types .= 's';
            $params[] = '%' . trim($search) . '%';
        }

        $sql .= ' ORDER BY e.expense_date DESC, e.id DESC LIMIT 300';

        return Database::fetchAll($sql, $types, $params);
    }

    public static function totalForMonth(int $month, int $year): float
    {
        $row = Database::fetchOne(
            'SELECT COALESCE(SUM(amount), 0) AS total FROM expenses WHERE MONTH(expense_date) = ? AND YEAR(expense_date) = ?',
            'ii',
            [$month, $year]
        );
        return (float)($row['total'] ?? 0);
    }

    public static function totalForYear(int $year): float
    {
        $row = Database::fetchOne(
            'SELECT COALESCE(SUM(amount), 0) AS total FROM expenses WHERE YEAR(expense_date) = ?',
            'i',
            [$year]
        );
        return (float)($row['total'] ?? 0);
    }
}
