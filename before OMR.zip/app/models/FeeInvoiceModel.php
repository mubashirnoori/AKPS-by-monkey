<?php

/**
 * FeeInvoiceModel
 * Handles invoice data operations (deprecated logic moved to FeeService)
 */
class FeeInvoiceModel
{
    private static function generateInvoiceNo(): string
    {
        return 'INV-' . date('Ymd') . '-' . substr(uniqid((string)mt_rand(), true), -6);
    }

    /**
     * Turns the comma-separated billing_months_raw column (produced by the
     * GROUP_CONCAT subquery in getStudentInvoices/list queries) into a
     * display string like "Apr 2026" or "Mar 2026, Apr 2026". Returns '—' for invoices
     * with no billing month at all (e.g. a one-time admission fee invoice).
     */
    public static function formatBillingMonths(?string $rawMonths): string
    {
        $rawMonths = trim((string)$rawMonths);
        if ($rawMonths === '') {
            return '—';
        }
        static $monthNames = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'May', 6 => 'Jun',
            7 => 'Jul', 8 => 'Aug', 9 => 'Sep', 10 => 'Oct', 11 => 'Nov', 12 => 'Dec',
        ];
        $labels = [];
        // Each entry is "YYYY-M" (or just "M" when the line has no billing_year).
        foreach (explode(',', $rawMonths) as $entry) {
            $parts = explode('-', trim($entry));
            $m = (int)end($parts);
            $y = count($parts) > 1 ? (int)$parts[0] : 0;
            if (isset($monthNames[$m])) {
                $labels[] = $monthNames[$m] . ($y > 0 ? ' ' . $y : '');
            }
        }
        return $labels ? implode(', ', $labels) : '—';
    }

    /**
     * Legacy method - delegates to FeeService for student invoice creation
     * @deprecated Use FeeService::createStudentInvoice instead
     */
    public static function createInvoiceForStudent(int $studentId, ?int $academicYearId, ?int $createdByUserId): int
    {
        $result = FeeService::createStudentInvoice(
            $studentId,
            $academicYearId,
            false, // No admission fee by default for backward compatibility
            [], // No specific months
            $createdByUserId
        );
        return (int)$result['invoice_id'];
    }

    public static function getInvoice(int $invoiceId): ?array
    {
        $invoice = Database::fetchOne(
            'SELECT fi.*, s.first_name, s.last_name, s.father_name, s.admission_no
             FROM fee_invoices fi
             JOIN students s ON s.id = fi.student_id
             WHERE fi.id = ?',
            'i',
            [$invoiceId]
        );

        if ($invoice) {
            // Add collections summary
            $collected = Database::fetchOne(
                'SELECT COALESCE(SUM(amount), 0) AS collected_amount
                 FROM fee_collections
                 WHERE fee_invoice_id = ?',
                'i',
                [$invoiceId]
            );
            if ($collected) {
                $invoice['collected_amount'] = (float)$collected['collected_amount'];
                $invoice['pending_balance'] = (float)$invoice['total_due'] - (float)$invoice['collected_amount'];
            }
        }

        return $invoice;
    }

    public static function getInvoiceLines(int $invoiceId): array
    {
        return Database::fetchAll(
            'SELECT fil.*,
                    fc.name AS fee_category_name
             FROM fee_invoice_lines fil
             JOIN fee_categories fc ON fc.id = fil.fee_category_id
             WHERE fil.fee_invoice_id = ?
             ORDER BY fil.id ASC',
            'i',
            [$invoiceId]
        );
    }

    /**
     * Record a cash collection - delegates to FeeService
     * @deprecated Use FeeService::recordPayment instead
     */
    public static function addCashCollection(int $invoiceId, float $amount, ?string $notes, ?int $collectedByUserId): void
    {
        FeeService::applyAutomaticFineIfOverdue($invoiceId);
        FeeService::recordPayment($invoiceId, $amount, 'cash', $notes, $collectedByUserId);
    }

    /**
     * Get invoice custom fines
     */
    public static function getInvoiceFines(int $invoiceId): array
    {
        return Database::fetchAll(
            'SELECT * FROM fee_custom_fines
             WHERE fee_invoice_id = ?
             ORDER BY id DESC',
            'i',
            [$invoiceId]
        );
    }

    /**
     * Get invoice collections
     */
    public static function getInvoiceCollections(int $invoiceId): array
    {
        return Database::fetchAll(
            'SELECT fc.*,
                    u.username AS collected_by_name
             FROM fee_collections fc
             LEFT JOIN users u ON u.id = fc.collected_by_user_id
             WHERE fc.fee_invoice_id = ?
             ORDER BY fc.collected_at DESC',
            'i',
            [$invoiceId]
        );
    }

    /**
     * Cancel an invoice
     */
    public static function cancelInvoice(int $invoiceId, ?string $reason = null): void
    {
        Database::execute(
            'UPDATE fee_invoices SET status = ?, note = ? WHERE id = ?',
            'ssi',
            ['cancelled', $reason ?? '', $invoiceId]
        );
    }

    /**
     * Update editable invoice header fields (due date / status)
     */
    public static function updateInvoiceMeta(int $invoiceId, array $data): void
    {
        Database::execute(
            'UPDATE fee_invoices SET due_date = ?, status = ? WHERE id = ?',
            'ssi',
            [
                $data['due_date'] ?? null,
                $data['status'] ?? 'open',
                $invoiceId,
            ]
        );
    }

    /**
     * Update a single invoice line's amounts
     */
    public static function updateInvoiceLine(int $lineId, float $baseAmount, float $discountAmount): void
    {
        $lineTotal = max(0, $baseAmount - $discountAmount);
        Database::execute(
            'UPDATE fee_invoice_lines SET base_amount = ?, discount_amount = ?, line_total = ? WHERE id = ?',
            'dddi',
            [$baseAmount, $discountAmount, $lineTotal, $lineId]
        );
    }

    /**
     * Permanently delete an invoice (cascades to lines, collections, and fines)
     */
    public static function deleteInvoice(int $invoiceId): void
    {
        Database::execute('DELETE FROM fee_invoices WHERE id = ?', 'i', [$invoiceId]);
    }

    /**
     * Get student invoices
     */
    public static function getStudentInvoices(int $studentId, ?int $academicYearId = null, int $limit = 50, int $offset = 0): array
    {
        $query = 'SELECT fi.*,
                         COALESCE(SUM(fc.amount), 0) AS collected_amount,
                         (
                             SELECT GROUP_CONCAT(DISTINCT CONCAT_WS(\'-\', fil.billing_year, fil.billing_month) ORDER BY fil.billing_year, fil.billing_month SEPARATOR \',\')
                             FROM fee_invoice_lines fil
                             WHERE fil.fee_invoice_id = fi.id AND fil.billing_month IS NOT NULL
                         ) AS billing_months_raw
                  FROM fee_invoices fi
                  LEFT JOIN fee_collections fc ON fc.fee_invoice_id = fi.id
                  WHERE fi.student_id = ?';
        $types = 'i';
        $params = [$studentId];

        if ($academicYearId) {
            $query .= ' AND fi.academic_year_id = ?';
            $types .= 'i';
            $params[] = $academicYearId;
        }

        $query .= ' GROUP BY fi.id ORDER BY fi.issued_at DESC LIMIT ? OFFSET ?';
        $types .= 'ii';
        $params[] = $limit;
        $params[] = $offset;

        return Database::fetchAll($query, $types, $params);
    }

    /**
     * All invoices (any status, any month) for every student currently in a
     * class section, paginated. Used by the teacher Fee Collection page so
     * older paid or still-open invoices stay reachable instead of only ever
     * showing each student's single latest invoice.
     */
    public static function listForClassSection(
        int $classSectionId,
        int $page = 1,
        int $perPage = 25,
        string $status = '',
        int $month = 0,
        string $search = ''
    ): array {
        $page = max(1, $page);
        $perPage = max(1, min(200, $perPage));
        $offset = ($page - 1) * $perPage;

        // Shared WHERE fragment + params, built once and reused for both the
        // count query and the list query so the two can never drift out of
        // sync (e.g. one filter applied to the list but forgotten in the
        // count, silently breaking pagination totals).
        $where = ' WHERE fi.class_section_id = ?';
        $types = 'i';
        $params = [$classSectionId];

        if (in_array($status, ['open', 'paid', 'cancelled'], true)) {
            $where .= ' AND fi.status = ?';
            $types .= 's';
            $params[] = $status;
        }

        if ($month >= 1 && $month <= 12) {
            // EXISTS rather than a JOIN so a multi-month invoice (several
            // fee_invoice_lines rows) still counts/lists as exactly one row.
            $where .= ' AND EXISTS (
                SELECT 1 FROM fee_invoice_lines fil2
                WHERE fil2.fee_invoice_id = fi.id AND fil2.billing_month = ?
            )';
            $types .= 'i';
            $params[] = $month;
        }

        $search = trim($search);
        if ($search !== '') {
            // Matched against student name, admission no, roll number and the
            // invoice number itself — covers every column already visible in
            // the table, so "does this filter find what I can see" holds.
            $where .= ' AND (
                s.first_name LIKE ? ESCAPE \'\\\\\' OR s.last_name LIKE ? ESCAPE \'\\\\\'
                OR CONCAT(s.first_name, \' \', s.last_name) LIKE ? ESCAPE \'\\\\\'
                OR IFNULL(s.father_name, \'\') LIKE ? ESCAPE \'\\\\\'
                OR s.admission_no LIKE ? ESCAPE \'\\\\\'
                OR sca.roll_number LIKE ? ESCAPE \'\\\\\'
                OR fi.invoice_no LIKE ? ESCAPE \'\\\\\'
            )';
            $like = '%' . str_replace(['%', '_'], ['\\%', '\\_'], $search) . '%';
            $types .= 'sssssss';
            array_push($params, $like, $like, $like, $like, $like, $like, $like);
        }

        // The student/roll-number join is needed by the search filter above
        // even when the list's own SELECT wouldn't otherwise require it for
        // counting, so it's included here too — a 1:1 join (one student, one
        // "current" class assignment), so it can't multiply invoice rows.
        $joins = '
             JOIN students s ON s.id = fi.student_id
             LEFT JOIN student_class_assignments sca
                ON sca.id = (
                    SELECT sca2.id FROM student_class_assignments sca2
                    WHERE sca2.student_id = s.id
                    ORDER BY sca2.assigned_at DESC, sca2.id DESC LIMIT 1
                )';

        $total = (int)(Database::fetchOne(
            "SELECT COUNT(*) AS cnt FROM fee_invoices fi{$joins}{$where}",
            $types,
            $params
        )['cnt'] ?? 0);

        $listTypes = $types . 'ii';
        $listParams = array_merge($params, [$perPage, $offset]);

        $rows = Database::fetchAll(
            "SELECT fi.*,
                    s.first_name, s.last_name, s.father_name, s.admission_no,
                    sca.roll_number,
                    COALESCE(SUM(fc.amount), 0) AS collected_amount,
                    (
                        SELECT GROUP_CONCAT(DISTINCT CONCAT_WS('-', fil.billing_year, fil.billing_month) ORDER BY fil.billing_year, fil.billing_month SEPARATOR ',')
                        FROM fee_invoice_lines fil
                        WHERE fil.fee_invoice_id = fi.id AND fil.billing_month IS NOT NULL
                    ) AS billing_months_raw
             FROM fee_invoices fi{$joins}
             LEFT JOIN fee_collections fc ON fc.fee_invoice_id = fi.id
             {$where}
             GROUP BY fi.id
             ORDER BY s.first_name, s.last_name, fi.issued_at DESC, fi.id DESC
             LIMIT ? OFFSET ?",
            $listTypes,
            $listParams
        );

        return [
            'rows' => $rows,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'status' => $status,
            'month' => $month,
            'search' => $search,
        ];
    }

    public static function countStudentInvoices(int $studentId): int
    {
        $row = Database::fetchOne(
            'SELECT COUNT(*) AS cnt FROM fee_invoices WHERE student_id = ?',
            'i',
            [$studentId]
        );
        return (int)($row['cnt'] ?? 0);
    }
}
