<?php

/**
 * Which class sections a staff member is allowed to collect fees for
 * (assigned by Admin), used to scope the Teacher Portal's fee collection
 * screens to only those classes.
 */
class StaffFeeClassModel
{
    /**
     * A class section has exactly one fee collector: assigning someone replaces
     * whoever was assigned before, rather than adding a second person.
     */
    public static function assign(int $staffProfileId, int $classSectionId, ?int $byUserId): void
    {
        Database::execute(
            'DELETE FROM staff_fee_classes WHERE class_section_id = ? AND staff_profile_id <> ?',
            'ii',
            [$classSectionId, $staffProfileId]
        );
        Database::execute(
            'INSERT INTO staff_fee_classes (staff_profile_id, class_section_id, assigned_by_user_id, created_at)
             VALUES (?, ?, ?, NOW())
             ON DUPLICATE KEY UPDATE staff_profile_id = staff_profile_id',
            'iii',
            [$staffProfileId, $classSectionId, $byUserId]
        );
    }

    public static function unassign(int $staffProfileId, int $classSectionId): void
    {
        Database::execute(
            'DELETE FROM staff_fee_classes WHERE staff_profile_id = ? AND class_section_id = ?',
            'ii',
            [$staffProfileId, $classSectionId]
        );
    }

    /** Class sections (with class/section names) assigned to a staff member for fee collection. */
    public static function getClassesForStaff(int $staffProfileId): array
    {
        return Database::fetchAll(
            'SELECT cs.id, c.name AS class_name, s.name AS section_name
             FROM staff_fee_classes sfc
             JOIN class_sections cs ON cs.id = sfc.class_section_id
             JOIN classes c ON c.id = cs.class_id
             JOIN sections s ON s.id = cs.section_id
             WHERE sfc.staff_profile_id = ?
             ORDER BY c.name, s.name',
            'i',
            [$staffProfileId]
        );
    }

    /** Class-section IDs assigned to a staff member for fee collection. */
    public static function getClassSectionIdsForStaff(int $staffProfileId): array
    {
        $rows = Database::fetchAll(
            'SELECT class_section_id FROM staff_fee_classes WHERE staff_profile_id = ?',
            'i',
            [$staffProfileId]
        );
        return array_map(static fn($r) => (int)$r['class_section_id'], $rows);
    }

    public static function isAssigned(int $staffProfileId, int $classSectionId): bool
    {
        $row = Database::fetchOne(
            'SELECT 1 FROM staff_fee_classes WHERE staff_profile_id = ? AND class_section_id = ? LIMIT 1',
            'ii',
            [$staffProfileId, $classSectionId]
        );
        return (bool)$row;
    }

    /** Staff profiles currently assigned to a class section, for the admin assignment screen. */
    public static function getStaffForClassSection(int $classSectionId): array
    {
        return Database::fetchAll(
            'SELECT sp.id, sp.full_name, sp.title
             FROM staff_fee_classes sfc
             JOIN staff_profiles sp ON sp.id = sfc.staff_profile_id
             WHERE sfc.class_section_id = ?
             ORDER BY sp.full_name',
            'i',
            [$classSectionId]
        );
    }

    /**
     * Fee-collection target for one staff member: across every student in the class
     * sections they're assigned to collect fees for, how much is owed in total, how
     * much of that has actually been paid, and how much is still pending. This is
     * distinct from the cash-handover ledger (FeeHandoverModel) — that tracks what a
     * teacher does with cash after collecting it; this tracks progress against the
     * classes they're responsible for.
     */
    public static function collectionSummaryForStaff(int $staffProfileId): array
    {
        $classSectionIds = self::getClassSectionIdsForStaff($staffProfileId);
        return self::collectionSummaryForClassSections($classSectionIds);
    }

    /** Same as collectionSummaryForStaff() but for an explicit list of class-section IDs (used for the admin all-teachers view, one query per teacher avoided by passing IDs directly where possible). */
    public static function collectionSummaryForClassSections(array $classSectionIds, ?int $academicYearId = null): array
    {
        $empty = ['to_collect' => 0.0, 'collected' => 0.0, 'pending' => 0.0, 'student_count' => 0];
        if (empty($classSectionIds)) {
            return $empty;
        }

        $ids = array_map('intval', $classSectionIds);
        $ph = implode(',', array_fill(0, count($ids), '?'));

        $ayClause = '';
        $ayParams = [];
        $ayTypes = '';
        if ($academicYearId && $academicYearId > 0) {
            $ayClause = ' AND fi.academic_year_id = ?';
            $ayParams = [$academicYearId];
            $ayTypes = 'i';
        }

        $row = Database::fetchOne(
            // "Collected" is real cash already received, so it is NEVER filtered by
            // the student's CURRENT status — a student who has since left the school
            // still genuinely paid that money, and it must not silently disappear
            // from the school-wide collected total just because they left afterward.
            // "To collect" / "pending" (and the headline student_count) ARE scoped to
            // currently-active students only, since there's nothing left to chase
            // from — and nothing to project as still-owed by — a student who's gone.
            "SELECT
                    COALESCE(SUM(CASE WHEN IFNULL(s.status, 1) = 1 THEN fi.total_due ELSE 0 END), 0) AS to_collect,
                    COALESCE(SUM(fc.paid), 0) AS collected,
                    COALESCE(SUM(CASE WHEN IFNULL(s.status, 1) = 1
                        THEN GREATEST(fi.total_due - IFNULL(fc.paid, 0), 0) ELSE 0 END), 0) AS pending,
                    COUNT(DISTINCT CASE WHEN IFNULL(s.status, 1) = 1 THEN s.id END) AS student_count
             FROM students s
             INNER JOIN student_class_assignments sca
               ON sca.id = (
                    SELECT sca2.id
                    FROM student_class_assignments sca2
                    WHERE sca2.student_id = s.id
                    ORDER BY sca2.assigned_at DESC, sca2.id DESC
                    LIMIT 1
                 )
             JOIN fee_invoices fi ON fi.student_id = s.id AND fi.status != 'cancelled'{$ayClause}
             LEFT JOIN (
                 SELECT fee_invoice_id, SUM(amount) AS paid
                 FROM fee_collections
                 GROUP BY fee_invoice_id
             ) fc ON fc.fee_invoice_id = fi.id
             WHERE sca.class_section_id IN ($ph)",
            str_repeat('i', count($ids)) . $ayTypes,
            array_merge($ids, $ayParams)
        );

        $toCollect = (float)($row['to_collect'] ?? 0);
        $collected = (float)($row['collected'] ?? 0);

        return [
            'to_collect' => $toCollect,
            'collected' => $collected,
            // Pending is summed per-invoice (each clamped at 0) rather than
            // netted as SUM(total_due) - SUM(paid): otherwise one student's
            // overpayment silently cancels out another student's genuinely
            // outstanding balance in the aggregate total.
            'pending' => (float)($row['pending'] ?? 0),
            'student_count' => (int)($row['student_count'] ?? 0),
        ];
    }

    /**
     * All fee-collection assignments across every class section in one query, grouped
     * by class_section_id => [ ['id' => staff_profile_id, 'full_name' => ..., 'title' => ...], ... ].
     * Powers the admin "all classes" overview so unassigned classes are visible at a
     * glance instead of checking teacher-by-teacher.
     */
    public static function getAllAssignmentsByClassSection(): array
    {
        $rows = Database::fetchAll(
            'SELECT sfc.class_section_id, sp.id, sp.full_name, sp.title
             FROM staff_fee_classes sfc
             JOIN staff_profiles sp ON sp.id = sfc.staff_profile_id
             ORDER BY sp.full_name'
        );

        $byClassSection = [];
        foreach ($rows as $r) {
            $byClassSection[(int)$r['class_section_id']][] = [
                'id' => (int)$r['id'],
                'full_name' => $r['full_name'],
                'title' => $r['title'],
            ];
        }
        return $byClassSection;
    }

    /**
     * collectionSummaryForStaff() for every staff member who has at least one class
     * assigned, keyed by staff_profile_id — for the Admin "Teacher Fee Collections"
     * overview, so it doesn't run one query per teacher.
     */
    /**
     * Staff eligible to be picked as "collecting on behalf of" for a given
     * class-section -- i.e. whoever is actually assigned to collect fees
     * for that class. Used to populate/pre-select the Admin fee-collection
     * screen's attribution dropdown. Falls back to every staff member with
     * ANY fee-collection assignment if the class-section isn't assigned to
     * anyone specific, so Admin can still attribute the payment manually.
     */
    public static function onBehalfOptionsForClassSection(int $classSectionId): array
    {
        $assigned = Database::fetchAll(
            'SELECT DISTINCT sp.id AS staff_profile_id, sp.full_name, sp.user_id
             FROM staff_fee_classes sfc
             JOIN staff_profiles sp ON sp.id = sfc.staff_profile_id
             WHERE sfc.class_section_id = ? AND sp.user_id IS NOT NULL
             ORDER BY sp.full_name',
            'i',
            [$classSectionId]
        );
        if (!empty($assigned)) {
            return $assigned;
        }

        return Database::fetchAll(
            'SELECT DISTINCT sp.id AS staff_profile_id, sp.full_name, sp.user_id
             FROM staff_fee_classes sfc
             JOIN staff_profiles sp ON sp.id = sfc.staff_profile_id
             WHERE sp.user_id IS NOT NULL
             ORDER BY sp.full_name'
        );
    }

    public static function collectionSummaryForAllStaff(?int $academicYearId = null): array
    {
        $assignments = Database::fetchAll('SELECT staff_profile_id, class_section_id FROM staff_fee_classes');
        if (empty($assignments)) {
            return [];
        }

        $byStaff = [];
        foreach ($assignments as $a) {
            $byStaff[(int)$a['staff_profile_id']][] = (int)$a['class_section_id'];
        }

        $result = [];
        foreach ($byStaff as $staffProfileId => $classSectionIds) {
            $result[$staffProfileId] = self::collectionSummaryForClassSections($classSectionIds, $academicYearId);
        }
        return $result;
    }
}