<?php

/**
 * Backs the "Send SMS" composer (Portal > Send SMS): lets a teacher/principal
 * (or anyone else holding sms.direct_send) look up a specific student, staff
 * member, or whole class and queue a direct SMS to them.
 *
 * Scoping: every read here accepts $allowedClassSectionIds, which is either
 *   - null   => unrestricted (Admin) — no class filter applied
 *   - array  => the caller may only see/message students in these class
 *               sections (a teacher's own taught + fee-collecting classes,
 *               resolved by the controller via RBAC before calling in)
 * Every method re-checks scope server-side rather than trusting anything
 * posted by the browser, since a hidden form field could otherwise be
 * tampered with to reach a student outside the caller's classes.
 */
class SmsDirectModel
{
    /**
     * Student search for the "Specific Student / Parent" picker.
     * Deliberately does NOT depend on the student having a `users` login —
     * unlike the Announcements "class" audience, this reads phone numbers
     * straight off students/guardians so it also reaches students who were
     * never given a portal account.
     */
    public static function searchStudents(?array $allowedClassSectionIds, string $q, int $limit = 20): array
    {
        if ($allowedClassSectionIds !== null && empty($allowedClassSectionIds)) {
            return []; // scoped caller with no classes assigned — nothing to show
        }

        $q = trim($q);
        $limit = max(1, min(50, $limit));

        $sql = "SELECT s.id, s.admission_no, s.first_name, s.last_name, s.father_name, sca.roll_number,
                       cs.id AS class_section_id, c.name AS class_name, sec.name AS section_name
                FROM students s
                INNER JOIN student_class_assignments sca
                    ON sca.id = (
                        SELECT sca2.id FROM student_class_assignments sca2
                        WHERE sca2.student_id = s.id
                        ORDER BY sca2.assigned_at DESC, sca2.id DESC LIMIT 1
                    )
                LEFT JOIN class_sections cs ON cs.id = sca.class_section_id
                LEFT JOIN classes c ON c.id = cs.class_id
                LEFT JOIN sections sec ON sec.id = cs.section_id
                WHERE IFNULL(s.status, 1) = 1";
        $types = '';
        $params = [];

        if ($allowedClassSectionIds !== null) {
            $placeholders = implode(',', array_fill(0, count($allowedClassSectionIds), '?'));
            $sql .= " AND cs.id IN ($placeholders)";
            $types .= str_repeat('i', count($allowedClassSectionIds));
            foreach ($allowedClassSectionIds as $id) {
                $params[] = (int)$id;
            }
        }

        if ($q !== '') {
            $like = '%' . $q . '%';
            $sql .= ' AND (s.admission_no LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ?
                        OR CONCAT(s.first_name, \' \', s.last_name) LIKE ? OR IFNULL(s.father_name, \'\') LIKE ?)';
            $types .= 'sssss';
            array_push($params, $like, $like, $like, $like, $like);
        }

        $sql .= ' ORDER BY s.first_name, s.last_name LIMIT ?';
        $types .= 'i';
        $params[] = $limit;

        return Database::fetchAll($sql, $types, $params);
    }

    /**
     * Contact options for one student: their own phone (if any) plus every
     * linked guardian's phone, each labelled. Returns null if the student
     * doesn't exist, is inactive, or falls outside $allowedClassSectionIds.
     */
    public static function getStudentContacts(int $studentId, ?array $allowedClassSectionIds): ?array
    {
        $student = Database::fetchOne(
            "SELECT s.id, s.first_name, s.last_name, s.father_name, s.phone, s.admission_no,
                    cs.id AS class_section_id, c.name AS class_name, sec.name AS section_name
             FROM students s
             INNER JOIN student_class_assignments sca
                 ON sca.id = (
                     SELECT sca2.id FROM student_class_assignments sca2
                     WHERE sca2.student_id = s.id
                     ORDER BY sca2.assigned_at DESC, sca2.id DESC LIMIT 1
                 )
             LEFT JOIN class_sections cs ON cs.id = sca.class_section_id
             LEFT JOIN classes c ON c.id = cs.class_id
             LEFT JOIN sections sec ON sec.id = cs.section_id
             WHERE s.id = ? AND IFNULL(s.status, 1) = 1",
            'i',
            [$studentId]
        );
        if (!$student) {
            return null;
        }

        $classSectionId = $student['class_section_id'] !== null ? (int)$student['class_section_id'] : null;
        if ($allowedClassSectionIds !== null && (!$classSectionId || !in_array($classSectionId, $allowedClassSectionIds, true))) {
            return null; // outside this caller's scope
        }

        $name = trim($student['first_name'] . ' ' . $student['last_name']);
        $classLabel = trim(($student['class_name'] ?? '') . ' ' . ($student['section_name'] ?? ''));

        $contacts = [];
        if (normalize_pk_mobile($student['phone'] ?? null) !== null) {
            $contacts[] = [
                'key' => 'student',
                'label' => $name . ' (Student)',
                'phone' => (string)$student['phone'],
            ];
        }

        $guardians = Database::fetchAll(
            'SELECT g.id, g.full_name, g.relation, g.phone
             FROM student_guardians sg
             JOIN guardians g ON g.id = sg.guardian_id
             WHERE sg.student_id = ?
             ORDER BY sg.is_primary DESC, g.full_name',
            'i',
            [$studentId]
        );
        foreach ($guardians as $g) {
            if (normalize_pk_mobile($g['phone'] ?? null) === null) {
                continue;
            }
            $contacts[] = [
                'key' => 'guardian_' . (int)$g['id'],
                'label' => trim($g['full_name'] . ' (' . ($g['relation'] ?: 'Guardian') . ')'),
                'phone' => (string)$g['phone'],
            ];
        }

        return [
            'name' => $name,
            'father_name' => (string)($student['father_name'] ?? ''),
            'admission_no' => (string)($student['admission_no'] ?? ''),
            'class_label' => $classLabel,
            'contacts' => $contacts,
        ];
    }

    /** Staff search — unrestricted (any teacher may message any staff member). */
    public static function searchStaff(string $q, int $limit = 20): array
    {
        $q = trim($q);
        $limit = max(1, min(50, $limit));

        $sql = 'SELECT id, full_name, title, staff_code, phone FROM staff_profiles WHERE 1=1';
        $types = '';
        $params = [];

        if ($q !== '') {
            $like = '%' . $q . '%';
            $sql .= ' AND (full_name LIKE ? OR staff_code LIKE ? OR title LIKE ?)';
            $types .= 'sss';
            array_push($params, $like, $like, $like);
        }

        $sql .= ' ORDER BY full_name LIMIT ?';
        $types .= 'i';
        $params[] = $limit;

        return Database::fetchAll($sql, $types, $params);
    }

    /** Contact info for one staff member, or null if they have no usable phone on file. */
    public static function getStaffContact(int $staffProfileId): ?array
    {
        $staff = Database::fetchOne(
            'SELECT id, full_name, title, phone FROM staff_profiles WHERE id = ?',
            'i',
            [$staffProfileId]
        );
        if (!$staff) {
            return null;
        }

        $contacts = [];
        if (normalize_pk_mobile($staff['phone'] ?? null) !== null) {
            $contacts[] = [
                'key' => 'staff',
                'label' => $staff['full_name'] . ($staff['title'] ? ' (' . $staff['title'] . ')' : ''),
                'phone' => (string)$staff['phone'],
            ];
        }

        return [
            'name' => (string)$staff['full_name'],
            'admission_no' => '',
            'class_label' => (string)($staff['title'] ?? ''),
            'contacts' => $contacts,
        ];
    }

    /** Class-section options for the "A Class" picker — all of them if unrestricted, else only the allowed ones. */
    public static function allowedClassOptions(?array $allowedClassSectionIds): array
    {
        if ($allowedClassSectionIds !== null && empty($allowedClassSectionIds)) {
            return [];
        }

        $sql = 'SELECT cs.id, c.name AS class_name, sec.name AS section_name
                FROM class_sections cs
                JOIN classes c ON c.id = cs.class_id
                JOIN sections sec ON sec.id = cs.section_id';
        $types = '';
        $params = [];

        if ($allowedClassSectionIds !== null) {
            $placeholders = implode(',', array_fill(0, count($allowedClassSectionIds), '?'));
            $sql .= " WHERE cs.id IN ($placeholders)";
            $types = str_repeat('i', count($allowedClassSectionIds));
            foreach ($allowedClassSectionIds as $id) {
                $params[] = (int)$id;
            }
        }

        $sql .= ' ORDER BY c.name, sec.name';

        return $types === ''
            ? Database::fetchAll($sql)
            : Database::fetchAll($sql, $types, $params);
    }

    /**
     * Every unique, valid phone number for a class: each enrolled student's
     * own phone plus every linked guardian's phone. Returns null if the
     * class is outside $allowedClassSectionIds. Numbers are deduplicated
     * (by normalized form) so a guardian shared across siblings, or a
     * student who is also their own contact, isn't texted twice.
     */
    public static function getClassContacts(int $classSectionId, ?array $allowedClassSectionIds): ?array
    {
        if ($allowedClassSectionIds !== null && !in_array($classSectionId, $allowedClassSectionIds, true)) {
            return null;
        }

        $classRow = ClassSectionModel::getById($classSectionId);
        if (!$classRow) {
            return null;
        }

        $students = Database::fetchAll(
            "SELECT s.id, s.first_name, s.last_name, s.phone
             FROM students s
             INNER JOIN student_class_assignments sca
                 ON sca.id = (
                     SELECT sca2.id FROM student_class_assignments sca2
                     WHERE sca2.student_id = s.id
                     ORDER BY sca2.assigned_at DESC, sca2.id DESC LIMIT 1
                 )
             WHERE sca.class_section_id = ? AND IFNULL(s.status, 1) = 1",
            'i',
            [$classSectionId]
        );

        $studentIds = array_map(static fn($s) => (int)$s['id'], $students);
        $guardians = [];
        if (!empty($studentIds)) {
            $placeholders = implode(',', array_fill(0, count($studentIds), '?'));
            $guardians = Database::fetchAll(
                "SELECT DISTINCT g.id, g.full_name, g.phone
                 FROM guardians g
                 JOIN student_guardians sg ON sg.guardian_id = g.id
                 WHERE sg.student_id IN ($placeholders)",
                str_repeat('i', count($studentIds)),
                $studentIds
            );
        }

        $seen = [];   // normalized number => true
        $numbers = []; // normalized number => original as typed (for display)
        foreach ($students as $s) {
            $norm = normalize_pk_mobile($s['phone'] ?? null);
            if ($norm !== null && !isset($seen[$norm])) {
                $seen[$norm] = true;
                $numbers[$norm] = (string)$s['phone'];
            }
        }
        foreach ($guardians as $g) {
            $norm = normalize_pk_mobile($g['phone'] ?? null);
            if ($norm !== null && !isset($seen[$norm])) {
                $seen[$norm] = true;
                $numbers[$norm] = (string)$g['phone'];
            }
        }

        return [
            'class_label' => trim($classRow['class_name'] . ' ' . $classRow['section_name']),
            'student_count' => count($students),
            'guardian_count' => count($guardians),
            'numbers' => array_values($numbers),
        ];
    }
}
