<?php
class FeeCategoryModel
{
    public static function list(string $search = '', int $limit = 50, int $offset = 0): array
    {
        $search = trim($search);
        $like = '%' . $search . '%';
        return Database::fetchAll(
            'SELECT * FROM fee_categories
             WHERE (? = \'\' OR name LIKE ?)
             ORDER BY sort_order ASC, name ASC
             LIMIT ? OFFSET ?',
            'ssii',
            [$search, $like, $limit, $offset]
        );
    }
    public static function count(string $search = ''): int
    {
        $search = trim($search);
        $like = '%' . $search . '%';
        $row = Database::fetchOne(
            'SELECT COUNT(*) AS cnt FROM fee_categories WHERE (? = \'\' OR name LIKE ?)',
            'ss',
            [$search, $like]
        );
        return (int)($row['cnt'] ?? 0);
    }
    public static function getById(int $id): ?array
    {
        return Database::fetchOne('SELECT * FROM fee_categories WHERE id = ?', 'i', [$id]);
    }
    public static function getAdmissionFees(): array
    {
        return Database::fetchAll(
            'SELECT * FROM fee_categories
             WHERE is_admission = 1
             ORDER BY sort_order ASC, name ASC'
        );
    }
    public static function getTuitionFees(): array
    {
        return Database::fetchAll(
            'SELECT * FROM fee_categories
             WHERE is_tuition = 1
             ORDER BY sort_order ASC, name ASC'
        );
    }
    public static function getOneTimeFees(): array
    {
        return Database::fetchAll(
            'SELECT * FROM fee_categories
             WHERE is_one_time = 1
             ORDER BY sort_order ASC, name ASC'
        );
    }
    public static function create(array $data): int
    {
        Database::execute(
            'INSERT INTO fee_categories
                (name, description, is_one_time, is_tuition, is_admission, sort_order, no_discount)
             VALUES (?, ?, ?, ?, ?, ?, ?)',
            'ssiiiii',
            [
                trim((string)$data['name']),
                trim((string)($data['description'] ?? '')),
                (int)($data['is_one_time'] ?? 0),
                (int)($data['is_tuition'] ?? 0),
                (int)($data['is_admission'] ?? 0),
                (int)($data['sort_order'] ?? 0),
                (int)($data['no_discount'] ?? 0),
            ]
        );
        return (int)Database::lastInsertId();
    }
    public static function update(int $id, array $data): void
    {
        Database::execute(
            'UPDATE fee_categories
             SET name = ?,
                 description = ?,
                 is_one_time = ?,
                 is_tuition = ?,
                 is_admission = ?,
                 sort_order = ?,
                 no_discount = ?
             WHERE id = ?',
            'ssiiiiii',
            [
                trim((string)$data['name']),
                trim((string)($data['description'] ?? '')),
                (int)($data['is_one_time'] ?? 0),
                (int)($data['is_tuition'] ?? 0),
                (int)($data['is_admission'] ?? 0),
                (int)($data['sort_order'] ?? 0),
                (int)($data['no_discount'] ?? 0),
                $id,
            ]
        );
    }
    public static function delete(int $id): void
    {
        Database::execute('DELETE FROM fee_categories WHERE id = ?', 'i', [$id]);
    }
}
