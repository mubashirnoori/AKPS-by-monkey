<?php

class OnlineCourseModel
{
    public static function list(): array
    {
        return Database::fetchAll(
            'SELECT oc.*, (SELECT COUNT(*) FROM course_assignments ca WHERE ca.course_id = oc.id) AS assigned_count
             FROM online_courses oc
             ORDER BY oc.created_at DESC'
        );
    }

    public static function getById(int $id): ?array
    {
        return Database::fetchOne('SELECT * FROM online_courses WHERE id = ?', 'i', [$id]);
    }

    public static function create(string $title, ?string $description, ?string $resourceUrl, ?int $createdByUserId): int
    {
        Database::execute(
            'INSERT INTO online_courses (title, description, resource_url, created_by_user_id, created_at)
             VALUES (?, ?, ?, ?, NOW())',
            'sssi',
            [$title, $description, $resourceUrl, $createdByUserId]
        );
        return (int)Database::lastInsertId();
    }

    public static function update(int $id, string $title, ?string $description, ?string $resourceUrl): void
    {
        Database::execute(
            'UPDATE online_courses SET title = ?, description = ?, resource_url = ? WHERE id = ?',
            'sssi',
            [$title, $description, $resourceUrl, $id]
        );
    }

    public static function delete(int $id): void
    {
        Database::execute('DELETE FROM online_courses WHERE id = ?', 'i', [$id]);
    }

    /** Replace the full set of students assigned to a course. */
    public static function setAssignments(int $courseId, array $studentIds): void
    {
        Database::execute('DELETE FROM course_assignments WHERE course_id = ?', 'i', [$courseId]);
        foreach ($studentIds as $studentId) {
            $studentId = (int)$studentId;
            if ($studentId > 0) {
                Database::execute(
                    'INSERT IGNORE INTO course_assignments (course_id, student_id, assigned_at) VALUES (?, ?, NOW())',
                    'ii',
                    [$courseId, $studentId]
                );
            }
        }
    }

    public static function assignedStudentIds(int $courseId): array
    {
        $rows = Database::fetchAll('SELECT student_id FROM course_assignments WHERE course_id = ?', 'i', [$courseId]);
        return array_map(static fn($r) => (int)$r['student_id'], $rows);
    }

    public static function isAssignedToStudent(int $courseId, int $studentId): bool
    {
        $row = Database::fetchOne(
            'SELECT 1 FROM course_assignments WHERE course_id = ? AND student_id = ? LIMIT 1',
            'ii',
            [$courseId, $studentId]
        );
        return (bool)$row;
    }

    /** Courses assigned to a specific student — used by the Student portal. */
    public static function listForStudent(int $studentId): array
    {
        return Database::fetchAll(
            'SELECT oc.*
             FROM course_assignments ca
             JOIN online_courses oc ON oc.id = ca.course_id
             WHERE ca.student_id = ?
             ORDER BY ca.assigned_at DESC',
            'i',
            [$studentId]
        );
    }

    // -----------------------------------------------------------------
    // Course Resources — lectures, live classes (Zoom/Meet links, etc.),
    // documents, or reference links attached to a course.
    // -----------------------------------------------------------------

    public static function listResources(int $courseId): array
    {
        return Database::fetchAll(
            'SELECT * FROM course_resources
             WHERE course_id = ?
             ORDER BY (scheduled_at IS NULL), scheduled_at, sort_order, id',
            'i',
            [$courseId]
        );
    }

    public static function getResource(int $id): ?array
    {
        return Database::fetchOne('SELECT * FROM course_resources WHERE id = ?', 'i', [$id]);
    }

    public static function addResource(
        int $courseId,
        string $title,
        string $resourceType,
        ?string $resourceUrl,
        ?string $description,
        ?string $scheduledAt,
        int $sortOrder = 0,
        string $sourceType = 'link'
    ): int {
        $allowedTypes = ['video', 'live_class', 'document', 'link'];
        if (!in_array($resourceType, $allowedTypes, true)) {
            $resourceType = 'link';
        }
        $sourceType = $sourceType === 'upload' ? 'upload' : 'link';
        Database::execute(
            'INSERT INTO course_resources
                (course_id, title, resource_type, source_type, resource_url, description, scheduled_at, sort_order, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())',
            'issssssi',
            [$courseId, $title, $resourceType, $sourceType, $resourceUrl, $description, $scheduledAt ?: null, $sortOrder]
        );
        return (int)Database::lastInsertId();
    }

    public static function deleteResource(int $id): void
    {
        Database::execute('DELETE FROM course_resources WHERE id = ?', 'i', [$id]);
    }

    // -----------------------------------------------------------------
    // Watch-progress tracking — only meaningful for source_type='upload'
    // videos, since that's the only playback we actually control.
    // -----------------------------------------------------------------

    /**
     * Records a student's progress on a video. Never lets progress go
     * backwards (e.g. rewinding to review a section shouldn't lower their
     * recorded percentage), and stamps completed_at the first time they
     * cross the completion threshold.
     */
    public static function recordProgress(int $resourceId, int $studentId, float $percent, int $positionSeconds): void
    {
        $percent = max(0, min(100, $percent));
        $completedNow = $percent >= 95;

        $existing = Database::fetchOne(
            'SELECT progress_percent, completed_at FROM resource_progress WHERE course_resource_id = ? AND student_id = ?',
            'ii',
            [$resourceId, $studentId]
        );

        if ($existing) {
            $bestPercent = max((float)$existing['progress_percent'], $percent);
            $completedAt = $existing['completed_at'];
            if (!$completedAt && $completedNow) {
                Database::execute(
                    'UPDATE resource_progress
                     SET progress_percent = ?, last_position_seconds = ?, completed_at = NOW()
                     WHERE course_resource_id = ? AND student_id = ?',
                    'diii',
                    [$bestPercent, $positionSeconds, $resourceId, $studentId]
                );
            } else {
                Database::execute(
                    'UPDATE resource_progress
                     SET progress_percent = ?, last_position_seconds = ?
                     WHERE course_resource_id = ? AND student_id = ?',
                    'diii',
                    [$bestPercent, $positionSeconds, $resourceId, $studentId]
                );
            }
            return;
        }

        Database::execute(
            'INSERT INTO resource_progress (course_resource_id, student_id, progress_percent, last_position_seconds, completed_at)
             VALUES (?, ?, ?, ?, ?)',
            'iidis',
            [$resourceId, $studentId, $percent, $positionSeconds, $completedNow ? date('Y-m-d H:i:s') : null]
        );
    }

    public static function getProgressForStudent(int $resourceId, int $studentId): ?array
    {
        return Database::fetchOne(
            'SELECT * FROM resource_progress WHERE course_resource_id = ? AND student_id = ?',
            'ii',
            [$resourceId, $studentId]
        );
    }

    /** Progress for every student assigned to this resource's course — for the Admin/Teacher view. */
    public static function getProgressSummary(int $resourceId): array
    {
        return Database::fetchAll(
            'SELECT s.id AS student_id, s.first_name, s.last_name, s.admission_no,
                    COALESCE(rp.progress_percent, 0) AS progress_percent,
                    rp.completed_at, rp.updated_at
             FROM course_resources cr
             JOIN course_assignments ca ON ca.course_id = cr.course_id
             JOIN students s ON s.id = ca.student_id
             LEFT JOIN resource_progress rp ON rp.course_resource_id = cr.id AND rp.student_id = s.id
             WHERE cr.id = ?
             ORDER BY progress_percent DESC, s.first_name',
            'i',
            [$resourceId]
        );
    }
}
