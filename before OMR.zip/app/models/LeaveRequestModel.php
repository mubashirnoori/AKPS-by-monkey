<?php

class LeaveRequestModel
{
    /**
     * @param string $applicantType '' (all), 'staff', or 'student'
     * @param array<int>|null $studentClassSectionIds When not null, restricts 'student' results to
     *        students whose CURRENT class section id is in this list (used to scope a Teacher's
     *        view to their own class — an empty array means "no classes, so no results").
     */
    public static function list(string $status = '', string $search = '', int $limit = 200, int $offset = 0, string $applicantType = '', ?array $studentClassSectionIds = null): array
    {
        $status = trim($status);
        $search = trim($search);
        $applicantType = trim($applicantType);
        $like = '%' . $search . '%';

        if ($studentClassSectionIds !== null && empty($studentClassSectionIds)) {
            return [];
        }

        $classScopeSql = '';
        $classScopeParams = [];
        $classScopeTypes = '';
        if ($studentClassSectionIds !== null) {
            $placeholders = implode(',', array_fill(0, count($studentClassSectionIds), '?'));
            $classScopeSql = "AND s.id IS NOT NULL AND (
                SELECT sca2.class_section_id FROM student_class_assignments sca2
                WHERE sca2.student_id = s.id
                ORDER BY sca2.assigned_at DESC, sca2.id DESC
                LIMIT 1
            ) IN ($placeholders)";
            $classScopeTypes = str_repeat('i', count($studentClassSectionIds));
            $classScopeParams = array_map('intval', $studentClassSectionIds);
        }

        return Database::fetchAll(
            'SELECT lr.*,
                    sp.full_name AS staff_full_name,
                    sp.title AS staff_title,
                    s.first_name AS student_first_name,
                    s.last_name AS student_last_name,
                    s.admission_no AS student_admission_no,
                    la.decision AS latest_decision
             FROM leave_requests lr
             LEFT JOIN staff_profiles sp ON sp.id = lr.staff_profile_id
             LEFT JOIN students s ON s.id = lr.student_id
             LEFT JOIN leave_approvals la ON la.leave_request_id = lr.id
             WHERE (? = \'\' OR lr.status = ?)
               AND (? = \'\' OR lr.applicant_type = ?)
               AND (? = \'\' OR sp.full_name LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ?)
               ' . $classScopeSql . '
             ORDER BY lr.id DESC
             LIMIT ? OFFSET ?',
            'ssssssss' . $classScopeTypes . 'ii',
            array_merge([$status, $status, $applicantType, $applicantType, $search, $like, $like, $like], $classScopeParams, [$limit, $offset])
        );
    }

    /** Single leave request by id, or null. Used to check duration/applicant before approving. */
    public static function find(int $leaveRequestId): ?array
    {
        return Database::fetchOne(
            'SELECT * FROM leave_requests WHERE id = ? LIMIT 1',
            'i',
            [$leaveRequestId]
        );
    }

    /** Inclusive day count for a leave request's date range (e.g. same day = 1). */
    public static function durationDays(array $leaveRequest): int
    {
        $from = (string)($leaveRequest['from_date'] ?? '');
        $to = (string)($leaveRequest['to_date'] ?? '');
        if ($from === '' || $to === '') {
            return 0;
        }
        $diff = (strtotime($to) - strtotime($from)) / 86400 + 1;
        return max(0, (int)$diff);
    }

    public static function listForStaff(int $staffProfileId, int $limit = 20): array
    {
        return Database::fetchAll(
            "SELECT lr.* FROM leave_requests lr
             WHERE lr.applicant_type = 'staff' AND lr.staff_profile_id = ?
             ORDER BY lr.id DESC LIMIT ?",
            'ii',
            [$staffProfileId, $limit]
        );
    }

    public static function listForStudent(int $studentId, int $limit = 20): array
    {
        return Database::fetchAll(
            "SELECT lr.* FROM leave_requests lr
             WHERE lr.applicant_type = 'student' AND lr.student_id = ?
             ORDER BY lr.id DESC LIMIT ?",
            'ii',
            [$studentId, $limit]
        );
    }

    public static function createForStaff(array $data, ?int $requestedByUserId): int
    {
        $staffProfileId = (int)$data['staff_profile_id'];
        $fromDate = (string)($data['from_date'] ?? '');
        $toDate = (string)($data['to_date'] ?? '');

        self::assertNoOverlap('staff', $staffProfileId, $fromDate, $toDate);

        Database::execute(
            "INSERT INTO leave_requests (staff_profile_id, student_id, applicant_type, leave_type, from_date, to_date, status, note, requested_by_user_id)
             VALUES (?, NULL, 'staff', ?, ?, ?, 'pending', ?, ?)",
            'issssi',
            [
                $staffProfileId,
                (string)($data['leave_type'] ?? 'leave'),
                $fromDate,
                $toDate,
                (string)($data['note'] ?? ''),
                $requestedByUserId,
            ]
        );
        return (int)Database::lastInsertId();
    }

    public static function createForStudent(array $data, ?int $requestedByUserId): int
    {
        $studentId = (int)$data['student_id'];
        $fromDate = (string)($data['from_date'] ?? '');
        $toDate = (string)($data['to_date'] ?? '');

        self::assertNoOverlap('student', $studentId, $fromDate, $toDate);

        Database::execute(
            "INSERT INTO leave_requests (staff_profile_id, student_id, applicant_type, leave_type, from_date, to_date, status, note, requested_by_user_id)
             VALUES (NULL, ?, 'student', ?, ?, ?, 'pending', ?, ?)",
            'issssi',
            [
                $studentId,
                (string)($data['leave_type'] ?? 'leave'),
                $fromDate,
                $toDate,
                (string)($data['note'] ?? ''),
                $requestedByUserId,
            ]
        );
        return (int)Database::lastInsertId();
    }

    /**
     * Blocks a new leave request if its date range overlaps a leave the same
     * person already has pending or approved — e.g. applying for 20–25 June
     * when 22–26 June is already on file. Rejected/older requests don't count.
     */
    private static function assertNoOverlap(string $applicantType, int $applicantId, string $fromDate, string $toDate): void
    {
        if ($fromDate === '' || $toDate === '' || $applicantId <= 0) {
            return;
        }
        if (strtotime($toDate) < strtotime($fromDate)) {
            throw new RuntimeException('The "to" date cannot be before the "from" date.');
        }

        $column = $applicantType === 'student' ? 'student_id' : 'staff_profile_id';
        $conflict = Database::fetchOne(
            "SELECT id, from_date, to_date, status FROM leave_requests
             WHERE applicant_type = ?
               AND {$column} = ?
               AND status IN ('pending','approved')
               AND from_date <= ?
               AND to_date >= ?
             ORDER BY from_date
             LIMIT 1",
            'siss',
            [$applicantType, $applicantId, $toDate, $fromDate]
        );

        if ($conflict) {
            throw new RuntimeException(
                'This overlaps a leave request you already have on file for '
                . $conflict['from_date'] . ' to ' . $conflict['to_date']
                . ' (' . $conflict['status'] . '). Please choose different dates or cancel that one first.'
            );
        }
    }

    /** @deprecated kept for backward compatibility — use createForStaff() */
    public static function create(array $data, ?int $requestedByUserId): int
    {
        return self::createForStaff($data, $requestedByUserId);
    }

    public static function approve(int $leaveRequestId, string $decision, string $decisionNote, ?int $approvedByUserId): void
    {
        $decision = in_array($decision, ['approved', 'rejected'], true) ? $decision : 'approved';

        $status = $decision === 'approved' ? 'approved' : 'rejected';

        $conn = Database::connection();
        $conn->begin_transaction();
        try {
            Database::execute(
                'INSERT INTO leave_approvals (leave_request_id, approved_by_user_id, decision, decision_note)
                 VALUES (?, ?, ?, ?)',
                'iiss',
                [$leaveRequestId, $approvedByUserId, $decision, $decisionNote]
            );

            Database::execute(
                'UPDATE leave_requests
                 SET status = ?
                 WHERE id = ?',
                'si',
                [$status, $leaveRequestId]
            );
            $conn->commit();
        } catch (Throwable $e) {
            $conn->rollback();
            throw $e;
        }
    }
}
