<?php

class Database
{
    /** @var mysqli|null */
    private static $conn = null;

    public static function connection(): mysqli
    {
        if (self::$conn instanceof mysqli) {
            return self::$conn;
        }

        $config = require __DIR__ . '/../../config/config.php';
        $db = $config['db'];

        $mysqli = new mysqli(
            $db['host'],
            $db['user'],
            $db['pass'],
            $db['name'],
            (int)($db['port'] ?? 3306)
        );

        if ($mysqli->connect_errno) {
            throw new RuntimeException('DB connect failed: ' . $mysqli->connect_error);
        }

        $mysqli->set_charset($db['charset'] ?? 'utf8mb4');

        // Align MySQL's own clock (used by DEFAULT CURRENT_TIMESTAMP() columns
        // such as activity_log.created_at and fee_invoices.issued_at) with the
        // app's configured timezone. Without this, timestamps written by the
        // database server itself can drift from Asia/Karachi if the DB host's
        // system timezone differs from PHP's date_default_timezone_set().
        $appConfig = $config['app'] ?? [];
        $tz = (string)($appConfig['timezone'] ?? 'Asia/Karachi');
        try {
            $offset = (new DateTime('now', new DateTimeZone($tz)))->format('P');
            $mysqli->query("SET time_zone = '" . $mysqli->real_escape_string($offset) . "'");
        } catch (Throwable $e) {
            // Non-fatal — worst case timestamps fall back to the DB server's own timezone.
        }

        // Enforce stricter error mode.
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        self::$conn = $mysqli;
        return self::$conn;
    }

    /**
     * Execute a prepared statement for non-select queries.
     *
     * @param string $sql
     * @param string $types e.g. 'sii'
     * @param array $params
     */
    public static function execute(string $sql, string $types = '', array $params = []): int
    {
        $conn = self::connection();
        $stmt = $conn->prepare($sql);
        if ($types !== '') {
            // bind_param requires references.
            $bind = [];
            $bind[] = $types;
            foreach ($params as $k => $v) {
                $bind[] = &$params[$k];
            }
            call_user_func_array([$stmt, 'bind_param'], $bind);
        }
        $stmt->execute();
        return $stmt->affected_rows;
    }

    /**
     * Fetch all rows (associative).
     *
     * @return array<int, array<string, mixed>>
     */
    public static function fetchAll(string $sql, string $types = '', array $params = []): array
    {
        $conn = self::connection();
        $stmt = $conn->prepare($sql);
        if ($types !== '') {
            $bind = [];
            $bind[] = $types;
            foreach ($params as $k => $v) {
                $bind[] = &$params[$k];
            }
            call_user_func_array([$stmt, 'bind_param'], $bind);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        $rows = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
        return is_array($rows) ? $rows : [];
    }

    /**
     * Fetch a single row (associative) or null.
     *
     * @return array<string, mixed>|null
     */
    public static function fetchOne(string $sql, string $types = '', array $params = []): ?array
    {
        $rows = self::fetchAll($sql, $types, $params);
        return $rows[0] ?? null;
    }

    public static function lastInsertId(): string
    {
        return (string)self::connection()->insert_id;
    }
}

