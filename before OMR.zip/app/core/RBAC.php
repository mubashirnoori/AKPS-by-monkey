<?php

class RBAC
{
    /** @param string|array<string> $permissionKey A single key, or an array of keys (OR — any one grants access). */
    public static function hasPermission($permissionKey): bool
    {
        if (is_array($permissionKey)) {
            foreach ($permissionKey as $key) {
                if (self::hasPermission($key)) {
                    return true;
                }
            }
            return false;
        }

        $user = Auth::currentUser();
        if (!$user) {
            return false;
        }
        $roleId = (int)$user['role_id'];

        // Request-scoped only (static, not $_SESSION): a per-session cache used to
        // live here, but it meant an admin granting/revoking a permission never
        // took effect for anyone already logged in until they logged all the way
        // out and back in -- role_permissions changes in Users & Roles were
        // silently ignored for the rest of that person's session. Caching per
        // request still avoids repeat queries for the same permission on one
        // page load, but always re-checks the database on the next request.
        static $cache = [];
        if (isset($cache[$roleId]) && array_key_exists($permissionKey, $cache[$roleId])) {
            return (bool)$cache[$roleId][$permissionKey];
        }

        $row = Database::fetchOne(
            'SELECT 1
             FROM permissions p
             JOIN role_permissions rp ON rp.permission_id = p.id
             WHERE rp.role_id = ? AND p.permission_key = ? LIMIT 1',
            'is',
            [$roleId, $permissionKey]
        );

        $allowed = (bool)($row ? true : false);
        if (!isset($cache[$roleId])) {
            $cache[$roleId] = [];
        }
        $cache[$roleId][$permissionKey] = $allowed;
        return $allowed;
    }

    /** @param string|array<string> $permissionKey */
    public static function requirePermission($permissionKey): void
    {
        if (!self::hasPermission($permissionKey)) {
            http_response_code(403);
            require __DIR__ . '/../views/errors/403.php';
            exit;
        }
    }

    // =========================================================
    // Role helpers — used to route users to the correct portal
    // and to scope queries so each role only sees its own data.
    // =========================================================

    public static function roleName(): string
    {
        $user = Auth::currentUser();
        return strtolower(trim((string)($user['role_name'] ?? '')));
    }

    public static function isAdmin(): bool
    {
        return self::roleName() === 'admin';
    }

    /** Bounce to 403 unless the logged-in user is Admin. Call after Auth::requireLogin(). */
    public static function requireAdmin(): void
    {
        if (!self::isAdmin()) {
            http_response_code(403);
            require __DIR__ . '/../views/errors/403.php';
            exit;
        }
    }

    public static function isTeacher(): bool
    {
        return self::roleName() === 'teacher';
    }

    public static function isStudent(): bool
    {
        return self::roleName() === 'student';
    }

    public static function isParent(): bool
    {
        return self::roleName() === 'parent';
    }

    public static function isAccountant(): bool
    {
        return self::roleName() === 'accountant';
    }

    /** The students.id row linked to the logged-in user (Student role), or null if not linked. */
    public static function currentStudentId(): ?int
    {
        $user = Auth::currentUser();
        if (!$user) {
            return null;
        }
        static $cache = [];
        $uid = (int)$user['id'];
        if (array_key_exists($uid, $cache)) {
            return $cache[$uid];
        }
        $row = Database::fetchOne('SELECT id FROM students WHERE user_id = ? LIMIT 1', 'i', [$uid]);
        return $cache[$uid] = ($row ? (int)$row['id'] : null);
    }

    /** The staff_profiles.id row linked to the logged-in user (Teacher/staff roles), or null. */
    public static function currentStaffProfileId(): ?int
    {
        $user = Auth::currentUser();
        if (!$user) {
            return null;
        }
        static $cache = [];
        $uid = (int)$user['id'];
        if (array_key_exists($uid, $cache)) {
            return $cache[$uid];
        }
        $row = Database::fetchOne('SELECT id FROM staff_profiles WHERE user_id = ? LIMIT 1', 'i', [$uid]);
        return $cache[$uid] = ($row ? (int)$row['id'] : null);
    }

    /** The guardians.id row linked to the logged-in user (Parent role), or null. */
    public static function currentGuardianId(): ?int
    {
        $user = Auth::currentUser();
        if (!$user) {
            return null;
        }
        static $cache = [];
        $uid = (int)$user['id'];
        if (array_key_exists($uid, $cache)) {
            return $cache[$uid];
        }
        $row = Database::fetchOne('SELECT id FROM guardians WHERE user_id = ? LIMIT 1', 'i', [$uid]);
        return $cache[$uid] = ($row ? (int)$row['id'] : null);
    }

    /** Student IDs of the children linked to the logged-in guardian (Parent role). */
    public static function currentGuardianChildIds(): array
    {
        $guardianId = self::currentGuardianId();
        if (!$guardianId) {
            return [];
        }
        $rows = Database::fetchAll(
            'SELECT student_id FROM student_guardians WHERE guardian_id = ? ORDER BY is_primary DESC',
            'i',
            [$guardianId]
        );
        return array_map(static fn($r) => (int)$r['student_id'], $rows);
    }

    /** Subject IDs currently assigned to the logged-in teacher. */
    public static function currentTeacherSubjectIds(): array
    {
        $staffId = self::currentStaffProfileId();
        if (!$staffId) {
            return [];
        }
        $rows = Database::fetchAll(
            'SELECT subject_id FROM staff_subject_assignments WHERE staff_profile_id = ?',
            'i',
            [$staffId]
        );
        return array_map(static fn($r) => (int)$r['subject_id'], $rows);
    }

    /** Class-section IDs the logged-in teacher teaches (derived from their assigned subjects). */
    public static function currentTeacherClassSectionIds(): array
    {
        $staffId = self::currentStaffProfileId();
        if (!$staffId) {
            return [];
        }
        $rows = Database::fetchAll(
            'SELECT DISTINCT cs.id
             FROM staff_subject_assignments ssa
             JOIN subjects s ON s.id = ssa.subject_id
             JOIN class_sections cs ON cs.class_id = s.class_id
             WHERE ssa.staff_profile_id = ? AND s.class_id IS NOT NULL',
            'i',
            [$staffId]
        );
        return array_map(static fn($r) => (int)$r['id'], $rows);
    }

    /** Class-section IDs where the logged-in teacher is the designated Class Teacher (can take attendance). */
    public static function currentTeacherClassTeacherSectionIds(): array
    {
        $staffId = self::currentStaffProfileId();
        if (!$staffId) {
            return [];
        }
        $rows = Database::fetchAll(
            'SELECT id FROM class_sections WHERE class_teacher_staff_id = ?',
            'i',
            [$staffId]
        );
        return array_map(static fn($r) => (int)$r['id'], $rows);
    }

    /** Class-section IDs the logged-in teacher is assigned to collect fees for. */
    public static function currentTeacherFeeClassSectionIds(): array
    {
        $staffId = self::currentStaffProfileId();
        if (!$staffId) {
            return [];
        }
        require_once __DIR__ . '/../models/StaffFeeClassModel.php';
        return StaffFeeClassModel::getClassSectionIdsForStaff($staffId);
    }
}