<?php

/**
 * Short-lived, HMAC-signed tokens for file export/download links.
 *
 * WHY THIS EXISTS
 * ----------------
 * Every export/download action normally relies on Auth::requireLogin(), which
 * reads the PHP session cookie. That works fine in a real browser, but breaks
 * for clients that don't reliably forward cookies on a download request —
 * most commonly a WebView-wrapped mobile app, where the OS's native download
 * manager (Android DownloadManager, etc.) fetches the URL itself and does NOT
 * automatically carry over the WebView's session cookie. The server then sees
 * an unauthenticated request, redirects to /login, and the wrapper saves that
 * login page's HTML with a .xlsx/.csv extension — which is exactly the
 * "file is corrupted" symptom this token exists to prevent.
 *
 * HOW IT WORKS
 * ------------
 * While the user is genuinely logged in (real session, already past
 * Auth::requireLogin() for the page that contains the export button), the
 * server stamps a signed token — user id + short expiry — directly into the
 * export link/form. That token is self-contained and self-verifying (HMAC),
 * so the export action can accept EITHER a valid session OR a valid token.
 * No server-side storage, no database table, nothing that has to be cleaned
 * up — the signature and the embedded expiry are the only things checked.
 *
 * This is a convenience/compatibility measure, not a replacement for the
 * session-based permission checks: the token only proves "this is user X, as
 * of a few minutes ago." Every actual permission check (RBAC::requirePermission
 * etc.) still runs exactly as before, against that user's real, current
 * role/permissions in the database.
 */
class DownloadToken
{
    /** Tokens are only meant to bridge "page load" -> "tap the download button". */
    private const DEFAULT_TTL_SECONDS = 600; // 10 minutes

    private static ?string $secretCache = null;

    /**
     * Creates a signed token for the given user, valid for $ttlSeconds.
     */
    public static function generate(int $userId, int $ttlSeconds = self::DEFAULT_TTL_SECONDS): string
    {
        $payload = [
            'uid' => $userId,
            'exp' => time() + max(30, $ttlSeconds),
        ];
        $encodedPayload = self::base64UrlEncode((string)json_encode($payload));
        $signature = self::sign($encodedPayload);
        return $encodedPayload . '.' . $signature;
    }

    /**
     * Verifies a token. Returns the user id on success, or null if the token
     * is missing, malformed, has a bad signature, or has expired.
     */
    public static function verify(?string $token): ?int
    {
        if ($token === null || $token === '') {
            return null;
        }
        $parts = explode('.', $token, 2);
        if (count($parts) !== 2) {
            return null;
        }
        [$encodedPayload, $signature] = $parts;

        $expectedSignature = self::sign($encodedPayload);
        if (!hash_equals($expectedSignature, $signature)) {
            return null;
        }

        $json = self::base64UrlDecode($encodedPayload);
        $payload = $json !== false ? json_decode($json, true) : null;
        if (!is_array($payload) || !isset($payload['uid'], $payload['exp'])) {
            return null;
        }

        if ((int)$payload['exp'] < time()) {
            return null; // expired
        }

        return (int)$payload['uid'];
    }

    private static function sign(string $encodedPayload): string
    {
        return self::base64UrlEncode(hash_hmac('sha256', $encodedPayload, self::secret(), true));
    }

    /**
     * The HMAC secret. Prefers the DOWNLOAD_TOKEN_KEY environment variable
     * (recommended for production, especially multi-server setups, so every
     * server signs/verifies with the same key). Falls back to a random key
     * that's generated once and persisted next to config.php, so it survives
     * across requests without requiring any manual setup.
     */
    private static function secret(): string
    {
        if (self::$secretCache !== null) {
            return self::$secretCache;
        }

        $fromEnv = getenv('DOWNLOAD_TOKEN_KEY');
        if (is_string($fromEnv) && $fromEnv !== '') {
            return self::$secretCache = $fromEnv;
        }

        $config = require __DIR__ . '/../../config/config.php';
        $fromConfig = $config['app']['download_token_key'] ?? '';
        if (is_string($fromConfig) && $fromConfig !== '') {
            return self::$secretCache = $fromConfig;
        }

        // Last resort: a per-install key generated once and cached to disk
        // (outside public/, so it's never web-accessible) — keeps this
        // feature working out of the box with zero manual configuration.
        $keyFile = __DIR__ . '/../../config/download_token.key';
        if (is_file($keyFile)) {
            $existing = trim((string)file_get_contents($keyFile));
            if ($existing !== '') {
                return self::$secretCache = $existing;
            }
        }

        $generated = bin2hex(random_bytes(32));
        // Best-effort write; if the filesystem is read-only (e.g. some
        // containerized deployments), fail open with an in-memory-only key
        // rather than fatally erroring the download.
        @file_put_contents($keyFile, $generated, LOCK_EX);
        @chmod($keyFile, 0600);
        return self::$secretCache = $generated;
    }

    private static function base64UrlEncode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    /** @return string|false */
    private static function base64UrlDecode(string $data)
    {
        $padded = str_pad(strtr($data, '-_', '+/'), strlen($data) % 4 === 0 ? strlen($data) : strlen($data) + (4 - strlen($data) % 4), '=');
        return base64_decode($padded, true);
    }
}
