<?php

abstract class Controller
{
    protected function render(string $view, array $data = []): void
    {
        $viewFile = __DIR__ . '/../views/' . $view . '.php';
        if (!file_exists($viewFile)) {
            http_response_code(500);
            echo 'View not found: ' . h($view);
            return;
        }

        $layoutFile = __DIR__ . '/../views/layout.php';
        $content = $this->renderView($viewFile, $data);
        $flash = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);

        $pageTitle = $data['title'] ?? 'School Management System';
        $user = Auth::currentUser();

        require $layoutFile;
    }

    /**
     * Render a view as a complete, standalone HTML page — no navbar, no sidebar shell.
     * For pages the visitor sees before (or instead of) the dashboard, like the login
     * screen, where the empty sidebar strip and dashboard chrome don't make sense.
     */
    protected function renderBare(string $view, array $data = []): void
    {
        $viewFile = __DIR__ . '/../views/' . $view . '.php';
        if (!file_exists($viewFile)) {
            http_response_code(500);
            echo 'View not found: ' . h($view);
            return;
        }

        $layoutFile = __DIR__ . '/../views/layout_bare.php';
        $content = $this->renderView($viewFile, $data);
        $pageTitle = $data['title'] ?? 'School Management System';

        require $layoutFile;
    }

    private function renderView(string $viewFile, array $data): string
    {
        extract($data, EXTR_SKIP);
        ob_start();
        require $viewFile;
        return (string)ob_get_clean();
    }

    /**
     * Render a view WITHOUT the surrounding layout (header/sidebar) — used to produce
     * an HTML fragment for AJAX responses, so a table/section can be swapped in place
     * instead of reloading the whole page.
     */
    protected function renderPartial(string $view, array $data = []): string
    {
        $viewFile = __DIR__ . '/../views/' . $view . '.php';
        if (!file_exists($viewFile)) {
            return '';
        }
        return $this->renderView($viewFile, $data);
    }

    /** True when the request came from fetch()/XHR rather than a normal form navigation. */
    protected function wantsJson(): bool
    {
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            return true;
        }
        return isset($_POST['ajax']) && $_POST['ajax'] === '1';
    }

    /** Send a JSON response and stop execution — used for AJAX form handling. */
    protected function jsonResponse(array $data, int $statusCode = 200): void
    {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data);
        exit;
    }

    /** @param string|array<string> $permissionKey */
    protected function requirePermission($permissionKey): void
    {
        RBAC::requirePermission($permissionKey);
    }

    protected function requireCsrf(): void
    {
        CSRF::validate($_POST['csrf_token'] ?? null);
    }

    protected function redirect(string $path): void
    {
        \redirect($path);
    }
}

