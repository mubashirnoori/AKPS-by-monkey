<?php

class Router
{
    public function dispatch(): void
    {
        $route = $this->getRoute();
        [$controllerPart, $actionPart] = $this->parseRoute($route);

        $controllerClass = ucfirst($controllerPart) . 'Controller';
        $actionMethod = $actionPart . 'Action';

        $controllerFile = __DIR__ . '/../controllers/' . $controllerClass . '.php';
        if (!file_exists($controllerFile)) {
            http_response_code(404);
            require __DIR__ . '/../views/errors/404.php';
            return;
        }

        require_once $controllerFile;

        if (!class_exists($controllerClass)) {
            http_response_code(500);
            echo 'Controller class missing: ' . h($controllerClass);
            return;
        }

        $controller = new $controllerClass();

        if (!method_exists($controller, $actionMethod)) {
            http_response_code(404);
            require __DIR__ . '/../views/errors/404.php';
            return;
        }

        $controller->{$actionMethod}();
    }

    // ✅ FIXED FUNCTION (ONLY ONE)
    private function getRoute(): string
    {
        // POST (forms)
        if (!empty($_POST['route'])) {
            return (string)$_POST['route'];
        }

        // GET (links)
        if (!empty($_GET['route'])) {
            return (string)$_GET['route'];
        }

        return 'dashboard/index';
    }

    private function parseRoute(string $route): array
    {
        $route = trim($route);
        $route = trim($route, '/');
        $parts = explode('/', $route);
        $controllerPart = $parts[0] ?: 'dashboard';
        $actionPart = $parts[1] ?? 'index';

        // Only letters/digits/underscore may reach the controller-class-name / file-path
        // build below — a route string is user input (GET/POST), and without this check
        // it flowed straight into a require_once path with no character restriction.
        if (!preg_match('/^[A-Za-z0-9_]+$/', $controllerPart) || !preg_match('/^[A-Za-z0-9_]+$/', $actionPart)) {
            return ['__invalid__', 'index'];
        }

        return [$controllerPart, $actionPart];
    }
}