<?php

function h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/**
 * Drop-in replacement for fputcsv() that runs every field through csv_safe()
 * first. Safe to use for header rows too (static strings never match the guard).
 */
function fputcsv_safe($handle, array $fields, string $separator = ',', string $enclosure = '"'): int|false
{
    return fputcsv($handle, array_map('csv_safe', $fields), $separator, $enclosure);
}

/**
 * Neutralizes CSV/Excel formula injection by prefixing risky leading characters.
 * LibreOffice treats it as a formula when the file is opened, not as plain text —
 * a classic vector for a malicious "name" or "remark" field to run a formula on
 * whoever opens the export. Prefixing a tab character keeps the value readable
 * (unlike a leading quote/apostrophe, which stays visible in the cell) while
 * stopping spreadsheet apps from evaluating it as a formula.
 */
function csv_safe($value): string
{
    $value = (string)$value;
    if ($value !== '' && in_array($value[0], ['=', '+', '-', '@'], true)) {
        return "\t" . $value;
    }
    return $value;
}

/**
 * Wraps a value that's purely digits (e.g. an admission number like "STU022"
 * with the letters stripped, or a plain numeric roll number) as an Excel
 * "force text" formula (="00123") so spreadsheet apps display it exactly as
 * typed instead of reinterpreting it as a number — which mangles long values
 * into scientific notation (2.57E+09) and silently drops leading zeros.
 * Anything that isn't purely digits is returned via csv_safe() unchanged,
 * since only an all-digit value is ever at risk of that reinterpretation.
 */
function csv_force_text($value): string
{
    $value = (string)$value;
    if ($value !== '' && preg_match('/^\d+$/', $value)) {
        return '="' . str_replace('"', '""', $value) . '"';
    }
    return csv_safe($value);
}

/**
 * Format a mark/score/percentage for display: whole numbers show with no
 * decimals (34.00 -> "34"), fractional values keep only the decimal places
 * they actually need (34.50 -> "34.5", 34.53 -> "34.53") instead of always
 * rounding to a whole number.
 */
function format_mark($value): string
{
    if ($value === null || $value === '') {
        return '—';
    }
    $f = (float)$value;
    if (abs($f - round($f)) < 0.005) {
        return (string)(int)round($f);
    }
    return rtrim(rtrim(number_format($f, 2, '.', ''), '0'), '.');
}

/** "1st", "2nd", "3rd", "4th", … */
function ordinal(int $n): string
{
    if ($n % 100 >= 11 && $n % 100 <= 13) {
        return $n . 'th';
    }
    switch ($n % 10) {
        case 1: return $n . 'st';
        case 2: return $n . 'nd';
        case 3: return $n . 'rd';
        default: return $n . 'th';
    }
}

/** Strip characters that aren't safe in a filesystem path/folder/file name. */
function safe_filename(string $s): string
{
    $s = preg_replace('/[\\\\\/:*?"<>|]+/', '-', $s) ?? $s;
    $s = trim(preg_replace('/\s+/', ' ', $s) ?? $s);
    return $s !== '' ? $s : 'unnamed';
}

function base_url(string $path = ''): string
{
    $config = require __DIR__ . '/../../config/config.php';
    $base = rtrim($config['app']['base_url'] ?? '', '/');
    $path = '/' . ltrim($path, '/');
    return $base . $path;
}

function redirect(string $path): void
{
    header('Location: ' . base_url($path));
    exit;
}

function route_url(string $route): string
{
    $route = ltrim($route, '/');
    return base_url('/index.php?route=' . rawurlencode($route));
}

function redirect_route(string $route): void
{
    redirect('/index.php?route=' . rawurlencode($route));
}

/**
 * Generates a signed download token for the currently logged-in user (see
 * DownloadToken / Auth::requireLoginOrToken()). Call this from a view when
 * rendering an export link/button so the URL still works even if the client
 * (e.g. a WebView-wrapped mobile app) doesn't forward the session cookie on
 * the actual download request. Returns '' if nobody is logged in — nothing
 * to embed a token for in that case, the link will just hit the login page
 * as it always did.
 */
function download_token(): string
{
    $user = Auth::currentUser();
    if (!$user) {
        return '';
    }
    return DownloadToken::generate((int)$user['id']);
}

/**
 * Remember list filters (search, class, per_page, page, …) so Save / Cancel / Back
 * can return to the same filtered list.
 */
function remember_list_filters(string $listKey, array $filters): void
{
    if (!isset($_SESSION['list_filters']) || !is_array($_SESSION['list_filters'])) {
        $_SESSION['list_filters'] = [];
    }
    $_SESSION['list_filters'][$listKey] = $filters;
}

/**
 * Read return filters from ret_* GET/POST, else last remembered list for $listKey.
 */
function recall_list_filters(string $listKey, array $defaults = []): array
{
    $src = array_merge($_GET, $_POST);
    $out = $defaults;
    $foundRet = false;
    foreach (array_keys($defaults) as $key) {
        $retKey = 'ret_' . $key;
        if (array_key_exists($retKey, $src)) {
            $foundRet = true;
            $out[$key] = $src[$retKey];
        }
    }
    if ($foundRet) {
        return $out;
    }
    $stored = $_SESSION['list_filters'][$listKey] ?? null;
    if (is_array($stored)) {
        return array_merge($defaults, $stored);
    }
    return $defaults;
}

/** Build /index.php?route=…&filters… URL (absolute via base_url). */
function list_url(string $route, array $filters = [], array $extra = []): string
{
    $query = array_merge(['route' => $route], $filters, $extra);
    // Drop empty strings but keep 0
    foreach ($query as $k => $v) {
        if ($v === null || $v === '') {
            unset($query[$k]);
        }
    }
    return base_url('/index.php?' . http_build_query($query));
}

function redirect_list(string $route, array $filters = []): void
{
    $query = array_merge(['route' => $route], $filters);
    foreach ($query as $k => $v) {
        if ($v === null || $v === '') {
            unset($query[$k]);
        }
    }
    redirect('/index.php?' . http_build_query($query));
}

/** Hidden fields so POST save keeps list filters (use ret_* to avoid form field clashes). */
function list_return_fields(array $filters): void
{
    foreach ($filters as $key => $value) {
        if ($value === null || $value === '') {
            continue;
        }
        echo '<input type="hidden" name="ret_' . h((string)$key) . '" value="' . h((string)$value) . '">' . "\n";
    }
}

/** Append ret_* to a URL query for Edit / Guardians links. */
function list_return_query(array $filters): string
{
    $parts = [];
    foreach ($filters as $key => $value) {
        if ($value === null || $value === '') {
            continue;
        }
        $parts['ret_' . $key] = $value;
    }
    return $parts === [] ? '' : '&' . http_build_query($parts);
}

function csrf_field(): void
{
    echo '<input type="hidden" name="csrf_token" value="' . h(CSRF::token()) . '">';
}

function now_utc(): string
{
    return gmdate('Y-m-d H:i:s');
}

/**
 * Whether $date (Y-m-d) is one of the school's configured holidays, as set
 * on Settings > Global ("Holidays (CSV dates)", stored as settings.holidays).
 * Never throws — a settings-read failure should not break the attendance page.
 */
function is_configured_holiday(string $date): bool
{
    if ($date === '' || !class_exists('Database')) {
        return false;
    }
    try {
        $row = Database::fetchOne("SELECT `value` FROM settings WHERE `key` = 'holidays'");
    } catch (Throwable $e) {
        return false;
    }
    $csv = (string)($row['value'] ?? '');
    if ($csv === '') {
        return false;
    }
    $dates = array_map('trim', explode(',', $csv));
    return in_array($date, $dates, true);
}

/**
 * Record one activity-log entry ("who did what"). Never throws — a logging
 * failure must never break the actual request the user is trying to do.
 */
function log_activity(string $action, string $description): void
{
    if (!class_exists('Database') || !class_exists('Auth')) {
        return;
    }
    try {
        $user = Auth::currentUser();
        Database::execute(
            'INSERT INTO activity_log (user_id, username, role_name, action, description, ip_address) VALUES (?, ?, ?, ?, ?, ?)',
            'isssss',
            [
                $user['id'] ?? null,
                $user['username'] ?? null,
                $user['role_name'] ?? null,
                $action,
                $description,
                $_SERVER['REMOTE_ADDR'] ?? null,
            ]
        );
    } catch (Throwable $e) {
        // Swallow — logging must never break the request it's logging.
    }
}

function is_https_request(): bool
{
    if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') {
        return true;
    }
    return !empty($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443;
}

/**
 * Resolve a staff member's uploaded photo URL by their staff_profiles.id,
 * or null if none has been uploaded. Photos are stored on disk as
 * public/uploads/staff/{staffProfileId}.{ext} — same convention already
 * used for student photos.
 */
function staff_photo_url($staffProfileId): ?string
{
    $staffProfileId = (int)$staffProfileId;
    if ($staffProfileId <= 0) {
        return null;
    }
    $files = glob(dirname(__DIR__, 2) . '/public/uploads/staff/' . $staffProfileId . '.*') ?: [];
    if (!$files) {
        return null;
    }
    return base_url('/uploads/staff/' . basename($files[0])) . '?v=' . filemtime($files[0]);
}

/**
 * Resolve a student's uploaded photo URL by their students.id, or null if
 * none has been uploaded. Same on-disk convention as staff photos.
 */
function student_photo_url($studentId): ?string
{
    $studentId = (int)$studentId;
    if ($studentId <= 0) {
        return null;
    }
    $files = glob(dirname(__DIR__, 2) . '/public/uploads/students/' . $studentId . '.*') ?: [];
    if (!$files) {
        return null;
    }
    return base_url('/uploads/students/' . basename($files[0])) . '?v=' . filemtime($files[0]);
}

/**
 * Resolve a logged-in user's avatar via their linked staff profile
 * (users.id -> staff_profiles.user_id) or, failing that, their linked
 * student record (users.id -> students.user_id). Returns null if the user
 * has neither, or no photo has been uploaded for either.
 */
function user_avatar_url(?int $userId): ?string
{
    if (!$userId || !class_exists('Database')) {
        return null;
    }
    try {
        $staff = Database::fetchOne('SELECT id FROM staff_profiles WHERE user_id = ? LIMIT 1', 'i', [$userId]);
        if ($staff) {
            $url = staff_photo_url((int)$staff['id']);
            if ($url) {
                return $url;
            }
        }
        $student = Database::fetchOne('SELECT id FROM students WHERE user_id = ? LIMIT 1', 'i', [$userId]);
        if ($student) {
            return student_photo_url((int)$student['id']);
        }
    } catch (Throwable $e) {
        return null;
    }
    return null;
}

/* ============================================================================
 * SMS gateway (Android device relay)
 * ----------------------------------------------------------------------------
 * We don't pay for a commercial SMS API. Instead PHP writes rows into the
 * `sms_outbox` table, and a phone (running the poller script in
 * docs/SMS_GATEWAY.md, sending through its own SIM — see Settings >
 * Notifications for the number on file) calls api/sms_gateway.php to pick
 * them up and report back whether each one actually sent.
 * ========================================================================= */

/** All `sms_*` settings as a flat key => value map (cached per request). */
function sms_gateway_settings(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $cache = [];
    if (!class_exists('Database')) {
        return $cache;
    }
    try {
        foreach (Database::fetchAll('SELECT `key`, `value` FROM settings') as $row) {
            if (strpos((string)$row['key'], 'sms_') === 0) {
                $cache[$row['key']] = (string)$row['value'];
            }
        }
    } catch (Throwable $e) {
        // settings table not migrated yet — treat SMS as disabled
    }
    return $cache;
}

function sms_gateway_enabled(): bool
{
    return (sms_gateway_settings()['sms_enabled'] ?? '0') === '1';
}

/**
 * Normalizes a Pakistani mobile number (03145525749, +923145525749,
 * 00923145525749, 923145525749, or bare 3145525749) to +923XXXXXXXXX.
 * Returns null if it doesn't look like a valid PK mobile number.
 */
function normalize_pk_mobile(?string $raw): ?string
{
    if ($raw === null || trim($raw) === '') {
        return null;
    }
    $digits = preg_replace('/\D+/', '', $raw) ?? '';
    if (strpos($digits, '0092') === 0) {
        $digits = substr($digits, 2); // -> 92...
    }
    if (strpos($digits, '92') === 0 && strlen($digits) === 12) {
        return '+' . $digits;
    }
    if (strpos($digits, '0') === 0 && strlen($digits) === 11) {
        return '+92' . substr($digits, 1);
    }
    if (strlen($digits) === 10 && strpos($digits, '3') === 0) {
        return '+92' . $digits;
    }
    return null;
}

/**
 * True if $text can be sent as GSM 03.38 (7-bit) SMS with no character loss.
 * False means it needs UCS-2 (Unicode) encoding — e.g. any Urdu/Arabic
 * character — which caps a single SMS segment at 70 characters (67 once
 * split across multiple concatenated segments) instead of 160 (153 split).
 */
function sms_is_gsm7(string $text): bool
{
    static $allowedSet = null;
    if ($allowedSet === null) {
        $allowed = "@£\$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !\"#¤%&'()*+,-./0123456789:;<=>?"
            . "¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà"
            . "^{}\\[~]|€";
        $allowedSet = array_flip(preg_split('//u', $allowed, -1, PREG_SPLIT_NO_EMPTY));
    }
    $chars = preg_split('//u', $text, -1, PREG_SPLIT_NO_EMPTY);
    if ($chars === false) {
        return false;
    }
    foreach ($chars as $ch) {
        if (!isset($allowedSet[$ch])) {
            return false;
        }
    }
    return true;
}

/**
 * Rewrites "smart" typographic characters (curly quotes, en/em dashes,
 * ellipsis, bullets, non-breaking space) to their plain-ASCII GSM 03.38
 * equivalents. Purely cosmetic — unlike the old gsm7_safe() it replaces,
 * it never drops or replaces a genuine non-Latin character, so Urdu/Arabic
 * text passes through untouched instead of turning into "?".
 */
function sms_normalize_typography(string $text): string
{
    static $map = [
        "\xe2\x80\x93" => '-',   // – en dash
        "\xe2\x80\x94" => '-',   // — em dash
        "\xe2\x80\x98" => "'",   // ‘ left single quote
        "\xe2\x80\x99" => "'",   // ’ right single quote
        "\xe2\x80\x9c" => '"',   // “ left double quote
        "\xe2\x80\x9d" => '"',   // ” right double quote
        "\xe2\x80\xa6" => '...', // … ellipsis
        "\xe2\x80\xa2" => '-',   // • bullet
        "\xc2\xa0"     => ' ',   // non-breaking space
    ];
    return strtr($text, $map);
}

/**
 * Splits a message into one or more SMS-sized segments — kept only for any
 * caller still on the old MacroDroid-based relay (Settings > Notifications >
 * SMS Gateway's earlier setup), which used the native "Send SMS" action with
 * no support for concatenated/multipart SMS, so a long message HAD to become
 * several separate real texts with "(1/5)"-style labels baked in.
 *
 * queue_sms() below no longer calls this. The native Android relay app
 * (see relay/SmsSender.kt) sends real concatenated SMS via SmsManager, which
 * the recipient's phone reassembles into a single message on its own — so
 * pre-splitting here would just recreate the exact "arrives as 5 separate
 * texts" problem this function used to work around.
 *
 * @return string[] Ready-to-send message bodies, each within a single SMS
 *                   segment's character budget.
 */
function sms_split_message(string $text, int $hardCap = 640): array
{
    $text = trim(sms_normalize_typography($text));
    $text = mb_substr($text, 0, $hardCap);
    if ($text === '') {
        return [];
    }

    $gsm7 = sms_is_gsm7($text);
    $singleCap = $gsm7 ? 160 : 70;
    $multiCap = $gsm7 ? 153 : 67;

    if (mb_strlen($text) <= $singleCap) {
        return [$text];
    }

    $words = preg_split('/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY) ?: [$text];

    for ($totalGuess = 2; $totalGuess <= 99; $totalGuess++) {
        $prefixLen = mb_strlen("($totalGuess/$totalGuess) ");
        $budget = $multiCap - $prefixLen;
        if ($budget <= 0) {
            continue;
        }
        $chunks = [];
        $current = '';
        foreach ($words as $word) {
            $candidate = $current === '' ? $word : $current . ' ' . $word;
            if (mb_strlen($candidate) <= $budget) {
                $current = $candidate;
                continue;
            }
            if ($current !== '') {
                $chunks[] = $current;
                $current = '';
            }
            // a single word longer than the budget: hard-slice it
            while (mb_strlen($word) > $budget) {
                $chunks[] = mb_substr($word, 0, $budget);
                $word = mb_substr($word, $budget);
            }
            $current = $word;
        }
        if ($current !== '') {
            $chunks[] = $current;
        }
        if (count($chunks) <= $totalGuess) {
            $total = count($chunks);
            $out = [];
            foreach ($chunks as $i => $chunk) {
                $out[] = '(' . ($i + 1) . '/' . $total . ') ' . $chunk;
            }
            return $out;
        }
    }

    // Fallback for pathological input (e.g. one 600-char word with no
    // spaces): hard-slice, still leaving room for the prefix.
    $prefixLen = mb_strlen('(99/99) ');
    $budget = max(1, $multiCap - $prefixLen);
    $rawChunks = [];
    for ($i = 0, $len = mb_strlen($text); $i < $len; $i += $budget) {
        $rawChunks[] = mb_substr($text, $i, $budget);
    }
    $total = count($rawChunks);
    $out = [];
    foreach ($rawChunks as $i => $chunk) {
        $out[] = '(' . ($i + 1) . '/' . $total . ') ' . $chunk;
    }
    return $out;
}

/**
 * Queues an outbound SMS for a relay phone (see sms_gateway_devices) to send.
 * No-ops (returns false) if SMS sending is disabled in Settings or the number
 * doesn't look like a valid mobile number — callers don't need to check first.
 *
 * Queues ONE outbox row per message, full text included (up to $hardCap as a
 * sanity limit against something pathological like an accidentally-pasted
 * essay — not a real-world message length). The relay phone's own SmsManager
 * handles multi-part SMS if the message is long, sending it as a single real
 * concatenated text the recipient's phone reassembles automatically — no
 * "(1/5)"-style manual splitting needed on this end. Returns true only if the
 * row was queued successfully.
 *
 * $senderStaffId: pass a staff_profiles.id to route this message to that
 * staff member's own device (see sms_gateway_devices) instead of the shared
 * default device — e.g. an announcement a teacher sends should go out under
 * their own number if they have one configured. Leave null for system
 * messages (OTP, fee reminders) — those always go out via the default
 * device regardless.
 */
function queue_sms(?string $to, string $message, string $purpose = 'general', ?int $senderStaffId = null, int $hardCap = 640): bool
{
    if (!sms_gateway_enabled() || !class_exists('Database')) {
        return false;
    }
    $number = normalize_pk_mobile($to);
    if ($number === null) {
        return false;
    }

    $text = trim(sms_normalize_typography($message));
    $text = mb_substr($text, 0, $hardCap);
    if ($text === '') {
        return false;
    }

    try {
        Database::execute(
            'INSERT INTO sms_outbox (to_number, message, purpose, sender_staff_id, created_at) VALUES (?, ?, ?, ?, NOW())',
            'sssi',
            [$number, $text, $purpose, $senderStaffId]
        );
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * Finds a mobile number linked to a user account: checks the student's own
 * phone first, then a linked guardian's phone, then a staff profile's phone.
 */
function resolve_user_mobile(int $userId): ?string
{
    if (!class_exists('Database')) {
        return null;
    }
    try {
        $row = Database::fetchOne("SELECT phone FROM students WHERE user_id = ? AND phone IS NOT NULL AND phone <> '' LIMIT 1", 'i', [$userId])
            ?? Database::fetchOne("SELECT phone FROM guardians WHERE user_id = ? AND phone IS NOT NULL AND phone <> '' LIMIT 1", 'i', [$userId])
            ?? Database::fetchOne("SELECT phone FROM staff_profiles WHERE user_id = ? AND phone IS NOT NULL AND phone <> '' LIMIT 1", 'i', [$userId]);
        return $row['phone'] ?? null;
    } catch (Throwable $e) {
        return null;
    }
}

/* ============================================================================
 * Announcement delivery channels (Push / SMS / Email)
 * ----------------------------------------------------------------------------
 * Push already goes out unconditionally today (best-effort — it no-ops per
 * device if Firebase isn't configured). SMS and email reuse the same
 * queue_sms() / Mailer::send() paths already used elsewhere (OTP, fee
 * receipts, etc.) — this just adds an explicit per-channel on/off switch so
 * an admin can choose, from Settings > Notifications, which channels an
 * announcement actually goes out on.
 * ========================================================================= */

/**
 * Which channels are enabled for announcements, read from `settings`.
 * Push defaults ON (matches the pre-existing behaviour before this toggle
 * existed); SMS and email default OFF since they're opt-in / cost money per
 * message on the relay SIM.
 *
 * @return array{push: bool, sms: bool, email: bool}
 */
function announcement_channels(): array
{
    $defaults = ['announce_channel_push' => '1', 'announce_channel_sms' => '0', 'announce_channel_email' => '0'];
    if (class_exists('Database')) {
        try {
            $rows = Database::fetchAll(
                "SELECT `key`, `value` FROM settings WHERE `key` IN ('announce_channel_push','announce_channel_sms','announce_channel_email')"
            );
            foreach ($rows as $r) {
                $defaults[(string)$r['key']] = (string)$r['value'];
            }
        } catch (Throwable $e) {
            // settings table not migrated yet — fall back to defaults above
        }
    }
    return [
        'push'  => $defaults['announce_channel_push'] === '1',
        'sms'   => $defaults['announce_channel_sms'] === '1',
        'email' => $defaults['announce_channel_email'] === '1',
    ];
}

/**
 * Batch-resolves contact info (display name, mobile number, email) for a
 * list of user ids in a single query, checking each user's linked student /
 * guardian / staff profile — the same sources resolve_user_mobile() checks
 * one user at a time, but here for many recipients at once (an announcement
 * audience can be hundreds of users, so N+1 queries would be slow).
 *
 * Email preference: the user's own login email (users.email) if set,
 * otherwise a linked guardian's email on file — mirrors how a guardian
 * account may not have its own users.email populated yet.
 *
 * @param array<int> $userIds
 * @return array<int, array{name: string, phone: ?string, email: ?string}>
 */
function resolve_contacts_for_users(array $userIds): array
{
    $userIds = array_values(array_unique(array_filter(array_map('intval', $userIds), static fn($id) => $id > 0)));
    if (empty($userIds) || !class_exists('Database')) {
        return [];
    }

    $placeholders = implode(',', array_fill(0, count($userIds), '?'));
    $rows = Database::fetchAll(
        "SELECT
            u.id AS user_id,
            u.username,
            u.email AS user_email,
            COALESCE(NULLIF(TRIM(CONCAT(s.first_name, ' ', s.last_name)), ''), g.full_name, sp.full_name, u.username) AS name,
            COALESCE(NULLIF(s.phone, ''), NULLIF(g.phone, ''), NULLIF(sp.phone, '')) AS phone,
            COALESCE(NULLIF(u.email, ''), NULLIF(g.email, '')) AS email
         FROM users u
         LEFT JOIN students s ON s.user_id = u.id
         LEFT JOIN guardians g ON g.user_id = u.id
         LEFT JOIN staff_profiles sp ON sp.user_id = u.id
         WHERE u.id IN ($placeholders)",
        str_repeat('i', count($userIds)),
        $userIds
    );

    $out = [];
    foreach ($rows as $r) {
        $out[(int)$r['user_id']] = [
            'name' => (string)($r['name'] ?? $r['username'] ?? ''),
            'phone' => $r['phone'] !== null ? (string)$r['phone'] : null,
            'email' => $r['email'] !== null ? (string)$r['email'] : null,
        ];
    }
    return $out;
}

/* ============================================================================
 * WhatsApp "click to chat" sharing (staff's own phone, staff's own WhatsApp)
 * ----------------------------------------------------------------------------
 * We deliberately do NOT integrate the WhatsApp Business/Cloud API here —
 * that needs a Meta Business account, a dedicated verified number, and
 * approved message templates, which is a lot of setup for "let a teacher
 * forward a fee voucher." Instead this opens WHATSAPP ITSELF (the app on the
 * staff member's phone, or WhatsApp Web if they're on desktop) with the
 * parent's number and a message pre-filled — the staff member's own WhatsApp
 * account sends it, same as if they'd typed it by hand. Zero cost, zero
 * account setup, and every send happens under a real staff member's own
 * number (useful for accountability — if a parent replies, it goes to the
 * staff member who actually sent it, not a shared school number).
 * ========================================================================= */

/**
 * Builds a `wa.me` click-to-chat URL, or null if $rawPhone doesn't look like
 * a valid Pakistani mobile number (same validation as the SMS gateway uses,
 * via normalize_pk_mobile()) — callers should treat null as "don't show a
 * WhatsApp button for this record" rather than showing a broken link.
 *
 * NOTE: WhatsApp's click-to-chat scheme only supports pre-filling TEXT.
 * There is no way to pre-attach a file/image this way — that's a deliberate
 * WhatsApp platform restriction, not a limitation of this code. Any document
 * (fee voucher, report card) must be linked to, not attached, and the parent
 * taps the link to view it.
 */
function whatsapp_click_to_chat_url(?string $rawPhone, string $message): ?string
{
    $normalized = normalize_pk_mobile($rawPhone);
    if ($normalized === null) {
        return null;
    }
    // wa.me wants bare digits with country code, no leading '+'.
    $digits = ltrim($normalized, '+');
    return 'https://wa.me/' . $digits . '?text=' . rawurlencode($message);
}

/**
 * Builds the full list of "Send via WhatsApp" recipient choices for a
 * student: the student's own phone (if any) plus every linked guardian's
 * phone (father, mother, etc. — pass rows from GuardianModel::listByStudent()),
 * each paired with a ready-to-use wa.me link carrying the same $message.
 *
 * Numbers that don't pass normalize_pk_mobile() are silently skipped, same
 * as whatsapp_click_to_chat_url() — callers should treat an empty return as
 * "don't show a WhatsApp button at all" rather than showing a broken one.
 * Duplicate numbers (e.g. a guardian's phone that's identical to the
 * student's own) are collapsed to a single entry, keeping whichever label
 * was seen first.
 *
 * @param array $student   Row with 'phone', 'first_name', 'last_name'.
 * @param array $guardians Rows from GuardianModel::listByStudent() — each with 'phone', 'full_name', 'relation'.
 * @return array<int, array{label: string, url: string}>
 */
function whatsapp_share_recipients(array $student, array $guardians, string $message): array
{
    $studentName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));

    $candidates = [
        ['label' => ($studentName !== '' ? "{$studentName} (Student)" : 'Student'), 'phone' => $student['phone'] ?? null],
    ];
    foreach ($guardians as $g) {
        $relation = trim((string)($g['relation'] ?? '')) ?: 'Guardian';
        $name = trim((string)($g['full_name'] ?? ''));
        $candidates[] = ['label' => ($name !== '' ? "{$name} ({$relation})" : $relation), 'phone' => $g['phone'] ?? null];
    }

    $seenDigits = [];
    $recipients = [];
    foreach ($candidates as $c) {
        $url = whatsapp_click_to_chat_url($c['phone'], $message);
        if ($url === null) {
            continue;
        }
        $digits = ltrim(normalize_pk_mobile($c['phone']) ?? '', '+');
        if (isset($seenDigits[$digits])) {
            continue; // same number already listed under an earlier label
        }
        $seenDigits[$digits] = true;
        $recipients[] = ['label' => $c['label'], 'url' => $url];
    }
    return $recipients;
}

/**
 * Generates and stores a fresh 6-digit OTP for a user, invalidating any
 * earlier unused code for the same purpose. Returns the plaintext code —
 * only the SHA-256 hash is ever stored.
 */
function issue_otp(int $userId, string $purpose = 'password_reset', int $ttlSeconds = 600): string
{
    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    Database::execute('DELETE FROM otp_codes WHERE user_id = ? AND purpose = ? AND used_at IS NULL', 'is', [$userId, $purpose]);
    Database::execute(
        'INSERT INTO otp_codes (user_id, purpose, code_hash, expires_at) VALUES (?, ?, ?, ?)',
        'isss',
        [$userId, $purpose, hash('sha256', $code), date('Y-m-d H:i:s', time() + $ttlSeconds)]
    );
    return $code;
}

/**
 * Verifies an OTP code for a username/email. On success, marks the code used
 * and returns the user id; on failure (wrong code, expired, too many tries,
 * unknown account) returns null and — for a wrong-but-live code — counts the
 * attempt so codes can't be brute-forced.
 */
function verify_otp(string $identifier, string $code, string $purpose = 'password_reset'): ?int
{
    if (!class_exists('Database')) {
        return null;
    }
    $user = Database::fetchOne('SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1', 'ss', [$identifier, $identifier]);
    if (!$user) {
        return null;
    }
    $row = Database::fetchOne(
        'SELECT id, code_hash, attempts FROM otp_codes
         WHERE user_id = ? AND purpose = ? AND used_at IS NULL AND expires_at > NOW()
         ORDER BY id DESC LIMIT 1',
        'is',
        [(int)$user['id'], $purpose]
    );
    if (!$row || (int)$row['attempts'] >= 5) {
        return null;
    }
    if (!hash_equals((string)$row['code_hash'], hash('sha256', $code))) {
        Database::execute('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?', 'i', [(int)$row['id']]);
        return null;
    }
    Database::execute('UPDATE otp_codes SET used_at = NOW() WHERE id = ?', 'i', [(int)$row['id']]);
    return (int)$user['id'];
}