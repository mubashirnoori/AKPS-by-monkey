<?php

/**
 * Sends Android push notifications via Firebase Cloud Messaging (FCM), using
 * the current HTTP v1 API (Google shut down the old legacy "server key" API
 * in 2024). No Composer / vendor library — this project has none, so this
 * hand-implements the two steps HTTP v1 needs, using only PHP's built-in
 * openssl + curl extensions:
 *
 *   1. Exchange your Firebase service account's private key for a short-lived
 *      (~1 hour) OAuth2 access token (self-signed RS256 JWT -> Google's token
 *      endpoint). See https://firebase.google.com/docs/cloud-messaging/auth-server
 *   2. POST the notification to
 *      https://fcm.googleapis.com/v1/projects/{project_id}/messages:send
 *      with that access token as a Bearer header, once per device token.
 *
 * Setup (Settings > Notifications > Push Notifications):
 *   Firebase Console -> Project settings -> Service accounts -> Generate new
 *   private key. Paste the project ID and the downloaded JSON file's full
 *   contents into those two fields.
 *
 * This only talks to Firebase — it has nothing to do with browser/Web Push.
 * The Android app itself (a separate Android Studio project, not part of
 * this codebase) needs the Firebase SDK added so it can obtain its own FCM
 * device token and register it via POST /api/index.php?route=devices/register.
 */
class FcmClient
{
    public static ?string $lastError = null;

    /**
     * Send one notification to one FCM device token.
     * Returns true on success. On failure (including an invalid/expired
     * token), $lastError is set and the caller should not treat this as
     * fatal — a single stale device token failing shouldn't stop the rest
     * of the send.
     */
    public static function sendToToken(string $fcmToken, string $title, string $body, array $data = []): bool
    {
        self::$lastError = null;

        $projectId = self::setting('firebase_project_id');
        $serviceAccountJson = self::setting('firebase_service_account_json');
        if ($projectId === '' || $serviceAccountJson === '') {
            self::$lastError = 'Firebase is not configured (Settings > Notifications > Push Notifications).';
            return false;
        }

        $accessToken = self::getAccessToken($serviceAccountJson);
        if ($accessToken === null) {
            return false; // self::$lastError already set
        }

        $message = [
            'message' => [
                'token' => $fcmToken,
                'notification' => [
                    'title' => $title,
                    'body' => $body,
                ],
            ],
        ];
        if (!empty($data)) {
            // FCM data payload values must all be strings.
            $message['message']['data'] = array_map('strval', $data);
        }

        [$status, $responseBody] = self::httpPostJson(
            'https://fcm.googleapis.com/v1/projects/' . rawurlencode($projectId) . '/messages:send',
            $message,
            ['Authorization: Bearer ' . $accessToken]
        );

        if ($status >= 200 && $status < 300) {
            return true;
        }

        self::$lastError = 'FCM send failed (HTTP ' . $status . '): ' . self::shortError($responseBody);
        return false;
    }

    /**
     * Exchange the service account's private key for a short-lived OAuth2
     * access token. Cached in-process for the lifetime of the request only
     * (a script sending many announcements in one request reuses it instead
     * of re-signing a JWT and re-requesting a token per device).
     */
    private static function getAccessToken(string $serviceAccountJson): ?string
    {
        static $cached = null;
        static $cachedForJson = null;
        if ($cached !== null && $cachedForJson === $serviceAccountJson) {
            return $cached;
        }

        $account = json_decode($serviceAccountJson, true);
        if (!is_array($account) || empty($account['private_key']) || empty($account['client_email'])) {
            self::$lastError = 'The saved Firebase service account JSON is invalid or incomplete.';
            return null;
        }

        $now = time();
        $header = ['alg' => 'RS256', 'typ' => 'JWT'];
        $claims = [
            'iss' => $account['client_email'],
            'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
            'aud' => 'https://oauth2.googleapis.com/token',
            'iat' => $now,
            'exp' => $now + 3600,
        ];

        $segments = [
            self::base64UrlEncode(json_encode($header, JSON_UNESCAPED_SLASHES)),
            self::base64UrlEncode(json_encode($claims, JSON_UNESCAPED_SLASHES)),
        ];
        $signingInput = implode('.', $segments);

        $signature = '';
        $privateKey = openssl_pkey_get_private($account['private_key']);
        if ($privateKey === false) {
            self::$lastError = 'Could not read the private key inside the saved Firebase service account JSON.';
            return null;
        }
        $ok = openssl_sign($signingInput, $signature, $privateKey, OPENSSL_ALGO_SHA256);
        if (!$ok) {
            self::$lastError = 'Failed to sign the Firebase auth request (openssl_sign failed).';
            return null;
        }
        $segments[] = self::base64UrlEncode($signature);
        $jwt = implode('.', $segments);

        [$status, $responseBody] = self::httpPostForm(
            'https://oauth2.googleapis.com/token',
            [
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion' => $jwt,
            ]
        );

        $decoded = json_decode((string)$responseBody, true);
        if ($status !== 200 || !is_array($decoded) || empty($decoded['access_token'])) {
            self::$lastError = 'Could not get a Firebase access token (HTTP ' . $status . '): ' . self::shortError($responseBody);
            return null;
        }

        $cached = (string)$decoded['access_token'];
        $cachedForJson = $serviceAccountJson;
        return $cached;
    }

    private static function setting(string $key): string
    {
        $row = Database::fetchOne('SELECT `value` FROM settings WHERE `key` = ?', 's', [$key]);
        return trim((string)($row['value'] ?? ''));
    }

    private static function base64UrlEncode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    /** @return array{0:int,1:string} [http status, response body] */
    private static function httpPostJson(string $url, array $payload, array $headers = []): array
    {
        return self::httpPost($url, json_encode($payload), array_merge(['Content-Type: application/json'], $headers));
    }

    /** @return array{0:int,1:string} [http status, response body] */
    private static function httpPostForm(string $url, array $fields): array
    {
        return self::httpPost($url, http_build_query($fields), ['Content-Type: application/x-www-form-urlencoded']);
    }

    /** @return array{0:int,1:string} [http status, response body] */
    private static function httpPost(string $url, string $body, array $headers): array
    {
        if (!function_exists('curl_init')) {
            self::$lastError = 'The PHP curl extension is required to send push notifications and is not enabled on this server.';
            return [0, ''];
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $response = curl_exec($ch);
        if ($response === false) {
            $err = curl_error($ch);
            curl_close($ch);
            self::$lastError = 'Network error contacting Google: ' . $err;
            return [0, ''];
        }
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return [$status, (string)$response];
    }

    private static function shortError(string $responseBody): string
    {
        $decoded = json_decode($responseBody, true);
        if (is_array($decoded) && isset($decoded['error'])) {
            if (is_array($decoded['error']) && isset($decoded['error']['message'])) {
                return (string)$decoded['error']['message'];
            }
            if (is_string($decoded['error'])) {
                return $decoded['error'];
            }
        }
        return substr($responseBody, 0, 200);
    }
}
