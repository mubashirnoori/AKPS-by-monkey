<?php

class CSRF
{
    public static function token(): string
    {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return (string)$_SESSION['csrf_token'];
    }

    public static function validate(?string $token): void
    {
        $expected = $_SESSION['csrf_token'] ?? '';
        if (!$token || !hash_equals((string)$expected, (string)$token)) {
            throw new RuntimeException('Invalid CSRF token');
        }
    }
}

