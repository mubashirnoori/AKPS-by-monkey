<?php

/**
 * Long-lived, HMAC-signed tokens that grant read-only access to ONE specific
 * record (a fee invoice, a report card, an attendance summary) with no login
 * at all — this is what lets a "Send via WhatsApp" button work from a
 * parent's phone, since the parent never has an account on this system.
 *
 * HOW THIS DIFFERS FROM DownloadToken
 * ------------------------------------
 * DownloadToken (app/core/DownloadToken.php) proves "this is user X, as of a
 * few minutes ago" — it's a session bridge for a user who IS logged in, and
 * every real permission check still runs against their live role. This class
 * is the opposite shape: nobody is logged in, so instead of a user id it
 * signs the RESOURCE itself (a type + an id, e.g. "fee_invoice" #482) with a
 * much longer expiry (share links get sent once and may sit in a WhatsApp
 * chat for months). The controller that verifies the token must still
 * independently re-check anything that could have changed since the link was
 * generated (e.g. "has this exam's results actually been published?") —
 * exactly the same "don't trust stale state" principle DownloadToken uses,
 * just with a resource in place of a user.
 *
 * SECURITY NOTES
 * --------------
 * - The token is a bearer credential: whoever holds the link can view that
 *   one record, same as a Google Drive "anyone with the link" share. Do not
 *   put anything more sensitive than what the record itself already shows
 *   (a fee amount, a report card, an attendance count) behind it.
 * - Scoped to exactly one (type, id) pair — a token minted for invoice #482
 *   cannot be replayed against invoice #483, even by editing the URL,
 *   because the id is inside the signed payload, not a separate parameter
 *   the server trusts on its own.
 * - `extra` lets a route add a second dimension (e.g. report card needs
 *   student_id AND exam_id) without weakening the signature — it's signed
 *   as part of the same payload, not appended afterwards.
 * - Uses its own secret file (share_token.key), deliberately separate from
 *   DownloadToken's key, so the two systems can be rotated independently —
 *   e.g. if a share link ever leaked publicly (forwarded outside WhatsApp),
 *   rotating share_token.key invalidates every outstanding share link
 *   without also logging out every staff session.
 */
class ShareToken
{
    /** Share links get sent once and may sit unread in a chat for a while. */
    private const DEFAULT_TTL_SECONDS = 60 * 60 * 24 * 120; // 120 days

    private static ?string $secretCache = null;

    /**
     * Creates a signed token scoped to one resource.
     *
     * @param string $type   Short resource type tag, e.g. 'fee_invoice', 'report_card', 'attendance'.
     * @param int    $id     The primary resource id (invoice id / student id / etc).
     * @param array  $extra  Optional extra scoping data (e.g. ['exam_id' => 5]). Keep small — it's
     *                       part of the signed payload and appears (base64'd) in the URL.
     */
    public static function generate(string $type, int $id, array $extra = [], int $ttlSeconds = self::DEFAULT_TTL_SECONDS): string
    {
        $payload = [
            'typ' => $type,
            'id'  => $id,
            'ext' => $extra,
            'exp' => time() + max(60, $ttlSeconds),
        ];
        $encodedPayload = self::base64UrlEncode((string)json_encode($payload));
        $signature = self::sign($encodedPayload);
        return $encodedPayload . '.' . $signature;
    }

    /**
     * Verifies a token against an EXPECTED type. Returns the decoded payload
     * (['id' => int, 'extra' => array]) on success, or null if the token is
     * missing, malformed, wrong type, has a bad signature, or has expired.
     *
     * Passing $expectedType is mandatory (not optional/default) so a token
     * minted for one route can never be silently accepted by another route
     * that forgot to check the type — e.g. a fee-voucher link opening a
     * report card just because the id happened to match.
     */
    public static function verify(?string $token, string $expectedType): ?array
    {
        if ($token === null || $token === '') {
            return null;
        }
        $parts = explode('.', $token, 2);
        if (count($parts) !== 2) {
            return null;
        }
        [$encodedPayload, $signature] = $parts;

        $expectedSignature = self::sign($encodedPayload);
        if (!hash_equals($expectedSignature, $signature)) {
            return null;
        }

        $json = self::base64UrlDecode($encodedPayload);
        $payload = $json !== false ? json_decode($json, true) : null;
        if (!is_array($payload) || !isset($payload['typ'], $payload['id'], $payload['exp'])) {
            return null;
        }

        if (!hash_equals($expectedType, (string)$payload['typ'])) {
            return null;
        }

        if ((int)$payload['exp'] < time()) {
            return null; // expired
        }

        return [
            'id'    => (int)$payload['id'],
            'extra' => is_array($payload['ext'] ?? null) ? $payload['ext'] : [],
        ];
    }

    private static function sign(string $encodedPayload): string
    {
        return self::base64UrlEncode(hash_hmac('sha256', $encodedPayload, self::secret(), true));
    }

    /**
     * The HMAC secret. Prefers the SHARE_TOKEN_KEY environment variable
     * (recommended for production, especially multi-server setups). Falls
     * back to a random key generated once and persisted next to config.php,
     * so this works out of the box with zero manual configuration.
     */
    private static function secret(): string
    {
        if (self::$secretCache !== null) {
            return self::$secretCache;
        }

        $fromEnv = getenv('SHARE_TOKEN_KEY');
        if (is_string($fromEnv) && $fromEnv !== '') {
            return self::$secretCache = $fromEnv;
        }

        $config = require __DIR__ . '/../../config/config.php';
        $fromConfig = $config['app']['share_token_key'] ?? '';
        if (is_string($fromConfig) && $fromConfig !== '') {
            return self::$secretCache = $fromConfig;
        }

        // Last resort: a per-install key generated once and cached to disk
        // (outside public/, so it's never web-accessible).
        $keyFile = __DIR__ . '/../../config/share_token.key';
        if (is_file($keyFile)) {
            $existing = trim((string)file_get_contents($keyFile));
            if ($existing !== '') {
                return self::$secretCache = $existing;
            }
        }

        $generated = bin2hex(random_bytes(32));
        // Best-effort write; if the filesystem is read-only, fail open with
        // an in-memory-only key rather than fatally erroring the request.
        @file_put_contents($keyFile, $generated, LOCK_EX);
        @chmod($keyFile, 0600);
        return self::$secretCache = $generated;
    }

    private static function base64UrlEncode(string $data): string
    {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    /** @return string|false */
    private static function base64UrlDecode(string $data)
    {
        $padded = str_pad($data, strlen($data) % 4 === 0 ? strlen($data) : strlen($data) + (4 - strlen($data) % 4), '=');
        return base64_decode(strtr($padded, '-_', '+/'), true);
    }
}
