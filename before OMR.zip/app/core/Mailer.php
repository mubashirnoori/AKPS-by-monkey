<?php

/**
 * Central mail sender. Every caller only ever calls Mailer::send() — this
 * class decides *how* the message actually goes out:
 *
 *  - If SMTP is enabled in Settings > Notifications (with a host saved),
 *    it sends through that SMTP server via SmtpMailer.
 *  - Otherwise it falls back to PHP's built-in mail(), same as before.
 *
 * All SMTP configuration (host, port, encryption, username, password) is
 * read from the `settings` table — it is entered in the app's Settings UI,
 * not hard-coded here.
 */
class Mailer
{
    /** Human-readable reason the last send() call failed, if it did. */
    public static ?string $lastError = null;

    public static function send(string $toEmail, string $toName, string $subject, string $htmlBody): bool
    {
        self::$lastError = null;
        $config = require __DIR__ . '/../../config/config.php';
        $settings = self::loadMailSettings();

        $fromEmail = $settings['mail_from_email'] !== ''
            ? $settings['mail_from_email']
            : (string)($config['mail']['from_email'] ?? 'no-reply@' . ($_SERVER['HTTP_HOST'] ?? 'localhost'));

        $fromName = $settings['mail_from_name'] !== ''
            ? $settings['mail_from_name']
            : (string)($config['mail']['from_name'] ?? ($config['app']['name'] ?? 'School Management System'));

        if ($settings['smtp_enabled'] === '1' && $settings['smtp_host'] !== '') {
            $smtpConfig = [
                'host' => $settings['smtp_host'],
                'port' => $settings['smtp_port'] !== '' ? (int)$settings['smtp_port'] : 587,
                'encryption' => $settings['smtp_encryption'] !== '' ? $settings['smtp_encryption'] : 'tls',
                'auth' => $settings['smtp_auth'] !== '0',
                'username' => $settings['smtp_username'],
                'password' => $settings['smtp_password'],
                'verify_peer' => $settings['smtp_verify_cert'] !== '0',
            ];

            $error = null;
            $ok = SmtpMailer::send($smtpConfig, $toEmail, $toName, $fromEmail, $fromName, $subject, $htmlBody, $error);
            if (!$ok) {
                self::$lastError = $error ?: 'SMTP send failed.';
                error_log('[Mailer:SMTP] send failed: ' . self::$lastError);
            }
            return $ok;
        }

        return self::sendViaPhpMail($toEmail, $toName, $subject, $htmlBody, $fromEmail, $fromName);
    }

    private static function sendViaPhpMail(
        string $toEmail,
        string $toName,
        string $subject,
        string $htmlBody,
        string $fromEmail,
        string $fromName
    ): bool {
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= 'From: ' . self::encodeHeader($fromName) . ' <' . $fromEmail . ">\r\n";
        $headers .= 'Reply-To: ' . $fromEmail . "\r\n";

        $encodedSubject = self::encodeHeader($subject);
        $to = self::encodeHeader($toName) . ' <' . $toEmail . '>';

        try {
            $ok = @mail($to, $encodedSubject, $htmlBody, $headers);
            if (!$ok) {
                self::$lastError = "PHP mail() returned false. Your host's mail server may not be configured — "
                    . 'turn on SMTP in Settings > Notifications instead.';
            }
            return $ok;
        } catch (Throwable $e) {
            self::$lastError = $e->getMessage();
            error_log('[Mailer] send failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * @return array<string,string>
     */
    private static function loadMailSettings(): array
    {
        $defaults = [
            'mail_from_email' => '',
            'mail_from_name' => '',
            'smtp_enabled' => '0',
            'smtp_host' => '',
            'smtp_port' => '',
            'smtp_encryption' => 'tls',
            'smtp_auth' => '1',
            'smtp_username' => '',
            'smtp_password' => '',
            'smtp_verify_cert' => '1',
        ];

        try {
            if (class_exists('Database')) {
                $rows = Database::fetchAll(
                    "SELECT `key`, `value` FROM settings WHERE `key` IN ('" . implode("','", array_keys($defaults)) . "')"
                );
                foreach ($rows as $r) {
                    $k = (string)$r['key'];
                    if (array_key_exists($k, $defaults)) {
                        $defaults[$k] = (string)$r['value'];
                    }
                }
            }
        } catch (Throwable $e) {
            // Fall through to defaults / config.php values below.
        }

        return $defaults;
    }

    private static function encodeHeader(string $value): string
    {
        return '=?UTF-8?B?' . base64_encode($value) . '?=';
    }
}
