<?php

/**
 * Minimal, dependency-free SMTP client. Talks raw SMTP over a socket
 * (EHLO / STARTTLS / AUTH LOGIN / MAIL FROM / RCPT TO / DATA), so it works
 * with any SMTP provider (Gmail, Outlook 365, SendGrid, Mailgun, cPanel/
 * shared-hosting mail servers, etc.) without composer or any external
 * library. Called only from Mailer::send() — nothing else in the app talks
 * to this class directly.
 */
class SmtpMailer
{
    /**
     * @param array{
     *   host: string, port: int, encryption: string, auth: bool,
     *   username: string, password: string, verify_peer?: bool, timeout?: int
     * } $config
     */
    public static function send(
        array $config,
        string $toEmail,
        string $toName,
        string $fromEmail,
        string $fromName,
        string $subject,
        string $htmlBody,
        ?string &$error = null
    ): bool {
        $error = null;

        $host = trim((string)($config['host'] ?? ''));
        $port = (int)($config['port'] ?? 587);
        $encryption = strtolower(trim((string)($config['encryption'] ?? 'tls')));
        if (!in_array($encryption, ['none', 'ssl', 'tls'], true)) {
            $encryption = 'tls';
        }
        $useAuth = !empty($config['auth']);
        $username = (string)($config['username'] ?? '');
        $password = (string)($config['password'] ?? '');
        $verifyPeer = array_key_exists('verify_peer', $config) ? (bool)$config['verify_peer'] : true;
        $timeout = (int)($config['timeout'] ?? 15);
        if ($timeout <= 0) {
            $timeout = 15;
        }

        if ($host === '') {
            $error = 'SMTP host is not configured.';
            return false;
        }
        if ($fromEmail === '' || !filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) {
            $error = 'A valid "from" email address is required.';
            return false;
        }
        if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid recipient email address.';
            return false;
        }

        $remote = ($encryption === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port;
        $context = stream_context_create([
            'ssl' => [
                'verify_peer' => $verifyPeer,
                'verify_peer_name' => $verifyPeer,
                'allow_self_signed' => !$verifyPeer,
            ],
        ]);

        $socket = @stream_socket_client($remote, $errno, $errstr, $timeout, STREAM_CLIENT_CONNECT, $context);
        if ($socket === false) {
            $error = "Could not connect to {$host}:{$port} — {$errstr} ({$errno})";
            return false;
        }
        stream_set_timeout($socket, $timeout);

        // Server greeting.
        if (!self::command($socket, '', [220], $error)) {
            fclose($socket);
            return false;
        }

        $localName = self::localHostname();

        if (!self::command($socket, "EHLO {$localName}", [250], $error)) {
            fclose($socket);
            return false;
        }

        if ($encryption === 'tls') {
            if (!self::command($socket, 'STARTTLS', [220], $error)) {
                fclose($socket);
                return false;
            }
            if (!@stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                $error = 'TLS negotiation with the SMTP server failed.';
                fclose($socket);
                return false;
            }
            // Must re-introduce ourselves after upgrading the connection.
            if (!self::command($socket, "EHLO {$localName}", [250], $error)) {
                fclose($socket);
                return false;
            }
        }

        if ($useAuth && $username !== '') {
            if (!self::command($socket, 'AUTH LOGIN', [334], $error)) {
                fclose($socket);
                return false;
            }
            if (!self::command($socket, base64_encode($username), [334], $error)) {
                fclose($socket);
                return false;
            }
            if (!self::command($socket, base64_encode($password), [235], $error)) {
                $error = 'SMTP authentication failed — check the SMTP username and password. (' . $error . ')';
                fclose($socket);
                return false;
            }
        }

        if (!self::command($socket, "MAIL FROM:<{$fromEmail}>", [250], $error)) {
            fclose($socket);
            return false;
        }
        if (!self::command($socket, "RCPT TO:<{$toEmail}>", [250, 251], $error)) {
            fclose($socket);
            return false;
        }
        if (!self::command($socket, 'DATA', [354], $error)) {
            fclose($socket);
            return false;
        }

        $headers = [];
        $headers[] = 'Date: ' . date('r');
        $headers[] = 'From: ' . self::encodeHeader($fromName) . " <{$fromEmail}>";
        $headers[] = 'To: ' . self::encodeHeader($toName) . " <{$toEmail}>";
        $headers[] = 'Subject: ' . self::encodeHeader($subject);
        $headers[] = 'MIME-Version: 1.0';
        $headers[] = 'Content-Type: text/html; charset=UTF-8';
        $headers[] = 'Message-ID: <' . bin2hex(random_bytes(16)) . '@' . preg_replace('/^www\./', '', $host) . '>';

        $body = str_replace(["\r\n", "\r"], "\n", $htmlBody);
        $body = str_replace("\n", "\r\n", $body);
        // RFC 5321 dot-stuffing: a line starting with '.' must be escaped with an extra '.'.
        $body = preg_replace('/(^|\r\n)\./', '$1..', $body);

        $data = implode("\r\n", $headers) . "\r\n\r\n" . $body . "\r\n.\r\n";
        fwrite($socket, $data);

        if (!self::command($socket, '', [250], $error)) {
            fclose($socket);
            return false;
        }

        fwrite($socket, "QUIT\r\n");
        fclose($socket);

        return true;
    }

    /**
     * Sends a command (unless empty, in which case it just reads the next
     * response — used for the initial greeting and after DATA's body) and
     * checks the reply code against $expectedCodes.
     *
     * @param array<int> $expectedCodes
     */
    private static function command($socket, string $cmd, array $expectedCodes, ?string &$error): bool
    {
        if ($cmd !== '') {
            fwrite($socket, $cmd . "\r\n");
        }

        $responseText = '';
        $code = self::readResponse($socket, $responseText);

        if (!in_array((int)$code, $expectedCodes, true)) {
            $shown = $cmd !== '' && stripos($cmd, 'AUTH LOGIN') === false && !preg_match('/^[A-Za-z0-9+\/=]+$/', $cmd)
                ? $cmd
                : ($cmd !== '' ? '[command]' : '[greeting]');
            $error = 'Unexpected SMTP response' . ($cmd !== '' ? " to {$shown}" : '') . ': ' . trim($responseText);
            return false;
        }

        return true;
    }

    private static function readResponse($socket, ?string &$fullText = null): string
    {
        $fullText = '';
        while (!feof($socket)) {
            $line = fgets($socket, 515);
            if ($line === false) {
                break;
            }
            $fullText .= $line;
            // The final line of a (possibly multi-line) reply has a space
            // as the 4th character; continuation lines use a hyphen.
            if (isset($line[3]) && $line[3] === ' ') {
                break;
            }
        }
        return substr($fullText, 0, 3);
    }

    private static function localHostname(): string
    {
        $host = $_SERVER['SERVER_NAME'] ?? $_SERVER['HTTP_HOST'] ?? gethostname();
        $host = is_string($host) ? (preg_replace('/:\d+$/', '', $host) ?? '') : '';
        return $host !== '' ? $host : 'localhost';
    }

    private static function encodeHeader(string $value): string
    {
        return '=?UTF-8?B?' . base64_encode($value) . '?=';
    }
}
