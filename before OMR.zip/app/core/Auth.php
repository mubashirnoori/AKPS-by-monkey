<?php

class Auth
{
    /**
     * Set only for the duration of a single request that authenticated via a
     * DownloadToken instead of the session cookie (see requireLoginOrToken()
     * below). Deliberately NOT written to $_SESSION: a download token is
     * meant to grant a few minutes of access for one export request, not
     * establish a persistent logged-in session for whoever holds the link.
     */
    private static ?array $tokenUser = null;

    public static function currentUser(): ?array
    {
        if (self::$tokenUser !== null) {
            return self::$tokenUser;
        }

        $id = $_SESSION['user_id'] ?? null;
        if (!$id) {
            return null;
        }
        return [
            'id' => $id,
            'username' => $_SESSION['username'] ?? '',
            'role_id' => (int)($_SESSION['role_id'] ?? 0),
            'role_name' => $_SESSION['role_name'] ?? '',
        ];
    }

    public static function requireLogin(): array
    {
        self::enforceSessionTimeout();
        self::enforceSingleSession();
        $user = self::currentUser();
        if (!$user) {
            redirect_route('auth/login');
        }
        self::sendNoCacheHeaders();
        return $user;
    }

    /**
     * Same as requireLogin(), but ALSO accepts a valid `dl_token` query
     * parameter (see DownloadToken) as an alternative to the session cookie.
     * Use this instead of requireLogin() for export/download actions — it's
     * a strict superset: a real session still works exactly as before, this
     * only adds a second, cookie-independent way in for download links.
     *
     * Every downstream permission check (requirePermission/RBAC) still runs
     * exactly the same way against this user's real current role — the token
     * only proves identity, not authorization.
     */
    public static function requireLoginOrToken(): array
    {
        self::enforceSessionTimeout();
        self::enforceSingleSession();

        $user = self::currentUser();
        if ($user) {
            self::sendNoCacheHeaders();
            return $user;
        }

        $userId = DownloadToken::verify($_GET['dl_token'] ?? null);
        if ($userId !== null) {
            $row = Database::fetchOne(
                'SELECT u.id, u.username, u.role_id, r.name AS role_name, u.status
                 FROM users u JOIN roles r ON r.id = u.role_id
                 WHERE u.id = ? LIMIT 1',
                'i',
                [$userId]
            );
            if ($row && (int)($row['status'] ?? 0) === 1) {
                self::$tokenUser = [
                    'id' => (int)$row['id'],
                    'username' => (string)$row['username'],
                    'role_id' => (int)$row['role_id'],
                    'role_name' => (string)($row['role_name'] ?? ''),
                ];
                self::sendNoCacheHeaders();
                return self::$tokenUser;
            }
        }

        // Neither a session nor a valid token — behave exactly like
        // requireLogin() so this fails the same safe way it always did.
        redirect_route('auth/login');
    }

    /**
     * Tell the browser never to cache this response. Without this, hitting
     * Back after logging out can redisplay a page straight from the browser's
     * cache/back-forward-cache — no request ever reaches the server, so the
     * "already logged out" check never runs and the old page just reappears.
     * The session itself IS destroyed (see logout() below); this only stops
     * the browser from showing a stale local copy instead of asking again.
     */
    private static function sendNoCacheHeaders(): void
    {
        if (headers_sent()) {
            return;
        }
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
    }

    private const MAX_FAILED_ATTEMPTS = 5;
    private const LOCKOUT_MINUTES = 1;

    // Per-IP throttle: separate from the per-account lockout above, which only
    // limits attempts against ONE username. Without this, an attacker can try
    // many different usernames from a single IP with no limit at all.
    private const IP_MAX_ATTEMPTS = 20;
    private const IP_WINDOW_MINUTES = 15;
    private const IP_LOCKOUT_MINUTES = 15;

    private static function ensureLoginThrottleTable(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        $done = true;
        try {
            Database::execute(
                'CREATE TABLE IF NOT EXISTS login_ip_throttle (
                    ip_address VARCHAR(45) NOT NULL PRIMARY KEY,
                    attempts INT NOT NULL DEFAULT 0,
                    window_started_at DATETIME NOT NULL,
                    locked_until DATETIME NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4'
            );
        } catch (Throwable $e) {
            // ignore — e.g. DB user lacks CREATE TABLE; throttle silently no-ops below
        }
    }

    private static function clientIp(): string
    {
        $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
        return $ip !== '' ? substr($ip, 0, 45) : 'unknown';
    }

    /** Throws if this IP has failed too many login attempts recently. Call before checking credentials. */
    private static function enforceIpThrottle(): void
    {
        self::ensureLoginThrottleTable();
        $ip = self::clientIp();
        try {
            $row = Database::fetchOne('SELECT * FROM login_ip_throttle WHERE ip_address = ?', 's', [$ip]);
        } catch (Throwable $e) {
            return; // table unavailable — don't block logins over a missing throttle table
        }
        if ($row && !empty($row['locked_until']) && strtotime((string)$row['locked_until']) > time()) {
            $minutesLeft = (int)ceil((strtotime((string)$row['locked_until']) - time()) / 60);
            throw new RuntimeException('Too many login attempts from this connection. Try again in ' . $minutesLeft . ' minute(s).');
        }
    }

    /** Records one failed attempt from this IP; locks the IP out if it crosses the threshold. */
    private static function recordIpFailure(): void
    {
        $ip = self::clientIp();
        try {
            $row = Database::fetchOne('SELECT * FROM login_ip_throttle WHERE ip_address = ?', 's', [$ip]);
            $now = time();
            $windowStart = $row ? strtotime((string)$row['window_started_at']) : $now;
            $windowExpired = ($now - $windowStart) > (self::IP_WINDOW_MINUTES * 60);

            $attempts = (!$row || $windowExpired) ? 1 : ((int)$row['attempts'] + 1);
            $windowStartedAt = (!$row || $windowExpired) ? date('Y-m-d H:i:s', $now) : $row['window_started_at'];
            $lockedUntil = null;
            if ($attempts >= self::IP_MAX_ATTEMPTS) {
                $lockedUntil = date('Y-m-d H:i:s', $now + (self::IP_LOCKOUT_MINUTES * 60));
            }

            Database::execute(
                'INSERT INTO login_ip_throttle (ip_address, attempts, window_started_at, locked_until)
                 VALUES (?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE attempts = VALUES(attempts), window_started_at = VALUES(window_started_at), locked_until = VALUES(locked_until)',
                'siss',
                [$ip, $attempts, $windowStartedAt, $lockedUntil]
            );
        } catch (Throwable $e) {
            // ignore — throttle is defense-in-depth, must never block a legitimate login attempt from failing normally
        }
    }

    private static function resetIpThrottle(): void
    {
        try {
            Database::execute('DELETE FROM login_ip_throttle WHERE ip_address = ?', 's', [self::clientIp()]);
        } catch (Throwable $e) {
            // ignore
        }
    }

    public static function login(string $username, string $password): void
    {
        self::enforceIpThrottle();

        $row = Database::fetchOne(
            'SELECT u.id, u.username, u.password_hash, u.role_id, r.name AS role_name, u.status,
                    u.failed_attempts, u.locked_until
             FROM users u
             JOIN roles r ON r.id = u.role_id
             WHERE u.username = ? LIMIT 1',
            's',
            [$username]
        );

        if (!$row || empty($row['password_hash']) || (int)($row['status'] ?? 0) !== 1) {
            self::recordIpFailure();
            throw new RuntimeException('Invalid credentials');
        }

        if (!empty($row['locked_until']) && strtotime((string)$row['locked_until']) > time()) {
            $minutesLeft = (int)ceil((strtotime((string)$row['locked_until']) - time()) / 60);
            throw new RuntimeException('Too many failed attempts. Try again in ' . $minutesLeft . ' minute(s).');
        }

        if (!password_verify($password, $row['password_hash'])) {
            self::recordIpFailure();
            $attempts = (int)$row['failed_attempts'] + 1;
            if ($attempts >= self::MAX_FAILED_ATTEMPTS) {
                // Computed in PHP (not via MySQL's NOW()) so the lockout window can't
                // drift if the database server's clock/timezone differs from the app's.
                $lockedUntil = date('Y-m-d H:i:s', time() + (self::LOCKOUT_MINUTES * 60));
                Database::execute(
                    'UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?',
                    'isi',
                    [$attempts, $lockedUntil, (int)$row['id']]
                );
                throw new RuntimeException('Too many failed attempts. Try again in ' . self::LOCKOUT_MINUTES . ' minute(s).');
            }
            Database::execute('UPDATE users SET failed_attempts = ? WHERE id = ?', 'ii', [$attempts, (int)$row['id']]);
            throw new RuntimeException('Invalid credentials');
        }

        self::resetIpThrottle();

        if ((int)$row['failed_attempts'] > 0 || !empty($row['locked_until'])) {
            Database::execute('UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?', 'i', [(int)$row['id']]);
        }

        // Prevent session fixation.
        session_regenerate_id(true);

        // Single-active-session enforcement: generate a fresh token for this login
        // and record it as the account's one "current" session. Any other browser/
        // device already holding a session for this account will have an older
        // token and gets signed out the next time it makes a request — see
        // enforceSingleSession() below.
        self::ensureSessionTokenColumn();
        $sessionToken = bin2hex(random_bytes(32));
        Database::execute('UPDATE users SET active_session_token = ? WHERE id = ?', 'si', [$sessionToken, (int)$row['id']]);

        $_SESSION['user_id'] = (int)$row['id'];
        $_SESSION['username'] = (string)$row['username'];
        $_SESSION['role_id'] = (int)$row['role_id'];
        $_SESSION['role_name'] = (string)($row['role_name'] ?? '');
        $_SESSION['last_activity'] = time();
        $_SESSION['session_token'] = $sessionToken;
    }

    public static function logout(): void
    {
        $userId = $_SESSION['user_id'] ?? null;
        if ($userId) {
            try {
                Database::execute('UPDATE users SET active_session_token = NULL WHERE id = ?', 'i', [(int)$userId]);
            } catch (Throwable $e) {
                // ignore — logging out must still succeed even if this cleanup fails
            }
        }
        self::destroySession();
        redirect_route('auth/login');
    }

    /** Clears the session (data + cookie) without redirecting — shared by logout() and forceLogoutOtherDevice(). */
    private static function destroySession(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $params['path'],
                $params['domain'] ?? '',
                (bool)($params['secure'] ?? false),
                (bool)($params['httponly'] ?? false)
            );
        }
        session_destroy();
    }

    private static function ensureSessionTokenColumn(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        $done = true;
        try {
            Database::execute('ALTER TABLE users ADD COLUMN active_session_token VARCHAR(64) NULL DEFAULT NULL');
        } catch (Throwable $e) {
            // ignore — column already exists (or DB user lacks ALTER; single-session
            // enforcement below fails open in that case rather than locking everyone out)
        }
    }

    /**
     * Single-active-session enforcement: every login writes a fresh token to
     * users.active_session_token (see login() above). If the token stored in
     * THIS session no longer matches the one on the account, a newer login
     * elsewhere has taken over the account, so this session is signed out.
     * Applies to every user/role — there is only ever one "current" device.
     */
    private static function enforceSingleSession(): void
    {
        if (!isset($_SESSION['user_id']) || !isset($_SESSION['session_token'])) {
            return;
        }
        self::ensureSessionTokenColumn();
        try {
            $row = Database::fetchOne(
                'SELECT active_session_token FROM users WHERE id = ?',
                'i',
                [(int)$_SESSION['user_id']]
            );
        } catch (Throwable $e) {
            return; // fail open — a DB hiccup here must never lock everyone out
        }
        $dbToken = $row ? (string)($row['active_session_token'] ?? '') : '';
        if ($dbToken === '' || !hash_equals($dbToken, (string)$_SESSION['session_token'])) {
            self::destroySession();
            redirect('/index.php?route=' . rawurlencode('auth/login') . '&reason=session_replaced');
        }
    }

    private static function enforceSessionTimeout(): void
    {
        $config = require __DIR__ . '/../../config/config.php';
        $ttl = (int)($config['app']['session_inactivity_seconds'] ?? 1800);
        if ($ttl <= 0) {
            return;
        }
        if (!isset($_SESSION['last_activity'])) {
            return;
        }
        $now = time();
        $last = (int)$_SESSION['last_activity'];
        if (($now - $last) > $ttl) {
            self::logout();
            return;
        }
        $_SESSION['last_activity'] = $now;
    }
}

