<?php

require_once __DIR__ . '/../models/FeeAssignmentModel.php';
require_once __DIR__ . '/../models/FeeCategoryModel.php';
require_once __DIR__ . '/../models/StudentModel.php';

/**
 * FeeService
 * Handles all fee-related business logic including invoicing, fine calculation,
 * discount application, and dynamic fee generation.
 */
class FeeService
{
    /**
     * Generate invoice number with unique identifier
     */
    public static function generateInvoiceNo(): string
    {
        return 'INV-' . date('Ymd') . '-' . substr(uniqid((string)mt_rand(), true), -6);
    }

    public static function resolveBillingYear(?int $academicYearId, int $month): int
    {
        if ($academicYearId) {
            $ay = Database::fetchOne(
                'SELECT start_date, end_date FROM academic_years WHERE id = ?',
                'i',
                [$academicYearId]
            );
            if ($ay && !empty($ay['start_date'])) {
                $startMonth = (int)date('n', strtotime($ay['start_date']));
                $startYear = (int)date('Y', strtotime($ay['start_date']));
                if ($month >= $startMonth) {
                    return $startYear;
                }
                return $startYear + 1;
            }
        }
        return (int)date('Y');
    }

    /**
     * The 12 billing months of an academic year in order, each with the calendar year it falls
     * in (e.g. March 2026 ... February 2027). Starts at the month the year starts in (March if unknown).
     *
     * @return array<int,array{month:int,year:int,label:string}>
     */
    public static function billingMonthOptions(?int $academicYearId): array
    {
        $startMonth = 3;
        if ($academicYearId) {
            $ay = Database::fetchOne('SELECT start_date FROM academic_years WHERE id = ?', 'i', [$academicYearId]);
            if ($ay && !empty($ay['start_date'])) {
                $startMonth = (int)date('n', strtotime($ay['start_date']));
            }
        }
        $options = [];
        for ($i = 0; $i < 12; $i++) {
            $month = (($startMonth - 1 + $i) % 12) + 1;
            $year = self::resolveBillingYear($academicYearId, $month);
            $options[] = ['month' => $month, 'year' => $year, 'label' => self::getMonthName($month) . ' ' . $year];
        }
        return $options;
    }

    public static function createStudentInvoice(
        int $studentId,
        ?int $academicYearId,
        bool $includeAdmissionFee = false,
        array $selectedMonths = [],
        ?int $createdByUserId = null,
        bool $allowDuplicateAdmission = false
    ): array {
        $student = Database::fetchOne(
            'SELECT s.id, s.first_name, s.last_name, s.admission_no
             FROM students s
             WHERE s.id = ?',
            'i',
            [$studentId]
        );

        if (!$student) {
            throw new RuntimeException('Student not found');
        }

        $assignments = FeeAssignmentModel::getAssignmentsForStudent($studentId, $academicYearId);
        if (empty($assignments)) {
            throw new RuntimeException('No fee assignments found for this student');
        }

        $classSectionIdSnapshot = StudentModel::getCurrentClassSectionId($studentId);
        $classSectionIdSnapshot = $classSectionIdSnapshot ? (int)$classSectionIdSnapshot : 0;

        $conn = Database::connection();
        $conn->begin_transaction();

        try {
            $invoiceLines = [];
            $totalAmount = 0.0;
            $skippedNotes = [];
            $seenCategories = [];

            foreach ($assignments as $assignment) {
                $catId = (int)$assignment['fee_category_id'];
                if (isset($seenCategories[$catId])) {
                    continue;
                }
                $seenCategories[$catId] = true;

                $isOneTime = (int)($assignment['is_one_time'] ?? 0);
                $categoryName = $assignment['fee_category_name'] ?? 'Fee';

                if ($isOneTime) {
                    if (!$includeAdmissionFee) {
                        continue;
                    }

                    $picked = FeeAssignmentModel::pickAssignmentForCategory(
                        $catId,
                        $studentId,
                        $classSectionIdSnapshot,
                        $academicYearId,
                        null
                    );
                    $amount = $picked !== null ? (float)$picked['amount'] : 0.0;
                    if ($amount <= 0) {
                        continue;
                    }

                    $existing = Database::fetchOne(
                        'SELECT fil.id
                         FROM fee_invoice_lines fil
                         JOIN fee_invoices fi ON fi.id = fil.fee_invoice_id
                         WHERE fi.student_id = ?
                           AND fil.fee_category_id = ?
                           AND fi.status IN ("open","paid")',
                        'ii',
                        [$studentId, $catId]
                    );

                    if ($existing && !$allowDuplicateAdmission) {
                        $skippedNotes[] = $categoryName . ' (already invoiced)';
                        continue;
                    }

                    $invoiceLines[] = [
                        'category_id' => $catId,
                        'description' => $categoryName,
                        'amount' => $amount,
                        'billing_month' => null,
                        'billing_year' => null,
                    ];
                    $totalAmount += $amount;
                    continue;
                }

                if (!empty($selectedMonths)) {
                    foreach ($selectedMonths as $month) {
                        $month = (int)$month;
                        $picked = FeeAssignmentModel::pickAssignmentForCategory(
                            $catId,
                            $studentId,
                            $classSectionIdSnapshot,
                            $academicYearId,
                            $month
                        );
                        $amount = $picked !== null ? (float)$picked['amount'] : 0.0;
                        if ($amount <= 0) {
                            continue;
                        }

                        $alreadyInvoiced = Database::fetchOne(
                            'SELECT fi.invoice_no, fi.status
                             FROM fee_invoice_lines fil
                             JOIN fee_invoices fi ON fi.id = fil.fee_invoice_id
                             WHERE fi.student_id = ?
                               AND fil.fee_category_id = ?
                               AND fil.billing_month = ?
                               AND fi.academic_year_id <=> ?
                               AND fi.status IN ("open","paid")
                             LIMIT 1',
                            'iiii',
                            [$studentId, $catId, $month, $academicYearId]
                        );

                        if ($alreadyInvoiced) {
                            $status = (string)($alreadyInvoiced['status'] ?? 'open');
                            $skippedNotes[] = $categoryName . ' - ' . self::getMonthName($month)
                                . ' (already ' . ($status === 'paid' ? 'paid' : 'invoiced')
                                . ', invoice ' . $alreadyInvoiced['invoice_no'] . ')';
                            continue;
                        }

                        $description = $categoryName . ' - ' . self::getMonthName($month);
                        $invoiceLines[] = [
                            'category_id' => $catId,
                            'description' => $description,
                            'amount' => $amount,
                            'billing_month' => $month,
                            'billing_year' => self::resolveBillingYear($academicYearId, $month),
                        ];
                        $totalAmount += $amount;
                    }
                } else {
                    $picked = FeeAssignmentModel::pickAssignmentForCategory(
                        $catId,
                        $studentId,
                        $classSectionIdSnapshot,
                        $academicYearId,
                        null
                    );
                    $amount = $picked !== null ? (float)$picked['amount'] : 0.0;
                    if ($amount <= 0) {
                        continue;
                    }
                    $invoiceLines[] = [
                        'category_id' => $catId,
                        'description' => $categoryName,
                        'amount' => $amount,
                        'billing_month' => null,
                        'billing_year' => null,
                    ];
                    $totalAmount += $amount;
                }
            }

            if (empty($invoiceLines)) {
                $conn->rollback();
                if (!empty($skippedNotes)) {
                    throw new RuntimeException(
                        'Nothing to invoice — already billed: ' . implode(', ', $skippedNotes)
                    );
                }
                throw new RuntimeException(
                    'No fees to invoice. Check: fee assignments exist for this student/class, amount > 0, '
                    . 'academic year matches, months selected for tuition, and admission fee checkbox if needed.'
                );
            }

            $safeCreatedBy = null;
            if ($createdByUserId !== null && (int)$createdByUserId > 0) {
                $userExists = Database::fetchOne(
                    'SELECT id FROM users WHERE id = ? LIMIT 1',
                    'i',
                    [(int)$createdByUserId]
                );
                if ($userExists) {
                    $safeCreatedBy = (int)$createdByUserId;
                }
            }

            // Snapshot the student's class at the moment the invoice is
            // generated. This is deliberately NOT re-derived from the
            // student's current assignment when the invoice is later
            // displayed -- otherwise promoting the student would silently
            // rewrite the class on every past invoice too.
            $dueDate = date('Y-m-d', strtotime('+10 days'));

            // One invoice per billing month, not one invoice bundling every
            // selected month together. Lines with no month (one-time fees
            // like admission/exam) ride along on the earliest month's
            // invoice so they don't need a bare invoice of their own when
            // months were also selected; if no month-tagged lines exist at
            // all, they get a single invoice together as before.
            $groups = [];
            $monthlessKey = '_none';
            foreach ($invoiceLines as $line) {
                $key = $line['billing_month'] !== null ? (string)$line['billing_month'] : $monthlessKey;
                $groups[$key][] = $line;
            }
            if (isset($groups[$monthlessKey]) && count($groups) > 1) {
                $firstMonthKey = null;
                foreach (array_keys($groups) as $k) {
                    if ($k !== $monthlessKey) {
                        $firstMonthKey = $k;
                        break;
                    }
                }
                if ($firstMonthKey !== null) {
                    $groups[$firstMonthKey] = array_merge($groups[$firstMonthKey], $groups[$monthlessKey]);
                    unset($groups[$monthlessKey]);
                }
            }
            ksort($groups, SORT_NUMERIC);

            $invoiceIds = [];
            foreach ($groups as $groupLines) {
                $groupTotal = array_sum(array_column($groupLines, 'amount'));
                $invoiceNo = self::generateInvoiceNo();

                Database::execute(
                    'INSERT INTO fee_invoices
                        (invoice_no, student_id, academic_year_id, class_section_id, status, total_amount, total_discount, total_due, fine_applied, due_date, created_by_user_id)
                     VALUES (?, ?, ?, ?, ?, ?, 0.00, ?, 0.00, ?, ?)',
                    'siiisddsi',
                    [
                        $invoiceNo,
                        $studentId,
                        $academicYearId,
                        $classSectionIdSnapshot,
                        'open',
                        $groupTotal,
                        $groupTotal,
                        $dueDate,
                        $safeCreatedBy,
                    ]
                );

                $invoiceId = (int)Database::lastInsertId();

                foreach ($groupLines as $line) {
                    Database::execute(
                        'INSERT INTO fee_invoice_lines
                            (fee_invoice_id, fee_category_id, billing_month, billing_year, description, base_amount, discount_amount, line_total)
                         VALUES (?, ?, ?, ?, ?, ?, 0.00, ?)',
                        'iiiisdd',
                        [
                            $invoiceId,
                            $line['category_id'],
                            $line['billing_month'],
                            $line['billing_year'],
                            $line['description'],
                            $line['amount'],
                            $line['amount'],
                        ]
                    );
                }

                self::applyDiscountsToInvoice($invoiceId, $studentId);
                self::recalculateInvoiceTotals($invoiceId);
                $invoiceIds[] = $invoiceId;
            }

            $conn->commit();
            return ['invoice_id' => $invoiceIds[0], 'invoice_ids' => $invoiceIds, 'skipped' => $skippedNotes];
        } catch (Throwable $e) {
            $conn->rollback();
            throw $e;
        }
    }

    public static function createClassInvoices(
        int $classSectionId,
        array $selectedMonths,
        ?int $academicYearId = null,
        bool $includeAdmissionFee = false,
        ?int $createdByUserId = null,
        bool $allowDuplicateAdmission = false
    ): array {
        if (empty($selectedMonths) && !$includeAdmissionFee) {
            throw new RuntimeException('Select at least one month, or include admission / one-time fee');
        }

        $students = Database::fetchAll(
            'SELECT s.id, s.admission_no, s.first_name, s.last_name
             FROM students s
             INNER JOIN student_class_assignments sca
               ON sca.id = (
                 SELECT sca2.id
                 FROM student_class_assignments sca2
                 WHERE sca2.student_id = s.id
                 ORDER BY sca2.assigned_at DESC, sca2.id DESC
                 LIMIT 1
               )
             WHERE sca.class_section_id = ?
               AND IFNULL(s.status, 1) = 1
             ORDER BY s.id',
            'i',
            [$classSectionId]
        );

        if (empty($students)) {
            throw new RuntimeException('No active students currently assigned to this class/section');
        }

        $createdInvoices = [];
        $errors = [];
        $alreadyUpToDate = 0;
        $partialSkips = [];

        foreach ($students as $student) {
            $sid = (int)$student['id'];
            $label = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
            if ($label === '') {
                $label = 'ID #' . $sid;
            }
            try {
                $result = self::createStudentInvoice(
                    $sid,
                    $academicYearId,
                    $includeAdmissionFee,
                    $selectedMonths,
                    $createdByUserId,
                    $allowDuplicateAdmission
                );
                $createdInvoices = array_merge($createdInvoices, $result['invoice_ids']);
                if (!empty($result['skipped'])) {
                    $partialSkips[] = $label . ': ' . implode(', ', $result['skipped']);
                }
            } catch (Throwable $e) {
                $msg = $e->getMessage();
                if (stripos($msg, 'already billed') !== false || stripos($msg, 'already invoiced') !== false) {
                    $alreadyUpToDate++;
                } else {
                    $errors[] = $label . ' (' . ($student['admission_no'] ?? $sid) . '): ' . $msg;
                    error_log('Failed to create invoice for student ' . $sid . ': ' . $msg);
                }
            }
        }

        if (empty($createdInvoices) && !empty($errors)) {
            throw new RuntimeException(
                'No invoices created. ' . implode(' | ', array_slice($errors, 0, 5))
                . (count($errors) > 5 ? ' …' : '')
            );
        }

        return [
            'invoice_ids' => $createdInvoices,
            'errors' => $errors,
            'skipped' => count($errors),
            'already_up_to_date' => $alreadyUpToDate,
            'partial_skips' => $partialSkips,
        ];
    }

    /**
     * Fixes unpaid open invoices that were generated when two tuition amounts
     * (e.g. 2250 and 2800) were both billed for the same month. Keeps one line
     * per category/month. It never changes an issued invoice's amount.
     * Invoices that already have a payment are left alone.
     */
    public static function resyncUnpaidOpenInvoiceAmounts(?int $studentId = null): void
    {
        require_once __DIR__ . '/../models/FeeAssignmentModel.php';
        require_once __DIR__ . '/../models/StudentModel.php';

        $where = "fi.status = 'open'
                  AND NOT EXISTS (
                      SELECT 1 FROM fee_collections fc WHERE fc.fee_invoice_id = fi.id
                  )";
        $types = '';
        $params = [];
        if ($studentId !== null && $studentId > 0) {
            $where .= ' AND fi.student_id = ?';
            $types = 'i';
            $params[] = $studentId;
        }

        $invoices = Database::fetchAll(
            "SELECT fi.id, fi.student_id, fi.academic_year_id, fi.class_section_id
             FROM fee_invoices fi
             WHERE $where",
            $types,
            $params
        );

        foreach ($invoices as $invoice) {
            self::resyncOneUnpaidInvoice(
                (int)$invoice['id'],
                (int)$invoice['student_id'],
                !empty($invoice['academic_year_id']) ? (int)$invoice['academic_year_id'] : null,
                (int)($invoice['class_section_id'] ?? 0)
            );
        }
    }

    private static function resyncOneUnpaidInvoice(
        int $invoiceId,
        int $studentId,
        ?int $academicYearId,
        int $classSectionId
    ): void {
        if ($classSectionId <= 0) {
            $classSectionId = (int)(StudentModel::getCurrentClassSectionId($studentId) ?? 0);
        }

        $lines = Database::fetchAll(
            // One-time fees (exam, late fee...) are left out: two of them can legitimately
            // share a month on one invoice, so they must not be treated as duplicates.
            'SELECT fil.id, fil.fee_category_id, fil.billing_month, fil.billing_year, fil.base_amount
             FROM fee_invoice_lines fil
             JOIN fee_categories fc ON fc.id = fil.fee_category_id
             WHERE fil.fee_invoice_id = ?
               AND COALESCE(fc.is_one_time, 0) = 0
             ORDER BY fil.id',
            'i',
            [$invoiceId]
        );

        $seen = [];
        $changed = false;

        foreach ($lines as $line) {
            $lineId = (int)$line['id'];
            $catId = (int)$line['fee_category_id'];
            $month = (int)($line['billing_month'] ?? 0);
            $year = (int)($line['billing_year'] ?? 0);
            if ($month < 1) {
                continue;
            }

            $key = $catId . '-' . $month . '-' . $year;
            if (isset($seen[$key])) {
                Database::execute('DELETE FROM fee_invoice_lines WHERE id = ?', 'i', [$lineId]);
                $changed = true;
                continue;
            }
            $seen[$key] = $lineId;

            // Amounts of invoices already issued are never re-priced: a newer fee
            // assignment only applies to invoices generated after it.
        }

        if ($changed) {
            Database::execute(
                'UPDATE fee_invoice_lines
                 SET discount_amount = 0, line_total = base_amount
                 WHERE fee_invoice_id = ?',
                'i',
                [$invoiceId]
            );
            Database::execute(
                'UPDATE fee_invoices SET total_discount = 0 WHERE id = ?',
                'i',
                [$invoiceId]
            );
            self::applyDiscountsToInvoice($invoiceId, $studentId);
            self::recalculateInvoiceTotals($invoiceId);
        }
    }

    /**
     * Apply a one-time fee to every active student in a class.
     *
     * $feeLabel says WHICH fee of the category is charged ("First Term Exam Fee", "Final Term
     * Exam Fee", "Late Fee", ...). It picks the matching Fee Assignment amount, is printed on the
     * invoice line, and is what the "already charged" check compares, so one category can hold
     * any number of differently named fees. Empty = the category's unlabelled assignment.
     * "Already charged" means: same student, fee and label in the same academic year (an
     * admission fee is once ever).
     *
     * $billingMonth (1-12) bills the fee with that month: added to the student's OPEN invoice for
     * that month, otherwise put on its own invoice for that month, never on another month's
     * invoice. Null = added to the latest open invoice, with no month.
     */
    public static function applyOneTimeFeeToClass(
        int $classSectionId,
        int $feeCategoryId,
        ?int $academicYearId = null,
        ?int $createdByUserId = null,
        bool $allowDuplicate = false,
        string $feeLabel = '',
        ?int $billingMonth = null
    ): array {
        require_once __DIR__ . '/../models/FeeAssignmentModel.php';
        require_once __DIR__ . '/../models/AcademicYearModel.php';

        $category = FeeCategoryModel::getById($feeCategoryId);
        if (!$category) {
            throw new RuntimeException('Fee category not found');
        }
        if (empty($category['is_one_time'])) {
            throw new RuntimeException('"' . $category['name'] . '" is not marked as a one-time fee. Edit it under Fee Categories first.');
        }
        $categoryName = (string)$category['name'];

        $feeLabel = trim((string)preg_replace('/\s+/', ' ', $feeLabel));
        if (mb_strlen($feeLabel) > 150) {
            throw new RuntimeException('Fee label is too long (150 characters at most)');
        }
        // What is printed on the invoice line and compared by the "already charged" check.
        $lineDescription = $feeLabel !== '' ? $feeLabel : $categoryName;

        if ($billingMonth !== null && ($billingMonth < 1 || $billingMonth > 12)) {
            throw new RuntimeException('Invalid billing month');
        }
        // The "already charged this year" check needs a year to compare against.
        $academicYearId = $academicYearId ?: AcademicYearModel::currentId();
        $billingYear = $billingMonth !== null ? self::resolveBillingYear($academicYearId, $billingMonth) : null;
        $isAdmission = !empty($category['is_admission']) || stripos($categoryName, 'admission') !== false;

        $students = Database::fetchAll(
            'SELECT s.id, s.admission_no, s.first_name, s.last_name
             FROM students s
             INNER JOIN student_class_assignments sca
               ON sca.id = (
                 SELECT sca2.id
                 FROM student_class_assignments sca2
                 WHERE sca2.student_id = s.id
                 ORDER BY sca2.assigned_at DESC, sca2.id DESC
                 LIMIT 1
               )
             WHERE sca.class_section_id = ?
               AND IFNULL(s.status, 1) = 1
             ORDER BY s.id',
            'i',
            [$classSectionId]
        );

        if (empty($students)) {
            throw new RuntimeException('No active students currently assigned to this class/section');
        }

        $appended = [];
        $created = [];
        $skipped = [];
        $errors = [];

        $safeCreatedBy = null;
        if ($createdByUserId !== null && (int)$createdByUserId > 0) {
            $userExists = Database::fetchOne('SELECT id FROM users WHERE id = ? LIMIT 1', 'i', [(int)$createdByUserId]);
            if ($userExists) {
                $safeCreatedBy = (int)$createdByUserId;
            }
        }

        foreach ($students as $student) {
            $sid = (int)$student['id'];
            $label = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
            if ($label === '') {
                $label = 'ID #' . $sid;
            }

            $conn = Database::connection();
            $conn->begin_transaction();

            try {
                $amount = FeeAssignmentModel::resolveAmountForLabel($feeCategoryId, $sid, $classSectionId, $academicYearId, $feeLabel);
                if ($amount === null || $amount <= 0) {
                    $conn->rollback();
                    $skipped[] = $label . ': no fee assignment found for "' . $lineDescription . '" (assign it under Fee Assignments first)';
                    continue;
                }

                $dupSql = 'SELECT fil.id
                           FROM fee_invoice_lines fil
                           JOIN fee_invoices fi ON fi.id = fil.fee_invoice_id
                           WHERE fi.student_id = ? AND fil.fee_category_id = ?
                             AND LOWER(TRIM(fil.description)) = LOWER(?) AND fi.status IN ("open","paid")';
                $dupTypes = 'iis';
                $dupParams = [$sid, $feeCategoryId, $lineDescription];
                if (!$isAdmission) {
                    $dupSql .= ' AND fi.academic_year_id <=> ?';
                    $dupTypes .= 'i';
                    $dupParams[] = $academicYearId;
                }
                $existing = Database::fetchOne($dupSql . ' LIMIT 1', $dupTypes, $dupParams);
                if ($existing && !$allowDuplicate) {
                    $conn->rollback();
                    $skipped[] = $label . ': already invoiced for "' . $lineDescription . '"';
                    continue;
                }

                if ($billingMonth !== null) {
                    // Only this month's own open invoice may take the fee.
                    $openInvoice = Database::fetchOne(
                        "SELECT fi.id FROM fee_invoices fi
                         WHERE fi.student_id = ? AND fi.status = 'open' AND fi.academic_year_id <=> ?
                           AND EXISTS (
                               SELECT 1 FROM fee_invoice_lines m
                               WHERE m.fee_invoice_id = fi.id AND m.billing_month = ? AND m.billing_year = ?
                           )
                         ORDER BY fi.id DESC LIMIT 1",
                        'iiii',
                        [$sid, $academicYearId, $billingMonth, $billingYear]
                    );
                } else {
                    $openInvoice = Database::fetchOne(
                        "SELECT id FROM fee_invoices WHERE student_id = ? AND status = 'open' ORDER BY id DESC LIMIT 1",
                        'i',
                        [$sid]
                    );
                }

                // The billing month only decides WHICH invoice takes the fee (above). The line itself is
                // saved without a month, so invoices and receipts show the fee's name ("First Term Exam Fee")
                // instead of a month like "Apr 2026".
                $lineSql = 'INSERT INTO fee_invoice_lines
                                (fee_invoice_id, fee_category_id, billing_month, billing_year, description, base_amount, discount_amount, line_total)
                            VALUES (?, ?, ?, ?, ?, ?, 0.00, ?)';

                if ($openInvoice) {
                    $invoiceId = (int)$openInvoice['id'];
                    Database::execute(
                        $lineSql,
                        'iiiisdd',
                        [$invoiceId, $feeCategoryId, null, null, $lineDescription, $amount, $amount]
                    );
                    self::recalculateInvoiceTotals($invoiceId);
                    $appended[] = $invoiceId;
                } else {
                    $invoiceNo = self::generateInvoiceNo();
                    $dueDate = date('Y-m-d', strtotime('+10 days'));

                    // Same class snapshot as createStudentInvoice() above --
                    // $classSectionId here is already the student's current
                    // class (it's how this student was selected in the first
                    // place), so it's safe to freeze it onto the invoice now.
                    Database::execute(
                        'INSERT INTO fee_invoices
                            (invoice_no, student_id, academic_year_id, class_section_id, status, total_amount, total_discount, total_due, fine_applied, due_date, created_by_user_id)
                         VALUES (?, ?, ?, ?, "open", ?, 0.00, ?, 0.00, ?, ?)',
                        'siiidssi',
                        [$invoiceNo, $sid, $academicYearId, $classSectionId, $amount, $amount, $dueDate, $safeCreatedBy]
                    );
                    $invoiceId = (int)Database::lastInsertId();

                    Database::execute(
                        $lineSql,
                        'iiiisdd',
                        [$invoiceId, $feeCategoryId, null, null, $lineDescription, $amount, $amount]
                    );

                    self::applyDiscountsToInvoice($invoiceId, $sid);
                    self::recalculateInvoiceTotals($invoiceId);
                    $created[] = $invoiceId;
                }

                $conn->commit();
            } catch (Throwable $e) {
                $conn->rollback();
                $errors[] = $label . ' (' . ($student['admission_no'] ?? $sid) . '): ' . $e->getMessage();
                error_log('Failed to apply one-time fee for student ' . $sid . ': ' . $e->getMessage());
            }
        }

        return ['appended' => $appended, 'created' => $created, 'skipped' => $skipped, 'errors' => $errors];
    }

    private static function applyDiscountsToInvoice(int $invoiceId, int $studentId): void
    {
        $invoice = Database::fetchOne(
            'SELECT total_amount FROM fee_invoices WHERE id = ?',
            'i',
            [$invoiceId]
        );
        if (!$invoice) {
            return;
        }

        $discountableRow = Database::fetchOne(
            'SELECT COALESCE(SUM(fil.line_total), 0) AS total
             FROM fee_invoice_lines fil
             JOIN fee_categories fc ON fc.id = fil.fee_category_id
             WHERE fil.fee_invoice_id = ? AND COALESCE(fc.no_discount, 0) = 0',
            'i',
            [$invoiceId]
        );
        $invoiceTotal = (float)($discountableRow['total'] ?? 0);
        if ($invoiceTotal <= 0) {
            return;
        }

        $profileValue = 0.0;
        $profileIsPercent = 1;
        try {
            $stu = Database::fetchOne(
                'SELECT fee_discount_percent, fee_discount_is_percent FROM students WHERE id = ?',
                'i',
                [$studentId]
            );
            $profileValue = (float)($stu['fee_discount_percent'] ?? 0);
            $profileIsPercent = (int)($stu['fee_discount_is_percent'] ?? 1);
        } catch (Throwable $e) {
            try {
                $stu = Database::fetchOne(
                    'SELECT fee_discount_percent FROM students WHERE id = ?',
                    'i',
                    [$studentId]
                );
                $profileValue = (float)($stu['fee_discount_percent'] ?? 0);
                $profileIsPercent = 1;
            } catch (Throwable $e2) {
                $profileValue = 0.0;
            }
        }

        if ($profileValue > 0) {
            if ($profileIsPercent) {
                $pct = min(100, max(0, $profileValue));
                $discountAmount = round($invoiceTotal * ($pct / 100), 2);
            } else {
                $discountAmount = min($profileValue, $invoiceTotal);
            }
            self::applyDiscountAmountToInvoiceLines($invoiceId, $discountAmount);
            return;
        }

        $classSectionId = null;
        $csRow = Database::fetchOne(
            'SELECT class_section_id
             FROM student_class_assignments
             WHERE student_id = ?
             ORDER BY assigned_at DESC, id DESC
             LIMIT 1',
            'i',
            [$studentId]
        );
        if ($csRow) {
            $classSectionId = (int)$csRow['class_section_id'];
        }

        $discounts = Database::fetchAll(
            'SELECT * FROM fee_discount_rules
             WHERE (start_date IS NULL OR start_date <= CURDATE())
               AND (end_date IS NULL OR end_date >= CURDATE())
               AND (
                   (student_id IS NULL AND class_section_id IS NULL)
                   OR student_id = ?
                   OR class_section_id = ?
               )
             ORDER BY id DESC',
            'ii',
            [$studentId, $classSectionId ?? 0]
        );

        if (empty($discounts)) {
            return;
        }

        $studentRules = [];
        $classRules = [];
        $globalRules = [];
        foreach ($discounts as $d) {
            if (!empty($d['student_id'])) {
                $studentRules[] = $d;
            } elseif (!empty($d['class_section_id'])) {
                $classRules[] = $d;
            } else {
                $globalRules[] = $d;
            }
        }
        if (!empty($studentRules)) {
            $discounts = $studentRules;
        } elseif (!empty($classRules)) {
            $discounts = $classRules;
        } else {
            $discounts = $globalRules;
        }

        $totalDiscount = 0.0;
        foreach ($discounts as $discount) {
            $isPercent = (int)$discount['is_percent'];
            $amount = (float)$discount['amount'];

            if ($isPercent) {
                $discountAmount = round($invoiceTotal * (min(100, max(0, $amount)) / 100), 2);
            } else {
                $discountAmount = min($amount, $invoiceTotal);
            }

            $totalDiscount += self::applyDiscountAmountToInvoiceLines($invoiceId, $discountAmount);
        }

        if ($totalDiscount > 0) {
            self::recalculateInvoiceTotals($invoiceId);
        }
    }

    private static function applyDiscountAmountToInvoiceLines(int $invoiceId, float $discountAmount): float
    {
        if ($discountAmount <= 0) {
            return 0.0;
        }

        $lines = Database::fetchAll(
            'SELECT fil.id, fil.line_total
             FROM fee_invoice_lines fil
             JOIN fee_categories fc ON fc.id = fil.fee_category_id
             WHERE fil.fee_invoice_id = ? AND COALESCE(fc.no_discount, 0) = 0',
            'i',
            [$invoiceId]
        );
        if (empty($lines)) {
            return 0.0;
        }

        $totalDiscount = 0.0;
        $discountPerLine = round($discountAmount / count($lines), 2);

        foreach ($lines as $line) {
            $lineDiscount = min($discountPerLine, (float)$line['line_total']);
            if ($lineDiscount <= 0) {
                continue;
            }
            Database::execute(
                'UPDATE fee_invoice_lines
                 SET discount_amount = discount_amount + ?,
                     line_total = line_total - ?
                 WHERE id = ?',
                'ddi',
                [$lineDiscount, $lineDiscount, (int)$line['id']]
            );
            $totalDiscount += $lineDiscount;
        }

        if ($totalDiscount > 0) {
            Database::execute(
                'UPDATE fee_invoices SET total_discount = COALESCE(total_discount, 0) + ? WHERE id = ?',
                'di',
                [$totalDiscount, $invoiceId]
            );
            self::recalculateInvoiceTotals($invoiceId);
        }

        return $totalDiscount;
    }

    public static function recalculateInvoiceTotals(int $invoiceId): void
    {
        $totals = Database::fetchOne(
            'SELECT COALESCE(SUM(base_amount), 0) AS total_amount,
                    COALESCE(SUM(discount_amount), 0) AS total_discount,
                    COALESCE(SUM(line_total), 0) AS total_due
             FROM fee_invoice_lines
             WHERE fee_invoice_id = ?',
            'i',
            [$invoiceId]
        );

        if ($totals) {
            $lineDue = (float)$totals['total_due'];
            $fineRow = Database::fetchOne(
                'SELECT COALESCE(fine_applied, 0) AS fine_applied FROM fee_invoices WHERE id = ?',
                'i',
                [$invoiceId]
            );
            $fine = (float)($fineRow['fine_applied'] ?? 0);
            $totalDue = $lineDue + $fine;

            Database::execute(
                'UPDATE fee_invoices
                 SET total_amount = ?, total_discount = ?, total_due = ?
                 WHERE id = ?',
                'dddi',
                [
                    (float)$totals['total_amount'],
                    (float)$totals['total_discount'],
                    $totalDue,
                    $invoiceId
                ]
            );

            self::syncInvoicePaidStatus($invoiceId);
        }
    }

    public static function syncInvoicePaidStatus(int $invoiceId): void
    {
        $row = Database::fetchOne(
            'SELECT fi.status, fi.total_due,
                    COALESCE((SELECT SUM(fc.amount) FROM fee_collections fc WHERE fc.fee_invoice_id = fi.id), 0) AS collected
             FROM fee_invoices fi
             WHERE fi.id = ?',
            'i',
            [$invoiceId]
        );
        if (!$row) {
            return;
        }
        if (($row['status'] ?? '') === 'cancelled') {
            return;
        }

        $pending = (float)$row['total_due'] - (float)$row['collected'];
        $newStatus = $pending <= 0.001 ? 'paid' : 'open';
        if ($newStatus !== (string)$row['status']) {
            Database::execute(
                'UPDATE fee_invoices SET status = ? WHERE id = ?',
                'si',
                [$newStatus, $invoiceId]
            );
        }
    }

    /**
     * Record a payment against an invoice, optionally tied to specific
     * month/fee lines (line_ids[] ticked on the Collect page). If specific
     * lines are given, that exact amount is booked against those months
     * first; any leftover (or the whole amount, if no lines were ticked)
     * is applied to the invoice's remaining unpaid months in chronological
     * order.
     */
    public static function recordPayment(
        int $invoiceId,
        float $amount,
        string $method,
        ?string $notes,
        ?int $collectedByUserId,
        array $lineIds = [],
        ?int $enteredByUserId = null
    ): void {
        if ($amount <= 0) {
            throw new RuntimeException('Payment amount must be greater than zero');
        }

        // $collectedByUserId is the staff member this payment is ATTRIBUTED
        // to -- whose "Collected So Far" / ledger / net balance it counts
        // toward. Normally that's whoever is actually submitting the form.
        $safeCollectedBy = null;
        if ($collectedByUserId !== null && (int)$collectedByUserId > 0) {
            $userExists = Database::fetchOne('SELECT id FROM users WHERE id = ? LIMIT 1', 'i', [(int)$collectedByUserId]);
            if ($userExists) {
                $safeCollectedBy = (int)$collectedByUserId;
            }
        }

        // $enteredByUserId is who PHYSICALLY took the payment and typed it
        // in, only set when it differs from the attributed staff member --
        // e.g. Admin collected cash at the counter on behalf of a teacher.
        // Left null for the common case (someone recording their own
        // collection), so existing payments and behaviour are unaffected.
        $safeEnteredBy = null;
        if ($enteredByUserId !== null && (int)$enteredByUserId > 0 && (int)$enteredByUserId !== $safeCollectedBy) {
            $enteredUserExists = Database::fetchOne('SELECT id FROM users WHERE id = ? LIMIT 1', 'i', [(int)$enteredByUserId]);
            if ($enteredUserExists) {
                $safeEnteredBy = (int)$enteredByUserId;
            }
        }

        $notes = $notes !== null && trim($notes) !== '' ? trim($notes) : null;

        $conn = Database::connection();
        $conn->begin_transaction();

        try {
            // Lock the invoice row for the duration of this payment so two
            // concurrent payments against the same invoice serialize instead of
            // both reading a stale "not yet fully paid" state.
            $invoice = Database::fetchOne('SELECT id, status, total_due FROM fee_invoices WHERE id = ? FOR UPDATE', 'i', [$invoiceId]);
            if (!$invoice) {
                throw new RuntimeException('Invoice not found');
            }
            if ((string)$invoice['status'] === 'cancelled') {
                throw new RuntimeException('Cannot record a payment against a cancelled invoice');
            }

            // Block accidental over-collection (e.g. a double-tapped submit
            // button firing the same payment twice) rather than silently
            // recording it. Computed under the row lock above so a genuine
            // race between two simultaneous payments can't both slip through.
            $alreadyPaidRow = Database::fetchOne(
                'SELECT COALESCE(SUM(amount), 0) AS paid FROM fee_collections WHERE fee_invoice_id = ?',
                'i',
                [$invoiceId]
            );
            $alreadyPaid = (float)($alreadyPaidRow['paid'] ?? 0);
            $totalDue = (float)($invoice['total_due'] ?? 0);
            $remaining = round($totalDue - $alreadyPaid, 2);
            if ($remaining <= 0.0) {
                throw new RuntimeException('This invoice is already fully paid — nothing left to collect. If this payment is genuinely for something else (e.g. a different month), raise a new invoice instead.');
            }
            if (round($amount, 2) > $remaining) {
                throw new RuntimeException('Amount (Rs ' . number_format($amount, 2) . ') exceeds the remaining balance of Rs ' . number_format($remaining, 2) . ' on this invoice.');
            }

            Database::execute(
                'INSERT INTO fee_collections (fee_invoice_id, amount, method, notes, collected_by_user_id, entered_by_user_id)
                 VALUES (?, ?, ?, ?, ?, ?)',
                'idssii',
                [$invoiceId, $amount, $method, $notes, $safeCollectedBy, $safeEnteredBy]
            );
            $collectionId = (int)Database::lastInsertId();

            self::allocatePaymentToLines($invoiceId, $collectionId, $amount, $lineIds);

            self::syncInvoicePaidStatus($invoiceId);

            $conn->commit();
        } catch (Throwable $e) {
            $conn->rollback();
            throw $e;
        }
    }

    /**
     * Books a payment amount against fee_invoice_lines so per-month
     * paid/pending figures stay accurate. Ticked lines are paid first
     * (in the order given), then any remaining amount rolls onto the
     * invoice's other unpaid months, oldest first.
     */
    private static function allocatePaymentToLines(int $invoiceId, int $collectionId, float $amount, array $lineIds): void
    {
        $lines = Database::fetchAll(
            'SELECT id, line_total FROM fee_invoice_lines WHERE fee_invoice_id = ? ORDER BY id',
            'i',
            [$invoiceId]
        );
        if (!$lines) {
            // No month lines on this invoice (e.g. a manual/one-off invoice) -
            // the payment simply stays at the invoice level.
            return;
        }

        $paidRows = Database::fetchAll(
            'SELECT fcl.fee_invoice_line_id, SUM(fcl.amount) AS paid
             FROM fee_collection_lines fcl
             JOIN fee_collections fc ON fc.id = fcl.fee_collection_id
             WHERE fc.fee_invoice_id = ?
             GROUP BY fcl.fee_invoice_line_id',
            'i',
            [$invoiceId]
        );
        $alreadyPaid = [];
        foreach ($paidRows as $row) {
            $alreadyPaid[(int)$row['fee_invoice_line_id']] = (float)$row['paid'];
        }

        $linesById = [];
        $validIds = [];
        foreach ($lines as $line) {
            $lineId = (int)$line['id'];
            $linesById[$lineId] = $line;
            $validIds[] = $lineId;
        }

        $selected = array_values(array_intersect(array_map('intval', $lineIds), $validIds));
        $orderedIds = $selected;
        foreach ($validIds as $id) {
            if (!in_array($id, $orderedIds, true)) {
                $orderedIds[] = $id;
            }
        }

        $remaining = $amount;
        foreach ($orderedIds as $lineId) {
            if ($remaining <= 0.001) {
                break;
            }
            $lineTotal = (float)($linesById[$lineId]['line_total'] ?? 0);
            $pending = max($lineTotal - ($alreadyPaid[$lineId] ?? 0.0), 0.0);
            if ($pending <= 0.001) {
                continue;
            }
            $allocate = min($pending, $remaining);
            Database::execute(
                'INSERT INTO fee_collection_lines (fee_collection_id, fee_invoice_line_id, amount) VALUES (?, ?, ?)',
                'iid',
                [$collectionId, $lineId, $allocate]
            );
            $remaining -= $allocate;
        }
        // Any amount left over (overpayment beyond every month's pending
        // balance) isn't tied to a specific month, but still counts toward
        // the invoice's total collected amount.
    }

    /**
     * Writes off whatever remains on an invoice without recording a real
     * cash payment - used for the "mark as paid (nothing due)" action.
     */
    public static function markSettledAsPaid(int $invoiceId): void
    {
        $row = Database::fetchOne(
            'SELECT fi.status,
                    COALESCE((SELECT SUM(amount) FROM fee_collections WHERE fee_invoice_id = fi.id), 0) AS collected
             FROM fee_invoices fi
             WHERE fi.id = ?',
            'i',
            [$invoiceId]
        );
        if (!$row) {
            throw new RuntimeException('Invoice not found');
        }
        if ((string)$row['status'] === 'cancelled') {
            throw new RuntimeException('Cannot settle a cancelled invoice');
        }

        Database::execute(
            "UPDATE fee_invoices SET total_due = ?, status = 'paid' WHERE id = ?",
            'di',
            [(float)$row['collected'], $invoiceId]
        );
    }

    /**
     * Adds a manually-entered fine (e.g. from the "Add Custom Fine" form)
     * to an invoice and folds it into total_due.
     */
    public static function addCustomFine(int $invoiceId, string $fineType, float $amount, ?string $notes, ?int $addedByUserId): void
    {
        if ($amount <= 0) {
            throw new RuntimeException('Fine amount must be greater than zero');
        }

        $invoice = Database::fetchOne('SELECT id, status FROM fee_invoices WHERE id = ?', 'i', [$invoiceId]);
        if (!$invoice) {
            throw new RuntimeException('Invoice not found');
        }

        $safeAddedBy = null;
        if ($addedByUserId !== null && (int)$addedByUserId > 0) {
            $userExists = Database::fetchOne('SELECT id FROM users WHERE id = ? LIMIT 1', 'i', [(int)$addedByUserId]);
            if ($userExists) {
                $safeAddedBy = (int)$addedByUserId;
            }
        }

        $notes = $notes !== null && trim($notes) !== '' ? trim($notes) : null;

        Database::execute(
            'INSERT INTO fee_custom_fines (fee_invoice_id, fine_type, amount, notes, added_by_user_id)
             VALUES (?, ?, ?, ?, ?)',
            'isdsi',
            [$invoiceId, $fineType, $amount, $notes, $safeAddedBy]
        );

        self::refreshFineTotal($invoiceId);
    }

    /**
     * Applies (or updates) an automatic overdue fine based on the school's
     * daily fine rate, if the invoice's due date has passed. Safe to call
     * Currently disabled by school policy: no daily late fee is charged
     * automatically. Overdue invoices simply show "Overdue by X day(s)" on
     * the Collect page; staff add a fine manually (via "Add Custom Fine")
     * only if/when they decide to. This method is kept as a safe no-op
     * since it's still called from a couple of places - to re-enable
     * automatic daily fines later, restore the logic that used to be here
     * (keyed off fee_fine_rules.daily_fine_amount).
     */
    public static function applyAutomaticFineIfOverdue(int $invoiceId): void
    {
        // Intentionally does nothing - automatic fines are turned off.
    }

    /**
     * Every open invoice that is past its due date and still has a real
     * pending balance (total_due minus whatever's actually been collected,
     * via pending_dues_view - not just total_due, so partially-paid
     * invoices aren't reported as fully overdue). No fine involved.
     *
     * @param int   $limit         0 = no limit (used internally by send()).
     * @param int   $offset        Row offset for pagination.
     * @param int[] $onlyInvoiceIds If non-empty, restricts to these invoice IDs
     *                              (still re-checked against the overdue/unpaid
     *                              criteria above - a stale checkbox can't force
     *                              a since-paid invoice through).
     */
    public static function getOverdueUnpaidInvoices(int $limit = 0, int $offset = 0, array $onlyInvoiceIds = []): array
    {
        $sql = "SELECT fi.id, fi.invoice_no, fi.due_date, fi.student_id,
                    s.first_name, s.last_name, s.admission_no, s.phone AS student_phone,
                    pdv.pending_amount,
                    DATEDIFF(CURDATE(), fi.due_date) AS days_overdue,
                    (SELECT MAX(frl.sent_at) FROM fee_reminder_log frl
                       WHERE frl.fee_invoice_id = fi.id AND DATE(frl.sent_at) = CURDATE()) AS reminded_today
             FROM fee_invoices fi
             JOIN students s ON s.id = fi.student_id
             JOIN pending_dues_view pdv ON pdv.fee_invoice_id = fi.id
             WHERE fi.status = 'open'
               AND fi.due_date IS NOT NULL
               AND fi.due_date < CURDATE()
               AND pdv.pending_amount > 0.001";
        $types = '';
        $params = [];

        if (!empty($onlyInvoiceIds)) {
            $ids = array_values(array_unique(array_map('intval', $onlyInvoiceIds)));
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $sql .= " AND fi.id IN ($placeholders)";
            $types .= str_repeat('i', count($ids));
            $params = array_merge($params, $ids);
        }

        $sql .= ' ORDER BY fi.due_date ASC';

        if ($limit > 0) {
            $sql .= ' LIMIT ? OFFSET ?';
            $types .= 'ii';
            $params[] = $limit;
            $params[] = $offset;
        }

        return Database::fetchAll($sql, $types, $params);
    }

    /** Total count for the same criteria as getOverdueUnpaidInvoices(), for pagination. */
    public static function countOverdueUnpaidInvoices(): int
    {
        $row = Database::fetchOne(
            "SELECT COUNT(*) AS cnt
             FROM fee_invoices fi
             JOIN pending_dues_view pdv ON pdv.fee_invoice_id = fi.id
             WHERE fi.status = 'open'
               AND fi.due_date IS NOT NULL
               AND fi.due_date < CURDATE()
               AND pdv.pending_amount > 0.001"
        );
        return (int)($row['cnt'] ?? 0);
    }

    /**
     * Sends a "your fee is overdue" SMS (no fine applied) to the student's
     * own number and every guardian linked to them, for each invoice ID
     * passed in - skipping any invoice already reminded today so clicking
     * the button twice doesn't double-text parents, and re-validating each
     * ID is still actually overdue/unpaid rather than trusting the checkbox
     * state as-is. Returns a summary for the flash message.
     *
     * @param int[] $invoiceIds Invoice IDs selected via checkbox on the page.
     */
    public static function sendOverdueFeeReminders(array $invoiceIds, ?int $sentByUserId): array
    {
        require_once __DIR__ . '/../models/GuardianModel.php';

        if (empty($invoiceIds)) {
            return [
                'invoices_selected' => 0,
                'invoices_reminded' => 0,
                'invoices_skipped_already_sent' => 0,
                'invoices_skipped_no_phone' => 0,
                'messages_queued' => 0,
            ];
        }

        $schoolNameRow = Database::fetchOne(
            "SELECT `value` FROM settings WHERE `key` IN ('branding_school_name','institute_name') ORDER BY `key` = 'branding_school_name' DESC LIMIT 1"
        );
        $schoolName = trim((string)($schoolNameRow['value'] ?? '')) ?: 'School';

        $invoices = self::getOverdueUnpaidInvoices(0, 0, $invoiceIds);

        $invoicesReminded = 0;
        $invoicesSkippedAlreadySent = 0;
        $invoicesSkippedNoPhone = 0;
        $messagesQueued = 0;

        foreach ($invoices as $inv) {
            if (!empty($inv['reminded_today'])) {
                $invoicesSkippedAlreadySent++;
                continue;
            }

            $studentName = trim((string)$inv['first_name'] . ' ' . (string)$inv['last_name']);
            $message = sprintf(
                'Dear Parent/Guardian, fee invoice %s for %s (due %s) of Rs %s is still unpaid. Kindly clear the dues at your earliest. - %s',
                (string)$inv['invoice_no'],
                $studentName,
                (string)$inv['due_date'],
                number_format((float)$inv['pending_amount'], 2),
                $schoolName
            );

            $numbers = [];
            if (!empty($inv['student_phone'])) {
                $numbers[] = (string)$inv['student_phone'];
            }
            foreach (GuardianModel::listByStudent((int)$inv['student_id']) as $g) {
                if (!empty($g['phone'])) {
                    $numbers[] = (string)$g['phone'];
                }
            }

            // De-dupe by normalized number so the same phone (e.g. student's
            // number also on file as a guardian's) isn't texted twice for
            // one invoice.
            $seen = [];
            $sentForThisInvoice = 0;
            foreach ($numbers as $number) {
                $normalized = normalize_pk_mobile($number);
                if ($normalized === null || isset($seen[$normalized])) {
                    continue;
                }
                $seen[$normalized] = true;
                if (queue_sms($number, $message, 'fee_overdue_reminder')) {
                    $sentForThisInvoice++;
                }
            }

            if ($sentForThisInvoice === 0) {
                $invoicesSkippedNoPhone++;
                continue;
            }

            Database::execute(
                'INSERT INTO fee_reminder_log (fee_invoice_id, sent_by_user_id, recipients_count) VALUES (?, ?, ?)',
                'iii',
                [(int)$inv['id'], $sentByUserId, $sentForThisInvoice]
            );

            $invoicesReminded++;
            $messagesQueued += $sentForThisInvoice;
        }

        return [
            'invoices_selected' => count($invoices),
            'invoices_reminded' => $invoicesReminded,
            'invoices_skipped_already_sent' => $invoicesSkippedAlreadySent,
            'invoices_skipped_no_phone' => $invoicesSkippedNoPhone,
            'messages_queued' => $messagesQueued,
        ];
    }

    /**
     * Recomputes fee_invoices.fine_applied from fee_custom_fines and folds
     * it into total_due via recalculateInvoiceTotals().
     */
    private static function refreshFineTotal(int $invoiceId): void
    {
        $sum = Database::fetchOne(
            'SELECT COALESCE(SUM(amount), 0) AS total FROM fee_custom_fines WHERE fee_invoice_id = ?',
            'i',
            [$invoiceId]
        );
        Database::execute(
            'UPDATE fee_invoices SET fine_applied = ? WHERE id = ?',
            'di',
            [(float)($sum['total'] ?? 0), $invoiceId]
        );

        self::recalculateInvoiceTotals($invoiceId);
    }

    public static function getInvoiceLineBalances(int $invoiceId): array
    {
        $lines = Database::fetchAll(
            'SELECT fil.id, fil.description, fil.line_total
             FROM fee_invoice_lines fil
             WHERE fil.fee_invoice_id = ?
             ORDER BY fil.id',
            'i',
            [$invoiceId]
        );

        $collectedRow = Database::fetchOne(
            'SELECT COALESCE(SUM(amount), 0) AS collected FROM fee_collections WHERE fee_invoice_id = ?',
            'i',
            [$invoiceId]
        );
        $collected = (float)($collectedRow['collected'] ?? 0);

        return self::applyLinePaymentAllocations($invoiceId, $lines, $collected);
    }

    /**
     * Works out how much of each invoice line has actually been paid.
     *
     * Payments made through recordPayment() with specific months ticked are
     * stored precisely in fee_collection_lines. Any collected amount that
     * isn't tied to a specific line yet (e.g. older payments recorded before
     * that table existed, or a manual lump-sum payment with no months
     * ticked) is filled in oldest-month-first so every line still ends up
     * with a sensible paid/pending value.
     */
    private static function applyLinePaymentAllocations(int $invoiceId, array $lines, float $collected): array
    {
        $explicitRows = Database::fetchAll(
            'SELECT fcl.fee_invoice_line_id, SUM(fcl.amount) AS paid
             FROM fee_collection_lines fcl
             JOIN fee_collections fc ON fc.id = fcl.fee_collection_id
             WHERE fc.fee_invoice_id = ?
             GROUP BY fcl.fee_invoice_line_id',
            'i',
            [$invoiceId]
        );

        $explicitPaid = [];
        $explicitTotal = 0.0;
        foreach ($explicitRows as $row) {
            $lineId = (int)$row['fee_invoice_line_id'];
            $explicitPaid[$lineId] = (float)$row['paid'];
            $explicitTotal += (float)$row['paid'];
        }

        $unallocated = max($collected - $explicitTotal, 0.0);

        $result = [];
        foreach ($lines as $line) {
            $lineId = (int)$line['id'];
            $lineTotal = (float)($line['line_total'] ?? 0);

            $paidSoFar = $explicitPaid[$lineId] ?? 0.0;
            $pendingAfterExplicit = max($lineTotal - $paidSoFar, 0.0);

            $fifoPaid = min($pendingAfterExplicit, $unallocated);
            $unallocated -= $fifoPaid;

            $totalPaid = $paidSoFar + $fifoPaid;
            $pending = max($lineTotal - $totalPaid, 0.0);

            $line['paid'] = $totalPaid;
            $line['pending'] = $pending;
            $line['paid_amount'] = $totalPaid;
            $line['pending_amount'] = $pending;
            $line['is_paid'] = $pending <= 0.001;

            $result[] = $line;
        }

        return $result;
    }

    public static function getStudentFeeSummary(int $studentId, ?int $academicYearId = null): array
    {
        $whereClause = 'WHERE fi.student_id = ?';
        $params = [$studentId];
        $types = 'i';

        $whereClause .= " AND fi.status <> 'cancelled'";

        if ($academicYearId) {
            $whereClause .= ' AND fi.academic_year_id = ?';
            $params[] = $academicYearId;
            $types .= 'i';
        }

        // NOTE: invoice-level sums (total_amount/total_discount/fine_applied/total_due)
        // and COUNT(fi.id) must be aggregated from fee_invoices alone. Joining
        // fee_collections directly into this aggregate fans out each invoice row once
        // per payment against it, multiplying every invoice-level column by the
        // invoice's payment count. total_paid is computed separately via a correlated
        // subquery instead, matching the pattern already used elsewhere in this file
        // (e.g. getInvoiceDetails(), syncInvoicePaidStatus()).
        $summary = Database::fetchOne(
            'SELECT COALESCE(SUM(fi.total_amount), 0) AS total_charged,
                    COALESCE(SUM(fi.total_discount), 0) AS total_discount,
                    COALESCE(SUM(fi.fine_applied), 0) AS total_fines,
                    COALESCE(SUM(
                        (SELECT SUM(fc.amount) FROM fee_collections fc WHERE fc.fee_invoice_id = fi.id)
                    ), 0) AS total_paid,
                    COALESCE(SUM(fi.total_due), 0) AS total_due,
                    COUNT(fi.id) AS invoice_count,
                    SUM(CASE WHEN fi.status = "paid" THEN 1 ELSE 0 END) AS paid_invoices,
                    SUM(CASE WHEN fi.status = "open" THEN 1 ELSE 0 END) AS pending_invoices
             FROM fee_invoices fi
             ' . $whereClause,
            $types,
            $params
        );

        return $summary ?: [
            'total_charged' => 0,
            'total_discount' => 0,
            'total_fines' => 0,
            'total_paid' => 0,
            'total_due' => 0,
            'invoice_count' => 0,
            'paid_invoices' => 0,
            'pending_invoices' => 0,
        ];
    }

    public static function getStudentBalance(int $studentId, ?int $academicYearId = null): float
    {
        $summary = self::getStudentFeeSummary($studentId, $academicYearId);
        return (float)($summary['total_due'] ?? 0) - (float)($summary['total_paid'] ?? 0);
    }

    private static function getMonthName(int $monthNumber): string
    {
        $months = [
            1 => 'January', 2 => 'February', 3 => 'March',
            4 => 'April', 5 => 'May', 6 => 'June',
            7 => 'July', 8 => 'August', 9 => 'September',
            10 => 'October', 11 => 'November', 12 => 'December'
        ];
        return $months[$monthNumber] ?? 'Month ' . $monthNumber;
    }

    public static function getInvoiceDetails(int $invoiceId): ?array
    {
        $invoice = Database::fetchOne(
            'SELECT fi.*,
                    s.first_name, s.last_name, s.admission_no,
                    ay.academic_year_label,
                    COALESCE(SUM(fc.amount), 0) AS collected_amount
             FROM fee_invoices fi
             JOIN students s ON s.id = fi.student_id
             LEFT JOIN academic_years ay ON ay.id = fi.academic_year_id
             LEFT JOIN fee_collections fc ON fc.fee_invoice_id = fi.id
             WHERE fi.id = ?
             GROUP BY fi.id',
            'i',
            [$invoiceId]
        );

        if (!$invoice) {
            return null;
        }

        $lines = Database::fetchAll(
            'SELECT fil.*, fc.name AS category_name
             FROM fee_invoice_lines fil
             JOIN fee_categories fc ON fc.id = fil.fee_category_id
             WHERE fil.fee_invoice_id = ?
             ORDER BY fil.id',
            'i',
            [$invoiceId]
        );

        $invoice['lines'] = self::applyLinePaymentAllocations($invoiceId, $lines, (float)$invoice['collected_amount']);
        $invoice['pending_balance'] = (float)$invoice['total_due'] - (float)$invoice['collected_amount'];
        $invoice['collections'] = self::getInvoiceCollectionsWithLabels($invoiceId);

        return $invoice;
    }

    /**
     * Payment history for an invoice, with a human-readable label of which
     * month(s) each payment covered (built from fee_collection_lines).
     */
    public static function getInvoiceCollectionsWithLabels(int $invoiceId): array
    {
        $collections = Database::fetchAll(
            'SELECT fc.*, u.username AS collected_by_name, eu.username AS entered_by_name
             FROM fee_collections fc
             LEFT JOIN users u ON u.id = fc.collected_by_user_id
             LEFT JOIN users eu ON eu.id = fc.entered_by_user_id
             WHERE fc.fee_invoice_id = ?
             ORDER BY fc.collected_at DESC, fc.id DESC',
            'i',
            [$invoiceId]
        );

        if (!$collections) {
            return [];
        }

        $labelRows = Database::fetchAll(
            'SELECT fcl.fee_collection_id, fil.description
             FROM fee_collection_lines fcl
             JOIN fee_invoice_lines fil ON fil.id = fcl.fee_invoice_line_id
             WHERE fcl.fee_collection_id IN (
                 SELECT id FROM fee_collections WHERE fee_invoice_id = ?
             )
             ORDER BY fil.id',
            'i',
            [$invoiceId]
        );
        $labelsByCollection = [];
        foreach ($labelRows as $row) {
            $cid = (int)$row['fee_collection_id'];
            $labelsByCollection[$cid][] = $row['description'];
        }

        foreach ($collections as &$col) {
            $cid = (int)$col['id'];
            $col['months_label'] = !empty($labelsByCollection[$cid])
                ? implode(', ', $labelsByCollection[$cid])
                : null;
        }
        unset($col);

        return $collections;
    }

    /**
     * Void/undo a payment - deletes the fee_collections row (and its month
     * allocations), then re-syncs the invoice's status. Returns the invoice
     * id that was affected, so the caller can redirect back to it.
     */
    public static function deletePayment(int $collectionId): int
    {
        $collection = Database::fetchOne(
            'SELECT id, fee_invoice_id FROM fee_collections WHERE id = ?',
            'i',
            [$collectionId]
        );
        if (!$collection) {
            throw new RuntimeException('Payment not found');
        }
        $invoiceId = (int)$collection['fee_invoice_id'];

        Database::execute('DELETE FROM fee_collection_lines WHERE fee_collection_id = ?', 'i', [$collectionId]);
        Database::execute('DELETE FROM fee_collections WHERE id = ?', 'i', [$collectionId]);

        self::syncInvoicePaidStatus($invoiceId);

        return $invoiceId;
    }
}