<?php

/**
 * XlsxGridWriter
 *
 * Builds a single-sheet, colour-coded .xlsx file (raw OOXML via ZipArchive — the
 * project has no Composer/PhpSpreadsheet available, and this mirrors the existing
 * ZipArchive-based export pattern already used in AcademicController/FeesController).
 *
 * Intended for "attendance register" style grids: a header row plus data rows where
 * individual cells can be colour-coded (e.g. Present/Absent/Late/Excused/Holiday).
 *
 * Usage:
 *   $xlsx = new XlsxGridWriter('Attendance');
 *   $xlsx->addHeaderRow(['Name', 'Class', '01-Mon', '02-Tue', ...]);
 *   $xlsx->addRow([
 *       XlsxGridWriter::cell('Ali Raza'),
 *       XlsxGridWriter::cell('10-A'),
 *       XlsxGridWriter::cell('P', 'P'),
 *       XlsxGridWriter::cell('A', 'A'),
 *   ]);
 *   $xlsx->download('attendance_register.xlsx'); // sends headers, streams, and exits
 */
final class XlsxGridWriter
{
    /** Fill colour codes this writer understands, mapped to their style index in styles.xml. */
    private const CODE_STYLES = [
        'P' => 2, // present  - green
        'L' => 4, // late     - amber
        'A' => 3, // absent   - red
        'E' => 5, // excused  - blue
        'H' => 6, // holiday  - pink
    ];

    private const STYLE_HEADER = 1;
    private const STYLE_BLANK_CENTER = 7; // bordered, no fill, centered (grid cell with no code)
    private const STYLE_LABEL = 8;        // bordered, no fill, left-aligned (name/class columns)
    private const STYLE_LABEL_BOLD = 9;   // bordered, no fill, bold (count columns)

    private string $sheetName;
    /** @var array<int, array<int, array{text:string, style:int, type:string}>> */
    private array $rows = [];
    /** @var int[] Column widths in Excel "character" units, indexed from 0. */
    private array $columnWidths = [];
    /** @var string[] Cell ranges (e.g. "C1:F1") to merge, for grouped header rows. */
    private array $merges = [];
    /** How many top rows stay pinned when scrolling. Defaults to 1 (just the header row). */
    private int $freezeRows = 1;

    public function __construct(string $sheetName = 'Sheet1')
    {
        // Excel sheet names: max 31 chars, and can't contain : \ / ? * [ ]
        $clean = preg_replace('/[:\\\\\/\?\*\[\]]/', '', $sheetName) ?? 'Sheet1';
        $this->sheetName = mb_substr($clean !== '' ? $clean : 'Sheet1', 0, 31);
    }

    /**
     * Builds one grid cell. $code selects a background colour (P/L/A/E/H, see
     * CODE_STYLES); pass null for an uncoloured cell. $bold/$numeric control the
     * style of uncoloured cells (numeric cells are right-aligned and written as
     * real numbers so Excel can sum them).
     */
    public static function cell(string $text, ?string $code = null, bool $bold = false, bool $numeric = false): array
    {
        return ['text' => $text, 'code' => $code, 'bold' => $bold, 'numeric' => $numeric];
    }

    public function setColumnWidths(array $widths): void
    {
        $this->columnWidths = array_map('intval', $widths);
    }

    /** How many top rows to keep pinned when scrolling — call before addHeaderRow() if not 1. */
    public function setFreezeRows(int $n): void
    {
        $this->freezeRows = max(0, $n);
    }

    /**
     * Merges a range of cells on one row (0-based row/column indices, both inclusive)
     * — used for a grouped header row, e.g. one "July 2026" label spanning every day
     * column that falls in July. Only the top-left cell's content/style is kept;
     * write that cell's text via addHeaderRow()/addRow() as normal, this just merges
     * the cells visually. A single-column "span" (startCol === endCol) is skipped —
     * merging one cell with itself is a no-op some Excel/LibreOffice versions warn on.
     */
    public function mergeCells(int $rowIndex, int $startCol, int $endCol): void
    {
        if ($endCol <= $startCol) {
            return;
        }
        $r = $rowIndex + 1;
        $this->merges[] = $this->columnLetter($startCol + 1) . $r . ':' . $this->columnLetter($endCol + 1) . $r;
    }

    /** @param string[] $labels */
    public function addHeaderRow(array $labels): void
    {
        $row = [];
        foreach ($labels as $label) {
            $row[] = ['text' => (string)$label, 'style' => self::STYLE_HEADER, 'type' => 'inlineStr'];
        }
        $this->rows[] = $row;
    }

    /** @param array<int, array{text:string,code:?string,bold:bool,numeric:bool}> $cells Built with self::cell(). */
    public function addRow(array $cells): void
    {
        $row = [];
        foreach ($cells as $c) {
            $code = $c['code'] ?? null;
            if ($code !== null && isset(self::CODE_STYLES[$code])) {
                $style = self::CODE_STYLES[$code];
            } elseif (!empty($c['bold'])) {
                $style = self::STYLE_LABEL_BOLD;
            } elseif (!empty($c['numeric'])) {
                $style = self::STYLE_BLANK_CENTER;
            } elseif ($code !== null) {
                // A code was given but it's not one we colour (defensive default).
                $style = self::STYLE_BLANK_CENTER;
            } else {
                $style = self::STYLE_LABEL;
            }
            $row[] = [
                'text' => (string)($c['text'] ?? ''),
                'style' => $style,
                'type' => !empty($c['numeric']) ? 'n' : 'inlineStr',
            ];
        }
        $this->rows[] = $row;
    }

    /** Sends the download headers, streams the file, and exits. Does not return. */
    public function download(string $filename): void
    {
        // Strip anything that isn't safe inside a Content-Disposition filename
        // (defence in depth against header injection / malformed filenames —
        // PHP's header() already rejects embedded CR/LF on its own).
        $safeName = preg_replace('/[^A-Za-z0-9._-]/', '_', $filename) ?? 'export.xlsx';
        if (!str_ends_with(strtolower($safeName), '.xlsx')) {
            $safeName .= '.xlsx';
        }

        if (!class_exists('ZipArchive')) {
            http_response_code(500);
            header('Content-Type: text/plain; charset=UTF-8');
            echo 'The PHP zip extension is not enabled on this server, so a .xlsx file cannot be built. Ask your host to enable ext-zip.';
            exit;
        }

        $tmpPath = tempnam(sys_get_temp_dir(), 'akps_xlsx_');
        if ($tmpPath === false) {
            http_response_code(500);
            echo 'Could not create a temporary file for the export.';
            exit;
        }

        try {
            $this->writeZip($tmpPath);

            // Defensive: some hosts (Hostinger included) enable zlib.output_compression
            // or wrap output in a buffer by default. If that's active, the browser
            // receives a different byte count than whatever Content-Length we declare,
            // which truncates/corrupts the download — Excel then reports "file format
            // or file extension is not valid". Clearing buffers and turning compression
            // off for this response avoids that mismatch.
            while (ob_get_level() > 0) {
                ob_end_clean();
            }
            if (function_exists('apache_setenv')) {
                @apache_setenv('no-gzip', '1');
            }
            @ini_set('zlib.output_compression', '0');

            $fileSize = filesize($tmpPath);

            header('Content-Description: File Transfer');
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="' . $safeName . '"');
            header('Content-Transfer-Encoding: binary');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: public');
            header('Expires: 0');
            // Only advertise a length when we're confident nothing downstream will
            // re-encode the body (no active output buffer at this point) — an
            // incorrect Content-Length is worse than none, since it makes the
            // browser cut the file off at the wrong byte.
            if ($fileSize !== false && ob_get_level() === 0) {
                header('Content-Length: ' . (string)$fileSize);
            }

            $handle = fopen($tmpPath, 'rb');
            if ($handle !== false) {
                fpassthru($handle);
                fclose($handle);
            } else {
                readfile($tmpPath);
            }
        } finally {
            // Always clean up the temp file, even if the read above throws.
            @unlink($tmpPath);
        }
        exit;
    }

    private function writeZip(string $path): void
    {
        $zip = new ZipArchive();
        // CREATE (not OVERWRITE) because $path comes from tempnam(), which already
        // creates an empty file — OVERWRITE expects an existing *zip* to replace.
        $zip->open($path, ZipArchive::CREATE);

        $zip->addFromString('[Content_Types].xml', $this->contentTypesXml());
        $zip->addFromString('_rels/.rels', $this->rootRelsXml());
        $zip->addFromString('xl/workbook.xml', $this->workbookXml());
        $zip->addFromString('xl/_rels/workbook.xml.rels', $this->workbookRelsXml());
        $zip->addFromString('xl/styles.xml', $this->stylesXml());
        $zip->addFromString('xl/worksheets/sheet1.xml', $this->sheetXml());

        $zip->close();
    }

    private function contentTypesXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            . '</Types>';
    }

    private function rootRelsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '</Relationships>';
    }

    private function workbookXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            . 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheets><sheet name="' . $this->escapeXml($this->sheetName) . '" sheetId="1" r:id="rId1"/></sheets>'
            . '</workbook>';
    }

    private function workbookRelsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
            . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            . '</Relationships>';
    }

    /**
     * Fonts/fills/borders/cellXfs indices here MUST stay in sync with the
     * STYLE_* / CODE_STYLES constants above.
     */
    private function stylesXml(): string
    {
        $fonts = [
            '<font><sz val="11"/><name val="Calibri"/></font>',                                   // 0 default
            '<font><b/><sz val="11"/><name val="Calibri"/></font>',                                // 1 bold (header)
            '<font><sz val="11"/><color rgb="FF006100"/><name val="Calibri"/></font>',             // 2 green text
            '<font><sz val="11"/><color rgb="FF9C0006"/><name val="Calibri"/></font>',             // 3 red text
            '<font><sz val="11"/><color rgb="FF9C6500"/><name val="Calibri"/></font>',             // 4 amber text
            '<font><sz val="11"/><color rgb="FF1F4E78"/><name val="Calibri"/></font>',             // 5 blue text
            '<font><sz val="11"/><color rgb="FFAD1457"/><name val="Calibri"/></font>',             // 6 pink text
        ];

        $fills = [
            '<fill><patternFill patternType="none"/></fill>',                                            // 0 required
            '<fill><patternFill patternType="gray125"/></fill>',                                          // 1 required
            '<fill><patternFill patternType="solid"><fgColor rgb="FFD9D9D9"/><bgColor indexed="64"/></patternFill></fill>', // 2 header grey
            '<fill><patternFill patternType="solid"><fgColor rgb="FFC6EFCE"/><bgColor indexed="64"/></patternFill></fill>', // 3 green
            '<fill><patternFill patternType="solid"><fgColor rgb="FFFFC7CE"/><bgColor indexed="64"/></patternFill></fill>', // 4 red
            '<fill><patternFill patternType="solid"><fgColor rgb="FFFFEB9C"/><bgColor indexed="64"/></patternFill></fill>', // 5 amber
            '<fill><patternFill patternType="solid"><fgColor rgb="FFBDD7EE"/><bgColor indexed="64"/></patternFill></fill>', // 6 blue
            '<fill><patternFill patternType="solid"><fgColor rgb="FFFCE4EC"/><bgColor indexed="64"/></patternFill></fill>', // 7 pink
        ];

        $thin = '<left style="thin"><color indexed="64"/></left><right style="thin"><color indexed="64"/></right>'
            . '<top style="thin"><color indexed="64"/></top><bottom style="thin"><color indexed="64"/></bottom><diagonal/>';
        $borders = [
            '<border><left/><right/><top/><bottom/><diagonal/></border>', // 0 none
            '<border>' . $thin . '</border>',                             // 1 thin all sides
        ];

        $center = '<alignment horizontal="center" vertical="center"/>';
        $left = '<alignment horizontal="left" vertical="center"/>';

        // xf: fontId, fillId, borderId, alignment — indices must match the class
        // constants (STYLE_HEADER=1, CODE_STYLES P/L/A/E/H=2..6, STYLE_BLANK_CENTER=7,
        // STYLE_LABEL=8, STYLE_LABEL_BOLD=9).
        $cellXfs = [
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>',                                                                  // 0 default
            '<xf numFmtId="0" fontId="1" fillId="2" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $center . '</xf>', // 1 header
            '<xf numFmtId="0" fontId="2" fillId="3" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $center . '</xf>', // 2 P
            '<xf numFmtId="0" fontId="3" fillId="4" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $center . '</xf>', // 3 A
            '<xf numFmtId="0" fontId="4" fillId="5" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $center . '</xf>', // 4 L
            '<xf numFmtId="0" fontId="5" fillId="6" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $center . '</xf>', // 5 E
            '<xf numFmtId="0" fontId="6" fillId="7" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $center . '</xf>', // 6 H
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1" applyAlignment="1">' . $center . '</xf>',            // 7 blank/count
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" applyBorder="1" applyAlignment="1">' . $left . '</xf>',              // 8 label
            '<xf numFmtId="0" fontId="1" fillId="0" borderId="1" applyFont="1" applyBorder="1" applyAlignment="1">' . $center . '</xf>', // 9 bold count
        ];

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<fonts count="' . count($fonts) . '">' . implode('', $fonts) . '</fonts>'
            . '<fills count="' . count($fills) . '">' . implode('', $fills) . '</fills>'
            . '<borders count="' . count($borders) . '">' . implode('', $borders) . '</borders>'
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . '<cellXfs count="' . count($cellXfs) . '">' . implode('', $cellXfs) . '</cellXfs>'
            . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
            . '</styleSheet>';
    }

    private function sheetXml(): string
    {
        $colsXml = '';
        if (!empty($this->columnWidths)) {
            $colsXml .= '<cols>';
            foreach ($this->columnWidths as $i => $width) {
                $col = $i + 1;
                $colsXml .= '<col min="' . $col . '" max="' . $col . '" width="' . max(4, (int)$width) . '" customWidth="1"/>';
            }
            $colsXml .= '</cols>';
        }

        $sheetData = '<sheetData>';
        foreach ($this->rows as $rowIndex => $cells) {
            $r = $rowIndex + 1;
            $sheetData .= '<row r="' . $r . '">';
            foreach ($cells as $colIndex => $cell) {
                $ref = $this->columnLetter($colIndex + 1) . $r;
                if ($cell['type'] === 'n') {
                    $num = is_numeric($cell['text']) ? $cell['text'] : '0';
                    $sheetData .= '<c r="' . $ref . '" s="' . $cell['style'] . '"><v>' . $num . '</v></c>';
                } else {
                    $sheetData .= '<c r="' . $ref . '" t="inlineStr" s="' . $cell['style'] . '">'
                        . '<is><t xml:space="preserve">' . $this->escapeXml($cell['text']) . '</t></is></c>';
                }
            }
            $sheetData .= '</row>';
        }
        $sheetData .= '</sheetData>';

        $mergeXml = '';
        if (!empty($this->merges)) {
            $mergeXml = '<mergeCells count="' . count($this->merges) . '">';
            foreach ($this->merges as $ref) {
                $mergeXml .= '<mergeCell ref="' . $ref . '"/>';
            }
            $mergeXml .= '</mergeCells>';
        }

        $paneXml = $this->freezeRows > 0
            ? '<pane ySplit="' . $this->freezeRows . '" topLeftCell="A' . ($this->freezeRows + 1) . '" activePane="bottomLeft" state="frozen"/>'
            : '';

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<sheetViews><sheetView tabSelected="1" workbookViewId="0">'
            . $paneXml
            . '</sheetView></sheetViews>'
            . $colsXml
            . $sheetData
            . $mergeXml
            . '</worksheet>';
    }

    /** 1-based column index to spreadsheet column letters (1 -> A, 27 -> AA, ...). */
    private function columnLetter(int $index): string
    {
        $letters = '';
        while ($index > 0) {
            $index--;
            $letters = chr(65 + ($index % 26)) . $letters;
            $index = intdiv($index, 26);
        }
        return $letters;
    }

    /**
     * Escapes text for XML content and strips characters that are outright illegal
     * in XML 1.0 (control chars other than tab/CR/LF) so a stray byte in a name
     * field can't produce a corrupt/unopenable .xlsx.
     */
    private function escapeXml(string $text): string
    {
        $clean = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $text) ?? $text;
        return htmlspecialchars($clean, ENT_XML1 | ENT_COMPAT, 'UTF-8');
    }
}
