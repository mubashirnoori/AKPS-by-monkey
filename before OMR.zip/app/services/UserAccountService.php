<?php

/**
 * Small shared helper so Students, Staff, and Guardians can each offer an
 * optional "also create a login" checkbox on their create forms without
 * duplicating the user-creation/linking logic that already lives in
 * UsersController.
 */
class UserAccountService
{
    public static function roleIdByName(string $roleName): ?int
    {
        $row = Database::fetchOne('SELECT id FROM roles WHERE name = ?', 's', [$roleName]);
        return $row ? (int)$row['id'] : null;
    }

    /** Turns "Ali Khan" into ali.khan, ali.khan2, ali.khan3 … until it's free. */
    public static function uniqueUsername(string $base): string
    {
        $base = strtolower(trim($base));
        $base = preg_replace('/[^a-z0-9]+/', '.', $base) ?? '';
        $base = trim($base, '.');
        if ($base === '') {
            $base = 'user';
        }

        $username = $base;
        $i = 1;
        while (Database::fetchOne('SELECT id FROM users WHERE username = ?', 's', [$username])) {
            $i++;
            $username = $base . $i;
        }
        return $username;
    }

    public static function randomPassword(int $length = 8): string
    {
        $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
        $out = '';
        for ($i = 0; $i < $length; $i++) {
            $out .= $chars[random_int(0, strlen($chars) - 1)];
        }
        return $out;
    }

    /**
     * Creates a user and links it to the given record (students / staff_profiles / guardians).
     * Any other record previously linked to a new user of the same username is irrelevant here —
     * this always creates a brand-new user row, so no unlink step is needed.
     */
    public static function createAndLink(string $table, int $recordId, string $username, ?string $email, string $password, int $roleId): int
    {
        $allowed = ['students', 'staff_profiles', 'guardians'];
        if (!in_array($table, $allowed, true) || $recordId <= 0 || $roleId <= 0) {
            return 0;
        }

        $hash = password_hash($password, PASSWORD_BCRYPT);
        Database::execute(
            'INSERT INTO users (username, email, password_hash, role_id, status, created_at) VALUES (?, ?, ?, ?, 1, NOW())',
            'sssi',
            [$username, $email !== '' ? $email : null, $hash, $roleId]
        );
        $userId = (int)Database::lastInsertId();

        Database::execute("UPDATE {$table} SET user_id = ? WHERE id = ?", 'ii', [$userId, $recordId]);

        return $userId;
    }
}
