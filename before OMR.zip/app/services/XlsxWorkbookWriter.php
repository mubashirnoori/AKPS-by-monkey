<?php

/**
 * XlsxWorkbookWriter
 *
 * Multi-sheet sibling of XlsxGridWriter — same "raw OOXML via ZipArchive, no
 * Composer/PhpSpreadsheet needed" approach, generalized to support several
 * sheets in one workbook, merged banner cells, per-sheet freeze rows/column
 * widths, and a fixed palette of named styles (banners, section headers,
 * zebra-striped data rows, a literal-"%" percent format, PASS/FAIL/PROMOTE
 * color coding). Built for AcademicController::buildResultsWorkbook().
 *
 * This exists specifically to replace an older implementation that produced
 * "Excel 2003 XML" (SpreadsheetML) — a plain-text XML document saved with a
 * .xls extension. Desktop Excel opens that leniently, but it is not a real
 * binary/zip spreadsheet file, and strict mobile document viewers (including
 * the ones bundled into WebView-wrapped Android apps) correctly identify the
 * mismatch and report the file as corrupted. A genuine .xlsx here is a real
 * ZIP archive whose bytes actually match what the extension promises.
 *
 * Usage:
 *   $w = new XlsxWorkbookWriter();
 *   $w->addSheet('Summary');
 *   $w->setColumnWidths([18, 20, 20, 20, 20]);
 *   $w->setFreezeRows(3);
 *   $w->addRow([XlsxWorkbookWriter::str('Title', XlsxWorkbookWriter::STYLE_TITLE_BANNER, 4)], 30);
 *   $w->addRow([XlsxWorkbookWriter::str(''), XlsxWorkbookWriter::str('Name'), XlsxWorkbookWriter::num(90.5, XlsxWorkbookWriter::STYLE_PERCENT)]);
 *   $w->addSheet('Detail'); // starts a second sheet
 *   ...
 *   $w->download('Results.xlsx'); // sends headers, streams, and exits
 */
final class XlsxWorkbookWriter
{
    // Named style IDs — indices into the shared cellXfs table built in stylesXml().
    public const STYLE_DEFAULT = 0;
    public const STYLE_TITLE_BANNER = 1;
    public const STYLE_SUBTITLE_BANNER = 2;
    public const STYLE_SPACER = 3;
    public const STYLE_SECTION_HEADER = 4;
    public const STYLE_SUBSECTION_HEADER = 5;
    public const STYLE_TOPPER_BANNER = 6;
    public const STYLE_HEADER = 7;
    public const STYLE_CELL = 8;
    public const STYLE_CELL_ALT = 9;
    public const STYLE_POSITION = 10;
    public const STYLE_PERCENT = 11;
    public const STYLE_RESULT_PASS = 12;
    public const STYLE_RESULT_FAIL = 13;
    public const STYLE_RESULT_PROMOTE = 14;

    /** @var array<int, array{name:string, rows:array, colWidths:int[], freezeRows:int, merges:string[]}> */
    private array $sheets = [];
    private int $current = -1;
    /** @var array<string,bool> */
    private array $usedSheetNames = [];

    /**
     * Diagnostic-only escape hatch: when true, every cell is written with the
     * single mandatory default style (no colors/fonts/borders) and no merged
     * cells are emitted at all, regardless of what the caller asked for — the
     * data/sheets/rows are unchanged. Exists purely so a "does a bare-bones
     * .xlsx open on this phone/app?" test can be done via a URL flag without
     * touching any of the caller code that builds the workbook.
     */
    private bool $plainMode = false;

    public function setPlainMode(bool $plain): void
    {
        $this->plainMode = $plain;
    }

    /** Builds one text cell. $mergeAcross N merges this cell across N additional columns to its right (0 = no merge) — same meaning as the old ss:MergeAcross. */
    public static function str(string $text, int $style = self::STYLE_CELL, int $mergeAcross = 0): array
    {
        return ['text' => $text, 'style' => $style, 'type' => 'str', 'merge' => $mergeAcross];
    }

    /** Builds one numeric cell. $value is written as a real number (Excel can sum/sort it); pass an already-percentage number for STYLE_PERCENT (it's displayed as "N.NN%" via a literal-quoted format, not divided by 100). */
    public static function num($value, int $style = self::STYLE_CELL): array
    {
        return ['text' => is_numeric($value) ? (string)$value : '0', 'style' => $style, 'type' => 'n', 'merge' => 0];
    }

    /** Starts a new sheet; all subsequent addRow()/setColumnWidths()/setFreezeRows() calls apply to it. */
    public function addSheet(string $name): void
    {
        $clean = preg_replace('/[:\\\\\/\?\*\[\]]/', '', $name) ?? 'Sheet';
        $clean = mb_substr($clean !== '' ? $clean : 'Sheet', 0, 31);
        $base = $clean;
        $i = 2;
        while (isset($this->usedSheetNames[$clean])) {
            $suffix = ' (' . $i . ')';
            $clean = mb_substr($base, 0, 31 - mb_strlen($suffix)) . $suffix;
            $i++;
        }
        $this->usedSheetNames[$clean] = true;

        $this->sheets[] = ['name' => $clean, 'rows' => [], 'colWidths' => [], 'freezeRows' => 0, 'merges' => []];
        $this->current = count($this->sheets) - 1;
    }

    public function setColumnWidths(array $widths): void
    {
        $this->sheets[$this->current]['colWidths'] = array_map('intval', $widths);
    }

    public function setFreezeRows(int $n): void
    {
        $this->sheets[$this->current]['freezeRows'] = max(0, $n);
    }

    /** @param array $cells Built with self::str()/self::num(). */
    public function addRow(array $cells, ?int $height = null): void
    {
        $rowIndex = count($this->sheets[$this->current]['rows']);
        foreach ($cells as $colIndex => $c) {
            $span = (int)($c['merge'] ?? 0);
            if ($span > 0) {
                $r = $rowIndex + 1;
                $startCol = $colIndex + 1;
                $endCol = $startCol + $span;
                $this->sheets[$this->current]['merges'][] =
                    $this->columnLetter($startCol) . $r . ':' . $this->columnLetter($endCol) . $r;
            }
        }
        $this->sheets[$this->current]['rows'][] = ['cells' => $cells, 'height' => $height];
    }

    /** Sends the download headers, streams the file, and exits. Does not return. */
    public function download(string $filename): void
    {
        $safeName = preg_replace('/[^A-Za-z0-9._-]/', '_', $filename) ?? 'export.xlsx';
        if (!str_ends_with(strtolower($safeName), '.xlsx')) {
            $safeName .= '.xlsx';
        }

        if (!class_exists('ZipArchive')) {
            http_response_code(500);
            header('Content-Type: text/plain; charset=UTF-8');
            echo 'The PHP zip extension is not enabled on this server, so a .xlsx file cannot be built. Ask your host to enable ext-zip.';
            exit;
        }

        $tmpPath = tempnam(sys_get_temp_dir(), 'akps_xlsx_');
        if ($tmpPath === false) {
            http_response_code(500);
            echo 'Could not create a temporary file for the export.';
            exit;
        }

        try {
            $this->writeZip($tmpPath);

            // Same defensive flush/compression-off as XlsxGridWriter::download() —
            // an active output buffer or host-level gzip re-encoding after we've
            // already told the client the exact byte count is what turns a
            // perfectly good file into "appears to be corrupted" on a strict
            // mobile viewer, even though desktop Excel/Chrome shrug it off.
            while (ob_get_level() > 0) {
                ob_end_clean();
            }
            if (function_exists('apache_setenv')) {
                @apache_setenv('no-gzip', '1');
            }
            @ini_set('zlib.output_compression', '0');

            $fileSize = filesize($tmpPath);

            header('Content-Description: File Transfer');
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="' . $safeName . '"');
            header('Content-Transfer-Encoding: binary');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: public');
            header('Expires: 0');
            if ($fileSize !== false && ob_get_level() === 0) {
                header('Content-Length: ' . (string)$fileSize);
            }

            $handle = fopen($tmpPath, 'rb');
            if ($handle !== false) {
                fpassthru($handle);
                fclose($handle);
            } else {
                readfile($tmpPath);
            }
        } finally {
            @unlink($tmpPath);
        }
        exit;
    }

    private function writeZip(string $path): void
    {
        $zip = new ZipArchive();
        $zip->open($path, ZipArchive::CREATE);

        $zip->addFromString('[Content_Types].xml', $this->contentTypesXml());
        $zip->addFromString('_rels/.rels', $this->rootRelsXml());
        $zip->addFromString('xl/workbook.xml', $this->workbookXml());
        $zip->addFromString('xl/_rels/workbook.xml.rels', $this->workbookRelsXml());
        $zip->addFromString('xl/styles.xml', $this->stylesXml());
        foreach ($this->sheets as $i => $sheet) {
            $zip->addFromString('xl/worksheets/sheet' . ($i + 1) . '.xml', $this->sheetXml($sheet));
        }

        $zip->close();
    }

    private function contentTypesXml(): string
    {
        $overrides = '';
        foreach ($this->sheets as $i => $sheet) {
            $overrides .= '<Override PartName="/xl/worksheets/sheet' . ($i + 1) . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
        }
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>'
            . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . $overrides
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            . '</Types>';
    }

    private function rootRelsXml(): string
    {
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '</Relationships>';
    }

    private function workbookXml(): string
    {
        $sheetsXml = '';
        foreach ($this->sheets as $i => $sheet) {
            $n = $i + 1;
            $sheetsXml .= '<sheet name="' . $this->escapeXml($sheet['name']) . '" sheetId="' . $n . '" r:id="rId' . ($n + 1) . '"/>';
        }
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            . 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheets>' . $sheetsXml . '</sheets>'
            . '</workbook>';
    }

    private function workbookRelsXml(): string
    {
        // Relationship IDs here are local to this file (xl/_rels/workbook.xml.rels)
        // and independent of the ones in the root _rels/.rels — starting at rId2
        // (leaving rId1 unused) just keeps every id in this file unique; nothing
        // requires starting at 1.
        $rels = '';
        foreach ($this->sheets as $i => $sheet) {
            $n = $i + 1;
            $rels .= '<Relationship Id="rId' . ($n + 1) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $n . '.xml"/>';
        }
        $stylesRid = count($this->sheets) + 2;
        $rels .= '<Relationship Id="rId' . $stylesRid . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . $rels
            . '</Relationships>';
    }

    /**
     * Fixed style palette. Indices here MUST stay in sync with the STYLE_* constants above.
     * Colors mirror the previous SpreadsheetML palette exactly (same hex values), just
     * expressed as OOXML fonts/fills/borders/cellXfs instead of <Style> elements.
     */
    private function stylesXml(): string
    {
        if ($this->plainMode) {
            // Bare minimum a valid xlsx must have: one font, one "none" fill, one
            // required "gray125" fill, one "none" border, one cellXf (index 0) —
            // no colors, no custom number formats, no borders.
            return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                . '<fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>'
                . '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
                . '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
                . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
                . '<cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellXfs>'
                . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
                . '</styleSheet>';
        }

        $fonts = [
            '<font><sz val="11"/><name val="Calibri"/></font>',                                                 // 0 default
            '<font><b/><sz val="16"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>',                      // 1 title banner
            '<font><i/><sz val="10"/><color rgb="FFD9C68F"/><name val="Calibri"/></font>',                      // 2 subtitle banner
            '<font><sz val="11"/><name val="Calibri"/></font>',                                                 // 3 spacer (unused, no text)
            '<font><b/><sz val="12"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>',                      // 4 section header
            '<font><b/><sz val="11"/><color rgb="FF1E3A5F"/><name val="Calibri"/></font>',                      // 5 sub-section header
            '<font><b/><sz val="13"/><color rgb="FF5C4300"/><name val="Calibri"/></font>',                      // 6 topper banner
            '<font><b/><color rgb="FF1E3A5F"/><name val="Calibri"/></font>',                                    // 7 header row
            '<font><sz val="11"/><name val="Calibri"/></font>',                                                 // 8 plain cell
            '<font><b/><name val="Calibri"/></font>',                                                           // 9 position (bold)
            '<font><b/><color rgb="FF006100"/><name val="Calibri"/></font>',                                    // 10 result pass
            '<font><b/><color rgb="FF9C0006"/><name val="Calibri"/></font>',                                    // 11 result fail
            '<font><b/><color rgb="FF9C6500"/><name val="Calibri"/></font>',                                    // 12 result promote
        ];

        $fills = [
            '<fill><patternFill patternType="none"/></fill>',                                                                     // 0 required
            '<fill><patternFill patternType="gray125"/></fill>',                                                                  // 1 required
            '<fill><patternFill patternType="solid"><fgColor rgb="FF0F2A47"/><bgColor indexed="64"/></patternFill></fill>',       // 2 title banner navy
            '<fill><patternFill patternType="solid"><fgColor rgb="FF16385C"/><bgColor indexed="64"/></patternFill></fill>',       // 3 subtitle navy
            '<fill><patternFill patternType="solid"><fgColor rgb="FF1E3A5F"/><bgColor indexed="64"/></patternFill></fill>',       // 4 section header navy
            '<fill><patternFill patternType="solid"><fgColor rgb="FFDCE6F1"/><bgColor indexed="64"/></patternFill></fill>',       // 5 sub-section / header light blue
            '<fill><patternFill patternType="solid"><fgColor rgb="FFF6E4A6"/><bgColor indexed="64"/></patternFill></fill>',       // 6 topper gold
            '<fill><patternFill patternType="solid"><fgColor rgb="FFF5F7FA"/><bgColor indexed="64"/></patternFill></fill>',       // 7 zebra alt
            '<fill><patternFill patternType="solid"><fgColor rgb="FFC6EFCE"/><bgColor indexed="64"/></patternFill></fill>',       // 8 result pass green
            '<fill><patternFill patternType="solid"><fgColor rgb="FFFFC7CE"/><bgColor indexed="64"/></patternFill></fill>',       // 9 result fail red
            '<fill><patternFill patternType="solid"><fgColor rgb="FFFFEB9C"/><bgColor indexed="64"/></patternFill></fill>',       // 10 result promote amber
        ];

        $thin = '<left style="thin"><color rgb="FFD9D9D9"/></left><right style="thin"><color rgb="FFD9D9D9"/></right>'
            . '<top style="thin"><color rgb="FFD9D9D9"/></top><bottom style="thin"><color rgb="FFD9D9D9"/></bottom><diagonal/>';
        $borders = [
            '<border><left/><right/><top/><bottom/><diagonal/></border>', // 0 none
            '<border>' . $thin . '</border>',                             // 1 thin all sides
        ];

        $center = '<alignment horizontal="center" vertical="center"/>';

        // Custom numFmt: literal "%" appended to the raw number, NOT the built-in
        // percentage format (which would multiply the value by 100) — matches the
        // old ss:Format="0.00&quot;%&quot;" behaviour exactly: pass 90.93, see "90.93%".
        $numFmts = '<numFmts count="1"><numFmt numFmtId="164" formatCode="0.00&quot;%&quot;"/></numFmts>';

        // xf: fontId, fillId, borderId, alignment, numFmtId — indices MUST match the
        // STYLE_* class constants (0..14) 1:1, in the same order.
        $cellXfs = [
            '<xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>',                                                                                        // 0 STYLE_DEFAULT
            '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" applyFont="1" applyFill="1" applyAlignment="1">' . $center . '</xf>',                       // 1 STYLE_TITLE_BANNER
            '<xf numFmtId="0" fontId="2" fillId="3" borderId="0" applyFont="1" applyFill="1" applyAlignment="1">' . $center . '</xf>',                       // 2 STYLE_SUBTITLE_BANNER
            '<xf numFmtId="0" fontId="3" fillId="0" borderId="0" applyFill="1"/>',                                                                           // 3 STYLE_SPACER
            '<xf numFmtId="0" fontId="4" fillId="4" borderId="0" applyFont="1" applyFill="1" applyAlignment="1">' . $center . '</xf>',                       // 4 STYLE_SECTION_HEADER
            '<xf numFmtId="0" fontId="5" fillId="5" borderId="1" applyFont="1" applyFill="1" applyBorder="1"/>',                                             // 5 STYLE_SUBSECTION_HEADER
            '<xf numFmtId="0" fontId="6" fillId="6" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $center . '</xf>',       // 6 STYLE_TOPPER_BANNER
            '<xf numFmtId="0" fontId="7" fillId="5" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $center . '</xf>',       // 7 STYLE_HEADER
            '<xf numFmtId="0" fontId="8" fillId="0" borderId="1" applyBorder="1"/>',                                                                         // 8 STYLE_CELL
            '<xf numFmtId="0" fontId="8" fillId="7" borderId="1" applyFill="1" applyBorder="1"/>',                                                           // 9 STYLE_CELL_ALT
            '<xf numFmtId="0" fontId="9" fillId="0" borderId="1" applyFont="1" applyBorder="1" applyAlignment="1">' . $center . '</xf>',                     // 10 STYLE_POSITION
            '<xf numFmtId="164" fontId="8" fillId="0" borderId="1" applyNumberFormat="1" applyBorder="1" applyAlignment="1">' . $center . '</xf>',           // 11 STYLE_PERCENT
            '<xf numFmtId="0" fontId="10" fillId="8" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $center . '</xf>',      // 12 STYLE_RESULT_PASS
            '<xf numFmtId="0" fontId="11" fillId="9" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $center . '</xf>',      // 13 STYLE_RESULT_FAIL
            '<xf numFmtId="0" fontId="12" fillId="10" borderId="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $center . '</xf>',     // 14 STYLE_RESULT_PROMOTE
        ];

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . $numFmts
            . '<fonts count="' . count($fonts) . '">' . implode('', $fonts) . '</fonts>'
            . '<fills count="' . count($fills) . '">' . implode('', $fills) . '</fills>'
            . '<borders count="' . count($borders) . '">' . implode('', $borders) . '</borders>'
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . '<cellXfs count="' . count($cellXfs) . '">' . implode('', $cellXfs) . '</cellXfs>'
            . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
            . '</styleSheet>';
    }

    private function sheetXml(array $sheet): string
    {
        $colsXml = '';
        if (!empty($sheet['colWidths'])) {
            $colsXml .= '<cols>';
            foreach ($sheet['colWidths'] as $i => $width) {
                $col = $i + 1;
                $colsXml .= '<col min="' . $col . '" max="' . $col . '" width="' . max(4, (int)$width) . '" customWidth="1"/>';
            }
            $colsXml .= '</cols>';
        }

        $sheetData = '<sheetData>';
        foreach ($sheet['rows'] as $rowIndex => $rowDef) {
            $r = $rowIndex + 1;
            $heightAttr = $rowDef['height'] !== null ? ' ht="' . (float)$rowDef['height'] . '" customHeight="1"' : '';
            $sheetData .= '<row r="' . $r . '"' . $heightAttr . '>';
            foreach ($rowDef['cells'] as $colIndex => $cell) {
                $ref = $this->columnLetter($colIndex + 1) . $r;
                $styleAttr = $this->plainMode ? '0' : (string)$cell['style'];
                if ($cell['type'] === 'n') {
                    $num = is_numeric($cell['text']) ? $cell['text'] : '0';
                    $sheetData .= '<c r="' . $ref . '" s="' . $styleAttr . '"><v>' . $num . '</v></c>';
                } else {
                    $sheetData .= '<c r="' . $ref . '" t="inlineStr" s="' . $styleAttr . '">'
                        . '<is><t xml:space="preserve">' . $this->escapeXml($cell['text']) . '</t></is></c>';
                }
            }
            $sheetData .= '</row>';
        }
        $sheetData .= '</sheetData>';

        $mergeXml = '';
        if (!$this->plainMode && !empty($sheet['merges'])) {
            $mergeXml = '<mergeCells count="' . count($sheet['merges']) . '">';
            foreach ($sheet['merges'] as $ref) {
                $mergeXml .= '<mergeCell ref="' . $ref . '"/>';
            }
            $mergeXml .= '</mergeCells>';
        }

        $freezeRows = $sheet['freezeRows'];
        $paneXml = $freezeRows > 0
            ? '<pane ySplit="' . $freezeRows . '" topLeftCell="A' . ($freezeRows + 1) . '" activePane="bottomLeft" state="frozen"/>'
            : '';

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<sheetViews><sheetView tabSelected="1" workbookViewId="0">'
            . $paneXml
            . '</sheetView></sheetViews>'
            . $colsXml
            . $sheetData
            . $mergeXml
            . '</worksheet>';
    }

    /** 1-based column index to spreadsheet column letters (1 -> A, 27 -> AA, ...). */
    private function columnLetter(int $index): string
    {
        $letters = '';
        while ($index > 0) {
            $index--;
            $letters = chr(65 + ($index % 26)) . $letters;
            $index = intdiv($index, 26);
        }
        return $letters;
    }

    private function escapeXml(string $text): string
    {
        $clean = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $text) ?? $text;
        return htmlspecialchars($clean, ENT_XML1 | ENT_COMPAT, 'UTF-8');
    }
}