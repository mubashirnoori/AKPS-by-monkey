<?php

class AuthController extends Controller
{
    public function loginAction(): void
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                $this->requireCsrf();
                $username = trim((string)($_POST['username'] ?? ''));
                $password = (string)($_POST['password'] ?? '');
                if ($username === '' || $password === '') {
                    throw new RuntimeException('Username and password are required');
                }
                Auth::login($username, $password);
                log_activity('auth.login', 'Logged in');

                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Login successful'];
                redirect_route('dashboard/index');
                return;
            } catch (Throwable $e) {
                $error = $e->getMessage();
                log_activity('auth.login_failed', 'Failed login attempt for username "' . ($username ?? '') . '"');
            }
        } else {
            $error = null;

            // Auth::enforceSingleSession() sends a signed-out user here with
            // ?reason=session_replaced once it detects their account was logged
            // in on another device/browser. Surface that as a plain message
            // instead of silently dropping them back on a blank login form.
            if (($_GET['reason'] ?? '') === 'session_replaced') {
                $error = 'You have been signed out because this account was signed in on another device or browser. Only one active session is allowed at a time.';
            }
        }

        $this->renderBare('auth/login', [
            'title' => 'Login',
            'error' => $error ?? null,
        ]);
    }

    /**
     * Request a password-reset link. Always shows the same confirmation
     * message whether or not the account/email was found — otherwise this
     * endpoint could be used to check which usernames/emails exist.
     */
    public function forgotPasswordAction(): void
    {
        $error = null;
        $sent = false;

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            try {
                $this->requireCsrf();
                $identifier = trim((string)($_POST['identifier'] ?? ''));
                if ($identifier === '') {
                    throw new RuntimeException('Enter your username or email address');
                }

                $user = Database::fetchOne(
                    'SELECT id, username, email FROM users WHERE username = ? OR email = ? LIMIT 1',
                    'ss',
                    [$identifier, $identifier]
                );

                if ($user && !empty($user['email'])) {
                    $token = bin2hex(random_bytes(32));
                    $tokenHash = hash('sha256', $token);

                    // Computed in PHP (not via MySQL's NOW()) so the expiry can't drift
                    // out of sync if the database server's clock/timezone differs from
                    // the app's configured timezone.
                    $expiresAt = date('Y-m-d H:i:s', time() + 1800);

                    // Invalidate any earlier unused links for this account first.
                    Database::execute('DELETE FROM password_resets WHERE user_id = ? AND used_at IS NULL', 'i', [(int)$user['id']]);
                    Database::execute(
                        'INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?, ?, ?)',
                        'iss',
                        [(int)$user['id'], $tokenHash, $expiresAt]
                    );

                    $resetUrl = base_url('/index.php?route=' . rawurlencode('auth/resetPassword') . '&token=' . $token);
                    $html = '<p>Hello ' . h($user['username']) . ',</p>'
                        . '<p>Someone requested a password reset for your School Management System account. '
                        . 'Click the link below to set a new password. This link expires in 30 minutes.</p>'
                        . '<p><a href="' . h($resetUrl) . '">' . h($resetUrl) . '</a></p>'
                        . '<p>If you did not request this, you can safely ignore this email — your password will not change.</p>';

                    Mailer::send((string)$user['email'], (string)$user['username'], 'Reset your password', $html);
                    log_activity('auth.password_reset_request', 'Requested a password reset for "' . $user['username'] . '"');
                }

                if ($user) {
                    $mobile = resolve_user_mobile((int)$user['id']);
                    if ($mobile !== null && sms_gateway_enabled()) {
                        $code = issue_otp((int)$user['id'], 'password_reset', 600);
                        queue_sms(
                            $mobile,
                            'Your password reset code is ' . $code . '. It expires in 10 minutes. '
                                . 'If you did not request this, ignore this message.',
                            'otp'
                        );
                        log_activity('auth.password_reset_otp_request', 'Queued an SMS reset code for "' . $user['username'] . '"');
                    }
                }

                $sent = true;
            } catch (Throwable $e) {
                $error = $e->getMessage();
            }
        }

        $this->renderBare('auth/forgot_password', [
            'title' => 'Forgot Password',
            'error' => $error,
            'sent' => $sent,
        ]);
    }

    /**
     * Consume a reset link (GET shows the form, POST sets the new password).
     * Tokens are single-use and expire after 30 minutes.
     */
    public function resetPasswordAction(): void
    {
        $token = (string)($_GET['token'] ?? $_POST['token'] ?? '');
        $error = null;
        $done = false;

        $tokenRow = null;
        if ($token !== '') {
            $tokenRow = Database::fetchOne(
                'SELECT pr.id, pr.user_id, pr.expires_at, pr.used_at, u.username
                 FROM password_resets pr JOIN users u ON u.id = pr.user_id
                 WHERE pr.token_hash = ? LIMIT 1',
                's',
                [hash('sha256', $token)]
            );
        }

        $valid = $tokenRow
            && empty($tokenRow['used_at'])
            && strtotime((string)$tokenRow['expires_at']) > time();

        if ($valid && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            try {
                $this->requireCsrf();
                $new = (string)($_POST['new_password'] ?? '');
                $confirm = (string)($_POST['confirm_password'] ?? '');
                if (strlen($new) < 6) {
                    throw new RuntimeException('New password must be at least 6 characters');
                }
                if ($new !== $confirm) {
                    throw new RuntimeException('New password and confirmation do not match');
                }

                Database::execute(
                    'UPDATE users SET password_hash = ?, failed_attempts = 0, locked_until = NULL WHERE id = ?',
                    'si',
                    [password_hash($new, PASSWORD_BCRYPT), (int)$tokenRow['user_id']]
                );
                Database::execute('UPDATE password_resets SET used_at = NOW() WHERE id = ?', 'i', [(int)$tokenRow['id']]);
                log_activity('auth.password_reset', 'Reset password for "' . $tokenRow['username'] . '" via emailed link');

                $done = true;
            } catch (Throwable $e) {
                $error = $e->getMessage();
            }
        }

        $this->renderBare('auth/reset_password', [
            'title' => 'Reset Password',
            'token' => $token,
            'valid' => $valid,
            'error' => $error,
            'done' => $done,
        ]);
    }

    /**
     * Alternative to resetPasswordAction() for accounts that received an SMS
     * code instead of (or in addition to) the emailed link. Identifier + code
     * together prove ownership, so this sets the new password directly.
     */
    public function verifyOtpAction(): void
    {
        $error = null;
        $done = false;
        $identifier = trim((string)($_POST['identifier'] ?? $_GET['identifier'] ?? ''));

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            try {
                $this->requireCsrf();
                $code = trim((string)($_POST['code'] ?? ''));
                $new = (string)($_POST['new_password'] ?? '');
                $confirm = (string)($_POST['confirm_password'] ?? '');

                if ($identifier === '' || $code === '') {
                    throw new RuntimeException('Enter your username/email and the code we texted you');
                }
                if (strlen($new) < 6) {
                    throw new RuntimeException('New password must be at least 6 characters');
                }
                if ($new !== $confirm) {
                    throw new RuntimeException('New password and confirmation do not match');
                }

                $userId = verify_otp($identifier, $code, 'password_reset');
                if ($userId === null) {
                    throw new RuntimeException('That code is invalid or has expired. Request a new one.');
                }

                Database::execute(
                    'UPDATE users SET password_hash = ?, failed_attempts = 0, locked_until = NULL WHERE id = ?',
                    'si',
                    [password_hash($new, PASSWORD_BCRYPT), $userId]
                );
                log_activity('auth.password_reset', 'Reset password for user #' . $userId . ' via SMS code');

                $done = true;
            } catch (Throwable $e) {
                $error = $e->getMessage();
            }
        }

        $this->renderBare('auth/verify_otp', [
            'title' => 'Enter SMS Code',
            'identifier' => $identifier,
            'error' => $error,
            'done' => $done,
        ]);
    }

    public function logoutAction(): void
    {
        // GET is still accepted so an already-expired/invalid session (no CSRF token
        // to check against) can still reach the login page instead of getting stuck.
        // A logged-in session logging out now goes through POST+CSRF like every other
        // state-changing action — see app/views/layout.php for the form this expects.
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && Auth::currentUser()) {
            $this->requireCsrf();
        }
        log_activity('auth.logout', 'Logged out');
        Auth::logout();
    }

    /**
     * Self-service "change my password", available to every role (Admin, Teacher,
     * Student, Parent, Accountant) via a navbar link. Updates the same users.password_hash
     * column Admin's Users page edits, so there is only ever one password per account —
     * a change here is immediately what Admin sees/controls too.
     */
    public function changePasswordAction(): void
    {
        $user = Auth::requireLogin();
        $error = null;

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            try {
                $this->requireCsrf();
                $current = (string)($_POST['current_password'] ?? '');
                $new = (string)($_POST['new_password'] ?? '');
                $confirm = (string)($_POST['confirm_password'] ?? '');

                $row = Database::fetchOne('SELECT password_hash FROM users WHERE id = ?', 'i', [$user['id']]);
                if (!$row || !password_verify($current, $row['password_hash'])) {
                    throw new RuntimeException('Current password is incorrect');
                }
                if (strlen($new) < 6) {
                    throw new RuntimeException('New password must be at least 6 characters');
                }
                if ($new !== $confirm) {
                    throw new RuntimeException('New password and confirmation do not match');
                }

                Database::execute(
                    'UPDATE users SET password_hash = ? WHERE id = ?',
                    'si',
                    [password_hash($new, PASSWORD_BCRYPT), $user['id']]
                );

                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Password updated successfully'];
                redirect_route('auth/changePassword');
                return;
            } catch (Throwable $e) {
                $error = $e->getMessage();
            }
        }

        $this->render('auth/change_password', [
            'title' => 'Change Password',
            'error' => $error,
        ]);
    }
}