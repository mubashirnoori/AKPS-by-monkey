<?php

/**
 * Public-facing, NO-LOGIN controller. Every action here is reachable by
 * anyone who has the link — that's the whole point (a parent has no account
 * on this system) — so the ONLY thing standing between "anyone" and "the one
 * specific record this link was minted for" is ShareToken::verify(). There is
 * deliberately no Auth::requireLogin() / RBAC check anywhere in this file.
 *
 * Every action re-checks anything that could have changed since the link was
 * generated (e.g. "is this exam still published?") rather than trusting that
 * the token being valid means it's still safe to show — a token only proves
 * "a staff member scoped this link to this record", not "nothing about that
 * record has changed since".
 */
class ShareController extends Controller
{
    /** Fee voucher: /index.php?route=share/feeVoucher&t=<token> */
    public function feeVoucherAction(): void
    {
        require_once __DIR__ . '/../services/FeeService.php';

        $claim = ShareToken::verify($_GET['t'] ?? null, 'fee_invoice');
        if ($claim === null) {
            $this->renderExpired();
            return;
        }

        $invoice = FeeService::getInvoiceDetails($claim['id']);
        if (!$invoice) {
            // Invoice was deleted after the link was sent — same user-facing
            // message as an expired link; no need to distinguish for a parent.
            $this->renderExpired();
            return;
        }

        // Standalone HTML document (own <!doctype html>), same technique as
        // FeesController::invoicePrintAction() — not wrapped in the app's
        // navbar/sidebar shell, which would leak internal nav to a parent
        // with no session anyway.
        echo $this->renderPartial('fees/invoice_print', [
            'title'   => 'Fee Voucher',
            'invoice' => $invoice,
        ]);
    }

    /** Report card: /index.php?route=share/reportCard&t=<token> */
    public function reportCardAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/ExamModel.php';

        $claim = ShareToken::verify($_GET['t'] ?? null, 'report_card');
        if ($claim === null) {
            $this->renderExpired();
            return;
        }

        $studentId = $claim['id'];
        $examId = (int)($claim['extra']['exam_id'] ?? 0);

        $student = $studentId > 0 ? StudentModel::getById($studentId) : null;
        $exam = $examId > 0 ? ExamModel::getExam($examId) : null;

        // Re-check publication status live, at view time — never trust that
        // "the link exists" implies "this result is meant to be public yet".
        // Mirrors the same rule AcademicController::certificateAction() applies
        // to any non-admin viewer.
        if (!$student || !$exam || (int)($exam['results_published'] ?? 0) !== 1) {
            $this->renderExpired();
            return;
        }

        $card = ExamModel::studentReportCard($studentId, $examId, false, false);

        [$schoolName, $logoPath] = $this->schoolBranding();

        echo $this->renderPartial('academic/_report_card_print', [
            'title'      => 'Report Card',
            'student'    => $student,
            'examName'   => (string)($exam['exam_name'] ?? ''),
            'card'       => $card,
            'schoolName' => $schoolName,
            'logoPath'   => $logoPath ? base_url($logoPath) : '',
        ]);
    }

    /** Attendance summary: /index.php?route=share/attendance&t=<token> */
    public function attendanceAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';

        $claim = ShareToken::verify($_GET['t'] ?? null, 'attendance');
        if ($claim === null) {
            $this->renderExpired();
            return;
        }

        $studentId = $claim['id'];
        $start = (string)($claim['extra']['start'] ?? '');
        $end = (string)($claim['extra']['end'] ?? '');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $end)) {
            $this->renderExpired();
            return;
        }

        $student = StudentModel::getById($studentId);
        if (!$student) {
            $this->renderExpired();
            return;
        }

        $records = Database::fetchAll(
            'SELECT attendance_date, status
             FROM attendance_records
             WHERE student_id = ? AND subject_id IS NULL AND attendance_date BETWEEN ? AND ?
             ORDER BY attendance_date ASC',
            'iss',
            [$studentId, $start, $end]
        );

        $summary = ['total' => 0, 'present' => 0, 'absent' => 0, 'late' => 0, 'excused' => 0, 'holiday' => 0];
        foreach ($records as $r) {
            $summary['total']++;
            $key = (string)($r['status'] ?? '');
            if (isset($summary[$key])) {
                $summary[$key]++;
            }
        }

        [$schoolName, $logoPath] = $this->schoolBranding();

        // Standalone document with its own responsive viewport — deliberately
        // NOT renderBare()/layout_bare.php, which is fixed to a 1280px desktop
        // viewport (fine for the login screen, wrong for a page a parent opens
        // from a phone via WhatsApp).
        echo $this->renderPartial('share/attendance_summary', [
            'title'      => 'Attendance Summary',
            'student'    => $student,
            'start'      => $start,
            'end'        => $end,
            'records'    => $records,
            'summary'    => $summary,
            'schoolName' => $schoolName,
            'logoPath'   => $logoPath ? base_url($logoPath) : '',
        ]);
    }

    /** Same friendly "not available" page for expired/invalid/deleted — never leaks which. */
    private function renderExpired(): void
    {
        http_response_code(404);
        echo $this->renderPartial('share/invalid', ['title' => 'Link Not Available']);
    }

    /** Same small helper duplicated in FeesController/AcademicController — kept consistent with their style. */
    private function schoolBranding(): array
    {
        $name = 'ARC School';
        $logo = '';
        try {
            $rows = Database::fetchAll('SELECT `key`, `value` FROM settings');
            $map = [];
            foreach ($rows as $r) {
                $map[$r['key']] = $r['value'];
            }
            $name = $map['branding_school_name'] ?? $map['institute_name'] ?? 'ARC School';
            $logo = $map['branding_logo_path'] ?? '';
        } catch (Throwable $e) {
            // Keep the defaults if settings can't be read.
        }
        return [$name, $logo];
    }
}
