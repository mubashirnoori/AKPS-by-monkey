<?php

class FeesController extends Controller
{
    public function indexAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission('fees.view');

        // The old tile-grid submenu page is gone — the sidebar's Fees flyout now goes
        // straight to each sub-page, so this route just forwards to the most-used one.
        redirect_route('fees/invoices');
    }

    // =========================
    // CATEGORIES (ENHANCED)
    // =========================
    public function categoriesAction(): void
    {
        require_once __DIR__ . '/../models/FeeCategoryModel.php';

        Auth::requireLogin();
        $this->requirePermission(['fees.manage', 'fees.categories']);

        $search = trim((string)($_GET['q'] ?? ''));
        $editId = (int)($_GET['id'] ?? 0);
        $categoryToEdit = $editId > 0 ? FeeCategoryModel::getById($editId) : null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();

            $id = (int)($_POST['id'] ?? 0);

            $payload = [
                'name'        => trim((string)($_POST['name'] ?? '')),
                'description' => trim((string)($_POST['description'] ?? '')),
                'is_one_time' => (int)($_POST['is_one_time'] ?? 0),
                'is_admission' => (int)($_POST['is_admission'] ?? 0),
                'is_tuition'  => (int)($_POST['is_tuition'] ?? 0),
                'sort_order'  => (int)($_POST['sort_order'] ?? 0),
                'no_discount' => (int)($_POST['no_discount'] ?? 0),
            ];

            if ($payload['name'] === '') {
                $error = 'Name is required';
            } else {
                if ($id > 0) {
                    FeeCategoryModel::update($id, $payload);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Category updated'];
                } else {
                    FeeCategoryModel::create($payload);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Category created'];
                }

                redirect_route('fees/categories');
                return;
            }
        }

        $categories = FeeCategoryModel::list($search, 50, 0);
        $total      = FeeCategoryModel::count($search);

        $this->render('fees/categories', [
            'title'          => 'Fee Categories',
            'search'         => $search,
            'categories'     => $categories,
            'total'          => $total,
            'categoryToEdit' => $categoryToEdit,
            'error'          => $error ?? null,
        ]);
    }

    public function categoryDeleteAction(): void
    {
        require_once __DIR__ . '/../models/FeeCategoryModel.php';

        Auth::requireLogin();
        $this->requirePermission(['fees.manage', 'fees.categories']);
        $this->requireCsrf();

        $id = (int)($_POST['id'] ?? 0);

        if ($id > 0) {
            FeeCategoryModel::delete($id);
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Category deleted'];
            log_activity('fees.category_delete', 'Deleted fee category #' . $id);
        }

        redirect_route('fees/categories');
    }

    // =========================
    // ASSIGNMENTS (FIXED)
    // =========================
    public function assignmentsAction(): void
    {
        require_once __DIR__ . '/../models/FeeCategoryModel.php';
        require_once __DIR__ . '/../models/FeeAssignmentModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';
        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLogin();
        $this->requirePermission(['fees.manage', 'fees.assignments']);

        $feeCategories = FeeCategoryModel::list('', 200, 0);
        $classSections = ClassSectionModel::allOptions();
        $error = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();

            $scopeType      = (string)($_POST['scope_type'] ?? 'student');
            // Class scope supports selecting multiple class/sections at once.
            // Keep the old single class field as a fallback for compatibility.
            $classSectionIds = [];
            $rawClassIds = $_POST['class_section_ids'] ?? [];
            if (is_array($rawClassIds)) {
                foreach ($rawClassIds as $cid) {
                    $cid = (int)$cid;
                    if ($cid > 0) {
                        $classSectionIds[$cid] = $cid;
                    }
                }
            }
            $singleClassId = (int)($_POST['class_section_id'] ?? 0);
            if ($singleClassId > 0) {
                $classSectionIds[$singleClassId] = $singleClassId;
            }
            $classSectionIds = array_values($classSectionIds);
            $classSectionId = $classSectionIds[0] ?? null;
            $academicYearId = (int)($_POST['academic_year_id'] ?? 0) ?: null;
            $feeCategoryId  = (int)($_POST['fee_category_id'] ?? 0);
            $amount         = (float)($_POST['amount'] ?? 0);
            $startMonth     = (int)($_POST['start_month'] ?? 0);
            $endMonth       = (int)($_POST['end_month'] ?? 0);
            $description    = trim((string)($_POST['description'] ?? ''));

            // Bulk students
            $studentIds = [];
            $rawIds = $_POST['student_ids'] ?? [];
            if (!is_array($rawIds)) {
                $rawIds = [];
            }
            foreach ($rawIds as $sid) {
                $sid = (int)$sid;
                if ($sid > 0) {
                    $studentIds[$sid] = $sid;
                }
            }
            $singleStudent = (int)($_POST['student_id'] ?? 0);
            if ($singleStudent > 0) {
                $studentIds[$singleStudent] = $singleStudent;
            }

            if ($feeCategoryId <= 0) {
                $error = 'Fee category is required.';
            } elseif ($amount <= 0) {
                $error = 'Amount must be greater than zero.';
            } elseif ($scopeType === 'student' && empty($studentIds)) {
                $error = 'Select at least one student.';
            } elseif ($scopeType === 'class' && empty($classSectionIds)) {
                $error = 'Please select at least one class / section.';
            } else {
                if ($scopeType === 'student') {
                    $created = 0;
                    foreach ($studentIds as $sid) {
                        FeeAssignmentModel::create([
                            'fee_category_id'  => $feeCategoryId,
                            'academic_year_id' => $academicYearId,
                            'student_id'       => $sid,
                            'class_section_id' => null,
                            'amount'           => $amount,
                            'start_month'      => $startMonth,
                            'end_month'        => $endMonth,
                            'description'      => $description,
                        ]);
                        $created++;
                    }
                    $_SESSION['flash'] = [
                        'type' => 'success',
                        'message' => 'Fee assigned to ' . $created . ' student(s)',
                    ];
                } elseif ($scopeType === 'class') {
                    $created = 0;
                    foreach ($classSectionIds as $selectedClassSectionId) {
                        FeeAssignmentModel::create([
                            'fee_category_id'  => $feeCategoryId,
                            'academic_year_id' => $academicYearId,
                            'student_id'       => null,
                            'class_section_id' => $selectedClassSectionId,
                            'amount'           => $amount,
                            'start_month'      => $startMonth,
                            'end_month'        => $endMonth,
                            'description'      => $description,
                        ]);
                        $created++;
                    }
                    $_SESSION['flash'] = [
                        'type' => 'success',
                        'message' => 'Fee assigned to ' . $created . ' class/section(s)',
                    ];
                } else {
                    FeeAssignmentModel::create([
                        'fee_category_id'  => $feeCategoryId,
                        'academic_year_id' => $academicYearId,
                        'student_id'       => null,
                        'class_section_id' => null,
                        'amount'           => $amount,
                        'start_month'      => $startMonth,
                        'end_month'        => $endMonth,
                        'description'      => $description,
                    ]);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Global fee assigned'];
                }
                redirect_route('fees/assignments');
                return;
            }
        }

        $assignments   = FeeAssignmentModel::list('', 200, 0);
        $academicYears = Database::fetchAll(
            'SELECT id, academic_year_label FROM academic_years ORDER BY academic_year_label DESC'
        );

        // Students with class for multi-select filter
        $students = Database::fetchAll(
            'SELECT s.id, s.first_name, s.last_name, s.admission_no,
                    cs.id AS class_section_id,
                    CONCAT(c.name, \' — \', sec.name) AS class_label
             FROM students s
             LEFT JOIN student_class_assignments sca
               ON sca.id = (
                 SELECT sca2.id FROM student_class_assignments sca2
                 WHERE sca2.student_id = s.id
                 ORDER BY sca2.assigned_at DESC, sca2.id DESC
                 LIMIT 1
               )
             LEFT JOIN class_sections cs ON cs.id = sca.class_section_id
             LEFT JOIN classes c ON c.id = cs.class_id
             LEFT JOIN sections sec ON sec.id = cs.section_id
             ORDER BY c.name, sec.name, s.first_name
             LIMIT 2000'
        );

        // Classes in school order (Nursery ... 2nd Year), used by the fee grid and the form.
        $classSections = Database::fetchAll(
            'SELECT cs.id, c.name AS class_name, sec.name AS section_name
             FROM class_sections cs
             JOIN classes c ON c.id = cs.class_id
             JOIN sections sec ON sec.id = cs.section_id
             ORDER BY c.id, sec.name'
        );

        // Current class-wide / global fee per category: the newest assignment wins.
        $feeGrid = ['class' => [], 'global' => []];
        $gridRows = Database::fetchAll(
            'SELECT id, fee_category_id, class_section_id, amount
             FROM fee_assignments WHERE student_id IS NULL ORDER BY id ASC'
        );
        foreach ($gridRows as $gr) {
            $catId = (int)$gr['fee_category_id'];
            if (!empty($gr['class_section_id'])) {
                $feeGrid['class'][(int)$gr['class_section_id']][$catId] = (float)$gr['amount'];
            } else {
                $feeGrid['global'][$catId] = (float)$gr['amount'];
            }
        }

        require_once __DIR__ . '/../models/AcademicYearModel.php';
        $currentYearId = (int)(AcademicYearModel::currentId() ?? 0);

        $this->render('fees/assignments', [
            'title'         => 'Fee Assignments',
            'feeCategories' => $feeCategories,
            'classSections' => $classSections,
            'feeGrid'       => $feeGrid,
            'currentYearId' => $currentYearId,
            'students'      => $students,
            'assignments'   => $assignments,
            'academicYears' => $academicYears,
            'error'         => $error ?? null,
        ]);
    }

    public function assignmentDeleteAction(): void
    {
        require_once __DIR__ . '/../models/FeeAssignmentModel.php';

        Auth::requireLogin();
        $this->requirePermission(['fees.manage', 'fees.assignments']);
        $this->requireCsrf();

        $id = (int)($_POST['id'] ?? 0);

        if ($id > 0) {
            FeeAssignmentModel::delete($id);
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Fee assignment deleted'];
        }

        redirect_route('fees/assignments');
    }

    // =========================
    // NEW INVOICE GENERATION (TWO MODES)
    // =========================
    public function generateInvoicesAction(): void
    {
        require_once __DIR__ . '/../models/FeeCategoryModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../services/FeeService.php';

        Auth::requireLogin();
        $this->requirePermission(['fees.manage', 'fees.generate_invoices']);

        $mode = trim((string)($_GET['mode'] ?? $_POST['mode'] ?? 'student'));
        $quickSelectQ = trim((string)($_GET['q'] ?? ''));
        $feeCategories = FeeCategoryModel::list('', 200, 0);
        $classSections = ClassSectionModel::allOptions();
        $students      = StudentModel::list($quickSelectQ, null, 500, 0, 1);
        $academicYears = Database::fetchAll(
            'SELECT id, academic_year_label, start_date, end_date FROM academic_years ORDER BY academic_year_label DESC'
        );

        $createdInvoices = [];
        $error = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();

            $user = Auth::currentUser();
            $byUserId = (int)($user['id'] ?? 0);
            $postYear = (int)($_POST['academic_year_id'] ?? 0);
            $academicYearId = $postYear > 0 ? $postYear : null;

            try {
                if ($mode === 'class') {
                    // Class-wise mode: Generate for all students in class
                    $classSectionId = (int)($_POST['class_section_id'] ?? 0);
                    $selectedMonths = array_values(array_filter(array_map('intval', $_POST['selected_months'] ?? [])));
                    $includeAdmission = (int)($_POST['include_admission'] ?? 0);
                    $allowDuplicateAdmission = (int)($_POST['allow_duplicate_admission'] ?? 0);

                    if ($classSectionId <= 0) {
                        throw new RuntimeException('Please select a class');
                    }
                    if (empty($selectedMonths) && !$includeAdmission) {
                        throw new RuntimeException('Please select at least one month, or include admission fee');
                    }

                    $result = FeeService::createClassInvoices(
                        $classSectionId,
                        $selectedMonths,
                        $academicYearId,
                        (bool)$includeAdmission,
                        $byUserId,
                        (bool)$allowDuplicateAdmission
                    );

                    $createdInvoices = $result['invoice_ids'] ?? [];
                    $alreadyUpToDate = (int)($result['already_up_to_date'] ?? 0);
                    $realErrors = (int)($result['skipped'] ?? 0);
                    $partialSkips = $result['partial_skips'] ?? [];

                    if (empty($createdInvoices) && $alreadyUpToDate > 0 && $realErrors === 0) {
                        // Nothing new to bill — every student already has an invoice
                        // (open or paid) for the selected month(s)/fee(s).
                        $msg = 'No new invoices created — all ' . $alreadyUpToDate
                            . ' student(s) already have an invoice for the selected month(s)/fee(s).';
                    } else {
                        $msg = 'Created ' . count($createdInvoices) . ' invoice(s) for the class';
                        $extras = [];
                        if ($alreadyUpToDate > 0) {
                            $extras[] = $alreadyUpToDate . ' already up to date';
                        }
                        if ($realErrors > 0) {
                            $extras[] = $realErrors . ' failed';
                        }
                        if (!empty($extras)) {
                            $msg .= ' (' . implode(', ', $extras) . ')';
                        }
                        if (!empty($partialSkips)) {
                            $msg .= '. Some months were already invoiced and skipped for: '
                                . implode(' | ', array_slice($partialSkips, 0, 5))
                                . (count($partialSkips) > 5 ? ' …' : '');
                        }
                    }

                    $_SESSION['flash'] = [
                        'type' => count($createdInvoices) > 0 ? 'success' : 'info',
                        'message' => $msg
                    ];
                } else {
                    // Student-wise mode: Generate for single student
                    $studentId = (int)($_POST['student_id'] ?? 0);
                    $selectedMonths = array_values(array_filter(array_map('intval', $_POST['selected_months'] ?? [])));
                    $includeAdmission = (int)($_POST['include_admission'] ?? 0);
                    $allowDuplicateAdmission = (int)($_POST['allow_duplicate_admission'] ?? 0);

                    if ($studentId <= 0) {
                        throw new RuntimeException('Please select a student');
                    }
                    if (empty($selectedMonths) && !$includeAdmission) {
                        throw new RuntimeException('Please select at least one month, or include admission fee');
                    }

                    $result = FeeService::createStudentInvoice(
                        $studentId,
                        $academicYearId,
                        (bool)$includeAdmission,
                        $selectedMonths,
                        $byUserId,
                        (bool)$allowDuplicateAdmission
                    );

                    $createdInvoices = $result['invoice_ids'];
                    $msg = count($createdInvoices) > 1
                        ? count($createdInvoices) . ' invoices created successfully'
                        : 'Invoice created successfully';
                    if (!empty($result['skipped'])) {
                        $msg .= '. Already invoiced and skipped: ' . implode(', ', $result['skipped']);
                    }
                    $_SESSION['flash'] = ['type' => 'success', 'message' => $msg];
                }

                // Notify each affected student + their guardians. The wording
                // differs per invoice (amount, invoice number), so this loops
                // rather than using the one-shared-message bulk helper — invoice
                // counts here are class-sized (tens, not thousands), so the
                // extra queries are cheap.
                if (!empty($createdInvoices)) {
                    require_once __DIR__ . '/../models/NotificationModel.php';
                    $newInvoiceRows = Database::fetchAll(
                        'SELECT id, student_id, invoice_no, total_due FROM fee_invoices WHERE id IN ('
                            . implode(',', array_fill(0, count($createdInvoices), '?')) . ')',
                        str_repeat('i', count($createdInvoices)),
                        $createdInvoices
                    );
                    foreach ($newInvoiceRows as $inv) {
                        NotificationModel::notifyStudentAndGuardians(
                            (int)$inv['student_id'],
                            'fee_invoice',
                            'New fee invoice generated',
                            'Invoice #' . ($inv['invoice_no'] ?? $inv['id']) . ' for Rs ' . number_format((float)($inv['total_due'] ?? 0), 2) . ' has been generated.',
                            route_url('portal/invoiceView') . '&invoice_id=' . (int)$inv['id']
                        );
                    }
                }

                redirect('/index.php?route=' . rawurlencode('fees/invoices'));
                return;
            } catch (Throwable $e) {
                $error = $e->getMessage();
            }
        }

        // Form defaults: POST first (after failed submit), then GET (prefill / bookmark)
        $formAcademicYearId = (int)($_POST['academic_year_id'] ?? $_GET['academic_year_id'] ?? 0);
        if ($formAcademicYearId <= 0 && empty($_POST) && empty($_GET['academic_year_id'])) {
            require_once __DIR__ . '/../models/AcademicYearModel.php';
            $currentYearId = AcademicYearModel::currentId();
            if ($currentYearId) {
                $formAcademicYearId = $currentYearId;
            }
        }
        $selectedAcademicYearId = $formAcademicYearId;
        $summaryYearId = $formAcademicYearId > 0 ? $formAcademicYearId : null;

        // Get student fee data if in student mode (academic year filter for summary)
        $studentData = null;
        $studentId = (int)($_POST['student_id'] ?? $_GET['student_id'] ?? 0);
        $prefillClassSectionId = (int)($_POST['class_section_id'] ?? $_GET['class_section_id'] ?? 0);
        if ($studentId > 0 && $mode === 'student') {
            require_once __DIR__ . '/../services/FeeService.php';
            $student = StudentModel::getById($studentId);
            if ($student) {
                $studentData = [
                    'student' => $student,
                    'summary' => FeeService::getStudentFeeSummary($studentId, $summaryYearId),
                    'balance' => FeeService::getStudentBalance($studentId, $summaryYearId),
                ];
            }
        }

        // Classes in school order, active student counts, and which months each student
        // already has an open/paid invoice for (per academic year) - used by the form
        // to show "already invoiced" before anything is generated.
        $classSections = Database::fetchAll(
            'SELECT cs.id, c.name AS class_name, sec.name AS section_name
             FROM class_sections cs
             JOIN classes c ON c.id = cs.class_id
             JOIN sections sec ON sec.id = cs.section_id
             ORDER BY c.id, sec.name'
        );
        $classCounts = [];
        foreach (Database::fetchAll(
            'SELECT sca.class_section_id AS cid, COUNT(*) AS n
             FROM students s
             JOIN student_class_assignments sca ON sca.id = (
                 SELECT sca2.id FROM student_class_assignments sca2
                 WHERE sca2.student_id = s.id ORDER BY sca2.assigned_at DESC, sca2.id DESC LIMIT 1
             )
             WHERE IFNULL(s.status, 1) = 1
             GROUP BY sca.class_section_id'
        ) as $cr) {
            $classCounts[(int)$cr['cid']] = (int)$cr['n'];
        }
        $invoicedMap = [];
        foreach (Database::fetchAll(
            'SELECT DISTINCT fi.student_id, IFNULL(fi.academic_year_id, 0) AS ay, fil.billing_month AS m
             FROM fee_invoice_lines fil
             JOIN fee_invoices fi ON fi.id = fil.fee_invoice_id
             JOIN fee_categories fcat ON fcat.id = fil.fee_category_id AND COALESCE(fcat.is_one_time, 0) = 0
             WHERE fil.billing_month IS NOT NULL AND fi.status IN (\'open\', \'paid\')'
        ) as $ir) {
            $invoicedMap[(int)$ir['student_id']][] = (int)$ir['ay'] . '-' . (int)$ir['m'];
        }

        // One-time fee form: the fees (by label) that have an amount, and the months of the year
        require_once __DIR__ . '/../models/FeeAssignmentModel.php';
        require_once __DIR__ . '/../services/FeeService.php';
        $oneTimeYearId = !empty($selectedAcademicYearId) ? (int)$selectedAcademicYearId : null;

        $this->render('fees/generate_invoices', [
            'oneTimeFeeOptions'   => FeeAssignmentModel::listOneTimeFeeOptions($oneTimeYearId),
            'billingMonthOptions' => FeeService::billingMonthOptions($oneTimeYearId),
            'classCounts'    => $classCounts,
            'invoicedMap'    => $invoicedMap,
            'title'          => 'Generate Invoices',
            'mode'           => $mode,
            'feeCategories'  => $feeCategories,
            'classSections'  => $classSections,
            'students'       => $students,
            'academicYears'  => $academicYears,
            'studentData'    => $studentData,
            'createdInvoices' => $createdInvoices,
            'error'          => $error,
            'selectedAcademicYearId' => $selectedAcademicYearId,
            'prefillStudentId' => $studentId,
            'prefillClassSectionId' => $prefillClassSectionId,
            'quickSelectQ' => $quickSelectQ,
        ]);
    }

    /**
     * Apply a one-time fee (e.g. "Exam Fee") to every active student in a class.
     * Adds to each student's existing OPEN invoice when they have one, otherwise
     * creates a new invoice for them — see FeeService::applyOneTimeFeeToClass().
     */
    public function applyOneTimeFeeAction(): void
    {
        require_once __DIR__ . '/../services/FeeService.php';

        Auth::requireLogin();
        $this->requirePermission(['fees.manage', 'fees.apply_one_time_fee']);

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect_route('fees/generateInvoices');
            return;
        }
        $this->requireCsrf();

        $classSectionId = (int)($_POST['class_section_id'] ?? 0);
        $feeCategoryId = (int)($_POST['fee_category_id'] ?? 0);
        $postYear = (int)($_POST['academic_year_id'] ?? 0);
        $academicYearId = $postYear > 0 ? $postYear : null;
        $allowDuplicate = !empty($_POST['allow_duplicate']);
        // Which fee of the category (e.g. "First Term Exam Fee") and the month it is billed with (0 = none).
        $feeLabel = trim((string)preg_replace('/\s+/', ' ', (string)($_POST['fee_label'] ?? '')));
        $billingMonth = (int)($_POST['billing_month'] ?? 0);
        $billingMonth = ($billingMonth >= 1 && $billingMonth <= 12) ? $billingMonth : null;

        $user = Auth::currentUser();
        $byUserId = (int)($user['id'] ?? 0);

        try {
            if ($classSectionId <= 0) {
                throw new RuntimeException('Please select a class');
            }
            if ($feeCategoryId <= 0) {
                throw new RuntimeException('Please select a fee');
            }

            $result = FeeService::applyOneTimeFeeToClass($classSectionId, $feeCategoryId, $academicYearId, $byUserId, $allowDuplicate, $feeLabel, $billingMonth);

            $createdCount = count($result['created']);
            $appendedCount = count($result['appended']);
            $skippedCount = count($result['skipped']);
            $errorCount = count($result['errors']);

            if ($createdCount === 0 && $appendedCount === 0) {
                $msg = 'Nothing to apply — ';
                $msg .= $skippedCount > 0
                    ? $skippedCount . ' student(s) already had this fee, or had no matching fee assignment.'
                    : 'no students matched.';
                $type = 'info';
            } else {
                $parts = [];
                if ($createdCount > 0) {
                    $parts[] = $createdCount . ' new invoice(s) created';
                }
                if ($appendedCount > 0) {
                    $parts[] = 'added to ' . $appendedCount . ' existing open invoice(s)';
                }
                $msg = implode(', ', $parts) . '.';
                if ($skippedCount > 0) {
                    $msg .= ' ' . $skippedCount . ' student(s) skipped (already invoiced / no assignment).';
                }
                $type = 'success';
            }
            if ($errorCount > 0) {
                $msg .= ' ' . $errorCount . ' failed — check the activity log.';
                $type = $createdCount === 0 && $appendedCount === 0 ? 'danger' : 'warning';
            }

            $_SESSION['flash'] = ['type' => $type, 'message' => $msg];
            log_activity(
                'fees.apply_one_time_fee',
                'Applied fee category #' . $feeCategoryId . ($feeLabel !== '' ? ' "' . $feeLabel . '"' : '')
                . ($billingMonth !== null ? ' (month ' . $billingMonth . ')' : '')
                . ' to class section #' . $classSectionId
                . ' — created ' . $createdCount . ', appended ' . $appendedCount . ', skipped ' . $skippedCount
            );
        } catch (Throwable $e) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => $e->getMessage()];
        }

        redirect(
            '/index.php?route=' . rawurlencode('fees/generateInvoices')
            . '&mode=onetime&class_section_id=' . $classSectionId
            . ($academicYearId ? '&academic_year_id=' . $academicYearId : '')
        );
    }

    // =========================
    // INVOICES (UPDATED)
    // =========================
    private function fetchInvoicesListData(array $filters): array
    {
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/FeeInvoiceModel.php';

        $q = (string)($filters['q'] ?? '');
        $invoiceStatus = (string)($filters['invoice_status'] ?? '');
        $studentStatus = (string)($filters['student_status'] ?? '');
        $classSectionId = (int)($filters['class_section_id'] ?? 0);
        $perPage = (int)($filters['per_page'] ?? 20);
        $page = max(1, (int)($filters['page'] ?? 1));
        $offset = ($page - 1) * $perPage;

        $where = ['1=1'];
        $params = [];
        $types = '';

        if ($q !== '') {
            $like = '%' . $q . '%';
            $where[] = '(fi.invoice_no LIKE ?
                        OR CAST(fi.id AS CHAR) LIKE ?
                        OR s.admission_no LIKE ?
                        OR s.first_name LIKE ?
                        OR s.last_name LIKE ?
                        OR CONCAT(s.first_name, \' \', s.last_name) LIKE ?
                        OR CAST(s.id AS CHAR) LIKE ?
                        OR IFNULL(s.father_name, \'\') LIKE ?
                        OR IFNULL(s.cnic_no, \'\') LIKE ?)';
            for ($i = 0; $i < 9; $i++) {
                $params[] = $like;
                $types .= 's';
            }
        }

        if ($invoiceStatus !== '') {
            $where[] = 'fi.status = ?';
            $params[] = $invoiceStatus;
            $types .= 's';
        }

        if ($studentStatus === 'active') {
            $where[] = 'IFNULL(s.status, 1) = 1';
        } elseif ($studentStatus === 'left') {
            $where[] = 'IFNULL(s.status, 1) = 0';
        }

        $joinClass = '';
        if ($classSectionId > 0) {
            $joinClass = 'INNER JOIN student_class_assignments sca_cur
               ON sca_cur.id = (
                 SELECT sca2.id FROM student_class_assignments sca2
                 WHERE sca2.student_id = s.id
                 ORDER BY sca2.assigned_at DESC, sca2.id DESC
                 LIMIT 1
               )';
            $where[] = 'sca_cur.class_section_id = ?';
            $params[] = $classSectionId;
            $types .= 'i';
        }

        $whereSql = implode(' AND ', $where);

        $countRow = Database::fetchOne(
            "SELECT COUNT(*) AS cnt FROM (
                SELECT fi.student_id
                FROM fee_invoices fi
                JOIN students s ON s.id = fi.student_id
                $joinClass
                WHERE $whereSql
                GROUP BY fi.student_id
             ) student_rows",
            $types,
            $params
        );
        $total = (int)($countRow['cnt'] ?? 0);

        $listParams = $params;
        $listTypes = $types . 'ii';
        $listParams[] = $perPage;
        $listParams[] = $offset;

        $dirSql = (($filters['dir'] ?? 'asc') === 'desc') ? 'DESC' : 'ASC';
        $sortExprs = [
            'student' => "s.first_name $dirSql, s.last_name $dirSql",
            'class' => "MAX(cur_c.id) $dirSql, MAX(cur_sec.name) $dirSql",
            'months' => "first_billing $dirSql",
            'invoices' => "COUNT(fi.id) $dirSql",
            'total' => "total_due $dirSql",
            'collected' => "collected_amount $dirSql",
            'pending' => "(COALESCE(SUM(CASE WHEN fi.status = 'cancelled' THEN 0 ELSE fi.total_due END), 0)
                           - COALESCE(SUM(CASE WHEN fi.status = 'cancelled' THEN 0 ELSE (
                                SELECT SUM(fcx.amount) FROM fee_collections fcx WHERE fcx.fee_invoice_id = fi.id
                             ) END), 0)) $dirSql",
            'status' => "(CASE
                            WHEN SUM(CASE WHEN fi.status = 'open' AND fi.due_date IS NOT NULL AND fi.due_date < CURDATE() THEN 1 ELSE 0 END) > 0 THEN 0
                            WHEN SUM(CASE WHEN fi.status = 'open' THEN 1 ELSE 0 END) > 0 THEN 1
                            WHEN SUM(CASE WHEN fi.status = 'paid' THEN 1 ELSE 0 END) > 0 THEN 2
                            ELSE 3 END) $dirSql",
        ];
        $sortKey = (string)($filters['sort'] ?? '');
        $orderSql = isset($sortExprs[$sortKey])
            ? $sortExprs[$sortKey] . ', s.first_name, s.last_name, s.id'
            : 's.first_name, s.last_name, s.id';

        $invoices = Database::fetchAll(
            "SELECT s.id AS id,
                    s.id AS student_id,
                    s.first_name,
                    s.last_name,
                    s.admission_no,
                    s.status AS student_status,
                    s.cnic_no,
                    MAX(COALESCE(sca_roll.roll_number, NULLIF(s.roll_number, ''))) AS roll_number,
                    MAX(cur_c.name) AS current_class_name,
                    MAX(cur_sec.name) AS current_section_name,
                    COUNT(fi.id) AS invoice_count,
                    SUM(CASE WHEN fi.status = 'open' THEN 1 ELSE 0 END) AS open_count,
                    SUM(CASE WHEN fi.status = 'paid' THEN 1 ELSE 0 END) AS paid_count,
                    SUM(CASE WHEN fi.status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_count,
                    COALESCE(SUM(CASE WHEN fi.status = 'cancelled' THEN 0 ELSE fi.total_due END), 0) AS total_due,
                    COALESCE(SUM(CASE WHEN fi.status = 'cancelled' THEN 0 ELSE (
                        SELECT SUM(fc.amount) FROM fee_collections fc WHERE fc.fee_invoice_id = fi.id
                    ) END), 0) AS collected_amount,
                    SUM(CASE WHEN fi.status = 'open'
                              AND fi.due_date IS NOT NULL
                              AND fi.due_date < CURDATE() THEN 1 ELSE 0 END) AS overdue_count,
                    (
                        SELECT GROUP_CONCAT(DISTINCT CONCAT_WS('-', fil.billing_year, fil.billing_month)
                               ORDER BY fil.billing_year, fil.billing_month SEPARATOR ',')
                        FROM fee_invoices fi2
                        JOIN fee_invoice_lines fil ON fil.fee_invoice_id = fi2.id
                        WHERE fi2.student_id = s.id
                          AND fi2.status <> 'cancelled'
                          AND fil.billing_month IS NOT NULL
                    ) AS billing_months_raw,
                    (
                        SELECT MIN(fil.billing_year * 100 + fil.billing_month)
                        FROM fee_invoices fi2
                        JOIN fee_invoice_lines fil ON fil.fee_invoice_id = fi2.id
                        WHERE fi2.student_id = s.id
                          AND fi2.status <> 'cancelled'
                          AND fil.billing_month IS NOT NULL
                    ) AS first_billing
             FROM fee_invoices fi
             JOIN students s ON s.id = fi.student_id
             LEFT JOIN student_class_assignments sca_roll
               ON sca_roll.id = (
                 SELECT sca3.id FROM student_class_assignments sca3
                 WHERE sca3.student_id = s.id
                 ORDER BY sca3.assigned_at DESC, sca3.id DESC
                 LIMIT 1
               )
             LEFT JOIN class_sections cur_cs ON cur_cs.id = sca_roll.class_section_id
             LEFT JOIN classes cur_c ON cur_c.id = cur_cs.class_id
             LEFT JOIN sections cur_sec ON cur_sec.id = cur_cs.section_id
             $joinClass
             WHERE $whereSql
             GROUP BY s.id
             ORDER BY $orderSql
             LIMIT ? OFFSET ?",
            $listTypes,
            $listParams
        );

        foreach ($invoices as &$inv) {
            $inv['id'] = (int)($inv['student_id'] ?? $inv['id'] ?? 0);
            $inv['student_id'] = (int)($inv['student_id'] ?? $inv['id'] ?? 0);
            $inv['pending_balance'] = max(0, (float)$inv['total_due'] - (float)$inv['collected_amount']);
            $inv['is_overdue'] = (int)($inv['overdue_count'] ?? 0) > 0;
            $inv['class_display'] = trim(
                (string)($inv['current_class_name'] ?? '') . ' ' . (string)($inv['current_section_name'] ?? '')
            );
            $inv['billing_month_display'] = FeeInvoiceModel::formatBillingMonths($inv['billing_months_raw'] ?? null);
            $openCount = (int)($inv['open_count'] ?? 0);
            $paidCount = (int)($inv['paid_count'] ?? 0);
            if ($openCount > 0) {
                $inv['status'] = 'open';
            } elseif ($paidCount > 0) {
                $inv['status'] = 'paid';
            } else {
                $inv['status'] = 'cancelled';
            }
        }
        unset($inv);

        return ['invoices' => $invoices, 'total' => $total];
    }

    private function renderInvoicesListPartial(): string
    {
        $filters = $this->feesInvoicesListFilters();
        $data = $this->fetchInvoicesListData($filters);

        require_once __DIR__ . '/../models/ClassSectionModel.php';

        return $this->renderPartial('fees/_invoice_list', [
            'invoices' => $data['invoices'],
            'total' => $data['total'],
            'q' => $filters['q'],
            'invoiceStatus' => $filters['invoice_status'],
            'studentStatus' => $filters['student_status'],
            'classSectionId' => $filters['class_section_id'],
            'classSections' => ClassSectionModel::allOptions(),
            'page' => $filters['page'],
            'perPage' => $filters['per_page'],
            'listFilters' => $filters,
        ]);
    }

    public function invoicesAction(): void
    {
        require_once __DIR__ . '/../models/FeeInvoiceModel.php';
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../services/FeeService.php';

        Auth::requireLogin();
        $this->requirePermission(['fees.manage', 'fees.invoices']);

        StudentModel::ensureCnicColumn();

        try {
            FeeService::resyncUnpaidOpenInvoiceAmounts();
        } catch (Throwable $e) {
            // non-fatal — list still loads if a single invoice cannot be repaired
        }

        // Auto-close fully discounted / zero-balance invoices left as "Open"
        try {
            Database::execute(
                'UPDATE fee_invoices fi
                 SET fi.status = \'paid\'
                 WHERE fi.status = \'open\'
                   AND (
                     fi.total_due - COALESCE((
                       SELECT SUM(fc.amount) FROM fee_collections fc WHERE fc.fee_invoice_id = fi.id
                     ), 0)
                   ) <= 0.001'
            );
        } catch (Throwable $e) {
            // non-fatal
        }

        $q = trim((string)($_GET['q'] ?? ''));
        $invoiceStatus = trim((string)($_GET['invoice_status'] ?? ''));
        if (!in_array($invoiceStatus, ['', 'open', 'paid', 'cancelled'], true)) {
            $invoiceStatus = '';
        }
        $studentStatus = trim((string)($_GET['student_status'] ?? '')); // '', active, left
        if (!in_array($studentStatus, ['', 'active', 'left'], true)) {
            $studentStatus = '';
        }
        $classSectionId = (int)($_GET['class_section_id'] ?? 0);

        $page = max(1, (int)($_GET['page'] ?? 1));
        $allowedPerPage = [10, 20, 50, 100];
        $perPage = (int)($_GET['per_page'] ?? 20);
        if (!in_array($perPage, $allowedPerPage, true)) {
            $perPage = 20;
        }

        require_once __DIR__ . '/../models/ClassSectionModel.php';
        $classSections = ClassSectionModel::allOptions();

        $listFilters = [
            'q' => $q,
            'invoice_status' => $invoiceStatus,
            'student_status' => $studentStatus,
            'class_section_id' => $classSectionId,
            'per_page' => $perPage,
            'page' => $page,
            'sort' => in_array((string)($_GET['sort'] ?? ''), ['student', 'class', 'months', 'invoices', 'total', 'collected', 'pending', 'status'], true)
                ? (string)$_GET['sort'] : '',
            'dir' => (($_GET['dir'] ?? 'asc') === 'desc') ? 'desc' : 'asc',
        ];
        remember_list_filters('fees_invoices', $listFilters);

        $data = $this->fetchInvoicesListData($listFilters);

        $this->render('fees/invoices', [
            'title' => 'Fee Invoices',
            'invoices' => $data['invoices'],
            'q' => $q,
            'invoiceStatus' => $invoiceStatus,
            'studentStatus' => $studentStatus,
            'classSectionId' => $classSectionId,
            'classSections' => $classSections,
            'page' => $page,
            'perPage' => $perPage,
            'total' => $data['total'],
            'listFilters' => $listFilters,
        ]);
    }

    public function studentInvoicesAction(): void
    {
        require_once __DIR__ . '/../models/FeeInvoiceModel.php';
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../services/FeeService.php';

        Auth::requireLogin();
        if (!RBAC::hasPermission('fees.view') && !RBAC::hasPermission('fees.manage')) {
            $this->requirePermission('fees.view');
            return;
        }

        $studentId = (int)($_GET['student_id'] ?? 0);
        if ($studentId <= 0) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Student not specified'];
            $this->redirectToFeesInvoicesList();
            return;
        }

        $student = StudentModel::getById($studentId);
        if (!$student) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Student not found'];
            $this->redirectToFeesInvoicesList();
            return;
        }

        try {
            FeeService::resyncUnpaidOpenInvoiceAmounts($studentId);
        } catch (Throwable $e) {
            // non-fatal
        }

        $invoiceRows = FeeInvoiceModel::getStudentInvoices($studentId, null, 500, 0);
        $invoices = [];
        $allLines = [];
        $allCollections = [];
        foreach ($invoiceRows as $row) {
            $detail = FeeService::getInvoiceDetails((int)$row['id']);
            if (!$detail) {
                continue;
            }
            $invoices[] = $detail;
            foreach ($detail['lines'] ?? [] as $line) {
                $line['invoice_no'] = $detail['invoice_no'] ?? '';
                $line['invoice_id'] = (int)$detail['id'];
                $line['invoice_status'] = $detail['status'] ?? '';
                $allLines[] = $line;
            }
            foreach ($detail['collections'] ?? [] as $col) {
                $col['invoice_no'] = $detail['invoice_no'] ?? '';
                $allCollections[] = $col;
            }
        }

        usort($allLines, static function ($a, $b) {
            $ya = (int)($a['billing_year'] ?? 0);
            $yb = (int)($b['billing_year'] ?? 0);
            if ($ya !== $yb) {
                return $ya <=> $yb;
            }
            $ma = (int)($a['billing_month'] ?? 0);
            $mb = (int)($b['billing_month'] ?? 0);
            if ($ma !== $mb) {
                return $ma <=> $mb;
            }
            return ((int)($a['id'] ?? 0)) <=> ((int)($b['id'] ?? 0));
        });

        $summary = FeeService::getStudentFeeSummary($studentId);
        $pending = (float)($summary['total_due'] ?? 0) - (float)($summary['total_paid'] ?? 0);

        // Academic year names, so a long invoice list can be filtered by year.
        $yearLabels = [];
        foreach (Database::fetchAll('SELECT id, academic_year_label FROM academic_years') as $yr) {
            $yearLabels[(int)$yr['id']] = (string)$yr['academic_year_label'];
        }

        $this->render('fees/student_invoices', [
            'yearLabels' => $yearLabels,
            'title' => 'Invoices — ' . trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? '')),
            'student' => $student,
            'invoices' => $invoices,
            'allLines' => $allLines,
            'bulkOnBehalf' => $this->onBehalfContextForInvoice(['student_id' => $studentId]),
            'allCollections' => $allCollections,
            'summary' => $summary,
            'pending' => $pending,
            'listFilters' => $this->feesInvoicesListFilters(),
        ]);
    }

    /**
     * Invoices report CSV: one row per invoice — invoice #, student, father's name,
     * class, status, amounts, who generated it and when, plus who collected/marked
     * the payment and when (from the most recent fee_collections row for that
     * invoice, since an invoice can be paid in more than one installment).
     * Honors the same filters as the Fee Invoices list, but pulls every matching
     * invoice rather than just the current page.
     */
    public function invoicesExportCsvAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLoginOrToken();
        $this->requirePermission(['fees.manage', 'fees.invoices_export_csv']);

        StudentModel::ensureCnicColumn();

        $q = trim((string)($_GET['q'] ?? ''));
        $invoiceStatus = trim((string)($_GET['invoice_status'] ?? ''));
        if (!in_array($invoiceStatus, ['', 'open', 'paid', 'cancelled'], true)) {
            $invoiceStatus = '';
        }
        $studentStatus = trim((string)($_GET['student_status'] ?? ''));
        if (!in_array($studentStatus, ['', 'active', 'left'], true)) {
            $studentStatus = '';
        }
        $classSectionId = (int)($_GET['class_section_id'] ?? 0);

        // Same WHERE-building as fetchInvoicesListData() (see above), minus pagination.
        $where = ['1=1'];
        $params = [];
        $types = '';

        if ($q !== '') {
            $like = '%' . $q . '%';
            $where[] = '(fi.invoice_no LIKE ?
                        OR CAST(fi.id AS CHAR) LIKE ?
                        OR s.admission_no LIKE ?
                        OR s.first_name LIKE ?
                        OR s.last_name LIKE ?
                        OR CONCAT(s.first_name, \' \', s.last_name) LIKE ?
                        OR CAST(s.id AS CHAR) LIKE ?
                        OR IFNULL(s.father_name, \'\') LIKE ?
                        OR IFNULL(s.cnic_no, \'\') LIKE ?)';
            for ($i = 0; $i < 9; $i++) {
                $params[] = $like;
                $types .= 's';
            }
        }

        if ($invoiceStatus !== '') {
            $where[] = 'fi.status = ?';
            $params[] = $invoiceStatus;
            $types .= 's';
        }

        if ($studentStatus === 'active') {
            $where[] = 'IFNULL(s.status, 1) = 1';
        } elseif ($studentStatus === 'left') {
            $where[] = 'IFNULL(s.status, 1) = 0';
        }

        $joinClass = '';
        if ($classSectionId > 0) {
            $joinClass = 'INNER JOIN student_class_assignments sca_cur
               ON sca_cur.id = (
                 SELECT sca2.id FROM student_class_assignments sca2
                 WHERE sca2.student_id = s.id
                 ORDER BY sca2.assigned_at DESC, sca2.id DESC
                 LIMIT 1
               )';
            $where[] = 'sca_cur.class_section_id = ?';
            $params[] = $classSectionId;
            $types .= 'i';
        }

        $whereSql = implode(' AND ', $where);

        $invoices = Database::fetchAll(
            "SELECT fi.invoice_no, fi.issued_at, fi.due_date, fi.status,
                    fi.total_amount, fi.total_discount, fi.total_due, fi.fine_applied,
                    s.admission_no, s.first_name, s.last_name, s.father_name,
                    inv_c.name AS invoice_class_name, inv_sec.name AS invoice_section_name,
                    gen_u.username AS generated_by,
                    COALESCE((
                        SELECT SUM(fc.amount) FROM fee_collections fc WHERE fc.fee_invoice_id = fi.id
                    ), 0) AS collected_amount,
                    lc.collected_at AS last_collected_at,
                    lc.method AS last_payment_method,
                    col_u.username AS last_collected_by
             FROM fee_invoices fi
             JOIN students s ON s.id = fi.student_id
             LEFT JOIN class_sections inv_cs ON inv_cs.id = fi.class_section_id
             LEFT JOIN classes inv_c ON inv_c.id = inv_cs.class_id
             LEFT JOIN sections inv_sec ON inv_sec.id = inv_cs.section_id
             LEFT JOIN users gen_u ON gen_u.id = fi.created_by_user_id
             LEFT JOIN fee_collections lc ON lc.id = (
                 SELECT fc2.id FROM fee_collections fc2
                 WHERE fc2.fee_invoice_id = fi.id
                 ORDER BY fc2.collected_at DESC, fc2.id DESC
                 LIMIT 1
             )
             LEFT JOIN users col_u ON col_u.id = lc.collected_by_user_id
             $joinClass
             WHERE $whereSql
             ORDER BY fi.id DESC",
            $types,
            $params
        );

        log_activity('fees.invoices_export_csv', 'Exported invoices report to CSV (' . count($invoices) . ' rows)');

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="invoices_report_' . date('Y-m-d_His') . '.csv"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");

        fputcsv_safe($out, [
            'Invoice Number', 'Student Name', "Father's Name", 'Class', 'Status',
            'Total Amount', 'Discount', 'Fine', 'Total Due', 'Collected Amount', 'Pending Balance',
            'Generated On', 'Generated By', 'Due Date',
            'Payment Date', 'Marked Paid By', 'Payment Method',
        ]);

        foreach ($invoices as $inv) {
            $collected = (float)$inv['collected_amount'];
            $pending = (float)$inv['total_due'] - $collected;
            $classDisplay = trim(
                (string)($inv['invoice_class_name'] ?? '') . ' ' . (string)($inv['invoice_section_name'] ?? '')
            );

            fputcsv_safe($out, [
                $inv['invoice_no'],
                trim($inv['first_name'] . ' ' . $inv['last_name']),
                $inv['father_name'] ?? '',
                $classDisplay,
                ucfirst((string)$inv['status']),
                number_format((float)$inv['total_amount'], 2),
                number_format((float)$inv['total_discount'], 2),
                number_format((float)$inv['fine_applied'], 2),
                number_format((float)$inv['total_due'], 2),
                number_format($collected, 2),
                number_format($pending, 2),
                $inv['issued_at'],
                $inv['generated_by'] ?? '',
                $inv['due_date'] ?? '',
                $inv['last_collected_at'] ?? '',
                $inv['last_collected_by'] ?? '',
                $inv['last_payment_method'] ?? '',
            ]);
        }

        fclose($out);
        exit;
    }

    private function feesInvoicesListFilters(): array
    {
        $filters = recall_list_filters('fees_invoices', [
            'q' => '',
            'invoice_status' => '',
            'student_status' => '',
            'class_section_id' => 0,
            'per_page' => 20,
            'page' => 1,
            'sort' => '',
            'dir' => 'asc',
        ]);
        $filters['q'] = trim((string)($filters['q'] ?? ''));
        $filters['sort'] = in_array((string)($filters['sort'] ?? ''), ['student', 'class', 'months', 'invoices', 'total', 'collected', 'pending', 'status'], true)
            ? (string)$filters['sort'] : '';
        $filters['dir'] = (($filters['dir'] ?? 'asc') === 'desc') ? 'desc' : 'asc';
        $inv = trim((string)($filters['invoice_status'] ?? ''));
        $filters['invoice_status'] = in_array($inv, ['', 'open', 'paid', 'cancelled'], true) ? $inv : '';
        $st = trim((string)($filters['student_status'] ?? ''));
        $filters['student_status'] = in_array($st, ['', 'active', 'left'], true) ? $st : '';
        $filters['class_section_id'] = (int)($filters['class_section_id'] ?? 0);
        $allowed = [10, 20, 50, 100];
        $perPage = (int)($filters['per_page'] ?? 20);
        $filters['per_page'] = in_array($perPage, $allowed, true) ? $perPage : 20;
        $filters['page'] = max(1, (int)($filters['page'] ?? 1));
        return $filters;
    }

    private function redirectToFeesInvoicesList(): void
    {
        redirect_list('fees/invoices', $this->feesInvoicesListFilters());
    }

    // =========================
    // INVOICE EDIT
    // =========================
    public function invoiceEditAction(): void
    {
        $this->handleInvoiceEdit();
    }

    /** Alias for older links: fees/editInvoice */
    public function editInvoiceAction(): void
    {
        $this->handleInvoiceEdit();
    }

    private function handleInvoiceEdit(): void
    {
        require_once __DIR__ . '/../services/FeeService.php';

        Auth::requireLogin();
        $this->requirePermission(['fees.manage', 'fees.invoice_update']);

        $invoiceId = (int)($_GET['invoice_id'] ?? $_POST['invoice_id'] ?? 0);
        if ($invoiceId <= 0) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Invoice not specified'];
            $this->redirectToFeesInvoicesList();
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();

            $dueDate = trim((string)($_POST['due_date'] ?? ''));
            $status = trim((string)($_POST['status'] ?? 'open'));
            if (!in_array($status, ['open', 'paid', 'cancelled'], true)) {
                $status = 'open';
            }

            Database::execute(
                'UPDATE fee_invoices SET due_date = ?, status = ? WHERE id = ?',
                'ssi',
                [$dueDate !== '' ? $dueDate : null, $status, $invoiceId]
            );

            $lineIds = $_POST['line_id'] ?? [];
            $baseAmounts = $_POST['base_amount'] ?? [];
            $discountAmounts = $_POST['discount_amount'] ?? [];

            if (is_array($lineIds) && !empty($lineIds)) {
                foreach ($lineIds as $idx => $lineId) {
                    $lineId = (int)$lineId;
                    if ($lineId <= 0) {
                        continue;
                    }
                    $base = (float)($baseAmounts[$idx] ?? 0);
                    $discount = (float)($discountAmounts[$idx] ?? 0);
                    if ($discount < 0) {
                        $discount = 0;
                    }
                    if ($discount > $base) {
                        $discount = $base;
                    }
                    $lineTotal = round($base - $discount, 2);

                    Database::execute(
                        'UPDATE fee_invoice_lines
                         SET base_amount = ?, discount_amount = ?, line_total = ?
                         WHERE id = ? AND fee_invoice_id = ?',
                        'dddii',
                        [$base, $discount, $lineTotal, $lineId, $invoiceId]
                    );
                }

                FeeService::recalculateInvoiceTotals($invoiceId);
            }

            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Invoice updated'];
            $invNoRow = Database::fetchOne('SELECT invoice_no FROM fee_invoices WHERE id = ? LIMIT 1', 'i', [$invoiceId]);
            log_activity(
                'fees.invoice_update',
                'Edited fee invoice #' . ($invNoRow['invoice_no'] ?? $invoiceId) . ' (status: ' . $status . ')'
            );
            $this->redirectToFeesInvoicesList();
            return;
        }

        $invoice = FeeService::getInvoiceDetails($invoiceId);
        if (!$invoice) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Invoice not found'];
            $this->redirectToFeesInvoicesList();
            return;
        }

        $this->render('fees/invoice_edit', [
            'title'   => 'Edit Invoice',
            'invoice' => $invoice,
            'listFilters' => $this->feesInvoicesListFilters(),
        ]);
    }

    // =========================
    // INVOICE DELETE
    // =========================
    public function invoiceDeleteAction(): void
    {
        $this->handleInvoiceDelete();
    }

    /**
     * Bulk delete from the invoice list: removes every invoice of the selected
     * students that has NO payment recorded. Invoices with a payment are skipped.
     */
    public function invoiceBulkDeleteAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['fees.manage', 'fees.invoice_delete']);
        $this->requireCsrf();

        // From a student's own invoice page: delete the ticked invoices (those with no payment recorded).
        $pickedInvoiceIds = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['invoice_ids'] ?? [])))));
        if ($pickedInvoiceIds) {
            $in = implode(',', array_fill(0, count($pickedInvoiceIds), '?'));
            $deletable = Database::fetchAll(
                "SELECT fi.id FROM fee_invoices fi
                 WHERE fi.id IN ($in)
                   AND NOT EXISTS (SELECT 1 FROM fee_collections fc WHERE fc.fee_invoice_id = fi.id)",
                str_repeat('i', count($pickedInvoiceIds)),
                $pickedInvoiceIds
            );
            $deleted = 0;
            foreach ($deletable as $inv) {
                $invoiceId = (int)$inv['id'];
                try {
                    Database::execute('DELETE FROM fee_custom_fines WHERE fee_invoice_id = ?', 'i', [$invoiceId]);
                } catch (Throwable $e) { /* ignore if table missing */ }
                Database::execute('DELETE FROM fee_invoice_lines WHERE fee_invoice_id = ?', 'i', [$invoiceId]);
                Database::execute('DELETE FROM fee_invoices WHERE id = ?', 'i', [$invoiceId]);
                $deleted++;
            }
            $kept = count($pickedInvoiceIds) - $deleted;
            log_activity('fees.invoice_delete', 'Bulk deleted ' . $deleted . ' selected fee invoice(s)');
            $msg = 'Deleted ' . $deleted . ' invoice(s).';
            if ($kept > 0) {
                $msg .= ' ' . $kept . ' invoice(s) with payments were kept (delete those one by one if you really need to).';
            }
            $_SESSION['flash'] = ['type' => 'success', 'message' => $msg];
            $returnStudentId = (int)($_POST['return_student_id'] ?? 0);
            if ($returnStudentId > 0) {
                redirect('/index.php?route=' . rawurlencode('fees/studentInvoices') . '&student_id=' . $returnStudentId);
                return;
            }
            $this->redirectToFeesInvoicesList();
            return;
        }

        $studentIds = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['student_ids'] ?? [])))));
        if (!$studentIds) {
            $_SESSION['flash'] = ['type' => 'warning', 'message' => 'No students selected.'];
            $this->redirectToFeesInvoicesList();
            return;
        }

        $in = implode(',', array_fill(0, count($studentIds), '?'));
        $types = str_repeat('i', count($studentIds));
        $deletable = Database::fetchAll(
            "SELECT fi.id, fi.invoice_no FROM fee_invoices fi
             WHERE fi.student_id IN ($in)
               AND NOT EXISTS (SELECT 1 FROM fee_collections fc WHERE fc.fee_invoice_id = fi.id)",
            $types,
            $studentIds
        );
        $totalForStudents = Database::fetchOne(
            "SELECT COUNT(*) AS c FROM fee_invoices WHERE student_id IN ($in)",
            $types,
            $studentIds
        );

        $deleted = 0;
        foreach ($deletable as $inv) {
            $invoiceId = (int)$inv['id'];
            try {
                Database::execute('DELETE FROM fee_custom_fines WHERE fee_invoice_id = ?', 'i', [$invoiceId]);
            } catch (Throwable $e) { /* ignore if table missing */ }
            Database::execute('DELETE FROM fee_invoice_lines WHERE fee_invoice_id = ?', 'i', [$invoiceId]);
            Database::execute('DELETE FROM fee_invoices WHERE id = ?', 'i', [$invoiceId]);
            $deleted++;
        }
        $skipped = max(0, (int)($totalForStudents['c'] ?? 0) - $deleted);

        log_activity('fees.invoice_delete', 'Bulk deleted ' . $deleted . ' fee invoice(s) for ' . count($studentIds) . ' student(s)');
        $msg = 'Deleted ' . $deleted . ' invoice(s) for ' . count($studentIds) . ' student(s).';
        if ($skipped > 0) {
            $msg .= ' ' . $skipped . ' invoice(s) with payments were kept.';
        }
        $_SESSION['flash'] = ['type' => 'success', 'message' => $msg];
        $this->redirectToFeesInvoicesList();
    }

    /**
     * Collect the full remaining balance of several ticked invoices in one go
     * (student invoice page). One payment is recorded per invoice, with the same
     * method / note / "on behalf of" for all of them.
     */
    public function invoiceBulkCollectAction(): void
    {
        require_once __DIR__ . '/../services/FeeService.php';

        Auth::requireLogin();
        $this->requirePermission(['fees.manage', 'fees.collect']);
        $this->requireCsrf();

        $invoiceIds = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['invoice_ids'] ?? [])))));
        $returnStudentId = (int)($_POST['return_student_id'] ?? 0);
        $back = function () use ($returnStudentId): void {
            if ($returnStudentId > 0) {
                redirect('/index.php?route=' . rawurlencode('fees/studentInvoices') . '&student_id=' . $returnStudentId);
                return;
            }
            $this->redirectToFeesInvoicesList();
        };

        if (!$invoiceIds) {
            $_SESSION['flash'] = ['type' => 'warning', 'message' => 'No invoices selected.'];
            $back();
            return;
        }

        sort($invoiceIds);
        $collectedTotal = 0.0;
        $done = 0;
        $skipped = 0;
        $errors = [];
        foreach ($invoiceIds as $invoiceId) {
            $detail = FeeService::getInvoiceDetails($invoiceId);
            if (!$detail || ($detail['status'] ?? '') !== 'open') {
                $skipped++;
                continue;
            }
            $remaining = round(max(0, (float)($detail['total_due'] ?? 0) - (float)($detail['collected_amount'] ?? 0)), 2);
            if ($remaining <= 0.001) {
                $skipped++;
                continue;
            }
            // attributeAndRecordPayment() reads the amount / lines from $_POST.
            $_POST['amount'] = number_format($remaining, 2, '.', '');
            $_POST['line_ids'] = [];
            try {
                $this->attributeAndRecordPayment($invoiceId);
                $collectedTotal += $remaining;
                $done++;
            } catch (Throwable $e) {
                $errors[] = ($detail['invoice_no'] ?? $invoiceId) . ': ' . $e->getMessage();
                if (RBAC::roleName() === 'admin' && (int)($_POST['on_behalf_of_staff_id'] ?? 0) <= 0) {
                    break; // same reason would fail every invoice
                }
            }
        }

        if ($done > 0) {
            $msg = 'Collected Rs ' . number_format($collectedTotal, 2) . ' across ' . $done . ' invoice(s).';
            if ($skipped > 0) {
                $msg .= ' ' . $skipped . ' already paid / skipped.';
            }
            if ($errors) {
                $msg .= ' Problems: ' . implode(' | ', array_slice($errors, 0, 3));
            }
            $_SESSION['flash'] = ['type' => $errors ? 'warning' : 'success', 'message' => $msg];
        } else {
            $_SESSION['flash'] = [
                'type' => 'error',
                'message' => $errors ? implode(' | ', array_slice($errors, 0, 3)) : 'Nothing to collect — the selected invoices are already paid.',
            ];
        }
        $back();
    }

    /** Alias for older links: fees/deleteInvoice */
    public function deleteInvoiceAction(): void
    {
        $this->handleInvoiceDelete();
    }

    private function handleInvoiceDelete(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['fees.manage', 'fees.invoice_delete']);
        $this->requireCsrf();

        $invoiceId = (int)($_POST['invoice_id'] ?? $_GET['invoice_id'] ?? 0);
        if ($invoiceId > 0) {
            $invNoRow = Database::fetchOne('SELECT invoice_no FROM fee_invoices WHERE id = ? LIMIT 1', 'i', [$invoiceId]);
            try {
                Database::execute('DELETE FROM fee_collections WHERE fee_invoice_id = ?', 'i', [$invoiceId]);
            } catch (Throwable $e) { /* ignore if table missing */ }
            try {
                Database::execute('DELETE FROM fee_custom_fines WHERE fee_invoice_id = ?', 'i', [$invoiceId]);
            } catch (Throwable $e) { /* ignore */ }
            try {
                Database::execute('DELETE FROM fee_invoice_lines WHERE fee_invoice_id = ?', 'i', [$invoiceId]);
            } catch (Throwable $e) { /* ignore */ }
            Database::execute('DELETE FROM fee_invoices WHERE id = ?', 'i', [$invoiceId]);
            $message = 'Invoice deleted';
            log_activity('fees.invoice_delete', 'Deleted fee invoice #' . ($invNoRow['invoice_no'] ?? $invoiceId));
            if ($this->wantsJson()) {
                $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderInvoicesListPartial()]);
            }
            $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
        }

        $returnStudentId = (int)($_POST['return_student_id'] ?? $_GET['return_student_id'] ?? 0);
        if ($returnStudentId > 0) {
            redirect('/index.php?route=' . rawurlencode('fees/studentInvoices') . '&student_id=' . $returnStudentId);
            return;
        }

        $this->redirectToFeesInvoicesList();
    }

    /**
     * Delete a single collection (payment) row — e.g. a duplicate entry from
     * a double-submitted "Collect Payment" click — without touching the rest
     * of the invoice. Cleans up its per-line allocation rows too, then
     * re-syncs the invoice's paid/open status against what's left.
     */
    public function collectionDeleteAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['fees.manage', 'fees.collection_delete']);
        $this->requireCsrf();

        require_once __DIR__ . '/../services/FeeService.php';

        $collectionId = (int)($_POST['collection_id'] ?? 0);
        $invoiceId = (int)($_POST['invoice_id'] ?? 0);

        if ($collectionId > 0 && $invoiceId > 0) {
            // Scope the lookup to the invoice_id passed in, so a crafted
            // collection_id can't be used to delete a payment on an invoice
            // the request didn't actually come from.
            $row = Database::fetchOne(
                'SELECT id, amount, fee_invoice_id FROM fee_collections WHERE id = ? AND fee_invoice_id = ? LIMIT 1',
                'ii',
                [$collectionId, $invoiceId]
            );
            if ($row) {
                try {
                    Database::execute('DELETE FROM fee_collection_lines WHERE fee_collection_id = ?', 'i', [$collectionId]);
                } catch (Throwable $e) { /* ignore if table/rows missing */ }
                Database::execute('DELETE FROM fee_collections WHERE id = ?', 'i', [$collectionId]);

                FeeService::syncInvoicePaidStatus($invoiceId);

                $message = 'Payment of Rs ' . number_format((float)$row['amount'], 2) . ' removed';
                log_activity('fees.collection_delete', 'Deleted a Rs ' . number_format((float)$row['amount'], 2) . ' payment from invoice #' . $invoiceId);
                $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
            } else {
                $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Payment not found on this invoice'];
            }
        }

        redirect('/index.php?route=' . rawurlencode('fees/invoiceView') . '&invoice_id=' . $invoiceId);
    }

    // =========================
    // COLLECT (UPDATED WITH FINE HANDLING)
    // =========================
    /**
     * Shared payment-recording logic used by both the full Fee Collection
     * page (collectAction) and the "Collect Payment" popup (collectModalAction).
     * Handles Admin's "on behalf of" attribution, applies overdue fines,
     * records the payment, and fires the student/guardian notification.
     * Throws on any validation/business error -- caller decides how to
     * surface it (flash message + redirect, or JSON).
     *
     * @return array{amount: float, method: string, invoiceNo: string}
     */
    private function attributeAndRecordPayment(int $invoiceId): array
    {
        $amount = (float)($_POST['amount'] ?? 0);
        $notes = trim((string)($_POST['notes'] ?? ''));
        $method = trim((string)($_POST['method'] ?? 'cash'));
        $lineIds = $_POST['line_ids'] ?? [];
        if (!is_array($lineIds)) {
            $lineIds = [];
        }
        $user = Auth::currentUser();
        $actingUserId = (int)($user['id'] ?? 0);
        $byUserId = $actingUserId;
        $enteredByUserId = null;

        // Admin/office staff collecting at the counter aren't the ones
        // responsible for the class -- they must say which teacher/principal
        // this payment is attributed to, so it lands correctly in that
        // person's fee ledger instead of quietly vanishing from anyone's
        // balance. Teachers/Principals collecting for their own classes are
        // always attributed to themselves, same as before.
        if (RBAC::roleName() === 'admin') {
            $onBehalfStaffId = (int)($_POST['on_behalf_of_staff_id'] ?? 0);
            if ($onBehalfStaffId <= 0) {
                throw new RuntimeException('Please select which teacher/staff member you are collecting this payment on behalf of.');
            }
            $staffRow = Database::fetchOne('SELECT user_id, full_name FROM staff_profiles WHERE id = ? LIMIT 1', 'i', [$onBehalfStaffId]);
            $onBehalfUserId = $staffRow ? (int)($staffRow['user_id'] ?? 0) : 0;
            if ($onBehalfUserId <= 0) {
                throw new RuntimeException('Selected staff member is not linked to a login account and can\'t receive credit for this payment.');
            }
            $byUserId = $onBehalfUserId;
            $enteredByUserId = $actingUserId;
        }

        FeeService::applyAutomaticFineIfOverdue($invoiceId);
        FeeService::recordPayment($invoiceId, $amount, $method, $notes, $byUserId, $lineIds, $enteredByUserId);

        $invoiceRow = Database::fetchOne(
            'SELECT student_id, invoice_no FROM fee_invoices WHERE id = ? LIMIT 1',
            'i',
            [$invoiceId]
        );

        log_activity(
            'fees.collect',
            'Collected Rs ' . number_format($amount, 2) . ' via ' . $method
            . ' for invoice #' . ($invoiceRow['invoice_no'] ?? $invoiceId)
        );
        if ($invoiceRow) {
            require_once __DIR__ . '/../models/NotificationModel.php';
            NotificationModel::notifyStudentAndGuardians(
                (int)$invoiceRow['student_id'],
                'fee_payment',
                'Fee payment received',
                'Rs ' . number_format($amount, 2) . ' received via ' . $method . ' for invoice #' . ($invoiceRow['invoice_no'] ?? $invoiceId) . '. Thank you!',
                route_url('portal/invoiceView') . '&invoice_id=' . $invoiceId
            );
        }

        return [
            'amount' => $amount,
            'method' => $method,
            'invoiceNo' => (string)($invoiceRow['invoice_no'] ?? $invoiceId),
        ];
    }

    /** Staff options for the "on behalf of" picker, plus whether to show it at all, for a given invoice. */
    private function onBehalfContextForInvoice(?array $invoice): array
    {
        $show = RBAC::roleName() === 'admin' && $invoice;
        if (!$show) {
            return ['options' => [], 'defaultStaffId' => 0, 'show' => false];
        }

        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/StaffFeeClassModel.php';
        $classSectionId = StudentModel::getCurrentClassSectionId((int)($invoice['student_id'] ?? 0)) ?? 0;
        $options = StaffFeeClassModel::onBehalfOptionsForClassSection($classSectionId);
        $defaultStaffId = count($options) === 1 ? (int)$options[0]['staff_profile_id'] : 0;

        return ['options' => $options, 'defaultStaffId' => $defaultStaffId, 'show' => true];
    }

    public function collectAction(): void
    {
        require_once __DIR__ . '/../models/FeeInvoiceModel.php';
        require_once __DIR__ . '/../services/FeeService.php';
        require_once __DIR__ . '/../models/NotificationModel.php';

        Auth::requireLogin();
        $this->requirePermission(['fees.manage', 'fees.collect']);

        $invoiceId = (int)($_GET['invoice_id'] ?? ($_POST['invoice_id'] ?? 0));

        if ($invoiceId <= 0) {
            $first = Database::fetchOne('SELECT id FROM fee_invoices ORDER BY id DESC LIMIT 1');
            $invoiceId = $first ? (int)$first['id'] : 0;
        }

        $invoice = $invoiceId ? FeeService::getInvoiceDetails($invoiceId) : null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();

            $action = (string)($_POST['action'] ?? 'record_payment');

            if ($action === 'record_payment') {
                try {
                    $this->attributeAndRecordPayment($invoiceId);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Payment recorded successfully'];

                    redirect('/index.php?route=' . rawurlencode('fees/collect') . '&invoice_id=' . $invoiceId);
                    return;
                } catch (Throwable $e) {
                    $_SESSION['flash'] = ['type' => 'error', 'message' => $e->getMessage()];
                }
            } elseif ($action === 'mark_settled') {
                try {
                    FeeService::markSettledAsPaid($invoiceId);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Invoice marked as paid (nothing due)'];
                    $this->redirectToFeesInvoicesList();
                    return;
                } catch (Throwable $e) {
                    $_SESSION['flash'] = ['type' => 'error', 'message' => $e->getMessage()];
                }
            } elseif ($action === 'add_fine') {
                $fineType = trim((string)($_POST['fine_type'] ?? ''));
                $amount = (float)($_POST['fine_amount'] ?? 0);
                $notes = trim((string)($_POST['fine_notes'] ?? ''));
                $user = Auth::currentUser();
                $byUserId = (int)($user['id'] ?? 0);

                try {
                    if (!$fineType) {
                        throw new RuntimeException('Fine type is required');
                    }
                    if ($amount <= 0) {
                        throw new RuntimeException('Fine amount must be positive');
                    }

                    FeeService::addCustomFine($invoiceId, $fineType, $amount, $notes, $byUserId);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Fine added successfully'];
                    redirect('/index.php?route=' . rawurlencode('fees/collect') . '&invoice_id=' . $invoiceId);
                    return;
                } catch (Throwable $e) {
                    $_SESSION['flash'] = ['type' => 'error', 'message' => $e->getMessage()];
                }
            } elseif ($action === 'delete_payment') {
                $collectionId = (int)($_POST['collection_id'] ?? 0);

                try {
                    if ($collectionId <= 0) {
                        throw new RuntimeException('Invalid payment');
                    }
                    $affectedInvoiceId = FeeService::deletePayment($collectionId);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Payment removed and invoice updated'];
                    $affNoRow = Database::fetchOne('SELECT invoice_no FROM fee_invoices WHERE id = ? LIMIT 1', 'i', [$affectedInvoiceId]);
                    log_activity(
                        'fees.collect_undo',
                        'Removed payment #' . $collectionId . ' from invoice #' . ($affNoRow['invoice_no'] ?? $affectedInvoiceId)
                    );
                    redirect('/index.php?route=' . rawurlencode('fees/collect') . '&invoice_id=' . $affectedInvoiceId);
                    return;
                } catch (Throwable $e) {
                    $_SESSION['flash'] = ['type' => 'error', 'message' => $e->getMessage()];
                }
            }
        }

        $invoiceOptions = Database::fetchAll(
            'SELECT fi.id, fi.invoice_no, fi.total_due, fi.status,
                    s.first_name, s.last_name, s.admission_no
             FROM fee_invoices fi
             JOIN students s ON s.id = fi.student_id
             ORDER BY fi.id DESC
             LIMIT 50'
        );

        $onBehalf = $this->onBehalfContextForInvoice($invoice);

        $this->render('fees/collect', [
            'title'                  => 'Fee Collection',
            'invoiceOptions'         => $invoiceOptions,
            'invoiceId'              => $invoiceId,
            'invoice'                => $invoice,
            'listFilters'            => $this->feesInvoicesListFilters(),
            'onBehalfOptions'        => $onBehalf['options'],
            'onBehalfDefaultStaffId' => $onBehalf['defaultStaffId'],
            'showOnBehalfPicker'     => $onBehalf['show'],
        ]);
    }

    /**
     * "Collect Payment" as a popup: an AJAX endpoint used from the Invoice
     * list/detail pages so collecting a payment doesn't navigate away.
     * GET returns the form as an HTML fragment (for the modal body); POST
     * records the payment and returns JSON. Only handles the collection
     * itself -- fines, delete-payment, mark-settled etc. stay on the full
     * fees/collect page.
     */
    public function collectModalAction(): void
    {
        require_once __DIR__ . '/../services/FeeService.php';

        Auth::requireLogin();
        $this->requirePermission(['fees.manage', 'fees.collect']);

        $invoiceId = (int)($_GET['invoice_id'] ?? ($_POST['invoice_id'] ?? 0));

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                $this->requireCsrf();
                $result = $this->attributeAndRecordPayment($invoiceId);
                $this->jsonResponse([
                    'success' => true,
                    'message' => 'Rs ' . number_format($result['amount'], 2) . ' recorded for invoice #' . $result['invoiceNo'] . '.',
                ]);
            } catch (Throwable $e) {
                $this->jsonResponse(['success' => false, 'message' => $e->getMessage()], 422);
            }
            return;
        }

        $invoice = $invoiceId ? FeeService::getInvoiceDetails($invoiceId) : null;
        if (!$invoice) {
            http_response_code(404);
            echo '<div class="alert alert-danger mb-0">Invoice not found.</div>';
            return;
        }

        $onBehalf = $this->onBehalfContextForInvoice($invoice);

        echo $this->renderPartial('fees/_collect_modal', [
            'invoice'                => $invoice,
            'invoiceId'              => $invoiceId,
            'onBehalfOptions'        => $onBehalf['options'],
            'onBehalfDefaultStaffId' => $onBehalf['defaultStaffId'],
            'showOnBehalfPicker'     => $onBehalf['show'],
        ]);
    }

    // =========================
    // INVOICE VIEW (detail page)
    // =========================
    public function invoiceViewAction(): void
    {
        $this->showInvoiceView();
    }

    /** Alias: fees/view -> same as invoiceView (fixes 404 from older View links) */
    public function viewAction(): void
    {
        $this->showInvoiceView();
    }

    private function showInvoiceView(): void
    {
        require_once __DIR__ . '/../services/FeeService.php';

        Auth::requireLogin();
        if (!RBAC::hasPermission('fees.view') && !RBAC::hasPermission('fees.manage')) {
            $this->requirePermission('fees.view');
            return;
        }

        $invoiceId = (int)($_GET['invoice_id'] ?? 0);
        if ($invoiceId <= 0) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Invoice not specified'];
            $this->redirectToFeesInvoicesList();
            return;
        }

        $invoice = FeeService::getInvoiceDetails($invoiceId);
        if (!$invoice) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Invoice not found'];
            $this->redirectToFeesInvoicesList();
            return;
        }

        // "Send via WhatsApp" support: a share link that opens this one
        // invoice with no login (for the parent), plus a choice of numbers
        // to pre-fill on the sending staff member's own WhatsApp — the
        // student's own phone and every guardian (father, mother, ...)
        // linked to them. Computed here (not in the view) since the view
        // has no DB access of its own and student_id/phone aren't part of
        // getInvoiceDetails().
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/GuardianModel.php';
        $studentId = (int)($invoice['student_id'] ?? 0);
        $student = StudentModel::getById($studentId);
        $guardians = GuardianModel::listByStudent($studentId);
        $shareToken = ShareToken::generate('fee_invoice', $invoiceId);
        $shareUrl = base_url('/index.php?' . http_build_query(['route' => 'share/feeVoucher', 't' => $shareToken]));
        $studentName = trim(($invoice['first_name'] ?? '') . ' ' . ($invoice['last_name'] ?? ''));
        $waMessage = "Fee voucher for {$studentName}"
            . (!empty($invoice['due_date']) ? " (due {$invoice['due_date']})" : '')
            . ": {$shareUrl}";
        $whatsappRecipients = whatsapp_share_recipients($student ?? [], $guardians, $waMessage);

        $this->render('fees/invoice_view', [
            'title'   => 'Invoice ' . ($invoice['invoice_no'] ?? ''),
            'invoice' => $invoice,
            'listFilters' => $this->feesInvoicesListFilters(),
            'whatsappRecipients' => $whatsappRecipients,
        ]);
    }

    // =========================
    // INVOICE PRINT (ENHANCED)
    // =========================
    public function invoicePrintAction(): void
    {
        require_once __DIR__ . '/../models/FeeInvoiceModel.php';
        require_once __DIR__ . '/../services/FeeService.php';

        Auth::requireLogin();
        if (!RBAC::hasPermission('fees.view') && !RBAC::hasPermission('fees.manage')) {
            $this->requirePermission('fees.view');
            return;
        }

        $invoiceId = (int)($_GET['invoice_id'] ?? 0);

        if ($invoiceId <= 0) {
            http_response_code(404);
            echo 'Missing invoice_id';
            return;
        }

        $invoice = FeeService::getInvoiceDetails($invoiceId);

        if (!$invoice) {
            http_response_code(404);
            echo 'Invoice not found';
            return;
        }

        // invoice_print.php is a complete standalone HTML document (its own
        // <!doctype html>/<head>/<body>) meant to be printed on its own — not
        // wrapped in the app shell's navbar/sidebar/dark theme, which is what
        // was causing the header to show up in print/PDF output. Output it
        // directly instead of going through render()/renderBare(), either of
        // which would nest it inside another full HTML document.
        echo $this->renderPartial('fees/invoice_print', [
            'title'   => 'Invoice',
            'invoice' => $invoice,
        ]);
    }

    // =========================
    // TEACHER FEE-COLLECTION LEDGER (collected vs. handed over)
    // =========================

    /**
     * Admin/Principal view: every teacher/principal who has collected fees or
     * submitted a handover, with Collected / Handed Over / Net Balance, plus
     * the queue of pending handovers awaiting confirmation.
     */
    public function teacherLedgerAction(): void
    {
        require_once __DIR__ . '/../models/FeeHandoverModel.php';
        require_once __DIR__ . '/../models/StaffFeeClassModel.php';

        Auth::requireLogin();
        $this->requirePermission('fees.handover_confirm');

        $academicYears = Database::fetchAll('SELECT id, academic_year_label FROM academic_years ORDER BY id DESC');

        $academicYearId = (int)($_GET['academic_year_id'] ?? 0);
        // No explicit choice made yet (first visit) — default to "All years"
        // rather than guessing a year, so collections are never hidden behind
        // a filter the user didn't pick.
        // academic_year_id=0 in the URL means the user explicitly chose "All years".

        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 20;

        $ledgerPaged = FeeHandoverModel::ledgerForAllStaff($academicYearId ?: null, $page, $perPage);

        $this->render('fees/teacher_ledger', [
            'title' => 'Teacher Fee Collections',
            'ledgerRows' => $ledgerPaged['rows'],
            'ledgerPage' => $page,
            'ledgerTotalPages' => (int)ceil($ledgerPaged['total'] / $perPage),
            'pending' => FeeHandoverModel::getPending(),
            'collectionSummaries' => StaffFeeClassModel::collectionSummaryForAllStaff($academicYearId ?: null),
            // School-wide progress tiles: a class assigned to two staff members must be
            // counted once, so this is computed over the DISTINCT assigned class sections
            // rather than by adding up each staff member's own summary.
            'overallSummary' => StaffFeeClassModel::collectionSummaryForClassSections(
                array_map('intval', array_column(Database::fetchAll('SELECT DISTINCT class_section_id FROM staff_fee_classes'), 'class_section_id')),
                $academicYearId ?: null
            ),
            'academicYears' => $academicYears,
            'academicYearId' => $academicYearId,
        ]);
    }

    /** Drill-down for one staff member: their full collection + handover history. */
    public function teacherLedgerDetailAction(): void
    {
        require_once __DIR__ . '/../models/FeeHandoverModel.php';
        require_once __DIR__ . '/../models/StaffFeeClassModel.php';

        Auth::requireLogin();
        $this->requirePermission('fees.handover_confirm');

        $staffId = (int)($_GET['staff_profile_id'] ?? 0);
        $staff = $staffId ? Database::fetchOne('SELECT id, full_name, title FROM staff_profiles WHERE id = ? LIMIT 1', 'i', [$staffId]) : null;

        if (!$staff) {
            http_response_code(404);
            echo 'Staff member not found';
            return;
        }

        $ledger = FeeHandoverModel::ledgerForStaff($staffId);
        $handovers = FeeHandoverModel::getForStaff($staffId);
        $collectionSummary = StaffFeeClassModel::collectionSummaryForStaff($staffId);

        $collections = [];
        $collectionsTotal = 0;
        $collectionsPage = max(1, (int)($_GET['cpage'] ?? 1));
        $collectionsPerPage = 50;
        $collectionsTotalPages = 1;
        if (!empty($staff['id'])) {
            $userRow = Database::fetchOne('SELECT user_id FROM staff_profiles WHERE id = ? LIMIT 1', 'i', [$staffId]);
            $userId = (int)($userRow['user_id'] ?? 0);
            if ($userId > 0) {
                $countRow = Database::fetchOne(
                    'SELECT COUNT(*) AS total FROM fee_collections WHERE collected_by_user_id = ?',
                    'i',
                    [$userId]
                );
                $collectionsTotal = (int)($countRow['total'] ?? 0);
                $collectionsTotalPages = max(1, (int)ceil($collectionsTotal / $collectionsPerPage));
                if ($collectionsPage > $collectionsTotalPages) {
                    $collectionsPage = $collectionsTotalPages;
                }
                $collectionsOffset = ($collectionsPage - 1) * $collectionsPerPage;

                $collections = Database::fetchAll(
                    'SELECT fc.*, fi.invoice_no, s.first_name, s.last_name
                     FROM fee_collections fc
                     JOIN fee_invoices fi ON fi.id = fc.fee_invoice_id
                     JOIN students s ON s.id = fi.student_id
                     WHERE fc.collected_by_user_id = ?
                     ORDER BY fc.collected_at DESC
                     LIMIT ? OFFSET ?',
                    'iii',
                    [$userId, $collectionsPerPage, $collectionsOffset]
                );
            }
        }

        $this->render('fees/teacher_ledger_detail', [
            'title' => 'Ledger — ' . ($staff['full_name'] ?? ''),
            'staff' => $staff,
            'ledger' => $ledger,
            'handovers' => $handovers,
            'collections' => $collections,
            'collectionsTotal' => $collectionsTotal,
            'collectionsPage' => $collectionsPage,
            'collectionsPerPage' => $collectionsPerPage,
            'collectionsTotalPages' => $collectionsTotalPages,
            'collectionSummary' => $collectionSummary,
        ]);
    }

    /** Admin/Principal confirms a pending handover -- this is the only thing that credits it to "handed over". */
    public function handoverConfirmAction(): void
    {
        require_once __DIR__ . '/../models/FeeHandoverModel.php';
        require_once __DIR__ . '/../models/NotificationModel.php';

        Auth::requireLogin();
        $this->requirePermission('fees.handover_confirm');
        $this->requireCsrf();

        $id = (int)($_POST['handover_id'] ?? 0);
        $handover = $id ? FeeHandoverModel::find($id) : null;
        $user = Auth::currentUser();

        if ($handover && $handover['status'] === 'pending') {
            FeeHandoverModel::confirm($id, (int)($user['id'] ?? 0));
            log_activity('fees.handover_confirm', 'Confirmed fee handover #' . $id . ' (Rs ' . number_format((float)$handover['amount'], 2) . ')');

            $staff = Database::fetchOne('SELECT user_id FROM staff_profiles WHERE id = ? LIMIT 1', 'i', [(int)$handover['staff_profile_id']]);
            if ($staff && !empty($staff['user_id'])) {
                NotificationModel::create(
                    (int)$staff['user_id'],
                    'fee_handover',
                    'Fee handover confirmed',
                    'Your handover of Rs ' . number_format((float)$handover['amount'], 2) . ' was confirmed received.',
                    route_url('portal/myFeeLedger')
                );
            }
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Handover confirmed'];
        } else {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'That handover is no longer pending.'];
        }

        redirect_route('fees/teacherLedger');
    }

    /** Admin/Principal rejects a pending handover -- e.g. wrong amount, cash never actually arrived. */
    public function handoverRejectAction(): void
    {
        require_once __DIR__ . '/../models/FeeHandoverModel.php';
        require_once __DIR__ . '/../models/NotificationModel.php';

        Auth::requireLogin();
        $this->requirePermission('fees.handover_confirm');
        $this->requireCsrf();

        $id = (int)($_POST['handover_id'] ?? 0);
        $reason = trim((string)($_POST['reason'] ?? ''));
        $handover = $id ? FeeHandoverModel::find($id) : null;
        $user = Auth::currentUser();

        if ($handover && $handover['status'] === 'pending') {
            FeeHandoverModel::reject($id, (int)($user['id'] ?? 0), $reason !== '' ? $reason : null);
            log_activity('fees.handover_reject', 'Rejected fee handover #' . $id);

            $staff = Database::fetchOne('SELECT user_id FROM staff_profiles WHERE id = ? LIMIT 1', 'i', [(int)$handover['staff_profile_id']]);
            if ($staff && !empty($staff['user_id'])) {
                NotificationModel::create(
                    (int)$staff['user_id'],
                    'fee_handover',
                    'Fee handover rejected',
                    'Your handover of Rs ' . number_format((float)$handover['amount'], 2) . ' was rejected.' . ($reason !== '' ? ' Reason: ' . $reason : ' Please re-check the amount and resubmit.'),
                    route_url('portal/myFeeLedger')
                );
            }
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Handover rejected'];
        } else {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'That handover is no longer pending.'];
        }

        redirect_route('fees/teacherLedger');
    }

    /**
     * Admin-only: correct a handover record's amount/note after the fact (e.g. a
     * teacher or the admin mistyped the figure). Works regardless of status --
     * pending, confirmed, or rejected -- since every ledger total is computed live
     * from this table, a correction here immediately fixes what everyone sees.
     */
    public function handoverUpdateAction(): void
    {
        require_once __DIR__ . '/../models/FeeHandoverModel.php';
        require_once __DIR__ . '/../models/NotificationModel.php';

        Auth::requireLogin();
        $this->requirePermission('fees.handover_manage');
        $this->requireCsrf();

        $id = (int)($_POST['handover_id'] ?? 0);
        $amount = (float)($_POST['amount'] ?? 0);
        $note = trim((string)($_POST['note'] ?? ''));
        $handover = $id ? FeeHandoverModel::find($id) : null;

        if (!$handover) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Handover not found.'];
            redirect_route('fees/teacherLedger');
            return;
        }

        if ($amount <= 0) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Amount must be greater than zero.'];
            redirect('/index.php?route=' . rawurlencode('fees/teacherLedgerDetail') . '&staff_profile_id=' . (int)$handover['staff_profile_id']);
            return;
        }

        $oldAmount = (float)$handover['amount'];
        FeeHandoverModel::update($id, $amount, $note !== '' ? $note : null);
        log_activity('fees.handover_manage', 'Edited fee handover #' . $id . ' (Rs ' . number_format($oldAmount, 2) . ' -> Rs ' . number_format($amount, 2) . ')');

        $staff = Database::fetchOne('SELECT user_id FROM staff_profiles WHERE id = ? LIMIT 1', 'i', [(int)$handover['staff_profile_id']]);
        if ($staff && !empty($staff['user_id'])) {
            NotificationModel::create(
                (int)$staff['user_id'],
                'fee_handover',
                'Fee handover corrected',
                'Admin corrected your handover from Rs ' . number_format($oldAmount, 2) . ' to Rs ' . number_format($amount, 2) . '.',
                route_url('portal/myFeeLedger')
            );
        }

        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Handover updated'];
        redirect('/index.php?route=' . rawurlencode('fees/teacherLedgerDetail') . '&staff_profile_id=' . (int)$handover['staff_profile_id']);
    }

    /** Admin-only: permanently remove a handover record entered in error. */
    public function handoverDeleteAction(): void
    {
        require_once __DIR__ . '/../models/FeeHandoverModel.php';
        require_once __DIR__ . '/../models/NotificationModel.php';

        Auth::requireLogin();
        $this->requirePermission('fees.handover_manage');
        $this->requireCsrf();

        $id = (int)($_POST['handover_id'] ?? 0);
        $handover = $id ? FeeHandoverModel::find($id) : null;

        if (!$handover) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Handover not found.'];
            redirect_route('fees/teacherLedger');
            return;
        }

        $staffProfileId = (int)$handover['staff_profile_id'];
        FeeHandoverModel::delete($id);
        log_activity('fees.handover_manage', 'Deleted fee handover #' . $id . ' (Rs ' . number_format((float)$handover['amount'], 2) . ')');

        $staff = Database::fetchOne('SELECT user_id FROM staff_profiles WHERE id = ? LIMIT 1', 'i', [$staffProfileId]);
        if ($staff && !empty($staff['user_id'])) {
            NotificationModel::create(
                (int)$staff['user_id'],
                'fee_handover',
                'Fee handover removed',
                'Admin removed a handover record of Rs ' . number_format((float)$handover['amount'], 2) . ' from your ledger.',
                route_url('portal/myFeeLedger')
            );
        }

        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Handover deleted'];
        redirect('/index.php?route=' . rawurlencode('fees/teacherLedgerDetail') . '&staff_profile_id=' . $staffProfileId);
    }

    // =========================
    // PENDING DUES (ENHANCED)
    // =========================
    public function pendingDuesAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../services/FeeService.php';

        Auth::requireLogin();
        $this->requirePermission('fees.view');

        $q = trim((string)($_GET['q'] ?? ''));
        $like = '%' . $q . '%';

        $countRow = Database::fetchOne(
            'SELECT COUNT(*) AS total FROM (
                 SELECT pdv.student_id, SUM(pdv.pending_amount) AS pending_amount
                 FROM pending_dues_view pdv
                 JOIN students s ON s.id = pdv.student_id
                 WHERE (? = \'\' OR s.admission_no LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ?
                        OR CONCAT(s.first_name, \' \', s.last_name) LIKE ?)
                 GROUP BY pdv.student_id
                 HAVING pending_amount > 0
             ) t',
            'sssss',
            [$q, $like, $like, $like, $like]
        );
        $total = (int)($countRow['total'] ?? 0);

        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 50;
        $totalPages = max(1, (int)ceil($total / $perPage));
        if ($page > $totalPages) {
            $page = $totalPages;
        }
        $offset = ($page - 1) * $perPage;

        $rows = Database::fetchAll(
            'SELECT pdv.student_id,
                    s.admission_no,
                    s.first_name,
                    s.last_name,
                    SUM(pdv.pending_amount) AS pending_amount,
                    COUNT(DISTINCT fi.id) AS invoice_count
             FROM pending_dues_view pdv
             JOIN students s ON s.id = pdv.student_id
             LEFT JOIN fee_invoices fi ON fi.student_id = pdv.student_id AND fi.status = \'open\'
             WHERE (? = \'\' OR s.admission_no LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ?
                    OR CONCAT(s.first_name, \' \', s.last_name) LIKE ?)
             GROUP BY pdv.student_id
             HAVING pending_amount > 0
             ORDER BY pending_amount DESC
             LIMIT ? OFFSET ?',
            'sssssii',
            [$q, $like, $like, $like, $like, $perPage, $offset]
        );

        $this->render('fees/pending_dues', [
            'title' => 'Pending Dues',
            'rows'  => $rows,
            'q' => $q,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'totalPages' => $totalPages,
        ]);
    }

    /**
     * Manual "Send Reminders Now" page. Lists every open, unpaid, past-due
     * invoice, paginated, with a checkbox per row so staff pick exactly who
     * gets texted; POST queues a warning SMS (no fine) to the student +
     * every linked guardian for each selected invoice not already reminded
     * today.
     */
    public function overdueRemindersAction(): void
    {
        require_once __DIR__ . '/../services/FeeService.php';

        $user = Auth::requireLogin();
        // Admin-only — not shown to Accountant/other staff even though they
        // may hold fees.manage, per explicit instruction (see app/config/menu.php).
        RBAC::requireAdmin();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();

            $rawIds = $_POST['invoice_ids'] ?? [];
            if (!is_array($rawIds)) {
                $rawIds = [];
            }
            $invoiceIds = array_values(array_unique(array_filter(array_map('intval', $rawIds))));

            if (empty($invoiceIds)) {
                $_SESSION['flash'] = ['type' => 'info', 'message' => 'Select at least one invoice to send a reminder.'];
                redirect_route('fees/overdueReminders');
                return;
            }

            $result = FeeService::sendOverdueFeeReminders($invoiceIds, (int)($user['id'] ?? 0) ?: null);

            if ($result['invoices_reminded'] > 0) {
                $message = "Reminders queued for {$result['invoices_reminded']} invoice(s), "
                    . "{$result['messages_queued']} SMS message(s) in total.";
                if ($result['invoices_skipped_already_sent'] > 0) {
                    $message .= " {$result['invoices_skipped_already_sent']} already reminded today, skipped.";
                }
                if ($result['invoices_skipped_no_phone'] > 0) {
                    $message .= " {$result['invoices_skipped_no_phone']} skipped (no phone on file).";
                }
                $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
            } else {
                $_SESSION['flash'] = ['type' => 'info', 'message' => 'Nothing sent — the selected invoice(s) were already reminded today, or have no phone on file.'];
            }

            redirect_route('fees/overdueReminders');
            return;
        }

        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 25;
        $offset = ($page - 1) * $perPage;

        $total = FeeService::countOverdueUnpaidInvoices();
        $totalPages = max(1, (int)ceil($total / $perPage));
        if ($page > $totalPages) {
            $page = $totalPages;
            $offset = ($page - 1) * $perPage;
        }

        $invoices = FeeService::getOverdueUnpaidInvoices($perPage, $offset);
        $smsEnabledRow = Database::fetchOne("SELECT `value` FROM settings WHERE `key` = 'sms_enabled'");
        $smsEnabled = (string)($smsEnabledRow['value'] ?? '0') === '1';

        $this->render('fees/overdue_reminders', [
            'title' => 'Overdue Fee Reminders',
            'invoices' => $invoices,
            'smsEnabled' => $smsEnabled,
            'page' => $page,
            'perPage' => $perPage,
            'total' => $total,
            'totalPages' => $totalPages,
        ]);
    }

    // =========================
    // SETTINGS (ENHANCED WITH FINE MANAGEMENT)
    // =========================
    public function feeSettingsAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['fees.manage', 'fees.settings']);

        $error = null;
        $success = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'discount_create') {
                $name = trim((string)($_POST['name'] ?? ''));
                if (!$name) {
                    $error = 'Discount name is required';
                } else {
                    $scopeType      = (string)($_POST['scope_type'] ?? 'global');
                    $discountId     = (int)($_POST['discount_id'] ?? 0);
                    $isPercent      = (int)($_POST['is_percent'] ?? 1);
                    $amount         = (float)($_POST['amount'] ?? 0);
                    $startDate      = trim((string)($_POST['start_date'] ?? '')) ?: null;
                    $endDate        = trim((string)($_POST['end_date'] ?? '')) ?: null;
                    $description    = trim((string)($_POST['description'] ?? ''));

                    $bulkStudentIds = [];
                    if ($scopeType === 'student' && $discountId <= 0) {
                        $rawIds = $_POST['scope_student_ids'] ?? [];
                        if (!is_array($rawIds)) {
                            $rawIds = [];
                        }
                        foreach ($rawIds as $sid) {
                            $sid = (int)$sid;
                            if ($sid > 0) {
                                $bulkStudentIds[$sid] = $sid;
                            }
                        }
                        $single = (int)($_POST['scope_student_id'] ?? 0);
                        if ($single > 0) {
                            $bulkStudentIds[$single] = $single;
                        }
                    }

                    if ($discountId > 0) {
                        $scopeStudentId = $scopeType === 'student' ? ((int)($_POST['scope_student_id'] ?? 0) ?: null) : null;
                        $scopeClassId   = $scopeType === 'class'   ? ((int)($_POST['scope_class_section_id'] ?? 0) ?: null) : null;
                        Database::execute(
                            'UPDATE fee_discount_rules
                             SET name = ?, is_percent = ?, amount = ?, start_date = ?, end_date = ?,
                                 description = ?, student_id = ?, class_section_id = ?
                             WHERE id = ?',
                            'sidsssiii',
                            [
                                $name,
                                $isPercent,
                                $amount,
                                $startDate,
                                $endDate,
                                $description,
                                $scopeStudentId,
                                $scopeClassId,
                                $discountId,
                            ]
                        );
                        $success = 'Discount rule updated';
                    } elseif ($scopeType === 'student' && !empty($bulkStudentIds)) {
                        $created = 0;
                        foreach ($bulkStudentIds as $sid) {
                            $st = Database::fetchOne(
                                'SELECT admission_no, first_name, last_name FROM students WHERE id = ?',
                                'i',
                                [$sid]
                            );
                            $label = $st
                                ? trim(($st['first_name'] ?? '') . ' ' . ($st['last_name'] ?? '')) . ' (' . ($st['admission_no'] ?? $sid) . ')'
                                : ('Student #' . $sid);
                            $ruleName = $name . ' — ' . $label;

                            Database::execute(
                                'INSERT INTO fee_discount_rules (name, is_percent, amount, start_date, end_date, description, student_id, class_section_id)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, NULL)',
                                'sidsssi',
                                [
                                    $ruleName,
                                    $isPercent,
                                    $amount,
                                    $startDate,
                                    $endDate,
                                    $description !== '' ? $description : $name,
                                    $sid,
                                ]
                            );
                            $created++;
                        }
                        $success = 'Applied ' . $amount . ($isPercent ? '%' : ' Rs') . ' discount to ' . $created . ' student(s)';
                    } else {
                        $scopeStudentId = $scopeType === 'student' ? ((int)($_POST['scope_student_id'] ?? 0) ?: null) : null;
                        $scopeClassId   = $scopeType === 'class'   ? ((int)($_POST['scope_class_section_id'] ?? 0) ?: null) : null;

                        if ($scopeType === 'student' && !$scopeStudentId) {
                            $error = 'Select at least one student for this discount.';
                        } else {
                            Database::execute(
                                'INSERT INTO fee_discount_rules (name, is_percent, amount, start_date, end_date, description, student_id, class_section_id)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                                'sidsssii',
                                [
                                    $name,
                                    $isPercent,
                                    $amount,
                                    $startDate,
                                    $endDate,
                                    $description,
                                    $scopeStudentId,
                                    $scopeClassId,
                                ]
                            );
                            $success = 'Discount rule saved';
                        }
                    }

                    if (empty($error) && !empty($success)) {
                        $_SESSION['flash'] = ['type' => 'success', 'message' => $success];
                        redirect_route('fees/feeSettings');
                        return;
                    }
                }
            }

            if ($action === 'fine_create') {
                $fineName = trim((string)($_POST['fine_name'] ?? ''));
                $fineId = (int)($_POST['fine_id'] ?? 0);
                if (!$fineName) {
                    $error = 'Fine rule name is required';
                } else {
                    if ($fineId > 0) {
                        Database::execute(
                            'UPDATE fee_fine_rules SET name = ?, daily_fine_amount = ?, description = ? WHERE id = ?',
                            'sdsi',
                            [
                                $fineName,
                                (float)($_POST['daily_fine_amount'] ?? 0),
                                trim((string)($_POST['fine_description'] ?? '')),
                                $fineId,
                            ]
                        );
                        $success = 'Fine rule updated';
                    } else {
                        Database::execute(
                            'INSERT INTO fee_fine_rules (name, daily_fine_amount, description)
                             VALUES (?, ?, ?)',
                            'sds',
                            [
                                $fineName,
                                (float)($_POST['daily_fine_amount'] ?? 0),
                                trim((string)($_POST['fine_description'] ?? '')),
                            ]
                        );
                        $success = 'Fine rule saved';
                    }
                    $_SESSION['flash'] = ['type' => 'success', 'message' => $success];
                    redirect_route('fees/feeSettings');
                    return;
                }
            }

            if ($action === 'discount_delete') {
                $discountId = (int)($_POST['discount_id'] ?? 0);
                if ($discountId > 0) {
                    Database::execute('DELETE FROM fee_discount_rules WHERE id = ?', 'i', [$discountId]);
                    $success = 'Discount rule deleted';
                    $_SESSION['flash'] = ['type' => 'success', 'message' => $success];
                    redirect_route('fees/feeSettings');
                    return;
                }
            }

            if ($action === 'fine_delete') {
                $fineId = (int)($_POST['fine_id'] ?? 0);
                if ($fineId > 0) {
                    Database::execute('DELETE FROM fee_fine_rules WHERE id = ?', 'i', [$fineId]);
                    $success = 'Fine rule deleted';
                    $_SESSION['flash'] = ['type' => 'success', 'message' => $success];
                    redirect_route('fees/feeSettings');
                    return;
                }
            }
        }

        $discountRules = Database::fetchAll(
            'SELECT dr.*,
                    CONCAT(s.first_name, \' \', s.last_name) AS student_name,
                    CONCAT(cl.name, \' - \', sec.name) AS class_section_name
             FROM fee_discount_rules dr
             LEFT JOIN students s ON s.id = dr.student_id
             LEFT JOIN class_sections cs ON cs.id = dr.class_section_id
             LEFT JOIN classes cl ON cl.id = cs.class_id
             LEFT JOIN sections sec ON sec.id = cs.section_id
             ORDER BY dr.id DESC
             LIMIT 200'
        );
        $fineRules = Database::fetchAll(
            'SELECT * FROM fee_fine_rules ORDER BY id DESC LIMIT 50'
        );

        $editDiscountId = (int)($_GET['edit_discount'] ?? 0);
        $editFineId = (int)($_GET['edit_fine'] ?? 0);
        $discountToEdit = null;
        $fineToEdit = null;
        if ($editDiscountId > 0) {
            foreach ($discountRules as $d) {
                if ((int)$d['id'] === $editDiscountId) {
                    $discountToEdit = $d;
                    break;
                }
            }
        }
        if ($editFineId > 0) {
            foreach ($fineRules as $f) {
                if ((int)$f['id'] === $editFineId) {
                    $fineToEdit = $f;
                    break;
                }
            }
        }

        $feeSettingsStudents = Database::fetchAll(
            'SELECT s.id, s.first_name, s.last_name, s.admission_no,
                    cs.id AS class_section_id,
                    CONCAT(c.name, \' — \', sec.name) AS class_label
             FROM students s
             LEFT JOIN student_class_assignments sca
               ON sca.id = (
                 SELECT sca2.id FROM student_class_assignments sca2
                 WHERE sca2.student_id = s.id
                 ORDER BY sca2.assigned_at DESC, sca2.id DESC
                 LIMIT 1
               )
             LEFT JOIN class_sections cs ON cs.id = sca.class_section_id
             LEFT JOIN classes c ON c.id = cs.class_id
             LEFT JOIN sections sec ON sec.id = cs.section_id
             ORDER BY c.name, sec.name, s.first_name
             LIMIT 2000'
        );
        $feeSettingsClasses = Database::fetchAll(
            'SELECT cs.id, c.name AS class_name, sec.name AS section_name
             FROM class_sections cs
             JOIN classes c ON c.id = cs.class_id
             JOIN sections sec ON sec.id = cs.section_id
             ORDER BY c.name, sec.name'
        );

        $this->render('fees/fee_settings', [
            'title'              => 'Fee Settings',
            'discountRules'      => $discountRules,
            'fineRules'          => $fineRules,
            'feeSettingsStudents'=> $feeSettingsStudents,
            'feeSettingsClasses' => $feeSettingsClasses,
            'discountToEdit'     => $discountToEdit,
            'fineToEdit'         => $fineToEdit,
            'error'              => $error,
            'success'            => $success,
        ]);
    }

    // =========================
    // BULK EXPORTS (invoices ZIP + results-style workbook + CSV)
    // =========================

    /** Academic years that have at least one invoice, plus a synthetic "Unassigned" bucket (id 0) if any invoices have no academic_year_id. */
    private function academicYearsWithInvoices(): array
    {
        $years = Database::fetchAll(
            "SELECT DISTINCT ay.id, ay.academic_year_label
             FROM fee_invoices fi
             JOIN academic_years ay ON ay.id = fi.academic_year_id
             ORDER BY ay.start_date DESC, ay.academic_year_label DESC"
        );

        $hasUnassigned = Database::fetchOne(
            'SELECT id FROM fee_invoices WHERE academic_year_id IS NULL LIMIT 1'
        );
        if ($hasUnassigned) {
            $years[] = ['id' => 0, 'academic_year_label' => 'Unassigned / No Academic Year'];
        }

        return $years;
    }

    private function monthLabelForInvoice(array $invoiceLines): string
    {
        $months = [
            1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
            5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
            9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December',
        ];

        $pairs = [];
        foreach ($invoiceLines as $line) {
            $m = (int)($line['billing_month'] ?? 0);
            $y = (int)($line['billing_year'] ?? 0);
            if ($m >= 1 && $m <= 12) {
                $pairs[$m . '-' . $y] = ($months[$m] ?? ('Month ' . $m)) . ($y > 0 ? ' ' . $y : '');
            }
        }

        if (empty($pairs)) {
            return 'One-Time - Other Fees';
        }
        if (count($pairs) === 1) {
            return reset($pairs);
        }
        return 'Multiple Months';
    }

    /** Picker page for the bulk fee-invoice exports below (invoices ZIP, results-style workbook, CSV). */
    public function bulkExportsAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['fees.manage', 'fees.bulk_exports']);

        $this->render('fees/bulk_exports', [
            'title' => 'Bulk Exports',
            'academicYears' => $this->academicYearsWithInvoices(),
        ]);
    }

    /** Validates and returns [academicYearIds, statuses] from the submitted checkbox lists. */
    private function bulkInvoiceExportFilters(): array
    {
        $availableYears = array_map(static fn($r) => (int)$r['id'], $this->academicYearsWithInvoices());

        $requestedYears = $_GET['academic_year_ids'] ?? [];
        if (!is_array($requestedYears)) {
            $requestedYears = [$requestedYears];
        }
        $requestedYears = array_map('intval', $requestedYears);
        $academicYearIds = array_values(array_intersect($availableYears, $requestedYears));

        $requestedStatuses = $_GET['statuses'] ?? [];
        if (!is_array($requestedStatuses)) {
            $requestedStatuses = [$requestedStatuses];
        }
        $statuses = array_values(array_intersect(['open', 'paid', 'cancelled'], $requestedStatuses));
        if (empty($statuses)) {
            $statuses = ['open', 'paid', 'cancelled']; // default: all statuses
        }

        return [$academicYearIds, $statuses];
    }

    /** Fetches every invoice (with student + class info) matching the selected academic years and statuses. */
    private function fetchInvoicesForBulkExport(array $academicYearIds, array $statuses): array
    {
        require_once __DIR__ . '/../models/StudentModel.php';

        if (empty($academicYearIds) || empty($statuses)) {
            return [];
        }

        $yearConditions = [];
        $params = [];
        $types = '';
        $hasUnassigned = in_array(0, $academicYearIds, true);
        $namedYears = array_values(array_filter($academicYearIds, static fn($id) => $id > 0));

        if (!empty($namedYears)) {
            $yearConditions[] = 'fi.academic_year_id IN (' . implode(',', array_fill(0, count($namedYears), '?')) . ')';
            $types .= str_repeat('i', count($namedYears));
            $params = array_merge($params, $namedYears);
        }
        if ($hasUnassigned) {
            $yearConditions[] = 'fi.academic_year_id IS NULL';
        }
        $yearSql = '(' . implode(' OR ', $yearConditions) . ')';

        $statusSql = 'fi.status IN (' . implode(',', array_fill(0, count($statuses), '?')) . ')';
        $types .= str_repeat('s', count($statuses));
        $params = array_merge($params, $statuses);

        $rows = Database::fetchAll(
            "SELECT fi.id
             FROM fee_invoices fi
             WHERE $yearSql AND $statusSql
             ORDER BY fi.academic_year_id, fi.issued_at",
            $types,
            $params
        );

        require_once __DIR__ . '/../services/FeeService.php';

        $invoices = [];
        foreach ($rows as $r) {
            $details = FeeService::getInvoiceDetails((int)$r['id']);
            if ($details) {
                $invoices[] = $details;
            }
        }
        return $invoices;
    }

    /**
     * Downloads a ZIP of every matching invoice, organised as
     * All Academic Years / Academic Year / Month / Class - Section / Student (Admission No) / Invoice - {invoice_no}.html
     */
    public function bulkInvoicesDownloadAction(): void
    {
        // See the matching comment on bulkInvoicesXlsDownloadAction() — catches any
        // stray warning/notice text before it can corrupt the ZIP bytes; drained and
        // discarded just below, right before headers are sent.
        ob_start();

        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLoginOrToken();
        $this->requirePermission(['fees.manage', 'fees.bulk_exports']);

        [$academicYearIds, $statuses] = $this->bulkInvoiceExportFilters();
        if (empty($academicYearIds)) {
            http_response_code(400);
            echo 'No academic year selected, or the selection is invalid.';
            return;
        }

        if (!class_exists('ZipArchive')) {
            http_response_code(500);
            echo 'The PHP zip extension is not enabled on this server, so a ZIP file cannot be built. Ask your host to enable ext-zip.';
            return;
        }

        $invoices = $this->fetchInvoicesForBulkExport($academicYearIds, $statuses);
        if (empty($invoices)) {
            http_response_code(404);
            echo 'No invoices found for the selected academic year(s)/status(es).';
            return;
        }

        $tmpZip = tempnam(sys_get_temp_dir(), 'akps_invoices_');
        $zip = new ZipArchive();
        $zip->open($tmpZip, ZipArchive::OVERWRITE);

        $studentCache = [];

        // Everything sits under one "All Academic Years" root folder — same idea as the
        // "All Exams" wrapper used for the report-card export below, so a multi-year
        // download and a single-year download always look the same shape inside the ZIP.
        $rootFolder = 'All Academic Years';

        foreach ($invoices as $invoice) {
            $studentId = (int)$invoice['student_id'];
            if (!isset($studentCache[$studentId])) {
                $studentCache[$studentId] = StudentModel::getById($studentId);
            }
            $student = $studentCache[$studentId];
            if (!$student) {
                continue;
            }

            $yearFolder = safe_filename($invoice['academic_year_label'] ?? 'Unassigned - No Academic Year');
            $monthFolder = safe_filename($this->monthLabelForInvoice($invoice['lines'] ?? []));
            $classFolder = safe_filename(
                trim(($student['current_class_name'] ?? '') . ' - ' . ($student['current_section_name'] ?? ''))
                ?: 'No Class Assigned'
            );
            $studentFolder = safe_filename(
                trim(($invoice['first_name'] ?? '') . ' ' . ($invoice['last_name'] ?? ''))
                . ' (' . ($invoice['admission_no'] ?: $studentId) . ')'
            );

            $html = $this->renderPartial('fees/invoice_print', ['invoice' => $invoice]);

            $path = $rootFolder . '/' . $yearFolder . '/' . $monthFolder . '/' . $classFolder . '/' . $studentFolder
                . '/Invoice - ' . safe_filename((string)($invoice['invoice_no'] ?? $invoice['id'])) . '.html';
            $zip->addFromString($path, $html);
        }

        $zip->close();

        $filename = count($academicYearIds) === 1
            ? safe_filename('Fee Invoices - ' . ($this->academicYearLabelForId($academicYearIds[0]))) . '.zip'
            : safe_filename('Fee Invoices - ' . count($academicYearIds) . ' Academic Years') . '.zip';

        // Drain/discard the buffer opened at the top of this action (see its comment)
        // and disable gzip re-encoding — same defensive steps as streamDownloadFile()
        // in AcademicController, applied here since this action builds its own
        // response instead of going through that shared helper.
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        if (function_exists('apache_setenv')) {
            @apache_setenv('no-gzip', '1');
        }
        @ini_set('zlib.output_compression', '0');

        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($tmpZip));
        header('Content-Encoding: identity');
        header('X-Content-Type-Options: nosniff');
        readfile($tmpZip);
        unlink($tmpZip);
        exit;
    }

    private function academicYearLabelForId(int $id): string
    {
        if ($id === 0) {
            return 'Unassigned';
        }
        foreach ($this->academicYearsWithInvoices() as $y) {
            if ((int)$y['id'] === $id) {
                return (string)$y['academic_year_label'];
            }
        }
        return 'Academic Year ' . $id;
    }

    /**
     * Downloads one real .xlsx workbook (raw OOXML via ZipArchive, no
     * Composer/PhpSpreadsheet needed — see XlsxWorkbookWriter) for the selected
     * academic year(s)/status(es): a Summary sheet (totals + a class breakdown
     * per academic year / month), plus one full-detail sheet per academic year / month.
     *
     * Previously this returned an "Excel 2003 XML" / SpreadsheetML string saved with
     * a .xls extension — desktop Excel opens that leniently, but it isn't a real
     * binary/zip spreadsheet file, and strict mobile document viewers (including the
     * ones bundled into WebView-wrapped Android apps) correctly flag the mismatch as
     * "corrupted". XlsxWorkbookWriter builds an actual OOXML zip archive instead, same
     * as AcademicController::buildResultsWorkbook() already does for Results exports.
     */
    public function bulkInvoicesXlsDownloadAction(): void
    {
        // Capture the whole request in one output buffer from the very first line —
        // XlsxWorkbookWriter::download() below drains and discards any buffer right
        // before it sends headers, so this guarantees a stray PHP notice/warning
        // fired anywhere during data-gathering gets swallowed instead of being echoed
        // straight to the client ahead of the real .xlsx bytes, which is exactly what
        // turns a perfectly good file into "appears to be corrupted" on a strict
        // mobile viewer.
        ob_start();

        Auth::requireLoginOrToken();
        $this->requirePermission(['fees.manage', 'fees.bulk_exports']);

        [$academicYearIds, $statuses] = $this->bulkInvoiceExportFilters();
        if (empty($academicYearIds)) {
            http_response_code(400);
            echo 'No academic year selected, or the selection is invalid.';
            return;
        }

        $invoices = $this->fetchInvoicesForBulkExport($academicYearIds, $statuses);
        $workbook = $this->buildInvoicesWorkbook($invoices);

        $filename = count($academicYearIds) === 1
            ? safe_filename('Fee Invoices - ' . ($this->academicYearLabelForId($academicYearIds[0]))) . '.xlsx'
            : safe_filename('Fee Invoices - ' . count($academicYearIds) . ' Academic Years') . '.xlsx';

        $workbook->download($filename);
    }

    /** Same settings lookup as AcademicController::schoolBranding() — kept local since the two controllers don't share a base helper for it. */
    private function schoolBranding(): array
    {
        $name = 'ARC School';
        $logo = '';
        try {
            $rows = Database::fetchAll('SELECT `key`, `value` FROM settings');
            $map = [];
            foreach ($rows as $r) {
                $map[$r['key']] = $r['value'];
            }
            $name = $map['branding_school_name'] ?? $map['institute_name'] ?? 'ARC School';
            $logo = $map['branding_logo_path'] ?? '';
        } catch (Throwable $e) {
            // Keep the defaults if settings can't be read.
        }
        return [$name, $logo];
    }

    /**
     * Downloads one flat CSV for the selected academic year(s)/status(es) — one row per
     * invoice, with Academic Year / Month / Class - Section / Student as leading columns
     * so the same "Academic Year → Month → Class → Student" grouping used by the ZIP and
     * the Excel workbook can be recreated by sorting or filtering the CSV in any
     * spreadsheet tool.
     */
    public function bulkInvoicesCsvDownloadAction(): void
    {
        // See the matching comment on bulkInvoicesXlsDownloadAction() — catches any
        // stray warning/notice text before it can land in row 1 of the CSV; drained
        // and discarded just below, right before headers are sent.
        ob_start();

        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLoginOrToken();
        $this->requirePermission(['fees.manage', 'fees.bulk_exports']);

        [$academicYearIds, $statuses] = $this->bulkInvoiceExportFilters();
        if (empty($academicYearIds)) {
            http_response_code(400);
            echo 'No academic year selected, or the selection is invalid.';
            return;
        }

        $invoices = $this->fetchInvoicesForBulkExport($academicYearIds, $statuses);

        $filename = count($academicYearIds) === 1
            ? safe_filename('Fee Invoices - ' . ($this->academicYearLabelForId($academicYearIds[0]))) . '.csv'
            : safe_filename('Fee Invoices - ' . count($academicYearIds) . ' Academic Years') . '.csv';

        // Drain/discard the buffer opened at the top of this action (see its comment)
        // before sending headers — same defensive step as the ZIP/Excel exports above.
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        $out = fopen('php://output', 'w');
        // UTF-8 BOM so Excel opens accented / non-Latin names correctly.
        fwrite($out, "\xEF\xBB\xBF");

        fputcsv_safe($out, [
            'Academic Year', 'Month', 'Class', 'Section', 'Student', 'Admission No',
            'Invoice No', 'Status', 'Issued', 'Due Date',
            'Total Due', 'Discount', 'Collected', 'Pending Balance',
        ]);

        $studentCache = [];
        // Sort the same way the ZIP/XLS group things, so rows for one
        // Academic Year / Month / Class sit together in the file.
        usort($invoices, static function ($a, $b) {
            return strcmp((string)($a['academic_year_label'] ?? ''), (string)($b['academic_year_label'] ?? ''));
        });

        foreach ($invoices as $invoice) {
            $studentId = (int)$invoice['student_id'];
            if (!isset($studentCache[$studentId])) {
                $studentCache[$studentId] = StudentModel::getById($studentId);
            }
            $student = $studentCache[$studentId];

            fputcsv_safe($out, [
                $invoice['academic_year_label'] ?? 'Unassigned / No Academic Year',
                $this->monthLabelForInvoice($invoice['lines'] ?? []),
                $student['current_class_name'] ?? '',
                $student['current_section_name'] ?? '',
                trim(($invoice['first_name'] ?? '') . ' ' . ($invoice['last_name'] ?? '')),
                $invoice['admission_no'] ?? '',
                $invoice['invoice_no'] ?? '',
                ucfirst((string)($invoice['status'] ?? '')),
                $invoice['issued_at'] ?? '',
                $invoice['due_date'] ?? '',
                round((float)$invoice['total_due'], 2),
                round((float)$invoice['total_discount'], 2),
                round((float)$invoice['collected_amount'], 2),
                round((float)$invoice['pending_balance'], 2),
            ]);
        }

        fclose($out);
        exit;
    }

    /**
     * Builds the real .xlsx workbook (raw OOXML, via XlsxWorkbookWriter — see the
     * doc comment on bulkInvoicesXlsDownloadAction() for why) for that action:
     * a Summary sheet (totals + a class breakdown per academic year / month), plus
     * one full-detail sheet per academic year / month group.
     */
    private function buildInvoicesWorkbook(array $invoices): XlsxWorkbookWriter
    {
        require_once __DIR__ . '/../services/XlsxWorkbookWriter.php';
        require_once __DIR__ . '/../models/StudentModel.php';

        [$schoolName] = $this->schoolBranding();
        $generatedOn = date('d M Y, h:i A');
        $w = new XlsxWorkbookWriter();

        $gutter = XlsxWorkbookWriter::str('');
        $strCell = static fn($v, int $style = XlsxWorkbookWriter::STYLE_CELL) => XlsxWorkbookWriter::str((string)$v, $style);
        $numCell = static fn($v, int $style = XlsxWorkbookWriter::STYLE_CELL) => XlsxWorkbookWriter::num($v, $style);
        $headerCell = static fn($v) => XlsxWorkbookWriter::str((string)$v, XlsxWorkbookWriter::STYLE_HEADER);
        // A merged banner cell spanning $span additional columns (title/section headers).
        $bannerCell = static fn(int $style, $v, int $span = 0) => XlsxWorkbookWriter::str((string)$v, $style, $span);

        // ---- Group invoices by "Academic Year — Month" ----
        $studentCache = [];
        $groups = []; // groupLabel => [invoices with resolved class/month attached]
        foreach ($invoices as $invoice) {
            $studentId = (int)$invoice['student_id'];
            if (!isset($studentCache[$studentId])) {
                $studentCache[$studentId] = StudentModel::getById($studentId);
            }
            $student = $studentCache[$studentId];
            $classDisplay = $student
                ? trim(($student['current_class_name'] ?? '') . ' - ' . ($student['current_section_name'] ?? ''))
                : 'Unknown';
            $classDisplay = $classDisplay !== '-' && $classDisplay !== '' ? $classDisplay : 'No Class Assigned';

            $yearLabel = $invoice['academic_year_label'] ?? 'Unassigned / No Academic Year';
            $monthLabel = $this->monthLabelForInvoice($invoice['lines'] ?? []);
            $groupLabel = $yearLabel . ' — ' . $monthLabel;

            $groups[$groupLabel][] = [
                'invoice' => $invoice,
                'class_display' => $classDisplay,
            ];
        }
        ksort($groups);

        // ---- Sheet 1: Summary — totals + class breakdown per group ----
        $summaryColSpan = 4; // widest row: Class/Section, Invoices, Total Due, Collected, Pending (5 cols)
        $w->addSheet('Summary');
        $w->setColumnWidths(array_merge([18], array_fill(0, $summaryColSpan + 1, 20)));
        $w->setFreezeRows(3);

        $w->addRow([$gutter, $bannerCell(XlsxWorkbookWriter::STYLE_TITLE_BANNER, $schoolName, $summaryColSpan)], 30);
        $w->addRow([$gutter, $bannerCell(XlsxWorkbookWriter::STYLE_SUBTITLE_BANNER, 'Fee Invoices Summary  |  Generated ' . $generatedOn, $summaryColSpan)], 20);
        $w->addRow([$gutter, $bannerCell(XlsxWorkbookWriter::STYLE_SPACER, '', $summaryColSpan)]);

        foreach ($groups as $groupLabel => $entries) {
            $w->addRow([$gutter, $bannerCell(XlsxWorkbookWriter::STYLE_SECTION_HEADER, $groupLabel, $summaryColSpan)], 22);

            $byClass = [];
            $grandTotal = 0.0;
            $grandCollected = 0.0;
            $grandPending = 0.0;
            foreach ($entries as $e) {
                $inv = $e['invoice'];
                $cls = $e['class_display'];
                if (!isset($byClass[$cls])) {
                    $byClass[$cls] = ['count' => 0, 'total' => 0.0, 'collected' => 0.0, 'pending' => 0.0];
                }
                $byClass[$cls]['count']++;
                $byClass[$cls]['total'] += (float)$inv['total_due'];
                $byClass[$cls]['collected'] += (float)$inv['collected_amount'];
                $byClass[$cls]['pending'] += (float)$inv['pending_balance'];
                $grandTotal += (float)$inv['total_due'];
                $grandCollected += (float)$inv['collected_amount'];
                $grandPending += (float)$inv['pending_balance'];
            }

            $w->addRow([$gutter, $headerCell('Class / Section'), $headerCell('Invoices'), $headerCell('Total Due'), $headerCell('Collected'), $headerCell('Pending')]);
            ksort($byClass);
            $i = 0;
            foreach ($byClass as $cls => $stats) {
                $rowStyle = $i % 2 === 1 ? XlsxWorkbookWriter::STYLE_CELL_ALT : XlsxWorkbookWriter::STYLE_CELL;
                $w->addRow([
                    $gutter,
                    $strCell($cls, $rowStyle),
                    $numCell($stats['count'], $rowStyle),
                    $numCell(round($stats['total'], 2), $rowStyle),
                    $numCell(round($stats['collected'], 2), $rowStyle),
                    $numCell(round($stats['pending'], 2), $rowStyle),
                ]);
                $i++;
            }
            $w->addRow([$gutter, $headerCell('Total'), $headerCell(count($entries)), $headerCell(round($grandTotal, 2)), $headerCell(round($grandCollected, 2)), $headerCell(round($grandPending, 2))]);
            $w->addRow([$gutter]); // spacer between groups
        }

        // ---- One full-detail sheet per Academic Year / Month group ----
        foreach ($groups as $groupLabel => $entries) {
            $w->addSheet($groupLabel); // addSheet() sanitizes/truncates to a valid 31-char sheet name and dedupes automatically
            $w->setColumnWidths([22, 16, 20, 16, 12, 14, 14, 14, 12, 14, 14]);
            $w->setFreezeRows(1);

            $w->addRow([
                $headerCell('Student'), $headerCell('Admission No'), $headerCell('Class / Section'),
                $headerCell('Invoice No'), $headerCell('Status'), $headerCell('Issued'), $headerCell('Due Date'),
                $headerCell('Total Due'), $headerCell('Discount'), $headerCell('Collected'), $headerCell('Pending'),
            ]);

            usort($entries, static function ($a, $b) {
                return strcmp($a['class_display'], $b['class_display']);
            });
            foreach ($entries as $i => $e) {
                $inv = $e['invoice'];
                $rowStyle = $i % 2 === 1 ? XlsxWorkbookWriter::STYLE_CELL_ALT : XlsxWorkbookWriter::STYLE_CELL;
                $studentName = trim(($inv['first_name'] ?? '') . ' ' . ($inv['last_name'] ?? ''));
                $w->addRow([
                    $strCell($studentName, $rowStyle),
                    $strCell($inv['admission_no'] ?? '', $rowStyle),
                    $strCell($e['class_display'], $rowStyle),
                    $strCell($inv['invoice_no'] ?? '', $rowStyle),
                    $strCell(ucfirst((string)($inv['status'] ?? '')), $rowStyle),
                    $strCell($inv['issued_at'] ?? '', $rowStyle),
                    $strCell($inv['due_date'] ?? '', $rowStyle),
                    $numCell(round((float)$inv['total_due'], 2), $rowStyle),
                    $numCell(round((float)$inv['total_discount'], 2), $rowStyle),
                    $numCell(round((float)$inv['collected_amount'], 2), $rowStyle),
                    $numCell(round((float)$inv['pending_balance'], 2), $rowStyle),
                ]);
            }
        }

        return $w;
    }
}