<?php

class ExpensesController extends Controller
{
    public function indexAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission('expenses.view');

        require_once __DIR__ . '/../models/ExpenseModel.php';

        $error = null;
        $month = (int)($_GET['expense_month'] ?? date('n'));
        $year = (int)($_GET['expense_year'] ?? date('Y'));
        $categoryId = (int)($_GET['category_id'] ?? 0);
        $search = trim((string)($_GET['q'] ?? ''));

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            $this->requireCsrf();
            $action = (string)($_POST['action'] ?? 'create');
            // Each sub-action below is independently permissioned (on top of the
            // broad 'expenses.manage' fallback) so a role can be given, say, just
            // "record expenses" without "delete expenses" or "manage categories".
            $subActionPermissions = [
                'create'          => 'expenses.create',
                'update'          => 'expenses.update',
                'delete'          => 'expenses.delete',
                'add_category'    => 'expenses.category_create',
                'rename_category' => 'expenses.category_rename',
                'delete_category' => 'expenses.category_delete',
            ];
            $this->requirePermission(['expenses.manage', $subActionPermissions[$action] ?? 'expenses.manage']);

            if ($action === 'create') {
                $catId = (int)($_POST['expense_category_id'] ?? 0);
                $description = trim((string)($_POST['description'] ?? ''));
                $amount = (float)($_POST['amount'] ?? 0);
                $expenseDate = trim((string)($_POST['expense_date'] ?? date('Y-m-d')));

                if ($catId <= 0 || $amount <= 0) {
                    $error = 'Category and a valid amount are required';
                } else {
                    $user = Auth::currentUser();
                    ExpenseModel::create($catId, $description, $amount, $expenseDate, $user['id'] ?? null);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Expense recorded'];
                    log_activity('expenses.create', 'Recorded expense of Rs ' . number_format($amount, 2) . ($description !== '' ? (' — ' . $description) : ''));
                    redirect('/index.php?route=' . rawurlencode('expenses/index') . '&expense_month=' . $month . '&expense_year=' . $year);
                    return;
                }
            } elseif ($action === 'update') {
                $id = (int)($_POST['id'] ?? 0);
                $catId = (int)($_POST['expense_category_id'] ?? 0);
                $description = trim((string)($_POST['description'] ?? ''));
                $amount = (float)($_POST['amount'] ?? 0);
                $expenseDate = trim((string)($_POST['expense_date'] ?? date('Y-m-d')));

                if ($id <= 0 || $catId <= 0 || $amount <= 0) {
                    $error = 'Category and a valid amount are required';
                } else {
                    ExpenseModel::update($id, $catId, $description, $amount, $expenseDate);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Expense updated'];
                    log_activity('expenses.update', 'Updated expense #' . $id . ' to Rs ' . number_format($amount, 2));
                    redirect('/index.php?route=' . rawurlencode('expenses/index') . '&expense_month=' . $month . '&expense_year=' . $year);
                    return;
                }
            } elseif ($action === 'delete') {
                $id = (int)($_POST['id'] ?? 0);
                if ($id > 0) {
                    ExpenseModel::delete($id);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Expense deleted'];
                    log_activity('expenses.delete', 'Deleted expense #' . $id);
                }
                redirect('/index.php?route=' . rawurlencode('expenses/index') . '&expense_month=' . $month . '&expense_year=' . $year);
                return;
            } elseif ($action === 'add_category') {
                $name = trim((string)($_POST['name'] ?? ''));
                if ($name === '') {
                    $error = 'Category name is required';
                } else {
                    ExpenseModel::createCategory($name);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Category added'];
                    log_activity('expenses.category_create', 'Added expense category "' . $name . '"');
                    redirect('/index.php?route=' . rawurlencode('expenses/index') . '&expense_month=' . $month . '&expense_year=' . $year);
                    return;
                }
            } elseif ($action === 'rename_category') {
                $id = (int)($_POST['id'] ?? 0);
                $name = trim((string)($_POST['name'] ?? ''));
                if ($id > 0 && $name !== '') {
                    ExpenseModel::renameCategory($id, $name);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Category renamed'];
                    log_activity('expenses.category_rename', 'Renamed expense category #' . $id . ' to "' . $name . '"');
                }
                redirect('/index.php?route=' . rawurlencode('expenses/index') . '&expense_month=' . $month . '&expense_year=' . $year);
                return;
            } elseif ($action === 'delete_category') {
                $id = (int)($_POST['id'] ?? 0);
                if ($id > 0) {
                    try {
                        ExpenseModel::deleteCategory($id);
                        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Category deleted'];
                        log_activity('expenses.category_delete', 'Deleted expense category #' . $id);
                    } catch (Throwable $e) {
                        $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Cannot delete — this category is used by one or more expenses.'];
                    }
                }
                redirect('/index.php?route=' . rawurlencode('expenses/index') . '&expense_month=' . $month . '&expense_year=' . $year);
                return;
            }
        }

        $categories = ExpenseModel::listCategories();
        $expenses = ExpenseModel::list($month, $year, $categoryId, $search);
        $total = ExpenseModel::totalForMonth($month, $year);
        $categoryUsage = ExpenseModel::categoryUsageCounts();

        $this->render('expenses/index', [
            'title' => 'Other Expenses',
            'error' => $error,
            'categories' => $categories,
            'categoryUsage' => $categoryUsage,
            'expenses' => $expenses,
            'total' => $total,
            'month' => $month,
            'year' => $year,
            'categoryId' => $categoryId,
            'search' => $search,
        ]);
    }
}
