<?php

class DashboardController extends Controller
{
    /**
     * First month of the school's academic year (3 = March). The year runs
     * March .. February, so "2026" means Mar 2026 - Feb 2027. Change this one
     * constant if the school ever moves its start month.
     */
    private const ACADEMIC_START_MONTH = 3;

    /** Calendar year in which the CURRENT academic year started (Nov 2026 => 2026, Jan 2027 => 2026). */
    private static function currentAcademicStartYear(): int
    {
        $y = (int)date('Y');
        $m = (int)date('n');
        return $m >= self::ACADEMIC_START_MONTH ? $y : $y - 1;
    }

    /**
     * Inclusive [from, to] "period index" (calendar_year * 12 + month) covering the
     * whole academic year that starts in $startYear. Comparing one integer keeps the
     * queries simple and index-friendly even though the year spans two calendar years.
     *
     * @return array{0:int,1:int}
     */
    private static function academicYearRange(int $startYear): array
    {
        $from = $startYear * 12 + self::ACADEMIC_START_MONTH;
        return [$from, $from + 11];
    }

    /** Calendar year a given calendar month falls in, inside the academic year starting in $startYear. */
    private static function calendarYearFor(int $startYear, int $month): int
    {
        return $month >= self::ACADEMIC_START_MONTH ? $startYear : $startYear + 1;
    }

    /** Calendar months in academic-year order: [3,4,...,12,1,2]. @return int[] */
    private static function academicMonthOrder(): array
    {
        $order = [];
        for ($i = 0; $i < 12; $i++) {
            $order[] = (($i + self::ACADEMIC_START_MONTH - 1) % 12) + 1;
        }
        return $order;
    }

    /**
     * Pending dues (invoice total - collected) for invoices whose billing period falls
     * inside [$fromIdx, $toIdx]. Uses the SAME billing-period rule as "Collected", so the
     * two cards always describe the same set of invoices. Cancelled invoices owe nothing.
     * Values are bound parameters; nothing from the request is concatenated into SQL.
     */
    private static function pendingDuesForRange(int $fromIdx, int $toIdx): float
    {
        $billingSql = self::feeBillingPeriodSql();
        $row = Database::fetchOne(
            "SELECT COALESCE(SUM(fi.total_due - COALESCE(paid.amount, 0)), 0) AS s
             FROM fee_invoices fi
             JOIN ({$billingSql}) bp ON bp.fee_invoice_id = fi.id
             LEFT JOIN (
                 SELECT fee_invoice_id, SUM(amount) AS amount
                 FROM fee_collections
                 GROUP BY fee_invoice_id
             ) paid ON paid.fee_invoice_id = fi.id
             WHERE fi.status <> 'cancelled'
               AND bp.period_idx BETWEEN ? AND ?",
            'ii',
            [$fromIdx, $toIdx]
        );
        return (float)($row['s'] ?? 0);
    }

    public function indexAction(): void
    {
        Auth::requireLogin();

        // Only Admin sees the full institute-wide financial dashboard (revenue, payroll,
        // net balance). Every other role is routed to their own scoped self-service portal
        // so they never see data beyond what belongs to them.
        if (!RBAC::isAdmin()) {
            redirect_route('portal/index');
            return;
        }

        // Soft check: users without dashboard.view go to landing instead of 403 loop
        if (!RBAC::hasPermission('dashboard.view')) {
            redirect_route('dashboard/landing');
            return;
        }

        // $year = calendar year in which the ACADEMIC year starts (Mar $year - Feb $year+1).
        $year = self::currentAcademicStartYear();

        require_once __DIR__ . '/../models/ExpenseModel.php';
        require_once __DIR__ . '/../models/AnnouncementModel.php';

        $stats = [
            'students_enrolled' => 0,
            'fees_collected' => 0.0,
            'expenses' => 0.0,
            'other_expenses' => 0.0,
            'net_balance' => 0.0,
            'pending_dues' => 0.0,
            'staff_count' => 0,
            'period_label' => 'Academic Year ' . $year . '-' . ($year + 1),
            'period_year' => $year,
        ];

        // Lightweight live data used by the modern admin dashboard cards.
        $dashboard = [
            'classes' => 0,
            'new_admissions' => 0,
            'attendance' => [
                'present' => 0,
                'absent' => 0,
                'late' => 0,
                'excused' => 0,
                'total' => 0,
                'marked_total' => 0,
                'rate' => 0.0,
            ],
            'announcements' => [],
            'activities' => [],
        ];

        try {
            // Active students only
            $row = Database::fetchOne('SELECT COUNT(*) AS c FROM students WHERE IFNULL(status, 1) = 1');
            $stats['students_enrolled'] = (int)($row['c'] ?? 0);
        } catch (Throwable $e) {
            try {
                $row = Database::fetchOne('SELECT COUNT(*) AS c FROM students');
                $stats['students_enrolled'] = (int)($row['c'] ?? 0);
            } catch (Throwable $e2) {
            }
        }

        // Fees + payroll for current year (same basis as chart default) so Net = Fees − Payroll is clear.
        // IMPORTANT: bucketed by the invoice's BILLING period (billing_year/billing_month), not by the
        // date the cash was physically collected — see feeTotalsByMonth() for why.
        try {
            $stats['fees_collected'] = array_sum(self::feeTotalsByMonth($year));
        } catch (Throwable $e) {
        }

        $stats['expenses'] = self::sumPayrollExpensesForYear($year);
        // Same Mar-Feb window as fees/payroll (ExpenseModel::totalForYear is calendar-year only).
        $stats['other_expenses'] = array_sum(self::otherExpenseTotalsByMonth($year));
        $stats['net_balance'] = round((float)$stats['fees_collected'] - (float)$stats['expenses'] - (float)$stats['other_expenses'], 2);

        try {
            // Pending for the same academic year as Collected (was: every invoice ever, any year).
            [$ayFrom, $ayTo] = self::academicYearRange($year);
            $stats['pending_dues'] = self::pendingDuesForRange($ayFrom, $ayTo);
        } catch (Throwable $e) {
        }

        try {
            $row = Database::fetchOne('SELECT COUNT(*) AS c FROM staff_profiles');
            $stats['staff_count'] = (int)($row['c'] ?? 0);
        } catch (Throwable $e) {
        }

        // Total class sections currently configured in the school.
        try {
            $row = Database::fetchOne('SELECT COUNT(*) AS c FROM class_sections');
            $dashboard['classes'] = (int)($row['c'] ?? 0);
        } catch (Throwable $e) {
        }

        // New admissions are students created today.
        try {
            $row = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM students WHERE DATE(created_at) = CURDATE()'
            );
            $dashboard['new_admissions'] = (int)($row['c'] ?? 0);
        } catch (Throwable $e) {
        }

        // Today's attendance summary.  Late students are counted as attending for
        // the headline attendance rate, while the breakdown remains visible.
        // Percentages are against the school's total (active) student count —
        // not just the students who happen to have an attendance record marked
        // for today — so the rate reflects the whole school, not only those marked.
        try {
            $rows = Database::fetchAll(
                "SELECT status, COUNT(*) AS c
                 FROM attendance_records
                 WHERE attendance_date = CURDATE()
                 GROUP BY status"
            );
            foreach ($rows as $row) {
                $status = (string)($row['status'] ?? '');
                $count = (int)($row['c'] ?? 0);
                if (array_key_exists($status, $dashboard['attendance'])) {
                    $dashboard['attendance'][$status] = $count;
                }
            }

            $dashboard['attendance']['marked_total'] =
                (int)$dashboard['attendance']['present'] +
                (int)$dashboard['attendance']['absent'] +
                (int)$dashboard['attendance']['late'] +
                (int)$dashboard['attendance']['excused'];

            // Denominator = total active students in the school, so an unmarked
            // student counts against the rate rather than being ignored.
            $dashboard['attendance']['total'] = (int)$stats['students_enrolled'];

            if ($dashboard['attendance']['total'] > 0) {
                $attending = (int)$dashboard['attendance']['present'] + (int)$dashboard['attendance']['late'];
                $dashboard['attendance']['rate'] = round(($attending / $dashboard['attendance']['total']) * 100, 1);
            }
        } catch (Throwable $e) {
        }

        // Latest three announcements for the dashboard feed.
        try {
            $dashboard['announcements'] = AnnouncementModel::recent(3);
        } catch (Throwable $e) {
            $dashboard['announcements'] = [];
        }

        // Build a small activity feed from real dashboard events without introducing
        // another activity-log dependency into the dashboard.
        if ((int)($dashboard['attendance']['marked_total'] ?? 0) > 0) {
            $dashboard['activities'][] = [
                'time' => 'Today',
                'title' => 'Attendance updated',
                'detail' => number_format((int)$dashboard['attendance']['marked_total']) . ' attendance record(s) recorded',
                'tone' => 'green',
            ];
        }
        if ((int)$dashboard['new_admissions'] > 0) {
            $dashboard['activities'][] = [
                'time' => 'Today',
                'title' => 'New admission received',
                'detail' => number_format((int)$dashboard['new_admissions']) . ' new student(s) added today',
                'tone' => 'blue',
            ];
        }
        if (!empty($dashboard['announcements'][0])) {
            $latest = $dashboard['announcements'][0];
            $dashboard['activities'][] = [
                'time' => !empty($latest['created_at']) ? date('h:i A', strtotime((string)$latest['created_at'])) : 'Recent',
                'title' => 'Announcement published',
                'detail' => (string)($latest['title'] ?? 'Latest announcement'),
                'tone' => 'amber',
            ];
        }
        if (!$dashboard['activities']) {
            $dashboard['activities'][] = [
                'time' => 'Today',
                'title' => 'No new activity',
                'detail' => 'Your school dashboard is up to date',
                'tone' => 'blue',
            ];
        }

        $this->render('dashboard/index', [
            'title' => 'Dashboard',
            'stats' => $stats,
            'dashboard' => $dashboard,
        ]);
    }

    /**
     * Finance chart data for Dashboard.
     * Returns JSON: fees collected + payroll expenses + other expenses + net + pending.
     *
     * Query params:
     * - mode:  'year' or 'month'
     * - year:  calendar year in which the ACADEMIC year starts (2026 = Mar 2026 - Feb 2027)
     * - month: 1-12 calendar month inside that academic year (required when mode=month)
     *
     * All inputs are cast to int and range-checked, then bound as query parameters.
     */
    public function financeDataAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission('dashboard.view');
        if (!RBAC::isAdmin()) {
            http_response_code(403);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['error' => 'Forbidden']);
            return;
        }

        header('Content-Type: application/json; charset=utf-8');

        $mode = strtolower(trim((string)($_GET['mode'] ?? 'year')));
        if (!in_array($mode, ['year', 'month'], true)) {
            $mode = 'year';
        }

        $year = (int)($_GET['year'] ?? 0);
        $month = (int)($_GET['month'] ?? 0);

        if ($year < 2000 || $year > 2100) {
            $year = self::currentAcademicStartYear();
        }

        $monthNames = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

        try {
            if ($mode === 'month') {
                if ($month < 1 || $month > 12) {
                    $month = (int)date('n');
                }
                // Jan/Feb belong to the NEXT calendar year of the academic year.
                $calYear = self::calendarYearFor($year, $month);
                $daysInMonth = (int)cal_days_in_month(CAL_GREGORIAN, $month, $calYear);

                $feeMap = self::feeTotalsByDay($year, $month);
                $expMap = self::expenseTotalsByDay($year, $month);
                $otherMap = self::otherExpenseTotalsByDay($year, $month);

                $labels = [];
                $feeValues = [];
                $expValues = [];
                $otherValues = [];
                for ($d = 1; $d <= $daysInMonth; $d++) {
                    $labels[] = (string)$d;
                    $feeValues[] = (float)($feeMap[$d] ?? 0);
                    $expValues[] = (float)($expMap[$d] ?? 0);
                    $otherValues[] = (float)($otherMap[$d] ?? 0);
                }

                $feesTotal = array_sum($feeValues);
                $expTotal = array_sum($expValues);
                $otherTotal = array_sum($otherValues);
                $idx = $calYear * 12 + $month;
                echo json_encode([
                    'mode' => 'month',
                    'year' => $year,
                    'calendar_year' => $calYear,
                    'month' => $month,
                    'label' => $monthNames[$month - 1] . ' ' . $calYear,
                    'labels' => $labels,
                    'values' => $feeValues,
                    'expenses' => $expValues,
                    'other_expenses' => $otherValues,
                    'total' => (float)$feesTotal,
                    'expenses_total' => (float)$expTotal,
                    'other_expenses_total' => (float)$otherTotal,
                    'net' => (float)$feesTotal - (float)$expTotal - (float)$otherTotal,
                    'pending' => self::pendingDuesForRange($idx, $idx),
                ]);
                return;
            }

            // mode=year -> the whole academic year, chart runs Mar .. Feb
            $feeMap = self::feeTotalsByMonth($year);
            $expMap = self::expenseTotalsByMonth($year);
            $otherMap = self::otherExpenseTotalsByMonth($year);

            $labels = [];
            $feeValues = [];
            $expValues = [];
            $otherValues = [];
            foreach (self::academicMonthOrder() as $m) {
                $labels[] = $monthNames[$m - 1];
                $feeValues[] = (float)($feeMap[$m] ?? 0);
                $expValues[] = (float)($expMap[$m] ?? 0);
                $otherValues[] = (float)($otherMap[$m] ?? 0);
            }

            $feesTotal = array_sum($feeValues);
            $expTotal = array_sum($expValues);
            $otherTotal = array_sum($otherValues);
            [$ayFrom, $ayTo] = self::academicYearRange($year);
            echo json_encode([
                'mode' => 'year',
                'year' => $year,
                'label' => $monthNames[self::ACADEMIC_START_MONTH - 1] . ' ' . $year
                    . " \u{2013} "
                    . $monthNames[(self::ACADEMIC_START_MONTH + 10) % 12] . ' ' . ($year + 1),
                'labels' => $labels,
                'values' => $feeValues,
                'expenses' => $expValues,
                'other_expenses' => $otherValues,
                'total' => (float)$feesTotal,
                'expenses_total' => (float)$expTotal,
                'other_expenses_total' => (float)$otherTotal,
                'net' => (float)$feesTotal - (float)$expTotal - (float)$otherTotal,
                'pending' => self::pendingDuesForRange($ayFrom, $ayTo),
            ]);
            return;
        } catch (Throwable $e) {
            // Log the detail server-side; do not leak SQL/internal messages to the browser.
            error_log('financeData failed: ' . $e->getMessage());
            http_response_code(500);
            echo json_encode(['error' => 'Failed to load chart data']);
            return;
        }
    }

    /**
     * Professional landing page for users who cannot access the full dashboard.
     * Shows only the modules the current user has permission to see.
     */
    public function landingAction(): void
    {
        $user = Auth::requireLogin();

        // dashboard/index is Admin-only (it bounces every non-admin straight to
        // portal/index), so only send Admins there — otherwise a non-admin role
        // with dashboard.view would bounce right back here in an endless loop.
        if (RBAC::isAdmin() && RBAC::hasPermission('dashboard.view')) {
            redirect_route('dashboard/index');
            return;
        }

        $modules = [];
        $allModules = [
            ['key' => 'students.view',  'route' => 'students/index',   'label' => 'Students',    'icon' => 'bi-people-fill',        'color' => '#3b82f6'],
            ['key' => 'fees.view',      'route' => 'fees/index',        'label' => 'Fees',        'icon' => 'bi-cash-coin',          'color' => '#10b981'],
            ['key' => 'academic.view',  'route' => 'academic/index',    'label' => 'Academic',    'icon' => 'bi-book-fill',          'color' => '#f59e0b'],
            ['key' => 'reports.view',   'route' => 'reports/index',     'label' => 'Reports',     'icon' => 'bi-bar-chart-fill',     'color' => '#8b5cf6'],
            ['key' => 'staff.view',     'route' => 'staff/index',       'label' => 'Staff',       'icon' => 'bi-person-badge-fill',  'color' => '#ef4444'],
            ['key' => 'settings.view',  'route' => 'settings/index',    'label' => 'Settings',    'icon' => 'bi-gear-fill',          'color' => '#6b7280'],
        ];
        foreach ($allModules as $mod) {
            if (RBAC::hasPermission($mod['key'])) {
                $modules[] = $mod;
            }
        }

        $this->render('dashboard/landing', [
            'title'   => 'Welcome',
            'user'    => $user,
            'modules' => $modules,
        ]);
    }

    /** Total staff salary payments (all time). */
    private static function sumPayrollExpenses(): float
    {
        try {
            $row = Database::fetchOne('SELECT COALESCE(SUM(amount),0) AS s FROM staff_salary_payments');
            return (float)($row['s'] ?? 0);
        } catch (Throwable $e) {
            return 0.0;
        }
    }

    private static function sumPayrollExpensesForYear(int $year): float
    {
        try {
            return array_sum(self::expenseTotalsByMonth($year));
        } catch (Throwable $e) {
            return 0.0;
        }
    }

    /** SQL expression for payment date — supports paid_date (live) or paid_at (schema). */
    private static function payrollDateExpr(): string
    {
        static $expr = null;
        if ($expr !== null) {
            return $expr;
        }
        $expr = 'created_at';
        try {
            $col = Database::fetchOne("SHOW COLUMNS FROM staff_salary_payments LIKE 'paid_date'");
            if ($col) {
                $expr = 'paid_date';
                return $expr;
            }
        } catch (Throwable $e) {
        }
        try {
            $col = Database::fetchOne("SHOW COLUMNS FROM staff_salary_payments LIKE 'paid_at'");
            if ($col) {
                $expr = 'paid_at';
                return $expr;
            }
        } catch (Throwable $e) {
        }
        return $expr;
    }

    /**
     * Per-invoice billing period as ONE integer (calendar_year * 12 + month), derived from
     * fee_invoice_lines. An invoice can have several lines (tuition + exam fee); the earliest
     * dated line wins and undated one-time lines are ignored. Invoices with no billing period
     * at all (one-off charges, e.g. exam-only invoices) fall back to the month they were issued.
     *
     * Collapsing year+month into one number matters now that a year spans two calendar years:
     * taking MIN(year) and MIN(month) separately could pair Dec 2026 with Jan 2027 as "Jan 2026".
     */
    private static function feeBillingPeriodSql(): string
    {
        return "SELECT fil.fee_invoice_id AS fee_invoice_id,
                        COALESCE(
                            MIN(CASE WHEN fil.billing_year IS NOT NULL AND fil.billing_month IS NOT NULL
                                     THEN fil.billing_year * 12 + fil.billing_month END),
                            YEAR(MIN(fi.issued_at)) * 12 + MONTH(MIN(fi.issued_at))
                        ) AS period_idx
                 FROM fee_invoice_lines fil
                 JOIN fee_invoices fi ON fi.id = fil.fee_invoice_id
                 GROUP BY fil.fee_invoice_id";
    }

    /**
     * @return array<int,float> day => total
     * Day-of-month comes from collected_at (the day cash changed hands); WHICH month a
     * collection counts toward comes from the invoice's billing period. $month is a calendar
     * month inside the academic year starting in $startYear (Jan/Feb resolve to $startYear+1).
     */
    private static function feeTotalsByDay(int $startYear, int $month): array
    {
        $billingSql = self::feeBillingPeriodSql();
        $idx = self::calendarYearFor($startYear, $month) * 12 + $month;
        $rows = Database::fetchAll(
            "SELECT DAY(fc.collected_at) AS d, SUM(fc.amount) AS total
             FROM fee_collections fc
             JOIN ({$billingSql}) bp ON bp.fee_invoice_id = fc.fee_invoice_id
             WHERE bp.period_idx = ?
             GROUP BY d
             ORDER BY d",
            'i',
            [$idx]
        );
        $map = [];
        foreach ($rows as $r) {
            $d = (int)($r['d'] ?? 0);
            if ($d > 0) {
                $map[$d] = (float)($r['total'] ?? 0);
            }
        }
        return $map;
    }

    /**
     * @return array<int,float> calendar month (1-12) => total, for the academic year starting
     * in $startYear (Mar $startYear .. Feb $startYear+1), bucketed by billing period.
     * Each calendar month occurs exactly once in a 12-month window, so keying by month is safe.
     */
    private static function feeTotalsByMonth(int $startYear): array
    {
        $billingSql = self::feeBillingPeriodSql();
        [$from, $to] = self::academicYearRange($startYear);
        $rows = Database::fetchAll(
            "SELECT ((bp.period_idx - 1) % 12) + 1 AS m, SUM(fc.amount) AS total
             FROM fee_collections fc
             JOIN ({$billingSql}) bp ON bp.fee_invoice_id = fc.fee_invoice_id
             WHERE bp.period_idx BETWEEN ? AND ?
             GROUP BY m
             ORDER BY m",
            'ii',
            [$from, $to]
        );
        $map = [];
        foreach ($rows as $r) {
            $m = (int)($r['m'] ?? 0);
            if ($m >= 1 && $m <= 12) {
                $map[$m] = (float)($r['total'] ?? 0);
            }
        }
        return $map;
    }

    /**
     * @return array<int,float> day => total (Payroll only)
     * Day-of-month comes from the actual payment date; which MONTH a payment counts toward comes
     * from staff_salary_details.salary_month/salary_year (the period the salary is FOR).
     * $month is a calendar month inside the academic year starting in $startYear.
     */
    private static function expenseTotalsByDay(int $startYear, int $month): array
    {
        try {
            $dateCol = self::payrollDateExpr();
            $rows = Database::fetchAll(
                "SELECT DAY(ssp.{$dateCol}) AS d, SUM(ssp.amount) AS total
                 FROM staff_salary_payments ssp
                 JOIN staff_salary_details ssd ON ssd.id = ssp.staff_salary_detail_id
                 WHERE ssd.salary_year = ? AND ssd.salary_month = ?
                 GROUP BY d
                 ORDER BY d",
                'ii',
                [self::calendarYearFor($startYear, $month), $month]
            );
            $map = [];
            foreach ($rows as $r) {
                $d = (int)($r['d'] ?? 0);
                if ($d > 0) {
                    $map[$d] = (float)($r['total'] ?? 0);
                }
            }
            return $map;
        } catch (Throwable $e) {
            return [];
        }
    }

    /** @return array<int,float> calendar month => total (Payroll only) for the academic year starting in $startYear. */
    private static function expenseTotalsByMonth(int $startYear): array
    {
        try {
            [$from, $to] = self::academicYearRange($startYear);
            $rows = Database::fetchAll(
                "SELECT ssd.salary_month AS m, SUM(ssp.amount) AS total
                 FROM staff_salary_payments ssp
                 JOIN staff_salary_details ssd ON ssd.id = ssp.staff_salary_detail_id
                 WHERE (ssd.salary_year * 12 + ssd.salary_month) BETWEEN ? AND ?
                 GROUP BY m
                 ORDER BY m",
                'ii',
                [$from, $to]
            );
            $map = [];
            foreach ($rows as $r) {
                $m = (int)($r['m'] ?? 0);
                if ($m >= 1 && $m <= 12) {
                    $map[$m] = (float)($r['total'] ?? 0);
                }
            }
            return $map;
        } catch (Throwable $e) {
            return [];
        }
    }

    /** @return array<int,float> day => total (Other Expenses only — kept separate from Payroll) */
    private static function otherExpenseTotalsByDay(int $startYear, int $month): array
    {
        try {
            $rows = Database::fetchAll(
                'SELECT DAY(expense_date) AS d, SUM(amount) AS total
                 FROM expenses
                 WHERE YEAR(expense_date) = ?
                   AND MONTH(expense_date) = ?
                 GROUP BY d
                 ORDER BY d',
                'ii',
                [self::calendarYearFor($startYear, $month), $month]
            );
            $map = [];
            foreach ($rows as $r) {
                $d = (int)($r['d'] ?? 0);
                if ($d > 0) {
                    $map[$d] = (float)($r['total'] ?? 0);
                }
            }
            return $map;
        } catch (Throwable $e) {
            return [];
        }
    }

    /** @return array<int,float> calendar month => total (Other Expenses only) for the academic year starting in $startYear. */
    private static function otherExpenseTotalsByMonth(int $startYear): array
    {
        try {
            // Half-open date range (>= start, < next start) so an index on expense_date can be used.
            $fromDate = sprintf('%04d-%02d-01', $startYear, self::ACADEMIC_START_MONTH);
            $toDate = sprintf('%04d-%02d-01', $startYear + 1, self::ACADEMIC_START_MONTH);
            $rows = Database::fetchAll(
                'SELECT MONTH(expense_date) AS m, SUM(amount) AS total
                 FROM expenses
                 WHERE expense_date >= ? AND expense_date < ?
                 GROUP BY m
                 ORDER BY m',
                'ss',
                [$fromDate, $toDate]
            );
            $map = [];
            foreach ($rows as $r) {
                $m = (int)($r['m'] ?? 0);
                if ($m >= 1 && $m <= 12) {
                    $map[$m] = (float)($r['total'] ?? 0);
                }
            }
            return $map;
        } catch (Throwable $e) {
            return [];
        }
    }
}