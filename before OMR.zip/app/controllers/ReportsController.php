<?php

require_once __DIR__ . '/../services/XlsxGridWriter.php';

class ReportsController extends Controller
{
    public function indexAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission('reports.view');

        // The old tile-grid submenu page is gone — the sidebar's Reports flyout now goes
        // straight to each sub-page, so this route just forwards to the most-used one.
        redirect_route('reports/studentAttendance');
    }

    /**
     * Dates configured under Settings > Global > "Holidays (CSV dates)", keyed by
     * Y-m-d for O(1) lookup. This setting is otherwise only used to show a banner
     * on the take-attendance screen — it was never joined into the reports, which
     * is why a day marked as a holiday there could simply vanish from an export
     * (no attendance_records rows exist for a day nobody took attendance on).
     */
    private function configuredHolidays(): array
    {
        $row = Database::fetchOne("SELECT `value` FROM settings WHERE `key` = 'holidays'");
        $csv = trim((string)($row['value'] ?? ''));
        if ($csv === '') {
            return [];
        }
        $set = [];
        foreach (explode(',', $csv) as $d) {
            $d = trim($d);
            if ($d !== '') {
                $set[$d] = true;
            }
        }
        return $set;
    }

    /** One-letter/short code for a grid cell. Blank means "no attendance was taken and it isn't a configured holiday". */
    private function gridStatusCode(?string $status): string
    {
        $map = [
            'present' => 'P',
            'absent'  => 'A',
            'late'    => 'L',
            'excused' => 'E',
            'holiday' => 'H',
        ];
        return $map[$status ?? ''] ?? '';
    }

    /** All Y-m-d dates in a given 'Y-m' month. */
    private function monthDates(string $month): array
    {
        $monthStart = $month . '-01';
        $ts = strtotime($monthStart);
        if ($ts === false) {
            $month = date('Y-m');
            $monthStart = $month . '-01';
            $ts = strtotime($monthStart);
        }
        $days = (int)date('t', $ts);
        $dates = [];
        for ($d = 1; $d <= $days; $d++) {
            $dates[] = $month . '-' . str_pad((string)$d, 2, '0', STR_PAD_LEFT);
        }
        return $dates;
    }

    /**
     * All Y-m-d dates between two dates inclusive (either order — swapped automatically).
     * Capped at 400 days so a fat-fingered date range can't blow up memory/columns.
     */
    private function rangeDates(string $start, string $end): array
    {
        $startTs = strtotime($start);
        $endTs = strtotime($end);
        if ($startTs === false || $endTs === false) {
            $startTs = strtotime(date('Y-m-01'));
            $endTs = strtotime(date('Y-m-t'));
        }
        if ($startTs > $endTs) {
            [$startTs, $endTs] = [$endTs, $startTs];
        }
        $maxEndTs = strtotime('+399 days', $startTs);
        if ($endTs > $maxEndTs) {
            $endTs = $maxEndTs;
        }
        $dates = [];
        for ($ts = $startTs; $ts <= $endTs; $ts = strtotime('+1 day', $ts)) {
            $dates[] = date('Y-m-d', $ts);
        }
        return $dates;
    }

    /**
     * Builds the "grouped month" header row that sits above the day/weekday header
     * row in the attendance grid exports — e.g. ['', '', 'July 2026', '', ..., 'August
     * 2026', ...] — one label per date column, blank except where a new month starts.
     * Without this, a range spanning more than one month (or more than one year) has
     * day columns like "01-Wed" with no way to tell which month/year they belong to.
     * @return array{labels: string[], spans: array<int, array{startCol:int, endCol:int, label:string}>}
     *   labels: one entry per date in $dates, for the CSV row / plain xlsx header row.
     *   spans: contiguous column ranges (0-based, relative to the first date column)
     *   sharing one month, for merging that header row's cells in the .xlsx export.
     */
    private function monthGroupHeader(array $dates): array
    {
        $labels = [];
        $spans = [];
        $currentLabel = null;
        $currentStart = 0;
        foreach ($dates as $i => $d) {
            $label = date('F Y', strtotime($d));
            $labels[] = ($label !== $currentLabel) ? $label : '';
            if ($label !== $currentLabel) {
                if ($currentLabel !== null) {
                    $spans[] = ['startCol' => $currentStart, 'endCol' => $i - 1, 'label' => $currentLabel];
                }
                $currentLabel = $label;
                $currentStart = $i;
            }
        }
        if ($currentLabel !== null) {
            $spans[] = ['startCol' => $currentStart, 'endCol' => count($dates) - 1, 'label' => $currentLabel];
        }
        return ['labels' => $labels, 'spans' => $spans];
    }

    public function studentAttendanceAction(): void
    {
        Auth::requireLoginOrToken();
        $this->requirePermission('reports.view');

        $start = trim((string)($_GET['start_date'] ?? date('Y-m-01')));
        $end = trim((string)($_GET['end_date'] ?? date('Y-m-t')));
        $classSectionId = (int)($_GET['class_section_id'] ?? 0);

        require_once __DIR__ . '/../models/ClassSectionModel.php';
        $classSections = ClassSectionModel::allOptions();

        $where = 'WHERE ar.attendance_date BETWEEN ? AND ? AND ar.subject_id IS NULL';
        $types = 'ss';
        $params = [$start, $end];
        if ($classSectionId > 0) {
            $where .= ' AND ar.class_section_id = ?';
            $types .= 'i';
            $params[] = $classSectionId;
        }

        // Register-style grid:one column per day of a chosen date
        // range — same shape as the paper attendance register, and it fills in "H" for
        // configured holidays even on days nobody opened the take-attendance screen for.
        if (($_GET['export'] ?? '') === 'grid_csv') {
            $this->requirePermission('reports.export');

            $gridStart = trim((string)($_GET['grid_start'] ?? $start));
            $gridEnd = trim((string)($_GET['grid_end'] ?? $end));
            $sundayOff = ($_GET['sunday_off'] ?? '1') === '1';
            $dates = $this->rangeDates($gridStart, $gridEnd);
            $holidays = $this->configuredHolidays();

            $studentWhere = '';
            $studentTypes = '';
            $studentParams = [];
            if ($classSectionId > 0) {
                $studentWhere = 'WHERE sca.class_section_id = ?';
                $studentTypes = 'i';
                $studentParams = [$classSectionId];
            }
            $students = Database::fetchAll(
                'SELECT s.id, s.admission_no, s.first_name, s.last_name, s.father_name,
                        c.name AS class_name, sec.name AS section_name
                 FROM students s
                 INNER JOIN student_class_assignments sca
                    ON sca.id = (
                        SELECT sca2.id FROM student_class_assignments sca2
                        WHERE sca2.student_id = s.id
                        ORDER BY sca2.assigned_at DESC, sca2.id DESC LIMIT 1
                    )
                 INNER JOIN class_sections cs ON cs.id = sca.class_section_id
                 INNER JOIN classes c ON c.id = cs.class_id
                 INNER JOIN sections sec ON sec.id = cs.section_id
                 WHERE IFNULL(s.status, 1) = 1' . ($studentWhere !== '' ? ' AND ' . substr($studentWhere, 6) : '') . '
                 ORDER BY c.name, sec.name, s.first_name, s.last_name',
                $studentTypes,
                $studentParams
            );

            $recordRows = Database::fetchAll(
                'SELECT ar.student_id, ar.attendance_date, ar.status
                 FROM attendance_records ar
                 WHERE ar.attendance_date BETWEEN ? AND ? AND ar.subject_id IS NULL' .
                    ($classSectionId > 0 ? ' AND ar.class_section_id = ?' : ''),
                $classSectionId > 0 ? 'ssi' : 'ss',
                $classSectionId > 0 ? [$dates[0], end($dates), $classSectionId] : [$dates[0], end($dates)]
            );
            $byStudentDate = [];
            foreach ($recordRows as $r) {
                $byStudentDate[(int)$r['student_id']][$r['attendance_date']] = $r['status'];
            }

            header('Content-Type: text/csv; charset=UTF-8');
            header('Content-Disposition: attachment; filename="student_attendance_grid_' . $gridStart . '_to_' . $gridEnd . '.csv"');
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");

            $header = ['First Name', 'Last Name', "Father's Name", 'Admission No', 'Class'];
            foreach ($dates as $d) {
                $header[] = date('d', strtotime($d)) . '-' . date('D', strtotime($d));
            }
            $header[] = 'Present Count';
            $header[] = 'Absent Count';
            $header[] = 'Leave Count';

            // A "grouped month" row above the day/weekday header row, so a range that
            // spans more than one month — or more than one year — doesn't leave every
            // "01-Wed"-style column ambiguous about which month/year it's actually for.
            $monthGroup = $this->monthGroupHeader($dates);
            fputcsv_safe($out, array_merge(array_fill(0, 5, ''), $monthGroup['labels'], ['', '', '']));
            fputcsv_safe($out, $header);

            foreach ($students as $s) {
                $row = [
                    $s['first_name'],
                    $s['last_name'],
                    $s['father_name'] ?? '',
                    $s['admission_no'],
                    trim(($s['class_name'] ?? '') . ' ' . ($s['section_name'] ?? '')),
                ];
                $presentCount = 0;
                $absentCount = 0;
                $leaveCount = 0;
                foreach ($dates as $d) {
                    if (isset($holidays[$d])) {
                        $code = 'H';
                    } elseif ($sundayOff && date('N', strtotime($d)) == 7) {
                        $code = 'H';
                    } else {
                        $code = $this->gridStatusCode($byStudentDate[(int)$s['id']][$d] ?? null);
                    }
                    $row[] = $code;
                    if ($code === 'P' || $code === 'L') {
                        $presentCount++;
                    } elseif ($code === 'A') {
                        $absentCount++;
                    } elseif ($code === 'E') {
                        $leaveCount++;
                    }
                }
                $row[] = $presentCount;
                $row[] = $absentCount;
                $row[] = $leaveCount;
                fputcsv_safe($out, $row);
            }
            fclose($out);
            exit;
        }

        // Same register grid as above, but as a coloured .xlsx instead of plain CSV
        // (green Present, red Absent, amber Late, blue Excused, pink Holiday).
        if (($_GET['export'] ?? '') === 'grid_xlsx') {
            $this->requirePermission('reports.export');

            $gridStart = trim((string)($_GET['grid_start'] ?? $start));
            $gridEnd = trim((string)($_GET['grid_end'] ?? $end));
            $sundayOff = ($_GET['sunday_off'] ?? '1') === '1';
            $dates = $this->rangeDates($gridStart, $gridEnd);
            $holidays = $this->configuredHolidays();

            $studentWhere = '';
            $studentTypes = '';
            $studentParams = [];
            if ($classSectionId > 0) {
                $studentWhere = 'WHERE sca.class_section_id = ?';
                $studentTypes = 'i';
                $studentParams = [$classSectionId];
            }
            $students = Database::fetchAll(
                'SELECT s.id, s.admission_no, s.first_name, s.last_name, s.father_name,
                        c.name AS class_name, sec.name AS section_name
                 FROM students s
                 INNER JOIN student_class_assignments sca
                    ON sca.id = (
                        SELECT sca2.id FROM student_class_assignments sca2
                        WHERE sca2.student_id = s.id
                        ORDER BY sca2.assigned_at DESC, sca2.id DESC LIMIT 1
                    )
                 INNER JOIN class_sections cs ON cs.id = sca.class_section_id
                 INNER JOIN classes c ON c.id = cs.class_id
                 INNER JOIN sections sec ON sec.id = cs.section_id
                 WHERE IFNULL(s.status, 1) = 1' . ($studentWhere !== '' ? ' AND ' . substr($studentWhere, 6) : '') . '
                 ORDER BY c.name, sec.name, s.first_name, s.last_name',
                $studentTypes,
                $studentParams
            );

            $recordRows = Database::fetchAll(
                'SELECT ar.student_id, ar.attendance_date, ar.status
                 FROM attendance_records ar
                 WHERE ar.attendance_date BETWEEN ? AND ? AND ar.subject_id IS NULL' .
                    ($classSectionId > 0 ? ' AND ar.class_section_id = ?' : ''),
                $classSectionId > 0 ? 'ssi' : 'ss',
                $classSectionId > 0 ? [$dates[0], end($dates), $classSectionId] : [$dates[0], end($dates)]
            );
            $byStudentDate = [];
            foreach ($recordRows as $r) {
                $byStudentDate[(int)$r['student_id']][$r['attendance_date']] = $r['status'];
            }

            $xlsx = new XlsxGridWriter('Student Attendance');
            $header = ['First Name', 'Last Name', "Father's Name", 'Admission No', 'Class'];
            foreach ($dates as $d) {
                $header[] = date('d', strtotime($d)) . '-' . date('D', strtotime($d));
            }
            $header[] = 'Present';
            $header[] = 'Absent';
            $header[] = 'Leave';

            // A "grouped month" row above the day/weekday header row, so a range that
            // spans more than one month — or more than one year — doesn't leave every
            // "01-Wed"-style column ambiguous about which month/year it's actually for.
            $monthGroup = $this->monthGroupHeader($dates);
            $xlsx->setFreezeRows(2);
            $xlsx->addHeaderRow(array_merge(array_fill(0, 5, ''), $monthGroup['labels'], ['', '', '']));
            foreach ($monthGroup['spans'] as $span) {
                $xlsx->mergeCells(0, 5 + $span['startCol'], 5 + $span['endCol']);
            }
            $xlsx->addHeaderRow($header);
            $xlsx->setColumnWidths(array_merge([16, 16, 16, 12, 14], array_fill(0, count($dates), 6), [9, 9, 9]));

            foreach ($students as $s) {
                $row = [
                    XlsxGridWriter::cell($s['first_name'] ?? ''),
                    XlsxGridWriter::cell($s['last_name'] ?? ''),
                    XlsxGridWriter::cell($s['father_name'] ?? ''),
                    XlsxGridWriter::cell($s['admission_no'] ?? ''),
                    XlsxGridWriter::cell(trim(($s['class_name'] ?? '') . ' ' . ($s['section_name'] ?? ''))),
                ];
                $presentCount = 0;
                $absentCount = 0;
                $leaveCount = 0;
                foreach ($dates as $d) {
                    if (isset($holidays[$d])) {
                        $code = 'H';
                    } elseif ($sundayOff && date('N', strtotime($d)) == 7) {
                        $code = 'H';
                    } else {
                        $code = $this->gridStatusCode($byStudentDate[(int)$s['id']][$d] ?? null);
                    }
                    $row[] = XlsxGridWriter::cell($code, $code !== '' ? $code : null);
                    if ($code === 'P' || $code === 'L') {
                        $presentCount++;
                    } elseif ($code === 'A') {
                        $absentCount++;
                    } elseif ($code === 'E') {
                        $leaveCount++;
                    }
                }
                $row[] = XlsxGridWriter::cell((string)$presentCount, null, true, true);
                $row[] = XlsxGridWriter::cell((string)$absentCount, null, true, true);
                $row[] = XlsxGridWriter::cell((string)$leaveCount, null, true, true);
                $xlsx->addRow($row);
            }

            $xlsx->download('student_attendance_register_' . $dates[0] . '_to_' . end($dates) . '.xlsx');
        }

        // Export pulls every matching row (that's the whole point of an export), but the
        // on-screen table is paginated below so the page itself never has to render an
        // ever-growing list — it just gets longer to page through as more days pass.
        if (($_GET['export'] ?? '') === 'csv') {
            $this->requirePermission('reports.export');

            $exportRows = Database::fetchAll(
                'SELECT ar.attendance_date,
                        ar.status,
                        s.admission_no,
                        s.first_name,
                        s.last_name,
                        c.name AS class_name,
                        sec.name AS section_name
                 FROM attendance_records ar
                 JOIN students s ON s.id = ar.student_id
                 JOIN class_sections cs ON cs.id = ar.class_section_id
                 JOIN classes c ON c.id = cs.class_id
                 JOIN sections sec ON sec.id = cs.section_id
                 ' . $where . '
                 ORDER BY ar.attendance_date DESC, s.admission_no',
                $types,
                $params
            );

            header('Content-Type: text/csv; charset=UTF-8');
            header('Content-Disposition: attachment; filename="student_attendance_' . $start . '_to_' . $end . '.csv"');
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv_safe($out, ['date', 'status', 'admission_no', 'student', 'class']);
            foreach ($exportRows as $r) {
                fputcsv_safe($out, [
                    $r['attendance_date'],
                    $r['status'],
                    $r['admission_no'],
                    trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? '')),
                    trim(($r['class_name'] ?? '') . ' ' . ($r['section_name'] ?? '')),
                ]);
            }
            fclose($out);
            exit;
        }

        // Summary counts (present/absent/late/excused + total) over the WHOLE filtered
        // range, not just the current page, so the KPI cards stay accurate.
        $summaryRow = Database::fetchOne(
            'SELECT COUNT(*) AS total,
                    SUM(CASE WHEN ar.status = "present" THEN 1 ELSE 0 END) AS present_count,
                    SUM(CASE WHEN ar.status = "absent" THEN 1 ELSE 0 END) AS absent_count,
                    SUM(CASE WHEN ar.status = "late" THEN 1 ELSE 0 END) AS late_count,
                    SUM(CASE WHEN ar.status = "excused" THEN 1 ELSE 0 END) AS excused_count,
                    SUM(CASE WHEN ar.status = "holiday" THEN 1 ELSE 0 END) AS holiday_count
             FROM attendance_records ar
             JOIN class_sections cs ON cs.id = ar.class_section_id
             ' . $where,
            $types,
            $params
        );
        $summary = [
            'total' => (int)($summaryRow['total'] ?? 0),
            'present' => (int)($summaryRow['present_count'] ?? 0),
            'absent' => (int)($summaryRow['absent_count'] ?? 0),
            'late' => (int)($summaryRow['late_count'] ?? 0),
            'excused' => (int)($summaryRow['excused_count'] ?? 0),
            'holiday' => (int)($summaryRow['holiday_count'] ?? 0),
        ];

        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 50;
        $offset = ($page - 1) * $perPage;
        $totalPages = max(1, (int)ceil($summary['total'] / $perPage));
        if ($page > $totalPages) {
            $page = $totalPages;
            $offset = ($page - 1) * $perPage;
        }

        $rows = Database::fetchAll(
            'SELECT ar.attendance_date,
                    ar.status,
                    s.id AS student_id,
                    s.admission_no,
                    s.first_name,
                    s.last_name,
                    s.phone,
                    c.name AS class_name,
                    sec.name AS section_name
             FROM attendance_records ar
             JOIN students s ON s.id = ar.student_id
             JOIN class_sections cs ON cs.id = ar.class_section_id
             JOIN classes c ON c.id = cs.class_id
             JOIN sections sec ON sec.id = cs.section_id
             ' . $where . '
             ORDER BY ar.attendance_date DESC, s.admission_no
             LIMIT ? OFFSET ?',
            $types . 'ii',
            array_merge($params, [$perPage, $offset])
        );

        // "Send via WhatsApp" support: one batch query for every guardian of
        // every student on this page, so the view can offer a choice of
        // numbers (student + each guardian) per row without a query per row.
        require_once __DIR__ . '/../models/GuardianModel.php';
        $guardiansByStudent = GuardianModel::listByStudents(array_column($rows, 'student_id'));

        $this->render('reports/student_attendance', [
            'title' => 'Student Attendance Report',
            'start_date' => $start,
            'end_date' => $end,
            'classSectionId' => $classSectionId,
            'classSections' => $classSections,
            'rows' => $rows,
            'guardiansByStudent' => $guardiansByStudent,
            'summary' => $summary,
            'page' => $page,
            'perPage' => $perPage,
            'totalPages' => $totalPages,
        ]);
    }

    public function examMarksAction(): void
    {
        Auth::requireLoginOrToken();
        $this->requirePermission('reports.view');

        $examId = (int)($_GET['exam_id'] ?? 0);
        $subjectId = (int)($_GET['subject_id'] ?? 0);

        $exams = Database::fetchAll('SELECT id, exam_name FROM exams ORDER BY id DESC LIMIT 100');
        $subjects = Database::fetchAll('SELECT id, subject_name FROM subjects ORDER BY subject_name');

        if ($examId <= 0 && !empty($exams)) $examId = (int)$exams[0]['id'];
        if ($subjectId <= 0 && !empty($subjects)) $subjectId = (int)$subjects[0]['id'];

        $rows = [];
        if ($examId > 0 && $subjectId > 0) {
            $rows = Database::fetchAll(
                'SELECT s.admission_no,
                        s.first_name,
                        s.last_name,
                        m.score,
                        COALESCE(m.total_marks, 100) AS total_marks,
                        g.grade_letter
                 FROM marks m
                 JOIN students s ON s.id = m.student_id
                 LEFT JOIN grades g ON g.id = m.grade_id
                 WHERE m.exam_id = ? AND m.subject_id = ?
                 ORDER BY m.score DESC',
                'ii',
                [$examId, $subjectId]
            );
        }

        if (($_GET['export'] ?? '') === 'csv') {
            $this->requirePermission('reports.export');
            header('Content-Type: text/csv; charset=UTF-8');
            header('Content-Disposition: attachment; filename="exam_marks.csv"');
            $out = fopen('php://output', 'w');
            fputcsv_safe($out, ['admission_no', 'student', 'score', 'total_marks', 'percentage', 'grade']);
            foreach ($rows as $r) {
                $tot = (float)($r['total_marks'] ?? 100);
                $pct = $tot > 0 ? round((float)$r['score'] / $tot * 100, 1) : 0;
                fputcsv_safe($out, [
                    $r['admission_no'],
                    trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? '')),
                    $r['score'],
                    $tot,
                    $pct . '%',
                    $r['grade_letter'],
                ]);
            }
            fclose($out);
            exit;
        }

        $this->render('reports/exam_marks', [
            'title' => 'Exam Marks Report',
            'exams' => $exams,
            'subjects' => $subjects,
            'examId' => $examId,
            'subjectId' => $subjectId,
            'rows' => $rows,
        ]);
    }

    public function feeCollectionsAction(): void
    {
        Auth::requireLoginOrToken();
        $this->requirePermission('reports.view');

        $start = trim((string)($_GET['start_date'] ?? date('Y-m-01')));
        $end = trim((string)($_GET['end_date'] ?? date('Y-m-t')));

        $rows = Database::fetchAll(
            'SELECT fc.collected_at,
                    fc.amount,
                    fc.method,
                    fi.invoice_no,
                    s.admission_no,
                    s.first_name,
                    s.last_name
             FROM fee_collections fc
             JOIN fee_invoices fi ON fi.id = fc.fee_invoice_id
             JOIN students s ON s.id = fi.student_id
             WHERE DATE(fc.collected_at) BETWEEN ? AND ?
             ORDER BY fc.collected_at DESC',
            'ss',
            [$start, $end]
        );

        if (($_GET['export'] ?? '') === 'csv') {
            $this->requirePermission('reports.export');
            header('Content-Type: text/csv; charset=UTF-8');
            header('Content-Disposition: attachment; filename="fee_collections.csv"');
            $out = fopen('php://output', 'w');
            fputcsv_safe($out, ['collected_at', 'invoice_no', 'admission_no', 'student', 'amount', 'method']);
            foreach ($rows as $r) {
                fputcsv_safe($out, [
                    $r['collected_at'],
                    $r['invoice_no'],
                    $r['admission_no'],
                    trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? '')),
                    $r['amount'],
                    $r['method'],
                ]);
            }
            fclose($out);
            exit;
        }

        $this->render('reports/fee_collections', [
            'title' => 'Fee Collections Report',
            'start_date' => $start,
            'end_date' => $end,
            'rows' => $rows,
        ]);
    }

    /**
     * Invoices report: every invoice issued in the selected date range, regardless
     * of status — open, paid, and cancelled are all included, since this is a
     * date-range report meant for a full record, not tied to the Fee Invoices
     * list's own status/class filters. Shows who generated each invoice and (from
     * the most recent fee_collections row, since an invoice can be paid across
     * more than one installment) who last collected/marked it paid and when.
     */
    public function invoicesAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLoginOrToken();
        $this->requirePermission('reports.view');

        StudentModel::ensureCnicColumn();

        $start = trim((string)($_GET['start_date'] ?? date('Y-m-01')));
        $end = trim((string)($_GET['end_date'] ?? date('Y-m-t')));

        $rows = Database::fetchAll(
            "SELECT fi.invoice_no, fi.issued_at, fi.due_date, fi.status,
                    fi.total_amount, fi.total_discount, fi.total_due, fi.fine_applied,
                    s.admission_no, s.first_name, s.last_name, s.father_name,
                    inv_c.name AS invoice_class_name, inv_sec.name AS invoice_section_name,
                    gen_u.username AS generated_by,
                    COALESCE((
                        SELECT SUM(fc.amount) FROM fee_collections fc WHERE fc.fee_invoice_id = fi.id
                    ), 0) AS collected_amount,
                    lc.collected_at AS last_collected_at,
                    lc.method AS last_payment_method,
                    col_u.username AS last_collected_by
             FROM fee_invoices fi
             JOIN students s ON s.id = fi.student_id
             LEFT JOIN class_sections inv_cs ON inv_cs.id = fi.class_section_id
             LEFT JOIN classes inv_c ON inv_c.id = inv_cs.class_id
             LEFT JOIN sections inv_sec ON inv_sec.id = inv_cs.section_id
             LEFT JOIN users gen_u ON gen_u.id = fi.created_by_user_id
             LEFT JOIN fee_collections lc ON lc.id = (
                 SELECT fc2.id FROM fee_collections fc2
                 WHERE fc2.fee_invoice_id = fi.id
                 ORDER BY fc2.collected_at DESC, fc2.id DESC
                 LIMIT 1
             )
             LEFT JOIN users col_u ON col_u.id = lc.collected_by_user_id
             WHERE DATE(fi.issued_at) BETWEEN ? AND ?
             ORDER BY fi.issued_at DESC, fi.id DESC",
            'ss',
            [$start, $end]
        );

        // Summary counts/totals for the header cards on the report page.
        $summary = ['open' => 0, 'paid' => 0, 'cancelled' => 0, 'total_due' => 0.0, 'total_collected' => 0.0];
        foreach ($rows as $r) {
            $status = (string)$r['status'];
            if (isset($summary[$status])) {
                $summary[$status]++;
            }
            $summary['total_due'] += (float)$r['total_due'];
            $summary['total_collected'] += (float)$r['collected_amount'];
        }

        if (($_GET['export'] ?? '') === 'csv') {
            $this->requirePermission('reports.export');

            header('Content-Type: text/csv; charset=UTF-8');
            header('Content-Disposition: attachment; filename="invoices_report_' . $start . '_to_' . $end . '.csv"');
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");

            fputcsv_safe($out, [
                'Invoice Number', 'Student Name', "Father's Name", 'Class', 'Status',
                'Total Amount', 'Discount', 'Fine', 'Total Due', 'Collected Amount', 'Pending Balance',
                'Generated On', 'Generated By', 'Due Date',
                'Payment Date', 'Marked Paid By', 'Payment Method',
            ]);

            foreach ($rows as $inv) {
                $collected = (float)$inv['collected_amount'];
                $pending = (float)$inv['total_due'] - $collected;
                $classDisplay = trim(
                    (string)($inv['invoice_class_name'] ?? '') . ' ' . (string)($inv['invoice_section_name'] ?? '')
                );

                fputcsv_safe($out, [
                    $inv['invoice_no'],
                    trim($inv['first_name'] . ' ' . $inv['last_name']),
                    $inv['father_name'] ?? '',
                    $classDisplay,
                    ucfirst((string)$inv['status']),
                    number_format((float)$inv['total_amount'], 2),
                    number_format((float)$inv['total_discount'], 2),
                    number_format((float)$inv['fine_applied'], 2),
                    number_format((float)$inv['total_due'], 2),
                    number_format($collected, 2),
                    number_format($pending, 2),
                    $inv['issued_at'],
                    $inv['generated_by'] ?? '',
                    $inv['due_date'] ?? '',
                    $inv['last_collected_at'] ?? '',
                    $inv['last_collected_by'] ?? '',
                    $inv['last_payment_method'] ?? '',
                ]);
            }

            fclose($out);
            exit;
        }

        $this->render('reports/invoices', [
            'title' => 'Invoices Report',
            'start_date' => $start,
            'end_date' => $end,
            'rows' => $rows,
            'summary' => $summary,
        ]);
    }

    /**
     * Expenses report: every outgoing payment in the selected date range — both
     * "Other Expenses" (expenses/expense_categories, e.g. utilities, repairs)
     * and staff salary payments (staff_salary_payments) — merged into one list
     * so Admin/Accountant can see total money going out, not just fees coming in.
     */
    public function expensesAction(): void
    {
        Auth::requireLoginOrToken();
        $this->requirePermission('reports.view');

        $start = trim((string)($_GET['start_date'] ?? date('Y-m-01')));
        $end = trim((string)($_GET['end_date'] ?? date('Y-m-t')));
        $type = trim((string)($_GET['type'] ?? 'all')); // all | expense | salary

        $expenseRows = [];
        if ($type !== 'salary') {
            $raw = Database::fetchAll(
                'SELECT e.expense_date, e.description, e.amount, ec.name AS category_name
                 FROM expenses e
                 JOIN expense_categories ec ON ec.id = e.expense_category_id
                 WHERE DATE(e.expense_date) BETWEEN ? AND ?
                 ORDER BY e.expense_date DESC, e.id DESC',
                'ss',
                [$start, $end]
            );
            foreach ($raw as $r) {
                $expenseRows[] = [
                    'date' => (string)$r['expense_date'],
                    'type' => 'Other Expense',
                    'category' => (string)$r['category_name'],
                    'details' => (string)($r['description'] ?? ''),
                    'amount' => (float)$r['amount'],
                    'method' => '',
                ];
            }
        }

        $salaryRows = [];
        if ($type !== 'expense') {
            $raw = Database::fetchAll(
                'SELECT ssp.paid_date, ssp.amount, ssp.method, ssp.note,
                        sp.full_name, sp.title, sd.salary_month, sd.salary_year
                 FROM staff_salary_payments ssp
                 JOIN staff_salary_details sd ON sd.id = ssp.staff_salary_detail_id
                 JOIN staff_profiles sp ON sp.id = sd.staff_profile_id
                 WHERE DATE(ssp.paid_date) BETWEEN ? AND ?
                 ORDER BY ssp.paid_date DESC, ssp.id DESC',
                'ss',
                [$start, $end]
            );
            foreach ($raw as $r) {
                $forPeriod = $r['salary_month'] && $r['salary_year']
                    ? date('M Y', mktime(0, 0, 0, (int)$r['salary_month'], 1, (int)$r['salary_year']))
                    : '';
                $details = trim((string)$r['full_name']) . ($r['title'] ? ' (' . $r['title'] . ')' : '');
                if ($forPeriod !== '') {
                    $details .= ' — Salary for ' . $forPeriod;
                }
                if (trim((string)($r['note'] ?? '')) !== '') {
                    $details .= ' — ' . trim((string)$r['note']);
                }
                $salaryRows[] = [
                    'date' => (string)$r['paid_date'],
                    'type' => 'Salary',
                    'category' => 'Salary',
                    'details' => $details,
                    'amount' => (float)$r['amount'],
                    'method' => (string)($r['method'] ?? ''),
                ];
            }
        }

        $rows = array_merge($expenseRows, $salaryRows);
        usort($rows, static function ($a, $b) {
            return strcmp($b['date'], $a['date']);
        });

        $summary = ['other_expenses' => 0.0, 'salaries' => 0.0, 'total' => 0.0, 'count' => count($rows)];
        foreach ($expenseRows as $r) {
            $summary['other_expenses'] += $r['amount'];
        }
        foreach ($salaryRows as $r) {
            $summary['salaries'] += $r['amount'];
        }
        $summary['total'] = $summary['other_expenses'] + $summary['salaries'];

        if (($_GET['export'] ?? '') === 'csv') {
            $this->requirePermission('reports.export');
            header('Content-Type: text/csv; charset=UTF-8');
            header('Content-Disposition: attachment; filename="expenses_report_' . $start . '_to_' . $end . '.csv"');
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv_safe($out, ['Date', 'Type', 'Category', 'Details', 'Amount', 'Method']);
            foreach ($rows as $r) {
                fputcsv_safe($out, [
                    $r['date'], $r['type'], $r['category'], $r['details'],
                    number_format($r['amount'], 2), $r['method'],
                ]);
            }
            fclose($out);
            exit;
        }

        $this->render('reports/expenses', [
            'title' => 'Expenses Report',
            'start_date' => $start,
            'end_date' => $end,
            'type' => $type,
            'rows' => $rows,
            'summary' => $summary,
        ]);
    }

    public function staffAttendanceAction(): void
    {
        Auth::requireLoginOrToken();
        $this->requirePermission('reports.view');

        $start = trim((string)($_GET['start_date'] ?? date('Y-m-01')));
        $end = trim((string)($_GET['end_date'] ?? date('Y-m-t')));

        // Register-style grid export: one row per staff member, one column per day of a
        // chosen date range, "H" filled in for configured holidays even if nobody opened
        // the take-attendance screen that day.
        if (($_GET['export'] ?? '') === 'grid_csv') {
            $this->requirePermission('reports.export');

            $gridStart = trim((string)($_GET['grid_start'] ?? $start));
            $gridEnd = trim((string)($_GET['grid_end'] ?? $end));
            $sundayOff = ($_GET['sunday_off'] ?? '1') === '1';
            $dates = $this->rangeDates($gridStart, $gridEnd);
            $holidays = $this->configuredHolidays();

            $staff = Database::fetchAll('SELECT id, full_name, title FROM staff_profiles ORDER BY full_name');

            $recordRows = Database::fetchAll(
                'SELECT sar.staff_profile_id, sar.attendance_date, sar.status
                 FROM staff_attendance_records sar
                 WHERE sar.attendance_date BETWEEN ? AND ?',
                'ss',
                [$dates[0], end($dates)]
            );
            $byStaffDate = [];
            foreach ($recordRows as $r) {
                $byStaffDate[(int)$r['staff_profile_id']][$r['attendance_date']] = $r['status'];
            }

            header('Content-Type: text/csv; charset=UTF-8');
            header('Content-Disposition: attachment; filename="staff_attendance_grid_' . $gridStart . '_to_' . $gridEnd . '.csv"');
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");

            $header = ['Staff Name', 'Designation'];
            foreach ($dates as $d) {
                $header[] = date('d', strtotime($d)) . '-' . date('D', strtotime($d));
            }
            $header[] = 'Present Count';
            $header[] = 'Absent Count';
            $header[] = 'Leave Count';

            // A "grouped month" row above the day/weekday header row, so a range that
            // spans more than one month — or more than one year — doesn't leave every
            // "01-Wed"-style column ambiguous about which month/year it's actually for.
            $monthGroup = $this->monthGroupHeader($dates);
            fputcsv_safe($out, array_merge(array_fill(0, 2, ''), $monthGroup['labels'], ['', '', '']));
            fputcsv_safe($out, $header);

            foreach ($staff as $sp) {
                $row = [$sp['full_name'], $sp['title'] ?? ''];
                $presentCount = 0;
                $absentCount = 0;
                $leaveCount = 0;
                foreach ($dates as $d) {
                    if (isset($holidays[$d])) {
                        $code = 'H';
                    } elseif ($sundayOff && date('N', strtotime($d)) == 7) {
                        $code = 'H';
                    } else {
                        $code = $this->gridStatusCode($byStaffDate[(int)$sp['id']][$d] ?? null);
                    }
                    $row[] = $code;
                    if ($code === 'P' || $code === 'L') {
                        $presentCount++;
                    } elseif ($code === 'A') {
                        $absentCount++;
                    } elseif ($code === 'E') {
                        $leaveCount++;
                    }
                }
                $row[] = $presentCount;
                $row[] = $absentCount;
                $row[] = $leaveCount;
                fputcsv_safe($out, $row);
            }
            fclose($out);
            exit;
        }

        // Same register grid as above, but as a coloured .xlsx instead of plain CSV
        // (green Present, red Absent, amber Late, blue Excused, pink Holiday).
        if (($_GET['export'] ?? '') === 'grid_xlsx') {
            $this->requirePermission('reports.export');

            $gridStart = trim((string)($_GET['grid_start'] ?? $start));
            $gridEnd = trim((string)($_GET['grid_end'] ?? $end));
            $sundayOff = ($_GET['sunday_off'] ?? '1') === '1';
            $dates = $this->rangeDates($gridStart, $gridEnd);
            $holidays = $this->configuredHolidays();

            $staff = Database::fetchAll('SELECT id, full_name, title FROM staff_profiles ORDER BY full_name');

            $recordRows = Database::fetchAll(
                'SELECT sar.staff_profile_id, sar.attendance_date, sar.status
                 FROM staff_attendance_records sar
                 WHERE sar.attendance_date BETWEEN ? AND ?',
                'ss',
                [$dates[0], end($dates)]
            );
            $byStaffDate = [];
            foreach ($recordRows as $r) {
                $byStaffDate[(int)$r['staff_profile_id']][$r['attendance_date']] = $r['status'];
            }

            $xlsx = new XlsxGridWriter('Staff Attendance');
            $header = ['Staff Name', 'Designation'];
            foreach ($dates as $d) {
                $header[] = date('d', strtotime($d)) . '-' . date('D', strtotime($d));
            }
            $header[] = 'Present';
            $header[] = 'Absent';
            $header[] = 'Leave';

            // A "grouped month" row above the day/weekday header row, so a range that
            // spans more than one month — or more than one year — doesn't leave every
            // "01-Wed"-style column ambiguous about which month/year it's actually for.
            $monthGroup = $this->monthGroupHeader($dates);
            $xlsx->setFreezeRows(2);
            $xlsx->addHeaderRow(array_merge(array_fill(0, 2, ''), $monthGroup['labels'], ['', '', '']));
            foreach ($monthGroup['spans'] as $span) {
                $xlsx->mergeCells(0, 2 + $span['startCol'], 2 + $span['endCol']);
            }
            $xlsx->addHeaderRow($header);
            $xlsx->setColumnWidths(array_merge([22, 16], array_fill(0, count($dates), 6), [9, 9, 9]));

            foreach ($staff as $sp) {
                $row = [
                    XlsxGridWriter::cell($sp['full_name'] ?? ''),
                    XlsxGridWriter::cell($sp['title'] ?? ''),
                ];
                $presentCount = 0;
                $absentCount = 0;
                $leaveCount = 0;
                foreach ($dates as $d) {
                    if (isset($holidays[$d])) {
                        $code = 'H';
                    } elseif ($sundayOff && date('N', strtotime($d)) == 7) {
                        $code = 'H';
                    } else {
                        $code = $this->gridStatusCode($byStaffDate[(int)$sp['id']][$d] ?? null);
                    }
                    $row[] = XlsxGridWriter::cell($code, $code !== '' ? $code : null);
                    if ($code === 'P' || $code === 'L') {
                        $presentCount++;
                    } elseif ($code === 'A') {
                        $absentCount++;
                    } elseif ($code === 'E') {
                        $leaveCount++;
                    }
                }
                $row[] = XlsxGridWriter::cell((string)$presentCount, null, true, true);
                $row[] = XlsxGridWriter::cell((string)$absentCount, null, true, true);
                $row[] = XlsxGridWriter::cell((string)$leaveCount, null, true, true);
                $xlsx->addRow($row);
            }

            $xlsx->download('staff_attendance_register_' . $dates[0] . '_to_' . end($dates) . '.xlsx');
        }

        // Export pulls every matching row; the on-screen table is paginated below.
        if (($_GET['export'] ?? '') === 'csv') {
            $this->requirePermission('reports.export');

            $exportRows = Database::fetchAll(
                'SELECT sar.attendance_date,
                        sar.status,
                        sp.full_name,
                        sp.title
                 FROM staff_attendance_records sar
                 JOIN staff_profiles sp ON sp.id = sar.staff_profile_id
                 WHERE sar.attendance_date BETWEEN ? AND ?
                 ORDER BY sar.attendance_date DESC, sp.full_name',
                'ss',
                [$start, $end]
            );

            header('Content-Type: text/csv; charset=UTF-8');
            header('Content-Disposition: attachment; filename="staff_attendance_' . $start . '_to_' . $end . '.csv"');
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv_safe($out, ['date', 'staff', 'title', 'status']);
            foreach ($exportRows as $r) {
                fputcsv_safe($out, [
                    $r['attendance_date'],
                    $r['full_name'],
                    $r['title'],
                    $r['status'],
                ]);
            }
            fclose($out);
            exit;
        }

        $summaryRow = Database::fetchOne(
            'SELECT COUNT(*) AS total,
                    SUM(CASE WHEN sar.status = "present" THEN 1 ELSE 0 END) AS present_count,
                    SUM(CASE WHEN sar.status = "absent" THEN 1 ELSE 0 END) AS absent_count,
                    SUM(CASE WHEN sar.status = "late" THEN 1 ELSE 0 END) AS late_count,
                    SUM(CASE WHEN sar.status = "excused" THEN 1 ELSE 0 END) AS excused_count,
                    SUM(CASE WHEN sar.status = "holiday" THEN 1 ELSE 0 END) AS holiday_count
             FROM staff_attendance_records sar
             WHERE sar.attendance_date BETWEEN ? AND ?',
            'ss',
            [$start, $end]
        );
        $summary = [
            'total' => (int)($summaryRow['total'] ?? 0),
            'present' => (int)($summaryRow['present_count'] ?? 0),
            'absent' => (int)($summaryRow['absent_count'] ?? 0),
            'late' => (int)($summaryRow['late_count'] ?? 0),
            'excused' => (int)($summaryRow['excused_count'] ?? 0),
            'holiday' => (int)($summaryRow['holiday_count'] ?? 0),
        ];

        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 50;
        $offset = ($page - 1) * $perPage;
        $totalPages = max(1, (int)ceil($summary['total'] / $perPage));
        if ($page > $totalPages) {
            $page = $totalPages;
            $offset = ($page - 1) * $perPage;
        }

        $rows = Database::fetchAll(
            'SELECT sar.attendance_date,
                    sar.status,
                    sp.full_name,
                    sp.title
             FROM staff_attendance_records sar
             JOIN staff_profiles sp ON sp.id = sar.staff_profile_id
             WHERE sar.attendance_date BETWEEN ? AND ?
             ORDER BY sar.attendance_date DESC, sp.full_name
             LIMIT ? OFFSET ?',
            'ssii',
            [$start, $end, $perPage, $offset]
        );

        $this->render('reports/staff_attendance', [
            'title' => 'Staff Attendance Report',
            'start_date' => $start,
            'end_date' => $end,
            'rows' => $rows,
            'summary' => $summary,
            'page' => $page,
            'perPage' => $perPage,
            'totalPages' => $totalPages,
        ]);
    }

    public function customGeneratorAction(): void
    {
        Auth::requireLoginOrToken();
        $this->requirePermission('reports.view');

        $dataset = (string)($_GET['dataset'] ?? 'students');
        $export = (string)($_GET['export'] ?? '');

        $start = trim((string)($_GET['start_date'] ?? ''));
        $end = trim((string)($_GET['end_date'] ?? ''));

        // Each dataset's date column, used to actually apply the start/end filters below.
        $dateColumns = [
            'students' => 'created_at',
            'invoices' => 'issued_at',
            'complaints' => 'created_at',
        ];
        $tables = [
            'students' => ['table' => 'students', 'cols' => 'id, admission_no, first_name, last_name, created_at'],
            'invoices' => ['table' => 'fee_invoices', 'cols' => 'invoice_no, student_id, issued_at, status, total_due'],
            'complaints' => ['table' => 'complaints', 'cols' => 'id, student_id, title, status, created_at'],
        ];

        $headers = [];
        $rows = [];
        $total = 0;
        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 100;
        $totalPages = 1;

        if (isset($tables[$dataset])) {
            $headers = array_map('trim', explode(',', $tables[$dataset]['cols']));
            $table = $tables[$dataset]['table'];
            $dateCol = $dateColumns[$dataset];

            $where = '';
            $types = '';
            $params = [];
            if ($start !== '') {
                $where .= ' AND ' . $dateCol . ' >= ?';
                $types .= 's';
                $params[] = $start . ' 00:00:00';
            }
            if ($end !== '') {
                $where .= ' AND ' . $dateCol . ' <= ?';
                $types .= 's';
                $params[] = $end . ' 23:59:59';
            }
            $where = $where !== '' ? 'WHERE 1=1' . $where : '';

            $countRow = Database::fetchOne(
                "SELECT COUNT(*) AS total FROM {$table} {$where}",
                $types,
                $params
            );
            $total = (int)($countRow['total'] ?? 0);

            if ($export === 'csv') {
                // A CSV export should contain the full filtered set, not a capped preview --
                // no LIMIT here at all.
                $rows = Database::fetchAll(
                    "SELECT {$tables[$dataset]['cols']} FROM {$table} {$where} ORDER BY id DESC",
                    $types,
                    $params
                );
            } else {
                $totalPages = max(1, (int)ceil($total / $perPage));
                if ($page > $totalPages) {
                    $page = $totalPages;
                }
                $offset = ($page - 1) * $perPage;
                $rows = Database::fetchAll(
                    "SELECT {$tables[$dataset]['cols']} FROM {$table} {$where} ORDER BY id DESC LIMIT ? OFFSET ?",
                    $types . 'ii',
                    array_merge($params, [$perPage, $offset])
                );
            }
        }

        if ($export === 'csv') {
            $this->requirePermission('reports.export');
            header('Content-Type: text/csv; charset=UTF-8');
            header('Content-Disposition: attachment; filename="custom_report.csv"');
            $out = fopen('php://output', 'w');
            fputcsv_safe($out, $headers);
            foreach ($rows as $r) {
                $line = [];
                foreach ($headers as $h) {
                    $line[] = $r[$h] ?? '';
                }
                fputcsv_safe($out, $line);
            }
            fclose($out);
            exit;
        }

        $this->render('reports/custom_generator', [
            'title' => 'Custom Report Generator',
            'dataset' => $dataset,
            'start_date' => $start,
            'end_date' => $end,
            'headers' => $headers,
            'rows' => $rows,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'totalPages' => $totalPages,
        ]);
    }
}