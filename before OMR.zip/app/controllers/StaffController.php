<?php

class StaffController extends Controller
{
    public function indexAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission('staff.view');

        // The old tile-grid submenu page is gone — the sidebar's Staff & HR flyout now goes
        // straight to each sub-page, so this route just forwards to the most-used one.
        redirect_route('staff/staffProfiles');
    }

    public function staffProfilesAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['staff.manage', 'staff.profiles']);

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            $this->requireCsrf();
            $fullName = trim((string)($_POST['full_name'] ?? ''));
            $title = trim((string)($_POST['title'] ?? ''));
            $phone = trim((string)($_POST['phone'] ?? ''));
            $address = trim((string)($_POST['address'] ?? ''));
            $basicSalary = (float)($_POST['basic_salary'] ?? 0);
            if ($fullName !== '') {
                Database::execute(
                    'INSERT INTO staff_profiles (user_id, staff_code, full_name, title, phone, address, basic_salary, created_at)
                     VALUES (NULL, NULL, ?, ?, ?, ?, ?, NOW())',
                    'ssssd',
                    [
                        $fullName,
                        $title !== '' ? $title : null,
                        $phone !== '' ? $phone : null,
                        $address !== '' ? $address : null,
                        $basicSalary,
                    ]
                );
                $staffId = (int)Database::lastInsertId();
                $message = 'Staff profile created';
                log_activity('staff.create', 'Created staff profile "' . $fullName . '"');

                // Handle optional photo upload
                if (!empty($_FILES['photo']['tmp_name']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                    $this->saveStaffPhoto($staffId, $_FILES['photo']);
                }

                if (!empty($_POST['create_login']) && $staffId > 0) {
                    require_once __DIR__ . '/../services/UserAccountService.php';
                    $roleName = trim((string)($_POST['login_role'] ?? 'Teacher'));
                    $roleId = UserAccountService::roleIdByName($roleName) ?? UserAccountService::roleIdByName('Teacher');
                    if ($roleId) {
                        $username = trim((string)($_POST['login_username'] ?? ''));
                        if ($username === '') {
                            $username = $fullName;
                        }
                        $username = UserAccountService::uniqueUsername($username);
                        $password = trim((string)($_POST['login_password'] ?? ''));
                        if ($password === '') {
                            $password = UserAccountService::randomPassword();
                        }
                        $email = trim((string)($_POST['login_email'] ?? ''));
                        UserAccountService::createAndLink('staff_profiles', $staffId, $username, $email, $password, $roleId);
                        $message = 'Staff profile created — login: ' . $username . ' / ' . $password . ' (share this with them now; it will not be shown again)';
                    }
                }

                $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
                $searchQs = trim((string)($_GET['q'] ?? ''));
                $qs = 'route=' . rawurlencode('staff/staffProfiles');
                if ($searchQs !== '') {
                    $qs .= '&' . http_build_query(['q' => $searchQs]);
                }
                redirect('/index.php?' . $qs);
                return;
            }
            $error = 'Full name required';
        }

        $search = trim((string)($_GET['q'] ?? ''));
        $like = '%' . $search . '%';
        $staff = Database::fetchAll(
            'SELECT * FROM staff_profiles
             WHERE (? = \'\' OR full_name LIKE ?)
             ORDER BY full_name
             LIMIT 200',
            'ss',
            [$search, $like]
        );

        $this->render('staff/staff_profiles', [
            'title' => 'Staff Profiles',
            'staff' => $staff,
            'search' => $search,
            'error' => $error ?? null,
        ]);
    }

    /** Re-run the staff-profile search and render the list partial (used by staffProfileDeleteAction). */
    private function renderStaffProfileListPartial(string $search): string
    {
        $like = '%' . $search . '%';
        $staff = Database::fetchAll(
            'SELECT * FROM staff_profiles
             WHERE (? = \'\' OR full_name LIKE ?)
             ORDER BY full_name
             LIMIT 200',
            'ss',
            [$search, $like]
        );

        return $this->renderPartial('staff/_staff_profile_list', [
            'staff' => $staff,
            'search' => $search,
        ]);
    }

    /** Save/replace a staff member's uploaded photo (mirrors the student photo-upload convention). */
    private function saveStaffPhoto(int $staffId, array $file): void
    {
        $allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
        $mimeType = mime_content_type($file['tmp_name']);
        if (!in_array($mimeType, $allowed, true)) {
            return;
        }
        $uploadDir = dirname(__DIR__, 2) . '/public/uploads/staff/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        $ext = ($mimeType === 'image/jpeg') ? 'jpg' : explode('/', $mimeType)[1];
        // Remove any previous photo (different extension) before saving the new one
        foreach (glob($uploadDir . $staffId . '.*') ?: [] as $old) {
            @unlink($old);
        }
        move_uploaded_file($file['tmp_name'], $uploadDir . $staffId . '.' . $ext);
    }

    /** Update a staff profile's basic details and/or photo. */
    public function staffProfileUpdateAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['staff.manage', 'staff.profiles']);
        $this->requireCsrf();

        $id = (int)($_POST['id'] ?? 0);
        $search = trim((string)($_POST['q'] ?? ''));
        $fullName = trim((string)($_POST['full_name'] ?? ''));

        if ($id > 0 && $fullName !== '') {
            $title = trim((string)($_POST['title'] ?? ''));
            $phone = trim((string)($_POST['phone'] ?? ''));
            $address = trim((string)($_POST['address'] ?? ''));

            Database::execute(
                'UPDATE staff_profiles SET full_name = ?, title = ?, phone = ?, address = ? WHERE id = ?',
                'ssssi',
                [$fullName, $title !== '' ? $title : null, $phone !== '' ? $phone : null, $address !== '' ? $address : null, $id]
            );

            if (!empty($_FILES['photo']['tmp_name']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                $this->saveStaffPhoto($id, $_FILES['photo']);
            }

            $message = 'Staff profile updated';
            log_activity('staff.update', 'Updated staff profile "' . $fullName . '" (#' . $id . ')');
            if ($this->wantsJson()) {
                $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderStaffProfileListPartial($search)]);
            }
            $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
        }

        $qs = 'route=' . rawurlencode('staff/staffProfiles');
        if ($search !== '') {
            $qs .= '&' . http_build_query(['q' => $search]);
        }
        redirect('/index.php?' . $qs);
    }

    public function staffProfileDeleteAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['staff.manage', 'staff.profiles']);
        $this->requireCsrf();

        $id = (int)($_POST['id'] ?? 0);
        $search = trim((string)($_POST['q'] ?? ''));
        if ($id > 0) {
            $existing = Database::fetchOne('SELECT full_name FROM staff_profiles WHERE id = ?', 'i', [$id]);
            Database::execute('DELETE FROM staff_profiles WHERE id = ?', 'i', [$id]);
            $message = 'Staff profile deleted';
            log_activity('staff.delete', 'Deleted staff profile "' . ($existing['full_name'] ?? ('#' . $id)) . '"');
            if ($this->wantsJson()) {
                $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderStaffProfileListPartial($search)]);
            }
            $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
        }
        $qs = 'route=' . rawurlencode('staff/staffProfiles');
        if ($search !== '') {
            $qs .= '&' . http_build_query(['q' => $search]);
        }
        redirect('/index.php?' . $qs);
    }

    /** Set a staff member's basic salary — Payroll auto-fills this amount when creating their monthly salary (still editable). */
    public function setBasicSalaryAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['staff.manage', 'staff.set_salary']);
        $this->requireCsrf();

        $id = (int)($_POST['id'] ?? 0);
        $basicSalary = (float)($_POST['basic_salary'] ?? 0);
        $search = trim((string)($_POST['q'] ?? ''));

        if ($id > 0) {
            Database::execute('UPDATE staff_profiles SET basic_salary = ? WHERE id = ?', 'di', [$basicSalary, $id]);
            $message = 'Basic salary updated';
            log_activity('staff.set_salary', 'Set basic salary for staff #' . $id . ' to Rs ' . number_format($basicSalary, 2));
            if ($this->wantsJson()) {
                $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderStaffProfileListPartial($search)]);
            }
            $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
        }
        $qs = 'route=' . rawurlencode('staff/staffProfiles');
        if ($search !== '') {
            $qs .= '&' . http_build_query(['q' => $search]);
        }
        redirect('/index.php?' . $qs);
    }

    /** Admin assigns which classes a staff member may collect fees for in the Teacher Portal. */
    public function feeCollectorsAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['staff.manage', 'fee_collection_assignments.manage']);

        require_once __DIR__ . '/../models/StaffFeeClassModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';

        $staffId = (int)($_GET['staff_profile_id'] ?? ($_POST['staff_profile_id'] ?? 0));

        // The per-row "quick assign" form on the all-classes overview (shown when no
        // teacher is selected) posts this flag so we know to redirect back to the
        // overview instead of to a specific teacher's page after saving.
        $fromOverview = !empty($_POST['from_overview']);

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            $this->requireCsrf();
            $classSectionId = (int)($_POST['class_section_id'] ?? 0);
            $mode = (string)($_POST['mode'] ?? 'assign');
            if ($staffId > 0 && $classSectionId > 0) {
                if ($mode === 'unassign') {
                    StaffFeeClassModel::unassign($staffId, $classSectionId);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Class removed from fee collection'];
                } else {
                    $user = Auth::currentUser();
                    StaffFeeClassModel::assign($staffId, $classSectionId, $user['id'] ?? null);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Class assigned for fee collection'];
                }
            } elseif ($classSectionId > 0) {
                // Overview "Assign" button submitted with no teacher chosen in its dropdown.
                $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Select a teacher before assigning this class'];
            }

            if ($fromOverview) {
                redirect('/index.php?route=' . rawurlencode('staff/feeCollectors'));
            } else {
                redirect('/index.php?route=' . rawurlencode('staff/feeCollectors') . '&staff_profile_id=' . $staffId);
            }
            return;
        }

        $staffOptions = Database::fetchAll('SELECT id, full_name, title FROM staff_profiles ORDER BY full_name');
        $classSections = ClassSectionModel::allOptions();
        $assignedIds = $staffId > 0 ? StaffFeeClassModel::getClassSectionIdsForStaff($staffId) : [];

        // No teacher picked yet: build the all-classes overview so admins can see at a
        // glance which classes already have a fee collector and which don't, instead of
        // checking one teacher at a time.
        $assignmentsByClassSection = $staffId > 0 ? [] : StaffFeeClassModel::getAllAssignmentsByClassSection();

        $this->render('staff/fee_collectors', [
            'title' => 'Fee Collection Assignments',
            'staffOptions' => $staffOptions,
            'classSections' => $classSections,
            'staffId' => $staffId,
            'assignedIds' => $assignedIds,
            'assignmentsByClassSection' => $assignmentsByClassSection,
        ]);
    }

    public function staffAttendanceAction(): void
    {
        require_once __DIR__ . '/../models/StaffAttendanceModel.php';

        Auth::requireLogin();
        $this->requirePermission(['staff.manage', 'staff.attendance_take']);

        $error = null;
        $date = (string)($_POST['attendance_date'] ?? $_GET['attendance_date'] ?? date('Y-m-d'));
        $search = trim((string)($_POST['q'] ?? $_GET['q'] ?? ''));

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();

            if (!empty($_POST['mark_holiday'])) {
                $user = Auth::currentUser();
                $byUserId = (int)($user['id'] ?? 0);
                try {
                    $count = StaffAttendanceModel::markAllHoliday($date, $search, $byUserId);
                    $message = "Marked $count staff member(s) as Holiday for $date";
                    log_activity('staff.attendance_holiday', $message);
                    if ($this->wantsJson()) {
                        $this->jsonResponse(['success' => true, 'message' => $message]);
                    }
                    $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
                    $qs = 'route=' . rawurlencode('staff/staffAttendance') . '&attendance_date=' . urlencode($date);
                    if ($search !== '') {
                        $qs .= '&' . http_build_query(['q' => $search]);
                    }
                    redirect('/index.php?' . $qs);
                    return;
                } catch (Throwable $e) {
                    $error = $e->getMessage();
                    if ($this->wantsJson()) {
                        $this->jsonResponse(['success' => false, 'message' => $error], 422);
                    }
                }
            } else {
            $statusByStaffId = $_POST['status'] ?? [];
            if (!is_array($statusByStaffId)) {
                $statusByStaffId = [];
            }
            $user = Auth::currentUser();
            $byUserId = (int)($user['id'] ?? 0);
            try {
                StaffAttendanceModel::save($date, $statusByStaffId, $byUserId);
                $message = 'Attendance saved';
                log_activity('staff.attendance_take', 'Recorded staff attendance for ' . $date . ' (' . count($statusByStaffId) . ' staff)');
                if ($this->wantsJson()) {
                    $this->jsonResponse(['success' => true, 'message' => $message]);
                }
                $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
                $qs = 'route=' . rawurlencode('staff/staffAttendance') . '&attendance_date=' . urlencode($date);
                if ($search !== '') {
                    $qs .= '&' . http_build_query(['q' => $search]);
                }
                redirect('/index.php?' . $qs);
                return;
            } catch (Throwable $e) {
                $error = $e->getMessage();
                if ($this->wantsJson()) {
                    $this->jsonResponse(['success' => false, 'message' => $error], 422);
                }
            }
            }
        }

        $rows = StaffAttendanceModel::listByDate($date, $search, 200, 0);
        $this->render('staff/staff_attendance', [
            'title' => 'Staff Attendance',
            'error' => $error,
            'attendance_date' => $date,
            'search' => $search,
            'rows' => $rows,
            'isConfiguredHoliday' => is_configured_holiday($date),
        ]);
    }

    public function leavesAction(): void
    {
        require_once __DIR__ . '/../models/LeaveRequestModel.php';

        Auth::requireLogin();
        $this->requirePermission(['staff.manage', 'staff.leaves']);

        $error = null;

        $staffOptions = Database::fetchAll('SELECT id, full_name, title FROM staff_profiles ORDER BY full_name LIMIT 200');
        $status = trim((string)($_GET['status'] ?? ''));
        $q = trim((string)($_GET['q'] ?? ''));

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $action = (string)($_POST['action'] ?? 'create');
            $user = Auth::currentUser();
            $byUserId = (int)($user['id'] ?? 0);
            if ($action === 'create') {
                $staffProfileId = (int)($_POST['staff_profile_id'] ?? 0);
                $fromDate = trim((string)($_POST['from_date'] ?? ''));
                $toDate = trim((string)($_POST['to_date'] ?? ''));
                $leaveType = trim((string)($_POST['leave_type'] ?? 'leave'));
                $note = trim((string)($_POST['note'] ?? ''));
                if ($staffProfileId <= 0 || $fromDate === '' || $toDate === '') {
                    $error = 'Staff and date range required';
                } else {
                    try {
                        LeaveRequestModel::createForStaff([
                            'staff_profile_id' => $staffProfileId,
                            'leave_type' => $leaveType,
                            'from_date' => $fromDate,
                            'to_date' => $toDate,
                            'note' => $note,
                        ], $byUserId);
                        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Leave request submitted'];
                        $this->redirectToLeaves($status, $q);
                        return;
                    } catch (RuntimeException $e) {
                        $error = $e->getMessage();
                    }
                }
            } elseif ($action === 'approve') {
                // Approvals are handled by separate action to keep forms simpler.
            }
        }

        $leaves = LeaveRequestModel::list($status, $q, 100, 0, 'staff');

        $this->render('staff/leaves', [
            'title' => 'Leave Requests',
            'error' => $error,
            'status' => $status,
            'q' => $q,
            'leaves' => $leaves,
            'staffOptions' => $staffOptions,
        ]);
    }

    /** Re-run the leave list query for given filters and render the list partial. */
    private function renderLeaveListPartial(string $status, string $q): string
    {
        require_once __DIR__ . '/../models/LeaveRequestModel.php';
        $leaves = LeaveRequestModel::list($status, $q, 100, 0, 'staff');
        return $this->renderPartial('staff/_leave_list', [
            'leaves' => $leaves,
            'q' => $q,
            'status' => $status,
        ]);
    }

    private function redirectToLeaves(string $status, string $q): void
    {
        $qs = 'route=' . rawurlencode('staff/leaves');
        $extra = array_filter(['status' => $status, 'q' => $q], fn($v) => $v !== '');
        if ($extra) {
            $qs .= '&' . http_build_query($extra);
        }
        redirect('/index.php?' . $qs);
    }

    public function approveLeaveAction(): void
    {
        require_once __DIR__ . '/../models/LeaveRequestModel.php';
        require_once __DIR__ . '/../models/NotificationModel.php';

        Auth::requireLogin();
        $this->requirePermission(['staff.manage', 'staff.leave_decision']);
        $this->requireCsrf();

        $leaveRequestId = (int)($_POST['leave_request_id'] ?? 0);
        $decision = (string)($_POST['decision'] ?? 'approved');
        $decisionNote = trim((string)($_POST['decision_note'] ?? ''));
        $status = trim((string)($_POST['status'] ?? ''));
        $q = trim((string)($_POST['q'] ?? ''));

        $user = Auth::currentUser();
        $byUserId = (int)($user['id'] ?? 0);

        if ($leaveRequestId > 0 && in_array($decision, ['approved', 'rejected'], true)) {
            $leaveRequest = LeaveRequestModel::find($leaveRequestId);
            LeaveRequestModel::approve($leaveRequestId, $decision, $decisionNote, $byUserId);
            $message = 'Leave updated';
            log_activity('staff.leave_decision', ucfirst($decision) . ' leave request #' . $leaveRequestId);

            // Notify the teacher back — the leave-apply flow already notifies
            // whoever can approve, but the requester was never told the outcome.
            if ($leaveRequest) {
                $staffUser = Database::fetchOne(
                    'SELECT user_id FROM staff_profiles WHERE id = ? LIMIT 1',
                    'i',
                    [(int)$leaveRequest['staff_profile_id']]
                );
                if ($staffUser && !empty($staffUser['user_id'])) {
                    $verb = $decision === 'approved' ? 'approved' : 'rejected';
                    $msg = 'Your ' . ($leaveRequest['leave_type'] ?? 'leave') . ' request ('
                        . ($leaveRequest['from_date'] ?? '') . ' to ' . ($leaveRequest['to_date'] ?? '') . ') was ' . $verb . '.';
                    if ($decisionNote !== '') {
                        $msg .= ' Note: ' . $decisionNote;
                    }
                    NotificationModel::create(
                        (int)$staffUser['user_id'],
                        'leave_decision',
                        'Leave request ' . $verb,
                        $msg,
                        route_url('portal/index')
                    );
                }
            }

            if ($this->wantsJson()) {
                $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderLeaveListPartial($status, $q)]);
            }
            $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
        }
        $this->redirectToLeaves($status, $q);
    }

    /** JSON for the scorecard form: what this staff member did in the month. */
    public function performanceEvidenceAction(): void
    {
        require_once __DIR__ . '/../models/PerformanceModel.php';
        Auth::requireLogin();
        $this->requirePermission(['staff.manage', 'staff.performance']);

        $staffId = (int)($_GET['staff_profile_id'] ?? 0);
        $ym = (string)($_GET['month'] ?? '');
        if ($staffId <= 0 || !preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $ym)) {
            $this->jsonResponse(['error' => 'Choose a staff member and a month'], 400);
            return;
        }
        $data = PerformanceModel::evidence($staffId, $ym);
        if (!$data) {
            $this->jsonResponse(['error' => 'Staff member not found'], 404);
            return;
        }
        $data['labels'] = array_map(fn($i) => ['label' => $i[0], 'help' => $i[1]], PerformanceModel::INDICATORS);
        $existing = Database::fetchOne('SELECT id, summary FROM performance_reports WHERE staff_profile_id = ? AND period_start = ? ORDER BY id DESC LIMIT 1', 'is', [$staffId, $ym . '-01']);
        $data['saved'] = null;
        if ($existing) {
            $data['saved'] = ['summary' => (string)$existing['summary'], 'scores' => PerformanceModel::scoresFor([(int)$existing['id']])[(int)$existing['id']] ?? []];
        }
        $this->jsonResponse($data);
    }

    public function performanceAction(): void
    {
        require_once __DIR__ . '/../models/PerformanceModel.php';

        Auth::requireLogin();
        $this->requirePermission(['staff.manage', 'staff.performance']);

        $error = null;
        $q = trim((string)($_GET['q'] ?? ''));
        $staffOptions = Database::fetchAll('SELECT id, full_name, title FROM staff_profiles ORDER BY full_name LIMIT 200');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $deleteId = (int)($_POST['delete_report_id'] ?? 0);
            if ($deleteId > 0) {
                PerformanceModel::delete($deleteId);
                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Performance report deleted'];
                redirect('/index.php?route=' . rawurlencode('staff/performance') . ($q !== '' ? '&' . http_build_query(['q' => $q]) : ''));
                return;
            }
            $staffProfileId = (int)($_POST['staff_profile_id'] ?? 0);
            $ym = trim((string)($_POST['month'] ?? ''));
            $summary = trim((string)($_POST['summary'] ?? ''));
            $scores = [];
            foreach (array_keys(PerformanceModel::INDICATORS) as $key) {
                $raw = (string)($_POST['score'][$key] ?? '');
                $scores[$key] = [
                    'score' => ($raw === '' || $raw === 'na') ? null : (int)$raw,
                    'note' => (string)($_POST['note'][$key] ?? ''),
                ];
            }
            $scored = array_filter($scores, fn($c) => $c['score'] !== null);
            if ($staffProfileId <= 0 || !preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $ym)) {
                $error = 'Choose a staff member and a month';
            } elseif (!$scored) {
                $error = 'Give a score to at least one indicator';
            } else {
                $updated = PerformanceModel::saveMonthly($staffProfileId, $ym, $scores, $summary, (int)(Auth::currentUser()['id'] ?? 0));
                $_SESSION['flash'] = ['type' => 'success', 'message' => $updated ? 'Performance report for that month updated' : 'Performance report saved'];
                $qs = 'route=' . rawurlencode('staff/performance');
                if ($q !== '') {
                    $qs .= '&' . http_build_query(['q' => $q]);
                }
                redirect('/index.php?' . $qs);
                return;
            }
        }

        $reports = PerformanceModel::list($q, 100, 0);
        $scoresByReport = PerformanceModel::scoresFor(array_map('intval', array_column($reports, 'id')));
        $this->render('staff/performance', [
            'title' => 'Performance Reports',
            'error' => $error,
            'q' => $q,
            'staffOptions' => $staffOptions,
            'reports' => $reports,
            'scoresByReport' => $scoresByReport,
        ]);
    }

    /** Everything the payroll list partial needs: rows with status, totals, status counts and the year strip. */
    private function payrollViewData(int $month, int $year, string $q): array
    {
        require_once __DIR__ . '/../models/StaffPayrollModel.php';
        $rows = StaffPayrollModel::listPayroll($month, $year, $q);
        $payments = StaffPayrollModel::paymentsForDetails(array_column($rows, 'detail_id'));

        $summary = ['staff' => count($rows), 'with_salary' => 0, 'net' => 0.0, 'paid' => 0.0, 'pending' => 0.0];
        $counts = ['all' => count($rows), 'not_generated' => 0, 'unpaid' => 0, 'partial' => 0, 'paid' => 0];

        foreach ($rows as &$r) {
            $r['net'] = (float)($r['net_amount'] ?? 0);
            $r['paid'] = (float)($r['total_paid'] ?? 0);
            $r['balance'] = max(0.0, $r['net'] - $r['paid']);
            $r['payments'] = $payments[(int)($r['detail_id'] ?? 0)] ?? [];

            if (empty($r['detail_id'])) {
                $r['status'] = 'not_generated';
            } elseif ($r['balance'] < 0.005) {
                $r['status'] = 'paid';
            } elseif ($r['paid'] > 0) {
                $r['status'] = 'partial';
            } else {
                $r['status'] = 'unpaid';
            }
            $counts[$r['status']]++;

            if (!empty($r['detail_id'])) {
                $summary['with_salary']++;
                $summary['net'] += $r['net'];
                $summary['paid'] += min($r['paid'], $r['net']);
                $summary['pending'] += $r['balance'];
            }
        }
        unset($r);

        $monthNames = [1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
                       7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'];

        return [
            'rows' => $rows,
            'summary' => $summary,
            'counts' => $counts,
            'yearOverview' => StaffPayrollModel::yearOverview($year),
            'month' => $month,
            'year' => $year,
            'monthName' => $monthNames[$month] ?? (string)$month,
            'q' => $q,
        ];
    }

    private function renderPayrollListPartial(int $month, int $year, string $q): string
    {
        return $this->renderPartial('staff/_payroll_list', $this->payrollViewData($month, $year, $q));
    }

    public function payrollAction(): void
    {
        require_once __DIR__ . '/../models/StaffPayrollModel.php';
        Auth::requireLogin();
        $this->requirePermission(['staff.manage', 'staff.payroll']);

        $error = null;
        $month = (int)($_POST['salary_month'] ?? $_GET['salary_month'] ?? date('n'));
        $year = (int)($_POST['salary_year'] ?? $_GET['salary_year'] ?? date('Y'));
        $q = trim((string)($_POST['q'] ?? $_GET['q'] ?? ''));

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $action = (string)($_POST['action'] ?? 'detail');
            $user = Auth::currentUser();
            $byUserId = (int)($user['id'] ?? 0);

            if ($action === 'create_detail') {
    $staffProfileId = (int)($_POST['staff_profile_id'] ?? 0);
    $gross = (float)($_POST['gross_amount'] ?? 0);
    $deductions = (float)($_POST['deductions'] ?? 0);
    $net = $gross - $deductions;

    $salaryCreatedDate = trim((string)($_POST['salary_created_date'] ?? date('Y-m-d')));

    if ($staffProfileId <= 0 || $gross <= 0) {
        $error = 'Staff and gross amount required';
    } else {
        StaffPayrollModel::createSalaryDetail(
            $staffProfileId,
            $month,
            $year,
            $gross,
            $deductions,
            $net,
            $byUserId,
            $salaryCreatedDate
        );

        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Salary detail saved'];
        redirect('/index.php?route=staff/payroll&salary_month=' . $month . '&salary_year=' . $year . ($q !== '' ? '&' . http_build_query(['q' => $q]) : ''));
        return;
    }
} elseif ($action === 'pay') {

    $salaryDetailId = (int)($_POST['staff_salary_detail_id'] ?? 0);
    $amount = (float)($_POST['amount'] ?? 0);
    $method = trim((string)($_POST['method'] ?? 'cash'));
    $note = trim((string)($_POST['note'] ?? ''));

    if ($salaryDetailId <= 0) {
        $error = 'Invalid salary detail';
    } else {

        // ✅ Get total already paid
        $row = Database::fetchOne(
            'SELECT COALESCE(SUM(amount),0) AS paid 
             FROM staff_salary_payments 
             WHERE staff_salary_detail_id = ?',
            'i',
            [$salaryDetailId]
        );

        $paid = (float)($row['paid'] ?? 0);

        // ✅ Get net salary
        $detail = Database::fetchOne(
            'SELECT net_amount FROM staff_salary_details WHERE id = ?',
            'i',
            [$salaryDetailId]
        );

        if (!$detail) {
            $error = 'Salary detail not found';
        } else {

            $net = (float)$detail['net_amount'];
            $remaining = $net - $paid;

            // ❌ VALIDATIONS
            if ($amount <= 0) {
                $error = 'Payment amount must be greater than 0';
            } elseif ($amount > $remaining + 0.005) {
                $error = 'Payment exceeds remaining salary amount';
            } else {

                // ✅ SAFE INSERT
                $paidDate = trim((string)($_POST['paid_date'] ?? date('Y-m-d')));

StaffPayrollModel::recordPayment(
    $salaryDetailId,
    $amount,
    $method,
    $note,
    $byUserId,
    $paidDate
);

                log_activity('staff.payroll_payment', 'Paid Rs ' . number_format($amount, 2) . ' salary via ' . $method . ' (detail #' . $salaryDetailId . ')');

                $_SESSION['flash'] = [
                    'type' => 'success',
                    'message' => 'Payment recorded successfully'
                ];

                if ($this->wantsJson()) {
                    $this->jsonResponse(['success' => true, 'message' => 'Payment recorded successfully', 'html' => $this->renderPayrollListPartial($month, $year, $q)]);
                }

                // ✅ KEEP MONTH/YEAR AFTER REDIRECT
                redirect('/index.php?route=staff/payroll&salary_month=' . $month . '&salary_year=' . $year . ($q !== '' ? '&' . http_build_query(['q' => $q]) : ''));
                return;
            }
        }
    }
} elseif ($action === 'generate_all') {
    list($created, $skipped) = StaffPayrollModel::generateForMonth($month, $year, $byUserId, date('Y-m-d'));
    $msg = $created . ' salary record(s) created for ' . $month . '/' . $year . '.';
    if ($skipped > 0) {
        $msg .= ' ' . $skipped . ' staff skipped (no previous salary or basic salary to copy) — use "Set salary" for them.';
    }
    if ($created > 0) {
        log_activity('staff.payroll_generate', 'Generated ' . $created . ' salary records for ' . $month . '/' . $year);
    }
    $_SESSION['flash'] = ['type' => $created > 0 ? 'success' : 'warning', 'message' => $msg];
    redirect('/index.php?route=staff/payroll&salary_month=' . $month . '&salary_year=' . $year);
    return;
} elseif ($action === 'bulk_pay') {
    $ids = array_values(array_unique(array_filter(array_map('intval', (array)($_POST['detail_ids'] ?? [])))));
    $method = in_array($_POST['method'] ?? '', ['cash', 'bank', 'card'], true) ? (string)$_POST['method'] : 'cash';
    $note = trim((string)($_POST['note'] ?? ''));
    $paidDate = trim((string)($_POST['paid_date'] ?? date('Y-m-d')));

    if (!$ids) {
        $error = 'Select at least one staff member to pay';
    } else {
        $done = 0;
        $total = 0.0;
        foreach ($ids as $detailId) {
            $detail = Database::fetchOne('SELECT net_amount FROM staff_salary_details WHERE id = ?', 'i', [$detailId]);
            if (!$detail) {
                continue;
            }
            $balance = (float)$detail['net_amount'] - StaffPayrollModel::getTotalPaid($detailId);
            if ($balance < 0.005) {
                continue; // already fully paid
            }
            StaffPayrollModel::recordPayment($detailId, $balance, $method, $note, $byUserId, $paidDate);
            $done++;
            $total += $balance;
        }
        $message = $done . ' salary payment(s) recorded — Rs ' . number_format($total, 2);
        if ($done > 0) {
            log_activity('staff.payroll_bulk_payment', $message . ' via ' . $method . ' for ' . $month . '/' . $year);
        }
        if ($this->wantsJson()) {
            $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderPayrollListPartial($month, $year, $q)]);
        }
        $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
        redirect('/index.php?route=staff/payroll&salary_month=' . $month . '&salary_year=' . $year);
        return;
    }
} elseif ($action === 'edit_detail') {
    $salaryDetailId    = (int)($_POST['salary_detail_id'] ?? 0);
    $gross             = (float)($_POST['gross_amount'] ?? 0);
    $deductions        = (float)($_POST['deductions'] ?? 0);
    $net               = $gross - $deductions;
    $salaryCreatedDate = trim((string)($_POST['salary_created_date'] ?? date('Y-m-d')));

    if ($salaryDetailId <= 0 || $gross <= 0) {
        $error = 'Invalid salary data';
    } else {
        Database::execute(
            'UPDATE staff_salary_details
             SET gross_amount = ?, deductions = ?, net_amount = ?, salary_created_date = ?, created_by_user_id = ?
             WHERE id = ?',
            'dddsii',
            [$gross, $deductions, $net, $salaryCreatedDate, $byUserId, $salaryDetailId]
        );
        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Salary record updated'];
        log_activity('staff.payroll_edit', 'Edited salary record #' . $salaryDetailId . ' (net: Rs ' . number_format($net, 2) . ')');
        redirect('/index.php?route=staff/payroll&salary_month=' . $month . '&salary_year=' . $year . ($q !== '' ? '&' . http_build_query(['q' => $q]) : ''));
        return;
    }
} elseif ($action === 'delete_detail') {
    $salaryDetailId = (int)($_POST['salary_detail_id'] ?? 0);
    if ($salaryDetailId > 0) {
        // Delete payment history first, then the salary detail
        Database::execute('DELETE FROM staff_salary_payments WHERE staff_salary_detail_id = ?', 'i', [$salaryDetailId]);
        Database::execute('DELETE FROM staff_salary_details WHERE id = ?', 'i', [$salaryDetailId]);
        $message = 'Salary record deleted';
        log_activity('staff.payroll_delete', 'Deleted salary record #' . $salaryDetailId);
        if ($this->wantsJson()) {
            $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderPayrollListPartial($month, $year, $q)]);
        }
        $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
        redirect('/index.php?route=staff/payroll&salary_month=' . $month . '&salary_year=' . $year . ($q !== '' ? '&' . http_build_query(['q' => $q]) : ''));
        return;
    }
}
        }

        if ($error !== null && $this->wantsJson()) {
            $this->jsonResponse(['success' => false, 'message' => $error], 422);
        }

        $this->render('staff/payroll', [
            'title'       => 'Payroll',
            'error'       => $error,
            'month'       => $month,
            'year'        => $year,
            'payrollData' => $this->payrollViewData($month, $year, $q),
        ]);
    }
}

