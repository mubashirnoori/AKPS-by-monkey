<?php

class ActivityLogController extends Controller
{
    /** Build the WHERE clause + bound params shared by the list view and the CSV export. */
    private function filtersFromRequest(): array
    {
        return [
            'q'       => trim((string)($_GET['q'] ?? '')),
            'role'    => trim((string)($_GET['role'] ?? '')),
            'date_from' => trim((string)($_GET['date_from'] ?? '')),
            'date_to'   => trim((string)($_GET['date_to'] ?? '')),
        ];
    }

    private function buildWhere(array $f): array
    {
        $where = [];
        $types = '';
        $params = [];

        if ($f['q'] !== '') {
            $where[] = '(username LIKE ? OR description LIKE ? OR action LIKE ?)';
            $types .= 'sss';
            $like = '%' . $f['q'] . '%';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }
        if ($f['role'] !== '') {
            $where[] = 'role_name = ?';
            $types .= 's';
            $params[] = $f['role'];
        }
        if ($f['date_from'] !== '') {
            $where[] = 'created_at >= ?';
            $types .= 's';
            $params[] = $f['date_from'] . ' 00:00:00';
        }
        if ($f['date_to'] !== '') {
            $where[] = 'created_at <= ?';
            $types .= 's';
            $params[] = $f['date_to'] . ' 23:59:59';
        }

        $sql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
        return [$sql, $types, $params];
    }

    public function indexAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission('activity_log.view');

        $f = $this->filtersFromRequest();
        [$whereSql, $types, $params] = $this->buildWhere($f);

        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 30;
        $offset = ($page - 1) * $perPage;

        $totalRow = Database::fetchOne("SELECT COUNT(*) AS c FROM activity_log $whereSql", $types, $params);
        $total = (int)($totalRow['c'] ?? 0);

        $logs = Database::fetchAll(
            "SELECT * FROM activity_log $whereSql ORDER BY id DESC LIMIT ? OFFSET ?",
            $types . 'ii',
            array_merge($params, [$perPage, $offset])
        );

        $roles = Database::fetchAll('SELECT DISTINCT role_name FROM activity_log WHERE role_name IS NOT NULL ORDER BY role_name');

        $this->render('activity_log/index', [
            'title' => 'Activity Log',
            'logs' => $logs,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'roles' => $roles,
            'filters' => $f,
        ]);
    }

    public function exportCsvAction(): void
    {
        Auth::requireLoginOrToken();
        $this->requirePermission('activity_log.view');

        $f = $this->filtersFromRequest();
        [$whereSql, $types, $params] = $this->buildWhere($f);

        $logs = Database::fetchAll("SELECT * FROM activity_log $whereSql ORDER BY id DESC", $types, $params);

        log_activity('activity_log.export', 'Exported the activity log to CSV (' . count($logs) . ' rows)');

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="activity_log_' . date('Y-m-d_His') . '.csv"');

        $out = fopen('php://output', 'w');
        // UTF-8 BOM so Excel opens special characters (names, etc) correctly
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv_safe($out, ['Date/Time', 'Username', 'Role', 'Action', 'Description', 'IP Address']);
        foreach ($logs as $row) {
            fputcsv_safe($out, [
                $row['created_at'],
                $row['username'],
                $row['role_name'],
                $row['action'],
                $row['description'],
                $row['ip_address'],
            ]);
        }
        fclose($out);
        exit;
    }
}
