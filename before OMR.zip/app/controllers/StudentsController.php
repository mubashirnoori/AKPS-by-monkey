<?php

class StudentsController extends Controller
{
    public function indexAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';
        require_once __DIR__ . '/../models/GuardianModel.php';
        require_once __DIR__ . '/../models/InquiriesModel.php';
        require_once __DIR__ . '/../models/ComplaintsModel.php';
        require_once __DIR__ . '/../models/AttendanceModel.php';
        require_once __DIR__ . '/../models/CustomFieldModel.php';
        require_once __DIR__ . '/../models/SubjectModel.php';

        Auth::requireLogin();
          $this->requirePermission('students.view');
        

        $q = trim((string)($_GET['q'] ?? ''));
        $classSectionId = (int)($_GET['class_section_id'] ?? 0);
        $statusFilterRaw = trim((string)($_GET['student_status'] ?? 'active'));
        if (!in_array($statusFilterRaw, ['', 'active', 'left', 'all'], true)) {
            $statusFilterRaw = 'active';
        }
        // Default: show active students; "all" = no filter
        $statusFilter = null;
        if ($statusFilterRaw === 'active' || $statusFilterRaw === '') {
            $statusFilter = 1;
            $statusFilterRaw = 'active';
        } elseif ($statusFilterRaw === 'left') {
            $statusFilter = 0;
        } else {
            $statusFilterRaw = 'all';
        }

        $page = max(1, (int)($_GET['page'] ?? 1));

        // ✅ Allowed values (security + control)
        $allowedPerPage = [10, 20, 50, 100, 200, 999];

        // ✅ Get from dropdown
        $perPage = (int)($_GET['per_page'] ?? 10);

        // ✅ Validate
        if (!in_array($perPage, $allowedPerPage, true)) {
            $perPage = 10;
        }

        $offset = ($page - 1) * $perPage;

        $total = StudentModel::count($q, $classSectionId > 0 ? $classSectionId : null, $statusFilter);
        $students = StudentModel::list($q, $classSectionId > 0 ? $classSectionId : null, $perPage, $offset, $statusFilter);
        $classSections = ClassSectionModel::allOptions();

        $listFilters = [
            'q' => $q,
            'class_section_id' => $classSectionId,
            'student_status' => $statusFilterRaw,
            'per_page' => $perPage,
            'page' => $page,
        ];
        remember_list_filters('students', $listFilters);

        $this->render('students/index', [
            'title' => 'Students',
            'q' => $q,
            'classSectionId' => $classSectionId,
            'studentStatus' => $statusFilterRaw,
            'students' => $students,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'classSections' => $classSections,
            'listFilters' => $listFilters,
        ]);
    }

    /**
     * Full CSV export of every student record — every field on the student
     * (admission no, names, father's name, CNIC, DOB, class, roll number, fee
     * discount %, status, etc), not just what's shown in the on-screen table.
     * Honors the same search / class / status filters as the Students list
     * (so "export what I'm looking at" and "export everyone" both work), but
     * pulls every matching row rather than the current page only.
     */
    public function exportCsvAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLoginOrToken();
        $this->requirePermission(['students.view', 'students.export_csv']);

        StudentModel::ensureCnicColumn();

        $q = trim((string)($_GET['q'] ?? ''));
        $classSectionId = (int)($_GET['class_section_id'] ?? 0);
        $statusFilterRaw = trim((string)($_GET['student_status'] ?? 'active'));
        if (!in_array($statusFilterRaw, ['', 'active', 'left', 'all'], true)) {
            $statusFilterRaw = 'active';
        }
        $statusFilter = null;
        if ($statusFilterRaw === 'active' || $statusFilterRaw === '') {
            $statusFilter = 1;
        } elseif ($statusFilterRaw === 'left') {
            $statusFilter = 0;
        }
        // 'all' => $statusFilter stays null => no status restriction

        // Same WHERE-building as StudentModel::list()/count() (see that file), but
        // with no LIMIT — an export is supposed to pull every matching row.
        $params = [];
        $types = '';
        $sql = "SELECT s.*,
                       c.name AS current_class_name,
                       sec.name AS current_section_name,
                       sca.roll_number AS current_roll_number
                FROM students s
                LEFT JOIN student_class_assignments sca
                  ON sca.id = (
                    SELECT sca2.id
                    FROM student_class_assignments sca2
                    WHERE sca2.student_id = s.id
                    ORDER BY sca2.assigned_at DESC, sca2.id DESC
                    LIMIT 1
                  )
                LEFT JOIN class_sections cs ON cs.id = sca.class_section_id
                LEFT JOIN classes c ON c.id = cs.class_id
                LEFT JOIN sections sec ON sec.id = cs.section_id
                WHERE 1=1";

        if ($q !== '') {
            $sql .= " AND (s.admission_no LIKE ? OR s.first_name LIKE ? OR s.last_name LIKE ?
                      OR s.father_name LIKE ? OR s.board_registration_no LIKE ?
                      OR CAST(s.id AS CHAR) LIKE ? OR IFNULL(s.cnic_no,'') LIKE ?)";
            $like = "%$q%";
            for ($i = 0; $i < 7; $i++) {
                $params[] = $like;
            }
            $types .= 'sssssss';
        }

        if ($classSectionId > 0) {
            $sql .= " AND cs.id = ?";
            $params[] = $classSectionId;
            $types .= 'i';
        }

        if ($statusFilter !== null) {
            $sql .= ' AND IFNULL(s.status, 1) = ?';
            $params[] = $statusFilter;
            $types .= 'i';
        }

        $sql .= " ORDER BY s.id DESC";

        $students = Database::fetchAll($sql, $types, $params);

        log_activity('students.export_csv', 'Exported students list to CSV (' . count($students) . ' rows)');

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="students_export_' . date('Y-m-d_His') . '.csv"');
        $out = fopen('php://output', 'w');
        // BOM so Excel opens Urdu/Arabic names correctly instead of mangling them
        fwrite($out, "\xEF\xBB\xBF");

        fputcsv_safe($out, [
            'Admission No', 'Roll Number', 'First Name', 'Last Name', "Father's Name",
            'Gender', 'Date of Birth', 'CNIC No', 'Board Registration No',
            'Phone', 'Address', 'Class', 'Section',
            'Fee Discount %', 'Fee Discount Type', 'Status', 'Registered On',
        ]);

        foreach ($students as $s) {
            fputcsv_safe($out, [
                $s['admission_no'],
                $s['current_roll_number'] ?? $s['roll_number'] ?? '',
                $s['first_name'],
                $s['last_name'],
                $s['father_name'] ?? '',
                $s['gender'] ?? '',
                $s['dob'] ?? '',
                $s['cnic_no'] ?? '',
                $s['board_registration_no'] ?? '',
                $s['phone'] ?? '',
                $s['address'] ?? '',
                $s['current_class_name'] ?? '',
                $s['current_section_name'] ?? '',
                number_format((float)($s['fee_discount_percent'] ?? 0), 2),
                ((int)($s['fee_discount_is_percent'] ?? 1) === 1) ? 'Percent' : 'Fixed Amount',
                ((int)($s['status'] ?? 1) === 1) ? 'Active' : 'Left',
                $s['created_at'] ?? '',
            ]);
        }

        fclose($out);
        exit;
    }

    /** Filters to restore after create/edit/delete/back. */
    private function studentsListFilters(): array
    {
        $filters = recall_list_filters('students', [
            'q' => '',
            'class_section_id' => 0,
            'student_status' => 'active',
            'per_page' => 10,
            'page' => 1,
        ]);
        $filters['q'] = trim((string)($filters['q'] ?? ''));
        $filters['class_section_id'] = (int)($filters['class_section_id'] ?? 0);
        $status = trim((string)($filters['student_status'] ?? 'active'));
        if (!in_array($status, ['active', 'left', 'all'], true)) {
            $status = 'active';
        }
        $filters['student_status'] = $status;
        $allowed = [10, 20, 50, 100, 200, 999];
        $perPage = (int)($filters['per_page'] ?? 10);
        $filters['per_page'] = in_array($perPage, $allowed, true) ? $perPage : 10;
        $filters['page'] = max(1, (int)($filters['page'] ?? 1));
        return $filters;
    }

    private function redirectToStudentsList(): void
    {
        redirect_list('students/index', $this->studentsListFilters());
    }

    /**
     * Save an uploaded student photo to public/uploads/students/{id}.{ext}.
     *
     * Every previous call site of this logic (create, update, standalone
     * upload form) trusted mime_content_type() and move_uploaded_file()
     * blindly, so a disabled fileinfo extension, a full disk, or a
     * non-writable uploads folder on the host would fail *silently* — the
     * student/staff record would save fine and no one would ever see an
     * error, they'd just find the photo missing later. This centralizes the
     * logic once and returns a human-readable error string on any failure
     * (or null on success / "no file was submitted", which is not an error —
     * the photo field is optional on create/edit).
     *
     * @param array $file One entry of $_FILES, e.g. $_FILES['photo'].
     * @return string|null Error message, or null if saved (or nothing to save).
     */
    private function saveStudentPhoto(int $studentId, array $file): ?string
    {
        if ($studentId <= 0) {
            return 'Invalid student ID';
        }

        // No file submitted — not an error, photo upload is optional here.
        if (empty($file['tmp_name'])) {
            return null;
        }

        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            $phpUploadErrors = [
                UPLOAD_ERR_INI_SIZE   => 'the file exceeds the server\'s max upload size',
                UPLOAD_ERR_FORM_SIZE  => 'the file exceeds the form\'s max upload size',
                UPLOAD_ERR_PARTIAL    => 'the file was only partially uploaded — please try again',
                UPLOAD_ERR_NO_TMP_DIR => 'the server has no temporary folder configured for uploads',
                UPLOAD_ERR_CANT_WRITE => 'the server failed to write the file to disk',
                UPLOAD_ERR_EXTENSION  => 'a server extension blocked the upload',
            ];
            return $phpUploadErrors[$file['error']] ?? ('upload failed with error code ' . $file['error']);
        }

        if (!is_uploaded_file($file['tmp_name'])) {
            // Defence in depth against a forged/non-multipart request.
            return 'the uploaded file failed validation';
        }

        $allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
        $mimeType = function_exists('mime_content_type') ? mime_content_type($file['tmp_name']) : false;
        if ($mimeType === false) {
            // Most common real-world cause on shared hosting: the PHP
            // fileinfo extension isn't enabled, so we can't verify the
            // file's real type at all. Fail loudly instead of silently
            // skipping the save (the old behaviour).
            return 'the server could not verify the image type (the PHP "fileinfo" extension may be disabled — ask your host to enable ext-fileinfo)';
        }
        if (!in_array($mimeType, $allowed, true)) {
            return 'only JPEG, PNG, WebP or GIF images are allowed';
        }

        $uploadDir = dirname(__DIR__, 2) . '/public/uploads/students/';
        if (!is_dir($uploadDir) && !@mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
            return 'the server could not create the uploads folder (check filesystem permissions)';
        }
        if (!is_writable($uploadDir)) {
            return 'the uploads folder is not writable by the server (check filesystem/hosting permissions)';
        }

        $ext = ($mimeType === 'image/jpeg') ? 'jpg' : explode('/', $mimeType)[1];
        foreach (glob($uploadDir . $studentId . '.*') ?: [] as $old) {
            @unlink($old);
        }
        $dest = $uploadDir . $studentId . '.' . $ext;

        if (!move_uploaded_file($file['tmp_name'], $dest)) {
            return 'the server failed to save the uploaded file (check disk space and folder permissions)';
        }

        return null;
    }

    /**
     * Merge a photo-upload error (if any) into the flash message already
     * queued for this request, without clobbering a success message set
     * earlier in the same action (e.g. "login created: ...").
     */
    private function appendPhotoFlashWarning(?string $photoError): void
    {
        if ($photoError === null) {
            return;
        }
        if (!empty($_SESSION['flash']['message'])) {
            $_SESSION['flash']['message'] .= ' However, the photo upload failed: ' . $photoError . '.';
        } else {
            $_SESSION['flash'] = ['type' => 'warning', 'message' => 'Saved, but the photo upload failed: ' . $photoError . '.'];
        }
        $_SESSION['flash']['type'] = 'warning';
    }

    /** Re-run the list query for the current (remembered) filters and render the list partial. */
    private function renderStudentListPartial(): string
    {
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';

        $filters = $this->studentsListFilters();
        $q = $filters['q'];
        $classSectionId = (int)$filters['class_section_id'];
        $studentStatusRaw = $filters['student_status'];
        $perPage = (int)$filters['per_page'];
        $page = max(1, (int)$filters['page']);

        $statusFilter = null;
        if ($studentStatusRaw === 'active') {
            $statusFilter = 1;
        } elseif ($studentStatusRaw === 'left') {
            $statusFilter = 0;
        }

        $offset = ($page - 1) * $perPage;
        $total = StudentModel::count($q, $classSectionId > 0 ? $classSectionId : null, $statusFilter);
        $students = StudentModel::list($q, $classSectionId > 0 ? $classSectionId : null, $perPage, $offset, $statusFilter);
        $classSections = ClassSectionModel::allOptions();

        return $this->renderPartial('students/_student_list', [
            'students' => $students,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'q' => $q,
            'classSectionId' => $classSectionId,
            'studentStatus' => $studentStatusRaw,
            'classSections' => $classSections,
            'listFilters' => $filters,
        ]);
    }

    public function createAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';
        require_once __DIR__ . '/../models/GuardianModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.create']);

        $classSections = ClassSectionModel::allOptions();
        $listFilters = $this->studentsListFilters();
        $this->render('students/create', [
            'title' => 'Add Student',
            'classSections' => $classSections,
            'listFilters' => $listFilters,
        ]);
    }

    public function storeAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';
        require_once __DIR__ . '/../models/GuardianModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.create']);

        $this->requireCsrf();

        $user = Auth::currentUser();
        $assignedByUserId = (int)($user['id'] ?? 0);

        $data = [
            'admission_no' => trim((string)($_POST['admission_no'] ?? '')),
            'first_name' => trim((string)($_POST['first_name'] ?? '')),
            'last_name' => trim((string)($_POST['last_name'] ?? '')),
            'father_name' => trim((string)($_POST['father_name'] ?? '')),
            'board_registration_no' => trim((string)($_POST['board_registration_no'] ?? '')),
            'cnic_no' => trim((string)($_POST['cnic_no'] ?? '')),
            'gender' => in_array((string)($_POST['gender'] ?? 'M'), ['M', 'F', 'Other'], true) ? (string)$_POST['gender'] : 'M',
            'dob' => trim((string)($_POST['dob'] ?? '')) ?: null,
            'phone' => trim((string)($_POST['phone'] ?? '')),
            'address' => trim((string)($_POST['address'] ?? '')),
            'fee_discount_percent' => (float)($_POST['fee_discount_percent'] ?? 0),
            'fee_discount_is_percent' => ((int)($_POST['fee_discount_is_percent'] ?? 1) === 1) ? 1 : 0,
        ];

        foreach (['admission_no', 'first_name', 'last_name'] as $f) {
            if ($data[$f] === '') {
                http_response_code(422);
                $error = $f . ' is required';
                $classSections = ClassSectionModel::allOptions();
                $this->render('students/create', [
                    'title' => 'Add Student',
                    'classSections' => $classSections,
                    'error' => $error,
                    'old' => $data,
                    'listFilters' => $this->studentsListFilters(),
                ]);
                return;
            }
        }

        $classSectionId = (int)($_POST['class_section_id'] ?? 0);
        $assignedClassSectionId = $classSectionId > 0 ? $classSectionId : null;
        $data['roll_number'] = (int)($_POST['roll_number'] ?? 0);

        try {
            $studentId = StudentModel::create($data, $assignedClassSectionId, $assignedByUserId);
        } catch (Throwable $e) {
            $classSections = ClassSectionModel::allOptions();
            $this->render('students/create', [
                'title' => 'Add Student',
                'classSections' => $classSections,
                'error' => $e->getMessage(),
                'old' => array_merge($data, ['class_section_id' => $classSectionId]),
                'listFilters' => $this->studentsListFilters(),
            ]);
            return;
        }

        log_activity('students.create', 'Added student "' . $data['first_name'] . ' ' . $data['last_name'] . '" (Admission #' . $data['admission_no'] . ')');

        // Handle optional photo upload
        $photoError = $this->saveStudentPhoto($studentId, $_FILES['photo'] ?? []);

        // Optional login account for the student
        if (!empty($_POST['create_login'])) {
            require_once __DIR__ . '/../services/UserAccountService.php';
            $roleName = trim((string)($_POST['login_role'] ?? 'Student'));
            $roleId = UserAccountService::roleIdByName($roleName) ?? UserAccountService::roleIdByName('Student');
            if ($roleId) {
                $username = trim((string)($_POST['login_username'] ?? ''));
                if ($username === '') {
                    $username = $data['admission_no'];
                }
                $username = UserAccountService::uniqueUsername($username);
                $password = trim((string)($_POST['login_password'] ?? ''));
                if ($password === '') {
                    $password = UserAccountService::randomPassword();
                }
                $email = trim((string)($_POST['login_email'] ?? ''));
                UserAccountService::createAndLink('students', $studentId, $username, $email, $password, $roleId);
                $_SESSION['flash'] = [
                    'type' => 'success',
                    'message' => 'Student created — login: ' . $username . ' / ' . $password . ' (share this with them now; it will not be shown again)',
                ];
            }
        }

        // Optional single guardian on create
        $guardianName = trim((string)($_POST['guardian_full_name'] ?? ''));
        if ($guardianName !== '') {
            $guardianId = GuardianModel::addAndLink(
                $studentId,
                [
                    'full_name' => $guardianName,
                    'relation' => trim((string)($_POST['guardian_relation'] ?? '')),
                    'phone' => trim((string)($_POST['guardian_phone'] ?? '')),
                    'email' => trim((string)($_POST['guardian_email'] ?? '')),
                    'address' => trim((string)($_POST['guardian_address'] ?? '')),
                ],
                (bool)($_POST['guardian_is_primary'] ?? false)
            );

            if (!empty($_POST['guardian_create_login']) && $guardianId) {
                require_once __DIR__ . '/../services/UserAccountService.php';
                $roleId = UserAccountService::roleIdByName('Parent');
                if ($roleId) {
                    $username = trim((string)($_POST['guardian_login_username'] ?? ''));
                    if ($username === '') {
                        $username = trim((string)($_POST['guardian_phone'] ?? '')) ?: $guardianName;
                    }
                    $username = UserAccountService::uniqueUsername($username);
                    $password = trim((string)($_POST['guardian_login_password'] ?? ''));
                    if ($password === '') {
                        $password = UserAccountService::randomPassword();
                    }
                    UserAccountService::createAndLink('guardians', $guardianId, $username, trim((string)($_POST['guardian_email'] ?? '')), $password, $roleId);
                    $_SESSION['flash'] = [
                        'type' => 'success',
                        'message' => 'Student created — guardian login: ' . $username . ' / ' . $password . ' (share this with them now; it will not be shown again)',
                    ];
                }
            }
        }

        if (empty($_SESSION['flash'])) {
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Student created successfully'];
        }
        $this->appendPhotoFlashWarning($photoError);
        $this->redirectToStudentsList();
    }

    public function editAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.update']);

        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) {
            http_response_code(404);
            echo 'Missing student id';
            return;
        }

        $student = StudentModel::getById($id);
        if (!$student) {
            http_response_code(404);
            echo 'Student not found';
            return;
        }

        $classSections = ClassSectionModel::allOptions();
        $this->render('students/edit', [
            'title' => 'Edit Student',
            'student' => $student,
            'classSections' => $classSections,
            'listFilters' => $this->studentsListFilters(),
        ]);
    }

    public function updateAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';
        require_once __DIR__ . '/../models/GuardianModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.update']);
        $this->requireCsrf();

        $user = Auth::currentUser();
        $assignedByUserId = (int)($user['id'] ?? 0);

        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) {
            http_response_code(422);
            echo 'Invalid student id';
            return;
        }

        $data = [
            'admission_no' => trim((string)($_POST['admission_no'] ?? '')),
            'first_name' => trim((string)($_POST['first_name'] ?? '')),
            'last_name' => trim((string)($_POST['last_name'] ?? '')),
            'father_name' => trim((string)($_POST['father_name'] ?? '')),
            'board_registration_no' => trim((string)($_POST['board_registration_no'] ?? '')),
            'cnic_no' => trim((string)($_POST['cnic_no'] ?? '')),
            'gender' => in_array((string)($_POST['gender'] ?? 'M'), ['M', 'F', 'Other'], true) ? (string)$_POST['gender'] : 'M',
            'dob' => trim((string)($_POST['dob'] ?? '')) ?: null,
            'phone' => trim((string)($_POST['phone'] ?? '')),
            'address' => trim((string)($_POST['address'] ?? '')),
            'fee_discount_percent' => (float)($_POST['fee_discount_percent'] ?? 0),
            'fee_discount_is_percent' => ((int)($_POST['fee_discount_is_percent'] ?? 1) === 1) ? 1 : 0,
            'status' => ((int)($_POST['status'] ?? 1) === 1) ? 1 : 0,
            'note' => trim((string)($_POST['assignment_note'] ?? '')),
        ];

        foreach (['admission_no', 'first_name', 'last_name'] as $f) {
            if ($data[$f] === '') {
                http_response_code(422);
                $classSections = ClassSectionModel::allOptions();
                $this->render('students/edit', [
                    'title' => 'Edit Student',
                    'classSections' => $classSections,
                    'error' => $f . ' is required',
                    'student' => array_merge(['id' => $id], $data),
                    'listFilters' => $this->studentsListFilters(),
                ]);
                return;
            }
        }

        $postedClassSectionId = (int)($_POST['class_section_id'] ?? 0);
        $current = StudentModel::getCurrentClassSectionId($id);
        $assignedClassSectionId = ($postedClassSectionId > 0 && (int)$current !== $postedClassSectionId) ? $postedClassSectionId : null;
        $data['roll_number'] = (int)($_POST['roll_number'] ?? 0);

        try {
            StudentModel::update($id, $data, $assignedClassSectionId, $assignedByUserId);
        } catch (Throwable $e) {
            $classSections = ClassSectionModel::allOptions();
            $this->render('students/edit', [
                'title' => 'Edit Student',
                'classSections' => $classSections,
                'error' => $e->getMessage(),
                'student' => array_merge(
                    StudentModel::getById($id) ?: ['id' => $id],
                    $data,
                    ['current_class_section_id' => $postedClassSectionId, 'roll_number' => $data['roll_number']]
                ),
                'listFilters' => $this->studentsListFilters(),
            ]);
            return;
        }

        // Handle optional photo upload on edit
        $photoError = $this->saveStudentPhoto($id, $_FILES['photo'] ?? []);

        // Optional add guardian
        $guardianName = trim((string)($_POST['guardian_full_name'] ?? ''));
        if ($guardianName !== '') {
            GuardianModel::addAndLink(
                $id,
                [
                    'full_name' => $guardianName,
                    'relation' => trim((string)($_POST['guardian_relation'] ?? '')),
                    'phone' => trim((string)($_POST['guardian_phone'] ?? '')),
                    'email' => trim((string)($_POST['guardian_email'] ?? '')),
                    'address' => trim((string)($_POST['guardian_address'] ?? '')),
                ],
                (bool)($_POST['guardian_is_primary'] ?? false)
            );
        }

        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Student updated successfully'];
        $this->appendPhotoFlashWarning($photoError);
        log_activity('students.update', 'Updated student "' . $data['first_name'] . ' ' . $data['last_name'] . '" (#' . $id . ')');
        $this->redirectToStudentsList();
    }

    public function deleteAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.deactivate']);
        $this->requireCsrf();

        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            $existing = StudentModel::getById($id);
            StudentModel::delete($id);
            $message = 'Student deactivated (all records preserved)';
            $name = trim(($existing['first_name'] ?? '') . ' ' . ($existing['last_name'] ?? '')) ?: ('#' . $id);
            log_activity('students.deactivate', 'Deactivated student "' . $name . '"');
            if ($this->wantsJson()) {
                $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderStudentListPartial()]);
            }
            $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
        }
        $this->redirectToStudentsList();
    }

    public function bulkDeleteAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.bulk_deactivate']);
        $this->requireCsrf();

        $ids = $_POST['student_ids'] ?? [];
        if (!is_array($ids)) {
            $ids = [];
        }

        $count = 0;
        foreach ($ids as $id) {
            $id = (int)$id;
            if ($id > 0) {
                StudentModel::delete($id);
                $count++;
            }
        }
        $message = 'Deactivated ' . $count . ' student(s) (all records preserved)';
        if ($count > 0) {
            log_activity('students.bulk_deactivate', 'Bulk-deactivated ' . $count . ' student(s)');
        }
        if ($this->wantsJson()) {
            $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderStudentListPartial()]);
        }
        $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
        $this->redirectToStudentsList();
    }

    public function bulkAssignClassAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.bulk_assign_class']);
        $this->requireCsrf();

        $targetClassSectionId = (int)($_POST['class_section_id'] ?? 0);
        if ($targetClassSectionId <= 0) {
            if ($this->wantsJson()) {
                $this->jsonResponse(['success' => false, 'message' => 'Choose a target class first.'], 422);
            }
            $this->redirectToStudentsList();
            return;
        }

        $ids = $_POST['student_ids'] ?? [];
        if (!is_array($ids)) {
            $ids = [];
        }

        $user = Auth::currentUser();
        $byUserId = (int)($user['id'] ?? 0);
        $note = trim((string)($_POST['assignment_note'] ?? ''));

        $count = 0;
        foreach ($ids as $id) {
            $id = (int)$id;
            if ($id > 0) {
                StudentModel::promote($id, $targetClassSectionId, $byUserId, $note); // reuse promotion logic to update assignment
                $count++;
            }
        }
        $message = 'Assigned class for ' . $count . ' student(s)';
        if ($count > 0) {
            log_activity('students.bulk_assign_class', $message);
        }
        if ($this->wantsJson()) {
            $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderStudentListPartial()]);
        }
        $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
        $this->redirectToStudentsList();
    }

   
    public function importAction(): void
{
    require_once __DIR__ . '/../models/StudentModel.php';
    require_once __DIR__ . '/../models/GuardianModel.php';
    require_once __DIR__ . '/../models/ClassSectionModel.php';

    Auth::requireLogin();
    $this->requirePermission(['students.manage', 'students.import']);

    $error = null;

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        $this->requireCsrf();

        if (empty($_FILES['csv_file']['tmp_name'])) {
            $error = "CSV file missing";
        } else {

            $file = fopen($_FILES['csv_file']['tmp_name'], 'r');

            $headers = fgetcsv($file);
            if (!$headers) {
                $error = "Invalid CSV";
            } else {

                // normalize headers
                $headers = array_map(fn($h) => strtolower(trim($h)), $headers);

                $map = array_flip($headers);

                $get = function ($row, $keys) use ($map) {
                    // Accept array of keys or single key
                    if (!is_array($keys)) {
                        $keys = [$keys];
                    }
                    foreach ($keys as $key) {
                        $key = strtolower($key);
                        if (isset($map[$key]) && $row[$map[$key]] !== null && $row[$map[$key]] !== '') {
                            return trim($row[$map[$key]]);
                        }
                    }
                    return null;
                };

                $imported = 0;
                $skipped = 0;
                $importErrors = [];

                // Get default class section if provided
                $defaultClassSectionId = (int)($_POST['default_class_section_id'] ?? 0) ?: null;

                while (($row = fgetcsv($file)) !== false) {

                    // Get admission number (try multiple column names)
                    $admissionNo = $get($row, ['admission_no', 'admission_number', 'admission']);
                    
                    // Get roll number
                    $rollNumber = $get($row, ['roll_number', 'roll_no', 'roll']);

                    // Get full name (try multiple column names)
                    $fullName = $get($row, ['full_name', 'student_name', 'name']);

                    // Validate required fields
                    if (!$admissionNo || !$fullName) {
                        $skipped++;
                        continue;
                    }

                    // Split full name into first and last
                    $parts = explode(' ', trim($fullName), 2);
                    $firstName = $parts[0] ?? '';
                    $lastName = $parts[1] ?? '';

                    // Get class section - try multiple methods
                    $assignedClassSectionId = null;

                    // Method 1: class_section_id directly from CSV
                    $csvClassSectionId = $get($row, ['class_section_id', 'classsectionid']);
                    if ($csvClassSectionId) {
                        $assignedClassSectionId = (int)$csvClassSectionId;
                    } 
                    // Method 2: class + section names from CSV
                    else {
                        $className = $get($row, ['class', 'class_name']);
                        $sectionName = $get($row, ['section', 'section_name']);

                        if ($className && $sectionName) {
                            // Find class section by name
                            $classSection = Database::fetchOne(
                                'SELECT cs.id 
                                 FROM class_sections cs
                                 JOIN classes c ON c.id = cs.class_id
                                 JOIN sections s ON s.id = cs.section_id
                                 WHERE c.name = ? AND s.name = ?',
                                'ss',
                                [$className, $sectionName]
                            );
                            if ($classSection) {
                                $assignedClassSectionId = (int)$classSection['id'];
                            }
                        }
                    }

                    // Method 3: Use default if no class found
                    if (!$assignedClassSectionId && $defaultClassSectionId) {
                        $assignedClassSectionId = $defaultClassSectionId;
                    }

                    // Build student data
                    $data = [
                        'admission_no' => trim($admissionNo),
                        'roll_number'  => ($rollNumber !== null && $rollNumber !== '') ? (int)$rollNumber : null,
                        'first_name'   => $firstName,
                        'last_name'    => $lastName,
                        'gender'       => $get($row, ['gender']) ?? 'M',
                        'dob'          => $get($row, ['dob', 'date_of_birth']) ?: null,
                        'phone'        => $get($row, ['phone', 'phone_number']) ?: null,
                        'address'      => $get($row, ['address']) ?: null,
                        'status'       => 1
                    ];

                    try {
                        $studentId = StudentModel::upsertByAdmissionNo(
                            $data,
                            $assignedClassSectionId,
                            Auth::currentUser()['id'] ?? 0
                        );
                        $imported++;
                    } catch (Throwable $e) {
                        $importErrors[] = "Row error: " . $e->getMessage();
                        $skipped++;
                    }
                }

                fclose($file);

                $message = "Imported: $imported | Skipped: $skipped";
                if (!empty($importErrors)) {
                    $message .= " | Errors: " . implode(", ", array_slice($importErrors, 0, 3));
                }

                $_SESSION['flash'] = [
                    'type' => ($imported > 0) ? 'success' : 'warning',
                    'message' => $message
                ];

                redirect_route('students/index');
                return;
            }
        }
    }

    $classSections = ClassSectionModel::allOptions();

    $this->render('students/import', [
        'title' => 'Import Students',
        'error' => $error,
        'classSections' => $classSections,
    ]);
}

    /**
     * Unified read-at-a-glance page for one student — personal, academic, fee and guardian
     * details together, with quick links into each area's real edit form. Reached via the
     * eye icon in the student list (replaces the old "Guardians" button, which now lives as
     * a tab here alongside everything else).
     */
    public function profileAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/GuardianModel.php';
        require_once __DIR__ . '/../models/FeeInvoiceModel.php';

        Auth::requireLogin();
        $this->requirePermission('students.view');

        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) {
            http_response_code(404);
            echo 'Missing student id';
            return;
        }

        $student = StudentModel::getById($id);
        if (!$student) {
            http_response_code(404);
            echo 'Student not found';
            return;
        }

        $guardians = GuardianModel::listByStudent($id);
        $invoices = FeeInvoiceModel::getStudentInvoices($id, null, 25, 0);
        $classHistory = StudentModel::getClassHistory($id);

        $totalDue = 0.0;
        $totalCollected = 0.0;
        foreach ($invoices as $inv) {
            $totalDue += (float)($inv['total_due'] ?? 0);
            $totalCollected += (float)($inv['collected_amount'] ?? 0);
        }
        $pendingBalance = 0.0;
        try {
            $row = Database::fetchOne(
                'SELECT COALESCE(SUM(pending_amount),0) AS s FROM pending_dues_view WHERE student_id = ?',
                'i',
                [$id]
            );
            $pendingBalance = (float)($row['s'] ?? 0);
        } catch (Throwable $e) {
        }

        $this->render('students/profile', [
            'title' => 'Student Profile',
            'student' => $student,
            'guardians' => $guardians,
            'invoices' => $invoices,
            'totalDue' => $totalDue,
            'totalCollected' => $totalCollected,
            'pendingBalance' => $pendingBalance,
            'classHistory' => $classHistory,
            'listFilters' => $this->studentsListFilters(),
        ]);
    }

    /**
     * AJAX search backing the "Link Existing Guardian" combo box. Replaces
     * preloading up to 500 guardians into the page and filtering them in
     * JS — that silently dropped anyone past the 500th row. Always returns
     * at most 10 matches from a live database query, so it scales to any
     * number of guardians.
     */
    public function guardianSearchAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.guardians_manage']);

        header('Content-Type: application/json; charset=utf-8');

        $studentId = (int)($_GET['student_id'] ?? 0);
        $q = trim((string)($_GET['q'] ?? ''));
        $like = '%' . $q . '%';

        $rows = Database::fetchAll(
            "SELECT g.id, g.full_name, g.phone, g.email,
                    GROUP_CONCAT(DISTINCT CONCAT(s2.first_name, ' ', s2.last_name) SEPARATOR ', ') AS children_label,
                    (g.user_id IS NOT NULL) AS has_login
             FROM guardians g
             LEFT JOIN student_guardians sg2 ON sg2.guardian_id = g.id
             LEFT JOIN students s2 ON s2.id = sg2.student_id
             WHERE g.id NOT IN (
                 SELECT guardian_id FROM student_guardians WHERE student_id = ?
             )
             AND (? = '' OR g.full_name LIKE ? OR g.phone LIKE ? OR g.email LIKE ?)
             GROUP BY g.id, g.full_name, g.phone, g.email, g.user_id
             ORDER BY g.full_name
             LIMIT 10",
            'issss',
            [$studentId, $q, $like, $like, $like]
        );

        $results = [];
        foreach ($rows as $g) {
            $sub = trim((string)($g['phone'] ?? ''));
            if (!empty($g['children_label'])) {
                $sub .= ($sub !== '' ? ' — ' : '') . 'parent of: ' . $g['children_label'];
            }
            if (!empty($g['has_login'])) {
                $sub .= ($sub !== '' ? ' · ' : '') . 'has login';
            }
            $results[] = ['id' => (int)$g['id'], 'label' => $g['full_name'], 'sub' => $sub];
        }

        echo json_encode($results, JSON_UNESCAPED_UNICODE);
    }

    public function guardiansAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/GuardianModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.guardians_manage']);

        $studentId = (int)($_GET['student_id'] ?? 0);
        if ($studentId <= 0) {
            http_response_code(404);
            echo 'Missing student_id';
            return;
        }

        $student = StudentModel::getById($studentId);
        if (!$student) {
            http_response_code(404);
            echo 'Student not found';
            return;
        }

        $guardians = GuardianModel::listByStudent($studentId);

        // The "Link Existing Guardian" picker below searches the database
        // live via guardianSearchAction() as the admin types (max 10
        // matches), instead of preloading every unlinked guardian in the
        // school into the page — that used to cap out at 500 and silently
        // hide the rest.

        $this->render('students/guardians', [
            'title' => 'Guardians',
            'student' => $student,
            'guardians' => $guardians,
            'listFilters' => $this->studentsListFilters(),
        ]);
    }

    public function guardiansLinkExistingAction(): void
    {
        require_once __DIR__ . '/../models/GuardianModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.guardians_manage']);
        $this->requireCsrf();

        $studentId = (int)($_POST['student_id'] ?? 0);
        $guardianId = (int)($_POST['existing_guardian_id'] ?? 0);

        if ($studentId > 0 && $guardianId > 0) {
            GuardianModel::linkExisting($studentId, $guardianId, (bool)($_POST['is_primary'] ?? false));
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Guardian linked — this student now shares that guardian\'s login (if any).'];
        } else {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Pick a guardian from the list before linking.'];
        }

        redirect('/index.php?route=students/guardians&student_id=' . $studentId . list_return_query($this->studentsListFilters()));
    }

    public function guardiansAddAction(): void
    {
        require_once __DIR__ . '/../models/GuardianModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.guardians_manage']);
        $this->requireCsrf();

        $studentId = (int)($_POST['student_id'] ?? 0);
        if ($studentId <= 0) {
            $this->redirectToStudentsList();
            return;
        }

        GuardianModel::addAndLink(
            $studentId,
            [
                'full_name' => trim((string)($_POST['full_name'] ?? '')),
                'relation' => trim((string)($_POST['relation'] ?? '')),
                'phone' => trim((string)($_POST['phone'] ?? '')),
                'email' => trim((string)($_POST['email'] ?? '')),
                'address' => trim((string)($_POST['address'] ?? '')),
            ],
            (bool)($_POST['is_primary'] ?? false)
        );

        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Guardian linked'];
        redirect('/index.php?route=students/guardians&student_id=' . $studentId . list_return_query($this->studentsListFilters()));
    }

    public function guardiansRemoveAction(): void
    {
        require_once __DIR__ . '/../models/GuardianModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.guardians_manage']);
        $this->requireCsrf();

        $studentId = (int)($_POST['student_id'] ?? 0);
        $guardianId = (int)($_POST['guardian_id'] ?? 0);
        if ($studentId > 0 && $guardianId > 0) {
            GuardianModel::removeLink($studentId, $guardianId);
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Guardian unlinked'];
        }
        redirect('/index.php?route=students/guardians&student_id=' . $studentId . list_return_query($this->studentsListFilters()));
    }

    public function leavesAction(): void
    {
        require_once __DIR__ . '/../models/LeaveRequestModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.view', 'students.manage', 'students.leave_approve']);

        $status = trim((string)($_GET['status'] ?? ''));
        $q = trim((string)($_GET['q'] ?? ''));

        // Full access (Admin / anyone holding students.view or students.manage) sees every
        // student's leave requests. A Teacher who only holds 'students.leave_approve' sees
        // just the requests for students in class section(s) where they're the Class Teacher —
        // and (enforced in approveLeaveAction below) can only decide leaves of 2 days or fewer.
        $hasFullAccess = RBAC::hasPermission('students.view') || RBAC::hasPermission('students.manage');
        $scopeToOwnClass = !$hasFullAccess;
        $classSectionIds = $scopeToOwnClass ? RBAC::currentTeacherClassTeacherSectionIds() : null;

        $leaves = LeaveRequestModel::list($status, $q, 100, 0, 'student', $classSectionIds);

        $this->render('students/leaves', [
            'title' => 'Student Leave Requests',
            'status' => $status,
            'q' => $q,
            'leaves' => $leaves,
            'canApproveLong' => $hasFullAccess,
            'scopedToOwnClass' => $scopeToOwnClass,
        ]);
    }

    public function approveLeaveAction(): void
    {
        require_once __DIR__ . '/../models/LeaveRequestModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.leave_approve']);
        $this->requireCsrf();

        $leaveRequestId = (int)($_POST['leave_request_id'] ?? 0);
        $decision = (string)($_POST['decision'] ?? 'approved');
        $decisionNote = trim((string)($_POST['decision_note'] ?? ''));

        $user = Auth::currentUser();
        $byUserId = (int)($user['id'] ?? 0);

        if ($leaveRequestId <= 0 || !in_array($decision, ['approved', 'rejected'], true)) {
            redirect_route('students/leaves');
            return;
        }

        $leaveRequest = LeaveRequestModel::find($leaveRequestId);
        if (!$leaveRequest || ($leaveRequest['applicant_type'] ?? '') !== 'student') {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Leave request not found'];
            redirect_route('students/leaves');
            return;
        }

        // Admin / a role holding 'students.manage' can approve any duration. A Teacher holding
        // only 'students.leave_approve' may decide it ONLY when it's 2 days or fewer AND the
        // student is in a class section where they're the Class Teacher — anything longer, or
        // outside their own class, must go to Admin/Principal instead.
        if (!RBAC::hasPermission('students.manage')) {
            $days = LeaveRequestModel::durationDays($leaveRequest);
            if ($days > 2) {
                $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Leaves of more than 2 days require Admin/Principal approval — teachers can only decide leaves of 2 days or fewer.'];
                redirect_route('students/leaves');
                return;
            }

            require_once __DIR__ . '/../models/StudentModel.php';
            $studentId = (int)($leaveRequest['student_id'] ?? 0);
            $studentClassSectionId = $studentId > 0 ? StudentModel::getCurrentClassSectionId($studentId) : null;
            $myClassSectionIds = RBAC::currentTeacherClassTeacherSectionIds();
            if ($studentClassSectionId === null || !in_array($studentClassSectionId, $myClassSectionIds, true)) {
                $_SESSION['flash'] = ['type' => 'danger', 'message' => 'You can only approve leave requests for students in your own class.'];
                redirect_route('students/leaves');
                return;
            }
        }

        LeaveRequestModel::approve($leaveRequestId, $decision, $decisionNote, $byUserId);

        // Notify the student and their guardians of the decision — the
        // apply flow already notifies whoever can approve, but the
        // requester was never told the outcome.
        require_once __DIR__ . '/../models/NotificationModel.php';
        $verb = $decision === 'approved' ? 'approved' : 'rejected';
        $msg = 'Your ' . ($leaveRequest['leave_type'] ?? 'leave') . ' request ('
            . ($leaveRequest['from_date'] ?? '') . ' to ' . ($leaveRequest['to_date'] ?? '') . ') was ' . $verb . '.';
        if ($decisionNote !== '') {
            $msg .= ' Note: ' . $decisionNote;
        }
        NotificationModel::notifyStudentAndGuardians(
            (int)($leaveRequest['student_id'] ?? 0),
            'leave_decision',
            'Leave request ' . $verb,
            $msg,
            route_url('portal/index')
        );

        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Leave updated'];
        redirect_route('students/leaves');
    }

    public function promotionsAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.promotions']);

        $classSections = ClassSectionModel::allOptions();
        $students = StudentModel::list('', 0, 200, 0);
$students = is_array($students) ? $students : [];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();

            $user = Auth::currentUser();
            $byUserId = (int)($user['id'] ?? 0);

            $toClassSectionId = (int)($_POST['to_class_section_id'] ?? 0);
            $note = trim((string)($_POST['note'] ?? ''));
            $studentIds = $_POST['student_ids'] ?? [];
            if (!is_array($studentIds)) {
                $studentIds = [];
            }

            $count = 0;
            foreach ($studentIds as $sid) {
                $sid = (int)$sid;
                if ($sid > 0) {
                    StudentModel::promote($sid, $toClassSectionId, $byUserId, $note);
                    $count++;
                }
            }

            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Promoted ' . $count . ' student(s)'];
            redirect_route('students/index');
        }

        $this->render('students/promotions', [
            'title' => 'Promotions',
            'classSections' => $classSections,
            'students' => $students,
        ]);
    }

    public function attendanceAction(): void
    {
        require_once __DIR__ . '/../models/AttendanceModel.php';
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';
        require_once __DIR__ . '/../models/SubjectModel.php';

        Auth::requireLogin();
        $this->requirePermission('students.view');
        

        $error = null;
        $today = date('Y-m-d');

        $classSections = ClassSectionModel::allOptions();

        $classSectionId = (int)($_GET['class_section_id'] ?? ($_POST['class_section_id'] ?? 0));
        if ($classSectionId <= 0) {
            $first = $classSections[0]['id'] ?? 0;
            $classSectionId = (int)$first;
        }

        $subjects = SubjectModel::optionsForClassSection($classSectionId);

        $attendanceDate = (string)($_POST['attendance_date'] ?? $_GET['attendance_date'] ?? $today);

        $subjectIdRaw = $_POST['subject_id'] ?? $_GET['subject_id'] ?? '';
        $subjectId = ($subjectIdRaw === '' || $subjectIdRaw === null) ? null : (int)$subjectIdRaw;
        if ($subjectId <= 0) {
            $subjectId = null;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();

            $user = Auth::currentUser();
            $byUserId = (int)($user['id'] ?? 0);

            if (!empty($_POST['mark_holiday'])) {
                try {
                    $count = AttendanceModel::markClassHoliday($classSectionId, $attendanceDate, $subjectId, $byUserId);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => "Marked $count student(s) as Holiday for $attendanceDate"];
                    $params = http_build_query([
                        'class_section_id' => $classSectionId,
                        'attendance_date'  => $attendanceDate,
                        'subject_id'       => $subjectId ?? '',
                    ]);
                    redirect('/index.php?route=students%2Fattendance&' . $params);
                    return;
                } catch (Throwable $e) {
                    $error = $e->getMessage();
                }
            } else {

            $statusByStudentId = $_POST['status'] ?? [];
            if (!is_array($statusByStudentId)) {
                $statusByStudentId = [];
            }

            try {
                AttendanceModel::save($classSectionId, $attendanceDate, $subjectId, $statusByStudentId, $byUserId);
                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Attendance saved successfully'];
                $params = http_build_query([
                    'class_section_id' => $classSectionId,
                    'attendance_date'  => $attendanceDate,
                    'subject_id'       => $subjectId ?? '',
                ]);
                redirect('/index.php?route=students%2Fattendance&' . $params);
                return;
            } catch (Throwable $e) {
                $error = $e->getMessage();
            }
            }
        }

        $students = AttendanceModel::getStudentsWithStatus($classSectionId, $attendanceDate, $subjectId);
        $this->render('students/attendance', [
            'title' => 'Attendance',
            'error' => $error,
            'classSections' => $classSections,
            'subjects' => $subjects,
            'classSectionId' => $classSectionId,
            'attendanceDate' => $attendanceDate,
            'subjectId' => $subjectId,
            'students' => $students,
            'isConfiguredHoliday' => is_configured_holiday($attendanceDate),
        ]);
    }

    public function inquiriesAction(): void
    {
        require_once __DIR__ . '/../models/InquiriesModel.php';
        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.inquiries']);

        $q = trim((string)($_GET['q'] ?? ''));
        $status = trim((string)($_GET['status'] ?? ''));
        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 10;
        $offset = ($page - 1) * $perPage;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $user = Auth::currentUser();
            $byUserId = (int)($user['id'] ?? 0);

            InquiriesModel::create([
                'inquiry_no' => trim((string)($_POST['inquiry_no'] ?? '')),
                'requested_first_name' => trim((string)($_POST['requested_first_name'] ?? '')),
                'requested_last_name' => trim((string)($_POST['requested_last_name'] ?? '')),
                'phone' => trim((string)($_POST['phone'] ?? '')),
                'email' => trim((string)($_POST['email'] ?? '')),
                'requested_class_id' => (int)($_POST['requested_class_id'] ?? 0) ?: null,
                'requested_section_id' => (int)($_POST['requested_section_id'] ?? 0) ?: null,
                'status' => 'new',
                'notes' => trim((string)($_POST['notes'] ?? '')),
            ], null);

            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Inquiry created'];
            redirect_route('students/inquiries');
            return;
        }

        $total = InquiriesModel::count($q, $status ?: null);
        $inquiries = InquiriesModel::list($q, $status ?: null, $perPage, $offset);

        $classes = Database::fetchAll('SELECT id, name FROM classes ORDER BY name');
        $sections = Database::fetchAll('SELECT id, name FROM sections ORDER BY name');

        $this->render('students/inquiries', [
            'title' => 'Inquiries',
            'q' => $q,
            'status' => $status,
            'inquiries' => $inquiries,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'classes' => $classes,
            'sections' => $sections,
        ]);
    }

    public function complaintsAction(): void
    {
        require_once __DIR__ . '/../models/ComplaintsModel.php';
        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.complaints']);

        $q = trim((string)($_GET['q'] ?? ''));
        $status = trim((string)($_GET['status'] ?? ''));
        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 10;
        $offset = ($page - 1) * $perPage;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Create complaint
            $this->requireCsrf();
            $user = Auth::currentUser();
            $byUserId = (int)($user['id'] ?? 0);

            ComplaintsModel::create([
                'student_id' => (int)($_POST['student_id'] ?? 0) ?: null,
                'title' => trim((string)($_POST['title'] ?? '')),
                'complaint_text' => trim((string)($_POST['complaint_text'] ?? '')),
                'status' => 'open',
            ], $byUserId);

            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Complaint recorded'];
            redirect_route('students/complaints');
            return;
        }

        $total = ComplaintsModel::count($q, $status ?: null);
        $complaints = ComplaintsModel::list($q, $status ?: null, $perPage, $offset);
        $students = StudentModel::list('', 0, 200, 0);
$students = is_array($students) ? $students : [];

        $this->render('students/complaints', [
            'title' => 'Complaints',
            'q' => $q,
            'status' => $status,
            'complaints' => $complaints,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'students' => $students,
        ]);
    }

    public function complaintResolveAction(): void
    {
        require_once __DIR__ . '/../models/ComplaintsModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.complaints']);
        $this->requireCsrf();

        $complaintId = (int)($_POST['complaint_id'] ?? 0);
        $resolutionText = trim((string)($_POST['resolution_text'] ?? ''));
        if ($complaintId <= 0 || $resolutionText === '') {
            redirect_route('students/complaints');
            return;
        }

        $user = Auth::currentUser();
        $byUserId = (int)($user['id'] ?? 0);

        ComplaintsModel::resolve($complaintId, $resolutionText, $byUserId);
        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Complaint resolved'];
        redirect_route('students/complaints');
    }

    public function assessmentSettingsAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.assessment_settings']);

        $grades = Database::fetchAll('SELECT id, grade_letter, min_score, max_score, sort_order FROM grades ORDER BY sort_order ASC');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            foreach ($grades as $grade) {
                $id = (int)$grade['id'];
                $min = trim((string)($_POST['min_score'][$id] ?? ''));
                $max = trim((string)($_POST['max_score'][$id] ?? ''));
                if ($min === '' || $max === '') {
                    continue;
                }
                Database::execute(
                    'UPDATE grades SET min_score = ?, max_score = ? WHERE id = ?',
                    'ddi',
                    [(float)$min, (float)$max, $id]
                );
            }
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Grade settings updated'];
            redirect_route('students/index');
            return;
        }

        $this->render('students/assessment_settings', [
            'title' => 'Assessment Settings',
            'grades' => $grades,
        ]);
    }

    public function studentFormFieldsAction(): void
    {
        require_once __DIR__ . '/../models/CustomFieldModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.custom_fields']);

        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            $this->requireCsrf();
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'create') {
                CustomFieldModel::create('student', [
                    'field_key' => trim((string)($_POST['field_key'] ?? '')),
                    'label_text' => trim((string)($_POST['label_text'] ?? '')),
                    'field_type' => trim((string)($_POST['field_type'] ?? 'text')),
                    'options_text' => trim((string)($_POST['options_text'] ?? '')),
                    'is_required' => (int)($_POST['is_required'] ?? 0),
                ]);
                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Field created'];
                redirect_route('students/studentFormFields');
                return;
            }
        }

        $fields = CustomFieldModel::listByScope('student');
        $this->render('students/student_form_fields', [
            'title' => 'Student Forms (Custom Fields)',
            'fields' => $fields,
        ]);
    }

    public function studentFormValuesAction(): void
    {
        require_once __DIR__ . '/../models/CustomFieldModel.php';
        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.custom_fields']);

        $studentId = (int)($_GET['student_id'] ?? 0);
        if ($studentId <= 0) {
            http_response_code(404);
            echo 'Missing student_id';
            return;
        }

        $student = StudentModel::getById($studentId);
        if (!$student) {
            http_response_code(404);
            echo 'Student not found';
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $valuesByKey = [];
            foreach ($_POST as $k => $v) {
                if (strpos((string)$k, 'field_') === 0) {
                    $fieldKey = substr((string)$k, 6);
                    $valuesByKey[$fieldKey] = $v;
                }
            }
            CustomFieldModel::saveValuesForStudent($studentId, $valuesByKey, 'student');
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Student form values saved'];
            redirect_route('students/index');
            return;
        }

        $fieldsValues = CustomFieldModel::getValuesForStudent($studentId, 'student');
        $this->render('students/student_form_values', [
            'title' => 'Student Form Values',
            'student' => $student,
            'fieldsValues' => $fieldsValues,
        ]);
    }

    public function studentFormFieldsUpdateAction(): void
    {
        require_once __DIR__ . '/../models/CustomFieldModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.custom_fields']);
        $this->requireCsrf();

        $fieldId = (int)($_POST['id'] ?? 0);
        if ($fieldId <= 0) {
            redirect_route('students/studentFormFields');
            return;
        }

        $fieldType = trim((string)($_POST['field_type'] ?? 'text'));
        if (!in_array($fieldType, ['text', 'number', 'date', 'select', 'textarea'], true)) {
            $fieldType = 'text';
        }

        CustomFieldModel::update($fieldId, [
            'label_text' => trim((string)($_POST['label_text'] ?? '')),
            'field_type' => $fieldType,
            'options_text' => trim((string)($_POST['options_text'] ?? '')),
            'is_required' => (int)($_POST['is_required'] ?? 0),
        ]);

        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Field updated'];
        redirect_route('students/studentFormFields');
    }

    public function studentFormFieldsDeleteAction(): void
    {
        require_once __DIR__ . '/../models/CustomFieldModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.custom_fields']);
        $this->requireCsrf();

        $fieldId = (int)($_POST['id'] ?? 0);
        if ($fieldId > 0) {
            CustomFieldModel::delete($fieldId);
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Field deleted'];
        }
        redirect_route('students/studentFormFields');
    }

    /**
     * Show the standalone photo upload form (for existing students).
     * Route: students/uploadPhoto
     */
    public function uploadPhotoAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.photo_upload']);

        $studentId = (int)($_GET['student_id'] ?? 0);
        $student   = $studentId > 0 ? StudentModel::getById($studentId) : null;

        $this->render('students/upload_photo', [
            'title'   => 'Upload Student Photo',
            'student' => $student,
        ]);
    }

    /**
     * Handle photo upload POST.
     * Route: students/uploadPhotoStore
     */
    public function uploadPhotoStoreAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLogin();
        $this->requirePermission(['students.manage', 'students.photo_upload']);
        $this->requireCsrf();

        $studentId = (int)($_POST['student_id'] ?? 0);
        if ($studentId <= 0) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Invalid student ID'];
            redirect_route('students/uploadPhoto');
            return;
        }

        $student = StudentModel::getById($studentId);
        if (!$student) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Student not found'];
            redirect_route('students/uploadPhoto');
            return;
        }

        // Validate + save upload (shared with create/edit — see saveStudentPhoto()).
        if (empty($_FILES['photo']['tmp_name'])) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'No file uploaded'];
            redirect('/index.php?route=students/uploadPhoto&student_id=' . $studentId);
            return;
        }

        $photoError = $this->saveStudentPhoto($studentId, $_FILES['photo']);
        if ($photoError !== null) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Photo upload failed: ' . $photoError . '.'];
            redirect('/index.php?route=students/uploadPhoto&student_id=' . $studentId);
            return;
        }

        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Photo uploaded successfully'];
        redirect('/index.php?route=students/uploadPhoto&student_id=' . $studentId);
    }

    /**
     * AJAX endpoint: search students and return JSON.
     * Route: students/searchJson
     */
    public function searchJsonAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLogin();

        $q             = trim((string)($_GET['q'] ?? ''));
        $classSectionId = (int)($_GET['class_section_id'] ?? 0);
        $scope         = trim((string)($_GET['scope'] ?? ''));

        // The report-card search box must not surface students whose class has
        // no published exam — a non-admin couldn't open a report card for them
        // anyway (see AcademicController::certificateAction), so don't let them
        // show up in the picker either. Only applies to that one caller
        // (scope=report_card); id card / photo upload searches are unaffected.
        $onlyPublishedExamClasses = ($scope === 'report_card' && !RBAC::isAdmin());

        // Browsing a class roster (class picked, nothing typed yet) shows the
        // whole class sorted by roll number instead of the usual 20-result,
        // newest-first search behaviour.
        $browsingClass = ($q === '' && $classSectionId > 0);

        $rows = StudentModel::list(
            $q,
            $classSectionId > 0 ? $classSectionId : null,
            $browsingClass ? 100 : 20,
            0,
            null,
            $onlyPublishedExamClasses,
            $browsingClass
        );

        $results = array_map(fn($r) => [
            'id'           => (int)$r['id'],
            'name'         => trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? '')),
            'admission_no' => $r['admission_no'] ?? '',
            'class'        => trim(($r['current_class_name'] ?? '') . ' ' . ($r['current_section_name'] ?? '')),
        ], $rows);

        header('Content-Type: application/json');
        echo json_encode(['results' => $results]);
        exit;
    }
}