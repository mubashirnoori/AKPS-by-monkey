<?php

class PortalController extends Controller
{
    public function indexAction(): void
    {
        require_once __DIR__ . '/../models/PortalModel.php';
        require_once __DIR__ . '/../models/StudentModel.php';

        $user = Auth::requireLogin();
        $this->requirePermission('portal.access');
        $role = RBAC::roleName();

        switch ($role) {
            case 'student':
                $this->renderStudent($user);
                return;
            case 'parent':
                $this->renderParent($user);
                return;
            case 'teacher':
            case 'principal':
                $this->renderTeacher($user);
                return;
            case 'accountant':
                $this->renderAccountant($user);
                return;
            default:
                // Admin always has the full dashboard. Any other role without a
                // dedicated portal view (e.g. a custom "Principal" role) falls back
                // to the generic module-list landing page — NOT dashboard/index,
                // which would immediately bounce non-admins straight back here and
                // create an infinite redirect loop.
                if (RBAC::isAdmin()) {
                    redirect_route('dashboard/index');
                } else {
                    redirect_route('dashboard/landing');
                }
                return;
        }
    }

    private function renderStudent(array $user): void
    {
        $studentId = RBAC::currentStudentId();

        if (!$studentId) {
            $this->render('dashboard/portal_unlinked', [
                'title' => 'My Portal',
                'roleLabel' => 'Student',
            ]);
            return;
        }

        $profile = PortalModel::studentProfile($studentId);
        $attendance = PortalModel::studentAttendanceSummary($studentId);
        $results = PortalModel::studentResults($studentId);
        $pendingResultsCount = PortalModel::studentPendingResultsCount($studentId);
        $invoices = PortalModel::studentFeeInvoices($studentId, 5);
        $invoicesTotalCount = PortalModel::studentFeeInvoicesCount($studentId);
        $courses = PortalModel::studentCourses($studentId);
        $leaveRequests = PortalModel::studentOwnLeaveRequests($studentId);
        $classSectionId = $profile['current_class_section_id'] ?? null;
        $timetable = $classSectionId ? PortalModel::studentTimetable((int)$classSectionId) : [];

        require_once __DIR__ . '/../models/NotificationModel.php';
        $announcements = NotificationModel::listForUser((int)$user['id'], 6);

        $this->render('dashboard/portal_student', [
            'title' => 'My Portal',
            'profile' => $profile,
            'attendance' => $attendance,
            'results' => $results,
            'pendingResultsCount' => $pendingResultsCount,
            'invoices' => $invoices,
            'invoicesTotalCount' => $invoicesTotalCount,
            'courses' => $courses,
            'timetable' => $timetable,
            'leaveRequests' => $leaveRequests,
            'announcements' => $announcements,
        ]);
    }

    private function renderParent(array $user): void
    {
        $guardianId = RBAC::currentGuardianId();

        if (!$guardianId) {
            $this->render('dashboard/portal_unlinked', [
                'title' => 'My Portal',
                'roleLabel' => 'Parent',
            ]);
            return;
        }

        $children = PortalModel::guardianChildren($guardianId);
        $childIds = array_map(static fn($c) => (int)$c['id'], $children);

        $selectedId = (int)($_GET['student_id'] ?? 0);
        if ($selectedId <= 0 || !in_array($selectedId, $childIds, true)) {
            $selectedId = $childIds[0] ?? 0;
        }

        $profile = null;
        $attendance = null;
        $results = [];
        $pendingResultsCount = 0;
        $invoices = [];
        $invoicesTotalCount = 0;
        $courses = [];

        if ($selectedId > 0) {
            $profile = PortalModel::studentProfile($selectedId);
            $attendance = PortalModel::studentAttendanceSummary($selectedId);
            $results = PortalModel::studentResults($selectedId);
            $pendingResultsCount = PortalModel::studentPendingResultsCount($selectedId);
            $invoices = PortalModel::studentFeeInvoices($selectedId, 5);
            $invoicesTotalCount = PortalModel::studentFeeInvoicesCount($selectedId);
            $courses = PortalModel::studentCourses($selectedId);
        }

        $this->render('dashboard/portal_parent', [
            'title' => 'My Portal',
            'children' => $children,
            'selectedId' => $selectedId,
            'profile' => $profile,
            'attendance' => $attendance,
            'results' => $results,
            'pendingResultsCount' => $pendingResultsCount,
            'invoices' => $invoices,
            'invoicesTotalCount' => $invoicesTotalCount,
            'courses' => $courses,
        ]);
    }

    private function renderTeacher(array $user): void
    {
        $staffId = RBAC::currentStaffProfileId();

        if (!$staffId) {
            $this->render('dashboard/portal_unlinked', [
                'title' => 'My Portal',
                'roleLabel' => ucfirst(RBAC::roleName()),
            ]);
            return;
        }

        $profile = PortalModel::teacherProfile($staffId);
        $subjects = PortalModel::teacherSubjects($staffId);
        $classSectionIds = RBAC::currentTeacherClassSectionIds();
        $classes = PortalModel::teacherClassStudentCounts($classSectionIds);
        $attendance = PortalModel::teacherOwnAttendance($staffId);
        $leaveRequests = PortalModel::teacherOwnLeaveRequests($staffId);
        $performance = PortalModel::teacherOwnPerformanceReports($staffId);
        $recentActivities = PortalModel::teacherOwnRecentActivities((int)($user['id'] ?? 0));

        require_once __DIR__ . '/../models/StaffPayrollModel.php';
        $salaryRecent = StaffPayrollModel::recentSalaryForStaff($staffId, 3);
        $salaryTotalCount = StaffPayrollModel::countSalaryForStaff($staffId);

        require_once __DIR__ . '/../models/StaffFeeClassModel.php';
        $classTeacherSectionIds = RBAC::currentTeacherClassTeacherSectionIds();
        $feeClasses = StaffFeeClassModel::getClassesForStaff($staffId);

        $this->render('dashboard/portal_teacher', [
            'title' => 'My Portal',
            'profile' => $profile,
            'subjects' => $subjects,
            'classes' => $classes,
            'attendance' => $attendance,
            'leaveRequests' => $leaveRequests,
            'performance' => $performance,
            'recentActivities' => $recentActivities,
            'salaryRecent' => $salaryRecent,
            'salaryTotalCount' => $salaryTotalCount,
            'classTeacherSectionIds' => $classTeacherSectionIds,
            'feeClasses' => $feeClasses,
        ]);
    }

    private function renderAccountant(array $user): void
    {
        $today = PortalModel::accountantTodayCollections();
        $month = PortalModel::accountantMonthCollections();
        $pendingTotal = PortalModel::accountantPendingDuesTotal();
        $recent = PortalModel::accountantRecentCollections();
        $topPending = PortalModel::accountantTopPendingDues();

        $this->render('dashboard/portal_accountant', [
            'title' => 'My Portal',
            'today' => $today,
            'month' => $month,
            'pendingTotal' => $pendingTotal,
            'recent' => $recent,
            'topPending' => $topPending,
        ]);
    }

    /**
     * Submit a leave request for the logged-in Student or Teacher — the
     * applicant's own student_id / staff_profile_id is always resolved
     * server-side from the session, never taken from POST, so nobody can
     * submit a leave request on someone else's behalf.
     */
    public function leaveApplyAction(): void
    {
        require_once __DIR__ . '/../models/LeaveRequestModel.php';
        require_once __DIR__ . '/../models/NotificationModel.php';

        $user = Auth::requireLogin();
        $this->requirePermission('portal.access');

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect_route('portal/index');
            return;
        }
        $this->requireCsrf();

        $fromDate = trim((string)($_POST['from_date'] ?? ''));
        $toDate = trim((string)($_POST['to_date'] ?? ''));
        $leaveType = trim((string)($_POST['leave_type'] ?? 'leave'));
        $note = trim((string)($_POST['note'] ?? ''));
        $byUserId = (int)($user['id'] ?? 0);

        if ($fromDate === '' || $toDate === '') {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Please provide both a from and to date'];
            redirect_route('portal/index');
            return;
        }

        if (RBAC::isTeacher()) {
            $staffId = RBAC::currentStaffProfileId();
            if (!$staffId) {
                $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Your account is not linked to a staff record yet'];
                redirect_route('portal/index');
                return;
            }
            try {
                LeaveRequestModel::createForStaff([
                    'staff_profile_id' => $staffId,
                    'leave_type' => $leaveType,
                    'from_date' => $fromDate,
                    'to_date' => $toDate,
                    'note' => $note,
                ], $byUserId);
                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Leave request submitted'];
                log_activity('portal.leave_apply', 'Applied for ' . $leaveType . ' leave (' . $fromDate . ' to ' . $toDate . ')');

                NotificationModel::notifyByPermission(
                    'staff.manage',
                    'leave_request',
                    'New leave request',
                    ($user['username'] ?? 'A staff member') . ' requested ' . $leaveType . ' leave from ' . $fromDate . ' to ' . $toDate . '.',
                    route_url('staff/leaves'),
                    $byUserId
                );
            } catch (RuntimeException $e) {
                $_SESSION['flash'] = ['type' => 'danger', 'message' => $e->getMessage()];
            }
        } elseif (RBAC::isStudent()) {
            $studentId = RBAC::currentStudentId();
            if (!$studentId) {
                $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Your account is not linked to a student record yet'];
                redirect_route('portal/index');
                return;
            }
            try {
                LeaveRequestModel::createForStudent([
                    'student_id' => $studentId,
                    'leave_type' => $leaveType,
                    'from_date' => $fromDate,
                    'to_date' => $toDate,
                    'note' => $note,
                ], $byUserId);
                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Leave request submitted'];
                log_activity('portal.leave_apply', 'Applied for ' . $leaveType . ' leave (' . $fromDate . ' to ' . $toDate . ')');

                NotificationModel::notifyByPermission(
                    ['students.manage', 'students.leave_approve'],
                    'leave_request',
                    'New student leave request',
                    ($user['username'] ?? 'A student') . ' requested ' . $leaveType . ' leave from ' . $fromDate . ' to ' . $toDate . '.',
                    route_url('students/leaves'),
                    $byUserId
                );
            } catch (RuntimeException $e) {
                $_SESSION['flash'] = ['type' => 'danger', 'message' => $e->getMessage()];
            }
        } else {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Leave requests are only available for Student and Teacher accounts'];
        }

        redirect_route('portal/index');
    }

    /**
     * Invoice detail for Student/Parent — shows which months/fees an invoice
     * actually covers and its payment history. Always verifies the invoice
     * belongs to the logged-in student (or one of the guardian's own
     * children) before showing anything.
     */
    /**
     * Full invoice history for the logged-in student — kept off the main portal
     * dashboard (which only shows the last few invoices) so the dashboard doesn't
     * grow forever as more invoices are issued over the years.
     */
    public function myFeesAction(): void
    {
        require_once __DIR__ . '/../models/PortalModel.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        $studentId = 0;
        if (RBAC::isStudent()) {
            $studentId = (int)(RBAC::currentStudentId() ?? 0);
        } elseif (RBAC::isParent()) {
            $requested = (int)($_GET['student_id'] ?? 0);
            $childIds = RBAC::currentGuardianChildIds();
            $studentId = in_array($requested, $childIds, true) ? $requested : (int)($childIds[0] ?? 0);
        }

        if (!$studentId) {
            $this->render('dashboard/portal_unlinked', [
                'title' => 'My Fees',
                'roleLabel' => RBAC::isParent() ? 'Parent' : 'Student',
            ]);
            return;
        }

        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 15;
        $offset = ($page - 1) * $perPage;

        $invoices = PortalModel::studentFeeInvoicesPage($studentId, $perPage, $offset);
        $total = PortalModel::studentFeeInvoicesCount($studentId);

        $this->render('dashboard/portal_fees_history', [
            'title' => 'My Fees',
            'invoices' => $invoices,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'studentId' => $studentId,
            'isParentView' => RBAC::isParent(),
        ]);
    }

    public function invoiceViewAction(): void
    {
        require_once __DIR__ . '/../models/FeeInvoiceModel.php';
        require_once __DIR__ . '/../services/FeeService.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        $invoiceId = (int)($_GET['invoice_id'] ?? 0);
        $invoice = $invoiceId > 0 ? FeeInvoiceModel::getInvoice($invoiceId) : null;

        $allowedStudentIds = [];
        if (RBAC::isStudent()) {
            $sid = RBAC::currentStudentId();
            if ($sid) {
                $allowedStudentIds = [$sid];
            }
        } elseif (RBAC::isParent()) {
            $allowedStudentIds = RBAC::currentGuardianChildIds();
        }

        $allowedByFeeClass = $invoice && RBAC::isTeacher() && $this->teacherOwnsInvoiceClass((int)$invoice['student_id']);

        if (!$invoice || (!in_array((int)$invoice['student_id'], $allowedStudentIds, true) && !$allowedByFeeClass)) {
            http_response_code(403);
            require __DIR__ . '/../views/errors/403.php';
            exit;
        }

        $returnUrl = $this->sanitizeReturnUrl((string)($_GET['return'] ?? ''), 'portal/feeClassStudents');

        $lines = FeeInvoiceModel::getInvoiceLines($invoiceId);
        $collections = FeeInvoiceModel::getInvoiceCollections($invoiceId);

        // Paid/pending per line (per month), so it's clear at a glance which months are settled.
        $lineBalances = [];
        foreach (FeeService::getInvoiceLineBalances($invoiceId) as $lb) {
            $lineBalances[(int)$lb['id']] = $lb;
        }

        $this->render('dashboard/portal_invoice_view', [
            'title' => 'Invoice ' . ($invoice['invoice_no'] ?? ''),
            'invoice' => $invoice,
            'lines' => $lines,
            'lineBalances' => $lineBalances,
            'collections' => $collections,
            'canCollectFee' => $allowedByFeeClass,
            'returnUrl' => $returnUrl,
        ]);
    }

    /** True if the logged-in teacher is assigned (by Admin) to collect fees for the class this student currently belongs to. */
    private function teacherOwnsInvoiceClass(int $studentId): bool
    {
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/StaffFeeClassModel.php';

        $staffId = RBAC::currentStaffProfileId();
        if (!$staffId) {
            return false;
        }
        $classSectionId = StudentModel::getCurrentClassSectionId($studentId);
        if (!$classSectionId) {
            return false;
        }
        return StaffFeeClassModel::isAssigned($staffId, $classSectionId);
    }

    /**
     * Students of a class the teacher is assigned to collect fees for
     * (assigned by Admin via Staff → Fee Collection Assignments). Shows
     * each student's latest invoice with View / Collect Payment / Print
     * buttons only — no edit or delete, matching the admin fee screens
     * but scoped strictly to this teacher's assigned classes.
     */
    /**
     * Validates a "return to the filtered list" URL supplied via ?return=,
     * rebuilding it from parsed pieces rather than ever trusting the raw
     * string as a redirect target (open-redirect guard). Only accepts a URL
     * that points back at this same app, at exactly the given route — any
     * mismatch (different host/scheme, wrong route, unparseable) returns
     * null and callers fall back to their normal default link/redirect.
     * Query values themselves aren't whitelisted here since the destination
     * controller (e.g. feeClassStudentsAction) already validates every
     * filter it reads before using it.
     */
    private function sanitizeReturnUrl(?string $raw, string $expectedRoute): ?string
    {
        if (!$raw) {
            return null;
        }
        $parsed = parse_url($raw);
        if ($parsed === false || !isset($parsed['path'])) {
            return null;
        }

        $config = require __DIR__ . '/../../config/config.php';
        $appParts = parse_url(rtrim((string)($config['app']['base_url'] ?? ''), '/'));

        $expectedHost = $appParts['host'] ?? null;
        if ($expectedHost !== null) {
            if (($parsed['host'] ?? '') !== $expectedHost) {
                return null;
            }
            if (($parsed['scheme'] ?? '') !== ($appParts['scheme'] ?? 'https')) {
                return null;
            }
        } elseif (!empty($parsed['host'])) {
            // App configured with a relative base_url but the supplied URL
            // has a host anyway — reject rather than guess.
            return null;
        }

        $expectedPath = rtrim((string)($appParts['path'] ?? ''), '/') . '/index.php';
        if (($parsed['path'] ?? '') !== $expectedPath) {
            return null;
        }

        parse_str($parsed['query'] ?? '', $query);
        if ((string)($query['route'] ?? '') !== $expectedRoute) {
            return null;
        }

        return base_url('/index.php?' . http_build_query($query));
    }

    public function feeClassStudentsAction(): void
    {
        require_once __DIR__ . '/../models/StaffFeeClassModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/FeeInvoiceModel.php';
        require_once __DIR__ . '/../services/FeeService.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        if (!RBAC::isTeacher()) {
            http_response_code(403);
            require __DIR__ . '/../views/errors/403.php';
            exit;
        }

        $staffId = RBAC::currentStaffProfileId();
        $classSectionId = (int)($_GET['class_section_id'] ?? 0);

        if (!$staffId || !$classSectionId || !StaffFeeClassModel::isAssigned($staffId, $classSectionId)) {
            http_response_code(403);
            require __DIR__ . '/../views/errors/403.php';
            exit;
        }

        $classSection = ClassSectionModel::getById($classSectionId);

        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = (int)($_GET['per_page'] ?? 25);
        $perPage = in_array($perPage, [25, 50, 100], true) ? $perPage : 25;
        $status = (string)($_GET['status'] ?? '');
        $status = in_array($status, ['open', 'paid', 'cancelled'], true) ? $status : '';
        $month = (int)($_GET['month'] ?? 0);
        $month = ($month >= 1 && $month <= 12) ? $month : 0;
        // Capped length purely to keep the query/URL sane — the LIKE clause
        // itself is parameterized, so this isn't a SQL-injection guard.
        $search = mb_substr(trim((string)($_GET['search'] ?? '')), 0, 100);

        $result = FeeInvoiceModel::listForClassSection($classSectionId, $page, $perPage, $status, $month, $search);

        $this->render('dashboard/portal_fee_class_students', [
            'title' => 'Fee Collection — ' . trim(($classSection['class_name'] ?? '') . ' ' . ($classSection['section_name'] ?? '')),
            'classSection' => $classSection,
            'invoices' => $result['rows'],
            'total' => $result['total'],
            'page' => $result['page'],
            'perPage' => $result['perPage'],
            'status' => $result['status'],
            'month' => $result['month'],
            'search' => $result['search'],
            'classSectionId' => $classSectionId,
        ]);
    }

    /**
     * "Collect Payment" as a popup for the Teacher Portal: an AJAX endpoint used
     * from the class fee list / invoice view pages so collecting a payment
     * doesn't navigate away from the Teacher Portal. Mirrors
     * FeesController::collectModalAction() but stays scoped to classes this
     * teacher is assigned to collect fees for (same check as feeCollectAction),
     * since this endpoint has no admin "on behalf of" picker and must never be
     * usable to collect against a student outside the teacher's own classes.
     * GET returns the form as an HTML fragment (for the modal body); POST
     * records the payment and returns JSON.
     */
    public function feeCollectModalAction(): void
    {
        require_once __DIR__ . '/../models/FeeInvoiceModel.php';
        require_once __DIR__ . '/../services/FeeService.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        $invoiceId = (int)($_GET['invoice_id'] ?? ($_POST['invoice_id'] ?? 0));
        $invoiceRow = $invoiceId > 0 ? FeeInvoiceModel::getInvoice($invoiceId) : null;
        $authorized = RBAC::isTeacher() && $invoiceRow && $this->teacherOwnsInvoiceClass((int)$invoiceRow['student_id']);

        if (!$authorized) {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $this->jsonResponse(['success' => false, 'message' => 'You are not authorized to collect this invoice.'], 403);
            } else {
                http_response_code(403);
                echo '<div class="alert alert-danger mb-0">You are not authorized to collect this invoice.</div>';
            }
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                $this->requireCsrf();
                $amount = (float)($_POST['amount'] ?? 0);
                $method = trim((string)($_POST['method'] ?? 'cash'));
                $notes = trim((string)($_POST['notes'] ?? ''));
                $lineIds = array_map('intval', (array)($_POST['line_ids'] ?? []));
                $user = Auth::currentUser();

                FeeService::recordPayment($invoiceId, $amount, $method !== '' ? $method : 'cash', $notes !== '' ? $notes : null, $user['id'] ?? null, $lineIds);
                log_activity(
                    'fees.collect',
                    'Collected Rs ' . number_format($amount, 2) . ' via ' . ($method !== '' ? $method : 'cash') . ' for invoice #' . ($invoiceRow['invoice_no'] ?? $invoiceId)
                );

                $this->jsonResponse([
                    'success' => true,
                    'message' => 'Rs ' . number_format($amount, 2) . ' recorded for invoice #' . ($invoiceRow['invoice_no'] ?? $invoiceId) . '.',
                ]);
            } catch (Throwable $e) {
                $this->jsonResponse(['success' => false, 'message' => $e->getMessage()], 422);
            }
            return;
        }

        $invoice = FeeService::getInvoiceDetails($invoiceId);
        if (!$invoice) {
            http_response_code(404);
            echo '<div class="alert alert-danger mb-0">Invoice not found.</div>';
            return;
        }

        echo $this->renderPartial('fees/_collect_modal', [
            'invoice'                => $invoice,
            'invoiceId'              => $invoiceId,
            'onBehalfOptions'        => [],
            'onBehalfDefaultStaffId' => 0,
            'showOnBehalfPicker'     => false,
        ]);
    }

    /** Teacher collects a payment against an invoice, scoped to a class they're assigned to collect fees for. */
    public function feeCollectAction(): void
    {
        require_once __DIR__ . '/../models/FeeInvoiceModel.php';
        require_once __DIR__ . '/../services/FeeService.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        if (!RBAC::isTeacher()) {
            http_response_code(403);
            require __DIR__ . '/../views/errors/403.php';
            exit;
        }

        $invoiceId = (int)($_GET['invoice_id'] ?? ($_POST['invoice_id'] ?? 0));
        $invoice = $invoiceId > 0 ? FeeInvoiceModel::getInvoice($invoiceId) : null;

        if (!$invoice || !$this->teacherOwnsInvoiceClass((int)$invoice['student_id'])) {
            http_response_code(403);
            require __DIR__ . '/../views/errors/403.php';
            exit;
        }

        // Carried through GET -> form hidden field -> POST, so a successful
        // payment can send the teacher straight back to their filtered class
        // list (via invoiceView's own return link) instead of losing the
        // filters at the first hop. Re-validated on every read since it's
        // untrusted input either way.
        $returnRaw = (string)($_GET['return'] ?? ($_POST['return'] ?? ''));
        $returnUrl = $this->sanitizeReturnUrl($returnRaw, 'portal/feeClassStudents');

        $error = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $amount = (float)($_POST['amount'] ?? 0);
            $method = trim((string)($_POST['method'] ?? 'cash'));
            $notes = trim((string)($_POST['notes'] ?? ''));
            $lineIds = array_map('intval', (array)($_POST['line_ids'] ?? []));
            $user = Auth::currentUser();

            try {
                FeeService::recordPayment($invoiceId, $amount, $method !== '' ? $method : 'cash', $notes !== '' ? $notes : null, $user['id'] ?? null, $lineIds);
                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Payment recorded'];
                log_activity('fees.collect', 'Collected Rs ' . number_format($amount, 2) . ' via ' . ($method !== '' ? $method : 'cash') . ' for invoice #' . $invoiceId);
                $redirectUrl = '/index.php?route=' . rawurlencode('portal/invoiceView') . '&invoice_id=' . $invoiceId;
                if ($returnUrl !== null) {
                    $redirectUrl .= '&return=' . rawurlencode($returnUrl);
                }
                redirect($redirectUrl);
                return;
            } catch (Throwable $e) {
                $error = $e->getMessage();
            }
        }

        $invoice = FeeInvoiceModel::getInvoice($invoiceId);
        $lineBalances = FeeService::getInvoiceLineBalances($invoiceId);

        $this->render('dashboard/portal_fee_collect', [
            'title' => 'Collect Payment — ' . ($invoice['invoice_no'] ?? ''),
            'invoice' => $invoice,
            'lineBalances' => $lineBalances,
            'error' => $error,
            'returnUrl' => $returnUrl,
        ]);
    }

    /**
     * "My Fee Ledger" — Teacher/Principal only. Shows what they've personally
     * collected (from fee_collections), what they've handed over and had
     * confirmed, what's pending confirmation, and the net balance they're
     * still holding — plus the form to submit a new handover.
     */
    public function myFeeLedgerAction(): void
    {
        require_once __DIR__ . '/../models/FeeHandoverModel.php';
        require_once __DIR__ . '/../models/StaffFeeClassModel.php';

        Auth::requireLogin();
        $this->requirePermission('fees.handover_submit');

        if (!in_array(RBAC::roleName(), ['teacher', 'principal'], true)) {
            redirect_route('portal/index');
            return;
        }

        $staffId = RBAC::currentStaffProfileId();
        if (!$staffId) {
            $this->render('dashboard/portal_unlinked', [
                'title' => 'My Fee Ledger',
                'roleLabel' => ucfirst(RBAC::roleName()),
            ]);
            return;
        }

        $onBehalfPerPage = 20;
        $onBehalfTotal = FeeHandoverModel::onBehalfCollectionsCountForStaff($staffId);
        $onBehalfTotalPages = max(1, (int)ceil($onBehalfTotal / $onBehalfPerPage));
        $onBehalfPage = max(1, (int)($_GET['ocpage'] ?? 1));
        if ($onBehalfPage > $onBehalfTotalPages) {
            $onBehalfPage = $onBehalfTotalPages;
        }

        $this->render('dashboard/portal_fee_ledger', [
            'title' => 'My Fee Ledger',
            'ledger' => FeeHandoverModel::ledgerForStaff($staffId),
            'handovers' => FeeHandoverModel::getForStaff($staffId),
            'recipients' => FeeHandoverModel::possibleRecipients(),
            'collectionSummary' => StaffFeeClassModel::collectionSummaryForStaff($staffId),
            'onBehalfCollections' => FeeHandoverModel::onBehalfCollectionsForStaff($staffId, $onBehalfPerPage, $onBehalfPage),
            'onBehalfTotal' => $onBehalfTotal,
            'onBehalfPage' => $onBehalfPage,
            'onBehalfPerPage' => $onBehalfPerPage,
            'onBehalfTotalPages' => $onBehalfTotalPages,
        ]);
    }

    /** Teacher/Principal submits a handover claim for cash they collected. Starts 'pending' until confirmed. */
    public function handoverSubmitAction(): void
    {
        require_once __DIR__ . '/../models/FeeHandoverModel.php';
        require_once __DIR__ . '/../models/NotificationModel.php';

        Auth::requireLogin();
        $this->requirePermission('fees.handover_submit');
        $this->requireCsrf();

        if (!in_array(RBAC::roleName(), ['teacher', 'principal'], true)) {
            redirect_route('portal/index');
            return;
        }

        $staffId = RBAC::currentStaffProfileId();
        $amount = (float)($_POST['amount'] ?? 0);
        $recipientUserId = (int)($_POST['handed_over_to_user_id'] ?? 0);
        $note = trim((string)($_POST['note'] ?? ''));
        $user = Auth::currentUser();

        if ($staffId && $amount > 0 && $recipientUserId > 0) {
            // Never let a claimed handover exceed what's actually still
            // outstanding -- guards against typos and duplicate submissions
            // inflating the pending queue past what was really collected.
            $ledger = FeeHandoverModel::ledgerForStaff($staffId);
            $outstanding = $ledger['net_balance'] - $ledger['pending_handover'];
            if ($amount > $outstanding + 0.01) {
                $_SESSION['flash'] = ['type' => 'danger', 'message' => 'That amount is more than your outstanding balance (Rs ' . number_format($outstanding, 2) . ' not yet handed over or already pending confirmation).'];
                redirect_route('portal/myFeeLedger');
                return;
            }

            $handoverId = FeeHandoverModel::create($staffId, $amount, $recipientUserId, $note !== '' ? $note : null, (int)($user['id'] ?? 0));
            log_activity('fees.handover_submit', 'Submitted fee handover of Rs ' . number_format($amount, 2) . ' (#' . $handoverId . ')');

            NotificationModel::create(
                $recipientUserId,
                'fee_handover',
                'Fee handover awaiting confirmation',
                ($user['username'] ?? 'A staff member') . ' says they handed you Rs ' . number_format($amount, 2) . ' in collected fees.' . ($note !== '' ? ' Note: ' . $note : ''),
                route_url('fees/teacherLedger')
            );

            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Handover submitted — it will show as confirmed once the recipient verifies it.'];
        } else {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Enter a valid amount and choose who you handed the cash to.'];
        }

        redirect_route('portal/myFeeLedger');
    }

    /** Same invoice as portal/invoiceView but rendered via the admin print template, for the teacher's Print button. */
    public function feeInvoicePrintAction(): void
    {
        require_once __DIR__ . '/../models/FeeInvoiceModel.php';
        require_once __DIR__ . '/../services/FeeService.php';


        Auth::requireLogin();
        $this->requirePermission('portal.access');

        if (!RBAC::isTeacher()) {
            http_response_code(403);
            require __DIR__ . '/../views/errors/403.php';
            exit;
        }

        $invoiceId = (int)($_GET['invoice_id'] ?? 0);
        $invoiceMeta = $invoiceId > 0 ? FeeInvoiceModel::getInvoice($invoiceId) : null;

        if (!$invoiceMeta || !$this->teacherOwnsInvoiceClass((int)$invoiceMeta['student_id'])) {
            http_response_code(403);
            require __DIR__ . '/../views/errors/403.php';
            exit;
        }

        $invoice = FeeService::getInvoiceDetails($invoiceId);

        // See FeesController::invoicePrintAction() — invoice_print.php is a
        // standalone HTML document; output it directly so it isn't nested
        // inside the app shell (that's what was showing the header on print).
        echo $this->renderPartial('fees/invoice_print', [
            'title' => 'Invoice ' . ($invoice['invoice_no'] ?? ''),
            'invoice' => $invoice,
        ]);
    }

    /**
     * Whole-day attendance for a class, restricted to the staff member marked
     * as that class's Class Teacher (set by Admin in Academic → Class Sections).
     */
    public function takeAttendanceAction(): void
    {
        require_once __DIR__ . '/../models/ClassSectionModel.php';
        require_once __DIR__ . '/../models/AttendanceModel.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        if (!RBAC::isTeacher()) {
            http_response_code(403);
            require __DIR__ . '/../views/errors/403.php';
            exit;
        }

        $myClassTeacherSectionIds = RBAC::currentTeacherClassTeacherSectionIds();
        $classSectionId = (int)($_GET['class_section_id'] ?? ($_POST['class_section_id'] ?? ($myClassTeacherSectionIds[0] ?? 0)));

        if (!in_array($classSectionId, $myClassTeacherSectionIds, true)) {
            http_response_code(403);
            require __DIR__ . '/../views/errors/403.php';
            exit;
        }

        $error = null;
        $attendanceDate = trim((string)($_POST['attendance_date'] ?? ($_GET['attendance_date'] ?? date('Y-m-d'))));

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $statuses = (array)($_POST['status'] ?? []);
            $user = Auth::currentUser();
            AttendanceModel::save($classSectionId, $attendanceDate, null, $statuses, $user['id'] ?? null);
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Attendance saved'];
            $csInfo = ClassSectionModel::getById($classSectionId);
            $csLabel = $csInfo ? trim(($csInfo['class_name'] ?? '') . ' ' . ($csInfo['section_name'] ?? '')) : ('#' . $classSectionId);
            log_activity('academic.attendance_take', 'Took attendance for ' . $csLabel . ' on ' . $attendanceDate . ' (' . count($statuses) . ' student(s))');
            redirect('/index.php?route=' . rawurlencode('portal/takeAttendance') . '&class_section_id=' . $classSectionId . '&attendance_date=' . $attendanceDate);
            return;
        }

        $classSections = [];
        foreach ($myClassTeacherSectionIds as $csId) {
            $cs = ClassSectionModel::getById($csId);
            if ($cs) {
                $classSections[] = $cs;
            }
        }
        $students = AttendanceModel::getStudentsWithStatus($classSectionId, $attendanceDate, null);

        $this->render('dashboard/portal_take_attendance', [
            'title' => 'Take Attendance',
            'error' => $error,
            'classSections' => $classSections,
            'classSectionId' => $classSectionId,
            'attendanceDate' => $attendanceDate,
            'students' => $students,
        ]);
    }

    /**
     * Full salary history for the logged-in teacher/staff member — kept off the main
     * portal dashboard (which only shows the last few months) so the dashboard doesn't
     * grow forever as more months pass. Mirrors the Student portal's fee-invoice pattern.
     */
    public function mySalaryAction(): void
    {
        require_once __DIR__ . '/../models/StaffPayrollModel.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        $staffId = RBAC::currentStaffProfileId();
        if (!$staffId) {
            $this->render('dashboard/portal_unlinked', [
                'title' => 'My Salary',
                'roleLabel' => 'Teacher',
            ]);
            return;
        }

        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 12;
        $offset = ($page - 1) * $perPage;

        $records = StaffPayrollModel::listSalaryHistoryForStaff($staffId, $perPage, $offset);
        $total = StaffPayrollModel::countSalaryForStaff($staffId);

        $this->render('dashboard/portal_salary_history', [
            'title' => 'My Salary',
            'records' => $records,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
        ]);
    }

    /** One month's salary breakdown + payment installments, for the owning staff member only. */
    public function salaryViewAction(): void
    {
        require_once __DIR__ . '/../models/StaffPayrollModel.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        $staffId = RBAC::currentStaffProfileId();
        $salaryDetailId = (int)($_GET['salary_detail_id'] ?? 0);
        $record = $staffId ? StaffPayrollModel::getSalaryDetailForStaff($salaryDetailId, $staffId) : null;

        if (!$record) {
            http_response_code(403);
            require __DIR__ . '/../views/errors/403.php';
            exit;
        }

        $payments = StaffPayrollModel::getPayments($salaryDetailId);
        $totalPaid = StaffPayrollModel::getTotalPaid($salaryDetailId);

        $this->render('dashboard/portal_salary_view', [
            'title' => 'Salary Detail',
            'record' => $record,
            'payments' => $payments,
            'totalPaid' => $totalPaid,
        ]);
    }

    /**
     * A single course's resources ("curriculum"), reachable from the course
     * card's eye icon on the Student/Parent portal. Re-verifies the course is
     * actually assigned to the viewing student — never trusts the URL alone.
     */
    public function courseAction(): void
    {
        require_once __DIR__ . '/../models/PortalModel.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        $courseId = (int)($_GET['course_id'] ?? 0);
        $studentId = null;
        $backUrl = route_url('portal/index');

        if (RBAC::isStudent()) {
            $studentId = RBAC::currentStudentId();
        } elseif (RBAC::isParent()) {
            $childIds = RBAC::currentGuardianChildIds();
            $requested = (int)($_GET['student_id'] ?? 0);
            if ($requested > 0 && in_array($requested, $childIds, true)) {
                $studentId = $requested;
            } elseif (!empty($childIds)) {
                $studentId = $childIds[0];
            }
            if ($studentId) {
                $backUrl = route_url('portal/index') . '&student_id=' . $studentId;
            }
        }

        if (!$studentId || $courseId <= 0) {
            redirect_route('portal/index');
            return;
        }

        $course = PortalModel::studentCourseDetail($studentId, $courseId);
        if (!$course) {
            // Not assigned to this student (or doesn't exist) — don't leak that
            // the course exists, just send them back to their own portal.
            redirect_route('portal/index');
            return;
        }

        $this->render('dashboard/portal_course_view', [
            'title' => $course['title'] ?? 'Course',
            'course' => $course,
            'studentId' => $studentId,
            'isParentView' => RBAC::isParent(),
            'backUrl' => $backUrl,
        ]);
    }

    /**
     * Called via fetch() from the video player on the Student portal to record
     * watch progress. Always resolves the student from the session — never
     * trusts a posted student id — and verifies the resource actually belongs
     * to a course assigned to them before recording anything.
     */
    public function resourceProgressAction(): void
    {
        require_once __DIR__ . '/../models/OnlineCourseModel.php';

        Auth::requireLogin();
        header('Content-Type: application/json; charset=utf-8');

        if (!RBAC::isStudent() || $_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(403);
            echo json_encode(['ok' => false]);
            return;
        }

        try {
            $this->requireCsrf();
        } catch (Throwable $e) {
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'Invalid session, please refresh the page']);
            return;
        }

        $studentId = RBAC::currentStudentId();
        if (!$studentId) {
            http_response_code(403);
            echo json_encode(['ok' => false]);
            return;
        }

        $resourceId = (int)($_POST['resource_id'] ?? 0);
        $percent = (float)($_POST['percent'] ?? 0);
        $position = (int)($_POST['position'] ?? 0);

        $resource = $resourceId > 0 ? OnlineCourseModel::getResource($resourceId) : null;
        if (!$resource || $resource['resource_type'] !== 'video' || $resource['source_type'] !== 'upload') {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => 'Not a trackable video']);
            return;
        }

        $assigned = in_array((int)$resource['course_id'], array_map(
            static fn($c) => (int)$c['id'],
            OnlineCourseModel::listForStudent($studentId)
        ), true);
        if (!$assigned) {
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'Course not assigned to you']);
            return;
        }

        OnlineCourseModel::recordProgress($resourceId, $studentId, $percent, $position);
        echo json_encode(['ok' => true]);
    }

    /**
     * Resolves which student a Student/Parent-facing portal page is about.
     * Student: always their own record. Parent: the ?student_id= in the URL if
     * it's actually one of their children, otherwise their first child.
     */
    private function resolvePortalStudentId(): ?int
    {
        if (RBAC::isStudent()) {
            return RBAC::currentStudentId();
        }
        if (RBAC::isParent()) {
            $childIds = RBAC::currentGuardianChildIds();
            $requested = (int)($_GET['student_id'] ?? 0);
            if ($requested > 0 && in_array($requested, $childIds, true)) {
                return $requested;
            }
            return $childIds[0] ?? null;
        }
        return null;
    }

    /**
     * "My Subjects & Classes" — Teacher/Principal only. Was previously shown as
     * two tables directly on the portal dashboard; moved to its own sidebar page
     * so the dashboard can stay a clean KPI overview.
     */
    public function mySubjectsAction(): void
    {
        require_once __DIR__ . '/../models/PortalModel.php';
        require_once __DIR__ . '/../models/StaffFeeClassModel.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        if (!in_array(RBAC::roleName(), ['teacher', 'principal'], true)) {
            redirect_route('portal/index');
            return;
        }

        $staffId = RBAC::currentStaffProfileId();
        if (!$staffId) {
            $this->render('dashboard/portal_unlinked', [
                'title' => 'My Subjects & Classes',
                'roleLabel' => ucfirst(RBAC::roleName()),
            ]);
            return;
        }

        $subjects = PortalModel::teacherSubjects($staffId);
        $classes = PortalModel::teacherClassStudentCounts(RBAC::currentTeacherClassSectionIds());
        $classTeacherSectionIds = RBAC::currentTeacherClassTeacherSectionIds();
        $feeClasses = StaffFeeClassModel::getClassesForStaff($staffId);

        $this->render('dashboard/portal_my_subjects', [
            'title' => 'My Subjects & Classes',
            'subjects' => $subjects,
            'classes' => $classes,
            'classTeacherSectionIds' => $classTeacherSectionIds,
            'feeClasses' => $feeClasses,
        ]);
    }

    /**
     * "Fee Collection Classes" — Teacher/Principal only, split out from My
     * Subjects & Classes so it can have its own sidebar link and Quick Access
     * card, matching what the dashboard advertises.
     */
    public function myFeeClassesAction(): void
    {
        require_once __DIR__ . '/../models/StaffFeeClassModel.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        if (!in_array(RBAC::roleName(), ['teacher', 'principal'], true)) {
            redirect_route('portal/index');
            return;
        }

        $staffId = RBAC::currentStaffProfileId();
        if (!$staffId) {
            $this->render('dashboard/portal_unlinked', [
                'title' => 'Fee Collection Classes',
                'roleLabel' => ucfirst(RBAC::roleName()),
            ]);
            return;
        }

        $this->render('dashboard/portal_my_fee_classes', [
            'title' => 'Fee Collection Classes',
            'feeClasses' => StaffFeeClassModel::getClassesForStaff($staffId),
        ]);
    }

    /** "My Performance Reports" — Teacher/Principal only, moved off the dashboard. */
    public function myPerformanceAction(): void
    {
        require_once __DIR__ . '/../models/PortalModel.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        if (!in_array(RBAC::roleName(), ['teacher', 'principal'], true)) {
            redirect_route('portal/index');
            return;
        }

        $staffId = RBAC::currentStaffProfileId();
        if (!$staffId) {
            $this->render('dashboard/portal_unlinked', [
                'title' => 'My Performance',
                'roleLabel' => ucfirst(RBAC::roleName()),
            ]);
            return;
        }

        $this->render('dashboard/portal_my_performance', [
            'title' => 'My Performance Reports',
            'performance' => PortalModel::teacherOwnPerformanceReports($staffId),
        ]);
    }

    /**
     * Combined "apply for leave" form + own leave history for Student and
     * Teacher/Principal roles. This is the GET page; submissions still post to
     * leaveApplyAction() above, unchanged.
     */
    public function myLeavesAction(): void
    {
        require_once __DIR__ . '/../models/PortalModel.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        $role = RBAC::roleName();

        if (in_array($role, ['teacher', 'principal'], true)) {
            $staffId = RBAC::currentStaffProfileId();
            if (!$staffId) {
                $this->render('dashboard/portal_unlinked', ['title' => 'My Leaves', 'roleLabel' => ucfirst($role)]);
                return;
            }
            $leaveRequests = PortalModel::teacherOwnLeaveRequests($staffId, 30);
        } elseif ($role === 'student') {
            $studentId = RBAC::currentStudentId();
            if (!$studentId) {
                $this->render('dashboard/portal_unlinked', ['title' => 'My Leaves', 'roleLabel' => 'Student']);
                return;
            }
            $leaveRequests = PortalModel::studentOwnLeaveRequests($studentId, 30);
        } else {
            redirect_route('portal/index');
            return;
        }

        $this->render('dashboard/portal_my_leaves', [
            'title' => 'My Leaves',
            'leaveRequests' => $leaveRequests,
            'isTeacher' => in_array($role, ['teacher', 'principal'], true),
        ]);
    }

    /** "My Results" — Student/Parent, moved off the dashboard. */
    public function myResultsAction(): void
    {
        require_once __DIR__ . '/../models/PortalModel.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        $studentId = $this->resolvePortalStudentId();
        if (!$studentId) {
            $this->render('dashboard/portal_unlinked', ['title' => 'My Results', 'roleLabel' => ucfirst(RBAC::roleName())]);
            return;
        }

        $this->render('dashboard/portal_my_results', [
            'title' => 'My Results',
            'results' => PortalModel::studentResults($studentId, 100),
            'pendingResultsCount' => PortalModel::studentPendingResultsCount($studentId),
        ]);
    }

    /** "My Report Card" — Student/Parent, official printable report card (same numbers as the admin certificate print). */
    public function myReportCardAction(): void
    {
        require_once __DIR__ . '/../models/PortalModel.php';
        require_once __DIR__ . '/../models/ExamModel.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        $studentId = $this->resolvePortalStudentId();
        if (!$studentId) {
            $this->render('dashboard/portal_unlinked', ['title' => 'My Report Card', 'roleLabel' => ucfirst(RBAC::roleName())]);
            return;
        }

        $profile = PortalModel::studentProfile($studentId);
        $exams = PortalModel::studentPublishedExams($studentId);

        $examId = (int)($_GET['exam_id'] ?? 0);
        $examIds = array_map(static fn($e) => (int)$e['id'], $exams);
        if ($examId <= 0 || !in_array($examId, $examIds, true)) {
            $examId = $examIds[0] ?? 0;
        }

        $card = $examId > 0
            ? ExamModel::studentReportCard($studentId, $examId)
            : null;

        $children = [];
        $selectedId = $studentId;
        if (RBAC::isParent()) {
            $children = PortalModel::guardianChildren((int)RBAC::currentGuardianId());
        }

        $this->render('dashboard/portal_report_card', [
            'title' => 'My Report Card',
            'student' => $profile,
            'exams' => $exams,
            'examId' => $examId,
            'card' => $card,
            'children' => $children,
            'selectedId' => $selectedId,
        ]);
    }

    /** "My Timetable" — Student/Parent, moved off the dashboard. */
    public function myTimetableAction(): void
    {
        require_once __DIR__ . '/../models/PortalModel.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        if (in_array(RBAC::roleName(), ['teacher', 'principal'], true)) {
            $staffId = RBAC::currentStaffProfileId();
            if (!$staffId) {
                $this->render('dashboard/portal_unlinked', ['title' => 'My Timetable', 'roleLabel' => ucfirst(RBAC::roleName())]);
                return;
            }

            $this->render('dashboard/portal_my_timetable', [
                'title' => 'My Timetable',
                'timetable' => PortalModel::teacherTimetable($staffId),
                'showClassColumn' => true,
            ]);
            return;
        }

        $studentId = $this->resolvePortalStudentId();
        if (!$studentId) {
            $this->render('dashboard/portal_unlinked', ['title' => 'My Timetable', 'roleLabel' => ucfirst(RBAC::roleName())]);
            return;
        }

        $profile = PortalModel::studentProfile($studentId);
        $classSectionId = $profile['current_class_section_id'] ?? null;

        $this->render('dashboard/portal_my_timetable', [
            'title' => 'My Timetable',
            'timetable' => $classSectionId ? PortalModel::studentTimetable((int)$classSectionId) : [],
            'showClassColumn' => false,
        ]);
    }

    /** "My Date Sheet" — Student/Parent, read-only. Needs the 'academic.date_sheet_view' permission. */
    public function myDateSheetAction(): void
    {
        try {
            $this->myDateSheetInner();
        } catch (Throwable $e) {
            // TEMPORARY diagnostic: show the real cause instead of the generic error page.
            error_log('[myDateSheet] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
            echo '<pre style="white-space:pre-wrap;padding:1rem;color:#b91c1c;background:#fff">DIAGNOSTIC: ' . htmlspecialchars(get_class($e) . ': ' . $e->getMessage() . ' @ ' . basename($e->getFile()) . ':' . $e->getLine(), ENT_QUOTES, 'UTF-8') . '</pre>';
        }
    }

    private function myDateSheetInner(): void
    {
        require_once __DIR__ . '/../models/PortalModel.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');
        $this->requirePermission('academic.date_sheet_view');

        $studentId = $this->resolvePortalStudentId();
        if (!$studentId) {
            $this->render('dashboard/portal_unlinked', ['title' => 'My Date Sheet', 'roleLabel' => ucfirst(RBAC::roleName())]);
            return;
        }

        $profile = PortalModel::studentProfile($studentId);
        $classSectionId = (int)($profile['current_class_section_id'] ?? 0);

        $sheets = [];
        $loadError = false;
        if ($classSectionId > 0) {
            try {
                $rows = Database::fetchAll(
                    'SELECT e.id AS exam_id, e.exam_name, ay.academic_year_label,
                            ess.scheduled_date, ess.start_time, ess.end_time, s.subject_name
                     FROM exams e
                     JOIN exam_subject_schedule ess ON ess.exam_id = e.id
                     JOIN subjects s ON s.id = ess.subject_id
                     LEFT JOIN academic_years ay ON ay.id = e.academic_year_id
                     WHERE e.class_section_id = ?
                       AND e.results_published = 0
                       AND (ess.scheduled_date IS NOT NULL OR ess.start_time IS NOT NULL)
                     ORDER BY e.id DESC, (ess.scheduled_date IS NULL), ess.scheduled_date, ess.start_time, s.subject_name',
                    'i',
                    [$classSectionId]
                );
                foreach ($rows as $r) {
                    $eid = (int)$r['exam_id'];
                    if (!isset($sheets[$eid])) {
                        $sheets[$eid] = [
                            'exam' => ['exam_name' => $r['exam_name'], 'academic_year_label' => $r['academic_year_label']],
                            'rows' => [],
                        ];
                    }
                    $sheets[$eid]['rows'][] = $r;
                }
            } catch (Throwable $e) {
                error_log('[myDateSheet] ' . $e->getMessage());
                $loadError = true;
            }
        }

        $this->render('dashboard/portal_my_date_sheet', [
            'title' => 'My Date Sheet',
            'student' => $profile,
            'sheets' => array_values($sheets),
            'loadError' => $loadError,
        ]);
    }

    /** "My Online Courses" — Student/Parent, moved off the dashboard. */
    public function myCoursesAction(): void
    {
        require_once __DIR__ . '/../models/PortalModel.php';

        Auth::requireLogin();
        $this->requirePermission('portal.access');

        $studentId = $this->resolvePortalStudentId();
        if (!$studentId) {
            $this->render('dashboard/portal_unlinked', ['title' => 'My Courses', 'roleLabel' => ucfirst(RBAC::roleName())]);
            return;
        }

        $this->render('dashboard/portal_my_courses', [
            'title' => 'My Online Courses',
            'courses' => PortalModel::studentCourses($studentId),
            'studentId' => $studentId,
            'isParentView' => RBAC::isParent(),
        ]);
    }

    // -----------------------------------------------------------------
    // Send SMS — direct message to one student/parent, one staff member,
    // or a whole class. See app/models/SmsDirectModel.php.
    // -----------------------------------------------------------------

    /**
     * Class-section IDs the logged-in user is allowed to message
     * students/parents in, or null for "no restriction" (Admin).
     * A teacher/principal may reach a class either because they teach a
     * subject there or because they're the assigned fee collector for it.
     */
    private function resolveSmsAllowedClassSectionIds(): ?array
    {
        if (RBAC::isAdmin()) {
            return null;
        }
        return array_values(array_unique(array_merge(
            RBAC::currentTeacherClassSectionIds(),
            RBAC::currentTeacherFeeClassSectionIds()
        )));
    }

    /** Masks a phone number for on-screen confirmation (e.g. "0314***5749") without hiding it entirely. */
    private function maskPhoneForDisplay(string $phone): string
    {
        $digits = preg_replace('/\s+/', '', $phone) ?? $phone;
        $len = strlen($digits);
        if ($len <= 6) {
            return $digits;
        }
        return substr($digits, 0, 4) . str_repeat('*', max(0, $len - 6)) . substr($digits, -2);
    }

    public function sendSmsAction(): void
    {
        require_once __DIR__ . '/../models/SmsDirectModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';

        Auth::requireLogin();
        $this->requirePermission('sms.direct_send');

        $allowed = $this->resolveSmsAllowedClassSectionIds();
        $error = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();

            $recipientType = (string)($_POST['recipient_type'] ?? '');
            $recipientId = (int)($_POST['recipient_id'] ?? 0);
            $selectedKeys = array_map('strval', (array)($_POST['contact_keys'] ?? []));
            $message = trim((string)($_POST['message'] ?? ''));

            if (!sms_gateway_enabled()) {
                $error = 'The SMS gateway is turned off — enable it under Settings &gt; Notifications first.';
            } elseif ($message === '') {
                $error = 'Write a message before sending.';
            } elseif (!in_array($recipientType, ['student', 'staff', 'class'], true) || $recipientId <= 0) {
                $error = 'Choose a recipient first.';
            } else {
                $senderStaffId = RBAC::currentStaffProfileId();
                $sentCount = 0;
                $recipientLabel = '';

                if ($recipientType === 'student') {
                    $data = SmsDirectModel::getStudentContacts($recipientId, $allowed);
                    if (!$data) {
                        $error = 'That student wasn\'t found, or is outside the classes you teach / collect fees for.';
                    } else {
                        $available = array_column($data['contacts'], null, 'key');
                        $toSend = array_intersect($selectedKeys, array_keys($available));
                        if (empty($toSend)) {
                            $error = 'Choose at least one number to send to.';
                        } else {
                            foreach ($toSend as $key) {
                                if (queue_sms($available[$key]['phone'], $message, 'direct', $senderStaffId)) {
                                    $sentCount++;
                                }
                            }
                            $recipientLabel = $data['name'];
                        }
                    }
                } elseif ($recipientType === 'staff') {
                    $data = SmsDirectModel::getStaffContact($recipientId);
                    if (!$data || empty($data['contacts'])) {
                        $error = 'That staff member wasn\'t found, or has no phone number on file.';
                    } else {
                        if (queue_sms($data['contacts'][0]['phone'], $message, 'direct', $senderStaffId)) {
                            $sentCount = 1;
                        }
                        $recipientLabel = $data['name'];
                    }
                } else { // class
                    $data = SmsDirectModel::getClassContacts($recipientId, $allowed);
                    if (!$data) {
                        $error = 'That class is outside the classes you teach / collect fees for.';
                    } elseif (empty($data['numbers'])) {
                        $error = 'No phone numbers on file for that class.';
                    } else {
                        foreach ($data['numbers'] as $number) {
                            if (queue_sms($number, $message, 'direct_class', $senderStaffId)) {
                                $sentCount++;
                            }
                        }
                        $recipientLabel = $data['class_label'];
                    }
                }

                if (!$error) {
                    log_activity('sms.direct_send', 'Sent direct SMS to ' . $sentCount . ' number(s) (' . $recipientType . ': ' . $recipientLabel . ')');
                    $_SESSION['flash'] = [
                        'type' => 'success',
                        'message' => 'SMS queued for ' . $sentCount . ' number(s) — ' . $recipientLabel,
                    ];
                    redirect_route('portal/sendSms');
                    return;
                }
            }
        }

        $this->render('dashboard/portal_send_sms', [
            'title' => 'Send SMS',
            'error' => $error,
            'isScoped' => $allowed !== null,
            'classOptions' => SmsDirectModel::allowedClassOptions($allowed),
            'gatewayEnabled' => sms_gateway_enabled(),
        ]);
    }

    /** AJAX: search-as-you-type for the Student / Staff pickers. JSON only. */
    public function smsSearchAction(): void
    {
        require_once __DIR__ . '/../models/SmsDirectModel.php';

        Auth::requireLogin();
        $this->requirePermission('sms.direct_send');

        $type = (string)($_GET['type'] ?? '');
        $q = (string)($_GET['q'] ?? '');
        $allowed = $this->resolveSmsAllowedClassSectionIds();

        if ($type === 'student') {
            $rows = SmsDirectModel::searchStudents($allowed, $q);
            $results = array_map(static function ($r) {
                $name = trim($r['first_name'] . ' ' . $r['last_name']);
                $classLabel = trim(($r['class_name'] ?? '') . ' ' . ($r['section_name'] ?? ''));
                // Father's name helps distinguish same-named students in the
                // dropdown (common with shared first names in one class).
                $metaParts = ['Adm: ' . $r['admission_no']];
                if (!empty($r['father_name'])) {
                    $metaParts[] = 'Father: ' . $r['father_name'];
                }
                if ($classLabel !== '') {
                    $metaParts[] = $classLabel;
                }
                return [
                    'id' => (int)$r['id'],
                    'label' => $name,
                    'meta' => implode(' — ', $metaParts),
                ];
            }, $rows);
        } elseif ($type === 'staff') {
            $rows = SmsDirectModel::searchStaff($q);
            $results = array_map(static function ($r) {
                return [
                    'id' => (int)$r['id'],
                    'label' => (string)$r['full_name'],
                    'meta' => trim((string)($r['title'] ?? '') . ($r['staff_code'] ? ' — ' . $r['staff_code'] : '')),
                ];
            }, $rows);
        } else {
            $results = [];
        }

        $this->jsonResponse(['results' => $results]);
    }

    /** AJAX: contact options for a chosen student/staff/class. JSON only. */
    public function smsContactAction(): void
{
    require_once __DIR__ . '/../models/SmsDirectModel.php';
    require_once __DIR__ . '/../models/ClassSectionModel.php';

        Auth::requireLogin();
        $this->requirePermission('sms.direct_send');

        $type = (string)($_GET['type'] ?? '');
        $id = (int)($_GET['id'] ?? 0);
        $allowed = $this->resolveSmsAllowedClassSectionIds();

        if ($id <= 0 || !in_array($type, ['student', 'staff', 'class'], true)) {
            $this->jsonResponse(['error' => 'Invalid request'], 400);
            return;
        }

        if ($type === 'student') {
            $data = SmsDirectModel::getStudentContacts($id, $allowed);
            if (!$data) {
                $this->jsonResponse(['error' => 'Student not found, or outside your allowed classes.'], 404);
                return;
            }
            $contacts = array_map(fn($c) => [
                'key' => $c['key'],
                'label' => $c['label'],
                'phone_masked' => $this->maskPhoneForDisplay($c['phone']),
            ], $data['contacts']);
        } elseif ($type === 'staff') {
            $data = SmsDirectModel::getStaffContact($id);
            if (!$data) {
                $this->jsonResponse(['error' => 'Staff member not found.'], 404);
                return;
            }
            $contacts = array_map(fn($c) => [
                'key' => $c['key'],
                'label' => $c['label'],
                'phone_masked' => $this->maskPhoneForDisplay($c['phone']),
            ], $data['contacts']);
        } else { // class
            $data = SmsDirectModel::getClassContacts($id, $allowed);
            if (!$data) {
                $this->jsonResponse(['error' => 'Class not found, or outside the classes you teach / collect fees for.'], 404);
                return;
            }
            $contacts = empty($data['numbers']) ? [] : [[
                'key' => 'class_all',
                'label' => 'All of ' . $data['class_label'] . ' — ' . $data['student_count'] . ' student(s), '
                    . $data['guardian_count'] . ' guardian(s)',
                'phone_masked' => count($data['numbers']) . ' number(s)',
            ]];
            $data['name'] = $data['class_label'];
            $data['admission_no'] = '';
            $data['father_name'] = '';
        }

        $this->jsonResponse([
            'name' => $data['name'],
            'father_name' => $data['father_name'] ?? '',
            'admission_no' => $data['admission_no'] ?? '',
            'class_label' => $data['class_label'] ?? '',
            'contacts' => $contacts,
        ]);
    }

    /**
     * List view over sms_outbox. Admin (sms.history_manage, implied by being
     * Admin — see migrate_sms_history.sql) sees every message the school has
     * ever sent. Anyone else with sms.history_view (Teacher/Principal) only
     * ever sees messages they personally sent — sender_staff_id must match
     * their own staff profile — never the whole outbox. That scoping is
     * enforced here in the query, not just hidden in the UI.
     */
    public function smsHistoryAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission('sms.history_view');

        $canManage = RBAC::hasPermission('sms.history_manage');
        $myStaffId = RBAC::currentStaffProfileId();

        $q = trim((string)($_GET['q'] ?? ''));
        $status = trim((string)($_GET['status'] ?? ''));

        $where = [];
        $types = '';
        $params = [];

        if (!$canManage) {
            // Non-admin viewers are hard-scoped to their own sent messages,
            // regardless of anything in the querystring.
            $where[] = 'o.sender_staff_id = ?';
            $types .= 'i';
            $params[] = (int)$myStaffId;
        }

        if ($q !== '') {
            $where[] = '(o.to_number LIKE ? OR o.message LIKE ?)';
            $types .= 'ss';
            $like = '%' . $q . '%';
            $params[] = $like;
            $params[] = $like;
        }

        if (in_array($status, ['pending', 'sending', 'sent', 'failed'], true)) {
            $where[] = 'o.status = ?';
            $types .= 's';
            $params[] = $status;
        }

        $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 30;
        $offset = ($page - 1) * $perPage;

        $totalRow = Database::fetchOne("SELECT COUNT(*) AS c FROM sms_outbox o $whereSql", $types, $params);
        $total = (int)($totalRow['c'] ?? 0);

        $rows = Database::fetchAll(
            "SELECT o.*, sp.full_name AS sender_name
             FROM sms_outbox o
             LEFT JOIN staff_profiles sp ON sp.id = o.sender_staff_id
             $whereSql
             ORDER BY o.id DESC
             LIMIT ? OFFSET ?",
            $types . 'ii',
            array_merge($params, [$perPage, $offset])
        );

        foreach ($rows as &$row) {
            $row['to_number_masked'] = $this->maskPhoneForDisplay((string)$row['to_number']);
        }
        unset($row);

        $this->render('dashboard/portal_sms_history', [
            'title' => 'SMS History',
            'rows' => $rows,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'filters' => ['q' => $q, 'status' => $status],
            'canManage' => $canManage,
        ]);
    }

    /** Deletes one sms_outbox row. Admin only — re-checked here even though the button is already hidden for everyone else. */
    public function smsHistoryDeleteAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission('sms.history_manage');
        $this->requireCsrf();

        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            $row = Database::fetchOne('SELECT to_number FROM sms_outbox WHERE id = ?', 'i', [$id]);
            Database::execute('DELETE FROM sms_outbox WHERE id = ?', 'i', [$id]);
            if ($row) {
                log_activity('sms.history_delete', 'Deleted an SMS history entry to ' . $this->maskPhoneForDisplay((string)$row['to_number']));
            }
        }

        redirect_route('portal/smsHistory');
    }
}