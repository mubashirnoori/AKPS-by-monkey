<?php

class UsersController extends Controller
{
    public function indexAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission('users.view');

        // The old tile-grid submenu page is gone — the sidebar's Users & Roles flyout now goes
        // straight to each sub-page, so this route just forwards to the most-used one.
        redirect_route('users/users');
    }

    /**
     * AJAX search endpoint backing the "Link to Record" combo boxes on the
     * user form. Replaces the old approach of preloading up to 500 students
     * / staff / guardians into the page and filtering them in JS — which
     * silently dropped anyone past the 500th row and never scaled. This
     * queries the database directly for the current keystroke and always
     * returns at most 10 matches, so it works the same whether the school
     * has 50 records or 50,000.
     */
    public function linkSearchAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['users.manage', 'users.accounts_manage']);

        header('Content-Type: application/json; charset=utf-8');

        $type = (string)($_GET['type'] ?? '');
        $q = trim((string)($_GET['q'] ?? ''));
        $editId = (int)($_GET['edit_id'] ?? 0);
        $like = '%' . $q . '%';
        $results = [];

        if ($type === 'student' || $type === 'parent') {
            $rows = Database::fetchAll(
                "SELECT s.id, s.admission_no, s.first_name, s.last_name, s.father_name,
                        GROUP_CONCAT(DISTINCT g.full_name SEPARATOR ', ') AS guardian_label
                 FROM students s
                 LEFT JOIN student_guardians sg ON sg.student_id = s.id
                 LEFT JOIN guardians g ON g.id = sg.guardian_id
                 WHERE (s.user_id IS NULL OR s.user_id = ?)
                   AND (? = '' OR s.first_name LIKE ? OR s.last_name LIKE ? OR s.admission_no LIKE ? OR s.father_name LIKE ?)
                 GROUP BY s.id, s.admission_no, s.first_name, s.last_name, s.father_name
                 ORDER BY s.first_name
                 LIMIT 10",
                'isssss',
                [$editId, $q, $like, $like, $like, $like]
            );
            foreach ($rows as $s) {
                $label = trim(($s['first_name'] ?? '') . ' ' . ($s['last_name'] ?? '')) . ' (' . ($s['admission_no'] ?? '') . ')';
                if ($type === 'parent') {
                    if (!empty($s['guardian_label'])) {
                        $sub = 'Current guardian: ' . $s['guardian_label'];
                    } elseif (!empty($s['father_name'])) {
                        $sub = "Will link via Father's Name: " . $s['father_name'];
                    } else {
                        $sub = "No guardian or Father's Name on file yet — add one on the student profile first";
                    }
                } else {
                    $sub = !empty($s['guardian_label']) ? 'Guardian: ' . $s['guardian_label'] : '';
                }
                $results[] = ['id' => (int)$s['id'], 'label' => $label, 'sub' => $sub];
            }
        } elseif ($type === 'staff') {
            $rows = Database::fetchAll(
                "SELECT id, staff_code, full_name FROM staff_profiles
                 WHERE (user_id IS NULL OR user_id = ?)
                   AND (? = '' OR full_name LIKE ? OR staff_code LIKE ?)
                 ORDER BY full_name
                 LIMIT 10",
                'isss',
                [$editId, $q, $like, $like]
            );
            foreach ($rows as $s) {
                $label = ($s['full_name'] ?? '') . (!empty($s['staff_code']) ? ' (' . $s['staff_code'] . ')' : '');
                $results[] = ['id' => (int)$s['id'], 'label' => $label, 'sub' => ''];
            }
        } elseif ($type === 'guardian') {
            $rows = Database::fetchAll(
                "SELECT g.id, g.full_name, g.phone,
                        GROUP_CONCAT(DISTINCT CONCAT(s.first_name, ' ', s.last_name, ' (', s.admission_no, ')') SEPARATOR ', ') AS children_label
                 FROM guardians g
                 LEFT JOIN student_guardians sg ON sg.guardian_id = g.id
                 LEFT JOIN students s ON s.id = sg.student_id
                 WHERE (g.user_id IS NULL OR g.user_id = ?)
                   AND (? = '' OR g.full_name LIKE ? OR g.phone LIKE ?)
                 GROUP BY g.id, g.full_name, g.phone
                 ORDER BY g.full_name
                 LIMIT 10",
                'isss',
                [$editId, $q, $like, $like]
            );
            foreach ($rows as $g) {
                $label = ($g['full_name'] ?? '') . (!empty($g['phone']) ? ' (' . $g['phone'] . ')' : '');
                $sub = !empty($g['children_label']) ? 'Parent of: ' . $g['children_label'] : '⚠ no child linked yet';
                $results[] = ['id' => (int)$g['id'], 'label' => $label, 'sub' => $sub];
            }
        }

        echo json_encode($results, JSON_UNESCAPED_UNICODE);
    }

    /** @return array{users: array, total: int} */
    private function fetchUsersListData(string $q, int $roleFilter, int $statusFilter, int $page, int $perPage): array
    {
        $offset = ($page - 1) * $perPage;

        $users = Database::fetchAll(
            'SELECT u.*,
                    r.name AS role_name,
                    sp.id AS staff_profile_id
             FROM users u
             JOIN roles r ON r.id = u.role_id
             LEFT JOIN staff_profiles sp ON sp.user_id = u.id
             WHERE (? = \'\' OR u.username LIKE ?)
               AND (? = 0 OR u.role_id = ?)
               AND (? = -1 OR u.status = ?)
             ORDER BY u.id DESC
             LIMIT ? OFFSET ?',
            'ssiiiiii',
            [$q, '%' . $q . '%', $roleFilter, $roleFilter, $statusFilter, $statusFilter, $perPage, $offset]
        );

        $totalRow = Database::fetchOne(
            'SELECT COUNT(*) AS cnt
             FROM users u
             WHERE (? = \'\' OR u.username LIKE ?)',
            'ss',
            [$q, '%' . $q . '%']
        );

        return ['users' => $users, 'total' => (int)($totalRow['cnt'] ?? 0)];
    }

    /** Re-run the list query for the given filters and render the list partial (used by bulk_assign/bulk_delete). */
    private function renderUsersListPartial(string $q, int $roleFilter, int $statusFilter, int $page, int $perPage): string
    {
        $data = $this->fetchUsersListData($q, $roleFilter, $statusFilter, $page, $perPage);
        $roles = Database::fetchAll('SELECT id, name FROM roles ORDER BY name');

        return $this->renderPartial('users/_user_list', [
            'users' => $data['users'],
            'total' => $data['total'],
            'q' => $q,
            'roleFilter' => $roleFilter,
            'statusFilter' => $statusFilter,
            'page' => $page,
            'perPage' => $perPage,
            'roles' => $roles,
        ]);
    }

    private function usersFiltersFromRequest(): array
    {
        $perPage = (int)($_POST['per_page'] ?? $_GET['per_page'] ?? 10);
        if (!in_array($perPage, [10, 25, 50, 100], true)) {
            $perPage = 10;
        }
        return [
            'q' => trim((string)($_POST['q'] ?? $_GET['q'] ?? '')),
            'role_id' => (int)($_POST['filter_role_id'] ?? $_GET['role_id'] ?? 0),
            'status' => (int)($_POST['filter_status'] ?? $_GET['status'] ?? -1),
            'page' => max(1, (int)($_POST['page'] ?? $_GET['page'] ?? 1)),
            'per_page' => $perPage,
        ];
    }

    private function redirectToUsersList(array $filters): void
    {
        $qs = 'route=' . rawurlencode('users/users');
        $extra = array_filter([
            'q' => $filters['q'],
            'role_id' => $filters['role_id'] ?: '',
            'status' => $filters['status'] !== -1 ? $filters['status'] : '',
            'page' => $filters['page'] > 1 ? $filters['page'] : '',
            'per_page' => (($filters['per_page'] ?? 10) !== 10) ? $filters['per_page'] : '',
        ], fn($v) => $v !== '');
        if ($extra) {
            $qs .= '&' . http_build_query($extra);
        }
        redirect('/index.php?' . $qs);
    }

    public function usersAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['users.manage', 'users.accounts_manage']);

        $roles = Database::fetchAll('SELECT id, name FROM roles ORDER BY name');
        $error = null;

        $editId = (int)($_GET['id'] ?? 0);
        $userToEdit = $editId > 0 ? Database::fetchOne(
            'SELECT * FROM users WHERE id = ?',
            'i',
            [$editId]
        ) : null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                $this->requireCsrf();

                $action = (string)($_POST['action'] ?? '');
                if ($action === 'bulk_assign') {
                    $listFilters = $this->usersFiltersFromRequest();
                    $ids = $_POST['user_ids'] ?? [];
                    $roleId = (int)($_POST['role_id'] ?? 0);
                    if ($roleId > 0 && is_array($ids)) {
                        foreach ($ids as $uid) {
                            $uid = (int)$uid;
                            if ($uid > 0) {
                                Database::execute(
                                    'UPDATE users SET role_id = ? WHERE id = ?',
                                    'ii',
                                    [$roleId, $uid]
                                );
                            }
                        }
                        $message = 'Users updated';
                        log_activity('users.bulk_assign_role', 'Bulk-assigned role #' . $roleId . ' to ' . count(array_filter(array_map('intval', $ids))) . ' user(s)');
                        if ($this->wantsJson()) {
                            $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderUsersListPartial($listFilters['q'], $listFilters['role_id'], $listFilters['status'], $listFilters['page'], $listFilters['per_page'])]);
                        }
                        $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
                    }
                    $this->redirectToUsersList($listFilters);
                    return;
                }

                if ($action === 'bulk_delete') {
                    $listFilters = $this->usersFiltersFromRequest();
                    $ids = $_POST['user_ids'] ?? [];
                    if (is_array($ids)) {
                        $count = 0;
                        foreach ($ids as $uid) {
                            $uid = (int)$uid;
                            if ($uid > 0) {
                                Database::execute('DELETE FROM users WHERE id = ?', 'i', [$uid]);
                                $count++;
                            }
                        }
                        $message = 'Deleted ' . $count . ' users';
                        if ($count > 0) {
                            log_activity('users.bulk_delete', 'Bulk-deleted ' . $count . ' user(s)');
                        }
                        if ($this->wantsJson()) {
                            $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderUsersListPartial($listFilters['q'], $listFilters['role_id'], $listFilters['status'], $listFilters['page'], $listFilters['per_page'])]);
                        }
                        $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
                    }
                    $this->redirectToUsersList($listFilters);
                    return;
                }

                // Create / update
                $id = (int)($_POST['id'] ?? 0);
                $username = trim((string)($_POST['username'] ?? ''));
                $email = trim((string)($_POST['email'] ?? ''));
                $roleId = (int)($_POST['role_id'] ?? 0);
                $status = (int)($_POST['status'] ?? 1);
                $password = (string)($_POST['password'] ?? '');
                $linkStudentId = (int)($_POST['link_student_id'] ?? 0);
                $linkStaffId = (int)($_POST['link_staff_id'] ?? 0);
                $linkParentStudentId = (int)($_POST['link_parent_student_id'] ?? 0);
                $linkGuardianOverrideId = (int)($_POST['link_guardian_id'] ?? 0);

                if ($username === '' || $roleId <= 0) {
                    $error = 'Username and role are required';
                } else {
                    if ($id > 0) {
                        if ($password !== '') {
                            $hash = password_hash($password, PASSWORD_BCRYPT);
                            Database::execute(
                                'UPDATE users
                                 SET username = ?, email = ?, role_id = ?, status = ?, password_hash = ?
                                 WHERE id = ?',
                                'ssiisi',
                                [$username, $email !== '' ? $email : null, $roleId, $status, $hash, $id]
                            );
                        } else {
                            Database::execute(
                                'UPDATE users
                                 SET username = ?, email = ?, role_id = ?, status = ?
                                 WHERE id = ?',
                                'ssiii',
                                [$username, $email !== '' ? $email : null, $roleId, $status, $id]
                            );
                        }
                        $_SESSION['flash'] = ['type' => 'success', 'message' => 'User updated'];
                        log_activity('users.update', 'Updated user account "' . $username . '"');
                    } else {
                        if ($password === '') {
                            $error = 'Password is required for new users';
                        } else {
                            $hash = password_hash($password, PASSWORD_BCRYPT);
                            Database::execute(
                                'INSERT INTO users (username, email, password_hash, role_id, status, created_at)
                                 VALUES (?, ?, ?, ?, ?, NOW())',
                                'sssii',
                                [$username, $email !== '' ? $email : null, $hash, $roleId, $status]
                            );
                            $id = (int)Database::lastInsertId();
                            $_SESSION['flash'] = ['type' => 'success', 'message' => 'User created'];
                            log_activity('users.create', 'Created user account "' . $username . '"');
                        }
                    }

                    if ($id > 0 && $error === null) {
                        require_once __DIR__ . '/../models/GuardianModel.php';
                        self::applyRecordLink('students', $id, $linkStudentId);
                        self::applyRecordLink('staff_profiles', $id, $linkStaffId);

                        $linkGuardianId = 0;
                        if ($linkGuardianOverrideId > 0) {
                            $linkGuardianId = $linkGuardianOverrideId;
                        } elseif ($linkParentStudentId > 0) {
                            $linkGuardianId = GuardianModel::resolvePrimaryOrCreateFromFather($linkParentStudentId);
                        }
                        self::applyRecordLink('guardians', $id, $linkGuardianId);
                    }

                    if ($error === null) {
                        redirect_route('users/users');
                        return;
                    }
                }
            } catch (Throwable $e) {
                $raw = $e->getMessage();
                if (stripos($raw, 'Duplicate entry') !== false && stripos($raw, 'username') !== false) {
                    $error = 'This username already exists. Please choose a different username.';
                } elseif (stripos($raw, 'Duplicate entry') !== false && stripos($raw, 'email') !== false) {
                    $error = 'This email is already used by another account.';
                } else {
                    $error = $raw;
                }
            }
        }

        $q = trim((string)($_GET['q'] ?? ''));
        $roleFilter = (int)($_GET['role_id'] ?? 0);
        $statusFilter = (int)($_GET['status'] ?? -1);
        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = (int)($_GET['per_page'] ?? 10);
        if (!in_array($perPage, [10, 25, 50, 100], true)) {
            $perPage = 10;
        }

        $listData = $this->fetchUsersListData($q, $roleFilter, $statusFilter, $page, $perPage);
        $users = $listData['users'];
        $total = $listData['total'];

        // Current links + selectable options for the "Link to record" dropdowns.
        // A record already linked to a *different* user is excluded so two logins
        // can never point at the same student/staff/guardian record.
        $linkedStudentId = 0;
        $linkedStaffId = 0;
        $linkedGuardianId = 0;
        if ($editId > 0) {
            $row = Database::fetchOne('SELECT id FROM students WHERE user_id = ?', 'i', [$editId]);
            $linkedStudentId = $row ? (int)$row['id'] : 0;
            $row = Database::fetchOne('SELECT id FROM staff_profiles WHERE user_id = ?', 'i', [$editId]);
            $linkedStaffId = $row ? (int)$row['id'] : 0;
            $row = Database::fetchOne('SELECT id FROM guardians WHERE user_id = ?', 'i', [$editId]);
            $linkedGuardianId = $row ? (int)$row['id'] : 0;
        }

        // The three combo boxes below used to be fed by preloading up to 500
        // students / staff / guardians into the page and filtering them in
        // JS. That silently excluded anyone past the 500th row and got
        // heavier with every student the school added. They now search the
        // database live via linkSearchAction() as the admin types, so all we
        // need here is the *currently linked* record's label (for edit mode).
        $linkedStudentLabel = '';
        if ($linkedStudentId > 0) {
            $row = Database::fetchOne('SELECT first_name, last_name, admission_no FROM students WHERE id = ?', 'i', [$linkedStudentId]);
            if ($row) {
                $linkedStudentLabel = trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? '')) . ' (' . ($row['admission_no'] ?? '') . ')';
            }
        }
        $linkedStaffLabel = '';
        if ($linkedStaffId > 0) {
            $row = Database::fetchOne('SELECT full_name, staff_code FROM staff_profiles WHERE id = ?', 'i', [$linkedStaffId]);
            if ($row) {
                $linkedStaffLabel = ($row['full_name'] ?? '') . (!empty($row['staff_code']) ? ' (' . $row['staff_code'] . ')' : '');
            }
        }
        $linkedGuardianLabel = '';
        if ($linkedGuardianId > 0) {
            $row = Database::fetchOne('SELECT full_name, phone FROM guardians WHERE id = ?', 'i', [$linkedGuardianId]);
            if ($row) {
                $linkedGuardianLabel = ($row['full_name'] ?? '') . (!empty($row['phone']) ? ' (' . $row['phone'] . ')' : '');
            }
        }

        // When editing a login already linked to a guardian, preselect that
        // guardian's student in the "search by student" picker so the admin
        // sees "linked to <student>'s parent" instead of a raw guardian id.
        $linkedParentStudentId = 0;
        $linkedParentStudentLabel = '';
        if ($linkedGuardianId > 0) {
            require_once __DIR__ . '/../models/GuardianModel.php';
            $primaryStudent = GuardianModel::primaryStudentForGuardian($linkedGuardianId);
            if ($primaryStudent) {
                $linkedParentStudentId = (int)$primaryStudent['id'];
                $linkedParentStudentLabel = trim(($primaryStudent['first_name'] ?? '') . ' ' . ($primaryStudent['last_name'] ?? ''))
                    . ' (' . ($primaryStudent['admission_no'] ?? '') . ')';
            }
        }

        $this->render('users/users', [
            'title' => 'User Management',
            'roles' => $roles,
            'editId' => $editId,
            'userToEdit' => $userToEdit,
            'error' => $error,
            'users' => $users,
            'q' => $q,
            'roleFilter' => $roleFilter,
            'statusFilter' => $statusFilter,
            'page' => $page,
            'perPage' => $perPage,
            'total' => $total,
            'linkedStudentId' => $linkedStudentId,
            'linkedStaffId' => $linkedStaffId,
            'linkedGuardianId' => $linkedParentStudentId > 0 ? 0 : $linkedGuardianId,
            'linkedParentStudentId' => $linkedParentStudentId,
            'linkedParentStudentLabel' => $linkedParentStudentLabel,
            'linkedStudentLabel' => $linkedStudentLabel,
            'linkedStaffLabel' => $linkedStaffLabel,
            'linkedGuardianLabel' => $linkedGuardianLabel,
        ]);
    }

    /**
     * Point $table.user_id at $userId (or clear it if $recordId is 0).
     * Also clears any *other* record in the table that previously pointed at this
     * user, so a login is only ever linked to one record at a time.
     */
    private static function applyRecordLink(string $table, int $userId, int $recordId): void
    {
        $allowed = ['students', 'staff_profiles', 'guardians'];
        if (!in_array($table, $allowed, true)) {
            return;
        }
        Database::execute("UPDATE {$table} SET user_id = NULL WHERE user_id = ?", 'i', [$userId]);
        if ($recordId > 0) {
            Database::execute("UPDATE {$table} SET user_id = ? WHERE id = ?", 'ii', [$userId, $recordId]);
        }
    }

    /**
     * One-click login generation for existing students/staff/guardians that don't
     * have one yet (e.g. records created before logins existed, or imported in bulk).
     * Shows the new username/password pairs once — they are hashed immediately after
     * and can't be retrieved again, so the admin must copy/share them from this screen.
     */
    public function bulkGenerateAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['users.manage', 'users.bulk_generate']);
        $this->requireCsrf();

        require_once __DIR__ . '/../services/UserAccountService.php';

        $created = [];

        if (!empty($_POST['include_students'])) {
            $roleId = UserAccountService::roleIdByName('Student');
            $rows = Database::fetchAll('SELECT id, admission_no, first_name, last_name FROM students WHERE user_id IS NULL');
            foreach ($rows as $r) {
                if (!$roleId) {
                    break;
                }
                $username = UserAccountService::uniqueUsername((string)($r['admission_no'] ?: ($r['first_name'] . ' ' . $r['last_name'])));
                $password = UserAccountService::randomPassword();
                UserAccountService::createAndLink('students', (int)$r['id'], $username, null, $password, $roleId);
                $created[] = [
                    'type' => 'Student',
                    'name' => trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? '')),
                    'username' => $username,
                    'password' => $password,
                ];
            }
        }

        if (!empty($_POST['include_staff'])) {
            $roleId = UserAccountService::roleIdByName('Teacher');
            $rows = Database::fetchAll('SELECT id, full_name FROM staff_profiles WHERE user_id IS NULL');
            foreach ($rows as $r) {
                if (!$roleId) {
                    break;
                }
                $username = UserAccountService::uniqueUsername((string)($r['full_name'] ?? 'staff'));
                $password = UserAccountService::randomPassword();
                UserAccountService::createAndLink('staff_profiles', (int)$r['id'], $username, null, $password, $roleId);
                $created[] = [
                    'type' => 'Staff',
                    'name' => $r['full_name'] ?? '',
                    'username' => $username,
                    'password' => $password,
                ];
            }
        }

        if (!empty($_POST['include_guardians'])) {
            $roleId = UserAccountService::roleIdByName('Parent');
            $rows = Database::fetchAll('SELECT id, full_name, phone FROM guardians WHERE user_id IS NULL');
            foreach ($rows as $r) {
                if (!$roleId) {
                    break;
                }
                $username = UserAccountService::uniqueUsername((string)($r['phone'] ?: $r['full_name']));
                $password = UserAccountService::randomPassword();
                UserAccountService::createAndLink('guardians', (int)$r['id'], $username, null, $password, $roleId);
                $created[] = [
                    'type' => 'Parent',
                    'name' => $r['full_name'] ?? '',
                    'username' => $username,
                    'password' => $password,
                ];
            }
        }

        $this->render('users/bulk_generate_result', [
            'title' => 'Generated Logins',
            'created' => $created,
        ]);
    }

    public function rolesAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['users.manage', 'users.permissions_update']);

        $roles = Database::fetchAll('SELECT * FROM roles ORDER BY name');
        $permissions = Database::fetchAll('SELECT * FROM permissions ORDER BY permission_key');

        $selectedRoleId = (int)($_GET['role_id'] ?? 0);
        if ($selectedRoleId <= 0 && !empty($roles)) {
            $selectedRoleId = (int)$roles[0]['id'];
        }

        $role = $selectedRoleId > 0 ? Database::fetchOne('SELECT * FROM roles WHERE id = ?', 'i', [$selectedRoleId]) : null;
        $currentPerms = $selectedRoleId > 0
            ? Database::fetchAll('SELECT permission_id FROM role_permissions WHERE role_id = ?', 'i', [$selectedRoleId])
            : [];

        $selectedPermIds = [];
        foreach ($currentPerms as $p) {
            $selectedPermIds[(int)$p['permission_id']] = true;
        }

        $error = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'create_role') {
                $name = trim((string)($_POST['name'] ?? ''));
                $description = trim((string)($_POST['description'] ?? ''));
                if ($name === '') {
                    $error = 'Role name required';
                } elseif (mb_strlen($name) > 50) {
                    // roles.name is varchar(50) — fail fast with a clear message
                    // instead of letting MySQL truncate/reject it further down.
                    $error = 'Role name is too long (max 50 characters).';
                } else {
                    try {
                        Database::execute(
                            'INSERT INTO roles (name, description) VALUES (?, ?)',
                            'ss',
                            [$name, $description !== '' ? $description : null]
                        );
                        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Role created'];
                        log_activity('users.role_create', 'Created role "' . $name . '"');
                        redirect_route('users/roles');
                        return;
                    } catch (Throwable $e) {
                        // roles.name has a UNIQUE key (case-insensitive collation), so
                        // creating "Admin" when "admin" already exists lands here.
                        if (stripos($e->getMessage(), 'Duplicate entry') !== false) {
                            $error = 'A role named "' . $name . '" already exists. Please choose a different name.';
                        } else {
                            // Never leak raw DB/driver detail to the browser.
                            error_log('[SMS] role_create failed: ' . $e->getMessage());
                            $error = 'Could not create the role. Please try again.';
                        }
                    }
                }
            }

            if ($action === 'save_permissions') {
                $roleId = (int)($_POST['role_id'] ?? 0);
                $permissionIds = $_POST['permission_ids'] ?? [];
                if ($roleId > 0) {
                    Database::execute('DELETE FROM role_permissions WHERE role_id = ?', 'i', [$roleId]);
                    if (is_array($permissionIds)) {
                        foreach ($permissionIds as $pid) {
                            $pid = (int)$pid;
                            if ($pid > 0) {
                                Database::execute(
                                    'INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)',
                                    'ii',
                                    [$roleId, $pid]
                                );
                            }
                        }
                    }
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Permissions updated'];
                    $roleRow = Database::fetchOne('SELECT name FROM roles WHERE id = ?', 'i', [$roleId]);
                    $grantedCount = is_array($permissionIds) ? count(array_filter(array_map('intval', $permissionIds))) : 0;
                    log_activity('users.permissions_update', 'Updated permissions for role "' . ($roleRow['name'] ?? ('#' . $roleId)) . '" (' . $grantedCount . ' permission(s) granted)');
                    redirect('/index.php?route=users/roles&role_id=' . $roleId);
                    return;
                }
            }
        }

        $this->render('users/roles', [
            'title' => 'Roles & Permissions',
            'roles' => $roles,
            'permissions' => $permissions,
            'role' => $role,
            'selectedRoleId' => $selectedRoleId,
            'selectedPermIds' => $selectedPermIds,
            'error' => $error,
        ]);
    }

    public function customFieldsAction(): void
    {
        require_once __DIR__ . '/../models/CustomFieldModel.php';

        Auth::requireLogin();
        $this->requirePermission(['users.manage', 'users.custom_fields']);

        $scope = (string)($_GET['scope'] ?? 'user');
        if (!in_array($scope, ['user', 'student', 'staff'], true)) {
            $scope = 'user';
        }

        $error = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'create') {
                $fieldKey = trim((string)($_POST['field_key'] ?? ''));
                $labelText = trim((string)($_POST['label_text'] ?? ''));
                $fieldType = trim((string)($_POST['field_type'] ?? 'text'));
                $optionsText = trim((string)($_POST['options_text'] ?? ''));
                $isRequired = (int)($_POST['is_required'] ?? 0);

                if ($fieldKey === '' || $labelText === '') {
                    $error = 'Field key and label are required';
                } else {
                    CustomFieldModel::create($scope, [
                        'field_key' => $fieldKey,
                        'label_text' => $labelText,
                        'field_type' => $fieldType,
                        'options_text' => $optionsText,
                        'is_required' => $isRequired,
                    ]);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Custom field created'];
                    log_activity('users.custom_field_create', 'Created custom field "' . $labelText . '" (' . $scope . ')');
                    redirect('/index.php?route=users/customFields&scope=' . $scope);
                    return;
                }
            }

            if ($action === 'delete') {
                $id = (int)($_POST['id'] ?? 0);
                if ($id > 0) {
                    CustomFieldModel::delete($id);
                    $message = 'Field deleted';
                    log_activity('users.custom_field_delete', 'Deleted custom field #' . $id . ' (' . $scope . ')');
                    if ($this->wantsJson()) {
                        $fields = CustomFieldModel::listByScope($scope);
                        $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderPartial('users/_custom_field_list', [
                            'fields' => $fields,
                            'scope' => $scope,
                        ])]);
                    }
                    $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
                }
                redirect('/index.php?route=users/customFields&scope=' . $scope);
                return;
            }
        }

        $fields = CustomFieldModel::listByScope($scope);
        $this->render('users/custom_fields', [
            'title' => 'Custom Fields',
            'scope' => $scope,
            'fields' => $fields,
            'error' => $error,
        ]);
    }

    public function attendanceAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission('users.view');

        $user = Auth::currentUser();
        $userId = (int)($user['id'] ?? 0);

        $start = trim((string)($_GET['start_date'] ?? date('Y-m-01')));
        $end = trim((string)($_GET['end_date'] ?? date('Y-m-t')));

        $student = Database::fetchOne('SELECT id FROM students WHERE user_id = ?', 'i', [$userId]);
        $staff = Database::fetchOne('SELECT id FROM staff_profiles WHERE user_id = ?', 'i', [$userId]);

        $mode = '';
        $rows = [];

        if ($student) {
            $mode = 'student';
            $rows = Database::fetchAll(
                'SELECT attendance_date, subject_id, status
                 FROM attendance_records
                 WHERE student_id = ?
                   AND subject_id IS NULL
                   AND attendance_date BETWEEN ? AND ?
                 ORDER BY attendance_date DESC',
                'iss',
                [$student['id'], $start, $end]
            );
        } elseif ($staff) {
            $mode = 'staff';
            $rows = Database::fetchAll(
                'SELECT attendance_date, status
                 FROM staff_attendance_records
                 WHERE staff_profile_id = ?
                   AND attendance_date BETWEEN ? AND ?
                 ORDER BY attendance_date DESC',
                'iss',
                [$staff['id'], $start, $end]
            );
        }

        $this->render('users/attendance', [
            'title' => 'My Attendance',
            'mode' => $mode,
            'rows' => $rows,
            'start_date' => $start,
            'end_date' => $end,
        ]);
    }
}