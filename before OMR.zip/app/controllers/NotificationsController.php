<?php

/**
 * Notification bell — every logged-in user (any role/portal) has their own
 * inbox here. No extra permission beyond being logged in: a notification
 * row only ever exists for the user_id it was created for, so there is
 * nothing to scope further.
 */
class NotificationsController extends Controller
{
    public function indexAction(): void
    {
        require_once __DIR__ . '/../models/NotificationModel.php';
        $user = Auth::requireLogin();
        $userId = (int)($user['id'] ?? 0);

        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = 20;
        $offset = ($page - 1) * $perPage;

        $notifications = NotificationModel::listForUser($userId, $perPage, $offset);

        $this->render('notifications/index', [
            'title' => 'Notifications',
            'notifications' => $notifications,
            'page' => $page,
            'perPage' => $perPage,
        ]);
    }

    /** JSON: unread count + latest few — polled by the bell icon in layout.php. */
    public function pollAction(): void
    {
        require_once __DIR__ . '/../models/NotificationModel.php';
        $user = Auth::requireLogin();
        $userId = (int)($user['id'] ?? 0);

        $this->jsonResponse([
            'unread' => NotificationModel::unreadCount($userId),
            'notifications' => NotificationModel::listForUser($userId, 8, 0),
        ]);
    }

    public function markReadAction(): void
    {
        require_once __DIR__ . '/../models/NotificationModel.php';
        $user = Auth::requireLogin();
        $this->requireCsrf();

        $id = (int)($_POST['id'] ?? 0);
        NotificationModel::markRead($id, (int)($user['id'] ?? 0));

        if ($this->wantsJson()) {
            $this->jsonResponse(['success' => true]);
            return;
        }
        redirect_route('notifications/index');
    }

    public function markAllReadAction(): void
    {
        require_once __DIR__ . '/../models/NotificationModel.php';
        $user = Auth::requireLogin();
        $this->requireCsrf();

        NotificationModel::markAllRead((int)($user['id'] ?? 0));

        if ($this->wantsJson()) {
            $this->jsonResponse(['success' => true]);
            return;
        }
        redirect_route('notifications/index');
    }

    /** Compose + send an announcement (bell notification + push to registered devices), and show recent history. */
    public function announcementsAction(): void
    {
        require_once __DIR__ . '/../models/NotificationModel.php';
        require_once __DIR__ . '/../models/AnnouncementModel.php';
        require_once __DIR__ . '/../models/DeviceTokenModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';
        require_once __DIR__ . '/../core/FcmClient.php';

        Auth::requireLogin();
        $this->requirePermission(['notifications.announce']);

        $error = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();

            $title = trim((string)($_POST['title'] ?? ''));
            $message = trim((string)($_POST['message'] ?? ''));
            $audience = (string)($_POST['audience'] ?? '');
            $classSectionId = (int)($_POST['class_section_id'] ?? 0) ?: null;

            if ($title === '' || $message === '') {
                $error = 'Title and message are required.';
            } elseif (!in_array($audience, AnnouncementModel::AUDIENCES, true)) {
                $error = 'Choose who this announcement is for.';
            } elseif ($audience === 'class' && !$classSectionId) {
                $error = 'Choose a class for a class-specific announcement.';
            }

            if (!$error) {
                $userIds = AnnouncementModel::resolveAudienceUserIds($audience, $classSectionId);
                $currentUser = Auth::currentUser();

                $announcementId = AnnouncementModel::create(
                    $title,
                    $message,
                    $audience,
                    $audience === 'class' ? $classSectionId : null,
                    count($userIds),
                    0,
                    (int)($currentUser['id'] ?? 0) ?: null
                );

                // Bell notification for every recipient — this always works, regardless
                // of whether push notifications are configured.
                foreach ($userIds as $uid) {
                    NotificationModel::create($uid, 'announcement', $title, $message, route_url('notifications/index'), $announcementId);
                }

                // Which channels to actually use — configured in Settings > Notifications.
                // Push defaults on; SMS/email are opt-in (SMS costs money per message on
                // the relay SIM, so it shouldn't fire just because SMTP happens to be on).
                $channels = announcement_channels();

                // Push, to every device registered by any of those users. Best-effort:
                // a device with no FCM configured, or a stale/uninstalled token, just
                // doesn't get counted — it never blocks the bell notification above.
                $pushSent = 0;
                if ($channels['push']) {
                    $tokens = DeviceTokenModel::tokensForUsers($userIds);
                    foreach ($tokens as $token) {
                        if (FcmClient::sendToToken($token, $title, $message)) {
                            $pushSent++;
                        }
                    }
                    if ($pushSent > 0) {
                        Database::execute('UPDATE announcements SET push_sent_count = ? WHERE id = ?', 'ii', [$pushSent, $announcementId]);
                    }
                }

                // SMS + email, to each recipient's registered mobile number / email — the
                // same delivery paths already used for OTPs, fee receipts, etc. Resolved
                // once in a single batched query rather than one lookup per recipient.
                $smsSent = 0;
                $emailSent = 0;
                if ($channels['sms'] || $channels['email']) {
                    require_once __DIR__ . '/../core/Mailer.php';
                    $contacts = resolve_contacts_for_users($userIds);

                    if ($channels['sms']) {
                        $smsBody = $title . ': ' . $message;
                        // Route through the sending staff member's own device (if
                        // they have one configured under Settings > SMS Gateway
                        // Devices) instead of always going out via the shared
                        // default number — falls back to the default device
                        // automatically at send time if this staff has none set up.
                        $senderStaffId = RBAC::currentStaffProfileId();
                        foreach ($contacts as $contact) {
                            if (!empty($contact['phone']) && queue_sms($contact['phone'], $smsBody, 'announcement', $senderStaffId)) {
                                $smsSent++;
                            }
                        }
                    }

                    if ($channels['email']) {
                        $emailHtml = '<p>' . nl2br(h($message)) . '</p>';
                        foreach ($contacts as $contact) {
                            $email = $contact['email'] ?? null;
                            if ($email && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                                if (Mailer::send($email, $contact['name'] ?: $email, $title, $emailHtml)) {
                                    $emailSent++;
                                }
                            }
                        }
                    }
                }

                if ($smsSent > 0 || $emailSent > 0) {
                    AnnouncementModel::recordChannelCounts($announcementId, $smsSent, $emailSent);
                }

                log_activity('notifications.announcement_sent', 'Sent announcement "' . $title . '" to ' . count($userIds) . ' recipient(s) (' . $audience . ')');

                $deliverySummary = [];
                if ($pushSent > 0) {
                    $deliverySummary[] = "push to $pushSent device(s)";
                }
                if ($channels['sms']) {
                    $deliverySummary[] = "SMS to $smsSent number(s)";
                }
                if ($channels['email']) {
                    $deliverySummary[] = "email to $emailSent address(es)";
                }

                $_SESSION['flash'] = [
                    'type' => 'success',
                    'message' => 'Announcement sent to ' . count($userIds) . ' recipient(s)'
                        . ($deliverySummary ? ' (' . implode(', ', $deliverySummary) . ')' : ''),
                ];
                redirect_route('notifications/announcements');
                return;
            }
        }

        $this->render('notifications/announcements', [
            'title' => 'Announcements',
            'error' => $error,
            'classSections' => ClassSectionModel::allOptions(),
            'recent' => AnnouncementModel::recent(),
        ]);
    }

    /**
     * Removes an announcement from the "Recently Sent" history only — it does not
     * (and cannot) recall the bell notifications, push, SMS, or email already sent.
     */
    public function announcementDeleteAction(): void
    {
        require_once __DIR__ . '/../models/AnnouncementModel.php';

        Auth::requireLogin();
        $this->requirePermission(['notifications.announce', 'notifications.announcement_delete']);
        $this->requireCsrf();

        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            $existing = AnnouncementModel::find($id);
            AnnouncementModel::delete($id);
            $message = 'Announcement removed from history';
            if ($existing) {
                log_activity('notifications.announcement_delete', 'Deleted announcement "' . $existing['title'] . '" from history');
            }
            if ($this->wantsJson()) {
                $audienceLabels = [
                    'everyone' => 'Everyone (staff + parents + students)',
                    'staff'    => 'Staff only',
                    'parents'  => 'Parents / guardians only',
                    'students' => 'Students only',
                    'class'    => 'A specific class',
                ];
                $this->jsonResponse([
                    'success' => true,
                    'message' => $message,
                    'html' => $this->renderPartial('notifications/_announcement_list', [
                        'recent' => AnnouncementModel::recent(),
                        'audienceLabels' => $audienceLabels,
                    ]),
                ]);
                return;
            }
            $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
        }
        redirect_route('notifications/announcements');
    }
}
