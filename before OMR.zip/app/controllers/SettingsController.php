<?php

class SettingsController extends Controller
{
    public function indexAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission('settings.view');

        // The old tile-grid submenu page is gone — the sidebar's Settings flyout now goes
        // straight to each sub-page. Every settings sub-page needs settings.manage though,
        // so a settings.view-only account (rare, but the permission exists) has nowhere to
        // land — show a short notice instead of a 403 loop.
        if (RBAC::hasPermission('settings.manage')) {
            redirect_route('settings/global');
            return;
        }

        $this->render('settings/index', [
            'title' => 'Settings',
        ]);
    }

    /** Keeps only valid Y-m-d dates from the holiday calendar, de-duplicated and sorted, as a CSV. */
    private function normalizeHolidayDates(string $csv): string
    {
        $dates = [];
        foreach (explode(',', $csv) as $d) {
            $d = trim($d);
            $dt = DateTime::createFromFormat('Y-m-d', $d);
            if ($dt && $dt->format('Y-m-d') === $d) {
                $dates[$d] = true;
            }
        }
        $dates = array_keys($dates);
        sort($dates);
        return implode(',', $dates);
    }

    public function globalAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['settings.manage', 'settings.global']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();

            $pairs = [
                'app_timezone' => trim((string)($_POST['app_timezone'] ?? 'UTC')),
                'currency' => trim((string)($_POST['currency'] ?? 'BDT')),
                'date_format' => trim((string)($_POST['date_format'] ?? 'Y-m-d')),
                'academic_year_active' => trim((string)($_POST['academic_year_active'] ?? '')),
                'holidays' => $this->normalizeHolidayDates((string)($_POST['holidays'] ?? '')),
            ];

            foreach ($pairs as $k => $v) {
                Database::execute(
                    'INSERT INTO settings (`key`, `value`, updated_at)
                     VALUES (?, ?, NOW())
                     ON DUPLICATE KEY UPDATE `value` = VALUES(`value`), updated_at = NOW()',
                    'ss',
                    [$k, $v]
                );
            }

            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Global settings saved'];
            redirect_route('settings/global');
            return;
        }

        $settings = Database::fetchAll('SELECT * FROM settings');
        $map = [];
        foreach ($settings as $s) {
            $map[(string)$s['key']] = (string)$s['value'];
        }

        $years = Database::fetchAll('SELECT id, academic_year_label, is_active FROM academic_years ORDER BY academic_year_label DESC');

        $this->render('settings/global', [
            'title' => 'Global Settings',
            'settings' => $map,
            'years' => $years,
        ]);
    }

    public function academicYearsAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['settings.manage', 'settings.academic_years']);

        $error = null;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $label = trim((string)($_POST['academic_year_label'] ?? ''));
            if ($label === '') {
                $error = 'Academic year label required';
            } else {
                Database::execute(
                    'INSERT INTO academic_years (academic_year_label, session_name, start_date, end_date, is_active)
                     VALUES (?, ?, ?, ?, ?)',
                    'ssssi',
                    [
                        $label,
                        trim((string)($_POST['session_name'] ?? '')) ?: null,
                        trim((string)($_POST['start_date'] ?? '')) ?: null,
                        trim((string)($_POST['end_date'] ?? '')) ?: null,
                        (int)($_POST['is_active'] ?? 0),
                    ]
                );
                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Academic year created'];
                redirect_route('settings/academicYears');
                return;
            }
        }

        if (isset($_POST['set_active_id'])) {
            $this->requireCsrf();
            $id = (int)$_POST['set_active_id'];
            Database::execute('UPDATE academic_years SET is_active = 0', '', []);
            Database::execute('UPDATE academic_years SET is_active = 1 WHERE id = ?', 'i', [$id]);
            $message = 'Active academic year updated';
            if ($this->wantsJson()) {
                $years = Database::fetchAll('SELECT * FROM academic_years ORDER BY academic_year_label DESC');
                $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderPartial('settings/_academic_year_list', ['years' => $years])]);
            }
            $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
            redirect_route('settings/academicYears');
            return;
        }

        $years = Database::fetchAll('SELECT * FROM academic_years ORDER BY academic_year_label DESC');
        $this->render('settings/academic_years', [
            'title' => 'Academic Years',
            'years' => $years,
            'error' => $error,
        ]);
    }

    public function instituteAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['settings.manage', 'settings.institute']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $pairs = [
                'institute_name' => trim((string)($_POST['institute_name'] ?? 'SchoolSMS Institute')),
                'institute_contact' => trim((string)($_POST['institute_contact'] ?? '')),
                'institute_address' => trim((string)($_POST['institute_address'] ?? '')),
                'institute_policies' => trim((string)($_POST['institute_policies'] ?? '')),
            ];
            foreach ($pairs as $k => $v) {
                Database::execute(
                    'INSERT INTO settings (`key`, `value`, updated_at)
                     VALUES (?, ?, NOW())
                     ON DUPLICATE KEY UPDATE `value` = VALUES(`value`), updated_at = NOW()',
                    'ss',
                    [$k, $v]
                );
            }
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Institute info saved'];
            redirect_route('settings/institute');
            return;
        }

        $settings = Database::fetchAll('SELECT * FROM settings');
        $map = [];
        foreach ($settings as $s) {
            $map[(string)$s['key']] = (string)$s['value'];
        }

        $this->render('settings/institute', [
            'title' => 'Institute Info',
            'settings' => $map,
        ]);
    }

    public function brandingAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['settings.manage', 'settings.branding']);

        $error = null;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();

            $schoolName = trim((string)($_POST['branding_school_name'] ?? ''));
            if ($schoolName === '') {
                $schoolName = 'SchoolSMS';
            }

            $pairs = [
                'branding_school_name' => $schoolName,
            ];

            $uploadDir = __DIR__ . '/../../public/uploads/branding';
            if (!is_dir($uploadDir) && !@mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
                $error = 'Unable to create branding upload folder.';
            } else {
                $uploadSpecs = [
                    'branding_logo' => [
                        'key' => 'branding_logo_path',
                        'prefix' => 'logo_',
                    ],
                    'branding_favicon' => [
                        'key' => 'branding_favicon_path',
                        'prefix' => 'favicon_',
                    ],
                ];

                // Extension is derived from the verified file content, never from the
                // uploader-supplied filename — same convention as staff/student photo
                // and course-video uploads elsewhere in this app. SVG is intentionally
                // NOT allowed here: it's an XML format that can embed <script>, and
                // mime_content_type() can't reliably distinguish a safe SVG from one
                // carrying a script payload the way it can for real binary image
                // formats, so allowing it would defeat the point of this check.
                $allowedMime = [
                    'image/png' => 'png',
                    'image/jpeg' => 'jpg',
                    'image/webp' => 'webp',
                    'image/vnd.microsoft.icon' => 'ico',
                    'image/x-icon' => 'ico',
                ];

                foreach ($uploadSpecs as $field => $spec) {
                    if (!isset($_FILES[$field]) || (int)($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
                        continue;
                    }

                    $fileErr = (int)($_FILES[$field]['error'] ?? UPLOAD_ERR_OK);
                    if ($fileErr !== UPLOAD_ERR_OK) {
                        $error = 'File upload failed for ' . $field . '.';
                        break;
                    }

                    $tmpName = (string)($_FILES[$field]['tmp_name'] ?? '');
                    $mimeType = @mime_content_type($tmpName) ?: '';
                    $ext = $allowedMime[$mimeType] ?? null;
                    if ($ext === null) {
                        $error = 'Invalid file type for ' . $field . '. Use PNG, JPG, WEBP, or ICO.';
                        break;
                    }

                    $fileName = $spec['prefix'] . date('YmdHis') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                    $destPath = $uploadDir . '/' . $fileName;
                    if (!move_uploaded_file($tmpName, $destPath)) {
                        $error = 'Unable to save uploaded file for ' . $field . '.';
                        break;
                    }
                    $pairs[$spec['key']] = '/uploads/branding/' . $fileName;
                }
            }

            if (!$error) {
                foreach ($pairs as $k => $v) {
                    Database::execute(
                        'INSERT INTO settings (`key`, `value`, updated_at)
                         VALUES (?, ?, NOW())
                         ON DUPLICATE KEY UPDATE `value` = VALUES(`value`), updated_at = NOW()',
                        'ss',
                        [$k, $v]
                    );
                }

                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Branding settings saved'];
                redirect_route('settings/branding');
                return;
            }
        }

        $settings = Database::fetchAll('SELECT * FROM settings');
        $map = [];
        foreach ($settings as $s) {
            $map[(string)$s['key']] = (string)$s['value'];
        }

        $this->render('settings/branding', [
            'title' => 'Branding',
            'settings' => $map,
            'error' => $error,
        ]);
    }

    public function notificationsAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['settings.manage', 'settings.notifications_update']);

        $error = null;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();

            $fromEmail = trim((string)($_POST['mail_from_email'] ?? ''));
            if ($fromEmail !== '' && !filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) {
                $error = 'Enter a valid "from" email address.';
            }

            $smtpEnabled = !empty($_POST['smtp_enabled']) ? '1' : '0';
            $smtpHost = trim((string)($_POST['smtp_host'] ?? ''));
            $smtpPort = trim((string)($_POST['smtp_port'] ?? ''));
            $smtpEncryption = trim((string)($_POST['smtp_encryption'] ?? 'tls'));
            if (!in_array($smtpEncryption, ['none', 'ssl', 'tls'], true)) {
                $smtpEncryption = 'tls';
            }
            $smtpAuth = !empty($_POST['smtp_auth']) ? '1' : '0';
            $smtpUsername = trim((string)($_POST['smtp_username'] ?? ''));
            $smtpVerifyCert = !empty($_POST['smtp_verify_cert']) ? '1' : '0';
            $smtpPasswordInput = (string)($_POST['smtp_password'] ?? '');
            $smtpPasswordClear = !empty($_POST['smtp_password_clear']);

            // Reject anything non-numeric outright for the SMS pacing fields
            // below, rather than silently coercing a typo to 0 — a bad value
            // should show up as a validation error, not quietly turn a safety
            // limit off. A field genuinely missing from the POST body (e.g. an
            // older cached copy of this form) falls back to $default instead
            // of failing the whole save — only a field that *was* submitted
            // but isn't a valid number blocks saving. Returns null (with
            // $error set) on invalid input.
            $parseNonNegativeInt = function (string $field, string $label, int $max, string $default) use (&$error): ?int {
                $raw = trim((string)($_POST[$field] ?? $default));
                if (!ctype_digit($raw)) {
                    $error = $error ?? ("Enter a whole number for \"$label\".");
                    return null;
                }
                $value = (int)$raw;
                if ($value > $max) {
                    $error = $error ?? ("\"$label\" can't be more than $max.");
                    return null;
                }
                return $value;
            };

            // Minimum gap (seconds) the gateway enforces between SMS dispatches
            // to the same device — see api/sms_gateway.php. '0' explicitly
            // disables pacing; anything else is floored at 2 so a mistyped "1"
            // doesn't quietly defeat the point.
            $smsIntervalSeconds = $parseNonNegativeInt('sms_send_interval_seconds', 'Delay Between Sends', 3600, '60');
            if ($smsIntervalSeconds !== null && $smsIntervalSeconds > 0 && $smsIntervalSeconds < 2) {
                $smsIntervalSeconds = 2;
            }

            // Rolling-window hard caps on top of the interval — see
            // api/sms_gateway.php for why the interval alone can't guarantee
            // these. '0' disables a given window's cap. Ceilings below are
            // generous headroom over the defaults (Zong's own stated
            // thresholds), just there to catch a fat-fingered entry.
            $smsCap15Min = $parseNonNegativeInt('sms_limit_per_15min', '15-Minute SMS Cap', 100000, '150');
            $smsCapHour = $parseNonNegativeInt('sms_limit_per_hour', 'Hourly SMS Cap', 100000, '250');
            $smsCapDay = $parseNonNegativeInt('sms_limit_per_day', 'Daily SMS Cap', 100000, '750');

            if (!$error && $smtpEnabled === '1') {
                if ($smtpHost === '') {
                    $error = 'SMTP host is required when SMTP sending is enabled.';
                } elseif ($smtpPort === '' || !ctype_digit($smtpPort) || (int)$smtpPort < 1 || (int)$smtpPort > 65535) {
                    $error = 'Enter a valid SMTP port (1-65535).';
                } elseif ($smtpAuth === '1' && $smtpUsername === '') {
                    $error = 'SMTP username is required when authentication is enabled.';
                }
            }

            if (!$error) {
                $pairs = [
                    'mail_from_email' => $fromEmail,
                    'mail_from_name' => trim((string)($_POST['mail_from_name'] ?? '')),
                    'announce_channel_push' => !empty($_POST['announce_channel_push']) ? '1' : '0',
                    'announce_channel_sms' => !empty($_POST['announce_channel_sms']) ? '1' : '0',
                    'announce_channel_email' => !empty($_POST['announce_channel_email']) ? '1' : '0',
                    'sms_enabled' => !empty($_POST['sms_enabled']) ? '1' : '0',
                    'sms_provider' => trim((string)($_POST['sms_provider'] ?? '')),
                    'sms_api_endpoint' => trim((string)($_POST['sms_api_endpoint'] ?? '')),
                    'sms_api_key' => trim((string)($_POST['sms_api_key'] ?? '')),
                    'sms_api_secret' => trim((string)($_POST['sms_api_secret'] ?? '')),
                    'sms_sender_id' => trim((string)($_POST['sms_sender_id'] ?? '')),
                    'sms_send_interval_seconds' => (string)$smsIntervalSeconds,
                    'sms_limit_per_15min' => (string)$smsCap15Min,
                    'sms_limit_per_hour' => (string)$smsCapHour,
                    'sms_limit_per_day' => (string)$smsCapDay,
                    'smtp_enabled' => $smtpEnabled,
                    'smtp_host' => $smtpHost,
                    'smtp_port' => $smtpPort,
                    'smtp_encryption' => $smtpEncryption,
                    'smtp_auth' => $smtpAuth,
                    'smtp_username' => $smtpUsername,
                    'smtp_verify_cert' => $smtpVerifyCert,
                ];

                // The password field is intentionally left blank when the page
                // is displayed, so we only ever touch the stored password when
                // the admin actually typed a new one or asked to clear it.
                if ($smtpPasswordClear) {
                    $pairs['smtp_password'] = '';
                } elseif ($smtpPasswordInput !== '') {
                    $pairs['smtp_password'] = $smtpPasswordInput;
                }

                foreach ($pairs as $k => $v) {
                    Database::execute(
                        'INSERT INTO settings (`key`, `value`, updated_at)
                         VALUES (?, ?, NOW())
                         ON DUPLICATE KEY UPDATE `value` = VALUES(`value`), updated_at = NOW()',
                        'ss',
                        [$k, $v]
                    );
                }

                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Notification settings saved'];
                log_activity('settings.notifications_update', 'Updated mail/SMS notification settings');
                redirect_route('settings/notifications');
                return;
            }
        }

        $settings = Database::fetchAll('SELECT * FROM settings');
        $map = [];
        foreach ($settings as $s) {
            $map[(string)$s['key']] = (string)$s['value'];
        }

        // Never send the stored password back down to the browser — only a
        // flag saying whether one is on file. The view uses this to show a
        // "leave blank to keep current password" placeholder instead.
        $hasSmtpPassword = !empty($map['smtp_password']);
        unset($map['smtp_password']);

        $this->render('settings/notifications', [
            'title' => 'Notifications',
            'settings' => $map,
            'hasSmtpPassword' => $hasSmtpPassword,
            'error' => $error,
        ]);
    }

    /**
     * List + add/edit/remove the per-device SMS relays (Admin's own, plus one
     * per staff member who should send under their own number). See
     * db/migrate_sms_gateway_devices.sql and api/sms_gateway.php.
     */
    public function smsDevicesAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['settings.manage', 'settings.sms_gateway_devices']);

        $error = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $formAction = (string)($_POST['form_action'] ?? '');

            if ($formAction === 'save') {
                $deviceId = (int)($_POST['device_id'] ?? 0);
                $label = trim((string)($_POST['label'] ?? ''));
                $staffId = (int)($_POST['staff_profile_id'] ?? 0);
                $phone = trim((string)($_POST['phone_number'] ?? ''));
                $isDefault = !empty($_POST['is_default']);
                $status = (($_POST['status'] ?? 'active') === 'inactive') ? 'inactive' : 'active';

                if ($label === '') {
                    $error = 'Give this device a label (e.g. a staff name or "Admin Office").';
                } else {
                    // Guard against ending up with zero default devices — e.g.
                    // unchecking "default" on the device that currently holds it,
                    // without marking a different one first. Checked *before*
                    // writing anything, since there's no transaction wrapper here
                    // to undo a bad write after the fact.
                    $currentDefault = Database::fetchOne('SELECT id FROM sms_gateway_devices WHERE is_default = 1 LIMIT 1');
                    $currentDefaultId = $currentDefault ? (int)$currentDefault['id'] : 0;
                    $anyDeviceExists = (bool)Database::fetchOne('SELECT id FROM sms_gateway_devices LIMIT 1');
                    if (!$isDefault && $deviceId > 0 && $deviceId === $currentDefaultId) {
                        $error = 'This is currently the default device — mark a different device as default first, or leave this one checked.';
                    } elseif (!$isDefault && !$anyDeviceExists) {
                        $error = 'This is the first device — it must be the default (there needs to be somewhere for OTPs and other system messages to go).';
                    } else {
                        if ($isDefault) {
                            // Exactly one default device — demote whichever one currently
                            // holds it before promoting this one.
                            Database::execute('UPDATE sms_gateway_devices SET is_default = 0');
                        }

                        if ($deviceId > 0) {
                            Database::execute(
                                'UPDATE sms_gateway_devices
                                 SET label = ?, staff_profile_id = ?, phone_number = ?, is_default = ?, status = ?, updated_at = NOW()
                                 WHERE id = ?',
                                'sisisi',
                                [$label, $staffId ?: null, $phone, $isDefault ? 1 : 0, $status, $deviceId]
                            );
                            log_activity('settings.sms_gateway_device_update', 'Updated SMS gateway device "' . $label . '"');
                        } else {
                            $newToken = bin2hex(random_bytes(24));
                            Database::execute(
                                'INSERT INTO sms_gateway_devices (label, staff_profile_id, phone_number, token, is_default, status, created_at, updated_at)
                                 VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())',
                                'sisssi',
                                [$label, $staffId ?: null, $phone, $newToken, $isDefault ? 1 : 0, $status]
                            );
                            log_activity('settings.sms_gateway_device_create', 'Added SMS gateway device "' . $label . '"');
                        }

                        $_SESSION['flash'] = ['type' => 'success', 'message' => 'SMS gateway device saved'];
                        redirect_route('settings/smsDevices');
                        return;
                    }
                }
            } elseif ($formAction === 'delete') {
                $deviceId = (int)($_POST['device_id'] ?? 0);
                $row = Database::fetchOne('SELECT label, is_default FROM sms_gateway_devices WHERE id = ?', 'i', [$deviceId]);
                if ($row && (int)$row['is_default'] === 1) {
                    $error = 'Can\'t delete the default device — mark a different one as default first.';
                } elseif ($row) {
                    Database::execute('DELETE FROM sms_gateway_devices WHERE id = ?', 'i', [$deviceId]);
                    log_activity('settings.sms_gateway_device_delete', 'Removed SMS gateway device "' . $row['label'] . '"');
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Device removed'];
                    redirect_route('settings/smsDevices');
                    return;
                }
            } elseif ($formAction === 'regenerate_token') {
                $deviceId = (int)($_POST['device_id'] ?? 0);
                $row = Database::fetchOne('SELECT label FROM sms_gateway_devices WHERE id = ?', 'i', [$deviceId]);
                if ($row) {
                    $newToken = bin2hex(random_bytes(24));
                    Database::execute('UPDATE sms_gateway_devices SET token = ?, updated_at = NOW() WHERE id = ?', 'si', [$newToken, $deviceId]);
                    log_activity('settings.sms_gateway_device_regenerate_token', 'Regenerated token for SMS gateway device "' . $row['label'] . '"');
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Token regenerated — update it on that device\'s app, or it will start getting rejected.'];
                    redirect_route('settings/smsDevices');
                    return;
                }
            }
        }

        $devices = Database::fetchAll(
            "SELECT d.id, d.label, d.staff_profile_id, d.phone_number, d.token, d.is_default, d.status, d.last_seen_at,
                    sp.full_name AS staff_name, sp.staff_code
             FROM sms_gateway_devices d
             LEFT JOIN staff_profiles sp ON sp.id = d.staff_profile_id
             ORDER BY d.is_default DESC, d.label"
        );

        $this->render('settings/sms_devices', [
            'title' => 'SMS Gateway Devices',
            'devices' => $devices,
            'error' => $error,
            'endpointUrl' => rtrim(base_url(), '/') . '/api/sms_gateway.php',
        ]);
    }

    /**
     * AJAX search backing the device form's "assign to staff" combo box.
     * Same live-search-instead-of-preloading approach as
     * UsersController::linkSearchAction() — see that method's comment for why.
     */
    public function smsDeviceStaffSearchAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['settings.manage', 'settings.sms_gateway_devices']);

        header('Content-Type: application/json; charset=utf-8');

        $q = trim((string)($_GET['q'] ?? ''));
        $like = '%' . $q . '%';

        $rows = Database::fetchAll(
            "SELECT sp.id, sp.full_name, sp.staff_code,
                    (SELECT d.label FROM sms_gateway_devices d WHERE d.staff_profile_id = sp.id LIMIT 1) AS existing_device_label
             FROM staff_profiles sp
             WHERE (? = '' OR sp.full_name LIKE ? OR sp.staff_code LIKE ?)
             ORDER BY sp.full_name
             LIMIT 10",
            'sss',
            [$q, $like, $like]
        );

        $results = [];
        foreach ($rows as $s) {
            $label = ($s['full_name'] ?? '') . (!empty($s['staff_code']) ? ' (' . $s['staff_code'] . ')' : '');
            $sub = !empty($s['existing_device_label']) ? '⚠ already assigned to device: ' . $s['existing_device_label'] : '';
            $results[] = ['id' => (int)$s['id'], 'label' => $label, 'sub' => $sub];
        }

        echo json_encode($results, JSON_UNESCAPED_UNICODE);
    }

    public function smtpTestAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['settings.manage', 'settings.smtp_test']);

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect_route('settings/notifications');
            return;
        }

        $this->requireCsrf();

        $testEmail = trim((string)($_POST['test_email'] ?? ''));
        $success = false;
        $message = '';

        if ($testEmail === '' || !filter_var($testEmail, FILTER_VALIDATE_EMAIL)) {
            $message = 'Enter a valid email address to send the test to.';
        } else {
            $sent = Mailer::send(
                $testEmail,
                $testEmail,
                'Test email from your School Management System',
                '<p>This is a test email confirming your outgoing mail settings are working.</p>'
                . '<p style="color:#888;font-size:12px;">Sent ' . h(date('Y-m-d H:i:s')) . '</p>'
            );
            if ($sent) {
                $success = true;
                $message = 'Test email sent to ' . $testEmail . '. Check the inbox (and spam folder).';
            } else {
                $message = 'Failed to send test email. ' . (Mailer::$lastError ?: 'Check your SMTP settings and try again.');
            }
        }

        log_activity(
            'settings.smtp_test',
            ($success ? 'Sent' : 'Failed to send') . ' a test email to ' . ($testEmail !== '' ? $testEmail : '(none)')
        );

        if ($this->wantsJson()) {
            $this->jsonResponse(['success' => $success, 'message' => $message]);
            return;
        }

        $_SESSION['flash'] = ['type' => $success ? 'success' : 'danger', 'message' => $message];
        redirect_route('settings/notifications');
    }

    public function smsTestAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['settings.manage', 'settings.sms_test']);

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            redirect_route('settings/notifications');
            return;
        }

        $this->requireCsrf();

        $testNumber = trim((string)($_POST['test_number'] ?? ''));
        $success = false;
        $message = '';

        if (!sms_gateway_enabled()) {
            $message = 'Enable "Send SMS sending" and save first.';
        } elseif (normalize_pk_mobile($testNumber) === null) {
            $message = 'Enter a valid mobile number, e.g. 03145525749.';
        } else {
            $queued = queue_sms($testNumber, 'Test message from your School Management System — SMS gateway is working. Sent ' . date('Y-m-d H:i:s'), 'test');
            if ($queued) {
                $success = true;
                $message = 'Queued. It will send next time your relay phone polls (usually within a few seconds).';
            } else {
                $message = 'Could not queue the test message. Check the settings above.';
            }
        }

        log_activity(
            'settings.sms_test',
            ($success ? 'Queued' : 'Failed to queue') . ' a test SMS to ' . ($testNumber !== '' ? $testNumber : '(none)')
        );

        if ($this->wantsJson()) {
            $this->jsonResponse(['success' => $success, 'message' => $message]);
            return;
        }

        $_SESSION['flash'] = ['type' => $success ? 'success' : 'danger', 'message' => $message];
        redirect_route('settings/notifications');
    }

    public function labelsAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['settings.manage', 'settings.labels']);

        $module = trim((string)($_GET['module'] ?? ($_POST['module'] ?? 'students')));
        if ($module === '') $module = 'students';

        $error = null;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $fieldKey = trim((string)($_POST['field_key'] ?? ''));
            $labelText = trim((string)($_POST['label_text'] ?? ''));
            if ($fieldKey === '' || $labelText === '') {
                $error = 'Field key and label required';
            } else {
                Database::execute(
                    'INSERT INTO label_overrides (module_name, field_key, label_text)
                     VALUES (?, ?, ?)
                     ON DUPLICATE KEY UPDATE label_text = VALUES(label_text)',
                    'sss',
                    [$module, $fieldKey, $labelText]
                );
                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Label saved'];
                redirect('/index.php?route=settings/labels&module=' . rawurlencode($module));
                return;
            }
        }

        if (isset($_POST['delete_id'])) {
            $this->requireCsrf();
            $id = (int)$_POST['delete_id'];
            Database::execute('DELETE FROM label_overrides WHERE id = ?', 'i', [$id]);
            $message = 'Label deleted';
            if ($this->wantsJson()) {
                $rows = Database::fetchAll(
                    'SELECT * FROM label_overrides WHERE module_name = ? ORDER BY id DESC',
                    's',
                    [$module]
                );
                $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderPartial('settings/_label_list', [
                    'rows' => $rows,
                    'module' => $module,
                    'routeBase' => base_url('/index.php?route=settings/labels'),
                ])]);
            }
            $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
            redirect('/index.php?route=settings/labels&module=' . rawurlencode($module));
            return;
        }

        $rows = Database::fetchAll(
            'SELECT * FROM label_overrides WHERE module_name = ? ORDER BY id DESC',
            's',
            [$module]
        );

        $this->render('settings/labels', [
            'title' => 'Label Management',
            'module' => $module,
            'rows' => $rows,
            'error' => $error,
        ]);
    }

    public function cleanDataAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['settings.manage', 'settings.clean_data']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $module = (string)($_POST['module'] ?? '');
            $confirmText = trim((string)($_POST['confirm_text'] ?? ''));

            if ($confirmText !== 'DELETE') {
                $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Type DELETE to confirm — nothing was deleted.'];
                redirect_route('settings/cleanData');
                return;
            }

            if ($module === 'attendance') {
                Database::execute('DELETE FROM attendance_records', '', []);
                Database::execute('DELETE FROM staff_attendance_records', '', []);
            } elseif ($module === 'marks') {
                Database::execute('DELETE FROM marks', '', []);
            } elseif ($module === 'fees') {
                Database::execute('DELETE FROM fee_collections', '', []);
                Database::execute('DELETE FROM fee_invoice_lines', '', []);
                Database::execute('DELETE FROM fee_invoices', '', []);
            } elseif ($module === 'complaints') {
                Database::execute('DELETE FROM complaints', '', []);
            } elseif ($module === 'inquiries') {
                Database::execute('DELETE FROM inquiries', '', []);
            }

            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Data cleaned for: ' . $module];
            log_activity('settings.clean_data', 'Cleaned data for module: ' . $module);
            redirect_route('settings/cleanData');
            return;
        }

        $this->render('settings/clean_data', [
            'title' => 'Clean Data',
        ]);
    }

    /**
     * Split a .sql dump into individual statements. Unlike a plain
     * `preg_split('/;\s*\n/')`, this tracks whether we're inside a quoted
     * string literal so a semicolon-then-newline that's part of a data value
     * (e.g. a multi-line remark field ending in "...;\n") doesn't get treated
     * as a statement boundary and split a valid INSERT in half.
     */
    private function splitSqlStatements(string $sql): array
    {
        $statements = [];
        $current = '';
        $len = strlen($sql);
        $inString = null; // null, or the quote char (' " `) currently open
        for ($i = 0; $i < $len; $i++) {
            $ch = $sql[$i];
            $current .= $ch;

            if ($inString !== null) {
                if ($ch === '\\' && $inString !== '`') {
                    // Escaped character inside a string — consume the next byte too so
                    // an escaped quote (\') doesn't end the string early.
                    if ($i + 1 < $len) {
                        $current .= $sql[$i + 1];
                        $i++;
                    }
                    continue;
                }
                if ($ch === $inString) {
                    $inString = null;
                }
                continue;
            }

            if ($ch === "'" || $ch === '"' || $ch === '`') {
                $inString = $ch;
                continue;
            }

            if ($ch === ';') {
                $trimmed = trim($current);
                if ($trimmed !== '' && strpos($trimmed, '--') !== 0) {
                    $statements[] = $trimmed;
                }
                $current = '';
            }
        }
        $trimmed = trim($current);
        if ($trimmed !== '' && strpos($trimmed, '--') !== 0) {
            $statements[] = $trimmed;
        }
        return $statements;
    }

    public function backupAction(): void
    {
        Auth::requireLoginOrToken();
        $this->requirePermission(['settings.manage', 'settings.backup_restore']);

        if (($_GET['download'] ?? '') === 'sql') {
            $this->requirePermission(['settings.manage', 'settings.backup_restore']);
            log_activity('settings.backup_download', 'Downloaded a full database backup (.sql)');
            header('Content-Type: text/plain; charset=UTF-8');
            header('Content-Disposition: attachment; filename="school_sms_backup.sql"');

            $mysqli = Database::connection();
            $tablesRes = $mysqli->query('SHOW TABLES');
            $tables = [];
            while ($row = $tablesRes->fetch_array()) {
                $tables[] = $row[0];
            }

            echo "-- SchoolSMS backup\n";
            echo "-- Generated: " . date('c') . "\n\n";
            echo "SET NAMES utf8mb4;\n";
            echo "SET FOREIGN_KEY_CHECKS=0;\n\n";

            foreach ($tables as $t) {
                $createRes = $mysqli->query('SHOW CREATE TABLE `' . $t . '`');
                $createRow = $createRes->fetch_assoc();
                $createSql = $createRow['Create Table'] ?? '';
                echo "DROP TABLE IF EXISTS `" . $t . "`;\n";
                echo $createSql . ";\n\n";

                $dataRes = $mysqli->query('SELECT * FROM `' . $t . '`');
                while ($data = $dataRes->fetch_assoc()) {
                    $cols = array_keys($data);
                    $vals = [];
                    foreach ($cols as $c) {
                        $v = $data[$c];
                        $vals[] = $v === null ? 'NULL' : ("'" . $mysqli->real_escape_string((string)$v) . "'");
                    }
                    echo "INSERT INTO `" . $t . "` (`" . implode('`,`', $cols) . "`) VALUES (" . implode(',', $vals) . ");\n";
                }
                echo "\n";
            }

            echo "SET FOREIGN_KEY_CHECKS=1;\n";
            exit;
        }

        // Restore
        $error = null;
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            if (empty($_FILES['sql_file']['tmp_name'])) {
                $error = 'Select a .sql file.';
            } else {
                $sql = file_get_contents($_FILES['sql_file']['tmp_name']);
                if (!$sql) {
                    $error = 'Unable to read SQL file.';
                } else {
                    $mysqli = Database::connection();
                    $mysqli->begin_transaction();
                    try {
                        $parts = $this->splitSqlStatements($sql);
                        foreach ($parts as $stmt) {
                            if ($stmt === '' || strpos($stmt, '--') === 0) continue;
                            $mysqli->query($stmt);
                        }
                        $mysqli->commit();
                        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Database restored'];
                        log_activity('settings.restore', 'Restored the database from an uploaded .sql backup file');
                        redirect_route('settings/backup');
                        return;
                    } catch (Throwable $e) {
                        $mysqli->rollback();
                        $error = 'Restore failed: ' . $e->getMessage();
                    }
                }
            }
        }

        $this->render('settings/backup', [
            'title' => 'Backup & Restore',
            'error' => $error,
        ]);
    }
}

