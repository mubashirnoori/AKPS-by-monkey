<?php

class AcademicController extends Controller
{
    /**
     * Institute-wide setup screens (subjects, exam structure, classes, teacher-subject
     * assignment, full timetable management) are Admin-only, even though Teacher also
     * holds 'academic.manage' for scoped tasks like marks entry.
     */
    private function requireAdminOnly(): void
    {
        RBAC::requireAdmin();
    }

    public function indexAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission('academic.view');

        $this->render('academic/index', [
            'title' => 'Academic',
        ]);
    }

    /** Filters to restore after create/edit/delete/merge (search, per_page). */
    private function subjectsListFilters(): array
    {
        $filters = recall_list_filters('subjects', [
            'q' => '',
            'per_page' => 50,
        ]);
        $filters['q'] = trim((string)($filters['q'] ?? ''));
        $allowed = [10, 20, 50, 100, 200, 999];
        $perPage = (int)($filters['per_page'] ?? 50);
        $filters['per_page'] = in_array($perPage, $allowed, true) ? $perPage : 50;
        return $filters;
    }

    private function redirectToSubjectsList(): void
    {
        redirect_list('academic/subjects', $this->subjectsListFilters());
    }

    /** Re-run the list query for the current (remembered) filters and render the list partial. */
    private function renderSubjectListPartial(): string
    {
        require_once __DIR__ . '/../models/SubjectModel.php';
        $filters = $this->subjectsListFilters();
        $search = $filters['q'];
        $perPage = (int)$filters['per_page'];
        $page = max(1, (int)($_POST['page'] ?? $_GET['page'] ?? 1));
        $offset = ($page - 1) * $perPage;

        return $this->renderPartial('academic/_subject_list', [
            'search' => $search,
            'perPage' => $perPage,
            'page' => $page,
            'total' => SubjectModel::count($search),
            'subjects' => SubjectModel::list($search, $perPage, $offset),
            'allSubjectOptions' => SubjectModel::allOptions(),
        ]);
    }

    public function subjectsAction(): void
    {
        require_once __DIR__ . '/../models/SubjectModel.php';

        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.subjects_manage']);
        $this->requireAdminOnly();

        $search = trim((string)($_GET['q'] ?? ''));
        $editId = (int)($_GET['id'] ?? 0);

        $subjectToEdit = $editId > 0 ? SubjectModel::getById($editId) : null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $id = (int)($_POST['id'] ?? 0);
            $payload = [
                'subject_code' => trim((string)($_POST['subject_code'] ?? '')),
                'subject_name' => trim((string)($_POST['subject_name'] ?? '')),
                'class_id' => (int)($_POST['class_id'] ?? 0) ?: null,
            ];
            if ($payload['subject_name'] === '') {
                $error = 'Subject name is required';
            } elseif (empty($payload['class_id'])) {
                $error = 'Please select the class this subject belongs to';
            } elseif (SubjectModel::existsInClass($payload['subject_name'], $payload['class_id'], $id)) {
                // Scoped per class, not global: "Urdu" is fine in First Year AND Second Year,
                // just not twice inside the same class.
                $error = '"' . $payload['subject_name'] . '" already exists in this class. '
                    . 'Edit the existing subject instead, or pick a different name (e.g. add the class/section, like "Urdu (Compulsory)").';
            } else {
                try {
                    if ($id > 0) {
                        SubjectModel::update($id, $payload);
                        $message = 'Subject updated';
                        log_activity('academic.subject_updated', 'Subject updated');
                    } else {
                        SubjectModel::create($payload);
                        $message = 'Subject created';
                        log_activity('academic.subject_created', 'Subject created');
                    }
                    if ($this->wantsJson()) {
                        $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderSubjectListPartial()]);
                    }
                    $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
                    $this->redirectToSubjectsList();
                    return;
                } catch (InvalidArgumentException $e) {
                    // Race condition fallback — existsInClass() already caught the common case above.
                    $error = $e->getMessage();
                }
            }
            if ($this->wantsJson()) {
                $this->jsonResponse(['success' => false, 'message' => $error], 422);
            }
        }

        $editId = $subjectToEdit ? (int)$subjectToEdit['id'] : 0;

        $page = max(1, (int)($_GET['page'] ?? 1));
        $allowedPerPage = [10, 20, 50, 100, 200, 999];
        $perPage = (int)($_GET['per_page'] ?? 50);
        if (!in_array($perPage, $allowedPerPage, true)) {
            $perPage = 50;
        }
        $offset = ($page - 1) * $perPage;

        $total = SubjectModel::count($search);
        $subjects = SubjectModel::list($search, $perPage, $offset);
        $classes = Database::fetchAll('SELECT id, name FROM classes ORDER BY name ASC');
        $allSubjectOptions = SubjectModel::allOptions();

        remember_list_filters('subjects', ['q' => $search, 'per_page' => $perPage]);

        $this->render('academic/subjects', [
            'title' => 'Subjects',
            'search' => $search,
            'subjects' => $subjects,
            'total' => $total,
            'page' => $page,
            'perPage' => $perPage,
            'subjectToEdit' => $subjectToEdit,
            'editId' => $editId,
            'classes' => $classes,
            'allSubjectOptions' => $allSubjectOptions,
            'error' => $error ?? null,
        ]);
    }

    public function subjectDeleteAction(): void
    {
        require_once __DIR__ . '/../models/SubjectModel.php';

        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.subjects_manage']);
        $this->requireAdminOnly();
        $this->requireCsrf();

        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            try {
                SubjectModel::delete($id);
                $message = 'Subject deleted';
                if ($this->wantsJson()) {
                    log_activity('academic.write', (string)($message));
                    $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderSubjectListPartial()]);
                }
                $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
                log_activity('academic.write', (string)($message));
            } catch (Throwable $e) {
                $message = 'Could not delete this subject — it already has timetable entries, marks, or attendance recorded against it. Use "Merge" instead to move that data to another subject first.';
                if ($this->wantsJson()) {
                    $this->jsonResponse(['success' => false, 'message' => $message], 422);
                }
                $_SESSION['flash'] = ['type' => 'danger', 'message' => $message];
            }
        }
        $this->redirectToSubjectsList();
    }

    public function subjectMergeAction(): void
    {
        require_once __DIR__ . '/../models/SubjectModel.php';
        require_once __DIR__ . '/../models/ExamSubjectScheduleModel.php';

        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.subjects_manage']);
        $this->requireAdminOnly();
        $this->requireCsrf();

        $fromId = (int)($_POST['from_id'] ?? 0);
        $intoId = (int)($_POST['into_id'] ?? 0);

        if ($fromId <= 0 || $intoId <= 0 || $fromId === $intoId) {
            $message = 'Pick two different subjects to merge.';
            if ($this->wantsJson()) {
                $this->jsonResponse(['success' => false, 'message' => $message], 422);
            }
            $_SESSION['flash'] = ['type' => 'danger', 'message' => $message];
        } else {
            try {
                SubjectModel::merge($fromId, $intoId);
                $message = 'Subjects merged — all its records now point to the subject you kept.';
                if ($this->wantsJson()) {
                    log_activity('academic.write', (string)($message));
                    $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $this->renderSubjectListPartial()]);
                }
                $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
                log_activity('academic.write', (string)($message));
            } catch (Throwable $e) {
                $message = 'Merge failed: ' . $e->getMessage();
                if ($this->wantsJson()) {
                    $this->jsonResponse(['success' => false, 'message' => $message], 422);
                }
                $_SESSION['flash'] = ['type' => 'danger', 'message' => $message];
            }
        }
        $this->redirectToSubjectsList();
    }

    public function teacherAssignmentsAction(): void
    {
        require_once __DIR__ . '/../models/SubjectModel.php';
        require_once __DIR__ . '/../models/StaffProfileModel.php';
        require_once __DIR__ . '/../models/StaffSubjectAssignmentModel.php';

        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.teacher_assignments']);
        $this->requireAdminOnly();

        $subjectId = (int)($_GET['subject_id'] ?? ($_POST['subject_id'] ?? 0));
        if ($subjectId <= 0) {
            $first = Database::fetchOne('SELECT id FROM subjects ORDER BY id ASC LIMIT 1');
            $subjectId = $first ? (int)$first['id'] : 0;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $action = (string)($_POST['action'] ?? '');
            if ($action === 'assign') {
                $staffProfileId = (int)($_POST['staff_profile_id'] ?? 0);
                StaffSubjectAssignmentModel::assignTeacher($subjectId, $staffProfileId);
                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Teacher assigned'];
                log_activity('academic.teacher_assigned', 'Teacher assigned');
            } elseif ($action === 'unassign') {
                $staffProfileId = (int)($_POST['staff_profile_id'] ?? 0);
                StaffSubjectAssignmentModel::unassignTeacher($subjectId, $staffProfileId);
                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Teacher unassigned'];
                log_activity('academic.teacher_unassigned', 'Teacher unassigned');
            }
            redirect('/index.php?route=academic/teacherAssignments&subject_id=' . $subjectId);
            return;
        }

        $assignedTeachers = $subjectId > 0 ? StaffSubjectAssignmentModel::getTeacherForSubject($subjectId) : [];
        $subjects = SubjectModel::allOptions();
        $staffOptions = StaffProfileModel::listOptions('', 200, 0);

        $this->render('academic/teacher_assignments', [
            'title' => 'Teacher Assignments',
            'subjectId' => $subjectId,
            'subjects' => $subjects,
            'staffOptions' => $staffOptions,
            'assignedTeachers' => $assignedTeachers,
        ]);
    }

    public function timetableAction(): void
    {
        require_once __DIR__ . '/../models/TimetableModel.php';
        require_once __DIR__ . '/../models/SubjectModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';
        require_once __DIR__ . '/../models/StaffProfileModel.php';

        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.timetable']);
        $this->requireAdminOnly();

        $classSectionId = (int)($_GET['class_section_id'] ?? ($_POST['class_section_id'] ?? 0));
        $classSections = ClassSectionModel::allOptions();
        if ($classSectionId <= 0) {
            $classSectionId = (int)($classSections[0]['id'] ?? 0);
        }
        $dayFilter = (int)($_GET['day_of_week'] ?? ($_POST['day_of_week_filter'] ?? 0));
        $dayNames = [1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday'];
        $dayColors = [
            1 => '#2563eb', 2 => '#7c3aed', 3 => '#0891b2', 4 => '#059669',
            5 => '#d97706', 6 => '#dc2626', 7 => '#64748b',
        ];
        $timetableUrl = base_url('/index.php?route=academic/timetable');

        require_once __DIR__ . '/../models/StaffSubjectAssignmentModel.php';
        $subjects = $classSectionId > 0
            ? SubjectModel::optionsForClassSection($classSectionId)
            : SubjectModel::allOptions();
        $entries = $classSectionId > 0 ? TimetableModel::listByClassSection($classSectionId, $dayFilter > 0 ? $dayFilter : null) : [];
        $teacherOptions = StaffProfileModel::listOptions('', 200, 0);
        $subjectTeacherMap = StaffSubjectAssignmentModel::getPrimaryTeacherMapForSubjects(array_column($subjects, 'id'));

        $redirectBack = function (int $cs) use ($dayFilter): void {
            $qs = '/index.php?route=academic/timetable&class_section_id=' . $cs;
            if ($dayFilter > 0) {
                $qs .= '&day_of_week=' . $dayFilter;
            }
            redirect($qs);
        };

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();

            $renderEntriesPartial = function () use (&$classSectionId, &$dayFilter, &$timetableUrl, &$dayNames, &$dayColors) {
                $entries = $classSectionId > 0 ? TimetableModel::listByClassSection($classSectionId, $dayFilter > 0 ? $dayFilter : null) : [];
                return $this->renderPartial('academic/_timetable_entries', [
                    'entries' => $entries,
                    'dayNames' => $dayNames,
                    'dayColors' => $dayColors,
                    'dayFilter' => $dayFilter,
                    'classSectionId' => $classSectionId,
                    'timetableUrl' => $timetableUrl,
                ]);
            };

            // Delete must run before create validation (delete form has no subject/time fields)
            if (isset($_POST['delete_id'])) {
                $deleteId = (int)$_POST['delete_id'];
                if ($deleteId > 0) {
                    TimetableModel::delete($deleteId);
                    if ($this->wantsJson()) {
                        log_activity('academic.timetable_entry_deleted', 'Timetable entry deleted');
                        $this->jsonResponse(['success' => true, 'message' => 'Timetable entry deleted', 'html' => $renderEntriesPartial()]);
                    }
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Timetable entry deleted'];
                    log_activity('academic.timetable_entry_deleted', 'Timetable entry deleted');
                    $redirectBack($classSectionId);
                    return;
                }
            }

            $user = Auth::currentUser();
            $byUserId = (int)($user['id'] ?? 0);
            $action = (string)($_POST['action'] ?? 'create');
            $editId = (int)($_POST['edit_id'] ?? 0);

            $payload = [
                'class_section_id' => (int)($_POST['class_section_id'] ?? 0),
                'day_of_week' => (int)($_POST['day_of_week'] ?? 1),
                'start_time' => trim((string)($_POST['start_time'] ?? '')),
                'end_time' => trim((string)($_POST['end_time'] ?? '')),
                'subject_id' => (int)($_POST['subject_id'] ?? 0),
                'teacher_id' => (int)($_POST['teacher_id'] ?? 0),
                'room' => trim((string)($_POST['room'] ?? '')),
            ];

            if ($payload['class_section_id'] <= 0 || $payload['subject_id'] <= 0 || $payload['start_time'] === '' || $payload['end_time'] === '') {
                $error = 'Please fill required fields (day, start, end, and a subject for this class).';
            } elseif ($payload['end_time'] <= $payload['start_time']) {
                $error = 'End time must be after start time.';
            } else {
                try {
                    if ($action === 'update' && $editId > 0) {
                        TimetableModel::update($editId, $payload, $byUserId > 0 ? $byUserId : null);
                        $message = 'Timetable entry updated';
                    } else {
                        TimetableModel::create($payload, $byUserId > 0 ? $byUserId : null);
                        $message = 'Timetable entry added';
                    }
                    if ($this->wantsJson()) {
                        log_activity('academic.write', (string)($message));
                        $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $renderEntriesPartial()]);
                    }
                    $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
                    log_activity('academic.write', (string)($message));
                    $redirectBack($payload['class_section_id']);
                    return;
                } catch (Throwable $e) {
                    $error = 'Could not save timetable: ' . $e->getMessage();
                }
            }

            if ($this->wantsJson()) {
                $this->jsonResponse(['success' => false, 'message' => $error], 422);
            }
            $entries = $classSectionId > 0 ? TimetableModel::listByClassSection($classSectionId, $dayFilter > 0 ? $dayFilter : null) : [];
            $subjects = $classSectionId > 0
                ? SubjectModel::optionsForClassSection($classSectionId)
                : SubjectModel::allOptions();
        }

        $this->render('academic/timetable', [
            'title' => 'Timetable',
            'classSections' => $classSections,
            'classSectionId' => $classSectionId,
            'dayFilter' => $dayFilter,
            'subjects' => $subjects,
            'entries' => $entries,
            'teacherOptions' => $teacherOptions,
            'subjectTeacherMap' => $subjectTeacherMap,
            'error' => $error ?? null,
        ]);
    }

    public function examTypesAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.exam_types']);
        $this->requireAdminOnly();

        require_once __DIR__ . '/../models/ExamModel.php';

        $error = null;
        $editId = (int)($_GET['id'] ?? 0);
        $typeToEdit = $editId > 0 ? ExamModel::getExamType($editId) : null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $action = (string)($_POST['action'] ?? 'save');

            if ($action === 'delete') {
                $id = (int)($_POST['id'] ?? 0);
                if ($id > 0) {
                    try {
                        ExamModel::deleteExamType($id);
                        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Exam type deleted'];
                        log_activity('academic.exam_type_deleted', 'Exam type deleted');
                    } catch (Throwable $e) {
                        $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Delete failed: ' . $e->getMessage()];
                    }
                }
                redirect_route('academic/examTypes');
                return;
            }

            $id = (int)($_POST['id'] ?? 0);
            $name = trim((string)($_POST['name'] ?? ''));
            $description = trim((string)($_POST['description'] ?? ''));
            if ($name === '') {
                $error = 'Exam type name required';
                $typeToEdit = $id > 0 ? ['id' => $id, 'name' => $name, 'description' => $description] : null;
            } else {
                if ($id > 0) {
                    ExamModel::updateExamType($id, $name, $description !== '' ? $description : null);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Exam type updated'];
                    log_activity('academic.exam_type_updated', 'Exam type updated');
                } else {
                    ExamModel::createExamType($name, $description !== '' ? $description : null);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Exam type created'];
                    log_activity('academic.exam_type_created', 'Exam type created');
                }
                redirect_route('academic/examTypes');
                return;
            }
        }

        $types = ExamModel::listExamTypes();
        $this->render('academic/exam_types', [
            'title' => 'Exam Types',
            'types' => $types,
            'typeToEdit' => $typeToEdit,
            'error' => $error,
        ]);
    }

    public function examGroupsAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.exam_groups']);
        $this->requireAdminOnly();

        require_once __DIR__ . '/../models/ExamModel.php';

        $examTypeId = (int)($_GET['exam_type_id'] ?? ($_POST['exam_type_id'] ?? 0));
        if ($examTypeId <= 0) {
            $first = Database::fetchOne('SELECT id FROM exam_types ORDER BY id ASC LIMIT 1');
            $examTypeId = $first ? (int)$first['id'] : 0;
        }

        $types = ExamModel::listExamTypes();
        $groups = ExamModel::listExamGroups($examTypeId > 0 ? $examTypeId : null);
        $editGroupId = (int)($_GET['edit_id'] ?? 0);
        $groupToEdit = $editGroupId > 0 ? ExamModel::getExamGroup($editGroupId) : null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $action = (string)($_POST['action'] ?? '');

            if ($action === 'deleteGroup') {
                $groupId = (int)($_POST['group_id'] ?? 0);
                if ($groupId > 0) {
                    try {
                        ExamModel::deleteExamGroup($groupId);
                        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Exam group deleted'];
                        log_activity('academic.exam_group_deleted', 'Exam group deleted');
                    } catch (Throwable $e) {
                        $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Delete failed: ' . $e->getMessage()];
                    }
                }
                redirect('/index.php?route=academic/examGroups&exam_type_id=' . $examTypeId);
                return;
            }

            if ($action === 'createGroup' || $action === 'updateGroup') {
                $groupId = (int)($_POST['group_id'] ?? 0);
                $name = trim((string)($_POST['group_name'] ?? ''));
                $sortOrder = (int)($_POST['sort_order'] ?? 0);
                $overallRaw = trim((string)($_POST['overall_passing_percentage'] ?? ''));
                $rule = [
                    'passing_percentage' => (float)($_POST['passing_percentage'] ?? 50),
                    'passing_description' => trim((string)($_POST['passing_description'] ?? '')),
                    'max_failed_subjects' => (int)($_POST['max_failed_subjects'] ?? 2),
                    'require_overall_pass' => isset($_POST['require_overall_pass']) ? 1 : 0,
                    'overall_passing_percentage' => $overallRaw !== '' ? (float)$overallRaw : null,
                    'no_marks_is_fail' => isset($_POST['no_marks_is_fail']) ? 1 : 0,
                    'force_grade_f_on_fail' => isset($_POST['force_grade_f_on_fail']) ? 1 : 0,
                ];

                if ($name === '') {
                    $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Group name is required'];
                    redirect('/index.php?route=academic/examGroups&exam_type_id=' . $examTypeId);
                    return;
                }

                if ($action === 'updateGroup' && $groupId > 0) {
                    ExamModel::updateExamGroup($groupId, $examTypeId, $name, $sortOrder);
                    ExamModel::upsertExamRule($groupId, $rule);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Exam group / pass criteria updated'];
                    log_activity('academic.exam_group_pass_criteria_updated', 'Exam group / pass criteria updated');
                } else {
                    $newId = ExamModel::createExamGroup($examTypeId, $name, $sortOrder);
                    ExamModel::upsertExamRule($newId, $rule);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Exam group created'];
                    log_activity('academic.exam_group_created', 'Exam group created');
                }
                redirect('/index.php?route=academic/examGroups&exam_type_id=' . $examTypeId);
                return;
            }
        }

        $this->render('academic/exam_groups', [
            'title' => 'Exam Groups',
            'types' => $types,
            'examTypeId' => $examTypeId,
            'groups' => $groups,
            'groupToEdit' => $groupToEdit,
        ]);
    }

    public function examsAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.exams']);
        $this->requireAdminOnly();

        require_once __DIR__ . '/../models/ExamModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';

        $classSections = ClassSectionModel::allOptions();

        $academicYears = Database::fetchAll('SELECT id, academic_year_label FROM academic_years ORDER BY academic_year_label DESC');
        $examGroups = Database::fetchAll('SELECT eg.id, eg.name, et.name AS exam_type_name FROM exam_groups eg JOIN exam_types et ON et.id = eg.exam_type_id ORDER BY et.name, eg.sort_order');
        $examBaseNames = ExamModel::distinctExamBaseNames();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $action = (string)($_POST['action'] ?? 'create');
            $user = Auth::currentUser();
            $byUserId = (int)($user['id'] ?? 0);
            $examsUrl = base_url('/index.php?route=academic/exams');
            $examPage = max(1, (int)($_POST['exam_page'] ?? $_GET['page'] ?? 1));
            $examPerPage = 15;

            $renderListPartial = function () use ($examsUrl, $examPage, $examPerPage) {
                $paged = ExamModel::listExamsPaginated($examPage, $examPerPage);
                return $this->renderPartial('academic/_exam_list', [
                    'exams' => $paged['rows'],
                    'examsUrl' => $examsUrl,
                    'examPage' => $examPage,
                    'examTotalPages' => (int)ceil($paged['total'] / $examPerPage),
                ]);
            };

            if ($action === 'delete') {
                $id = (int)($_POST['id'] ?? 0);
                if ($id > 0) {
                    try {
                        ExamModel::deleteExam($id);
                        $message = 'Exam deleted';
                        if ($this->wantsJson()) {
                            log_activity('academic.write', (string)($message));
                            $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $renderListPartial()]);
                        }
                        $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
                        log_activity('academic.write', (string)($message));
                    } catch (Throwable $e) {
                        if ($this->wantsJson()) {
                            $this->jsonResponse(['success' => false, 'message' => 'Delete failed: ' . $e->getMessage()], 422);
                        }
                        $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Delete failed: ' . $e->getMessage()];
                    }
                }
                redirect_route('academic/exams');
                return;
            }

            if ($action === 'publish' || $action === 'unpublish') {
                $id = (int)($_POST['id'] ?? 0);
                if ($id > 0) {
                    if ($action === 'publish') {
                        ExamModel::publishResults($id);
                        $message = 'Results published — students and parents can now see them.';

                        // Notify every student (and their guardians) who has
                        // marks recorded for this exam — same text works for
                        // all of them, so this uses the bulk helper.
                        require_once __DIR__ . '/../models/NotificationModel.php';
                        $examRow = Database::fetchOne('SELECT exam_name FROM exams WHERE id = ? LIMIT 1', 'i', [$id]);
                        $studentIdRows = Database::fetchAll('SELECT DISTINCT student_id FROM marks WHERE exam_id = ?', 'i', [$id]);
                        $affectedStudentIds = array_map(static fn($r) => (int)$r['student_id'], $studentIdRows);
                        if ($examRow && !empty($affectedStudentIds)) {
                            NotificationModel::notifyStudentsAndGuardians(
                                $affectedStudentIds,
                                'result_published',
                                'Results published',
                                'Results for ' . ($examRow['exam_name'] ?? 'an exam') . ' have been published. Check your report card.',
                                route_url('portal/myReportCard')
                            );
                        }
                    } else {
                        ExamModel::unpublishResults($id);
                        $message = 'Results hidden from students and parents again.';
                    }
                    if ($this->wantsJson()) {
                        log_activity('academic.write', (string)($message));
                        $this->jsonResponse(['success' => true, 'message' => $message, 'html' => $renderListPartial()]);
                    }
                    $_SESSION['flash'] = ['type' => 'success', 'message' => $message];
                    log_activity('academic.write', (string)($message));
                }
                redirect_route('academic/exams');
                return;
            }

            if ($action === 'create') {
                $classSectionIds = array_map('intval', (array)($_POST['class_section_ids'] ?? []));
                $classSectionIds = array_values(array_filter($classSectionIds, function ($id) { return $id > 0; }));

                $payload = [
                    'exam_group_id' => (int)($_POST['exam_group_id'] ?? 0),
                    'academic_year_id' => (int)($_POST['academic_year_id'] ?? 0) ?: null,
                    'exam_name' => trim((string)($_POST['exam_name'] ?? '')),
                    'scheduled_date' => trim((string)($_POST['scheduled_date'] ?? '')) ?: null,
                    'start_time' => trim((string)($_POST['start_time'] ?? '')) ?: null,
                    'end_time' => trim((string)($_POST['end_time'] ?? '')) ?: null,
                    'total_marks' => (int)($_POST['total_marks'] ?? 0) ?: null,
                    'cumulative_source_exam_name' => trim((string)($_POST['cumulative_source_exam_name'] ?? '')) ?: null,
                ];

                if ($payload['exam_group_id'] <= 0 || $payload['exam_name'] === '' || empty($classSectionIds)) {
                    $error = 'Fill exam group, exam name, and select at least one class.';
                } elseif ($payload['start_time'] && $payload['end_time'] && $payload['end_time'] <= $payload['start_time']) {
                    $error = 'End time must be after start time.';
                } else {
                    $result = ExamModel::createExamForClasses($classSectionIds, $payload, $byUserId > 0 ? $byUserId : null);
                    $count = count($result['created']);
                    if ($count > 0) {
                        $msg = $count === 1 ? 'Exam created.' : "Exam created for $count classes.";
                        if (!empty($result['errors'])) {
                            $msg .= ' Some classes were skipped: ' . implode(' ', $result['errors']);
                        }
                        if ($this->wantsJson()) {
                            log_activity('academic.write', (string)($msg));
                            $this->jsonResponse(['success' => true, 'message' => $msg, 'html' => $renderListPartial()]);
                        }
                        $_SESSION['flash'] = ['type' => 'success', 'message' => $msg];
                        log_activity('academic.write', (string)($msg));
                    } else {
                        $failMsg = 'No exams created. ' . implode(' ', $result['errors']);
                        if ($this->wantsJson()) {
                            $this->jsonResponse(['success' => false, 'message' => $failMsg], 422);
                        }
                        $_SESSION['flash'] = ['type' => 'danger', 'message' => $failMsg];
                    }
                    redirect_route('academic/exams');
                    return;
                }
                // fall through to re-render with $error set
            } elseif ($action === 'update') {
                $id = (int)($_POST['id'] ?? 0);
                $payload = [
                    'exam_group_id' => (int)($_POST['exam_group_id'] ?? 0),
                    'academic_year_id' => (int)($_POST['academic_year_id'] ?? 0) ?: null,
                    'class_section_id' => (int)($_POST['class_section_id'] ?? 0) ?: null,
                    'exam_name' => trim((string)($_POST['exam_name'] ?? '')),
                    'scheduled_date' => trim((string)($_POST['scheduled_date'] ?? '')) ?: null,
                    'start_time' => trim((string)($_POST['start_time'] ?? '')) ?: null,
                    'end_time' => trim((string)($_POST['end_time'] ?? '')) ?: null,
                    'total_marks' => (int)($_POST['total_marks'] ?? 0) ?: null,
                    'cumulative_source_exam_name' => trim((string)($_POST['cumulative_source_exam_name'] ?? '')) ?: null,
                ];

                if ($payload['exam_group_id'] <= 0 || $payload['exam_name'] === '' || !$payload['class_section_id'] || $id <= 0) {
                    $error = 'Fill exam group, class section and exam name.';
                } elseif ($payload['start_time'] && $payload['end_time'] && $payload['end_time'] <= $payload['start_time']) {
                    $error = 'End time must be after start time.';
                } else {
                    ExamModel::updateExam($id, $payload);
                    if ($this->wantsJson()) {
                        log_activity('academic.exam_updated', 'Exam updated');
                        $this->jsonResponse(['success' => true, 'message' => 'Exam updated', 'html' => $renderListPartial()]);
                    }
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Exam updated'];
                    log_activity('academic.exam_updated', 'Exam updated');
                    redirect_route('academic/exams');
                    return;
                }
            }

            if ($this->wantsJson() && isset($error)) {
                $this->jsonResponse(['success' => false, 'message' => $error], 422);
            }
        }

        $examPage = max(1, (int)($_GET['page'] ?? 1));
        $examPerPage = 15;
        $examsPaged = ExamModel::listExamsPaginated($examPage, $examPerPage);
        $exams = $examsPaged['rows'];
        $this->render('academic/exams', [
            'title' => 'Exams',
            'classSections' => $classSections,
            'examGroups' => $examGroups,
            'academicYears' => $academicYears,
            'examPage' => $examPage,
            'examTotalPages' => (int)ceil($examsPaged['total'] / $examPerPage),
            'exams' => $exams,
            'examBaseNames' => $examBaseNames,
            'error' => $error ?? null,
        ]);
    }

    public function marksEntryAction(): void
    {
        require_once __DIR__ . '/../models/ExamModel.php';
        require_once __DIR__ . '/../models/MarkModel.php';
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/SubjectModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';
        require_once __DIR__ . '/../models/ExamSubjectScheduleModel.php';

        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.marks_entry']);

        // A Teacher may only enter marks for their own assigned classes/subjects.
        $isTeacherScoped = !RBAC::isAdmin();
        $allowedClassSectionIds = $isTeacherScoped ? RBAC::currentTeacherClassSectionIds() : [];
        $allowedSubjectIds = $isTeacherScoped ? RBAC::currentTeacherSubjectIds() : [];
        if ($isTeacherScoped && empty($allowedClassSectionIds)) {
            $this->render('academic/marks_entry', [
                'title' => 'Marks Entry',
                'error' => 'No classes are assigned to you yet. Ask an admin to assign your subjects.',
                'exams' => [], 'subjects' => [], 'classSections' => [], 'examId' => 0,
                'subjectId' => 0, 'classSectionId' => 0, 'exam' => null, 'students' => [],
                'marksByStudent' => [], 'savedSubjectTotal' => null, 'lastSavedInfo' => null,
            ]);
            return;
        }

        $error = null;
        $examId = (int)($_GET['exam_id'] ?? ($_POST['exam_id'] ?? 0));
        $subjectId = (int)($_GET['subject_id'] ?? ($_POST['subject_id'] ?? 0));
        $classSectionId = (int)($_GET['class_section_id'] ?? ($_POST['class_section_id'] ?? 0));

        if ($isTeacherScoped && $classSectionId > 0 && !in_array($classSectionId, $allowedClassSectionIds, true)) {
            $classSectionId = 0;
        }

        $classSections = $isTeacherScoped
            ? array_values(array_filter(
                ClassSectionModel::allOptions(),
                static fn($cs) => in_array((int)$cs['id'], $allowedClassSectionIds, true)
            ))
            : ClassSectionModel::allOptions();
        if ($classSectionId <= 0 && $isTeacherScoped) {
            $classSectionId = $allowedClassSectionIds[0] ?? 0;
        }

        // Load exams for selected class (or all), with class labels
        $exams = ExamModel::listExams($classSectionId > 0 ? $classSectionId : null);

        // Was class_section_id itself explicitly part of this request? All three selects
        // (class/exam/subject) live in one auto-submitting form, so switching the Class
        // dropdown still posts the *stale* exam_id/subject_id left over from the previous
        // class. In that case the class the user just picked should win — the leftover
        // exam should be dropped, not used to snap the class back.
        $classSectionExplicit = isset($_GET['class_section_id']) || isset($_POST['class_section_id']);

        // If exam selected, lock class to that exam's class/section
        $exam = $examId > 0 ? ExamModel::getExam($examId) : null;
        if ($exam && !empty($exam['class_section_id'])) {
            $examClassSectionId = (int)$exam['class_section_id'];
            if ($isTeacherScoped && !in_array($examClassSectionId, $allowedClassSectionIds, true)) {
                // Not this teacher's class — ignore the exam entirely.
                $exam = null;
                $examId = 0;
            } elseif ($classSectionExplicit && $examClassSectionId !== $classSectionId) {
                // The user just changed the class in this same request — the exam_id we
                // received is stale (belongs to the old class). Drop it instead of
                // overriding the class the user just picked.
                $exam = null;
                $examId = 0;
            } else {
                $classSectionId = $examClassSectionId;
                // Keep exam list scoped to this class once an exam is chosen
                if (!$classSectionExplicit) {
                    $exams = ExamModel::listExams($classSectionId);
                }
            }
        }

        if ($isTeacherScoped) {
            $exams = array_values(array_filter(
                $exams,
                static fn($e) => in_array((int)($e['class_section_id'] ?? 0), $allowedClassSectionIds, true)
            ));
        }

        // Default exam: first in filtered list
        if ($examId <= 0 && !empty($exams)) {
            $examId = (int)$exams[0]['id'];
            $exam = ExamModel::getExam($examId);
            if ($exam && !empty($exam['class_section_id'])) {
                $classSectionId = (int)$exam['class_section_id'];
            }
        }

        // Subjects only for the selected / exam's class — not Nursery subjects on Prep
        $subjects = $classSectionId > 0
            ? SubjectModel::optionsForClassSection($classSectionId)
            : [];
        if ($isTeacherScoped) {
            $subjects = array_values(array_filter(
                $subjects,
                static fn($s) => in_array((int)$s['id'], $allowedSubjectIds, true)
            ));
        }

        if ($subjectId > 0) {
            $allowedIds = array_map(static fn($s) => (int)$s['id'], $subjects);
            if (!in_array($subjectId, $allowedIds, true)) {
                $subjectId = 0;
            }
        }
        if ($subjectId <= 0 && !empty($subjects)) {
            $subjectId = (int)$subjects[0]['id'];
        }

        // Students of the exam's class/section only (not exam type)
        $students = [];
        if ($classSectionId > 0) {
            $students = StudentModel::getStudentsForClassSection($classSectionId, '', 500, 0);
        }

        // Existing marks map (student_id => score) + saved total_marks for this subject
        $marksByStudent = [];
        $savedSubjectTotal = null;
        $lastSavedInfo = null;
        if ($examId > 0 && $subjectId > 0) {
            $existing = MarkModel::getMarksForExamSubject($examId, $subjectId);
            foreach ($existing as $m) {
                $marksByStudent[(int)$m['student_id']] = (string)($m['score'] ?? '0');
                if ($savedSubjectTotal === null && !empty($m['total_marks'])) {
                    $savedSubjectTotal = (float)$m['total_marks'];
                }
            }
            if (!empty($existing)) {
                $lastSavedInfo = MarkModel::getLastSavedInfo($examId, $subjectId);
            }
        }

        // No marks saved yet for this subject — fall back to the per-subject total set
        // on the exam's Date Sheet (exam_subject_schedule), before the exam-wide default.
        $dateSheetSubjectTotal = null;
        if ($savedSubjectTotal === null && $examId > 0 && $subjectId > 0) {
            $scheduleRow = ExamSubjectScheduleModel::mapForExam($examId)[$subjectId] ?? null;
            if ($scheduleRow && !empty($scheduleRow['total_marks'])) {
                $dateSheetSubjectTotal = (float)$scheduleRow['total_marks'];
            }
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['filter_only'])) {
            $this->requireCsrf();
            $blocked = $isTeacherScoped && (
                !in_array($classSectionId, $allowedClassSectionIds, true) ||
                !in_array($subjectId, $allowedSubjectIds, true)
            );
            if ($blocked) {
                http_response_code(403);
                require __DIR__ . '/../views/errors/403.php';
                exit;
            }
            if ($examId > 0 && $subjectId > 0) {
                $user = Auth::currentUser();
                $byUserId = (int)($user['id'] ?? 0);
                $scoreByStudentId = $_POST['score_by_student'] ?? [];
                if (!is_array($scoreByStudentId)) {
                    $scoreByStudentId = [];
                }
                $subjectTotalMarks = (float)($_POST['subject_total_marks'] ?? 100);
                if ($subjectTotalMarks <= 0) { $subjectTotalMarks = 100.0; }
                try {
                    MarkModel::saveMarks($examId, $subjectId, $scoreByStudentId, $byUserId, $subjectTotalMarks);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Marks saved'];
                    log_activity('academic.marks_saved', 'Marks saved');
                    redirect('/index.php?route=academic/marksEntry&exam_id=' . $examId
                        . '&subject_id=' . $subjectId
                        . '&class_section_id=' . $classSectionId);
                    return;
                } catch (Throwable $e) {
                    $error = $e->getMessage();
                }
            }
        }

        $this->render('academic/marks_entry', [
            'title' => 'Marks Entry',
            'error' => $error,
            'exams' => $exams,
            'subjects' => $subjects,
            'classSections' => $classSections,
            'examId' => $examId,
            'subjectId' => $subjectId,
            'classSectionId' => $classSectionId,
            'exam' => $exam,
            'students' => $students,
            'marksByStudent' => $marksByStudent,
            'savedSubjectTotal' => $savedSubjectTotal,
            'dateSheetSubjectTotal' => $dateSheetSubjectTotal,
            'lastSavedInfo' => $lastSavedInfo,
        ]);
    }

    public function gradeSettingsAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.grade_settings']);
        $this->requireAdminOnly();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $grades = Database::fetchAll('SELECT id FROM grades');
            foreach ($grades as $g) {
                $id = (int)$g['id'];
                $min = trim((string)($_POST['min_score'][$id] ?? ''));
                $max = trim((string)($_POST['max_score'][$id] ?? ''));
                if ($min === '' || $max === '') {
                    continue;
                }
                Database::execute(
                    'UPDATE grades SET min_score = ?, max_score = ? WHERE id = ?',
                    'ddi',
                    [(float)$min, (float)$max, $id]
                );
            }
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Grades updated'];
            log_activity('academic.grades_updated', 'Grades updated');
            redirect_route('academic/gradeSettings');
            return;
        }

        $grades = Database::fetchAll('SELECT id, grade_letter, min_score, max_score, sort_order FROM grades ORDER BY sort_order ASC');
        $this->render('academic/grade_settings', [
            'title' => 'Grade Settings',
            'grades' => $grades,
        ]);
    }

    public function dateSheetAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission('academic.view');

        require_once __DIR__ . '/../models/ExamModel.php';
        require_once __DIR__ . '/../models/ExamSubjectScheduleModel.php';
        require_once __DIR__ . '/../models/SubjectModel.php';

        $examId = (int)($_GET['exam_id'] ?? ($_POST['exam_id'] ?? 0));

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Saving per-subject dates requires the same admin-only edit rights as the rest of Academic.
            $this->requirePermission(['academic.manage', 'academic.date_sheet']);
            $this->requireAdminOnly();
            $this->requireCsrf();

            $exam = $examId > 0 ? ExamModel::getExam($examId) : null;
            if (!$exam) {
                $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Choose an exam first.'];
                redirect_route('academic/dateSheet');
                return;
            }

            $subjectIds = $_POST['subject_id'] ?? [];
            $dates = $_POST['scheduled_date'] ?? [];
            $starts = $_POST['start_time'] ?? [];
            $ends = $_POST['end_time'] ?? [];
            $marks = $_POST['total_marks'] ?? [];

            foreach ($subjectIds as $i => $sid) {
                $sid = (int)$sid;
                if ($sid <= 0) {
                    continue;
                }
                $date = trim((string)($dates[$i] ?? ''));
                $start = trim((string)($starts[$i] ?? ''));
                $end = trim((string)($ends[$i] ?? ''));
                $mark = trim((string)($marks[$i] ?? ''));

                if ($date === '' && $start === '' && $end === '' && $mark === '') {
                    // Nothing entered for this subject — clear any previous row so it drops off the sheet.
                    ExamSubjectScheduleModel::clearForSubject($examId, $sid);
                    continue;
                }
                if ($start !== '' && $end !== '' && $end <= $start) {
                    $_SESSION['flash'] = ['type' => 'danger', 'message' => 'End time must be after start time for one of the subjects.'];
                    redirect('/index.php?route=academic/dateSheet&exam_id=' . $examId);
                    return;
                }
                ExamSubjectScheduleModel::upsert(
                    $examId,
                    $sid,
                    $date !== '' ? $date : null,
                    $start !== '' ? $start : null,
                    $end !== '' ? $end : null,
                    $mark !== '' ? (int)$mark : null,
                    (int)$i
                );
            }

            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Date sheet saved'];
            log_activity('academic.date_sheet_saved', 'Date sheet saved');
            redirect('/index.php?route=academic/dateSheet&exam_id=' . $examId);
            return;
        }

        $exam = $examId > 0 ? ExamModel::getExam($examId) : null;
        $exams = ExamModel::listExams();

        $subjects = [];
        $scheduleMap = [];
        if ($exam) {
            $subjects = SubjectModel::optionsForClassSection((int)($exam['class_section_id'] ?? 0));
            $scheduleMap = ExamSubjectScheduleModel::mapForExam($examId);
        }

        $this->render('academic/date_sheet', [
            'title' => 'Date Sheet',
            'examId' => $examId,
            'exam' => $exam,
            'exams' => $exams,
            'subjects' => $subjects,
            'scheduleMap' => $scheduleMap,
            'canManage' => RBAC::isAdmin(),
        ]);
    }

    /**
     * Printable per-student date slips: each student's name, roll number and the exam's
     * subject dates, several slips to an A4 page. scope=class prints one class's students,
     * scope=group prints every class that has an exam in the same exam group.
     */
    public function dateSheetSlipsAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission('academic.view');

        require_once __DIR__ . '/../models/ExamModel.php';
        require_once __DIR__ . '/../models/ExamSubjectScheduleModel.php';
        require_once __DIR__ . '/../models/SubjectModel.php';
        require_once __DIR__ . '/../models/StudentModel.php';

        $examId = (int)($_GET['exam_id'] ?? 0);
        $exam = $examId > 0 ? ExamModel::getExam($examId) : null;
        if (!$exam) {
            $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Choose an exam first.'];
            redirect_route('academic/dateSheet');
            return;
        }
        $scope = (($_GET['scope'] ?? 'class') === 'group') ? 'group' : 'class';
        $perPageChoice = (string)($_GET['per_page'] ?? 'auto');
        if (!in_array($perPageChoice, ['auto', '1', '2', '3', '4', '6', '8'], true)) {
            $perPageChoice = 'auto';
        }

        $examIds = [$examId];
        if ($scope === 'group') {
            $examIds = array_map('intval', array_column(Database::fetchAll(
                'SELECT e.id FROM exams e
                 LEFT JOIN class_sections cs ON cs.id = e.class_section_id
                 WHERE e.exam_group_id = ?
                 ORDER BY cs.class_id, cs.section_id, e.id',
                'i', [(int)$exam['exam_group_id']]
            ), 'id'));
        }

        $blocks = [];
        $skipped = [];
        foreach ($examIds as $eid) {
            $ex = $eid === $examId ? $exam : ExamModel::getExam($eid);
            if (!$ex) {
                continue;
            }
            $classLabel = trim(($ex['class_name'] ?? '') . ' ' . ($ex['section_name'] ?? ''));
            $subjects = SubjectModel::optionsForClassSection((int)($ex['class_section_id'] ?? 0));
            $map = ExamSubjectScheduleModel::mapForExam($eid);
            $rows = [];
            foreach ($subjects as $sub) {
                $r = $map[(int)$sub['id']] ?? null;
                if ($r && (!empty($r['scheduled_date']) || !empty($r['start_time']))) {
                    $rows[] = [
                        'subject_name' => $sub['subject_name'],
                        'scheduled_date' => $r['scheduled_date'] ?? null,
                        'start_time' => $r['start_time'] ?? null,
                        'end_time' => $r['end_time'] ?? null,
                    ];
                }
            }
            usort($rows, function ($a, $b) {
                return (($a['scheduled_date'] ?? '9999-99-99') . ($a['start_time'] ?? '99:99:99'))
                    <=> (($b['scheduled_date'] ?? '9999-99-99') . ($b['start_time'] ?? '99:99:99'));
            });
            if (!$rows) {
                $skipped[] = $classLabel . ' (no dates scheduled)';
                continue;
            }
            $students = StudentModel::getStudentsForClassSection((int)($ex['class_section_id'] ?? 0), '', 2000);
            if (!$students) {
                $skipped[] = $classLabel . ' (no students)';
                continue;
            }
            usort($students, function ($a, $b) {
                $ra = (int)($a['roll_number'] ?? 0) ?: PHP_INT_MAX;
                $rb = (int)($b['roll_number'] ?? 0) ?: PHP_INT_MAX;
                return $ra <=> $rb ?: strcasecmp((string)$a['first_name'], (string)$b['first_name']);
            });

            // Fit: estimated slip height in mm (header, student line, table, signatures) against the
            // 281mm printable A4 height. Auto packs as many as fit in two columns; a chosen
            // number is honoured unless the slip would overflow, then it is lowered to what fits.
            $slipMm = 50 + 6.5 * count($rows);
            $fitRows = max(1, (int)floor(281 / $slipMm));
            $layouts = ['1' => [1, 1], '2' => [1, 2], '3' => [1, 3], '4' => [2, 2], '6' => [2, 3], '8' => [2, 4]];
            [$cols, $rowsPerPage] = $perPageChoice === 'auto' ? [2, $fitRows] : $layouts[$perPageChoice];
            $note = '';
            if ($rowsPerPage > $fitRows) {
                $note = $classLabel . ': ' . ($cols * $rowsPerPage) . ' per page would not fit ' . count($rows) . ' subjects, so ' . ($cols * $fitRows) . ' per page is used.';
                $rowsPerPage = $fitRows;
            }
            $blocks[] = [
                'exam' => $ex, 'class_label' => $classLabel, 'rows' => $rows, 'students' => $students,
                'cols' => $cols, 'rows_per_page' => $rowsPerPage, 'per_page' => $cols * $rowsPerPage, 'note' => $note,
            ];
        }

        $this->render('academic/date_sheet_slips', [
            'title' => 'Student Date Slips',
            'exam' => $exam,
            'examId' => $examId,
            'scope' => $scope,
            'perPageChoice' => $perPageChoice,
            'blocks' => $blocks,
            'skipped' => $skipped,
        ]);
    }

    public function certificateAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/MarkModel.php';
        require_once __DIR__ . '/../models/ExamModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';

        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.report_cards']);

        $studentId = (int)($_GET['student_id'] ?? 0);
        $examId = (int)($_GET['exam_id'] ?? 0);
        $classSectionId = (int)($_GET['class_section_id'] ?? 0);

        $isAdmin = RBAC::isAdmin();
        $isRestrictedTeacher = !$isAdmin && RBAC::isTeacher();
        // Only Admin may ever see an unpublished/draft report card — this used to
        // only apply to the literal 'teacher' role, so Principal or any other
        // non-admin role could still open draft results before they were published.
        $isRestrictedNonAdmin = !$isAdmin;

        // Teachers may only print report cards for students in their own classes.
        if ($isRestrictedTeacher && $studentId > 0) {
            $studentCsId = StudentModel::getCurrentClassSectionId($studentId);
            $allowedCsIds = RBAC::currentTeacherClassSectionIds();
            if (!$studentCsId || !in_array((int)$studentCsId, $allowedCsIds, true)) {
                http_response_code(403);
                require __DIR__ . '/../views/errors/403.php';
                exit;
            }
        }

        // Only Admin may see/print exams whose results haven't been published yet —
        // same as the student/parent portal.
        if ($isRestrictedNonAdmin && $examId > 0) {
            $examCheck = ExamModel::getExam($examId);
            if (!$examCheck || (int)($examCheck['results_published'] ?? 0) !== 1) {
                http_response_code(403);
                require __DIR__ . '/../views/errors/403.php';
                exit;
            }
        }

        $student = $studentId > 0 ? StudentModel::getById($studentId) : null;
        $studentMarks = [];
        $average = null;
        $overallGrade = null;
        $failedSubjects = 0;
        $passingPercentage = 50.0;
        $resultStatus = null;
        $resultReasons = [];
        $passRule = null;
        $classToppers = [];
        $studentRank = null;
        $classSize = 0;
        $isSchoolTopper = false;
        $combinedWith = null;
        $breakdown = [];

        $exams = ExamModel::listExams($classSectionId > 0 ? $classSectionId : null);
        if ($isRestrictedNonAdmin) {
            $exams = array_values(array_filter(
                $exams,
                static fn($e) => (int)($e['results_published'] ?? 0) === 1
            ));
        }
        $classSections = ClassSectionModel::allOptions();

        if ($student && $examId > 0) {
            $card = ExamModel::studentReportCard($studentId, $examId, false, $this->canSeeUnpublishedResults());
            $studentMarks = $card['studentMarks'];
            $average = $card['average'];
            $overallGrade = $card['overallGrade'];
            $failedSubjects = $card['failedSubjects'];
            $passingPercentage = $card['passingPercentage'];
            $resultStatus = $card['resultStatus'];
            $resultReasons = $card['resultReasons'];
            $passRule = $card['passRule'];
            $classToppers = $card['classToppers'];
            $studentRank = $card['studentRank'];
            $classSize = $card['classSize'];
            $isSchoolTopper = $card['isSchoolTopper'];
            $combinedWith = $card['combinedWith'];
            $breakdown = $card['breakdown'];
        }

        // "Send via WhatsApp" support: only offer it once there's an actual
        // result on screen for a real student (not the bare search form),
        // and only for a published exam — same gate already enforced above
        // for non-admins, applied here regardless of role since the link
        // itself will be openable by anyone who has it (i.e. a parent).
        $whatsappRecipients = [];
        if ($student && $examId > 0 && !empty($studentMarks)) {
            $examRow = null;
            foreach ($exams as $e) {
                if ((int)$e['id'] === $examId) {
                    $examRow = $e;
                    break;
                }
            }
            if ($examRow === null) {
                // Not in $exams at all for a non-admin means it was filtered out
                // above for being unpublished — look it up directly so we can
                // check its real, current publish status rather than assuming.
                $examRow = ExamModel::getExam($examId);
            }
            if ($examRow && (int)($examRow['results_published'] ?? 0) === 1) {
                $shareToken = ShareToken::generate('report_card', $studentId, ['exam_id' => $examId]);
                $shareUrl = base_url('/index.php?' . http_build_query(['route' => 'share/reportCard', 't' => $shareToken]));
                $studentDisplayName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
                $waMessage = "Report card for {$studentDisplayName} ({$examRow['exam_name']}): {$shareUrl}";
                require_once __DIR__ . '/../models/GuardianModel.php';
                $guardians = GuardianModel::listByStudent($studentId);
                $whatsappRecipients = whatsapp_share_recipients($student ?? [], $guardians, $waMessage);
            }
        }

        $this->render('academic/certificate', [
            'title' => 'Certificate',
            'student' => $student,
            'exams' => $exams,
            'examId' => $examId,
            'studentId' => $studentId,
            'whatsappRecipients' => $whatsappRecipients,
            'studentMarks' => $studentMarks,
            'average' => $average,
            'overallGrade' => $overallGrade,
            'failedSubjects' => $failedSubjects,
            'passingPercentage' => $passingPercentage,
            'resultStatus' => $resultStatus,
            'resultReasons' => $resultReasons,
            'passRule' => $passRule,
            'classSections' => $classSections,
            'classSectionId' => $classSectionId,
            'classToppers' => $classToppers,
            'studentRank' => $studentRank,
            'classSize' => $classSize,
            'isSchoolTopper' => $isSchoolTopper,
            'combinedWith' => $combinedWith,
            'breakdown' => $breakdown,
        ]);
    }

    /**
     * True when the logged-in user may see or bulk-export DRAFT (not yet
     * officially published) exam results. Admin always can. Any other role
     * only if explicitly granted the 'academic.unpublished_results'
     * permission from Users & Roles -> Roles & Permissions — e.g. for a
     * "Result Admin" / "Principal" role that needs to review results before
     * they're published to teachers/parents/students.
     */
    private function canSeeUnpublishedResults(): bool
    {
        return RBAC::isAdmin() || RBAC::hasPermission('academic.unpublished_results');
    }

    /**
     * Gate for the bulk export tools specifically (Report Cards ZIP, Results
     * CSV, Results Excel workbook — bulkExportsAction() and everything it
     * feeds). Unlike canSeeUnpublishedResults() above, this is Admin-only,
     * full stop — no permission can widen it. Before results are published,
     * nobody except Admin may see them or download them in any of the three
     * bulk formats, regardless of role or granted permissions.
     */
    private function canBulkExportUnpublished(): bool
    {
        return RBAC::isAdmin();
    }

    /** Whole-school topper (classes 5th–8th only), for school management to review before announcing. */
    public function schoolTopperAction(): void
    {
        require_once __DIR__ . '/../models/ExamModel.php';

        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.school_topper']);

        $canSeeUnpublished = $this->canSeeUnpublishedResults();
        $examNames = array_map(static fn($r) => $r['exam_name'], ExamModel::schoolTopperExamNames($canSeeUnpublished));
        $examName = trim((string)($_GET['exam_name'] ?? ''));
        if ($examName === '' || !in_array($examName, $examNames, true)) {
            $examName = $examNames[0] ?? '';
        }

        $data = $examName !== '' ? ExamModel::schoolTopper($examName, $canSeeUnpublished) : ['exams' => [], 'toppers' => []];

        $this->render('academic/school_topper', [
            'title' => 'Whole-School Topper',
            'examNames' => $examNames,
            'examName' => $examName,
            'eligibleClasses' => ExamModel::schoolTopperClassNames(),
            'exams' => $data['exams'],
            'toppers' => $data['toppers'],
        ]);
    }

    /**
     * RESULT — POSITION HOLDERS SUMMARY.
     *
     * One page for a chosen exam name: the whole-school topper (classes 5th–8th
     * combined) up top, then every class's own 1st/2nd/3rd position holders below it,
     * senior class first (12th/2nd Year down to Nursery), grouped by class the same
     * way classes are actually named in the database (so streams such as "12th
     * Science" / "12th Arts" stay separate, and classes that don't exist are simply
     * never shown — nothing here is hard-coded). Reuses the same ranking/tie-break
     * logic already used for the School Topper page and the bulk results workbook
     * (ExamModel::classRankings() / ExamModel::schoolTopper()), so a mark entered or
     * changed by an admin is reflected here automatically, with no separate
     * "position" data to maintain.
     */
    public function positionHoldersAction(): void
    {
        require_once __DIR__ . '/../models/ExamModel.php';

        Auth::requireLogin();
        $this->requirePermission(['academic.view', 'academic.manage', 'academic.school_topper']);

        $canSeeUnpublished = $this->canSeeUnpublishedResults();
        $examRows = $canSeeUnpublished ? ExamModel::allExamNamesIncludingUnpublished() : ExamModel::allPublishedExamNames();
        $examNames = array_map(static fn($r) => $r['exam_name'], $examRows);

        $examName = trim((string)($_GET['exam_name'] ?? ''));
        if ($examName === '' || !in_array($examName, $examNames, true)) {
            $examName = $examNames[0] ?? '';
        }

        $schoolTopperData = $examName !== '' ? ExamModel::schoolTopper($examName, $canSeeUnpublished) : ['exams' => [], 'toppers' => []];

        // Group each class_section's position holders under its class name (senior
        // class first), preserving separate streams/sections exactly as configured
        // under Academic → Classes & Sections — nothing here assumes a fixed list.
        $classGroups = [];
        if ($examName !== '') {
            $exams = $this->sortExamsBySeniority(ExamModel::examsForName($examName, $canSeeUnpublished));
            foreach ($exams as $ex) {
                $className = (string)($ex['class_name'] ?? '');
                if ($className === '') {
                    continue;
                }
                if (!isset($classGroups[$className])) {
                    $classGroups[$className] = [
                        'class_name' => $className,
                        'sections' => [],
                    ];
                }
                $classGroups[$className]['sections'][] = [
                    'exam_id' => (int)$ex['id'],
                    'section_name' => (string)($ex['section_name'] ?? ''),
                    'results_published' => (int)($ex['results_published'] ?? 0) === 1,
                    'rankings' => ExamModel::classRankings((int)$ex['id']),
                ];
            }
        }

        $this->render('academic/position_holders', [
            'title' => 'Result — Position Holders Summary',
            'examNames' => $examNames,
            'examName' => $examName,
            'eligibleClasses' => ExamModel::schoolTopperClassNames(),
            'schoolToppers' => $schoolTopperData['toppers'],
            'classGroups' => array_values($classGroups),
        ]);
    }

    /**
     * Full class result — one class_section's exam, every subject, every student,
     * with position holders highlighted. Linked from the Position Holders Summary
     * page ("View full class result"). Subject columns come entirely from
     * ExamModel::subjectListForExam() — a class with 5 subjects shows 5, a class
     * with 7 shows 7, nothing is hard-coded.
     */
    public function classResultAction(): void
    {
        require_once __DIR__ . '/../models/ExamModel.php';

        Auth::requireLogin();
        $this->requirePermission(['academic.view', 'academic.manage', 'academic.school_topper']);

        $examId = (int)($_GET['exam_id'] ?? 0);
        $exam = $examId > 0 ? ExamModel::getExam($examId) : null;

        if (!$exam) {
            http_response_code(404);
            require __DIR__ . '/../views/errors/404.php';
            return;
        }

        // Admin, or a role explicitly granted 'academic.unpublished_results'
        // (e.g. a "Result Admin" role), may preview a class result before
        // it's officially published — same rule the bulk export tools use.
        if ((int)($exam['results_published'] ?? 0) !== 1 && !$this->canSeeUnpublishedResults()) {
            http_response_code(403);
            require __DIR__ . '/../views/errors/403.php';
            return;
        }

        $pool = ExamModel::examStudentPool($examId); // everyone, pass and fail
        $rankByStudent = [];
        foreach (ExamModel::classRankings($examId) as $r) {
            $rankByStudent[(int)$r['student_id']] = (int)$r['rank'];
        }
        usort($pool, static function ($a, $b) {
            $byPct = $b['percentage'] <=> $a['percentage'];
            if ($byPct !== 0) {
                return $byPct;
            }
            return $b['total_obtained'] <=> $a['total_obtained'];
        });

        $subjects = ExamModel::subjectListForExam($examId);
        $ownMarksByStudent = ExamModel::ownMarksGroupedByStudent($examId);

        $this->render('academic/class_result', [
            'title' => trim('Class Result — ' . ($exam['class_name'] ?? '') . ' ' . ($exam['section_name'] ?? '')),
            'exam' => $exam,
            'subjects' => $subjects,
            'pool' => $pool,
            'rankByStudent' => $rankByStudent,
            'ownMarksByStudent' => $ownMarksByStudent,
        ]);
    }

    /** Picker page for the bulk exports below (report cards ZIP, results workbook, CSV). */
    public function bulkExportsAction(): void
    {
        require_once __DIR__ . '/../models/ExamModel.php';

        Auth::requireLogin();
        $this->requirePermission('academic.bulk_export');

        // Only Admin may pick draft/unpublished exams here — everyone else
        // (even with the academic.bulk_export permission, and even with
        // 'academic.unpublished_results') is limited to results that are
        // already published. Unpublished results must never be visible or
        // downloadable, in any of the three bulk formats, to anyone but Admin.
        $canSeeUnpublished = $this->canBulkExportUnpublished();
        $examRows = $canSeeUnpublished ? ExamModel::allExamNamesIncludingUnpublished() : ExamModel::allPublishedExamNames();
        $examNames = array_map(static fn($r) => $r['exam_name'], $examRows);
        $academicYears = Database::fetchAll('SELECT id, academic_year_label FROM academic_years ORDER BY academic_year_label DESC');
        $classes = Database::fetchAll('SELECT id, name FROM classes ORDER BY id ASC');

        $this->render('academic/bulk_exports', [
            'title' => 'Bulk Exports',
            'examNames' => $examNames,
            'academicYears' => $academicYears,
            'classes' => $classes,
            'isAdmin' => RBAC::isAdmin(),
            'canSeeUnpublished' => $canSeeUnpublished,
        ]);
    }

    /** School branding (name + logo) used on printed report cards. */
    /**
     * Sends a file already on disk (a ZIP built via ZipArchive, etc.) as a
     * download and exits. Centralizes three things bulk exports got bitten by:
     *   - Any stray output already buffered (a PHP notice/warning printed
     *     before this point, a BOM, whitespace outside a <?php tag somewhere
     *     in the include chain) gets discarded before headers are sent, so it
     *     can never land inside the file bytes and corrupt the archive.
     *   - PHP's zlib output compression (and mod_deflate/mod_gzip if the
     *     webserver applies it based on Content-Type) is turned off for this
     *     response. A ZIP/XLSX is already compressed; gzip-ing it again on
     *     top, AFTER we've already told the client the exact uncompressed
     *     Content-Length, is the classic cause of a download that completes
     *     "successfully" but the client rejects it as corrupt — plain
     *     desktop browsers are lenient about this, but an embedded WebView's
     *     download/file-viewer (the "wrap" apps some schools use) generally
     *     is not.
     *   - Content-Length is always sent, computed from the real file on disk.
     */
    private function streamDownloadFile(string $path, string $contentType, string $filename, bool $unlinkAfter = true): void
    {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        if (function_exists('apache_setenv')) {
            @apache_setenv('no-gzip', '1');
        }
        @ini_set('zlib.output_compression', '0');

        header('Content-Type: ' . $contentType);
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($path));
        header('Content-Encoding: identity');
        header('X-Content-Type-Options: nosniff');
        readfile($path);
        if ($unlinkAfter) {
            unlink($path);
        }
        exit;
    }

    /** Same guarantees as streamDownloadFile(), for content already built in memory (e.g. the XLS workbook string). */
    private function streamDownloadString(string $content, string $contentType, string $filename): void
    {
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        if (function_exists('apache_setenv')) {
            @apache_setenv('no-gzip', '1');
        }
        @ini_set('zlib.output_compression', '0');

        header('Content-Type: ' . $contentType);
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($content));
        header('Content-Encoding: identity');
        header('X-Content-Type-Options: nosniff');
        echo $content;
        exit;
    }

    private function schoolBranding(): array
    {
        $name = 'ARC School';
        $logo = '';
        try {
            $rows = Database::fetchAll('SELECT `key`, `value` FROM settings');
            $map = [];
            foreach ($rows as $r) {
                $map[$r['key']] = $r['value'];
            }
            $name = $map['branding_school_name'] ?? $map['institute_name'] ?? 'ARC School';
            $logo = $map['branding_logo_path'] ?? '';
        } catch (Throwable $e) {
            // Keep the defaults if settings can't be read.
        }
        return [$name, $logo];
    }

    /**
     * Printable Admission Form — one click from the Academic menu, pre-filled with the
     * school's own branding, contact details, and live class/section list, ready to
     * print or save as PDF. No data is submitted anywhere; it's a blank/fillable
     * paper-workflow form, matching how ID Cards / Report Cards already work here.
     */
    public function admissionFormAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['academic.view', 'academic.manage']);

        $settingsMap = [];
        try {
            foreach (Database::fetchAll('SELECT `key`, `value` FROM settings') as $r) {
                $settingsMap[(string)$r['key']] = (string)$r['value'];
            }
        } catch (Throwable $e) {
            // Keep rendering with defaults even if settings can't be read.
        }

        $schoolName = $settingsMap['branding_school_name'] ?? $settingsMap['institute_name'] ?? 'School';
        $logoPath = $settingsMap['branding_logo_path'] ?? '';
        $address = $settingsMap['institute_address'] ?? '';
        $contact = $settingsMap['institute_contact'] ?? '';
        $email = $settingsMap['mail_from_email'] ?? '';
        $academicYear = $settingsMap['academic_year_active'] ?? (string)date('Y');

        $classes = [];
        try {
            $classes = Database::fetchAll('SELECT id, name FROM classes ORDER BY id ASC');
        } catch (Throwable $e) {
            // Leave the dropdown empty if the classes table can't be read.
        }

        $sections = [];
        try {
            $sections = Database::fetchAll('SELECT id, name FROM sections ORDER BY id ASC');
        } catch (Throwable $e) {
            // Leave the dropdown empty if the sections table can't be read.
        }

        $this->render('academic/admission_form', [
            'title' => 'Admission Form',
            'schoolName' => $schoolName,
            'logoUrl' => $logoPath !== '' ? base_url($logoPath) : '',
            'address' => $address,
            'contact' => $contact,
            'email' => $email,
            'academicYear' => $academicYear,
            'classes' => $classes,
            'sections' => $sections,
        ]);
    }

    /**
     * Validates the exam_names[]/exam_name request param against the allowed exam name
     * list. Only Admin is allowed to select draft/unpublished exams here; every other
     * role is restricted to published exams only, even if they hold academic.bulk_export
     * or academic.unpublished_results — unpublished results must never be reachable
     * through bulk export (CSV, ZIP, or Excel) outside Admin.
     */
    private function selectedExamNamesFromRequest(): array
    {
        require_once __DIR__ . '/../models/ExamModel.php';

        $examRows = $this->canBulkExportUnpublished() ? ExamModel::allExamNamesIncludingUnpublished() : ExamModel::allPublishedExamNames();
        $allExamNames = array_map(static fn($r) => $r['exam_name'], $examRows);

        // Accept either exam_names[]=A&exam_names[]=B (checkbox list) or the
        // older single exam_name= param, for backward-compatible links.
        $requested = $_GET['exam_names'] ?? ($_GET['exam_name'] ?? []);
        if (!is_array($requested)) {
            $requested = [$requested];
        }
        $requested = array_map('trim', $requested);

        return array_values(array_intersect($allExamNames, $requested));
    }

    /** Reads a request param that's a list of ids (e.g. academic_year_ids[], class_ids[]) as ints. Empty = "no filter, include all". */
    private function selectedIdsFromRequest(string $param): array
    {
        $requested = $_GET[$param] ?? [];
        if (!is_array($requested)) {
            $requested = [$requested];
        }
        return array_values(array_unique(array_filter(array_map('intval', $requested))));
    }

    /**
     * Downloads a ZIP of every student's report card, as standalone HTML files,
     * for one or more selected exam names — optionally narrowed to selected
     * academic year(s) and/or class(es) — organised as:
     * Academic Year / Exam Name / Class - Section / Student (Admission No) - <label>.html
     */
    public function bulkReportCardsDownloadAction(): void
    {
        // Capture the whole request in one output buffer from the very first line —
        // streamDownloadFile() below drains and discards any buffer right before it
        // sends headers, so this guarantees a stray PHP notice/warning fired anywhere
        // during data-gathering below gets swallowed instead of being echoed straight
        // to the client (ahead of the real ZIP bytes), which is exactly what turns a
        // perfectly good file into "appears to be corrupted" on a strict mobile viewer.
        ob_start();

        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/ExamModel.php';

        Auth::requireLoginOrToken();
        $this->requirePermission('academic.bulk_export');

        $selectedExamNames = $this->selectedExamNamesFromRequest();
        $selectedAcademicYearIds = $this->selectedIdsFromRequest('academic_year_ids');
        $selectedClassIds = $this->selectedIdsFromRequest('class_ids');

        if (empty($selectedExamNames)) {
            http_response_code(400);
            echo 'No exams selected, or the selected exam(s) are unknown/unpublished.';
            return;
        }

        if (!class_exists('ZipArchive')) {
            http_response_code(500);
            echo 'The PHP zip extension is not enabled on this server, so a ZIP file cannot be built. Ask your host to enable ext-zip.';
            return;
        }

        [$schoolName, $logoPath] = $this->schoolBranding();
        $logoAbsolute = $logoPath ? base_url($logoPath) : '';

        $tmpZip = tempnam(sys_get_temp_dir(), 'akps_report_cards_');
        $zip = new ZipArchive();
        $zip->open($tmpZip, ZipArchive::OVERWRITE);

        $anyExamHadSections = false;
        // Guards against writing the same (exam, mode, student) report twice —
        // e.g. First Term gets written once as "combined exam's source" even
        // if First Term was ALSO separately checked in the exam picker.
        $written = [];

        // One HTML report card, added under $folderPath/<Student (Admission No)>[ - <label>].html.
        // $mode: 'full' (this exam's real result — combined total if it's a
        // combined exam, otherwise its only result — WITH position/topper),
        // 'own' (this exam's own marks only, no combination, no position —
        // used for a combined exam's own-term file).
        $addReportCard = function (string $folderPath, ?string $label, int $examId, int $studentId, array $student, string $examLabel, string $mode) use (&$written, $zip, $schoolName, $logoAbsolute) {
            $key = $examId . '|' . $mode . '|' . $studentId;
            if (isset($written[$key])) {
                return;
            }
            $written[$key] = true;

            $card = ExamModel::studentReportCard($studentId, $examId, $mode === 'own', $this->canBulkExportUnpublished());
            $html = $this->renderPartial('academic/_report_card_print', [
                'student' => $student,
                'examName' => $examLabel,
                'card' => $card,
                'schoolName' => $schoolName,
                'logoPath' => $logoAbsolute,
            ]);

            $studentLabel = trim($student['first_name'] . ' ' . $student['last_name']) . ' (' . ($student['admission_no'] ?: $studentId) . ')';
            $fileName = $label !== null ? $studentLabel . ' - ' . $label : $studentLabel;
            $zip->addFromString($folderPath . '/' . safe_filename($fileName) . '.html', $html);
        };

        // Report Cards ZIP: unpublished/draft results are Admin-only here — same
        // as the CSV and Excel workbook exports below. Nobody but Admin can ever
        // download or see a report before it's published.
        foreach ($selectedExamNames as $examName) {
            $exams = ExamModel::examsForName($examName, $this->canBulkExportUnpublished());
            if (empty($exams)) {
                continue;
            }

            foreach ($exams as $ex) {
                // Apply the optional academic year / class filters.
                if (!empty($selectedAcademicYearIds) && !in_array((int)($ex['academic_year_id'] ?? 0), $selectedAcademicYearIds, true)) {
                    continue;
                }
                if (!empty($selectedClassIds) && !in_array((int)($ex['class_id'] ?? 0), $selectedClassIds, true)) {
                    continue;
                }
                $anyExamHadSections = true;

                $examId = (int)$ex['id'];
                $academicYearLabel = trim((string)($ex['academic_year_label'] ?? '')) ?: 'No Academic Year';
                $className = trim((string)($ex['class_name'] ?? ''));
                $sectionName = trim((string)($ex['section_name'] ?? ''));
                $classLabel = $sectionName !== '' ? $className . ' - ' . $sectionName : ($className ?: 'No Class');
                $sourceBase = trim((string)($ex['cumulative_source_exam_name'] ?? ''));
                $sourceExamId = $sourceBase !== '' ? ExamModel::resolveCumulativeSourceExamId($ex) : null;
                $sourceExam = $sourceExamId ? ExamModel::getExam($sourceExamId) : null;

                // Academic Year / Exam Name / Class - Section
                $classFolder = safe_filename($academicYearLabel) . '/' . safe_filename($examName) . '/' . safe_filename($classLabel);

                foreach (ExamModel::examStudentPool($examId) as $st) {
                    $studentId = (int)$st['student_id'];
                    $student = StudentModel::getById($studentId);
                    if (!$student) {
                        continue;
                    }

                    if ($sourceExam) {
                        // Combined exam (e.g. Final Term = First Term + Final Term):
                        // three HTML files per student — the source exam's own standalone
                        // report, this exam's own marks only, and the actual combined result.
                        $addReportCard($classFolder, (string)$sourceExam['exam_name'], $sourceExamId, $studentId, $student, (string)$sourceExam['exam_name'], 'full');
                        $addReportCard($classFolder, $examName . ' (Own)', $examId, $studentId, $student, $examName, 'own');
                        $addReportCard($classFolder, 'Total Result', $examId, $studentId, $student, $examName, 'full');
                    } else {
                        // Standalone exam — one HTML file, that's the whole result.
                        $addReportCard($classFolder, null, $examId, $studentId, $student, $examName, 'full');
                    }
                }
            }
        }

        if (!$anyExamHadSections) {
            $zip->close();
            unlink($tmpZip);
            http_response_code(404);
            echo 'No sections found for the selected exam(s), academic year(s), and class(es).';
            return;
        }

        $zip->close();

        $filename = count($selectedExamNames) === 1
            ? safe_filename('Report Cards - ' . $selectedExamNames[0]) . '.zip'
            : safe_filename('Report Cards - ' . count($selectedExamNames) . ' Exams') . '.zip';

        $this->streamDownloadFile($tmpZip, 'application/zip', $filename);
    }

    /**
     * Downloads one real .xlsx workbook (raw OOXML via ZipArchive, no
     * Composer/PhpSpreadsheet needed — see XlsxWorkbookWriter) for one or more
     * selected exam names: an overall Summary sheet (each exam's school topper +
     * each class's position holders, grouped by exam) plus one full-detail
     * sheet per exam/class/section.
     */
    public function bulkResultsXlsDownloadAction(): void
    {
        // See the matching comment in bulkReportCardsDownloadAction() — this catches
        // any stray warning/notice text before it can corrupt the .xlsx bytes; the
        // buffer is drained and discarded by XlsxWorkbookWriter::download() below.
        ob_start();

        require_once __DIR__ . '/../models/ExamModel.php';

        Auth::requireLoginOrToken();
        $this->requirePermission('academic.bulk_export');

        $selectedExamNames = $this->selectedExamNamesFromRequest();

        if (empty($selectedExamNames)) {
            http_response_code(400);
            echo 'No exams selected, or the selected exam(s) are unknown/unpublished.';
            return;
        }

        $workbook = $this->buildResultsWorkbook($selectedExamNames);

        // Diagnostic-only: appending &plain=1 to this download's URL strips every
        // color/merge/custom style out of the .xlsx (keeping the same data/sheets)
        // to test whether a mobile viewer that rejects the normal file will open a
        // bare-bones one — narrows down whether the problem is in the formatting
        // or somewhere else entirely (e.g. the file never actually reaching the
        // device intact). Remove this block once that's been confirmed either way.
        if (($_GET['plain'] ?? '') === '1') {
            $workbook->setPlainMode(true);
        }

        $filename = count($selectedExamNames) === 1
            ? safe_filename('Results - ' . $selectedExamNames[0]) . '.xlsx'
            : safe_filename('Results - ' . count($selectedExamNames) . ' Exams') . '.xlsx';

        $workbook->download($filename);
    }

    /**
     * Downloads a ZIP of separate CSV files for one or more selected exam names —
     * a real .csv file cannot contain multiple "sheets", so a true "separate sheet
     * per class" layout means separate CSV files, bundled together:
     *   - "00 - School & Class Toppers.csv" — the whole-school topper (classes
     *     5th–8th only, always exactly one student) then every class's own
     *     1st/2nd/3rd, senior class first.
     *   - One "<N> - <Class> - <Section>.csv" file per class/section after that,
     *     numbered in seniority order (2nd Year, then 1st Year, then 10th, ...
     *     down to Nursery) so they sort correctly once extracted — each with a
     *     column per subject (same breakdown as the Excel workbook), not just
     *     the total obtained.
     */
    public function bulkResultsCsvDownloadAction(): void
    {
        // See the matching comment in bulkReportCardsDownloadAction() — this catches
        // any stray warning/notice text before it can corrupt the ZIP bytes; the
        // buffer is drained and discarded by streamDownloadFile() below.
        ob_start();

        require_once __DIR__ . '/../models/ExamModel.php';

        Auth::requireLoginOrToken();
        $this->requirePermission('academic.bulk_export');

        $selectedExamNames = $this->selectedExamNamesFromRequest();

        if (empty($selectedExamNames)) {
            http_response_code(400);
            echo 'No exams selected, or the selected exam(s) are unknown/unpublished.';
            return;
        }

        if (!class_exists('ZipArchive')) {
            http_response_code(500);
            echo 'The PHP zip extension is not enabled on this server, so a ZIP file cannot be built. Ask your host to enable ext-zip.';
            return;
        }

        // CSV export: same Admin-only rule for drafts as the Report Cards ZIP and
        // Excel workbook — nobody but Admin can ever see/download a report before
        // it's published, regardless of role or granted permissions.
        $canSeeDrafts = $this->canBulkExportUnpublished();

        // examName => exams-for-that-name, senior class first — computed once,
        // reused for both the toppers file and the per-class detail files below.
        $examsByName = [];
        foreach ($selectedExamNames as $examName) {
            $examsByName[$examName] = $this->sortExamsBySeniority(ExamModel::examsForName($examName, $canSeeDrafts));
        }

        $csvString = static function (array $rows): string {
            $buf = fopen('php://temp', 'w+');
            fwrite($buf, "\xEF\xBB\xBF"); // UTF-8 BOM so Excel opens accented / non-Latin names correctly.
            foreach ($rows as $r) {
                fputcsv($buf, $r);
            }
            rewind($buf);
            $out = stream_get_contents($buf);
            fclose($buf);
            return $out;
        };
        // Admission No gets Excel "force text" treatment instead of the usual
        // formula-injection guard — it's a system-generated value (never free
        // user text), so an all-digit admission number is safe to wrap this
        // way, and it stops Excel mangling it into scientific notation.
        $safeRow = static function (array $rowValues, int $admissionNoIndex = -1): array {
            $safe = [];
            foreach ($rowValues as $i => $v) {
                $safe[] = $i === $admissionNoIndex ? csv_force_text($v) : csv_safe($v);
            }
            return $safe;
        };

        $tmpZip = tempnam(sys_get_temp_dir(), 'akps_results_csv_');
        $zip = new ZipArchive();
        $zip->open($tmpZip, ZipArchive::OVERWRITE);

        // ---- File 1: School Topper & Class Toppers (mirrors Sheet 1 of the Excel workbook) ----
        $topperRows = [];
        $topperRows[] = ['SCHOOL TOPPER & CLASS TOPPERS — ' . implode(', ', $selectedExamNames)];
        $topperRows[] = [''];

        foreach ($selectedExamNames as $examName) {
            $exams = $examsByName[$examName];
            if (count($selectedExamNames) > 1) {
                $topperRows[] = ['EXAM: ' . $examName];
            }

            // Whole-school topper first — classes 5th–8th only, always exactly one student.
            $schoolTopperData = ExamModel::schoolTopper($examName, $canSeeDrafts);
            $schoolTopper = $schoolTopperData['toppers'][0] ?? null;

            $topperRows[] = ['School Topper (Classes 5th–8th) — ' . $examName];
            if ($schoolTopper === null) {
                $topperRows[] = ['No passing student found across classes 5th–8th for this exam.'];
            } else {
                $topperRows[] = ['Student', 'Father Name', 'Class', 'Section', 'Admission No', 'Marks Obtained', 'Total Marks', 'Percentage'];
                $topperRows[] = $safeRow([
                    $schoolTopper['name'],
                    $schoolTopper['father_name'] ?? '',
                    $schoolTopper['class_name'] ?? '',
                    $schoolTopper['section_name'] ?? '',
                    $schoolTopper['admission_no'] ?? '',
                    format_mark($schoolTopper['total_obtained']),
                    format_mark($schoolTopper['total_max']),
                    round((float)$schoolTopper['percentage'], 2),
                ], 4);
            }
            $topperRows[] = [''];

            // Then every class's own 1st/2nd/3rd, senior class first.
            foreach ($exams as $ex) {
                $examId = (int)$ex['id'];
                $topperRows[] = ['Class ' . ($ex['class_name'] ?? '') . ' - ' . ($ex['section_name'] ?? '') . ' Toppers'];

                $ranked = ExamModel::classRankings($examId); // PASS-only, rank 1–3, ties included
                if (empty($ranked)) {
                    $topperRows[] = ['No position holders (no passing students).'];
                } else {
                    $topperRows[] = ['Position', 'Name', 'Father Name', 'Percentage', 'Marks'];
                    foreach ($ranked as $r) {
                        $topperRows[] = $safeRow([
                            ordinal((int)$r['rank']),
                            $r['name'],
                            $r['father_name'] ?? '',
                            round($r['percentage'], 2),
                            format_mark($r['total_obtained']) . ' / ' . format_mark($r['total_max']),
                        ]);
                    }
                }
                $topperRows[] = [''];
            }
        }
        $zip->addFromString('00 - School & Class Toppers.csv', $csvString($topperRows));

        // ---- File 2+: one CSV per class/section, senior class first, with a column
        // per subject (same breakdown as the Excel workbook's per-class sheet) —
        // never merged together into one flat list. ----
        $fileNum = 1;
        foreach ($selectedExamNames as $examName) {
            $exams = $examsByName[$examName];
            $examPrefix = count($selectedExamNames) > 1 ? ($examName . ' — ') : '';

            foreach ($exams as $ex) {
                $examId = (int)$ex['id'];
                $pool = ExamModel::examStudentPool($examId); // everyone, pass and fail
                $rankByStudent = [];
                foreach (ExamModel::classRankings($examId) as $r) {
                    $rankByStudent[(int)$r['student_id']] = (int)$r['rank'];
                }
                usort($pool, static function ($a, $b) {
                    return $b['percentage'] <=> $a['percentage'];
                });

                // This exam's own subjects (stable, alphabetical order) and each
                // student's own per-subject marks — the per-subject columns below.
                $subjects = ExamModel::subjectListForExam($examId);
                $ownMarksByStudent = ExamModel::ownMarksGroupedByStudent($examId);

                // For a combined exam (e.g. Final Term = First Term + Final Term),
                // also total up the prior term's marks and this exam's own marks on
                // their own, per student and per subject, so the file can show
                // "Prior Term + This Exam = Final Result" side by side — not just
                // the already-added-together final number. Same logic as the Excel workbook.
                $sourceBase = trim((string)($ex['cumulative_source_exam_name'] ?? ''));
                $sourceExamId = $sourceBase !== '' ? ExamModel::resolveCumulativeSourceExamId($ex) : null;
                $priorTotals = [];
                $ownTotals = [];
                $combinedMarksByStudent = [];
                if ($sourceExamId) {
                    foreach (ExamModel::examStudentPool($sourceExamId) as $r) {
                        $priorTotals[(int)$r['student_id']] = $r['total_obtained'];
                    }
                    foreach (ExamModel::examStudentPool($examId, true) as $r) {
                        $ownTotals[(int)$r['student_id']] = $r['total_obtained'];
                    }
                    $combinedMarksByStudent = ExamModel::effectiveMarksForExam($examId);
                }

                $header = ['Position', 'Name', 'Father Name', 'Admission No'];
                foreach ($subjects as $subj) {
                    $header[] = $subj['name'] . ' (' . format_mark($subj['total_marks']) . ')';
                }
                $header = array_merge($header, ['Total Obtained', 'Total Marks', 'Percentage', 'Result']);
                if ($sourceExamId) {
                    $header = array_merge($header, ['Combined With', 'Prior Term Marks', 'This Exam Marks (Own)']);
                    foreach ($subjects as $subj) {
                        $header[] = $subj['name'] . ' (Combined)';
                    }
                    $header[] = 'Final Result Marks (Combined)';
                }

                $classRows = [$header];
                foreach ($pool as $st) {
                    $sid = (int)$st['student_id'];
                    $pos = isset($rankByStudent[$sid]) ? ordinal($rankByStudent[$sid]) : '';

                    $rowValues = [$pos, $st['name'], $st['father_name'] ?? '', $st['admission_no'] ?? ''];
                    foreach ($subjects as $subj) {
                        $subId = (int)$subj['id'];
                        $score = $ownMarksByStudent[$sid][$subId]['score'] ?? null;
                        $rowValues[] = $score !== null ? format_mark($score) : '';
                    }
                    $rowValues = array_merge($rowValues, [
                        format_mark($st['total_obtained']), format_mark($st['total_max']),
                        round((float)$st['percentage'], 2), $st['result'],
                    ]);

                    if ($sourceExamId) {
                        $rowValues[] = $sourceBase;
                        $rowValues[] = isset($priorTotals[$sid]) ? format_mark($priorTotals[$sid]) : '';
                        $rowValues[] = isset($ownTotals[$sid]) ? format_mark($ownTotals[$sid]) : '';
                        foreach ($subjects as $subj) {
                            $subId = (int)$subj['id'];
                            $combinedScore = $combinedMarksByStudent[$sid][$subId]['score'] ?? null;
                            $rowValues[] = $combinedScore !== null ? format_mark($combinedScore) : '';
                        }
                        $rowValues[] = format_mark($st['total_obtained']); // final/combined total — examStudentPool() already uses effective marks
                    }

                    // Admission No is column index 3 in every row shape above (Position, Name, Father Name, Admission No).
                    $classRows[] = $safeRow($rowValues, 3);
                }

                $label = $examPrefix . ($ex['class_name'] ?? '') . ' - ' . ($ex['section_name'] ?? '');
                $fileName = sprintf('%02d', $fileNum) . ' - ' . safe_filename($label) . '.csv';
                $zip->addFromString($fileName, $csvString($classRows));
                $fileNum++;
            }
        }

        $zip->close();

        $filename = count($selectedExamNames) === 1
            ? safe_filename('Results CSV - ' . $selectedExamNames[0]) . '.zip'
            : safe_filename('Results CSV - ' . count($selectedExamNames) . ' Exams') . '.zip';

        $this->streamDownloadFile($tmpZip, 'application/zip', $filename);
    }

    /**
     * Best-effort "how senior is this class" rank used only to order the results
     * workbook (highest class first: 12th/2nd Year, 11th/1st Year, 10th, ... down to
     * Nursery/Prep). Class names are free text set up by the school, so this reads
     * common patterns (a leading number, "1st/2nd Year", or a number word) rather
     * than assuming a fixed list of names. Unrecognised class names sort last.
     */
    private function classSortRank(string $className): int
    {
        $name = trim($className);
        if ($name === '') {
            return -1;
        }

        // Intermediate-style naming: "1st Year Science", "2nd Year Arts", etc.
        if (preg_match('/\b(2nd|second)\s*year\b/i', $name)) {
            return 12;
        }
        if (preg_match('/\b(1st|first)\s*year\b/i', $name)) {
            return 11;
        }

        // A digit anywhere in the name — "10th Science", "9th Arts", "3rd", "Class 8".
        if (preg_match('/(\d+)/', $name, $m)) {
            return (int)$m[1];
        }

        // Spelled-out class names.
        $wordRank = [
            'nursery' => 0, 'playgroup' => 0, 'play group' => 0, 'kg' => 0, 'kindergarten' => 0, 'prep' => 0,
            'one' => 1, 'two' => 2, 'three' => 3, 'four' => 4, 'five' => 5,
            'six' => 6, 'seven' => 7, 'eight' => 8, 'nine' => 9, 'ten' => 10,
        ];
        $lower = strtolower($name);
        foreach ($wordRank as $word => $rank) {
            if (preg_match('/\b' . preg_quote($word, '/') . '\b/i', $lower)) {
                return $rank;
            }
        }

        return -1; // unrecognised naming — push to the bottom
    }

    /**
     * "College level" = 9th class and above (9th, 10th, 1st/2nd Year, 11th,
     * 12th, ...) using the same classSortRank() used to order the workbook —
     * everything below that (Nursery through 8th, plus any unrecognised class
     * name) is "school level". Used to split the whole-school Result Summary
     * on the Position Holders sheet into its two parts.
     */
    private function isCollegeLevelClass(string $className): bool
    {
        return $this->classSortRank($className) >= 9;
    }

    /**
     * No. of Students Appeared/Passed/Failed and Result % from an exam's
     * student pool (as returned by ExamModel::examStudentPool()) — PASS and
     * PROMOTE both count as "passed" since both advance the student to the
     * next class, only FAIL counts against the percentage. Used for the
     * per-class Result Summary blocks and the whole-school summary on the
     * Position Holders sheet.
     */
    private function resultSummaryCounts(array $pool): array
    {
        $appeared = count($pool);
        $passed = 0;
        foreach ($pool as $st) {
            if ($st['result'] === 'PASS' || $st['result'] === 'PROMOTE') {
                $passed++;
            }
        }
        $failed = $appeared - $passed;
        return [
            'appeared' => $appeared,
            'passed' => $passed,
            'failed' => $failed,
            'percentage' => $appeared > 0 ? round($passed / $appeared * 100, 2) : 0.0,
        ];
    }

    /** Sorts a list of exam rows (each with class_name/section_name) senior class first, using classSortRank(). */
    private function sortExamsBySeniority(array $exams): array
    {
        usort($exams, function ($a, $b) {
            $rankA = $this->classSortRank((string)($a['class_name'] ?? ''));
            $rankB = $this->classSortRank((string)($b['class_name'] ?? ''));
            if ($rankA !== $rankB) {
                return $rankB <=> $rankA; // descending: senior class first
            }
            $classCmp = strcmp((string)($a['class_name'] ?? ''), (string)($b['class_name'] ?? ''));
            if ($classCmp !== 0) {
                return $classCmp;
            }
            return strcmp((string)($a['section_name'] ?? ''), (string)($b['section_name'] ?? ''));
        });
        return $exams;
    }

    /**
     * Builds the real .xlsx (OOXML) results workbook for bulkResultsXlsDownloadAction(),
     * across one or more exam names — a Summary sheet (each exam's school topper +
     * each class's position holders, senior class first) plus one full-detail sheet
     * per exam/class/section. Returns the writer fully populated; the caller streams
     * it via XlsxWorkbookWriter::download().
     *
     * (Previously this returned an "Excel 2003 XML" / SpreadsheetML string saved with
     * a .xls extension — desktop Excel opens that leniently, but it isn't a real
     * binary spreadsheet file, and strict mobile document viewers correctly flag the
     * mismatch as "corrupted". XlsxWorkbookWriter builds an actual OOXML zip archive
     * instead, so the bytes genuinely match the .xlsx extension.)
     */
    private function buildResultsWorkbook(array $examNames): XlsxWorkbookWriter
    {
        require_once __DIR__ . '/../services/XlsxWorkbookWriter.php';

        [$schoolName] = $this->schoolBranding();
        $generatedOn = date('d M Y, h:i A');
        $w = new XlsxWorkbookWriter();

        $gutter = XlsxWorkbookWriter::str('');
        $strCell = static fn($v, int $style = XlsxWorkbookWriter::STYLE_CELL) => XlsxWorkbookWriter::str((string)$v, $style);
        $numCell = static fn($v, int $style = XlsxWorkbookWriter::STYLE_CELL) => XlsxWorkbookWriter::num($v, $style);
        $percentCell = static fn($v) => XlsxWorkbookWriter::num($v, XlsxWorkbookWriter::STYLE_PERCENT);
        $positionCell = static fn($v) => XlsxWorkbookWriter::str((string)$v, XlsxWorkbookWriter::STYLE_POSITION);
        $headerCell = static fn($v) => XlsxWorkbookWriter::str((string)$v, XlsxWorkbookWriter::STYLE_HEADER);
        $resultCell = static function (string $result): array {
            $style = XlsxWorkbookWriter::STYLE_CELL;
            if ($result === 'PASS') {
                $style = XlsxWorkbookWriter::STYLE_RESULT_PASS;
            } elseif ($result === 'FAIL') {
                $style = XlsxWorkbookWriter::STYLE_RESULT_FAIL;
            } elseif ($result === 'PROMOTE') {
                $style = XlsxWorkbookWriter::STYLE_RESULT_PROMOTE;
            }
            return XlsxWorkbookWriter::str($result, $style);
        };
        // A merged banner cell spanning $span additional columns (title/section headers).
        $bannerCell = static fn(int $style, $v, int $span = 0) => XlsxWorkbookWriter::str((string)$v, $style, $span);

        // Writes one "RESULT SUMMARY" block (title banner, Appeared/Passed/Failed/
        // Percentage, then a Class Teacher Sign + Principal Sign line each) at the
        // current position in whichever sheet is currently open. Used both for each
        // class's own detail sheet and for the two whole-school parts on the
        // Position Holders sheet.
        $writeResultSummary = function (string $title, array $counts, int $span, int $rightOffset = 0) use ($w, $gutter, $bannerCell, $headerCell, $numCell, $percentCell, $strCell): void {
            $pad = array_fill(0, $rightOffset, $gutter);
            $w->addRow([$gutter, $bannerCell(XlsxWorkbookWriter::STYLE_SUBSECTION_HEADER, $title, $span)]);
            $w->addRow(array_merge([$gutter], $pad, [$headerCell('No. of Students Appeared'), $numCell($counts['appeared'])]));
            $w->addRow(array_merge([$gutter], $pad, [$headerCell('No. of Students Passed'), $numCell($counts['passed'])]));
            $w->addRow(array_merge([$gutter], $pad, [$headerCell('No. of Students Failed'), $numCell($counts['failed'])]));
            $w->addRow(array_merge([$gutter], $pad, [$headerCell('Result Percentage'), $percentCell($counts['percentage'])]));
            $w->addRow([$gutter]);
            $w->addRow(array_merge([$gutter], $pad, [$headerCell('Class Teacher Sign'), $strCell('_____________________________')]));
            $w->addRow(array_merge([$gutter], $pad, [$headerCell('Principal Sign'), $strCell('_____________________________')]));
            $w->addRow([$gutter]);
        };

        // ---- Sheet 1: "School & Class Toppers" — school banner, then the whole-school
        // topper (5th–8th, always exactly one student), then every class's own
        // 1st/2nd/3rd, senior class first (12th/2nd Year down to Nursery). ----
        $summaryColSpan = 6; // widest row on this sheet: Father Name/Class/Section/Marks Obtained/Total Marks/Percentage
        $w->addSheet('School & Class Toppers');
        $w->setColumnWidths(array_merge([18], array_fill(0, $summaryColSpan, 20)));
        $w->setFreezeRows(3);

        $w->addRow([$gutter, $bannerCell(XlsxWorkbookWriter::STYLE_TITLE_BANNER, $schoolName, $summaryColSpan)], 30);
        $w->addRow([$gutter, $bannerCell(XlsxWorkbookWriter::STYLE_SUBTITLE_BANNER, 'School Topper & Class Toppers — ' . implode(', ', $examNames) . '  |  Generated ' . $generatedOn, $summaryColSpan)], 20);
        $w->addRow([$gutter, $bannerCell(XlsxWorkbookWriter::STYLE_SPACER, '', $summaryColSpan)]);

        $allExams = []; // examName => exams-for-that-name (senior class first), kept for the per-class detail sheets below

        foreach ($examNames as $examName) {
            // Excel workbook: unpublished/draft results are Admin-only, same as
            // the CSV and ZIP exports — no permission can widen this.
            $exams = $this->sortExamsBySeniority(ExamModel::examsForName($examName, $this->canBulkExportUnpublished()));
            $allExams[$examName] = $exams;

            $w->addRow([$gutter, $bannerCell(XlsxWorkbookWriter::STYLE_SECTION_HEADER, 'EXAM: ' . $examName, $summaryColSpan)], 22);

            // School Topper first — whole-school recognition across classes 5th–8th only.
            $schoolTopperData = ExamModel::schoolTopper($examName, $this->canBulkExportUnpublished());
            $schoolTopper = $schoolTopperData['toppers'][0] ?? null;

            $w->addRow([$gutter, $bannerCell(XlsxWorkbookWriter::STYLE_SUBSECTION_HEADER, 'School Topper (Classes 5th–8th) — ' . $examName, $summaryColSpan)]);
            if ($schoolTopper === null) {
                $w->addRow([$gutter, $strCell('No passing student found across classes 5th–8th for this exam.')]);
            } else {
                // Topper's name on its own highlighted row, full details directly below it.
                $w->addRow([$gutter, $bannerCell(XlsxWorkbookWriter::STYLE_TOPPER_BANNER, '🏆  ' . $schoolTopper['name'], $summaryColSpan)], 22);
                $w->addRow([$gutter, $headerCell('Father Name'), $headerCell('Class'), $headerCell('Section'), $headerCell('Marks Obtained'), $headerCell('Total Marks'), $headerCell('Percentage')]);
                $w->addRow([
                    $gutter,
                    $strCell($schoolTopper['father_name'] ?? ''),
                    $strCell($schoolTopper['class_name'] ?? ''),
                    $strCell($schoolTopper['section_name'] ?? ''),
                    $numCell($schoolTopper['total_obtained']),
                    $numCell($schoolTopper['total_max']),
                    $percentCell(round($schoolTopper['percentage'], 2)),
                ]);
            }
            $w->addRow([$gutter]); // blank spacer row

            // Whole-school Result Summary, in two parts — College Level (9th class
            // and above) and School Level (Nursery to 8th) — each totalled from
            // every class's own student pool for this exam.
            $collegeCounts = ['appeared' => 0, 'passed' => 0, 'failed' => 0];
            $schoolCounts = ['appeared' => 0, 'passed' => 0, 'failed' => 0];
            foreach ($exams as $ex) {
                $c = $this->resultSummaryCounts(ExamModel::examStudentPool((int)$ex['id']));
                $isCollege = $this->isCollegeLevelClass((string)($ex['class_name'] ?? ''));
                $target = $isCollege ? 'collegeCounts' : 'schoolCounts';
                ${$target}['appeared'] += $c['appeared'];
                ${$target}['passed'] += $c['passed'];
                ${$target}['failed'] += $c['failed'];
            }
            $collegeCounts['percentage'] = $collegeCounts['appeared'] > 0 ? round($collegeCounts['passed'] / $collegeCounts['appeared'] * 100, 2) : 0.0;
            $schoolCounts['percentage'] = $schoolCounts['appeared'] > 0 ? round($schoolCounts['passed'] / $schoolCounts['appeared'] * 100, 2) : 0.0;

            $writeResultSummary('WHOLE SCHOOL RESULT SUMMARY — College Level (9th & Above) — ' . $examName, $collegeCounts, $summaryColSpan);
            $writeResultSummary('WHOLE SCHOOL RESULT SUMMARY — School Level (Nursery – 8th) — ' . $examName, $schoolCounts, $summaryColSpan);

            // Then every class's own 1st/2nd/3rd position holders, senior class first.
            foreach ($exams as $ex) {
                $examId = (int)$ex['id'];
                $label = 'Class ' . ($ex['class_name'] ?? '') . ' - ' . ($ex['section_name'] ?? '') . ' Position Holders';
                $w->addRow([$gutter, $bannerCell(XlsxWorkbookWriter::STYLE_SUBSECTION_HEADER, $label, $summaryColSpan)]);

                $ranked = ExamModel::classRankings($examId); // already PASS-only, rank 1-3, ties included
                if (empty($ranked)) {
                    $w->addRow([$gutter, $strCell('No position holders (no passing students).')]);
                } else {
                    $w->addRow([$gutter, $headerCell('Position'), $headerCell('Name'), $headerCell('Father Name'), $headerCell('Percentage'), $headerCell('Marks')]);
                    foreach ($ranked as $i => $r) {
                        $rowStyle = $i % 2 === 1 ? XlsxWorkbookWriter::STYLE_CELL_ALT : XlsxWorkbookWriter::STYLE_CELL;
                        $w->addRow([
                            $gutter,
                            $positionCell(ordinal((int)$r['rank'])),
                            $strCell($r['name'], $rowStyle),
                            $strCell($r['father_name'] ?? '', $rowStyle),
                            $numCell(round($r['percentage'], 2), $rowStyle),
                            $strCell(format_mark($r['total_obtained']) . ' / ' . format_mark($r['total_max']), $rowStyle),
                        ]);
                    }
                }
                $w->addRow([$gutter]);
            }

            $w->addRow([$gutter]); // extra spacer between exams
        }

        // ---- One full-detail sheet per exam/class/section (senior class first), with
        // a school banner, one column per subject alongside the totals, and colour-coded
        // Pass/Fail/Promote results — sheet name prefixed with the exam name. ----
        foreach ($examNames as $examName) {
            $exams = $allExams[$examName];
            $examPrefix = count($examNames) > 1 ? ($examName . ' - ') : '';

            foreach ($exams as $ex) {
                $examId = (int)$ex['id'];
                $pool = ExamModel::examStudentPool($examId); // everyone, pass and fail
                $rankByStudent = [];
                foreach (ExamModel::classRankings($examId) as $r) {
                    $rankByStudent[(int)$r['student_id']] = (int)$r['rank'];
                }
                usort($pool, static function ($a, $b) {
                    return $b['percentage'] <=> $a['percentage'];
                });

                // This exam's own subjects (in a stable, alphabetical order) and each
                // student's own per-subject marks — the per-subject columns below.
                $subjects = ExamModel::subjectListForExam($examId);
                $ownMarksByStudent = ExamModel::ownMarksGroupedByStudent($examId);

                // Same per-term breakdown as the CSV export — see bulkResultsCsvDownloadAction().
                $sourceBase = trim((string)($ex['cumulative_source_exam_name'] ?? ''));
                $sourceExamId = $sourceBase !== '' ? ExamModel::resolveCumulativeSourceExamId($ex) : null;
                $priorTotals = [];
                $ownTotals = [];
                $combinedMarksByStudent = [];
                if ($sourceExamId) {
                    foreach (ExamModel::examStudentPool($sourceExamId) as $r) {
                        $priorTotals[(int)$r['student_id']] = $r['total_obtained'];
                    }
                    foreach (ExamModel::examStudentPool($examId, true) as $r) {
                        $ownTotals[(int)$r['student_id']] = $r['total_obtained'];
                    }
                    // Combined (own + prior term) marks per subject — the "(Combined)" columns below.
                    $combinedMarksByStudent = ExamModel::effectiveMarksForExam($examId);
                }

                $colCount = 4 + count($subjects) + 4;
                if ($sourceExamId) {
                    $colCount += 3 + count($subjects) + 1;
                }

                $className = trim((string)($ex['class_name'] ?? ''));
                $sectionName = trim((string)($ex['section_name'] ?? ''));
                $classLabel = $sectionName !== '' ? $className . ' - ' . $sectionName : $className;

                $label = $examPrefix . $classLabel;
                $w->addSheet($label);
                $colWidths = array_fill(0, $colCount, 16);
                $colWidths[0] = 42; // Name gets more room
                $colWidths[1] = 32; // Father Name gets more room too
                $colWidths[$colCount - 2] = 42; // second-to-last column also hosts the Result Summary labels below
                $colWidths[$colCount - 1] = 22; // Position (now last) also hosts the Result Summary values below
                $w->setColumnWidths(array_merge([18], $colWidths));
                $w->setFreezeRows(4);

                $w->addRow([$gutter, $bannerCell(XlsxWorkbookWriter::STYLE_TITLE_BANNER, $schoolName, $colCount - 1)], 30);
                $w->addRow([$gutter, $bannerCell(XlsxWorkbookWriter::STYLE_SUBTITLE_BANNER, trim($examPrefix, ' -') . ' — ' . $classLabel . ' — Result Sheet  |  Generated ' . $generatedOn, $colCount - 1)], 20);
                $w->addRow([$gutter, $bannerCell(XlsxWorkbookWriter::STYLE_SPACER, '', $colCount - 1)]);

                $headerRow = [$gutter, $headerCell('Name'), $headerCell('Father Name'), $headerCell('Admission No')];
                foreach ($subjects as $subj) {
                    $headerRow[] = $headerCell($subj['name'] . ' (' . format_mark($subj['total_marks']) . ')');
                }
                $headerRow[] = $headerCell('Total Obtained');
                $headerRow[] = $headerCell('Total Marks');
                $headerRow[] = $headerCell('Percentage');
                $headerRow[] = $headerCell('Result');
                if ($sourceExamId) {
                    $headerRow[] = $headerCell('Combined With');
                    $headerRow[] = $headerCell('Prior Term Marks');
                    $headerRow[] = $headerCell('This Exam Marks (Own)');
                    foreach ($subjects as $subj) {
                        $headerRow[] = $headerCell($subj['name'] . ' (Combined)');
                    }
                    $headerRow[] = $headerCell('Final Result Marks (Combined)');
                }
                $headerRow[] = $headerCell('Position'); // last column
                $w->addRow($headerRow);

                foreach ($pool as $i => $st) {
                    $sid = (int)$st['student_id'];
                    $pos = isset($rankByStudent[$sid]) ? ordinal($rankByStudent[$sid]) : '';
                    $rowStyle = $i % 2 === 1 ? XlsxWorkbookWriter::STYLE_CELL_ALT : XlsxWorkbookWriter::STYLE_CELL;

                    $dataRow = [$gutter, $strCell($st['name'], $rowStyle), $strCell((string)($st['father_name'] ?? ''), $rowStyle), $strCell((string)($st['admission_no'] ?? ''), $rowStyle)];
                    foreach ($subjects as $subj) {
                        $subId = (int)$subj['id'];
                        $score = $ownMarksByStudent[$sid][$subId]['score'] ?? null;
                        $dataRow[] = $score !== null ? $numCell(format_mark($score), $rowStyle) : $strCell('', $rowStyle);
                    }
                    $dataRow[] = $numCell($st['total_obtained'], $rowStyle);
                    $dataRow[] = $numCell($st['total_max'], $rowStyle);
                    $dataRow[] = $percentCell(round($st['percentage'], 2));
                    $dataRow[] = $resultCell((string)$st['result']);

                    if ($sourceExamId) {
                        $dataRow[] = $strCell($sourceBase, $rowStyle);
                        $dataRow[] = isset($priorTotals[$sid]) ? $numCell($priorTotals[$sid], $rowStyle) : $strCell('', $rowStyle);
                        $dataRow[] = isset($ownTotals[$sid]) ? $numCell($ownTotals[$sid], $rowStyle) : $strCell('', $rowStyle);
                        foreach ($subjects as $subj) {
                            $subId = (int)$subj['id'];
                            $combinedScore = $combinedMarksByStudent[$sid][$subId]['score'] ?? null;
                            $dataRow[] = $combinedScore !== null ? $numCell(format_mark($combinedScore), $rowStyle) : $strCell('', $rowStyle);
                        }
                        $dataRow[] = $numCell($st['total_obtained'], $rowStyle); // final/combined total — examStudentPool() already uses effective marks
                    }

                    $dataRow[] = $positionCell($pos); // last column
                    $w->addRow($dataRow);
                }

                // Per-class Result Summary — appeared/passed/failed/percentage for
                // this class/section, plus a Class Teacher Sign and Principal Sign
                // line, right-aligned under the last two columns (Result / Position)
                // to match where the data table itself ends.
                $w->addRow([$gutter]);
                $writeResultSummary('RESULT SUMMARY', $this->resultSummaryCounts($pool), $colCount - 1, max(0, $colCount - 2));
            }
        }

        return $w;
    }

    public function idCardAction(): void
    {
        require_once __DIR__ . '/../models/StudentModel.php';
        require_once __DIR__ . '/../models/ClassSectionModel.php';

        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.id_cards']);
        // ID cards carry photos + personal details for the whole student body —
        // printing them is kept an Admin (front office) task only.
        $this->requireAdminOnly();

        $studentId = (int)($_GET['student_id'] ?? 0);
        $q = trim((string)($_GET['q'] ?? ''));
        $classSectionId = (int)($_GET['class_section_id'] ?? 0);
        $classSectionFilter = $classSectionId > 0 ? $classSectionId : null;

        $limit = 50;
        $offset = 0;

        $total = StudentModel::count($q, $classSectionFilter);
        $students = StudentModel::list($q, $classSectionFilter, $limit, $offset);
        $classSections = ClassSectionModel::allOptions();

        $student = $studentId > 0 ? StudentModel::getById($studentId) : null;

        $photoUrl = null;
        if ($student) {
            $pFiles = glob(dirname(__DIR__, 2) . '/public/uploads/students/' . $studentId . '.*') ?: [];
            if (!empty($pFiles)) {
                $photoUrl = base_url('/uploads/students/' . basename($pFiles[0]));
            }
        }

        // "Print Selected" on the bulk picker submits student_ids[] + print=1 —
        // build the 4-up print grid for those students here. Without this the
        // form just reloads the same filtered list and never prints anything.
        $bulkStudents = [];
        if (!empty($_GET['print']) && !empty($_GET['student_ids'])) {
            $studentIds = array_map('intval', (array)$_GET['student_ids']);
            $studentIds = array_values(array_unique(array_filter($studentIds, static fn($id) => $id > 0)));
            foreach ($studentIds as $sid) {
                $s = StudentModel::getById($sid);
                if (!$s) {
                    continue;
                }
                $bFiles = glob(dirname(__DIR__, 2) . '/public/uploads/students/' . $sid . '.*') ?: [];
                $bulkStudents[] = [
                    'student' => $s,
                    'photoUrl' => !empty($bFiles) ? base_url('/uploads/students/' . basename($bFiles[0])) : null,
                ];
            }
        }

        $this->render('academic/id_card', [
            'title' => 'ID Card',
            'student' => $student,
            'students' => $students,
            'bulkStudents' => $bulkStudents,
            'studentId' => $studentId,
            'q' => $q,
            'classSections' => $classSections,
            'classSectionId' => $classSectionId,
            'totalMatches' => $total,
            'limit' => $limit,
            'photoUrl' => $photoUrl,
        ]);
    }

    public function classesAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.classes']);
        $this->requireAdminOnly();

        $error = null;
        $editId = (int)($_GET['id'] ?? 0);
        $classToEdit = $editId > 0 ? Database::fetchOne('SELECT * FROM classes WHERE id = ?', 'i', [$editId]) : null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $id = (int)($_POST['id'] ?? 0);
            $name = trim((string)($_POST['name'] ?? ''));

            if ($name === '') {
                $error = 'Class name is required';
            } else {
                try {
                    if ($id > 0) {
                        Database::execute('UPDATE classes SET name = ? WHERE id = ?', 'si', [$name, $id]);
                        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Class updated'];
                        log_activity('academic.class_updated', 'Class updated');
                    } else {
                        Database::execute('INSERT INTO classes (name) VALUES (?)', 's', [$name]);
                        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Class created'];
                        log_activity('academic.class_created', 'Class created');
                    }
                    redirect_route('academic/classes');
                    return;
                } catch (Throwable $e) {
                    $msg = $e->getMessage();
                    if (stripos($msg, 'Duplicate entry') !== false) {
                        $error = 'This class name already exists.';
                    } else {
                        $error = 'Save failed: ' . $msg;
                    }
                }
            }
        }

        $classes = Database::fetchAll('SELECT * FROM classes ORDER BY name ASC');
        $this->render('academic/classes', [
            'title' => 'Classes',
            'classes' => $classes,
            'editId' => $editId,
            'classToEdit' => $classToEdit,
            'error' => $error,
        ]);
    }

    public function classDeleteAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.classes']);
        $this->requireAdminOnly();
        $this->requireCsrf();

        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            try {
                Database::execute('DELETE FROM classes WHERE id = ?', 'i', [$id]);
                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Class deleted'];
                log_activity('academic.class_deleted', 'Class deleted');
            } catch (Throwable $e) {
                $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Delete failed: ' . $e->getMessage()];
            }
        }
        redirect_route('academic/classes');
    }

    public function sectionsAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.sections']);
        $this->requireAdminOnly();

        $error = null;
        $editId = (int)($_GET['id'] ?? 0);
        $sectionToEdit = $editId > 0 ? Database::fetchOne('SELECT * FROM sections WHERE id = ?', 'i', [$editId]) : null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $id = (int)($_POST['id'] ?? 0);
            $name = trim((string)($_POST['name'] ?? ''));

            if ($name === '') {
                $error = 'Section name is required';
            } else {
                try {
                    if ($id > 0) {
                        Database::execute('UPDATE sections SET name = ? WHERE id = ?', 'si', [$name, $id]);
                        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Section updated'];
                        log_activity('academic.section_updated', 'Section updated');
                    } else {
                        Database::execute('INSERT INTO sections (name) VALUES (?)', 's', [$name]);
                        $_SESSION['flash'] = ['type' => 'success', 'message' => 'Section created'];
                        log_activity('academic.section_created', 'Section created');
                    }
                    redirect_route('academic/sections');
                    return;
                } catch (Throwable $e) {
                    $msg = $e->getMessage();
                    if (stripos($msg, 'Duplicate entry') !== false) {
                        $error = 'This section name already exists.';
                    } else {
                        $error = 'Save failed: ' . $msg;
                    }
                }
            }
        }

        $sections = Database::fetchAll('SELECT * FROM sections ORDER BY name ASC');
        $this->render('academic/sections', [
            'title' => 'Sections',
            'sections' => $sections,
            'editId' => $editId,
            'sectionToEdit' => $sectionToEdit,
            'error' => $error,
        ]);
    }

    public function sectionDeleteAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.sections']);
        $this->requireAdminOnly();
        $this->requireCsrf();

        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            try {
                Database::execute('DELETE FROM sections WHERE id = ?', 'i', [$id]);
                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Section deleted'];
                log_activity('academic.section_deleted', 'Section deleted');
            } catch (Throwable $e) {
                $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Delete failed: ' . $e->getMessage()];
            }
        }
        redirect_route('academic/sections');
    }

    public function classSectionsAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.class_sections']);
        $this->requireAdminOnly();

        $error = null;

        $classes = Database::fetchAll('SELECT id, name FROM classes ORDER BY name ASC');
        $sections = Database::fetchAll('SELECT id, name FROM sections ORDER BY name ASC');
        $years = Database::fetchAll('SELECT id, academic_year_label, is_active FROM academic_years ORDER BY academic_year_label DESC');

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();

            $classId = (int)($_POST['class_id'] ?? 0);
            $sectionId = (int)($_POST['section_id'] ?? 0);
            $academicYearId = (int)($_POST['academic_year_id'] ?? 0);
            $startDate = trim((string)($_POST['start_date'] ?? ''));
            $endDate = trim((string)($_POST['end_date'] ?? ''));

            if ($classId <= 0 || $sectionId <= 0) {
                $error = 'Class and section are required';
            } else {
                try {
                    $yearIdVal = $academicYearId > 0 ? $academicYearId : null;
                    $startVal = $startDate !== '' ? $startDate : null;
                    $endVal = $endDate !== '' ? $endDate : null;

                    Database::execute(
                        'INSERT INTO class_sections (class_id, section_id, academic_year_id, start_date, end_date)
                         VALUES (?, ?, ?, ?, ?)',
                        'iiiss',
                        [$classId, $sectionId, $yearIdVal, $startVal, $endVal]
                    );

                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Class section created'];
                    log_activity('academic.class_section_created', 'Class section created');
                    redirect_route('academic/classSections');
                    return;
                } catch (Throwable $e) {
                    $msg = $e->getMessage();
                    if (stripos($msg, 'Duplicate entry') !== false) {
                        $error = 'This class/section/year combination already exists.';
                    } else {
                        $error = 'Save failed: ' . $msg;
                    }
                }
            }
        }

        $mappings = Database::fetchAll(
            'SELECT cs.id,
                    c.name AS class_name,
                    s.name AS section_name,
                    ay.academic_year_label,
                    cs.start_date,
                    cs.end_date,
                    cs.class_teacher_staff_id,
                    sp.full_name AS class_teacher_name
             FROM class_sections cs
             JOIN classes c ON c.id = cs.class_id
             JOIN sections s ON s.id = cs.section_id
             LEFT JOIN academic_years ay ON ay.id = cs.academic_year_id
             LEFT JOIN staff_profiles sp ON sp.id = cs.class_teacher_staff_id
             ORDER BY c.name, s.name, cs.id DESC'
        );

        $staffOptions = Database::fetchAll('SELECT id, full_name, title FROM staff_profiles ORDER BY full_name');

        $this->render('academic/class_sections', [
            'title' => 'Class Sections',
            'error' => $error,
            'classes' => $classes,
            'sections' => $sections,
            'years' => $years,
            'mappings' => $mappings,
            'staffOptions' => $staffOptions,
        ]);
    }

    /** Admin sets/clears which staff member is the Class Teacher of a class section (controls who may take attendance for it). */
    public function classTeacherAssignAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'class_teachers.manage']);
        $this->requireAdminOnly();
        $this->requireCsrf();

        require_once __DIR__ . '/../models/ClassSectionModel.php';

        $classSectionId = (int)($_POST['class_section_id'] ?? 0);
        $staffProfileId = (int)($_POST['class_teacher_staff_id'] ?? 0);

        if ($classSectionId > 0) {
            ClassSectionModel::setClassTeacher($classSectionId, $staffProfileId > 0 ? $staffProfileId : null);
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Class teacher updated'];
            log_activity('academic.class_teacher_updated', 'Class teacher updated');
        }
        redirect_route('academic/classSections');
    }

    public function classSectionDeleteAction(): void
    {
        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.class_sections']);
        $this->requireAdminOnly();
        $this->requireCsrf();

        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            try {
                Database::execute('DELETE FROM class_sections WHERE id = ?', 'i', [$id]);
                $_SESSION['flash'] = ['type' => 'success', 'message' => 'Class section deleted'];
                log_activity('academic.class_section_deleted', 'Class section deleted');
            } catch (Throwable $e) {
                $_SESSION['flash'] = ['type' => 'danger', 'message' => 'Delete failed: ' . $e->getMessage()];
            }
        }
        redirect_route('academic/classSections');
    }

    // =========================================================
    // Online Courses — Admin can manage for the whole school;
    // Teacher can only assign courses to students in their own classes.
    // =========================================================

    public function coursesAction(): void
    {
        require_once __DIR__ . '/../models/OnlineCourseModel.php';

        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.courses']);

        $error = null;
        $editId = (int)($_GET['id'] ?? 0);
        $courseToEdit = $editId > 0 ? OnlineCourseModel::getById($editId) : null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $action = (string)($_POST['action'] ?? 'save');

            if ($action === 'delete') {
                $id = (int)($_POST['id'] ?? 0);
                if ($id > 0) {
                    OnlineCourseModel::delete($id);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Course deleted'];
                    log_activity('academic.course_deleted', 'Course deleted');
                }
                redirect_route('academic/courses');
                return;
            }

            $title = trim((string)($_POST['title'] ?? ''));
            $description = trim((string)($_POST['description'] ?? ''));
            $resourceUrl = trim((string)($_POST['resource_url'] ?? ''));
            $id = (int)($_POST['id'] ?? 0);

            if ($title === '') {
                $error = 'Title is required';
            } else {
                $user = Auth::currentUser();
                if ($id > 0) {
                    OnlineCourseModel::update($id, $title, $description ?: null, $resourceUrl ?: null);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Course updated'];
                    log_activity('academic.course_updated', 'Course updated');
                } else {
                    $id = OnlineCourseModel::create($title, $description ?: null, $resourceUrl ?: null, (int)($user['id'] ?? 0));
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Course created'];
                    log_activity('academic.course_created', 'Course created');
                }
                redirect_route('academic/courses');
                return;
            }
        }

        $courses = OnlineCourseModel::list();

        $this->render('academic/courses', [
            'title' => 'Online Courses',
            'error' => $error,
            'courses' => $courses,
            'courseToEdit' => $courseToEdit,
        ]);
    }

    public function courseAssignAction(): void
    {
        require_once __DIR__ . '/../models/OnlineCourseModel.php';
        require_once __DIR__ . '/../models/StudentModel.php';

        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.courses']);

        $courseId = (int)($_GET['course_id'] ?? ($_POST['course_id'] ?? 0));
        $course = $courseId > 0 ? OnlineCourseModel::getById($courseId) : null;
        if (!$course) {
            redirect_route('academic/courses');
            return;
        }

        $isTeacherScoped = !RBAC::isAdmin();
        $allowedClassSectionIds = $isTeacherScoped ? RBAC::currentTeacherClassSectionIds() : [];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $studentIds = $_POST['student_ids'] ?? [];
            if (!is_array($studentIds)) {
                $studentIds = [];
            }
            $studentIds = array_map('intval', $studentIds);

            if ($isTeacherScoped) {
                // Never let a teacher assign to a student outside their own classes,
                // and never let them wipe out assignments another teacher/admin made
                // for students outside their scope.
                $allowedStudentIds = [];
                foreach ($allowedClassSectionIds as $csId) {
                    foreach (StudentModel::getStudentsForClassSection($csId, '', 1000, 0) as $s) {
                        $allowedStudentIds[] = (int)$s['id'];
                    }
                }
                $studentIds = array_values(array_intersect($studentIds, $allowedStudentIds));
                $existing = OnlineCourseModel::assignedStudentIds($courseId);
                $outsideScope = array_diff($existing, $allowedStudentIds);
                $studentIds = array_values(array_unique(array_merge($studentIds, $outsideScope)));
            }

            OnlineCourseModel::setAssignments($courseId, $studentIds);
            $_SESSION['flash'] = ['type' => 'success', 'message' => 'Course assignments updated'];
            log_activity('academic.course_assignments_updated', 'Course assignments updated');
            redirect('/index.php?route=academic/courseAssign&course_id=' . $courseId);
            return;
        }

        $assignedIds = OnlineCourseModel::assignedStudentIds($courseId);

        if ($isTeacherScoped) {
            $students = [];
            foreach ($allowedClassSectionIds as $csId) {
                $students = array_merge($students, StudentModel::getStudentsForClassSection($csId, '', 1000, 0));
            }
        } else {
            $students = StudentModel::list('', null, 1000, 0);
        }

        $this->render('academic/course_assign', [
            'title' => 'Assign Course',
            'course' => $course,
            'students' => $students,
            'assignedIds' => $assignedIds,
        ]);
    }

    public function courseResourcesAction(): void
    {
        require_once __DIR__ . '/../models/OnlineCourseModel.php';

        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.courses']);

        $courseId = (int)($_GET['course_id'] ?? ($_POST['course_id'] ?? 0));
        $course = $courseId > 0 ? OnlineCourseModel::getById($courseId) : null;
        if (!$course) {
            redirect_route('academic/courses');
            return;
        }

        $error = null;

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->requireCsrf();
            $action = (string)($_POST['action'] ?? 'add');

            if ($action === 'delete') {
                $id = (int)($_POST['id'] ?? 0);
                if ($id > 0) {
                    OnlineCourseModel::deleteResource($id);
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Resource removed'];
                    log_activity('academic.resource_removed', 'Resource removed');
                }
                redirect('/index.php?route=academic/courseResources&course_id=' . $courseId);
                return;
            }

            $title = trim((string)($_POST['title'] ?? ''));
            $resourceType = trim((string)($_POST['resource_type'] ?? 'link'));
            $sourceType = (string)($_POST['source_type'] ?? 'link') === 'upload' ? 'upload' : 'link';
            $resourceUrl = trim((string)($_POST['resource_url'] ?? ''));
            $description = trim((string)($_POST['description'] ?? ''));
            $scheduledAt = trim((string)($_POST['scheduled_at'] ?? ''));
            $sortOrder = (int)($_POST['sort_order'] ?? 0);

            // Only video (for now) supports uploading a file instead of a link.
            if ($resourceType !== 'video') {
                $sourceType = 'link';
            }

            if ($title === '') {
                $error = 'Title is required';
            } elseif ($resourceType === 'live_class' && $scheduledAt === '') {
                $error = 'Please set a date/time for a live class';
            } elseif ($sourceType === 'upload' && (empty($_FILES['video_file']['tmp_name']) || $_FILES['video_file']['error'] !== UPLOAD_ERR_OK)) {
                $fileErr = (int)($_FILES['video_file']['error'] ?? UPLOAD_ERR_NO_FILE);
                $error = $fileErr === UPLOAD_ERR_INI_SIZE || $fileErr === UPLOAD_ERR_FORM_SIZE
                    ? 'That video file is too large for this server\'s upload limit. Use a smaller file, or paste a link instead (e.g. YouTube, Vimeo, Google Drive).'
                    : 'Please choose a video file to upload, or switch to "Link" instead.';
            } elseif ($sourceType === 'link' && $resourceUrl === '') {
                $error = 'Please provide a URL';
            } else {
                if ($sourceType === 'upload') {
                    $allowedMime = ['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime'];
                    $mimeType = mime_content_type($_FILES['video_file']['tmp_name']);
                    if (!in_array($mimeType, $allowedMime, true)) {
                        $error = 'Unsupported video format. Please upload MP4, WebM, OGG, or MOV.';
                    } else {
                        $uploadDir = dirname(__DIR__, 2) . '/public/uploads/course_videos/';
                        if (!is_dir($uploadDir)) {
                            mkdir($uploadDir, 0755, true);
                        }
                        $ext = ['video/mp4' => 'mp4', 'video/webm' => 'webm', 'video/ogg' => 'ogv', 'video/quicktime' => 'mov'][$mimeType] ?? 'mp4';
                        $filename = 'course' . $courseId . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
                        if (move_uploaded_file($_FILES['video_file']['tmp_name'], $uploadDir . $filename)) {
                            $resourceUrl = '/uploads/course_videos/' . $filename;
                        } else {
                            $error = 'Failed to save the uploaded video. Please try again.';
                        }
                    }
                }

                if ($error === null) {
                    // <input type="datetime-local"> gives "YYYY-MM-DDTHH:MM" — normalize for MySQL
                    $scheduledAtSql = $scheduledAt !== '' ? str_replace('T', ' ', $scheduledAt) . ':00' : null;
                    OnlineCourseModel::addResource(
                        $courseId,
                        $title,
                        $resourceType,
                        $resourceUrl ?: null,
                        $description ?: null,
                        $scheduledAtSql,
                        $sortOrder,
                        $sourceType
                    );
                    $_SESSION['flash'] = ['type' => 'success', 'message' => 'Resource added'];
                    log_activity('academic.resource_added', 'Resource added');
                    redirect('/index.php?route=academic/courseResources&course_id=' . $courseId);
                    return;
                }
            }
        }

        $resources = OnlineCourseModel::listResources($courseId);

        $this->render('academic/course_resources', [
            'title' => 'Course Resources',
            'course' => $course,
            'resources' => $resources,
            'error' => $error,
        ]);
    }

    public function courseResourceProgressAction(): void
    {
        require_once __DIR__ . '/../models/OnlineCourseModel.php';

        Auth::requireLogin();
        $this->requirePermission(['academic.manage', 'academic.courses']);

        $resourceId = (int)($_GET['resource_id'] ?? 0);
        $resource = $resourceId > 0 ? OnlineCourseModel::getResource($resourceId) : null;
        if (!$resource) {
            redirect_route('academic/courses');
            return;
        }
        $course = OnlineCourseModel::getById((int)$resource['course_id']);
        $progress = OnlineCourseModel::getProgressSummary($resourceId);

        $this->render('academic/course_resource_progress', [
            'title' => 'Watch Progress',
            'course' => $course,
            'resource' => $resource,
            'progress' => $progress,
        ]);
    }
}