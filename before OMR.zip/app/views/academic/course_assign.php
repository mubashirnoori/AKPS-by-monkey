<?php
// Variables: $course, $students, $assignedIds
$assignedIds = $assignedIds ?? [];
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Assign Course: <?= h($course['title'] ?? '') ?></h1>
        <div class="text-muted">Tick the students who should see this course in their portal.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/courses'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=academic/courseAssign&course_id=' . (int)$course['id']), ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
            <input type="hidden" name="course_id" value="<?= (int)$course['id'] ?>">

            <div class="table-responsive" style="max-height: 500px; overflow-y:auto;">
                <table class="table table-sm table-striped mb-0">
                    <thead>
                        <tr>
                            <th style="width:60px;">Assign</th>
                            <th>Admission #</th>
                            <th>Name</th>
                            <th>Class</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($students as $s): ?>
                        <tr>
                            <td>
                                <input class="form-check-input" type="checkbox" name="student_ids[]"
                                       value="<?= (int)$s['id'] ?>"
                                       <?= in_array((int)$s['id'], $assignedIds, true) ? 'checked' : '' ?>>
                            </td>
                            <td><?= h($s['admission_no'] ?? '') ?></td>
                            <td class="fw-semibold"><?= h(trim(($s['first_name'] ?? '') . ' ' . ($s['last_name'] ?? ''))) ?></td>
                            <td class="text-muted small"><?= h(($s['current_class_name'] ?? $s['class_name'] ?? '') . ' ' . ($s['current_section_name'] ?? $s['section_name'] ?? '')) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($students)): ?>
                        <tr><td colspan="4" class="text-muted">No students available to assign.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                <button class="btn btn-primary" type="submit">Save Assignments</button>
            </div>
        </form>
    </div>
</div>
