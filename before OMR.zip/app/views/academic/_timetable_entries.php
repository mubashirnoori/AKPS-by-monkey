<?php
// Variables: $entries, $dayNames, $dayColors, $dayFilter, $classSectionId, $timetableUrl
?>
<?php if (empty($entries)): ?>
    <div class="text-muted small py-4 text-center">
        No entries<?= $dayFilter > 0 ? ' for ' . h($dayNames[$dayFilter]) : '' ?> yet.
    </div>
<?php else: ?>
    <?php
    // Group entries by day so the table reads like a real weekly schedule.
    $grouped = [];
    foreach ($entries as $e) {
        $d = (int)($e['day_of_week'] ?? 0);
        $grouped[$d][] = $e;
    }
    ?>
    <?php foreach ($grouped as $d => $rows): ?>
        <div class="tt-day-block">
            <div class="tt-day-header mb-2" style="background: <?= h($dayColors[$d] ?? '#64748b') ?>;">
                <?= h($dayNames[$d] ?? 'Day ' . $d) ?>
                <span class="opacity-75">· <?= count($rows) ?> <?= count($rows) === 1 ? 'period' : 'periods' ?></span>
            </div>
            <div class="table-responsive">
                <table class="table table-sm tt-table mb-0 align-middle">
                    <thead>
                    <tr>
                        <th>Time</th>
                        <th>Subject</th>
                        <th>Teacher</th>
                        <th>Room</th>
                        <th style="width: 140px;">Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($rows as $e): ?>
                        <tr>
                            <td class="tt-time-pill"><?= h(substr((string)($e['start_time'] ?? ''), 0, 5)) ?> – <?= h(substr((string)($e['end_time'] ?? ''), 0, 5)) ?></td>
                            <td><span class="tt-subject-pill"><?= h($e['subject_name'] ?? '') ?></span></td>
                            <td><?= h($e['teacher_name'] ?? '—') ?></td>
                            <td><?= !empty($e['room']) ? '<span class="tt-room-badge">' . h($e['room']) . '</span>' : '<span class="text-muted">—</span>' ?></td>
                            <td class="text-nowrap">
                                <button type="button" class="btn btn-sm btn-outline-primary"
                                        data-bs-toggle="modal" data-bs-target="#editTtModal"
                                        data-id="<?= (int)$e['id'] ?>"
                                        data-day="<?= (int)($e['day_of_week'] ?? 1) ?>"
                                        data-start="<?= h(substr((string)($e['start_time'] ?? ''), 0, 5)) ?>"
                                        data-end="<?= h(substr((string)($e['end_time'] ?? ''), 0, 5)) ?>"
                                        data-subject-id="<?= (int)($e['subject_id'] ?? 0) ?>"
                                        data-teacher-id="<?= (int)($e['teacher_id'] ?? 0) ?>"
                                        data-room="<?= h($e['room'] ?? '') ?>">
                                    Edit
                                </button>
                                <form method="post" action="<?= htmlspecialchars($timetableUrl, ENT_QUOTES, 'UTF-8') ?>" class="d-inline"
                                      data-ajax data-target="#timetableEntries" data-confirm="Delete this entry?">
                                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                    <input type="hidden" name="delete_id" value="<?= (int)$e['id'] ?>">
                                    <input type="hidden" name="class_section_id" value="<?= (int)$classSectionId ?>">
                                    <input type="hidden" name="day_of_week_filter" value="<?= (int)$dayFilter ?>">
                                    <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
