<?php

class TimetableModel
{
    /** Lazily add teacher_id if the migration hasn't been run yet (mirrors SubjectModel's pattern). */
    public static function ensureTeacherIdColumn(): void
    {
        static $done = false;
        if ($done) {
            return;
        }
        try {
            $col = Database::fetchOne("SHOW COLUMNS FROM timetable_entries LIKE 'teacher_id'");
            if (!$col) {
                Database::execute('ALTER TABLE timetable_entries ADD COLUMN teacher_id INT NULL AFTER subject_id');
                try {
                    Database::execute(
                        'ALTER TABLE timetable_entries
                         ADD CONSTRAINT fk_timetable_teacher
                         FOREIGN KEY (teacher_id) REFERENCES staff_profiles(id) ON DELETE SET NULL'
                    );
                } catch (Throwable $e) {
                    // FK may already exist or lack permission — column alone is enough
                }
            }
        } catch (Throwable $e) {
            // ignore — run db/migrate_timetable_teacher.sql manually if needed
        }
        $done = true;
    }

    public static function listByClassSection(int $classSectionId): array
    {
        self::ensureTeacherIdColumn();
        return Database::fetchAll(
            'SELECT te.*,
                    s.subject_name,
                    cs.id AS class_section_row_id,
                    c.name AS class_name,
                    sec.name AS section_name,
                    sp.full_name AS teacher_name
             FROM timetable_entries te
             JOIN subjects s ON s.id = te.subject_id
             JOIN class_sections cs ON cs.id = te.class_section_id
             JOIN classes c ON c.id = cs.class_id
             JOIN sections sec ON sec.id = cs.section_id
             LEFT JOIN staff_profiles sp ON sp.id = te.teacher_id
             WHERE te.class_section_id = ?
             ORDER BY te.day_of_week, te.start_time',
            'i',
            [$classSectionId]
        );
    }

    private static function normalizeTime(string $time): string
    {
        $time = trim($time);
        if ($time === '') {
            return $time;
        }
        // HTML time inputs often send HH:MM; MySQL TIME prefers HH:MM:SS
        if (preg_match('/^\d{1,2}:\d{2}$/', $time)) {
            return $time . ':00';
        }
        return $time;
    }

    public static function create(array $data, ?int $createdByUserId): int
    {
        self::ensureTeacherIdColumn();
        $room = trim((string)($data['room'] ?? ''));
        $teacherId = !empty($data['teacher_id']) ? (int)$data['teacher_id'] : null;
        Database::execute(
            'INSERT INTO timetable_entries (class_section_id, day_of_week, start_time, end_time, subject_id, teacher_id, room, created_by_user_id)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            'iissiisi',
            [
                (int)$data['class_section_id'],
                (int)$data['day_of_week'],
                self::normalizeTime((string)$data['start_time']),
                self::normalizeTime((string)$data['end_time']),
                (int)$data['subject_id'],
                $teacherId,
                $room !== '' ? $room : null,
                $createdByUserId ? (int)$createdByUserId : null,
            ]
        );
        return (int)Database::lastInsertId();
    }

    public static function update(int $id, array $data, ?int $updatedByUserId): void
    {
        self::ensureTeacherIdColumn();
        $room = trim((string)($data['room'] ?? ''));
        $teacherId = !empty($data['teacher_id']) ? (int)$data['teacher_id'] : null;
        Database::execute(
            'UPDATE timetable_entries
             SET class_section_id = ?,
                 day_of_week = ?,
                 start_time = ?,
                 end_time = ?,
                 subject_id = ?,
                 teacher_id = ?,
                 room = ?,
                 updated_at = NOW()
             WHERE id = ?',
            'iissiisi',
            [
                (int)$data['class_section_id'],
                (int)$data['day_of_week'],
                self::normalizeTime((string)$data['start_time']),
                self::normalizeTime((string)$data['end_time']),
                (int)$data['subject_id'],
                $teacherId,
                $room !== '' ? $room : null,
                $id
            ]
        );
    }

    public static function delete(int $id): void
    {
        Database::execute('DELETE FROM timetable_entries WHERE id = ?', 'i', [$id]);
    }
}

