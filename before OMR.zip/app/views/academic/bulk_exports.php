<?php
// Variables: $examNames, $academicYears, $classes, $isAdmin, $canSeeUnpublished
$examNames = $examNames ?? [];
$academicYears = $academicYears ?? [];
$classes = $classes ?? [];
$isAdmin = $isAdmin ?? false;
$canSeeUnpublished = $canSeeUnpublished ?? $isAdmin;
?>

<style>
/* Bootstrap's .form-check-label sets color: var(--bs-body-color), which this
   theme never overrides to the dark-mode text color — so checkbox labels
   default to Bootstrap's dark gray and disappear against the dark dropdown
   background. Force the theme's own text color inside these pickers. */
.bulk-export-picker .dropdown-menu,
.bulk-export-picker .form-check-label {
    color: var(--sms-text);
}
.bulk-export-picker .text-muted {
    color: #9ca3af !important;
}
</style>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Bulk Exports</h1>
        <div class="text-muted">Select one or more exams, then download every student's report card, or a results workbook, for all of them in one file.</div>
        <?php if ($isAdmin): ?>
        <div class="text-muted small mt-1"><i class="bi bi-shield-lock"></i> As Admin, this list includes exams that haven't been published yet, and drafts are included in all three downloads below (Report Cards ZIP, Results CSV, Results Excel workbook).</div>
        <?php else: ?>
        <div class="text-muted small mt-1"><i class="bi bi-shield-lock"></i> This list only includes exams whose results have already been published. Draft/unpublished results can never be downloaded or previewed here, in any format (ZIP, CSV, or Excel) — only Admin can access those, before they're announced.</div>
        <?php endif; ?>
    </div>
    <a class="btn btn-outline-secondary" href="<?= h(base_url('/index.php?route=academic/index')) ?>">Back</a>
</div>

<?php if (empty($examNames)): ?>
<div class="card shadow-sm border-0"><div class="card-body">
    <div class="text-muted"><?= $canSeeUnpublished ? 'No exams found yet.' : 'No exams with announced results yet.' ?></div>
</div></div>
<?php else: ?>

<!-- Each button below sets a hidden "route" field (via its data-route attribute) right
     before the form submits. We do NOT rely on formaction="...?route=..." because on a
     method="get" form, browsers discard any query string already present in the
     action/formaction URL and replace it entirely with the serialized form fields — so
     "route" never actually reached the server and the app fell back to its default route
     (the dashboard). Sending "route" as a real form field avoids that. -->
<form method="get" action="<?= h(base_url('/index.php')) ?>" class="card shadow-sm border-0 mb-3" id="bulkExportForm">
    <div class="card-body">
        <input type="hidden" name="route" id="bulkExportRoute" value="">
        <!-- Lets this export work even when the download request itself doesn't carry the
             session cookie (e.g. the mobile app's WebView wrapper handing the download off
             to the OS's native downloader) — see DownloadToken / Auth::requireLoginOrToken(). -->
        <input type="hidden" name="dl_token" value="<?= h(download_token()) ?>">
        <!-- Diagnostic-only field for the "plain" test link on the Results Workbook
             card below — see the comment on that link and on bulkResultsXlsDownloadAction()
             in AcademicController.php. Remove both once that's been resolved. -->
        <input type="hidden" name="plain" id="bulkExportPlain" value="">

        <label class="form-label small text-muted mb-2">Filters</label>
        <div class="row g-2 mb-3">
            <div class="col-md-4">
                <div class="dropdown bulk-export-picker" data-picker="exam">
                    <button type="button" class="btn btn-outline-secondary w-100 d-flex align-items-center justify-content-between" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
                        <span class="bulk-export-picker-label">All Exams (<?= count($examNames) ?>)</span>
                        <i class="bi bi-chevron-down small"></i>
                    </button>
                    <div class="dropdown-menu p-2" style="width: 320px; max-height: 300px; overflow-y: auto;">
                        <div class="d-flex align-items-center justify-content-between mb-2 px-1">
                            <span class="small fw-semibold text-muted">Exams to include</span>
                            <span>
                                <button type="button" class="btn btn-link btn-sm p-0 me-2 bulk-export-select-all">Select all</button>
                                <button type="button" class="btn btn-link btn-sm p-0 bulk-export-select-none">Select none</button>
                            </span>
                        </div>
                        <?php foreach ($examNames as $en): ?>
                            <div class="form-check">
                                <input class="form-check-input bulk-export-picker-checkbox" type="checkbox" name="exam_names[]" value="<?= h($en) ?>" id="exam_<?= h(md5($en)) ?>" checked>
                                <label class="form-check-label small" for="exam_<?= h(md5($en)) ?>"><?= h($en) ?></label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="dropdown bulk-export-picker" data-picker="academicYear">
                    <button type="button" class="btn btn-outline-secondary w-100 d-flex align-items-center justify-content-between" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
                        <span class="bulk-export-picker-label">All Academic Years</span>
                        <i class="bi bi-chevron-down small"></i>
                    </button>
                    <div class="dropdown-menu p-2" style="width: 280px; max-height: 300px; overflow-y: auto;">
                        <div class="d-flex align-items-center justify-content-between mb-2 px-1">
                            <span class="small fw-semibold text-muted">Academic year</span>
                            <span>
                                <button type="button" class="btn btn-link btn-sm p-0 me-2 bulk-export-select-all">All</button>
                                <button type="button" class="btn btn-link btn-sm p-0 bulk-export-select-none">None</button>
                            </span>
                        </div>
                        <?php if (empty($academicYears)): ?>
                            <div class="text-muted small px-1">No academic years found.</div>
                        <?php endif; ?>
                        <?php foreach ($academicYears as $ay): ?>
                            <div class="form-check">
                                <input class="form-check-input bulk-export-picker-checkbox" type="checkbox" name="academic_year_ids[]" value="<?= (int)$ay['id'] ?>" id="ay_<?= (int)$ay['id'] ?>">
                                <label class="form-check-label small" for="ay_<?= (int)$ay['id'] ?>"><?= h($ay['academic_year_label']) ?></label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="dropdown bulk-export-picker" data-picker="class">
                    <button type="button" class="btn btn-outline-secondary w-100 d-flex align-items-center justify-content-between" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
                        <span class="bulk-export-picker-label">All Classes</span>
                        <i class="bi bi-chevron-down small"></i>
                    </button>
                    <div class="dropdown-menu p-2" style="width: 280px; max-height: 300px; overflow-y: auto;">
                        <div class="d-flex align-items-center justify-content-between mb-2 px-1">
                            <span class="small fw-semibold text-muted">Class</span>
                            <span>
                                <button type="button" class="btn btn-link btn-sm p-0 me-2 bulk-export-select-all">All</button>
                                <button type="button" class="btn btn-link btn-sm p-0 bulk-export-select-none">None</button>
                            </span>
                        </div>
                        <?php if (empty($classes)): ?>
                            <div class="text-muted small px-1">No classes found.</div>
                        <?php endif; ?>
                        <?php foreach ($classes as $c): ?>
                            <div class="form-check">
                                <input class="form-check-input bulk-export-picker-checkbox" type="checkbox" name="class_ids[]" value="<?= (int)$c['id'] ?>" id="cls_<?= (int)$c['id'] ?>">
                                <label class="form-check-label small" for="cls_<?= (int)$c['id'] ?>"><?= h($c['name']) ?></label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-muted small mb-3">
            Leaving Academic Year / Class unchecked includes all of them. These two filters only narrow the
            <strong>Report Cards ZIP</strong> below — the Excel workbook and CSV always cover every class/section for the selected exam(s).
        </div>

        <div class="row g-3">
            <div class="col-md-4">
                <div class="card border-0 h-100" style="background: var(--sms-surface-2);">
                    <div class="card-body d-flex flex-column">
                        <h2 class="h6"><i class="bi bi-file-earmark-zip"></i> All Report Cards (ZIP of HTML)</h2>
                        <p class="text-muted small flex-grow-1 mb-3">
                            One ZIP file of ready-to-use HTML report cards, organised as
                            <code>Academic Year / Exam Name / Class - Section / Student (Admission No).html</code>.
                            Each opens in any browser and can be printed or saved as a PDF from there (Ctrl/Cmd+P → Save as PDF).
                            For a combined exam (e.g. Final Term = First Term + Final Term), each student gets three
                            files in that folder — the prior term on its own, this exam on its own, and
                            <code>Total Result</code>, the actual combined result.
                        </p>
                        <button type="submit" class="btn btn-primary bulk-export-submit" data-route="academic/bulkReportCardsDownload">
                            <i class="bi bi-download"></i> Download ZIP
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 h-100" style="background: var(--sms-surface-2);">
                    <div class="card-body d-flex flex-column">
                        <h2 class="h6"><i class="bi bi-file-earmark-spreadsheet"></i> Results Workbook (Excel)</h2>
                        <p class="text-muted small flex-grow-1 mb-3">
                            One Excel file covering every selected exam: a combined Summary sheet (each exam's whole-school
                            topper plus each class/section's position holders, grouped by exam), plus a separate
                            full-detail sheet per exam/class/section — with the same prior-term/this-exam/combined
                            breakdown columns as the CSV for any combined exam.
                        </p>
                        <button type="submit" class="btn btn-primary bulk-export-submit" data-route="academic/bulkResultsXlsDownload">
                            <i class="bi bi-download"></i> Download Excel
                        </button>
                        <button type="submit" class="btn btn-link btn-sm bulk-export-submit-plain mt-1" data-route="academic/bulkResultsXlsDownload">
                            Download Excel (plain test — no colors/merges)
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 h-100" style="background: var(--sms-surface-2);">
                    <div class="card-body d-flex flex-column">
                        <h2 class="h6"><i class="bi bi-file-earmark-zip"></i> Results (CSV)</h2>
                        <p class="text-muted small flex-grow-1 mb-3">
                            A ZIP of separate CSV files — a genuine CSV can't hold multiple "sheets", so each
                            class/section gets its own CSV file (senior class first), plus one
                            "School &amp; Class Toppers" CSV. Every class file includes a column per subject
                            alongside the totals, matching the Excel workbook's per-class breakdown. For a
                            combined exam, extra columns show prior term marks, this exam's own marks, and
                            the combined final result per subject.
                        </p>
                        <button type="submit" class="btn btn-primary bulk-export-submit" data-route="academic/bulkResultsCsvDownload">
                            <i class="bi bi-download"></i> Download CSV (ZIP)
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<script>
(function () {
    var form = document.getElementById('bulkExportForm');
    if (!form) return;
    var routeField = document.getElementById('bulkExportRoute');
    var plainField = document.getElementById('bulkExportPlain');

    // Wire up each dropdown picker (exam / academic year / class): its
    // "Select all / Select none" links and its summary label, which reflects
    // how many checkboxes are checked (or "All ..." when every box is checked).
    var pickers = form.querySelectorAll('.bulk-export-picker');
    pickers.forEach(function (picker) {
        var kind = picker.getAttribute('data-picker');
        var boxes = picker.querySelectorAll('.bulk-export-picker-checkbox');
        var label = picker.querySelector('.bulk-export-picker-label');
        var allLabel = kind === 'exam' ? 'All Exams' : (kind === 'academicYear' ? 'All Academic Years' : 'All Classes');
        var noneLabel = kind === 'exam' ? 'No exams selected' : (kind === 'academicYear' ? 'All Academic Years' : 'All Classes');
        var itemNoun = kind === 'exam' ? 'exam' : (kind === 'academicYear' ? 'year' : 'class');

        function refreshLabel() {
            if (!label || boxes.length === 0) return;
            var checked = Array.prototype.filter.call(boxes, function (b) { return b.checked; });
            if (kind === 'exam') {
                // Exams: an empty selection is invalid, so always show a real count.
                label.textContent = checked.length === boxes.length
                    ? allLabel + ' (' + boxes.length + ')'
                    : checked.length + ' ' + itemNoun + (checked.length === 1 ? '' : 's') + ' selected';
            } else {
                // Academic Year / Class: unchecked (none) means "no filter" = everything included.
                label.textContent = checked.length === 0
                    ? noneLabel
                    : checked.length + ' ' + itemNoun + (checked.length === 1 ? '' : 's') + ' selected';
            }
        }

        boxes.forEach(function (b) { b.addEventListener('change', refreshLabel); });

        var selectAllBtn = picker.querySelector('.bulk-export-select-all');
        var selectNoneBtn = picker.querySelector('.bulk-export-select-none');
        if (selectAllBtn) {
            selectAllBtn.addEventListener('click', function () {
                boxes.forEach(function (b) { b.checked = true; });
                refreshLabel();
            });
        }
        if (selectNoneBtn) {
            selectNoneBtn.addEventListener('click', function () {
                boxes.forEach(function (b) { b.checked = false; });
                refreshLabel();
            });
        }

        // Clicking inside the dropdown (checkboxes, labels) shouldn't close it —
        // data-bs-auto-close="outside" on the toggle already handles this, but
        // stop propagation too in case Bootstrap's JS isn't loaded on some page.
        var menu = picker.querySelector('.dropdown-menu');
        if (menu) {
            menu.addEventListener('click', function (e) { e.stopPropagation(); });
        }

        refreshLabel();
    });

    // Each download button just records which route it wants; the actual submit/validation
    // happens in the form's submit handler below (works with click, Enter key, etc).
    var submitButtons = form.querySelectorAll('.bulk-export-submit');
    submitButtons.forEach(function (btn) {
        btn.addEventListener('click', function () {
            routeField.value = btn.getAttribute('data-route');
            plainField.value = ''; // a normal download button always clears the diagnostic flag
        });
    });

    // Diagnostic-only "plain test" link — see the comment near its markup above.
    var plainButtons = form.querySelectorAll('.bulk-export-submit-plain');
    plainButtons.forEach(function (btn) {
        btn.addEventListener('click', function () {
            routeField.value = btn.getAttribute('data-route');
            plainField.value = '1';
        });
    });

    form.addEventListener('submit', function (e) {
        var examBoxes = form.querySelectorAll('input[name="exam_names[]"]');
        var anyChecked = Array.prototype.some.call(examBoxes, function (b) { return b.checked; });
        if (!anyChecked) {
            e.preventDefault();
            alert('Select at least one exam first.');
            return;
        }
        if (!routeField.value) {
            // Fallback safety net in case submit fired without a button click event
            // (e.g. pressing Enter in a text field) — default to the ZIP export.
            routeField.value = 'academic/bulkReportCardsDownload';
        }
    });
})();
</script>

<?php endif; ?>