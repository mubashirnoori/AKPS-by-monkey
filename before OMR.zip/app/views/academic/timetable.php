<?php
// Variables: $classSections,$classSectionId,$dayFilter,$subjects,$entries,$teacherOptions,$error
$dayNames = [1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday'];
$dayColors = [
    1 => '#2563eb', 2 => '#7c3aed', 3 => '#0891b2', 4 => '#059669',
    5 => '#d97706', 6 => '#dc2626', 7 => '#64748b',
];
$timetableUrl = base_url('/index.php?route=academic/timetable');
$dayFilter = (int)($dayFilter ?? 0);
?>
<style>
.tt-day-header {
    padding: .5rem .9rem;
    font-weight: 600;
    font-size: .85rem;
    letter-spacing: .02em;
    color: #fff;
    border-radius: .4rem;
    display: inline-flex;
    align-items: center;
    gap: .4rem;
}
.tt-table thead th {
    font-size: .72rem;
    text-transform: uppercase;
    letter-spacing: .04em;
    color: #6b7280;
    border-bottom: 2px solid #e5e7eb;
    background: #f9fafb;
}
.tt-table td { vertical-align: middle; }
.tt-subject-pill {
    display: inline-block;
    padding: .25rem .6rem;
    border-radius: 999px;
    background: #eef2ff;
    color: #3730a3;
    font-weight: 600;
    font-size: .8rem;
}
.tt-time-pill {
    font-variant-numeric: tabular-nums;
    color: #374151;
    font-weight: 500;
}
.tt-room-badge {
    background: #f1f5f9;
    color: #475569;
    border-radius: .35rem;
    padding: .15rem .5rem;
    font-size: .78rem;
}
.tt-day-block { margin-bottom: 1.1rem; }
.tt-day-block:last-child { margin-bottom: 0; }
</style>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Timetable</h1>
        <div class="text-muted">Schedule entries by class/section — subjects listed are for that class only.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="academic/timetable">
            <div class="col-md-7">
                <label class="form-label">Class / Section</label>
                <select class="form-select" name="class_section_id" onchange="this.form.submit()">
                    <?php foreach ($classSections as $cs): ?>
                        <option value="<?= (int)$cs['id'] ?>" <?= ((int)$classSectionId === (int)$cs['id']) ? 'selected' : '' ?>>
                            <?= h($cs['class_name'] . ' ' . $cs['section_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-5">
                <label class="form-label">Day</label>
                <select class="form-select" name="day_of_week" onchange="this.form.submit()">
                    <option value="0" <?= $dayFilter === 0 ? 'selected' : '' ?>>All Days</option>
                    <?php foreach ($dayNames as $d => $label): ?>
                        <option value="<?= (int)$d ?>" <?= $dayFilter === $d ? 'selected' : '' ?>><?= h($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </form>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Add Timetable Entry</h2>
                <form method="post" action="<?= htmlspecialchars($timetableUrl, ENT_QUOTES, 'UTF-8') ?>"
                      data-ajax data-target="#timetableEntries" data-reset-on-success>
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="action" value="create">
                    <input type="hidden" name="class_section_id" value="<?= (int)$classSectionId ?>">
                    <input type="hidden" name="day_of_week_filter" value="<?= (int)$dayFilter ?>">

                    <div class="mb-3">
                        <label class="form-label">Day of Week</label>
                        <select class="form-select" name="day_of_week" required>
                            <?php foreach ($dayNames as $d => $label): ?>
                                <option value="<?= (int)$d ?>" <?= $dayFilter === $d ? 'selected' : '' ?>><?= h($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Start</label>
                            <input class="form-control" name="start_time" type="time" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">End</label>
                            <input class="form-control" name="end_time" type="time" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Subject</label>
                        <?php if (empty($subjects)): ?>
                            <div class="alert alert-warning py-2 mb-0 small">
                                No subjects for this class yet.
                                <a href="<?= htmlspecialchars(base_url('/index.php?route=academic/subjects'), ENT_QUOTES, 'UTF-8') ?>">Create a subject</a>
                                and assign it to this class.
                            </div>
                            <input type="hidden" name="subject_id" value="0">
                        <?php else: ?>
                            <select class="form-select" name="subject_id" id="add_tt_subject" required>
                                <?php foreach ($subjects as $sub): ?>
                                    <option value="<?= (int)$sub['id'] ?>"><?= h($sub['subject_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Teacher</label>
                        <?php if (!empty($subjectTeacherMap)): ?>
                            <div class="text-muted small mb-1">Auto-filled from Teacher Assignments — change it here if needed for this period only.</div>
                        <?php endif; ?>
                        <?php if (empty($teacherOptions)): ?>
                            <div class="alert alert-warning py-2 mb-0 small">No staff on file yet.</div>
                            <input type="hidden" name="teacher_id" value="0">
                        <?php else: ?>
                            <select class="form-select" name="teacher_id" id="add_tt_teacher">
                                <option value="0">— Unassigned —</option>
                                <?php foreach ($teacherOptions as $t): ?>
                                    <option value="<?= (int)$t['id'] ?>"><?= h($t['full_name'] ?? '') ?></option>
                                <?php endforeach; ?>
                            </select>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Room (optional)</label>
                        <input class="form-control" name="room">
                    </div>

                    <button class="btn btn-primary w-100" type="submit" <?= empty($subjects) ? 'disabled' : '' ?>>Add Entry</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-3">Entries</h2>
                <div id="timetableEntries">
                    <?= $this->renderPartial('academic/_timetable_entries', [
                        'entries' => $entries,
                        'dayNames' => $dayNames,
                        'dayColors' => $dayColors,
                        'dayFilter' => $dayFilter,
                        'classSectionId' => $classSectionId,
                        'timetableUrl' => $timetableUrl,
                    ]) ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Entry Modal -->
<div class="modal fade" id="editTtModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form method="post" action="<?= htmlspecialchars($timetableUrl, ENT_QUOTES, 'UTF-8') ?>"
            data-ajax data-target="#timetableEntries" data-close-modal="#editTtModal">
        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="edit_id" id="edit_tt_id" value="">
        <input type="hidden" name="class_section_id" value="<?= (int)$classSectionId ?>">
        <input type="hidden" name="day_of_week_filter" value="<?= (int)$dayFilter ?>">
        <div class="modal-header">
          <h5 class="modal-title">Edit Timetable Entry</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Day of Week</label>
            <select class="form-select" name="day_of_week" id="edit_tt_day" required>
              <?php foreach ($dayNames as $d => $label): ?>
                <option value="<?= (int)$d ?>"><?= h($label) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="row g-2 mb-3">
            <div class="col-md-6">
              <label class="form-label">Start</label>
              <input class="form-control" name="start_time" id="edit_tt_start" type="time" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">End</label>
              <input class="form-control" name="end_time" id="edit_tt_end" type="time" required>
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label">Subject</label>
            <select class="form-select" name="subject_id" id="edit_tt_subject" required>
              <?php foreach ($subjects as $sub): ?>
                <option value="<?= (int)$sub['id'] ?>"><?= h($sub['subject_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Teacher</label>
            <select class="form-select" name="teacher_id" id="edit_tt_teacher">
              <option value="0">— Unassigned —</option>
              <?php foreach ($teacherOptions as $t): ?>
                <option value="<?= (int)$t['id'] ?>"><?= h($t['full_name'] ?? '') ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-1">
            <label class="form-label">Room (optional)</label>
            <input class="form-control" name="room" id="edit_tt_room">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Save Changes</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
var SUBJECT_TEACHER_MAP = <?= json_encode($subjectTeacherMap ?? [], JSON_HEX_TAG | JSON_HEX_AMP) ?>;

function ttAutoFillTeacher(subjectSelectEl, teacherSelectEl) {
    if (!subjectSelectEl || !teacherSelectEl) return;
    var mappedTeacherId = SUBJECT_TEACHER_MAP[subjectSelectEl.value];
    if (mappedTeacherId && teacherSelectEl.querySelector('option[value="' + mappedTeacherId + '"]')) {
        teacherSelectEl.value = String(mappedTeacherId);
    }
}

document.getElementById('add_tt_subject')?.addEventListener('change', function () {
    ttAutoFillTeacher(this, document.getElementById('add_tt_teacher'));
});
// Pre-fill on initial load too, since the subject select already has a value.
ttAutoFillTeacher(document.getElementById('add_tt_subject'), document.getElementById('add_tt_teacher'));

document.getElementById('edit_tt_subject')?.addEventListener('change', function () {
    ttAutoFillTeacher(this, document.getElementById('edit_tt_teacher'));
});

document.getElementById('editTtModal')?.addEventListener('show.bs.modal', function (event) {
    var btn = event.relatedTarget;
    if (!btn) return;
    document.getElementById('edit_tt_id').value = btn.getAttribute('data-id') || '';
    document.getElementById('edit_tt_day').value = btn.getAttribute('data-day') || '1';
    document.getElementById('edit_tt_start').value = btn.getAttribute('data-start') || '';
    document.getElementById('edit_tt_end').value = btn.getAttribute('data-end') || '';
    document.getElementById('edit_tt_subject').value = btn.getAttribute('data-subject-id') || '';
    document.getElementById('edit_tt_teacher').value = btn.getAttribute('data-teacher-id') || '0';
    document.getElementById('edit_tt_room').value = btn.getAttribute('data-room') || '';
});
</script>