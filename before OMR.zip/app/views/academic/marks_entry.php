<?php
// Variables: $error,$exams,$subjects,$classSections,$examId,$subjectId,$classSectionId,$exam,$students,$marksByStudent
$exam = $exam ?? [];
$marksByStudent = $marksByStudent ?? [];
$classSections = $classSections ?? [];
$classSectionId = (int)($classSectionId ?? 0);
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Marks Entry</h1>
        <div class="text-muted">Select class first — students load from that class for the chosen exam &amp; subject.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="row g-3 align-items-end">
            <input type="hidden" name="route" value="academic/marksEntry">
            <div class="col-md-4">
                <label class="form-label fw-semibold">Class / Section *</label>
                <select class="form-select" name="class_section_id" onchange="this.form.submit()">
                    <option value="0">— All classes —</option>
                    <?php foreach ($classSections as $cs): ?>
                        <option value="<?= (int)$cs['id'] ?>" <?= $classSectionId === (int)$cs['id'] ? 'selected' : '' ?>>
                            <?= h(($cs['class_name'] ?? '') . ' — ' . ($cs['section_name'] ?? '')) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold">Exam</label>
                <select class="form-select" name="exam_id" required onchange="this.form.submit()">
                    <?php if (empty($exams)): ?>
                        <option value="">No exams for this class</option>
                    <?php else: ?>
                        <?php foreach ($exams as $e): ?>
                            <?php
                            $cls = trim(($e['class_name'] ?? '') . ' ' . ($e['section_name'] ?? ''));
                            $label = ($e['exam_name'] ?? '');
                            if ($cls !== '') {
                                $label .= ' [' . $cls . ']';
                            }
                            ?>
                            <option value="<?= (int)$e['id'] ?>" <?= ((int)$examId === (int)$e['id']) ? 'selected' : '' ?>>
                                <?= h($label) ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold">Subject</label>
                <select class="form-select" name="subject_id" required onchange="this.form.submit()" <?= empty($subjects) ? 'disabled' : '' ?>>
                    <?php if (empty($subjects)): ?>
                        <option value="">No subjects for this class — create them under Subjects</option>
                    <?php else: ?>
                        <?php foreach ($subjects as $s): ?>
                            <option value="<?= (int)$s['id'] ?>" <?= ((int)$subjectId === (int)$s['id']) ? 'selected' : '' ?>>
                                <?= h($s['subject_name'] ?? '') ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=academic/marksEntry'), ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
            <input type="hidden" name="exam_id" value="<?= (int)$examId ?>">
            <input type="hidden" name="subject_id" value="<?= (int)$subjectId ?>">
            <input type="hidden" name="class_section_id" value="<?= (int)$classSectionId ?>">

            <div class="text-muted small mb-2">
                <?= h(($exam['exam_name'] ?? '') . ' — ' . ($exam['exam_group_name'] ?? '') . ' (' . ($exam['exam_type_name'] ?? '') . ')') ?>
                <?php if (!empty($exam['class_name'])): ?>
                    &nbsp;|&nbsp; <span class="badge bg-info text-dark">Class: <?= h(trim(($exam['class_name'] ?? '') . ' ' . ($exam['section_name'] ?? ''))) ?></span>
                <?php endif; ?>
                <?php if (!empty($exam['total_marks'])): ?>
                    &nbsp;|&nbsp; <span class="badge bg-primary">Default Total: <?= (int)$exam['total_marks'] ?></span>
                <?php endif; ?>
                &nbsp;|&nbsp; <span class="badge bg-secondary"><?= count($students) ?> student(s)</span>
            </div>

            <?php if (!empty($lastSavedInfo)): ?>
                <div class="text-muted small mb-3">
                    <i class="bi bi-clock-history me-1"></i>Last saved by
                    <strong><?= h($lastSavedInfo['saved_by_name'] ?? 'a deleted user') ?></strong>
                    on <?= h(date('d M Y, h:i A', strtotime($lastSavedInfo['updated_at']))) ?>
                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-sm table-striped mb-0 align-middle">
                    <thead>
                    <tr>
                        <th>Roll</th>
                        <th>Admission</th>
                        <th>Student</th>
                        <th>Father's Name</th>
                        <th style="width: 160px;">Score</th>
                        <th style="width: 140px;">Out of (Total Marks)</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if ($classSectionId <= 0): ?>
                        <tr><td colspan="6" class="text-muted">Select a class/section (or an exam tied to a class) to load students.</td></tr>
                    <?php elseif (empty($students)): ?>
                        <tr><td colspan="6" class="text-muted">No students currently assigned to this class/section.</td></tr>
                    <?php else: ?>
                        <?php
                        $savedSubjectTotal = $savedSubjectTotal ?? null;
                        $dateSheetSubjectTotal = $dateSheetSubjectTotal ?? null;
                        if ($savedSubjectTotal !== null) {
                            $defaultTotal = (float)$savedSubjectTotal;
                        } elseif ($dateSheetSubjectTotal !== null) {
                            $defaultTotal = (float)$dateSheetSubjectTotal;
                        } else {
                            $defaultTotal = !empty($exam['total_marks']) ? (int)$exam['total_marks'] : '';
                        }
                        ?>
                        <tr class="table-warning">
                            <td colspan="4" class="fw-semibold small">
                                Total Marks for this Subject
                                <?php if ($savedSubjectTotal !== null): ?>
                                    <span class="badge bg-success ms-1">Saved: <?= (float)$savedSubjectTotal ?></span>
                                <?php elseif ($dateSheetSubjectTotal !== null): ?>
                                    <span class="badge bg-info text-dark ms-1">From Date Sheet: <?= (float)$dateSheetSubjectTotal ?></span>
                                <?php endif; ?>
                            </td>
                            <td colspan="2">
                                <input class="form-control form-control-sm" style="width:160px;" type="number" step="0.01" min="1"
                                    name="subject_total_marks"
                                    value="<?= h((string)$defaultTotal) ?>"
                                    placeholder="e.g. <?= $defaultTotal ?: '100' ?>">
                            </td>
                        </tr>
                        <?php foreach ($students as $st): ?>
                            <?php $sid = (int)$st['id']; $existing = $marksByStudent[$sid] ?? ''; ?>
                            <tr>
                                <td class="text-muted small"><?= h((string)($st['roll_number'] ?? '—')) ?></td>
                                <td><?= h($st['admission_no'] ?? '') ?></td>
                                <td><?= h(($st['first_name'] ?? '') . ' ' . ($st['last_name'] ?? '')) ?></td>
                                <td class="text-muted small"><?= h($st['father_name'] ?? '') ?: '—' ?></td>
                                <td>
                                    <input class="form-control form-control-sm" type="number" step="0.01" name="score_by_student[<?= (int)$sid ?>]" value="<?= h($existing) ?>">
                                </td>
                                <td class="text-muted small">/ <span class="total-marks-display"><?= $defaultTotal ?: '—' ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                <button class="btn btn-primary" type="submit" <?= empty($students) ? 'disabled' : '' ?>>Save Marks</button>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const totalInput = document.querySelector('input[name="subject_total_marks"]');
    const displays = document.querySelectorAll('.total-marks-display');
    if (totalInput) {
        totalInput.addEventListener('input', function () {
            const val = this.value.trim() || '—';
            displays.forEach(function (el) { el.textContent = val; });
        });
    }
});
</script>
