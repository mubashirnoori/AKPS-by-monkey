<?php
// Variables: $schoolName, $logoUrl, $address, $contact, $email, $academicYear, $classes, $sections
$schoolName = $schoolName ?? 'School';
$logoUrl = $logoUrl ?? '';
$address = $address ?? '';
$contact = $contact ?? '';
$email = $email ?? '';
$academicYear = $academicYear ?? (string)date('Y');
$classes = $classes ?? [];
$sections = $sections ?? [];
$nextYear = substr((string)((int)$academicYear + 1), -2);
?>
<style>
/* ============================================================
   SCHOOL ADMISSION FORM — A4 PRINT OPTIMIZED
   ============================================================ */

.admission-page{
    --navy:#17345c;
    --navy-dark:#102744;
    --gold:#b8892f;
    --gold-soft:#e8d39e;
    --paper:#fffdf8;
    --paper-soft:#f7f1e3;
    --ink:#1d2938;
    --muted:#5d6978;
    --line:#c9cfd7;
    --line-dark:#9da7b3;
    font-family:'Inter',Arial,sans-serif;
    color:var(--ink);
}

.admission-toolbar{
    display:flex;
    align-items:center;
    gap:.75rem;
    flex-wrap:wrap;
    background:var(--navy-dark);
    border-radius:10px;
    padding:.75rem 1rem;
    margin-bottom:1rem;
}
.admission-toolbar__label{
    color:#dce5f2;
    font-size:.82rem;
    margin-right:auto;
    display:flex;
    align-items:center;
    gap:.5rem;
}
.admission-btn{
    appearance:none;
    border:1px solid transparent;
    border-radius:7px;
    padding:.55rem 1rem;
    font-family:inherit;
    font-size:.8rem;
    font-weight:700;
    cursor:pointer;
    display:inline-flex;
    align-items:center;
    gap:.45rem;
}
.admission-btn-print{
    background:linear-gradient(180deg,#e5c77f,#b8892f);
    color:#241b0a;
    box-shadow:0 2px 0 #8e6720;
}
.admission-btn-ghost{
    background:transparent;
    color:#e3e9f2;
    border-color:rgba(255,255,255,.3);
}

.admission-sheet-wrap{
    display:flex;
    justify-content:center;
    padding-bottom:2rem;
}

.admission-sheet{
    position:relative;
    box-sizing:border-box;
    width:210mm;
    min-height:297mm;
    max-width:100%;
    padding:8mm 9mm 6.5mm;
    overflow:hidden;
    background:var(--paper);
    color:var(--ink);
    box-shadow:0 8px 30px rgba(0,0,0,.15);
}

.admission-frame{
    position:absolute;
    inset:4mm;
    border:1.2px solid #b8a066;
    pointer-events:none;
    z-index:5;
}
.admission-frame::before{
    content:"";
    position:absolute;
    inset:3px;
    border:1px solid rgba(184,137,47,.45);
}
.admission-inner{
    position:relative;
    z-index:1;
}

.admission-tick{
    position:absolute;
    width:12px;
    height:12px;
    z-index:6;
}
.admission-tick::before,
.admission-tick::after{
    content:"";
    position:absolute;
    background:var(--gold);
}
.admission-tick::before{width:12px;height:2px;top:0;left:0;}
.admission-tick::after{width:2px;height:12px;top:0;left:0;}
.admission-tick.tl{top:4mm;left:4mm;}
.admission-tick.tr{top:4mm;right:4mm;transform:scaleX(-1);}
.admission-tick.bl{bottom:4mm;left:4mm;transform:scaleY(-1);}
.admission-tick.br{bottom:4mm;right:4mm;transform:scale(-1,-1);}

.sf-letterhead{
    display:grid;
    grid-template-columns:24mm 1fr 30mm;
    align-items:center;
    gap:4mm;
    min-height:25mm;
    padding:0 2mm 2mm;
}
.sf-letterhead__crest{
    width:21mm;
    height:21mm;
    display:flex;
    align-items:center;
    justify-content:center;
}
.sf-letterhead__crest img{
    width:100%;
    height:100%;
    object-fit:contain;
}
.sf-letterhead__mid{
    min-width:0;
    text-align:center;
}
.sf-letterhead__name{
    font-family:'Lora',Georgia,serif;
    font-weight:800;
    font-size:18px;
    color:var(--navy);
    margin:0;
    line-height:1.15;
}
.sf-letterhead__tagline{
    font-family:'Lora',Georgia,serif;
    font-style:italic;
    font-size:10px;
    color:var(--gold);
    margin:2px 0 4px;
}
.sf-letterhead__meta{
    font-size:8.5px;
    color:var(--muted);
    margin:0;
    line-height:1.25;
}
.sf-letterhead__meta span{margin:0 .35em;}
.sf-letterhead__photo{
    box-sizing:border-box;
    width:29mm;
    height:36mm;
    border:1.4px dashed var(--gold);
    border-radius:2px;
    display:flex;
    align-items:center;
    justify-content:center;
    text-align:center;
    font-size:8px;
    font-weight:600;
    color:#8d6a28;
    line-height:1.25;
    background:#fffaf0;
    padding:2mm;
}

.sf-rule{
    height:1px;
    background:linear-gradient(90deg,transparent,var(--gold) 10%,var(--gold) 90%,transparent);
    margin:0 0 3.2mm;
}

.sf-title-band{
    display:grid;
    grid-template-columns:1fr auto;
    align-items:center;
    gap:5mm;
    background:linear-gradient(135deg,var(--navy),#244b79);
    color:#fffaf0;
    border-radius:2px;
    padding:3.2mm 4mm;
    margin:0 0 4mm;
}
.sf-title-band__text{
    font-family:'Lora',Georgia,serif;
    font-weight:800;
    font-size:14px;
    letter-spacing:.07em;
    text-transform:uppercase;
}
.sf-title-band__sub{
    font-size:8.5px;
    color:#f0dfb2;
    margin-top:1px;
}
.sf-title-band__fields{
    display:flex;
    gap:6mm;
}
.sf-tb-field{min-width:31mm;}
.sf-tb-field label{
    display:block;
    font-size:7px;
    text-transform:uppercase;
    letter-spacing:.08em;
    color:#e7cf91;
    margin-bottom:1px;
}
.sf-tb-field input{
    box-sizing:border-box;
    width:100%;
    height:6mm;
    background:transparent;
    border:none;
    border-bottom:1px solid rgba(255,255,255,.65);
    color:#fff;
    font-family:inherit;
    font-size:9px;
    padding:0;
}
.sf-tb-field input::placeholder{color:rgba(255,255,255,.55);}

.sf-section{
    margin-bottom:3.5mm;
}
.sf-section__head{
    display:flex;
    align-items:center;
    gap:2mm;
    margin-bottom:1.3mm;
}
.sf-section__mark{
    width:6px;
    height:6px;
    background:var(--gold);
    transform:rotate(45deg);
    flex:0 0 auto;
}
.sf-section__title{
    font-family:'Lora',Georgia,serif;
    font-weight:800;
    font-size:10.5px;
    letter-spacing:.055em;
    text-transform:uppercase;
    color:var(--navy);
    margin:0;
    white-space:nowrap;
}
.sf-section__line{
    flex:1;
    height:1px;
    background:repeating-linear-gradient(90deg,#c8cdd3 0 4px,transparent 4px 8px);
}

.sf-grid{
    display:grid;
    grid-template-columns:repeat(4,minmax(0,1fr));
    column-gap:4mm;
    row-gap:2.4mm;
}
.sf-field{
    min-width:0;
    display:flex;
    flex-direction:column;
}
.sf-field.span-2{grid-column:span 2;}
.sf-field.span-3{grid-column:span 3;}
.sf-field.span-4{grid-column:span 4;}

.sf-field label{
    font-size:7px;
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:.045em;
    color:#596577;
    margin-bottom:.8mm;
    display:flex;
    justify-content:space-between;
    line-height:1.1;
}
.sf-field label .opt{
    text-transform:none;
    font-weight:400;
    font-style:italic;
    color:#9299a4;
    font-size:7px;
    letter-spacing:0;
}

.sf-field input[type=text],
.sf-field input[type=date],
.sf-field input[type=tel],
.sf-field input[type=email],
.sf-field select{
    box-sizing:border-box;
    width:100%;
    height:6.2mm;
    font-family:inherit;
    font-size:9px;
    color:var(--ink);
    background:transparent;
    border:none;
    border-bottom:1px solid var(--line);
    border-radius:0;
    padding:0 1px;
    outline:none;
}
.sf-field input:focus,
.sf-field select:focus{
    border-bottom-color:var(--navy);
}
.sf-field select{
    appearance:none;
    background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 6'%3E%3Cpath d='M0 0 5 6 10 0' fill='none' stroke='%235c6577' stroke-width='1.3'/%3E%3C/svg%3E");
    background-repeat:no-repeat;
    background-position:right 2px center;
    background-size:8px 5px;
    padding-right:12px;
}
.sf-radio-row{
    display:flex;
    align-items:center;
    gap:4mm;
    height:6.2mm;
    border-bottom:1px solid var(--line);
}
.sf-radio-opt{
    display:flex;
    align-items:center;
    gap:1.2mm;
    font-size:8px;
    color:var(--ink);
}
.sf-radio-opt input{
    accent-color:var(--navy);
    width:11px;
    height:11px;
    margin:0;
}

.sf-checklist{
    display:grid;
    grid-template-columns:1fr 1fr;
    column-gap:8mm;
    row-gap:1mm;
}
.sf-check-item{
    display:flex;
    align-items:center;
    gap:1.5mm;
    font-size:8px;
    color:var(--ink);
    line-height:1.25;
}
.sf-check-item input{
    width:12px;
    height:12px;
    margin:0;
    accent-color:var(--navy);
}

.sf-declaration{
    font-size:8px;
    line-height:1.35;
    color:#3c4654;
    background:var(--paper-soft);
    border-left:2px solid var(--gold);
    padding:2.6mm 3mm;
    margin:0 0 2.8mm;
}
.sf-sign-row{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:6mm;
    margin-top:3.2mm;
}
.sf-sign-box{text-align:center;min-width:0;}
.sf-sign-box .line{
    border-top:1px solid #39424f;
    height:5mm;
    margin-bottom:1mm;
}
.sf-sign-box .cap{
    font-size:6.8px;
    line-height:1.15;
    letter-spacing:.045em;
    text-transform:uppercase;
    color:#657080;
}

.sf-office{
    margin-top:3.5mm;
    border:1px solid #c7cdd4;
    overflow:hidden;
    background:#fbf7eb;
}
.sf-office__head{
    background:var(--navy);
    color:#f0dfb2;
    font-family:'Lora',Georgia,serif;
    font-weight:800;
    font-size:8.5px;
    letter-spacing:.08em;
    text-transform:uppercase;
    padding:1.7mm 3mm;
    display:flex;
    align-items:center;
    gap:1.5mm;
}
.sf-office__body{
    padding:2.2mm 3mm 1.8mm;
}
.sf-office .sf-field label{color:#806a36;}
.sf-office .sf-field input,
.sf-office .sf-field select{border-bottom-color:#b9b29f;}
.sf-office .sf-sign-row{margin-top:3mm;}

.sf-foot-strip{
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:4mm;
    margin-top:2.5mm;
    padding-top:1.5mm;
    border-top:1px solid #d4d8de;
    font-size:6.8px;
    color:#89919d;
}

/* Screen-only responsive behavior */
@media (max-width:800px){
    .admission-sheet{
        width:100%;
        padding:7mm 5mm 6mm;
    }
    .admission-frame{inset:3mm;}
    .sf-letterhead{
        grid-template-columns:18mm 1fr 27mm;
        gap:2mm;
    }
    .sf-letterhead__crest{width:17mm;height:17mm;}
    .sf-letterhead__photo{width:26mm;height:33mm;}
    .sf-grid{grid-template-columns:1fr 1fr;}
    .sf-field.span-3,.sf-field.span-4{grid-column:span 2;}
    .sf-title-band{grid-template-columns:1fr;}
    .sf-title-band__fields{width:100%;}
}

@media print{
    @page{
        size:A4 portrait;
        margin:0;
    }

    html,body{
        width:210mm !important;
        height:297mm !important;
        min-height:297mm !important;
        max-height:297mm !important;
        margin:0 !important;
        padding:0 !important;
        background:#fff !important;
        overflow:hidden !important;
    }

    body{
        position:relative !important;
        -webkit-print-color-adjust:exact !important;
        print-color-adjust:exact !important;
    }

    .sms-no-print,
    .navbar,
    aside,
    nav,
    .nav-flyout,
    .btn{
        display:none !important;
    }

    .admission-page{
        position:absolute !important;
        top:0 !important;
        left:0 !important;
        width:210mm !important;
        height:297mm !important;
        min-height:0 !important;
        max-height:297mm !important;
        margin:0 !important;
        padding:0 !important;
        background:#fff !important;
        overflow:hidden !important;
    }

    .admission-sheet-wrap{
        display:block !important;
        width:210mm !important;
        padding:0 !important;
        margin:0 !important;
    }

    .admission-sheet{
        display:block !important;
        box-sizing:border-box !important;
        width:210mm !important;
        max-width:none !important;
        min-height:0 !important;
        height:auto !important;
        max-height:none !important;
        margin:0 !important;
        padding:7mm 9mm 4mm !important;
        overflow:hidden !important;
        box-shadow:none !important;
        page-break-after:avoid !important;
        break-after:avoid-page !important;
    }

    .admission-inner{
        page-break-inside:avoid !important;
        break-inside:avoid !important;
    }
    .sf-section,
    .sf-office{
        page-break-inside:avoid !important;
        break-inside:avoid !important;
    }

    .admission-frame{inset:4mm !important;}

    /* Keep the sheet only as tall as its actual form content. The A4 page itself
       remains 297mm, so unused paper below the form stays outside the border. */
    .admission-sheet{
        overflow:hidden !important;
        page-break-before:avoid !important;
        page-break-after:avoid !important;
        break-before:avoid-page !important;
        break-after:avoid-page !important;
    }

    /* Keep the school logo and photograph large and consistent on paper */
    .sf-letterhead{
        grid-template-columns:24mm 1fr 30mm !important;
        min-height:25mm !important;
        gap:4mm !important;
    }
    .sf-letterhead__crest{
        width:21mm !important;
        height:21mm !important;
    }
    .sf-letterhead__crest img{
        width:21mm !important;
        height:21mm !important;
        max-width:none !important;
        max-height:none !important;
        object-fit:contain !important;
    }
    .sf-letterhead__photo{
        width:29mm !important;
        height:36mm !important;
        min-width:29mm !important;
        min-height:36mm !important;
        font-size:8px !important;
    }

    /* Prevent browser rules from shrinking the form */
    .sf-grid{grid-template-columns:repeat(4,minmax(0,1fr)) !important;}
    .sf-field.span-2{grid-column:span 2 !important;}
    .sf-field.span-3{grid-column:span 3 !important;}
    .sf-field.span-4{grid-column:span 4 !important;}
    .sf-checklist{grid-template-columns:1fr 1fr !important;}
    .sf-sign-row{grid-template-columns:repeat(3,1fr) !important;}

    input,select{
        -webkit-print-color-adjust:exact !important;
        print-color-adjust:exact !important;
    }
}
</style>

<div class="admission-page">

    <div class="admission-toolbar sms-no-print">
        <div class="admission-toolbar__label">
            <i class="bi bi-file-earmark-person"></i>
            Admission Form — ready to print
        </div>
        <button type="button" class="admission-btn admission-btn-print" onclick="window.print()">
            <i class="bi bi-printer"></i> Print / Save as PDF
        </button>
        <button type="button" class="admission-btn admission-btn-ghost" onclick="if(confirm('Clear all entered details?')){document.getElementById('admissionFormSheet').querySelectorAll('input,select').forEach(function(el){ if(el.type==='checkbox'||el.type==='radio'){el.checked=false;} else {el.value='';} });}">
            <i class="bi bi-x-lg"></i> Clear Form
        </button>
    </div>

    <div class="admission-sheet-wrap">
        <div class="admission-sheet" id="admissionFormSheet">

            <div class="admission-frame"></div>
            <span class="admission-tick tl"></span><span class="admission-tick tr"></span>
            <span class="admission-tick bl"></span><span class="admission-tick br"></span>

            <div class="admission-inner">

                <div class="sf-letterhead">
                    <div class="sf-letterhead__crest">
                        <?php if ($logoUrl !== ''): ?>
                            <img src="<?= h($logoUrl) ?>" alt="School crest">
                        <?php endif; ?>
                    </div>
                    <div class="sf-letterhead__mid">
                        <p class="sf-letterhead__name"><?= h($schoolName) ?></p>
                        <p class="sf-letterhead__tagline">Excellence in Education, Excellence in Life</p>
                        <p class="sf-letterhead__meta">
                            <?php if ($address !== ''): ?><?= h($address) ?><?php endif; ?>
                            <?php if ($contact !== ''): ?><span>&middot;</span><?= h($contact) ?><?php endif; ?>
                            <?php if ($email !== ''): ?><span>&middot;</span><?= h($email) ?><?php endif; ?>
                        </p>
                    </div>
                    <div class="sf-letterhead__photo">Paste<br>Recent<br>Photograph</div>
                </div>

                <div class="sf-rule"></div>

                <div class="sf-title-band">
                    <div>
                        <div class="sf-title-band__text">Student Admission Form</div>
                        <div class="sf-title-band__sub">Academic Year <?= h($academicYear) ?> &ndash; <?= h($nextYear) ?></div>
                    </div>
                    <div class="sf-title-band__fields">
                        <div class="sf-tb-field">
                            <label>Form No.</label>
                            <input type="text" placeholder="&mdash;">
                        </div>
                        <div class="sf-tb-field">
                            <label>Date</label>
                            <input type="date">
                        </div>
                    </div>
                </div>

                <div class="sf-section">
                    <div class="sf-section__head">
                        <span class="sf-section__mark"></span>
                        <h3 class="sf-section__title">Student Information</h3>
                        <span class="sf-section__line"></span>
                    </div>
                    <div class="sf-grid sf-grid-4">
                        <div class="sf-field span-2"><label>First Name</label><input type="text" name="first_name"></div>
                        <div class="sf-field span-2"><label>Last Name</label><input type="text" name="last_name"></div>

                        <div class="sf-field span-2"><label>Father's Name</label><input type="text" name="father_name"></div>
                        <div class="sf-field"><label>Date of Birth</label><input type="date" name="dob"></div>
                        <div class="sf-field">
                            <label>Gender</label>
                            <div class="sf-radio-row">
                                <label class="sf-radio-opt"><input type="radio" name="gender" value="male"> Male</label>
                                <label class="sf-radio-opt"><input type="radio" name="gender" value="female"> Female</label>
                            </div>
                        </div>

                        <div class="sf-field span-2"><label>CNIC / B-Form No.</label><input type="text" name="cnic_no" placeholder="e.g. 17301-1234567-1"></div>
                        <div class="sf-field span-2"><label>Contact Phone</label><input type="tel" name="phone"></div>

                        <div class="sf-field span-4"><label>Residential Address</label><input type="text" name="address"></div>
                    </div>
                </div>

                <div class="sf-section">
                    <div class="sf-section__head">
                        <span class="sf-section__mark"></span>
                        <h3 class="sf-section__title">Class Applying For</h3>
                        <span class="sf-section__line"></span>
                    </div>
                    <div class="sf-grid sf-grid-4">
                        <div class="sf-field span-2">
                            <label>Class</label>
                            <select name="class_id">
                                <option value="">Select class</option>
                                <?php foreach ($classes as $c): ?>
                                    <option value="<?= (int)$c['id'] ?>"><?= h($c['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="sf-field">
                            <label>Section <span class="opt">preferred</span></label>
                            <select name="section_id">
                                <option value="">&mdash;</option>
                                <?php foreach ($sections as $s): ?>
                                    <option value="<?= (int)$s['id'] ?>"><?= h($s['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="sf-field"><label>Shift <span class="opt">if applicable</span></label><input type="text" name="shift"></div>

                        <div class="sf-field span-3"><label>Previous School Attended <span class="opt">if any</span></label><input type="text" name="previous_school"></div>
                        <div class="sf-field"><label>Board Reg. No. <span class="opt">if any</span></label><input type="text" name="board_registration_no"></div>
                    </div>
                </div>

                <div class="sf-section">
                    <div class="sf-section__head">
                        <span class="sf-section__mark"></span>
                        <h3 class="sf-section__title">Parent / Guardian Information</h3>
                        <span class="sf-section__line"></span>
                    </div>
                    <div class="sf-grid sf-grid-4">
                        <div class="sf-field span-2"><label>Guardian Full Name</label><input type="text" name="guardian_full_name"></div>
                        <div class="sf-field"><label>Relation</label><input type="text" name="guardian_relation" placeholder="Father / Mother / Guardian"></div>
                        <div class="sf-field"><label>CNIC No.</label><input type="text" name="guardian_cnic"></div>

                        <div class="sf-field span-2"><label>Phone Number</label><input type="tel" name="guardian_phone"></div>
                        <div class="sf-field span-2"><label>Email <span class="opt">optional</span></label><input type="email" name="guardian_email"></div>

                        <div class="sf-field span-4"><label>Guardian Address <span class="opt">if different from above</span></label><input type="text" name="guardian_address"></div>
                    </div>
                </div>

                <div class="sf-section">
                    <div class="sf-section__head">
                        <span class="sf-section__mark"></span>
                        <h3 class="sf-section__title">Documents Attached</h3>
                        <span class="sf-section__line"></span>
                    </div>
                    <div class="sf-checklist">
                        <label class="sf-check-item"><input type="checkbox"> Copy of B-Form / CNIC</label>
                        <label class="sf-check-item"><input type="checkbox"> Passport-size photographs (2)</label>
                        <label class="sf-check-item"><input type="checkbox"> Previous school leaving certificate</label>
                        <label class="sf-check-item"><input type="checkbox"> Last report card / mark sheet</label>
                        <label class="sf-check-item"><input type="checkbox"> Guardian CNIC copy</label>
                        <label class="sf-check-item"><input type="checkbox"> Birth certificate</label>
                    </div>
                </div>

                <div class="sf-section">
                    <div class="sf-section__head">
                        <span class="sf-section__mark"></span>
                        <h3 class="sf-section__title">Declaration</h3>
                        <span class="sf-section__line"></span>
                    </div>
                    <p class="sf-declaration">
                        I hereby declare that the information provided above is true and correct to the best of my
                        knowledge. I agree to abide by the rules and regulations of <?= h($schoolName) ?>, and
                        understand that any false information may result in cancellation of admission.
                    </p>
                    <div class="sf-sign-row">
                        <div class="sf-sign-box"><div class="line"></div><div class="cap">Parent / Guardian Signature</div></div>
                        <div class="sf-sign-box"><div class="line"></div><div class="cap">Date</div></div>
                        <div class="sf-sign-box"><div class="line"></div><div class="cap">Thumb Impression <span style="text-transform:none;font-style:italic;">(if applicable)</span></div></div>
                    </div>
                </div>

                <div class="sf-office">
                    <div class="sf-office__head">
                        <i class="bi bi-archive"></i> For Office Use Only
                    </div>
                    <div class="sf-office__body">
                        <div class="sf-grid sf-grid-4">
                            <div class="sf-field"><label>Admission No.</label><input type="text" name="office_admission_no"></div>
                            <div class="sf-field"><label>Roll No.</label><input type="text" name="office_roll_no"></div>
                            <div class="sf-field"><label>Class Section Assigned</label><input type="text" name="office_class_section"></div>
                            <div class="sf-field"><label>Fee Category</label><input type="text" name="office_fee_category"></div>
                        </div>
                        <div class="sf-sign-row" style="margin-top:4mm;">
                            <div class="sf-sign-box"><div class="line"></div><div class="cap">Verified By</div></div>
                            <div class="sf-sign-box"><div class="line"></div><div class="cap">Accounts</div></div>
                            <div class="sf-sign-box"><div class="line"></div><div class="cap">Principal / Head</div></div>
                        </div>
                    </div>
                </div>

                <div class="sf-foot-strip">
                    <span><?= h($schoolName) ?><?php if ($address !== ''): ?> &middot; <?= h($address) ?><?php endif; ?></span>
                    <span>Please complete in block letters</span>
                </div>

            </div>
        </div>
    </div>
</div>
