<?php
// Variables: $student,$exams,$examId,$studentId,$studentMarks,$average,$overallGrade
$student = $student ?? null;
$settingsMap = [];
$schoolName  = 'ARC School';
$logoPath    = '';
try {
    if (class_exists('Database')) {
        $rows = Database::fetchAll('SELECT `key`, `value` FROM settings');
        foreach ($rows as $r) { $settingsMap[$r['key']] = $r['value']; }
    }
    $schoolName = $settingsMap['branding_school_name'] ?? $settingsMap['institute_name'] ?? 'ARC School';
    $logoPath   = $settingsMap['branding_logo_path'] ?? '';
} catch (Throwable $e) {}
?>
<style>
/* ---- Screen controls ---- */
.cert-controls { margin-bottom: 1.2rem; }

/* ---- Certificate card ---- */
.cert-page {
    background: #fff;
    border: 3px solid #1e3a5f;
    border-radius: 12px;
    max-width: 720px;
    margin: 0 auto;
    padding: 0;
    box-shadow: 0 6px 32px rgba(30,58,95,.13);
    overflow: hidden;
    font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif;
    color: #0f172a;
    --bs-body-color: #0f172a;
    --bs-table-color: #0f172a;
    /* Always close to a full A4 page tall, whether the student has 3
       subjects or 6+, so there's no leftover page space for a print/PDF
       viewer to paint as a blank area below the card. Deliberately a bit
       under the full 277mm content height (297mm page - 10mm margin each
       side) rather than exactly matching it -- borders, box-shadow and
       sub-pixel rounding differences between browsers/print engines only
       need to push a box a hair past the page edge to spill a whole extra
       (near-empty) second page, so this leaves real headroom instead of
       cutting it exactly at the line. box-sizing: border-box keeps the 3px
       border counted INSIDE this height rather than adding on top of it. */
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    min-height: 250mm;
}
.cert-page,
.cert-page table,
.cert-page td,
.cert-page th,
.cert-page strong {
    color: inherit;
}
.cert-outer-border {
    border: 6px double #b89a4e;
    margin: 8px;
    border-radius: 8px;
    padding: 1.1rem 1.8rem 1rem;
    color: #0f172a;
    /* Stretch to fill .cert-page so the gold double border always reaches
       the bottom of the page too, not just the top content block. */
    flex: 1;
    display: flex;
    flex-direction: column;
}
.cert-school-title {
    font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif;
    text-align: center;
    font-size: 1.5rem;
    font-weight: 800;
    letter-spacing: .1em;
    color: #1e3a5f;
    margin: 0 0 .15rem;
    text-transform: uppercase;
}
.cert-arc-wrap {
    text-align: center;
    margin-bottom: .3rem;
}
.cert-info-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: .3rem 1.5rem;
    font-size: .8rem;
    margin: .55rem 0 .65rem;
    padding: .5rem .9rem;
    background: #f8fafc;
    border-radius: 8px;
    border: 1px solid #e2e8f0;
    text-align: left;
}
.cert-info-grid .lbl { color: #64748b; font-size: .66rem; text-transform: uppercase; letter-spacing: .06em; }
.cert-info-grid .val { font-weight: 600; color: #0f172a; }
.cert-logo {
    display: block;
    margin: .2rem auto .4rem;
    height: 52px;
    width: auto;
    border-radius: 8px;
}
.cert-logo-fallback {
    width: 52px; height: 52px;
    border-radius: 50%;
    background: linear-gradient(135deg,#1e3a5f,#2563eb);
    color: #fff;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.5rem;
    margin: .2rem auto .4rem;
}
.cert-title {
    font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif;
    text-align: center;
    font-size: 1.1rem;
    font-weight: 700;
    letter-spacing: 2.5px;
    text-transform: uppercase;
    color: #1e3a5f;
    border-top: 1.5px solid #b89a4e;
    border-bottom: 1.5px solid #b89a4e;
    padding: .3rem 0;
    margin: .4rem 0 .55rem;
}
.cert-subtitle {
    text-align: center;
    color: #6b7280;
    font-size: .82rem;
    margin-bottom: .5rem;
    font-style: italic;
}
.cert-student-name {
    font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif;
    text-align: center;
    font-size: 1.3rem;
    font-weight: 700;
    color: #1e3a5f;
    border-bottom: 2px solid #b89a4e;
    display: inline-block;
    padding: 0 1.5rem .15rem;
    margin: 0 auto .2rem;
    letter-spacing: 1px;
}
.cert-admission {
    text-align: center;
    color: #6b7280;
    font-size: .8rem;
    margin-bottom: .6rem;
}
/* Totals row lives inside <tfoot> of .cert-table itself, so its cells sit
   in the exact same columns as the Obtained/Total/%/Grade cells above it.
   Spacer row, total row, and the result line below all share the same
   cream background so they read as one connected block, separate from
   the white/striped subject rows above. */
.cert-table tfoot tr.cert-spacer-row td {
    padding: 0;
    height: 36px;
    border: 0;
    background: #fff !important;
}
.cert-table tfoot tr.cert-total-row td {
    background: #f8f5ec !important;
    border-top: 3px solid #1e3a5f;
    border-bottom: none;
    padding: .5rem .65rem;
    font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif;
    font-weight: 700;
    color: #1e3a5f !important;
}
.cert-table tfoot tr.cert-total-row td.cert-total-label {
    text-transform: uppercase;
    letter-spacing: 1px;
    font-size: .68rem;
    color: #64748b !important;
    font-weight: 700;
}
.cert-result-line {
    text-align: center;
    margin: 0 0 .8rem;
    padding: .5rem .9rem;
    background: #f8f5ec;
    border-radius: 8px;
    border: 0px solid #e9e0c5;
}
.cert-result-badge {
    font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif;
    font-size: 1.15rem;
    font-weight: 800;
    letter-spacing: 1.5px;
}
.cert-result-extra {
    margin-top: .2rem;
    font-size: .68rem;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: #9ca3af;
}
.cert-table {
    width: 100%;
    border-collapse: collapse;
    font-size: .8rem;
    margin-bottom: 0;
    color: #0f172a;
}
.cert-table th {
    font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif;
    background: #1e3a5f !important;
    color: #fff !important;
    padding: .32rem .65rem;
    text-align: left;
    font-size: .7rem;
    letter-spacing: .6px;
    text-transform: uppercase;
}
.cert-table td {
    padding: .28rem .65rem;
    border-bottom: 1px solid #f0e9d6;
    color: #0f172a !important;
    background: #fff;
}
.cert-table tr:nth-child(even) td { background: #faf7f0 !important; color: #0f172a !important; }
.cert-table tr.cert-row-fail td { color: #9f1239 !important; }
.cert-table strong { color: inherit !important; }
.cert-grade-badge {
    display: inline-block;
    padding: 1px 8px;
    border-radius: 20px;
    font-size: .7rem;
    font-weight: 700;
    background: #1e3a5f;
    color: #fff !important;
}
.cert-footer {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    margin-top: auto;
    padding-top: .6rem;
    border-top: 1px solid #e5e7eb;
    font-size: .74rem;
    color: #6b7280;
}
.cert-sig { text-align: center; }
.cert-sig-line { border-top: 1.5px solid #374151; width: 130px; margin: 0 auto .25rem; }
.cert-seal {
    width: 52px; height: 52px;
    border-radius: 50%;
    border: 3px dashed #b89a4e;
    display: flex; align-items: center; justify-content: center;
    color: #b89a4e; font-size: .6rem; text-align: center;
    padding: 5px;
}

/* ---- Print styles ---- */
@page { size: A4; margin: 10mm; }
@media print {
    .cert-controls, .navbar, aside, nav, .sms-no-print { display: none !important; }
    /* app.css sets html's background to the dashboard's dark theme color
       (--sms-bg) site-wide, and that rule isn't scoped to screen-only —
       resetting just <body> here left <html> dark, so any stray overflow
       onto a second page (even a few px, e.g. from .cert-page's own border)
       showed that dark background filling the whole page instead of white. */
    html, body, .app-shell, .app-shell__main, main {
        background: #fff !important;
    }
    .cert-page { box-shadow: none; border-radius: 0; max-width: 100%; }
    * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
}
</style>

<!-- Controls (hidden on print) -->
<div class="cert-controls sms-no-print">
    <div class="d-flex align-items-center justify-content-between mb-3">
        <div>
            <h1 class="h4 mb-0">Report Card / Certificate</h1>
            <div class="text-muted small">Search a student by name or admission no., then pick an exam.</div>
        </div>
        <a class="btn btn-outline-secondary" href="<?= h(route_url('academic/index')) ?>">Back</a>
    </div>
    <div class="card shadow-sm border-0 mb-3 sms-search-card" style="overflow:visible !important;">
        <div class="card-body" style="overflow:visible;">
            <form method="get" action="<?= h(base_url('/index.php')) ?>" id="certForm">
                <input type="hidden" name="route" value="academic/certificate">
                <input type="hidden" name="student_id" id="certStudentId" value="<?= (int)$studentId ?>">

                <!-- Controls stay on their own row so search results never push them -->
                <div class="row g-2 align-items-end mb-3">
                    <div class="col-md-4">
                        <label class="form-label">Filter by Class</label>
                        <select class="form-select" name="class_section_id" id="certClassFilter" onchange="this.form.submit()">
                            <option value="0">All classes</option>
                            <?php foreach (($classSections ?? []) as $cs): ?>
                                <option value="<?= (int)$cs['id'] ?>" <?= (int)($classSectionId ?? 0) === (int)$cs['id'] ? 'selected' : '' ?>>
                                    <?= h(($cs['class_name'] ?? '') . ' — ' . ($cs['section_name'] ?? '')) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-5">
                        <label class="form-label">Exam</label>
                        <select class="form-select" name="exam_id" required>
                            <?php foreach ($exams as $e): ?>
                                <?php
                                $cls = trim(($e['class_name'] ?? '') . ' ' . ($e['section_name'] ?? ''));
                                $label = $e['exam_name'] ?? '';
                                if ($cls !== '') { $label .= ' [' . $cls . ']'; }
                                ?>
                                <option value="<?= (int)$e['id'] ?>" <?= ((int)$examId === (int)$e['id']) ? 'selected' : '' ?>>
                                    <?= h($label) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3 d-grid gap-1">
                        <button class="btn btn-primary" type="submit">Load</button>
                        <?php if ($student): ?>
                            <button class="btn btn-success" type="button" onclick="printReportCard()">
                                <i class="bi bi-printer me-1"></i>Print
                            </button>
                        <?php endif; ?>
                        <?php if (!empty($whatsappRecipients) && count($whatsappRecipients) === 1): ?>
                            <a class="btn btn-success js-wa-share" href="<?= h($whatsappRecipients[0]['url']) ?>" target="_blank" rel="noopener">
                                <i class="bi bi-whatsapp me-1"></i>Send via WhatsApp
                            </a>
                        <?php elseif (!empty($whatsappRecipients)): ?>
                            <div class="btn-group">
                                <button type="button" class="btn btn-success dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="bi bi-whatsapp me-1"></i>Send via WhatsApp
                                </button>
                                <ul class="dropdown-menu">
                                    <?php foreach ($whatsappRecipients as $rec): ?>
                                        <li><a class="dropdown-item js-wa-share" href="<?= h($rec['url']) ?>" target="_blank" rel="noopener"><?= h($rec['label']) ?></a></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-8 col-lg-6">
                        <label class="form-label fw-semibold">Search Student</label>
                        <div class="position-relative" style="z-index:20;">
                            <input type="text" id="certSearchInput" class="form-control" autocomplete="off"
                                   placeholder="Type name or admission number…"
                                   value="<?= $student ? h(trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''))) : '' ?>">
                            <div id="certDropdown"
                                 style="display:none;position:absolute;z-index:4000;top:100%;left:0;right:0;
                                        background:#fff;border:1px solid #dee2e6;border-radius:0 0 .5rem .5rem;
                                        max-height:280px;overflow-y:auto;box-shadow:0 12px 28px rgba(15,23,42,.18);"></div>
                        </div>
                        <?php if ($student): ?>
                        <div class="small text-success mt-1">
                            <i class="bi bi-check-circle"></i>
                            <strong><?= h(trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''))) ?></strong>
                            &nbsp;|&nbsp; Adm: <?= h($student['admission_no'] ?? '') ?>
                            &nbsp;|&nbsp; <?= h(trim(($student['current_class_name'] ?? '') . ' ' . ($student['current_section_name'] ?? ''))) ?>
                            &mdash; <a href="<?= h(base_url('/index.php?route=academic/certificate')) ?>" class="text-muted small">Clear</a>
                        </div>
                        <?php else: ?>
                        <div class="small text-muted mt-1" id="certSearchHint">
                            <?= ((int)($classSectionId ?? 0) > 0) ? 'Click the search box to browse this class, or type to search.' : 'Select a class above to browse its students, or type a name / admission no.' ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
(function () {
    const input    = document.getElementById('certSearchInput');
    const dropdown = document.getElementById('certDropdown');
    const studentIdField = document.getElementById('certStudentId');
    const classFilter = document.getElementById('certClassFilter');
    const form = document.getElementById('certForm');
    const searchUrl = <?= json_encode(base_url('/index.php?route=students/searchJson&scope=report_card&q=')) ?>;
    let timer;

    function classParam() {
        const cs = classFilter ? classFilter.value : '0';
        return (cs && cs !== '0') ? ('&class_section_id=' + encodeURIComponent(cs)) : '';
    }

    function hasClassSelected() {
        return !!(classFilter && classFilter.value && classFilter.value !== '0');
    }

    // With no class picked and no typed text, there's nothing sensible to
    // list (every student in the school), so we require one or the other.
    function runSearch(q) {
        if (q.length === 0 && !hasClassSelected()) {
            dropdown.innerHTML = '<div style="padding:.6rem 1rem;color:#6c757d;font-size:.85rem;">Select a class above to browse its students, or type to search.</div>';
            dropdown.style.display = 'block';
            return;
        }

        fetch(searchUrl + encodeURIComponent(q) + classParam())
            .then(r => r.json())
            .then(data => {
                dropdown.innerHTML = '';
                if (!data.results || data.results.length === 0) {
                    dropdown.innerHTML = '<div style="padding:.6rem 1rem;color:#6c757d;font-size:.85rem;">No students found</div>';
                    dropdown.style.display = 'block';
                    return;
                }
                data.results.forEach(st => {
                    const row = document.createElement('button');
                    row.type = 'button';
                    row.style.cssText = 'display:flex;flex-direction:column;width:100%;text-align:left;padding:.55rem 1rem;border:0;background:#fff;border-bottom:1px solid #f1f3f5;cursor:pointer;';
                    row.onmouseover = () => row.style.background = '#f0f4ff';
                    row.onmouseout  = () => row.style.background = '#fff';
                    row.innerHTML   = `
                        <span style="font-weight:600;font-size:.9rem;">${st.name}</span>
                        <span style="font-size:.78rem;color:#6c757d;margin-top:2px;">
                            ID #${st.id} &nbsp;|&nbsp; Adm: ${st.admission_no} &nbsp;|&nbsp; ${st.class || '<em>Unassigned</em>'}
                        </span>`;
                    row.addEventListener('click', () => {
                        studentIdField.value = st.id;
                        input.value = st.name;
                        dropdown.style.display = 'none';
                        form.submit();
                    });
                    dropdown.appendChild(row);
                });
                dropdown.style.display = 'block';
            })
            .catch(() => { dropdown.style.display = 'none'; });
    }

    input?.addEventListener('input', function () {
        clearTimeout(timer);
        const q = this.value.trim();
        studentIdField.value = '';
        timer = setTimeout(() => runSearch(q), 260);
    });

    // Clicking into an empty box immediately browses the selected class,
    // instead of forcing the user to type first.
    input?.addEventListener('focus', function () {
        const q = this.value.trim();
        if (q.length === 0) { runSearch(''); }
    });

    document.addEventListener('click', e => {
        if (!dropdown.contains(e.target) && e.target !== input) {
            dropdown.style.display = 'none';
        }
    });
})();
</script>

<?php if ($student): ?>
<?php
$fullName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
$className = trim((string)($student['current_class_name'] ?? ''));
$sectionName = trim((string)($student['current_section_name'] ?? ''));
$rollNo = (int)($student['roll_number'] ?? 0);
$totalObtained = 0.0;
$totalMaxMarks = 0.0;
foreach ($studentMarks as $m) {
    $totalObtained += (float)($m['score'] ?? 0);
    $subTot = (float)($m['total_marks'] ?? 100);
    $totalMaxMarks += ($subTot > 0 ? $subTot : 100.0);
}
$overallPercentage = $totalMaxMarks > 0 ? round($totalObtained / $totalMaxMarks * 100, 1) : 0.0;
$examName = '';
foreach ($exams as $e) {
    if ((int)$e['id'] === (int)$examId) {
        $examName = $e['exam_name'] ?? '';
        break;
    }
}
?>
<div class="cert-print-scale-wrap" id="certScaleWrap">
<div class="cert-page">
  <div class="cert-outer-border">

    <h1 class="cert-school-title"><?= h($schoolName) ?></h1>

    <?php if ($logoPath): ?>
        <img src="<?= htmlspecialchars(base_url($logoPath), ENT_QUOTES, 'UTF-8') ?>" alt="School Logo" class="cert-logo">
    <?php else: ?>
        <div class="cert-logo-fallback"><i class="bi bi-mortarboard-fill"></i></div>
    <?php endif; ?>

    <div class="cert-title">Student Report Card</div>
    <div class="cert-subtitle">
        <?= h($examName) ?> &nbsp;|&nbsp; Academic Year <?= date('Y') ?>
    </div>

    <div class="cert-info-grid">
        <div>
            <div class="lbl">Student name</div>
            <div class="val"><?= h($fullName) ?></div>
        </div>
        <div>
            <div class="lbl">Father's name</div>
            <div class="val"><?= !empty($student['father_name']) ? h($student['father_name']) : '—' ?></div>
        </div>
        <div>
            <div class="lbl">Class</div>
            <div class="val"><?= $className !== '' ? h($className) : '—' ?></div>
        </div>
        <div>
            <div class="lbl">Section</div>
            <div class="val"><?= $sectionName !== '' ? h($sectionName) : '—' ?></div>
        </div>
        <div>
            <div class="lbl">Roll number</div>
            <div class="val"><?= $rollNo > 0 ? h((string)$rollNo) : '—' ?></div>
        </div>
        <div>
            <div class="lbl">Admission no.</div>
            <div class="val"><?= h($student['admission_no'] ?? '') ?></div>
        </div>
        <div>
            <div class="lbl">Student ID</div>
            <div class="val"><?= (int)$student['id'] ?></div>
        </div>
    </div>

    <?php $breakdown = $breakdown ?? []; ?>
    <table class="cert-table">
        <thead>
            <?php if (!empty($combinedWith) && !empty($breakdown)): ?>
            <tr>
                <th>#</th>
                <th>Subject</th>
                <th><?= h($combinedWith) ?></th>
                <th><?= h($examName) ?></th>
                <th>Final Result</th>
                <th>Total</th>
                <th>%</th>
                <th>Grade</th>
            </tr>
            <?php else: ?>
            <tr>
                <th>#</th>
                <th>Subject</th>
                <th>Obtained</th>
                <th>Total</th>
                <th>%</th>
                <th>Grade</th>
            </tr>
            <?php endif; ?>
        </thead>
        <tbody>
            <?php if (empty($studentMarks)): ?>
                <tr><td colspan="8" style="text-align:center;color:#9ca3af;padding:1.5rem;">No marks recorded for this exam.</td></tr>
            <?php else: ?>
                <?php foreach ($studentMarks as $i => $m): ?>
                    <?php
                    $score    = (float)($m['score'] ?? 0);
                    $subTotal = (float)($m['total_marks'] ?? 100);
                    $subTotal = $subTotal > 0 ? $subTotal : 100.0;
                    $pct      = round($score / $subTotal * 100, 1);
                    $bd = $breakdown[$m['subject_id']] ?? null;
                    ?>
                    <tr class="<?= empty($m['is_pass']) ? 'cert-row-fail' : '' ?>">
                        <td><?= $i + 1 ?></td>
                        <td><?= h($m['subject_name'] ?? '') ?></td>
                        <?php if (!empty($combinedWith) && !empty($breakdown)): ?>
                            <td><?= h(format_mark($bd['source']['score'] ?? 0)) ?></td>
                            <td><?= h(format_mark($bd['own']['score'] ?? 0)) ?></td>
                            <td><strong><?= h(format_mark($score)) ?></strong></td>
                        <?php else: ?>
                            <td><strong><?= h(format_mark($score)) ?></strong></td>
                        <?php endif; ?>
                        <td><?= h(format_mark($subTotal)) ?></td>
                        <td><?= h(format_mark($pct)) ?>%</td>
                        <td><span class="cert-grade-badge"><?= h($m['grade_letter'] ?? '—') ?></span></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
        <?php if (!empty($studentMarks)): ?>
        <tfoot>
            <?php if (!empty($combinedWith) && !empty($breakdown)): ?>
                <?php /* 8 cols: #, Subject, combinedWith, examName, Final Result, Total, %, Grade */ ?>
                <tr class="cert-spacer-row"><td colspan="8"></td></tr>
                <tr class="cert-total-row">
                    <td class="cert-total-label" colspan="4">Total</td>
                    <td><?= h(format_mark($totalObtained)) ?></td>
                    <td><?= h(format_mark($totalMaxMarks)) ?></td>
                    <td><?= h(format_mark($overallPercentage)) ?>%</td>
                    <td><?= h((string)($overallGrade ?? '—')) ?></td>
                </tr>
            <?php else: ?>
                <?php /* 6 cols: #, Subject, Obtained, Total, %, Grade */ ?>
                <tr class="cert-spacer-row"><td colspan="6"></td></tr>
                <tr class="cert-total-row">
                    <td class="cert-total-label" colspan="2">Total</td>
                    <td><?= h(format_mark($totalObtained)) ?></td>
                    <td><?= h(format_mark($totalMaxMarks)) ?></td>
                    <td><?= h(format_mark($overallPercentage)) ?>%</td>
                    <td><?= h((string)($overallGrade ?? '—')) ?></td>
                </tr>
            <?php endif; ?>
        </tfoot>
        <?php endif; ?>
    </table>

    <?php if (!empty($resultStatus) || !empty($studentRank) || !empty($isSchoolTopper)): ?>
    <?php
    $resultColor = $resultStatus === 'PASS' ? '#15803d'
        : ($resultStatus === 'PROMOTE' ? '#1d4ed8'
        : ($resultStatus === 'INCOMPLETE' ? '#a16207' : '#b91c1c'));
    $resultLabelText = $resultStatus === 'PROMOTE' ? 'PROMOTED' : $resultStatus;
    ?>
    <div class="cert-result-line">
        <?php if (!empty($resultStatus)): ?>
        <div class="cert-result-badge" style="color:<?= $resultColor ?>"><?= h((string)$resultLabelText) ?></div>
        <?php endif; ?>
        <?php if (!empty($studentRank) || !empty($isSchoolTopper)): ?>
        <div class="cert-result-extra">
            <?php
            $extras = [];
            if (!empty($studentRank)) { $extras[] = h(ordinal((int)$studentRank)) . ' Position'; }
            if (!empty($isSchoolTopper)) { $extras[] = '🏆 Whole-School Topper'; }
            echo implode(' &nbsp;·&nbsp; ', $extras);
            ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if (!empty($combinedWith)): ?>
    <div style="text-align:center;font-size:.7rem;color:#9ca3af;margin:-.6rem 0 .8rem;">Combined result: <?= h($combinedWith) ?> + <?= h($examName ?? '') ?></div>
    <?php endif; ?>

    <div class="cert-footer">
        <div class="cert-sig">
            <div class="cert-sig-line"></div>
            <div>Teacher signature</div>
        </div>
        <div class="cert-seal">OFFICIAL<br>SEAL</div>
        <div class="cert-sig">
            <div class="cert-sig-line"></div>
            <div>Principal signature</div>
        </div>
    </div>
    <div style="text-align:center;font-size:.8rem;color:#475569;margin-top:.6rem;">
        <strong>Date:</strong> <?= date('d F Y') ?>
    </div>
    <div style="text-align:center;font-size:.7rem;color:#9ca3af;margin-top:.35rem;">
        <?= h($schoolName) ?> — Confidential academic record
    </div>

  </div><!-- outer border -->
</div><!-- cert-page -->
</div><!-- cert-print-scale-wrap -->
<script>
// Called directly by the Print button (not by a beforeprint listener) so it
// does not depend on the browser firing beforeprint at all -- iOS Safari and
// many Android Chrome/WebView builds fire beforeprint unreliably or not at
// all, which is why this used to overflow onto a second page on phones even
// though it printed fine on desktop.
function printReportCard() {
    if (typeof window.fitReportCardToPage === 'function') { window.fitReportCardToPage(); }
    // Give the browser a couple of frames to actually paint the transform
    // before the print snapshot is taken -- on some mobile browsers, a
    // style change applied in the same tick as window.print() isn't
    // reflected in the printed output yet.
    requestAnimationFrame(function () {
        requestAnimationFrame(function () {
            window.print();
        });
    });
}
(function () {
    var scaleWrap = document.getElementById('certScaleWrap');
    var page = scaleWrap ? scaleWrap.querySelector('.cert-page') : null;
    if (!scaleWrap || !page) { return; }

    // A4 printable width/height in CSS reference px, after the @page margin
    // above (10mm each side). 96px = 1in, 25.4mm = 1in -- fixed CSS
    // constants, not tied to the actual screen/printer DPI.
    var PAGE_WIDTH_PX  = (210 - 20) * (96 / 25.4);
    var PAGE_HEIGHT_PX = (297 - 20) * (96 / 25.4);

    function fitToOnePage() {
        // Always measure from a clean, unscaled state.
        page.style.transform = 'none';
        page.style.width = '';
        scaleWrap.style.height = '';
        scaleWrap.style.overflow = '';

        // On a phone the page normally renders at the phone's narrow screen
        // width (the on-screen view is responsive to fit small screens),
        // but printing renders at the full A4 content width. Measuring
        // height at the phone's narrow on-screen width gives the wrong
        // number and produces the wrong scale (or no scale at all), so we
        // force the actual print-time width here before measuring, then
        // restore it below.
        page.style.width = PAGE_WIDTH_PX + 'px';
        var naturalHeight = page.offsetHeight;

        if (naturalHeight > PAGE_HEIGHT_PX) {
            var scale = PAGE_HEIGHT_PX / naturalHeight;
            page.style.transformOrigin = 'top center';
            page.style.transform = 'scale(' + scale + ')';
            scaleWrap.style.height = (naturalHeight * scale) + 'px';
            scaleWrap.style.overflow = 'hidden';
        }
    }
    window.fitReportCardToPage = fitToOnePage;

    function resetFit() {
        page.style.transform = 'none';
        page.style.width = '';
        scaleWrap.style.height = '';
        scaleWrap.style.overflow = '';
    }

    // Fallback for print triggered outside our button (Ctrl+P, browser
    // menu, share-sheet print) on browsers that DO support these events.
    window.addEventListener('beforeprint', fitToOnePage);
    window.addEventListener('afterprint', resetFit);
    // afterprint has the same reliability problem as beforeprint, especially
    // on iOS, so also reset once the tab is visible again -- covers
    // "cancelled the print dialog" on browsers that never fire afterprint.
    document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible') { resetFit(); }
    });
})();
</script>

<?php endif; ?>