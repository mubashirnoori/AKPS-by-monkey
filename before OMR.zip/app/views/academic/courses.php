<?php
// Variables: $courses, $courseToEdit, $error
$courseToEdit = $courseToEdit ?? null;
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Online Courses</h1>
        <div class="text-muted">Create courses and assign them to specific students. Students only see courses assigned to them.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <h2 class="h6 mb-3"><?= $courseToEdit ? 'Edit Course' : 'Create Course' ?></h2>
        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=academic/courses'), ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
            <input type="hidden" name="id" value="<?= $courseToEdit ? (int)$courseToEdit['id'] : '' ?>">
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Title *</label>
                    <input class="form-control" name="title" value="<?= h($courseToEdit['title'] ?? '') ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Resource URL</label>
                    <input class="form-control" name="resource_url" placeholder="https://…" value="<?= h($courseToEdit['resource_url'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Description</label>
                    <input class="form-control" name="description" value="<?= h($courseToEdit['description'] ?? '') ?>">
                </div>
            </div>
            <div class="mt-3 d-flex gap-2">
                <button class="btn btn-primary" type="submit"><?= $courseToEdit ? 'Update' : 'Create' ?></button>
                <?php if ($courseToEdit): ?>
                    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/courses'), ENT_QUOTES, 'UTF-8') ?>">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <h2 class="h6 mb-3">Course List</h2>
        <div class="table-responsive">
            <table class="table table-sm table-striped mb-0">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Assigned Students</th>
                        <th style="width: 260px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($courses as $c): ?>
                    <tr>
                        <td class="fw-semibold"><?= h($c['title'] ?? '') ?></td>
                        <td class="text-muted small"><?= h($c['description'] ?? '') ?></td>
                        <td><span class="badge text-bg-info"><?= (int)($c['assigned_count'] ?? 0) ?></span></td>
                        <td class="d-flex gap-2">
                            <a class="btn btn-sm btn-outline-danger" href="<?= htmlspecialchars(base_url('/index.php?route=academic/courseResources&course_id=' . (int)$c['id']), ENT_QUOTES, 'UTF-8') ?>">Resources</a>
                            <a class="btn btn-sm btn-outline-primary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/courseAssign&course_id=' . (int)$c['id']), ENT_QUOTES, 'UTF-8') ?>">Assign</a>
                            <a class="btn btn-sm btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/courses&id=' . (int)$c['id']), ENT_QUOTES, 'UTF-8') ?>">Edit</a>
                            <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=academic/courses'), ENT_QUOTES, 'UTF-8') ?>" onsubmit="return confirm('Delete this course?')">
                                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                                <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($courses)): ?>
                    <tr><td colspan="4" class="text-muted">No courses yet.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
