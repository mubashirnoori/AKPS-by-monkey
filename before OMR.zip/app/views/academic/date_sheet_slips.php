<?php
// Variables: $exam, $examId, $scope, $perPageChoice, $blocks, $skipped
$blocks = $blocks ?? [];
$skipped = $skipped ?? [];

$schoolName = 'School';
$logoPath = '';
try {
    $map = [];
    foreach (Database::fetchAll('SELECT `key`, `value` FROM settings') as $r) {
        $map[$r['key']] = $r['value'];
    }
    $schoolName = $map['branding_school_name'] ?? $map['institute_name'] ?? 'School';
    $logoPath = $map['branding_logo_path'] ?? '';
} catch (Throwable $e) {
}

$fmtDate = function ($d) {
    $ts = $d ? strtotime((string)$d) : false;
    return $ts === false ? '—' : date('D, j M Y', $ts);
};
$fmtTime = function ($a, $b) {
    if (empty($a)) {
        return '—';
    }
    return substr((string)$a, 0, 5) . (!empty($b) ? ' – ' . substr((string)$b, 0, 5) : '');
};
$totalSlips = array_sum(array_map(fn($b) => count($b['students']), $blocks));
$backUrl = base_url('/index.php?route=academic/dateSheet&exam_id=' . (int)$examId);
?>
<style>
@page { size: A4; margin: 8mm; }

.dss-controls { max-width: 900px; margin: 0 auto 1rem; }
.dss-page {
    width: 194mm; height: 281mm; margin: 0 auto 12px; background: #fff; color: #1f2937;
    display: grid; gap: 3mm; box-sizing: border-box; page-break-after: always; break-after: page;
    padding: 0; box-shadow: 0 2px 10px rgba(0,0,0,.35);
}
.dss-page:last-of-type { page-break-after: auto; break-after: auto; }
.dss-slip {
    border: 1px dashed #6b7280; padding: 2.5mm 3.5mm; overflow: hidden; box-sizing: border-box;
    display: flex; flex-direction: column; font-size: 9pt; line-height: 1.25; background: #fff; color: #1f2937;
}
.dss-head { display: flex; align-items: center; gap: 2.5mm; border-bottom: 1.2px solid #1f2937; padding-bottom: 1.5mm; }
.dss-head img { height: 9mm; width: auto; }
.dss-school { font-weight: 700; font-size: 10.5pt; }
.dss-sub { font-size: 8pt; color: #4b5563; }
.dss-student { display: grid; grid-template-columns: 1fr auto; gap: 0 4mm; margin: 1.8mm 0; font-size: 9pt; }
.dss-student b { font-size: 10pt; }
.dss-roll { font-weight: 700; font-size: 10pt; text-align: right; }
.dss-table { width: 100%; border-collapse: collapse; font-size: 8.5pt; }
.dss-table th { background: #1f2937 !important; color: #fff !important; text-align: left; padding: 1mm 1.6mm; font-size: 7.5pt; text-transform: uppercase; letter-spacing: .02em; }
.dss-table td { border: 1px solid #9ca3af; padding: 1mm 1.6mm; color: #1f2937; }
.dss-table tbody tr:nth-child(even) td { background: #f3f4f6 !important; }
.dss-sign { margin-top: auto; display: flex; justify-content: space-between; padding-top: 4mm; font-size: 7.5pt; color: #4b5563; }
.dss-sign span { border-top: 1px solid #4b5563; padding-top: .6mm; min-width: 32mm; text-align: center; }

@media print {
    .navbar, aside, nav, .dss-no-print { display: none !important; }
    html, body, .app-shell, .app-shell__main, main { background: #fff !important; margin: 0 !important; padding: 0 !important; }
    .container, main > .container { max-width: none !important; padding: 0 !important; margin: 0 !important; }
    .dss-page { margin: 0 !important; box-shadow: none !important; }
    * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
}
</style>

<div class="dss-controls dss-no-print">
    <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-2">
        <div>
            <h4 class="mb-0">Student Date Slips</h4>
            <div class="text-muted small">
                <?= (int)$totalSlips ?> slip(s) · <?= count($blocks) ?> class(es) ·
                <?= $scope === 'group' ? 'all classes in ' . h($exam['exam_group_name'] ?? '') : h(trim(($exam['class_name'] ?? '') . ' ' . ($exam['section_name'] ?? ''))) ?>
            </div>
        </div>
        <div class="d-flex gap-2">
            <a class="btn btn-outline-secondary" href="<?= h($backUrl) ?>">Back</a>
            <button class="btn btn-primary" type="button" onclick="window.print()">Print</button>
        </div>
    </div>
    <div class="text-muted small">Tip: in the print window choose paper size <strong>A4</strong>, scale <strong>100%</strong>, and turn <strong>Headers and footers</strong> off.</div>
    <?php foreach ($blocks as $b): if ($b['note'] !== ''): ?>
        <div class="alert alert-warning py-1 small mt-2 mb-0"><?= h($b['note']) ?></div>
    <?php endif; endforeach; ?>
    <?php if ($skipped): ?>
        <div class="alert alert-warning py-1 small mt-2 mb-0">Skipped: <?= h(implode('; ', $skipped)) ?></div>
    <?php endif; ?>
</div>

<?php if (!$blocks): ?>
    <div class="alert alert-light border text-muted dss-no-print">Nothing to print. Set the subject dates on the Date Sheet page first.</div>
<?php endif; ?>

<?php foreach ($blocks as $b):
    $ex = $b['exam'];
    foreach (array_chunk($b['students'], $b['per_page']) as $pageStudents): ?>
    <div class="dss-page" style="grid-template-columns: repeat(<?= (int)$b['cols'] ?>, 1fr); grid-template-rows: repeat(<?= (int)$b['rows_per_page'] ?>, 1fr);">
        <?php foreach ($pageStudents as $st):
            $name = trim(($st['first_name'] ?? '') . ' ' . ($st['last_name'] ?? ''));
            $roll = (int)($st['roll_number'] ?? 0); ?>
        <div class="dss-slip">
            <div class="dss-head">
                <?php if ($logoPath !== ''): ?><img src="<?= h(base_url($logoPath)) ?>" alt=""><?php endif; ?>
                <div>
                    <div class="dss-school"><?= h($schoolName) ?></div>
                    <div class="dss-sub"><?= h($ex['exam_name'] ?? '') ?> · Date Sheet<?= !empty($ex['academic_year_label']) ? ' · ' . h($ex['academic_year_label']) : '' ?></div>
                </div>
            </div>
            <div class="dss-student">
                <div><b><?= h($name) ?></b><?= !empty($st['father_name']) ? '<br><span class="dss-sub">' . (($st['gender'] ?? '') === 'F' ? 'D/O' : ((($st['gender'] ?? '') === 'M') ? 'S/O' : 'Child of')) . ' ' . h($st['father_name']) . '</span>' : '' ?></div>
                <div class="dss-roll">Roll No: <?= $roll > 0 ? (int)$roll : '—' ?><br><span class="dss-sub" style="font-weight:400;">Class: <?= h($b['class_label']) ?></span></div>
            </div>
            <table class="dss-table">
                <thead><tr><th>Subject</th><th>Date</th><th>Time</th></tr></thead>
                <tbody>
                <?php foreach ($b['rows'] as $r): ?>
                    <tr><td><b><?= h($r['subject_name']) ?></b></td><td><?= h($fmtDate($r['scheduled_date'])) ?></td><td><?= h($fmtTime($r['start_time'], $r['end_time'])) ?></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <div class="dss-sign"><span>Class Teacher</span><span>Principal</span></div>
        </div>
        <?php endforeach; ?>
    </div>
<?php endforeach; endforeach; ?>
