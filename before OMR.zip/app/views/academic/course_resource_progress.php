<?php
// Variables: $course, $resource, $progress
$progress = $progress ?? [];
$total = count($progress);
$completed = 0;
foreach ($progress as $p) {
    if (!empty($p['completed_at'])) {
        $completed++;
    }
}
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Watch Progress: <?= h($resource['title'] ?? '') ?></h1>
        <div class="text-muted"><?= h($course['title'] ?? '') ?></div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/courseResources&course_id=' . (int)($course['id'] ?? 0)), ENT_QUOTES, 'UTF-8') ?>">Back to Resources</a>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-4">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="text-muted small">Assigned Students</div>
                <div class="h3 mb-0"><?= $total ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="text-muted small">Completed (95%+)</div>
                <div class="h3 mb-0 text-success"><?= $completed ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="text-muted small">Not Started</div>
                <?php
                $notStarted = 0;
                foreach ($progress as $p) {
                    if ((float)($p['progress_percent'] ?? 0) <= 0) { $notStarted++; }
                }
                ?>
                <div class="h3 mb-0 text-muted"><?= $notStarted ?></div>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-striped mb-0">
                <thead>
                    <tr>
                        <th>Student</th>
                        <th style="width:260px;">Watched</th>
                        <th>Last Updated</th>
                        <th>Completed</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($progress as $p): $pct = round((float)($p['progress_percent'] ?? 0), 1); ?>
                    <tr>
                        <td>
                            <div class="fw-semibold"><?= h(trim(($p['first_name'] ?? '') . ' ' . ($p['last_name'] ?? ''))) ?></div>
                            <div class="text-muted small"><?= h($p['admission_no'] ?? '') ?></div>
                        </td>
                        <td>
                            <div class="progress" style="height: 18px;">
                                <div class="progress-bar <?= $pct >= 95 ? 'bg-success' : ($pct > 0 ? 'bg-info' : 'bg-secondary') ?>" style="width: <?= $pct ?>%;"><?= $pct ?>%</div>
                            </div>
                        </td>
                        <td class="text-muted small"><?= h($p['updated_at'] ?? '—') ?></td>
                        <td><?= !empty($p['completed_at']) ? '<span class="badge text-bg-success">Yes</span>' : '<span class="badge text-bg-secondary">No</span>' ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($progress)): ?>
                    <tr><td colspan="4" class="text-muted">No students assigned to this course yet.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
