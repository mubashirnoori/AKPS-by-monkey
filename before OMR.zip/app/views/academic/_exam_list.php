<?php
// Variables: $exams, $examsUrl, $examPage, $examTotalPages
$examPage = $examPage ?? 1;
$examTotalPages = $examTotalPages ?? 1;
?>
<div class="table-responsive">
    <table class="table table-sm table-striped mb-0 align-middle">
        <thead>
            <tr>
                <th>Exam</th>
                <th>Group</th>
                <th>Class</th>
                <th>Date</th>
                <th>Time</th>
                <th>Total Marks</th>
                <th>Results</th>
                <th style="width: 160px;">Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php if (empty($exams)): ?>
            <tr><td colspan="8" class="text-muted">No exams created.</td></tr>
        <?php else: ?>
            <?php foreach ($exams as $e): ?>
                <?php
                $startDisp = !empty($e['start_time']) ? substr((string)$e['start_time'], 0, 5) : '';
                $endDisp = !empty($e['end_time']) ? substr((string)$e['end_time'], 0, 5) : '';
                $isPublished = !empty($e['results_published']);
                ?>
                <tr>
                    <td>
                        <?= h($e['exam_name'] ?? '') ?>
                        <?php if (!empty($e['cumulative_source_exam_name'])): ?>
                            <br><span class="badge text-bg-primary-subtle text-primary-emphasis" style="font-weight:500;">+ <?= h($e['cumulative_source_exam_name']) ?></span>
                        <?php endif; ?>
                    </td>
                    <td><?= h(($e['exam_type_name'] ?? '') . ' / ' . ($e['exam_group_name'] ?? '')) ?></td>
                    <td class="text-muted"><?= h(($e['class_name'] ?? '') . ' ' . ($e['section_name'] ?? '')) ?></td>
                    <td><?= h($e['scheduled_date'] ?? '') ?></td>
                    <td><?= h($startDisp !== '' || $endDisp !== '' ? ($startDisp . ' - ' . $endDisp) : '') ?></td>
                    <td><?= !empty($e['total_marks']) ? (int)$e['total_marks'] : '<span class="text-muted">—</span>' ?></td>
                    <td>
                        <?php if ($isPublished): ?>
                            <span class="badge text-bg-success">Published</span>
                        <?php else: ?>
                            <span class="badge text-bg-secondary">Not published</span>
                        <?php endif; ?>
                        <form method="post" action="<?= htmlspecialchars($examsUrl, ENT_QUOTES, 'UTF-8') ?>" class="d-inline"
                              data-ajax data-target="#examListContainer"
                              <?= $isPublished ? '' : 'data-confirm="Publish results for this exam? Students and parents will immediately be able to see their marks."' ?>>
                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                            <input type="hidden" name="action" value="<?= $isPublished ? 'unpublish' : 'publish' ?>">
                            <input type="hidden" name="id" value="<?= (int)$e['id'] ?>">
                            <input type="hidden" name="exam_page" value="<?= (int)$examPage ?>">
                            <button class="btn btn-sm <?= $isPublished ? 'btn-outline-secondary' : 'btn-outline-success' ?> mt-1" type="submit">
                                <?= $isPublished ? 'Unpublish' : 'Publish Results' ?>
                            </button>
                        </form>
                    </td>
                    <td class="text-nowrap">
                        <button type="button" class="btn btn-sm btn-outline-primary"
                                data-bs-toggle="modal" data-bs-target="#editExamModal"
                                data-id="<?= (int)$e['id'] ?>"
                                data-exam-group-id="<?= (int)($e['exam_group_id'] ?? 0) ?>"
                                data-academic-year-id="<?= (int)($e['academic_year_id'] ?? 0) ?>"
                                data-class-section-id="<?= (int)($e['class_section_id'] ?? 0) ?>"
                                data-exam-name="<?= h($e['exam_name'] ?? '') ?>"
                                data-scheduled-date="<?= h($e['scheduled_date'] ?? '') ?>"
                                data-start-time="<?= h($startDisp) ?>"
                                data-end-time="<?= h($endDisp) ?>"
                                data-total-marks="<?= !empty($e['total_marks']) ? (int)$e['total_marks'] : '' ?>"
                                data-cumulative-source-exam-name="<?= h($e['cumulative_source_exam_name'] ?? '') ?>">
                            Edit
                        </button>
                        <form method="post" action="<?= htmlspecialchars($examsUrl, ENT_QUOTES, 'UTF-8') ?>"
                              class="d-inline" data-ajax data-target="#examListContainer" data-confirm="Delete this exam and its marks?">
                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= (int)$e['id'] ?>">
                            <input type="hidden" name="exam_page" value="<?= (int)$examPage ?>">
                            <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php if ($examTotalPages > 1): ?>
<nav class="mt-3">
    <ul class="pagination pagination-sm justify-content-center flex-wrap">
        <?php for ($p = 1; $p <= $examTotalPages; $p++): ?>
            <?php $pUrl = $examsUrl . '&page=' . $p; ?>
            <li class="page-item <?= $p === $examPage ? 'active' : '' ?>">
                <a class="page-link" href="<?= h($pUrl) ?>"><?= (int)$p ?></a>
            </li>
        <?php endfor; ?>
    </ul>
</nav>
<?php endif; ?>

