<?php
// Variables: $classes,$sections,$years,$mappings,$error
$classes = $classes ?? [];
$sections = $sections ?? [];
$years = $years ?? [];
$mappings = $mappings ?? [];
$staffOptions = $staffOptions ?? [];
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Class Sections</h1>
        <div class="text-muted">Create class-section combinations used by timetable and student allocation.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="row g-3 align-items-start mb-3">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-3">Create Class Section</h2>
                <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=academic/classSections'), ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">

                    <div class="mb-3">
                        <label class="form-label">Class *</label>
                        <select class="form-select" name="class_id" required>
                            <option value="">Choose...</option>
                            <?php foreach ($classes as $c): ?>
                                <option value="<?= (int)$c['id'] ?>"><?= h($c['name'] ?? '') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Section *</label>
                        <select class="form-select" name="section_id" required>
                            <option value="">Choose...</option>
                            <?php foreach ($sections as $s): ?>
                                <option value="<?= (int)$s['id'] ?>"><?= h($s['name'] ?? '') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Academic Year (optional)</label>
                        <select class="form-select" name="academic_year_id">
                            <option value="0">Leave blank</option>
                            <?php foreach ($years as $y): ?>
                                <option value="<?= (int)$y['id'] ?>">
                                    <?= h($y['academic_year_label'] ?? '') ?>
                                    <?php if (!empty($y['is_active'])): ?>
                                        (Active)
                                    <?php endif; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Start Date (optional)</label>
                            <input class="form-control" type="date" name="start_date">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">End Date (optional)</label>
                            <input class="form-control" type="date" name="end_date">
                        </div>
                    </div>

                    <button class="btn btn-primary w-100" type="submit">Create</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h2 class="h6 mb-0">Existing Combinations</h2>
                    <div class="text-muted small"><?= is_array($mappings) ? count($mappings) : 0 ?> total</div>
                </div>

                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0">
                        <thead>
                        <tr>
                            <th>Class</th>
                            <th>Section</th>
                            <th>Academic Year</th>
                            <th>Dates</th>
                            <th style="width: 220px;">Class Teacher <span class="text-muted fw-normal">(for attendance)</span></th>
                            <th style="width: 90px;">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($mappings)): ?>
                            <tr><td colspan="6" class="text-muted">No class sections found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($mappings as $m): ?>
                                <tr>
                                    <td class="fw-semibold"><?= h($m['class_name'] ?? '') ?></td>
                                    <td class="fw-semibold"><?= h($m['section_name'] ?? '') ?></td>
                                    <td><?= h($m['academic_year_label'] ?? '') ?></td>
                                    <td class="text-muted small">
                                        <?php if (!empty($m['start_date']) || !empty($m['end_date'])): ?>
                                            <?= h($m['start_date'] ?? '') ?> - <?= h($m['end_date'] ?? '') ?>
                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=academic/classTeacherAssign'), ENT_QUOTES, 'UTF-8') ?>" class="d-flex gap-1">
                                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                            <input type="hidden" name="class_section_id" value="<?= (int)($m['id'] ?? 0) ?>">
                                            <select class="form-select form-select-sm" name="class_teacher_staff_id">
                                                <option value="0">— None —</option>
                                                <?php foreach ($staffOptions as $st): ?>
                                                    <option value="<?= (int)$st['id'] ?>" <?= ((int)($m['class_teacher_staff_id'] ?? 0) === (int)$st['id']) ? 'selected' : '' ?>>
                                                        <?= h(($st['full_name'] ?? '') . ($st['title'] ? ' · ' . $st['title'] : '')) ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                            <button type="submit" class="btn btn-sm btn-outline-primary">Save</button>
                                        </form>
                                    </td>
                                    <td>
                                        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=academic/classSectionDelete'), ENT_QUOTES, 'UTF-8') ?>" class="d-inline" onsubmit="return confirm('Delete this class-section combination?')">
                                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                            <input type="hidden" name="id" value="<?= (int)($m['id'] ?? 0) ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>

