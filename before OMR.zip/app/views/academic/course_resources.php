<?php
// Variables: $course, $resources, $error
$resources = $resources ?? [];
$typeLabels = ['video' => 'Video Lecture', 'live_class' => 'Live Class', 'document' => 'Document', 'link' => 'Link'];
$typeBadge = ['video' => 'primary', 'live_class' => 'danger', 'document' => 'secondary', 'link' => 'info'];
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Resources: <?= h($course['title'] ?? '') ?></h1>
        <div class="text-muted">Add recorded lectures, scheduled live classes (Zoom/Meet links), documents, or reference links. Assigned students see these in order on their portal.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/courses'), ENT_QUOTES, 'UTF-8') ?>">Back to Courses</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <h2 class="h6 mb-3">Add Resource</h2>
        <form method="post" id="addResourceForm" action="<?= htmlspecialchars(base_url('/index.php?route=academic/courseResources&course_id=' . (int)$course['id']), ENT_QUOTES, 'UTF-8') ?>" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
            <input type="hidden" name="course_id" value="<?= (int)$course['id'] ?>">
            <input type="hidden" name="action" value="add">
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Title *</label>
                    <input class="form-control" name="title" placeholder="e.g. Week 1 — Introduction" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Type *</label>
                    <select class="form-select" name="resource_type" id="resourceType">
                        <option value="video">Video Lecture (recorded)</option>
                        <option value="live_class">Live Class (Zoom/Meet, scheduled)</option>
                        <option value="document">Document (PDF, notes)</option>
                        <option value="link">Reference Link</option>
                    </select>
                </div>
                <div class="col-md-5" id="sourceTypeWrap" style="display:none;">
                    <label class="form-label">Video Source *</label>
                    <div class="btn-group d-block" role="group">
                        <input type="radio" class="btn-check" name="source_type" id="sourceLink" value="link" checked>
                        <label class="btn btn-outline-secondary btn-sm" for="sourceLink">Paste a Link</label>
                        <input type="radio" class="btn-check" name="source_type" id="sourceUpload" value="upload">
                        <label class="btn btn-outline-secondary btn-sm" for="sourceUpload">Upload Video File</label>
                    </div>
                </div>

                <div class="col-md-5" id="urlFieldWrap">
                    <label class="form-label">URL</label>
                    <input class="form-control" name="resource_url" id="resourceUrlInput" placeholder="https://zoom.us/j/… or https://…">
                </div>
                <div class="col-md-5" id="fileFieldWrap" style="display:none;">
                    <label class="form-label">Video File</label>
                    <input class="form-control" type="file" name="video_file" id="videoFileInput" accept="video/mp4,video/webm,video/ogg,video/quicktime">
                    <div class="form-text">MP4, WebM, OGG, or MOV. Only uploaded videos get a watch-progress tracker — external links (YouTube etc.) can't be tracked.</div>
                </div>

                <div class="col-md-4">
                    <label class="form-label" id="scheduledLabel">Scheduled Date/Time <span class="text-muted small">(for a live class)</span></label>
                    <input class="form-control" type="datetime-local" name="scheduled_at">
                </div>
                <div class="col-md-8">
                    <label class="form-label">Description</label>
                    <input class="form-control" name="description" placeholder="Optional notes for students">
                </div>
            </div>
            <div id="uploadProgressWrap" class="mt-3" style="display:none;">
                <div class="d-flex justify-content-between small mb-1">
                    <span id="uploadProgressLabel">Uploading…</span>
                    <span id="uploadProgressPct">0%</span>
                </div>
                <div class="progress" style="height:10px;">
                    <div id="uploadProgressBar" class="progress-bar progress-bar-striped progress-bar-animated" style="width:0%;"></div>
                </div>
            </div>

            <div class="mt-3">
                <button class="btn btn-primary" type="submit" id="addResourceSubmitBtn">Add Resource</button>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <h2 class="h6 mb-3">Resources (<?= count($resources) ?>)</h2>
        <div class="table-responsive">
            <table class="table table-sm table-striped mb-0">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Title</th>
                        <th>When</th>
                        <th>Link</th>
                        <th style="width:170px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($resources as $r): ?>
                    <tr>
                        <td>
                            <span class="badge text-bg-<?= h($typeBadge[$r['resource_type']] ?? 'secondary') ?>"><?= h($typeLabels[$r['resource_type']] ?? $r['resource_type']) ?></span>
                            <?php if (($r['resource_type'] ?? '') === 'video'): ?>
                                <span class="badge text-bg-<?= ($r['source_type'] ?? 'link') === 'upload' ? 'success' : 'light text-dark' ?>"><?= ($r['source_type'] ?? 'link') === 'upload' ? 'Uploaded — tracked' : 'External link' ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="fw-semibold"><?= h($r['title'] ?? '') ?>
                            <?php if (!empty($r['description'])): ?><div class="text-muted small"><?= h($r['description']) ?></div><?php endif; ?>
                        </td>
                        <td class="text-muted small"><?= h($r['scheduled_at'] ?? '—') ?></td>
                        <td>
                            <?php if (!empty($r['resource_url'])): ?>
                                <a href="<?= h(($r['source_type'] ?? 'link') === 'upload' ? base_url($r['resource_url']) : $r['resource_url']) ?>" target="_blank" rel="noopener">Open →</a>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td class="d-flex gap-2">
                            <?php if (($r['resource_type'] ?? '') === 'video' && ($r['source_type'] ?? 'link') === 'upload'): ?>
                                <a class="btn btn-sm btn-outline-primary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/courseResourceProgress&resource_id=' . (int)$r['id']), ENT_QUOTES, 'UTF-8') ?>">Progress</a>
                            <?php endif; ?>
                            <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=academic/courseResources&course_id=' . (int)$course['id']), ENT_QUOTES, 'UTF-8') ?>" onsubmit="return confirm('Remove this resource?')">
                                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($resources)): ?>
                    <tr><td colspan="5" class="text-muted">No resources added yet.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
var resourceTypeEl = document.getElementById('resourceType');
var sourceTypeWrap = document.getElementById('sourceTypeWrap');
var urlFieldWrap = document.getElementById('urlFieldWrap');
var fileFieldWrap = document.getElementById('fileFieldWrap');
var scheduledLabel = document.getElementById('scheduledLabel');
var sourceLinkRadio = document.getElementById('sourceLink');
var sourceUploadRadio = document.getElementById('sourceUpload');

function syncResourceForm() {
    var isVideo = resourceTypeEl.value === 'video';
    var isUpload = isVideo && sourceUploadRadio.checked;

    sourceTypeWrap.style.display = isVideo ? '' : 'none';
    fileFieldWrap.style.display = isUpload ? '' : 'none';
    urlFieldWrap.style.display = isUpload ? 'none' : '';

    if (resourceTypeEl.value === 'live_class') {
        scheduledLabel.innerHTML = 'Scheduled Date/Time <span class="text-danger">*</span>';
    } else {
        scheduledLabel.innerHTML = 'Scheduled Date/Time <span class="text-muted small">(optional)</span>';
    }
}

resourceTypeEl.addEventListener('change', syncResourceForm);
sourceLinkRadio.addEventListener('change', syncResourceForm);
sourceUploadRadio.addEventListener('change', syncResourceForm);
syncResourceForm();

// --- Upload progress bar -------------------------------------------------
// A plain <form> submit gives no feedback while a large video uploads (the
// browser just sits on the current page). For an upload, we submit via XHR
// instead so we can show a real percentage from xhr.upload.onprogress.
(function () {
    var form = document.getElementById('addResourceForm');
    var progressWrap = document.getElementById('uploadProgressWrap');
    var progressBar = document.getElementById('uploadProgressBar');
    var progressPct = document.getElementById('uploadProgressPct');
    var progressLabel = document.getElementById('uploadProgressLabel');
    var submitBtn = document.getElementById('addResourceSubmitBtn');

    form.addEventListener('submit', function (e) {
        var isVideo = resourceTypeEl.value === 'video';
        var isUpload = isVideo && sourceUploadRadio.checked;
        var fileInput = document.getElementById('videoFileInput');
        var hasFile = isUpload && fileInput && fileInput.files && fileInput.files.length > 0;

        if (!hasFile) {
            // Link / document / live-class / no-file-selected: normal submit,
            // nothing to show a progress bar for.
            return;
        }

        e.preventDefault();

        var xhr = new XMLHttpRequest();
        xhr.open('POST', form.getAttribute('action'), true);

        progressWrap.style.display = '';
        progressBar.style.width = '0%';
        progressBar.classList.remove('bg-danger');
        progressPct.textContent = '0%';
        progressLabel.textContent = 'Uploading…';
        submitBtn.disabled = true;
        submitBtn.textContent = 'Uploading…';

        xhr.upload.addEventListener('progress', function (evt) {
            if (!evt.lengthComputable) { return; }
            var pct = Math.round((evt.loaded / evt.total) * 100);
            progressBar.style.width = pct + '%';
            progressPct.textContent = pct + '%';
            if (pct >= 100) {
                progressLabel.textContent = 'Processing on server…';
            }
        });

        xhr.onload = function () {
            if (xhr.status >= 200 && xhr.status < 400) {
                progressBar.style.width = '100%';
                progressPct.textContent = '100%';
                progressLabel.textContent = 'Done — reloading…';
                // Server redirected after saving; do a normal navigation so the
                // page reloads with the fresh resource list + flash message.
                window.location.href = form.getAttribute('action');
            } else {
                progressLabel.textContent = 'Upload failed. Please try again.';
                progressBar.classList.add('bg-danger');
                submitBtn.disabled = false;
                submitBtn.textContent = 'Add Resource';
            }
        };

        xhr.onerror = function () {
            progressLabel.textContent = 'Upload failed — connection error.';
            progressBar.classList.add('bg-danger');
            submitBtn.disabled = false;
            submitBtn.textContent = 'Add Resource';
        };

        xhr.send(new FormData(form));
    });
})();
</script>
