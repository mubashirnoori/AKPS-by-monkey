<?php
// Variables: $classSections,$examGroups,$academicYears,$exams,$error
$examsUrl = base_url('/index.php?route=academic/exams');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Exams</h1>
        <div class="text-muted">Create exam instances and schedule them.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="alert alert-info d-flex align-items-start gap-2 mb-3">
    <span>ℹ️</span>
    <div>
        An exam here is one container for a class (e.g. "First Term Exam Nursery"). Pick as many classes as you like below and
        one exam is created per class automatically. The date/time/total-marks fields are optional overall defaults for each —
        to give a class's exam a different date, or to give each subject (Math, English, Urdu…) its own date, time and total
        marks, open <a href="<?= h(route_url('academic/dateSheet')) ?>">Date Sheet</a> afterwards and pick it.
    </div>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <h2 class="h6 mb-3">Create Exam</h2>
        <form method="post" action="<?= htmlspecialchars($examsUrl, ENT_QUOTES, 'UTF-8') ?>"
              data-ajax data-target="#examListContainer" data-reset-on-success>
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
            <input type="hidden" name="action" value="create">
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Exam Group</label>
                    <select class="form-select" name="exam_group_id" required>
                        <?php foreach ($examGroups as $g): ?>
                            <option value="<?= (int)$g['id'] ?>">
                                <?= h($g['exam_type_name'] . ' - ' . $g['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Academic Year (optional)</label>
                    <select class="form-select" name="academic_year_id">
                        <option value="0">Not set</option>
                        <?php foreach ($academicYears as $y): ?>
                            <option value="<?= (int)$y['id'] ?>"><?= h($y['academic_year_label']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Exam Name *</label>
                    <input class="form-control" name="exam_name" required placeholder="e.g. First Term Exam">
                    <div class="form-text">When more than one class is picked, each exam is auto-tagged with its class, e.g. "First Term Exam — 6th A".</div>
                </div>

                <div class="col-12">
                    <label class="form-label mb-1">Applicable To *</label>
                    <div class="border rounded p-3" style="background: var(--sms-surface-2, #1f2937); border-color: var(--sms-border, #2a3340) !important;">
                        <div class="d-flex flex-wrap gap-2 mb-2">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="examAllClasses">
                                <label class="form-check-label fw-semibold" for="examAllClasses" style="color: var(--sms-text, #e5e7eb);">All Classes</label>
                            </div>
                            <button type="button" class="btn btn-xs btn-outline-secondary ms-3" style="font-size:0.75rem;padding:2px 8px;" onclick="examToggleAll(false)">Clear</button>
                        </div>
                        <div class="row" style="max-height: 260px; overflow-y: auto;">
                            <?php foreach ($classSections as $cs): ?>
                                <div class="col-6 col-sm-4 col-md-3 mb-1">
                                    <div class="form-check">
                                        <input class="form-check-input exam-class-cb" type="checkbox" name="class_section_ids[]"
                                               value="<?= (int)$cs['id'] ?>" id="examClass<?= (int)$cs['id'] ?>">
                                        <label class="form-check-label small" for="examClass<?= (int)$cs['id'] ?>" style="color: var(--sms-text, #e5e7eb);">
                                            <?= h($cs['class_name'] . ' ' . $cs['section_name']) ?>
                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="form-text"><span id="examClassCount">0</span> class(es) selected.</div>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Combine with (optional)</label>
                    <select class="form-select" name="cumulative_source_exam_name">
                        <option value="">Not combined — stands on its own</option>
                        <?php foreach ($examBaseNames as $bn): ?>
                            <option value="<?= h($bn) ?>"><?= h($bn) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text">
                        For a year-end exam like "Final Term": pick "First Term Exam" here and this exam's marks
                        will be added on top of it, per subject, before pass/fail and class/school position are
                        worked out — e.g. a subject failed in First Term can still pass once Final Term's marks
                        are added in.
                    </div>
                </div>
                <div class="col-md-6"></div>
                <div class="col-md-3">
                    <label class="form-label">Scheduled Date</label>
                    <input class="form-control" name="scheduled_date" type="date">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Start Time</label>
                    <input class="form-control" name="start_time" type="time">
                </div>
                <div class="col-md-3">
                    <label class="form-label">End Time</label>
                    <input class="form-control" name="end_time" type="time">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Total Marks</label>
                    <input class="form-control" name="total_marks" type="number" min="1" step="1" placeholder="e.g. 25, 50, 100">
                    <div class="form-text">Default max marks (can vary per class/subject in Date Sheet)</div>
                </div>
            </div>

            <div class="mt-3">
                <button class="btn btn-primary" type="submit">Create Exam</button>
            </div>
        </form>
    </div>
</div>

<script>
function examToggleAll(check) {
    document.querySelectorAll('.exam-class-cb').forEach(function (cb) { cb.checked = check; });
    document.getElementById('examAllClasses').checked = check;
    examUpdateCount();
}
function examUpdateCount() {
    var n = document.querySelectorAll('.exam-class-cb:checked').length;
    document.getElementById('examClassCount').textContent = n;
    var all = document.querySelectorAll('.exam-class-cb').length;
    document.getElementById('examAllClasses').checked = (n === all && all > 0);
}
document.getElementById('examAllClasses')?.addEventListener('change', function () {
    examToggleAll(this.checked);
});
document.querySelectorAll('.exam-class-cb').forEach(function (cb) {
    cb.addEventListener('change', examUpdateCount);
});
document.querySelector('form[data-target="#examListContainer"][data-reset-on-success]')?.addEventListener('reset', function () {
    setTimeout(examUpdateCount, 0);
});
examUpdateCount();
</script>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <h2 class="h6 mb-3">Exam List</h2>
        <div id="examListContainer">
            <?= $this->renderPartial('academic/_exam_list', [
                'exams' => $exams,
                'examsUrl' => $examsUrl,
                'examPage' => $examPage ?? 1,
                'examTotalPages' => $examTotalPages ?? 1,
            ]) ?>
        </div>
    </div>
</div>

<div class="modal fade" id="editExamModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <form method="post" action="<?= htmlspecialchars($examsUrl, ENT_QUOTES, 'UTF-8') ?>"
            data-ajax data-target="#examListContainer" data-close-modal="#editExamModal">
        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="id" id="edit_exam_id" value="">
        <input type="hidden" name="exam_page" value="<?= (int)($examPage ?? 1) ?>">
        <div class="modal-header">
          <h5 class="modal-title">Edit Exam</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="row g-3">
            <div class="col-md-4">
              <label class="form-label">Exam Group</label>
              <select class="form-select" name="exam_group_id" id="edit_exam_group_id" required>
                <?php foreach ($examGroups as $g): ?>
                  <option value="<?= (int)$g['id'] ?>"><?= h($g['exam_type_name'] . ' - ' . $g['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">Academic Year</label>
              <select class="form-select" name="academic_year_id" id="edit_academic_year_id">
                <option value="0">Not set</option>
                <?php foreach ($academicYears as $y): ?>
                  <option value="<?= (int)$y['id'] ?>"><?= h($y['academic_year_label']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label">Class / Section</label>
              <select class="form-select" name="class_section_id" id="edit_class_section_id" required>
                <?php foreach ($classSections as $cs): ?>
                  <option value="<?= (int)$cs['id'] ?>"><?= h($cs['class_name'] . ' ' . $cs['section_name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Exam Name *</label>
              <input class="form-control" name="exam_name" id="edit_exam_name" required>
            </div>
            <div class="col-md-3">
              <label class="form-label">Scheduled Date</label>
              <input class="form-control" name="scheduled_date" id="edit_scheduled_date" type="date">
            </div>
            <div class="col-md-3">
              <label class="form-label">Total Marks</label>
              <input class="form-control" name="total_marks" id="edit_total_marks" type="number" min="1" step="1">
            </div>
            <div class="col-md-3">
              <label class="form-label">Start Time</label>
              <input class="form-control" name="start_time" id="edit_start_time" type="time">
            </div>
            <div class="col-md-3">
              <label class="form-label">End Time</label>
              <input class="form-control" name="end_time" id="edit_end_time" type="time">
            </div>
            <div class="col-md-6">
              <label class="form-label">Combine with (optional)</label>
              <select class="form-select" name="cumulative_source_exam_name" id="edit_cumulative_source_exam_name">
                <option value="">Not combined — stands on its own</option>
                <?php foreach ($examBaseNames as $bn): ?>
                    <option value="<?= h($bn) ?>"><?= h($bn) ?></option>
                <?php endforeach; ?>
              </select>
              <div class="form-text">This exam's marks get added on top of the picked exam's, per subject, before pass/fail and position are worked out.</div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Update Exam</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
document.getElementById('editExamModal')?.addEventListener('show.bs.modal', function (event) {
    var btn = event.relatedTarget;
    if (!btn) return;
    document.getElementById('edit_exam_id').value = btn.getAttribute('data-id') || '';
    document.getElementById('edit_exam_group_id').value = btn.getAttribute('data-exam-group-id') || '';
    document.getElementById('edit_academic_year_id').value = btn.getAttribute('data-academic-year-id') || '0';
    document.getElementById('edit_class_section_id').value = btn.getAttribute('data-class-section-id') || '';
    document.getElementById('edit_exam_name').value = btn.getAttribute('data-exam-name') || '';
    document.getElementById('edit_scheduled_date').value = btn.getAttribute('data-scheduled-date') || '';
    document.getElementById('edit_start_time').value = btn.getAttribute('data-start-time') || '';
    document.getElementById('edit_end_time').value = btn.getAttribute('data-end-time') || '';
    document.getElementById('edit_total_marks').value = btn.getAttribute('data-total-marks') || '';
    document.getElementById('edit_cumulative_source_exam_name').value = btn.getAttribute('data-cumulative-source-exam-name') || '';
});
</script>
