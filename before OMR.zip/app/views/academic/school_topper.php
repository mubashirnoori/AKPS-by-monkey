<?php
// Variables: $examNames, $examName, $eligibleClasses, $exams, $toppers
$examNames = $examNames ?? [];
$examName = $examName ?? '';
$eligibleClasses = $eligibleClasses ?? [];
$exams = $exams ?? [];
$toppers = $toppers ?? [];
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Whole-School Topper</h1>
        <div class="text-muted">Classes <?= h(implode(', ', $eligibleClasses)) ?> only — always exactly one student: highest percentage among students who passed, ties broken by total marks obtained. Review before announcing.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= h(base_url('/index.php?route=academic/index')) ?>">Back</a>
</div>

<?php if (empty($examNames)): ?>
<div class="card shadow-sm border-0"><div class="card-body">
    <div class="text-muted">No published exam results found yet for classes <?= h(implode(', ', $eligibleClasses)) ?>.</div>
</div></div>
<?php else: ?>

<form method="get" action="<?= h(base_url('/index.php')) ?>" class="card shadow-sm border-0 mb-3">
    <div class="card-body d-flex align-items-center gap-2 flex-wrap">
        <input type="hidden" name="route" value="academic/schoolTopper">
        <label class="form-label mb-0 small text-muted">Exam</label>
        <select name="exam_name" class="form-select form-select-sm" style="max-width:320px;" onchange="this.form.submit()">
            <?php foreach ($examNames as $en): ?>
                <option value="<?= h($en) ?>" <?= $en === $examName ? 'selected' : '' ?>><?= h($en) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</form>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <h2 class="h6 text-muted mb-3">Sections included in this exam</h2>
        <?php if (empty($exams)): ?>
            <div class="text-muted small">No sections found for this exam in the eligible classes.</div>
        <?php else: ?>
            <ul class="mb-0">
                <?php foreach ($exams as $ex): ?>
                    <li><?= h($ex['class_name'] ?? '') ?> — <?= h($ex['section_name'] ?? '') ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <h2 class="h6 text-muted mb-3">Result</h2>
        <?php if (empty($toppers)): ?>
            <div class="text-muted">No passing student found across these classes for this exam.</div>
        <?php else: ?>
            <div class="d-flex flex-wrap gap-3">
                <?php foreach ($toppers as $t): ?>
                    <div class="border rounded-3 p-3" style="min-width:220px;">
                        <div class="text-warning-emphasis fw-bold small mb-1"><i class="bi bi-trophy-fill"></i> School Topper</div>
                        <div class="fw-semibold"><?= h($t['name']) ?></div>
                        <div class="text-muted small"><?= h($t['class_name'] ?? '') ?> — <?= h($t['section_name'] ?? '') ?></div>
                        <div class="text-muted small">Admission No: <?= h($t['admission_no'] ?? '') ?></div>
                        <div class="mt-2"><span class="fw-bold"><?= h(format_mark($t['percentage'])) ?>%</span>
                            <span class="text-muted small">(<?= h(format_mark($t['total_obtained'])) ?> / <?= h(format_mark($t['total_max'])) ?>)</span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php endif; ?>
