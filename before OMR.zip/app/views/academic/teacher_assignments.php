<?php
// Variables: $subjectId,$subjects,$staffOptions,$assignedTeachers
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Teacher Assignments</h1>
        <div class="text-muted">Assign teachers (staff profiles) to subjects.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="academic/teacherAssignments">
            <div class="col-md-6">
                <label class="form-label">Subject</label>
                <select class="form-select" name="subject_id" onchange="this.form.submit()">
                    <?php
                    $groupedSubjects = [];
                    foreach ($subjects as $sub) {
                        $groupedSubjects[$sub['class_name'] ?? ''][] = $sub;
                    }
                    ?>
                    <?php foreach ($groupedSubjects as $className => $subs): ?>
                        <optgroup label="<?= h($className !== '' ? $className : 'No class assigned') ?>">
                            <?php foreach ($subs as $sub): ?>
                                <option value="<?= (int)$sub['id'] ?>" <?= ((int)$subjectId === (int)$sub['id']) ? 'selected' : '' ?>>
                                    <?= h($sub['subject_name'] ?? '') ?>
                                </option>
                            <?php endforeach; ?>
                        </optgroup>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 d-grid">
                <button class="btn btn-primary" type="submit">Load</button>
            </div>
        </form>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-1">Assign Teacher</h2>
                <?php
                $currentSubjectLabel = '';
                $currentClassLabel = '';
                foreach ($subjects as $sub) {
                    if ((int)$sub['id'] === (int)$subjectId) {
                        $currentSubjectLabel = $sub['subject_name'] ?? '';
                        $currentClassLabel = $sub['class_name'] ?? '';
                        break;
                    }
                }
                ?>
                <?php if ($currentSubjectLabel !== ''): ?>
                    <div class="text-muted small mb-3">
                        <?= h($currentSubjectLabel) ?> — <?= h($currentClassLabel !== '' ? $currentClassLabel : 'No class assigned') ?>
                    </div>
                <?php endif; ?>
                <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=academic/teacherAssignments'), ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="action" value="assign">
                    <input type="hidden" name="subject_id" value="<?= (int)$subjectId ?>">
                    <div class="mb-3">
                        <label class="form-label">Teacher (Staff Profile)</label>
                        <select class="form-select" name="staff_profile_id" required>
                            <option value="">Choose...</option>
                            <?php foreach ($staffOptions as $st): ?>
                                <option value="<?= (int)$st['id'] ?>">
                                    <?= h(($st['full_name'] ?? '') . ($st['title'] ? ' - ' . $st['title'] : '')) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button class="btn btn-primary w-100" type="submit">Assign</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-3">Assigned Teachers</h2>
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0">
                        <thead>
                        <tr>
                            <th>Teacher</th>
                            <th>Subject</th>
                            <th style="width: 150px;">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($assignedTeachers)): ?>
                            <tr><td colspan="2" class="text-muted">No teachers assigned yet.</td></tr>
                        <?php else: ?>
                            <?php foreach ($assignedTeachers as $t): ?>
                                <tr>
                                    <td>
                                        <div class="fw-semibold"><?= h($t['full_name'] ?? '') ?></div>
                                        <div class="text-muted small"><?= h($t['title'] ?? '') ?></div>
                                    </td>
                                    <td>
                                        <?php
                                        $subjectLabel = '';
                                        $subjectClassLabel = '';
                                        foreach ($subjects as $sub) {
                                            if ((int)$sub['id'] === (int)$subjectId) {
                                                $subjectLabel = $sub['subject_name'] ?? '';
                                                $subjectClassLabel = $sub['class_name'] ?? '';
                                                break;
                                            }
                                        }
                                        ?>
                                        <span class="badge border" style="background: var(--sms-surface-2, #1f2937); color: var(--sms-text, #e5e7eb);">
                                            <?= h($subjectLabel) ?><?= $subjectClassLabel !== '' ? ' — ' . h($subjectClassLabel) : '' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=academic/teacherAssignments'), ENT_QUOTES, 'UTF-8') ?>" onsubmit="return confirm('Unassign this teacher?')">
                                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                            <input type="hidden" name="action" value="unassign">
                                            <input type="hidden" name="subject_id" value="<?= (int)$subjectId ?>">
                                            <input type="hidden" name="staff_profile_id" value="<?= (int)($t['staff_profile_id'] ?? 0) ?>">
                                            <button class="btn btn-sm btn-outline-danger" type="submit">Unassign</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>