<?php
// Variables: $student (StudentModel::getById row), $examName, $card (ExamModel::studentReportCard result), $schoolName, $logoPath
$student = $student ?? [];
$examName = $examName ?? '';
$card = $card ?? [];
$schoolName = $schoolName ?? 'ARC School';
$logoPath = $logoPath ?? '';

$fullName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
$className = trim((string)($student['current_class_name'] ?? ''));
$sectionName = trim((string)($student['current_section_name'] ?? ''));
$rollNo = (int)($student['roll_number'] ?? 0);

$studentMarks = $card['studentMarks'] ?? [];
$overallGrade = $card['overallGrade'] ?? null;
$resultStatus = $card['resultStatus'] ?? null;
$studentRank = $card['studentRank'] ?? null;
$isSchoolTopper = $card['isSchoolTopper'] ?? false;
$combinedWith = $card['combinedWith'] ?? null;
$breakdown = $card['breakdown'] ?? [];

/** PASS -> green, PROMOTE -> amber/blue (passed overall but not eligible for position), INCOMPLETE -> amber, FAIL -> red. */
$resultLabel = static function (?string $status): string {
    if ($status === 'PROMOTE') {
        return 'PROMOTED';
    }
    return (string)$status;
};

$totalObtained = 0.0;
$totalMaxMarks = 0.0;
foreach ($studentMarks as $m) {
    $totalObtained += (float)($m['score'] ?? 0);
    $subTot = (float)($m['total_marks'] ?? 100);
    $totalMaxMarks += ($subTot > 0 ? $subTot : 100.0);
}
$overallPercentage = $totalMaxMarks > 0 ? round($totalObtained / $totalMaxMarks * 100, 1) : 0.0;
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Report Card — <?= h($fullName) ?></title>
<style>
body { margin: 0; padding: 24px; background: #f1f5f9; font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif; color: #0f172a; }
.cert-page { background: #fff; border: 3px solid #1e3a5f; border-radius: 12px; max-width: 720px; margin: 0 auto; box-shadow: 0 6px 32px rgba(30,58,95,.13); overflow: hidden; display: flex; flex-direction: column; min-height: 250mm; }
.cert-outer-border { border: 6px double #b89a4e; margin: 10px; border-radius: 8px; padding: 2rem 2.5rem 1.8rem; flex: 1; display: flex; flex-direction: column; }
.cert-school-title { font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif; text-align: center; font-size: 1.85rem; font-weight: 800; letter-spacing: .1em; color: #1e3a5f; margin: 0 0 .25rem; text-transform: uppercase; }
.cert-info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: .5rem 1.5rem; font-size: .88rem; margin: 1rem 0 1.25rem; padding: .85rem 1rem; background: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0; }
.cert-info-grid .lbl { color: #64748b; font-size: .72rem; text-transform: uppercase; letter-spacing: .06em; }
.cert-info-grid .val { font-weight: 700; color: #0f172a; }
.cert-logo { display: block; margin: .4rem auto .8rem; height: 72px; width: auto; border-radius: 8px; }
.cert-logo-fallback { width: 72px; height: 72px; border-radius: 50%; background: linear-gradient(135deg,#1e3a5f,#2563eb); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 2rem; margin: .4rem auto .8rem; }
.cert-title { font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif; text-align: center; font-size: 1.35rem; font-weight: 700; letter-spacing: 3px; text-transform: uppercase; color: #1e3a5f; border-top: 1.5px solid #b89a4e; border-bottom: 1.5px solid #b89a4e; padding: .4rem 0; margin: .6rem 0 1rem; }
.cert-subtitle { text-align: center; color: #6b7280; font-size: .9rem; margin-bottom: 1.2rem; font-style: italic; }
.cert-student-name { font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif; text-align: center; font-size: 1.7rem; font-weight: 700; color: #1e3a5f; }
/* Totals row lives inside <tfoot> of .cert-table itself, so its cells sit
   in the exact same columns as the Obtained/Total/%/Grade cells above it.
   Spacer row, total row, and the result line below all share the same
   cream background so they read as one connected block, separate from
   the white/striped subject rows above. */
.cert-table tfoot tr.cert-spacer-row td { padding: 0; height: 18px; border: 0; background: #fff; }
.cert-table tfoot tr.cert-total-row td { background: #f8f5ec; border-top: 3px solid #1e3a5f; border-bottom: none; padding: .6rem .8rem; font-weight: 700; color: #1e3a5f; }
.cert-table tfoot tr.cert-total-row td.cert-total-label { text-transform: uppercase; letter-spacing: 1px; font-size: .74rem; color: #64748b; font-weight: 700; }
.cert-result-line { text-align: center; margin: 0 0 1.2rem; padding: .7rem 1rem; background: #f8f5ec; border-radius: 8px; border: 1px solid #e9e0c5; }
.cert-result-badge { font-size: 1.5rem; font-weight: 800; letter-spacing: 2px; }
.cert-result-extra { margin-top: .3rem; font-size: .72rem; text-transform: uppercase; letter-spacing: 1px; color: #9ca3af; }
.cert-table { width: 100%; border-collapse: collapse; font-size: .88rem; margin-bottom: 0; }
.cert-table th { font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif; background: #1e3a5f; color: #fff; padding: .5rem .8rem; text-align: left; font-size: .78rem; letter-spacing: .8px; text-transform: uppercase; }
.cert-table td { padding: .45rem .8rem; border-bottom: 1px solid #f0e9d6; background: #fff; }
.cert-table tr:nth-child(even) td { background: #faf7f0; }
.cert-table tr.cert-row-fail td { color: #9f1239; }
.cert-grade-badge { display: inline-block; padding: 1px 8px; border-radius: 20px; font-size: .78rem; font-weight: 700; background: #1e3a5f; color: #fff; }
.cert-footer-note { text-align: center; font-size: .7rem; color: #9ca3af; margin-top: .8rem; }
@page { size: A4; margin: 10mm; }
@media print { body { background: #fff; padding: 0; } .cert-page { box-shadow: none; border-radius: 0; max-width: 100%; } }
</style>
</head>
<body>
<div class="cert-print-scale-wrap" id="certScaleWrap">
<div class="cert-page">
  <div class="cert-outer-border">

    <h1 class="cert-school-title"><?= h($schoolName) ?></h1>

    <?php if ($logoPath): ?>
        <img src="<?= h($logoPath) ?>" alt="School Logo" class="cert-logo">
    <?php else: ?>
        <div class="cert-logo-fallback">&#127891;</div>
    <?php endif; ?>

    <div class="cert-title">Student Report Card</div>
    <div class="cert-subtitle"><?= h($examName) ?></div>
    <div class="cert-student-name"><?= h($fullName) ?></div>

    <div class="cert-info-grid">
        <div><div class="lbl">Class</div><div class="val"><?= $className !== '' ? h($className) : '—' ?></div></div>
        <div><div class="lbl">Section</div><div class="val"><?= $sectionName !== '' ? h($sectionName) : '—' ?></div></div>
        <div><div class="lbl">Roll number</div><div class="val"><?= $rollNo > 0 ? h((string)$rollNo) : '—' ?></div></div>
        <div><div class="lbl">Admission no.</div><div class="val"><?= h($student['admission_no'] ?? '') ?></div></div>
        <div><div class="lbl">Father's name</div><div class="val"><?= !empty($student['father_name']) ? h($student['father_name']) : '—' ?></div></div>
    </div>

    <table class="cert-table">
        <thead>
        <?php if ($combinedWith && !empty($breakdown)): ?>
            <tr><th>#</th><th>Subject</th><th><?= h($combinedWith) ?></th><th><?= h($examName) ?></th><th>Final Result</th><th>Total</th><th>%</th><th>Grade</th></tr>
        <?php else: ?>
            <tr><th>#</th><th>Subject</th><th>Obtained</th><th>Total</th><th>%</th><th>Grade</th></tr>
        <?php endif; ?>
        </thead>
        <tbody>
            <?php if (empty($studentMarks)): ?>
                <tr><td colspan="8" style="text-align:center;color:#9ca3af;padding:1.5rem;">No marks recorded for this exam.</td></tr>
            <?php else: ?>
                <?php foreach ($studentMarks as $i => $m): ?>
                    <?php
                    $score = (float)($m['score'] ?? 0);
                    $subTotal = (float)($m['total_marks'] ?? 100);
                    $subTotal = $subTotal > 0 ? $subTotal : 100.0;
                    $pct = round($score / $subTotal * 100, 1);
                    $bd = $breakdown[$m['subject_id']] ?? null;
                    ?>
                    <tr class="<?= empty($m['is_pass']) ? 'cert-row-fail' : '' ?>">
                        <td><?= $i + 1 ?></td>
                        <td><?= h($m['subject_name'] ?? '') ?></td>
                        <?php if ($combinedWith && !empty($breakdown)): ?>
                            <td><?= h(format_mark($bd['source']['score'] ?? 0)) ?></td>
                            <td><?= h(format_mark($bd['own']['score'] ?? 0)) ?></td>
                            <td><strong><?= h(format_mark($score)) ?></strong></td>
                        <?php else: ?>
                            <td><strong><?= h(format_mark($score)) ?></strong></td>
                        <?php endif; ?>
                        <td><?= h(format_mark($subTotal)) ?></td>
                        <td><?= h(format_mark($pct)) ?>%</td>
                        <td><span class="cert-grade-badge"><?= h($m['grade_letter'] ?? '—') ?></span></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
        <?php if (!empty($studentMarks)): ?>
        <tfoot>
            <?php if ($combinedWith && !empty($breakdown)): ?>
                <?php /* 8 cols: #, Subject, combinedWith, examName, Final Result, Total, %, Grade */ ?>
                <tr class="cert-spacer-row"><td colspan="8"></td></tr>
                <tr class="cert-total-row">
                    <td class="cert-total-label" colspan="4">Total</td>
                    <td><?= h(format_mark($totalObtained)) ?></td>
                    <td><?= h(format_mark($totalMaxMarks)) ?></td>
                    <td><?= h(format_mark($overallPercentage)) ?>%</td>
                    <td><?= h((string)($overallGrade ?? '—')) ?></td>
                </tr>
            <?php else: ?>
                <?php /* 6 cols: #, Subject, Obtained, Total, %, Grade */ ?>
                <tr class="cert-spacer-row"><td colspan="6"></td></tr>
                <tr class="cert-total-row">
                    <td class="cert-total-label" colspan="2">Total</td>
                    <td><?= h(format_mark($totalObtained)) ?></td>
                    <td><?= h(format_mark($totalMaxMarks)) ?></td>
                    <td><?= h(format_mark($overallPercentage)) ?>%</td>
                    <td><?= h((string)($overallGrade ?? '—')) ?></td>
                </tr>
            <?php endif; ?>
        </tfoot>
        <?php endif; ?>
    </table>

    <?php if (!empty($resultStatus) || !empty($studentRank) || !empty($isSchoolTopper)): ?>
    <?php
    $resultColor = $resultStatus === 'PASS' ? '#15803d'
        : ($resultStatus === 'PROMOTE' ? '#1d4ed8'
        : ($resultStatus === 'INCOMPLETE' ? '#a16207' : '#b91c1c'));
    ?>
    <div class="cert-result-line">
        <?php if (!empty($resultStatus)): ?>
        <div class="cert-result-badge" style="color:<?= $resultColor ?>"><?= h($resultLabel($resultStatus)) ?></div>
        <?php endif; ?>
        <?php if (!empty($studentRank) || !empty($isSchoolTopper)): ?>
        <div class="cert-result-extra">
            <?php
            $extras = [];
            if (!empty($studentRank)) { $extras[] = h(ordinal((int)$studentRank)) . ' Position'; }
            if (!empty($isSchoolTopper)) { $extras[] = '&#127942; Whole-School Topper'; }
            echo implode(' &nbsp;&middot;&nbsp; ', $extras);
            ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if ($combinedWith): ?>
    <div class="cert-footer-note" style="margin-top:auto;padding-top:.6rem;">Combined result: <?= h($combinedWith) ?> + <?= h($examName) ?></div>
    <?php endif; ?>

    <div class="cert-footer-note" style="<?= $combinedWith ? '' : 'margin-top:auto;padding-top:.6rem;' ?>"><?= h($schoolName) ?> — Confidential academic record</div>

  </div>
</div>
</div>
<script>
(function () {
    var scaleWrap = document.getElementById('certScaleWrap');
    var page = scaleWrap ? scaleWrap.querySelector('.cert-page') : null;
    if (!scaleWrap || !page) { return; }

    // A4 printable width/height in CSS reference px, after the @page margin
    // above (10mm each side). 96px = 1in, 25.4mm = 1in — this ratio is a
    // fixed CSS constant, not tied to the actual screen/printer DPI.
    var PAGE_WIDTH_PX  = (210 - 20) * (96 / 25.4);
    var PAGE_HEIGHT_PX = (297 - 20) * (96 / 25.4);

    function fitToOnePage() {
        page.style.transform = 'none';
        page.style.width = '';
        scaleWrap.style.height = '';
        scaleWrap.style.overflow = '';

        // Force the print-time width before measuring -- if this file is
        // opened on a phone, the page renders at the narrow screen width by
        // default, which gives the wrong height and the wrong (or no) scale.
        page.style.width = PAGE_WIDTH_PX + 'px';
        var naturalHeight = page.offsetHeight;
        if (naturalHeight > PAGE_HEIGHT_PX) {
            var scale = PAGE_HEIGHT_PX / naturalHeight;
            page.style.transformOrigin = 'top center';
            page.style.transform = 'scale(' + scale + ')';
            scaleWrap.style.height = (naturalHeight * scale) + 'px';
            scaleWrap.style.overflow = 'hidden';
        }
    }

    function resetFit() {
        page.style.transform = 'none';
        page.style.width = '';
        scaleWrap.style.height = '';
        scaleWrap.style.overflow = '';
    }

    // Measuring naturalHeight before the logo <img> has finished loading
    // under-reports the card's real height, so the "does it fit on one
    // page?" check can wrongly say yes -- the logo then loads, pushes the
    // layout taller than a page, and the overflow shows up as a second,
    // near-empty page (a solid black block in most print/PDF previews).
    // Wait for every image inside the card before measuring.
    function fitToOnePageWhenReady() {
        var imgs = page.querySelectorAll('img');
        var pending = imgs.length;
        if (pending === 0) { fitToOnePage(); return; }
        var settle = function () {
            pending -= 1;
            if (pending <= 0) { fitToOnePage(); }
        };
        imgs.forEach(function (img) {
            if (img.complete) { settle(); return; }
            img.addEventListener('load', settle);
            img.addEventListener('error', settle);
        });
    }

    window.addEventListener('beforeprint', fitToOnePageWhenReady);
    window.addEventListener('afterprint', resetFit);
    // This file's only purpose is printing (it's the standalone HTML saved into
    // the bulk-export ZIP), so also fit as soon as images are ready in case a
    // print pipeline doesn't fire beforeprint (e.g. some PDF-from-HTML tools).
    fitToOnePageWhenReady();
})();
</script>
</body>
</html>