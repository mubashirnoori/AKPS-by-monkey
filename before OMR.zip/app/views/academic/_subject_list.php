<?php
// Variables: $search,$perPage,$page,$total,$subjects,$allSubjectOptions
$subjects = $subjects ?? [];
$total = $total ?? 0;
?>
<div class="d-flex align-items-center justify-content-between mb-2">
    <h2 class="h6 mb-0">Subject List</h2>
    <div class="text-muted small"><?= (int)$total ?> total</div>
</div>
<div class="table-responsive">
    <table class="table table-sm table-striped mb-0">
        <thead>
            <tr>
                <th>Class</th>
                <th>Code</th>
                <th>Name</th>
                <th style="width: 220px;">Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($subjects as $s): ?>
            <tr>
                <td><?= h($s['class_name'] ?? '') ?: '<span class="text-muted">—</span>' ?></td>
                <td><?= h($s['subject_code'] ?? '') ?></td>
                <td class="fw-semibold"><?= h($s['subject_name'] ?? '') ?></td>
                <td>
                    <button type="button" class="btn btn-sm btn-outline-primary"
                            data-bs-toggle="modal" data-bs-target="#subjectFormModal"
                            data-id="<?= (int)$s['id'] ?>"
                            data-class-id="<?= (int)($s['class_id'] ?? 0) ?>"
                            data-subject-code="<?= h($s['subject_code'] ?? '') ?>"
                            data-subject-name="<?= h($s['subject_name'] ?? '') ?>">
                        Edit
                    </button>
                    <button type="button" class="btn btn-sm btn-outline-secondary"
                            data-bs-toggle="modal" data-bs-target="#mergeSubjectModal"
                            data-from-id="<?= (int)$s['id'] ?>"
                            data-from-name="<?= h(($s['subject_name'] ?? '') . (!empty($s['class_name']) ? ' — ' . $s['class_name'] : '')) ?>">
                        Merge
                    </button>
                    <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=academic/subjectDelete'), ENT_QUOTES, 'UTF-8') ?>" class="d-inline"
                          data-ajax data-target="#subjectListContainer" data-confirm="Delete this subject?">
                        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                        <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
                        <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($subjects)): ?>
            <tr><td colspan="4" class="text-muted">No subjects found.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>