<?php
// Variables: $examId,$exam,$exams,$subjects,$scheduleMap,$canManage
$exam = $exam ?? null;
$subjects = $subjects ?? [];
$scheduleMap = $scheduleMap ?? [];
$canManage = $canManage ?? false;
$dateSheetUrl = base_url('/index.php?route=academic/dateSheet');
$dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

$settingsMap = [];
$schoolName = 'School';
$logoPath = '';
try {
    if (class_exists('Database')) {
        $rows = Database::fetchAll('SELECT `key`, `value` FROM settings');
        foreach ($rows as $r) { $settingsMap[$r['key']] = $r['value']; }
    }
    $schoolName = $settingsMap['branding_school_name'] ?? $settingsMap['institute_name'] ?? 'School';
    $logoPath = $settingsMap['branding_logo_path'] ?? '';
} catch (Throwable $e) {}

// Rows for the printable sheet: every subject that has at least a date or a time set.
$printRows = [];
foreach ($subjects as $sub) {
    $sid = (int)$sub['id'];
    $row = $scheduleMap[$sid] ?? null;
    if ($row && (!empty($row['scheduled_date']) || !empty($row['start_time']))) {
        $printRows[] = [
            'subject_name' => $sub['subject_name'],
            'scheduled_date' => $row['scheduled_date'] ?? null,
            'start_time' => $row['start_time'] ?? null,
            'end_time' => $row['end_time'] ?? null,
            'total_marks' => $row['total_marks'] ?? null,
        ];
    }
}
usort($printRows, function ($a, $b) {
    $ka = ($a['scheduled_date'] ?? '9999-99-99') . ($a['start_time'] ?? '99:99:99');
    $kb = ($b['scheduled_date'] ?? '9999-99-99') . ($b['start_time'] ?? '99:99:99');
    return $ka <=> $kb;
});
?>
<style>
/* On-screen: follow the app's dark theme so text stays readable against the card. */
.ds-header { border-bottom: 2px solid var(--sms-border, #1f2937); padding-bottom: 1rem; margin-bottom: 1.25rem; }
.ds-title { font-size: 1.3rem; font-weight: 700; letter-spacing: .03em; text-transform: uppercase; }
.ds-meta-row { font-size: .85rem; color: var(--sms-muted, #4b5563); }
.ds-table thead th {
    background: var(--sms-surface-2, #1f2937); color: var(--sms-heading, #fff); font-size: .75rem;
    text-transform: uppercase; letter-spacing: .03em; border: none;
}
.ds-table td { vertical-align: middle; color: var(--sms-text, #1f2937); }
.ds-table tbody tr:nth-child(even) { background: rgba(255, 255, 255, 0.04); }
.ds-sign-line { border-top: 1.5px solid var(--sms-border, #374151); width: 160px; margin-top: 2.5rem; padding-top: .3rem; font-size: .8rem; color: var(--sms-muted, #4b5563); }

/* Print: force a plain light page regardless of the on-screen dark theme, and
   set every text color explicitly so nothing inherits a light theme color
   that would vanish on the white printed page. */
@media print {
    .navbar, aside, nav, .ds-no-print { display: none !important; }
    body, .ds-print-card { background: #fff !important; color: #1f2937 !important; }
    .ds-print-card { box-shadow: none !important; border: none !important; }
    .ds-title, .ds-header, .ds-meta-row, .ds-sign-line, .ds-table td, .ds-table th {
        color: #1f2937 !important;
    }
    .ds-meta-row, .ds-sign-line { color: #4b5563 !important; }
    .ds-table thead th { background: #1f2937 !important; color: #fff !important; }
    .ds-table tbody tr:nth-child(even) { background: #f8fafc !important; }
    * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
}
</style>

<div class="ds-no-print">
    <div class="d-flex align-items-center justify-content-between mb-3">
        <div>
            <h1 class="h4 mb-0">Date Sheet</h1>
            <div class="text-muted">Schedule each subject's date &amp; time for an exam, then print a ready-to-post date sheet.</div>
        </div>
        <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
    </div>

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-body">
            <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
                <input type="hidden" name="route" value="academic/dateSheet">
                <div class="col-md-8">
                    <label class="form-label">Exam</label>
                    <select class="form-select" name="exam_id" onchange="this.form.submit()">
                        <option value="0">Choose...</option>
                        <?php foreach ($exams as $e): ?>
                            <option value="<?= (int)$e['id'] ?>" <?= ((int)$examId === (int)$e['id']) ? 'selected' : '' ?>>
                                <?= h($e['exam_name'] ?? '') ?>
                                <?php
                                $cls = trim(($e['class_name'] ?? '') . ' ' . ($e['section_name'] ?? ''));
                                if ($cls !== '') {
                                    echo ' [' . h($cls) . ']';
                                }
                                ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php if ($exam): ?>
                <div class="col-md-4 d-grid">
                    <button class="btn btn-primary" type="button" onclick="window.print()">Print Date Sheet</button>
                </div>
                <?php endif; ?>
            </form>
            <?php if ($exam): ?>
            <hr>
            <form method="get" action="<?= h(base_url('/index.php')) ?>" target="_blank" class="row g-2 align-items-end">
                <input type="hidden" name="route" value="academic/dateSheetSlips">
                <input type="hidden" name="exam_id" value="<?= (int)$examId ?>">
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Student date slips for</label>
                    <select class="form-select" name="scope">
                        <option value="class">This class only</option>
                        <option value="group">All classes in this exam (<?= h($exam['exam_group_name'] ?? '') ?>)</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Slips per A4 page</label>
                    <select class="form-select" name="per_page">
                        <option value="auto">Automatic (as many as fit)</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="6">6</option>
                        <option value="8">8</option>
                    </select>
                </div>
                <div class="col-md-4 d-grid">
                    <button class="btn btn-outline-primary" type="submit">Print date slips for students</button>
                </div>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($exam && empty($subjects)): ?>
        <div class="alert alert-warning">
            No subjects are assigned to <?= h(trim(($exam['class_name'] ?? '') . ' ' . ($exam['section_name'] ?? ''))) ?> yet.
            <a href="<?= h(route_url('academic/subjects')) ?>">Add subjects for this class</a> first.
        </div>
    <?php elseif ($exam && $canManage): ?>
        <div class="card shadow-sm border-0 mb-3">
            <div class="card-body">
                <h2 class="h6 mb-1">Schedule Subjects</h2>
                <div class="text-muted small mb-3">
                    Give each subject its own date and time — leave a subject blank to keep it off the printed sheet.
                </div>
                <form method="post" action="<?= htmlspecialchars($dateSheetUrl, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="exam_id" value="<?= (int)$examId ?>">
                    <div class="table-responsive">
                        <table class="table table-sm align-middle mb-3">
                            <thead>
                            <tr>
                                <th>Subject</th>
                                <th style="width:160px;">Date</th>
                                <th style="width:130px;">Start Time</th>
                                <th style="width:130px;">End Time</th>
                                <th style="width:110px;">Total Marks</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($subjects as $i => $sub): ?>
                                <?php
                                $sid = (int)$sub['id'];
                                $row = $scheduleMap[$sid] ?? null;
                                $rDate = $row['scheduled_date'] ?? '';
                                $rStart = !empty($row['start_time']) ? substr((string)$row['start_time'], 0, 5) : '';
                                $rEnd = !empty($row['end_time']) ? substr((string)$row['end_time'], 0, 5) : '';
                                $rMarks = $row['total_marks'] ?? '';
                                ?>
                                <tr>
                                    <td class="fw-semibold">
                                        <?= h($sub['subject_name']) ?>
                                        <input type="hidden" name="subject_id[]" value="<?= $sid ?>">
                                    </td>
                                    <td><input class="form-control form-control-sm" type="date" name="scheduled_date[]" value="<?= h((string)$rDate) ?>"></td>
                                    <td><input class="form-control form-control-sm" type="time" name="start_time[]" value="<?= h($rStart) ?>"></td>
                                    <td><input class="form-control form-control-sm" type="time" name="end_time[]" value="<?= h($rEnd) ?>"></td>
                                    <td><input class="form-control form-control-sm" type="number" min="1" step="1" name="total_marks[]" value="<?= h((string)$rMarks) ?>" placeholder="e.g. 50"></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <button class="btn btn-primary" type="submit">Save Date Sheet</button>
                </form>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php if ($exam): ?>
    <div class="card shadow-sm border-0 ds-print-card">
        <div class="card-body">
            <div class="ds-header d-flex align-items-center gap-3">
                <?php if ($logoPath !== ''): ?>
                    <img src="<?= htmlspecialchars(base_url($logoPath), ENT_QUOTES, 'UTF-8') ?>" alt="Logo" style="max-height:56px;width:auto;">
                <?php endif; ?>
                <div>
                    <div style="font-size:1.15rem;font-weight:700;"><?= h($schoolName) ?></div>
                    <div class="text-muted small">Examination Date Sheet</div>
                </div>
            </div>

            <div class="text-center mb-3">
                <div class="ds-title"><?= h($exam['exam_name'] ?? '') ?></div>
                <div class="text-muted small">
                    <?= h(($exam['exam_type_name'] ?? '') . ' / ' . ($exam['exam_group_name'] ?? '')) ?>
                </div>
            </div>

            <div class="row ds-meta-row mb-3">
                <div class="col-md-6">
                    <strong>Class:</strong> <?= h(trim(($exam['class_name'] ?? '') . ' ' . ($exam['section_name'] ?? ''))) ?>
                </div>
                <div class="col-md-6 text-md-end">
                    <strong>Total Subjects:</strong> <?= count($printRows) ?>
                </div>
            </div>

            <?php if (empty($printRows)): ?>
                <div class="alert alert-light border text-muted mb-0">
                    No subject dates have been scheduled yet<?= $canManage ? ' — fill in the table above and save.' : '.' ?>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered ds-table mb-0">
                        <thead>
                        <tr>
                            <th style="width:50px;">#</th>
                            <th>Subject</th>
                            <th>Day</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Total Marks</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($printRows as $i => $r): ?>
                            <?php
                            $dayLabel = '';
                            if (!empty($r['scheduled_date'])) {
                                $ts = strtotime((string)$r['scheduled_date']);
                                if ($ts !== false) {
                                    $dayLabel = $dayNames[(int)date('w', $ts)];
                                }
                            }
                            $timeLabel = '';
                            if (!empty($r['start_time'])) {
                                $timeLabel = substr((string)$r['start_time'], 0, 5);
                                if (!empty($r['end_time'])) {
                                    $timeLabel .= ' – ' . substr((string)$r['end_time'], 0, 5);
                                }
                            }
                            ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td class="fw-semibold"><?= h($r['subject_name']) ?></td>
                                <td><?= h($dayLabel) ?: '<span class="text-muted">—</span>' ?></td>
                                <td><?= h($r['scheduled_date'] ?? '') ?: '<span class="text-muted">—</span>' ?></td>
                                <td><?= h($timeLabel) ?: '<span class="text-muted">—</span>' ?></td>
                                <td><?= !empty($r['total_marks']) ? (int)$r['total_marks'] : '<span class="text-muted">—</span>' ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="row mt-2">
                    <div class="col-6"><div class="ds-sign-line">Class Teacher</div></div>
                    <div class="col-6 text-end"><div class="ds-sign-line ms-auto">Principal</div></div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php else: ?>
    <div class="card shadow-sm border-0 ds-no-print">
        <div class="card-body text-muted">Select an exam to build its date sheet.</div>
    </div>
<?php endif; ?>
