<?php
// Variables: $types,$error
$types = $types ?? [];
$typesUrl = base_url('/index.php?route=academic/examTypes');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Exam Types</h1>
        <div class="text-muted">Create categories like Midterm, Final, Monthly Tests.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Create Exam Type</h2>
                <form method="post" action="<?= htmlspecialchars($typesUrl, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="action" value="save">
                    <div class="mb-3">
                        <label class="form-label">Name *</label>
                        <input class="form-control" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" rows="3"></textarea>
                    </div>
                    <button class="btn btn-primary w-100" type="submit">Create</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-3">Existing Types</h2>
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0 align-middle">
                        <thead>
                        <tr><th>Name</th><th>Description</th><th style="width:140px;">Actions</th></tr>
                        </thead>
                        <tbody>
                        <?php if (empty($types)): ?>
                            <tr><td colspan="3" class="text-muted">No types yet.</td></tr>
                        <?php else: ?>
                            <?php foreach ($types as $t): ?>
                                <tr>
                                    <td class="fw-semibold"><?= h($t['name'] ?? '') ?></td>
                                    <td class="text-muted small"><?= h($t['description'] ?? '') ?></td>
                                    <td class="text-nowrap">
                                        <button type="button" class="btn btn-sm btn-outline-primary"
                                                data-bs-toggle="modal" data-bs-target="#editTypeModal"
                                                data-id="<?= (int)$t['id'] ?>"
                                                data-name="<?= h($t['name'] ?? '') ?>"
                                                data-description="<?= h($t['description'] ?? '') ?>">
                                            Edit
                                        </button>
                                        <form method="post" action="<?= htmlspecialchars($typesUrl, ENT_QUOTES, 'UTF-8') ?>"
                                              class="d-inline" onsubmit="return confirm('Delete this exam type?');">
                                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
                                            <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Type Modal -->
<div class="modal fade" id="editTypeModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form method="post" action="<?= htmlspecialchars($typesUrl, ENT_QUOTES, 'UTF-8') ?>">
        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" id="edit_type_id" value="">
        <div class="modal-header">
          <h5 class="modal-title">Edit Exam Type</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Name *</label>
            <input class="form-control" name="name" id="edit_type_name" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea class="form-control" name="description" id="edit_type_description" rows="3"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
document.getElementById('editTypeModal')?.addEventListener('show.bs.modal', function (event) {
    var btn = event.relatedTarget;
    if (!btn) return;
    document.getElementById('edit_type_id').value = btn.getAttribute('data-id') || '';
    document.getElementById('edit_type_name').value = btn.getAttribute('data-name') || '';
    document.getElementById('edit_type_description').value = btn.getAttribute('data-description') || '';
});
</script>
