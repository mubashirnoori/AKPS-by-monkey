<?php
// Variables: $classes,$editId,$classToEdit,$error
$editId = (int)($editId ?? 0);
$classToEdit = $classToEdit ?? null;
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Classes</h1>
        <div class="text-muted">Create, update and delete classes.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="row g-3 align-items-start mb-3">
    <div class="col-md-5">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-3"><?= $classToEdit ? 'Edit Class' : 'Create Class' ?></h2>
                <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=academic/classes'), ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="id" value="<?= $classToEdit ? (int)$classToEdit['id'] : '' ?>">

                    <label class="form-label">Class Name *</label>
                    <input class="form-control" name="name" value="<?= h($classToEdit['name'] ?? '') ?>" required>

                    <div class="mt-3 d-flex gap-2">
                        <button class="btn btn-primary w-100" type="submit"><?= $classToEdit ? 'Update' : 'Create' ?></button>
                    </div>

                    <?php if ($classToEdit): ?>
                        <div class="mt-2">
                            <a class="btn btn-outline-secondary w-100" href="<?= htmlspecialchars(base_url('/index.php?route=academic/classes'), ENT_QUOTES, 'UTF-8') ?>">Cancel</a>
                        </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-7">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h2 class="h6 mb-0">Class List</h2>
                    <div class="text-muted small"><?= is_array($classes) ? count($classes) : 0 ?> total</div>
                </div>

                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th style="width: 200px;">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($classes)): ?>
                            <tr><td colspan="2" class="text-muted">No classes found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($classes as $c): ?>
                                <tr>
                                    <td class="fw-semibold"><?= h($c['name'] ?? '') ?></td>
                                    <td>
                                        <a class="btn btn-sm btn-outline-primary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/classes&id=' . (int)$c['id']), ENT_QUOTES, 'UTF-8') ?>">Edit</a>
                                        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=academic/classDelete'), ENT_QUOTES, 'UTF-8') ?>" class="d-inline" onsubmit="return confirm('Delete this class?')">
                                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                            <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                                            <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>

