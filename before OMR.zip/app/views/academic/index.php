<?php
// Academic hub — grouped by workflow so staff can follow steps easily.
?>

<div class="ac-hub">
    <div class="ac-hub__head">
        <div>
            <h1 class="ac-hub__title">Academic</h1>
            <p class="ac-hub__sub">Follow the steps below for exams, marks, timetable and date sheet.</p>
        </div>
    </div>

    <!-- Primary daily actions -->
    <section class="ac-hub__quick" aria-label="Most used">
        <a class="ac-quick ac-quick--marks" href="<?= h(route_url('academic/marksEntry')) ?>">
            <span class="ac-quick__icon"><i class="bi bi-pencil-square"></i></span>
            <span class="ac-quick__text">
                <strong>Marks Entry</strong>
                <small>Enter student scores</small>
            </span>
        </a>
        <a class="ac-quick ac-quick--exam" href="<?= h(route_url('academic/exams')) ?>">
            <span class="ac-quick__icon"><i class="bi bi-journal-check"></i></span>
            <span class="ac-quick__text">
                <strong>Create Exams</strong>
                <small>New exam for a class</small>
            </span>
        </a>
        <a class="ac-quick ac-quick--sheet" href="<?= h(route_url('academic/dateSheet')) ?>">
            <span class="ac-quick__icon"><i class="bi bi-calendar3"></i></span>
            <span class="ac-quick__text">
                <strong>Date Sheet</strong>
                <small>Print exam schedule</small>
            </span>
        </a>
        <a class="ac-quick ac-quick--time" href="<?= h(route_url('academic/timetable')) ?>">
            <span class="ac-quick__icon"><i class="bi bi-clock-history"></i></span>
            <span class="ac-quick__text">
                <strong>Timetable</strong>
                <small>Class weekly schedule</small>
            </span>
        </a>
        <a class="ac-quick ac-quick--report" href="<?= h(route_url('academic/certificate')) ?>">
            <span class="ac-quick__icon"><i class="bi bi-file-earmark-text"></i></span>
            <span class="ac-quick__text">
                <strong>Report Cards</strong>
                <small>Print certificates</small>
            </span>
        </a>
        <a class="ac-quick ac-quick--admission" href="<?= h(route_url('academic/admissionForm')) ?>" target="_blank" rel="noopener">
            <span class="ac-quick__icon"><i class="bi bi-file-earmark-person"></i></span>
            <span class="ac-quick__text">
                <strong>Admission Form</strong>
                <small>Print a blank form</small>
            </span>
        </a>
    </section>

    <!-- Exam workflow -->
    <section class="ac-flow">
        <div class="ac-flow__head">
            <h2 class="ac-flow__title">Exam workflow</h2>
            <p class="ac-flow__hint">Do these in order the first time. Later you usually only need steps 3–6.</p>
        </div>
        <ol class="ac-steps">
            <li class="ac-step">
                <span class="ac-step__num">1</span>
                <div class="ac-step__body">
                    <div class="ac-step__name">Exam Types</div>
                    <div class="ac-step__desc">Midterm, Final, Monthly…</div>
                    <a class="ac-step__btn" href="<?= h(route_url('academic/examTypes')) ?>">Open</a>
                </div>
            </li>
            <li class="ac-step">
                <span class="ac-step__num">2</span>
                <div class="ac-step__body">
                    <div class="ac-step__name">Exam Groups</div>
                    <div class="ac-step__desc">Passing rules &amp; criteria</div>
                    <a class="ac-step__btn" href="<?= h(route_url('academic/examGroups')) ?>">Open</a>
                </div>
            </li>
            <li class="ac-step ac-step--focus">
                <span class="ac-step__num">3</span>
                <div class="ac-step__body">
                    <div class="ac-step__name">Create Exams</div>
                    <div class="ac-step__desc">Exam instance for a class</div>
                    <a class="ac-step__btn" href="<?= h(route_url('academic/exams')) ?>">Open</a>
                </div>
            </li>
            <li class="ac-step ac-step--focus">
                <span class="ac-step__num">4</span>
                <div class="ac-step__body">
                    <div class="ac-step__name">Date Sheet</div>
                    <div class="ac-step__desc">Publish / print schedule</div>
                    <a class="ac-step__btn" href="<?= h(route_url('academic/dateSheet')) ?>">Open</a>
                </div>
            </li>
            <li class="ac-step ac-step--focus">
                <span class="ac-step__num">5</span>
                <div class="ac-step__body">
                    <div class="ac-step__name">Marks Entry</div>
                    <div class="ac-step__desc">Enter scores by subject</div>
                    <a class="ac-step__btn" href="<?= h(route_url('academic/marksEntry')) ?>">Open</a>
                </div>
            </li>
            <li class="ac-step ac-step--focus">
                <span class="ac-step__num">6</span>
                <div class="ac-step__body">
                    <div class="ac-step__name">Report Cards</div>
                    <div class="ac-step__desc">Print results</div>
                    <a class="ac-step__btn" href="<?= h(route_url('academic/certificate')) ?>">Open</a>
                </div>
            </li>
        </ol>
    </section>

    <div class="ac-grid">
        <!-- Timetable -->
        <section class="ac-panel">
            <h2 class="ac-panel__title">Timetable</h2>
            <p class="ac-panel__hint">Weekly class schedule</p>
            <div class="ac-links">
                <a href="<?= h(route_url('academic/timetable')) ?>">
                    <strong>Build timetable</strong>
                    <span>Periods by class / section</span>
                </a>
                <a href="<?= h(route_url('academic/teacherAssignments')) ?>">
                    <strong>Teacher assignments</strong>
                    <span>Who teaches which subject</span>
                </a>
                <a href="<?= h(route_url('academic/subjects')) ?>">
                    <strong>Subjects</strong>
                    <span>Add or edit subjects</span>
                </a>
            </div>
        </section>

        <!-- Grades & cards -->
        <section class="ac-panel">
            <h2 class="ac-panel__title">Grades &amp; cards</h2>
            <p class="ac-panel__hint">After marks are entered</p>
            <div class="ac-links">
                <a href="<?= h(route_url('academic/gradeSettings')) ?>">
                    <strong>Grade settings</strong>
                    <span>A+, A, B boundaries</span>
                </a>
                <a href="<?= h(route_url('academic/certificate')) ?>">
                    <strong>Report cards</strong>
                    <span>Print certificates</span>
                </a>
                <a href="<?= h(route_url('academic/idCard')) ?>">
                    <strong>ID cards</strong>
                    <span>Student identity cards</span>
                </a>
                <a href="<?= h(route_url('academic/courses')) ?>">
                    <strong>Online Courses</strong>
                    <span>Create &amp; assign to students</span>
                </a>
            </div>
        </section>

        <!-- School structure -->
        <section class="ac-panel">
            <h2 class="ac-panel__title">School structure</h2>
            <p class="ac-panel__hint">Set up once, then rarely change</p>
            <div class="ac-links">
                <a href="<?= h(route_url('academic/classes')) ?>">
                    <strong>Classes</strong>
                    <span>Class names (e.g. 8th)</span>
                </a>
                <a href="<?= h(route_url('academic/sections')) ?>">
                    <strong>Sections</strong>
                    <span>Section names (e.g. A)</span>
                </a>
                <a href="<?= h(route_url('academic/classSections')) ?>">
                    <strong>Class + Section</strong>
                    <span>Combine into 8th A</span>
                </a>
            </div>
        </section>
    </div>
</div>

<style>
.ac-hub { max-width: 1100px; }
.ac-hub__title {
    margin: 0;
    font-size: 1.5rem;
    font-weight: 750;
    color: #f8fafc;
    border: 0 !important;
    padding: 0 !important;
}
.ac-hub__sub { margin: .25rem 0 0; color: #94a3b8; font-size: .95rem; }
.ac-hub__head { margin-bottom: 1.15rem; }

.ac-hub__quick {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: .75rem;
    margin-bottom: 1.25rem;
}
@media (max-width: 991px) {
    .ac-hub__quick { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 575px) {
    .ac-hub__quick { grid-template-columns: 1fr; }
}

.ac-quick {
    display: flex;
    align-items: center;
    gap: .75rem;
    padding: .9rem 1rem;
    border-radius: 14px;
    text-decoration: none;
    color: #e5e7eb;
    background: #161b22;
    border: 1px solid #2a3340;
    box-shadow: 0 8px 20px rgba(0, 0, 0, .25);
    transition: border-color .15s ease, transform .15s ease;
}
.ac-quick:hover { border-color: #475569; color: #fff; transform: translateY(-1px); }
.ac-quick__icon {
    width: 42px; height: 42px; border-radius: 12px;
    display: inline-flex; align-items: center; justify-content: center;
    font-size: 1.2rem; flex-shrink: 0;
}
.ac-quick__text { display: flex; flex-direction: column; min-width: 0; }
.ac-quick__text strong { font-size: .95rem; line-height: 1.2; color: #f8fafc; }
.ac-quick__text small { color: #94a3b8; font-size: .78rem; margin-top: .15rem; }

.ac-quick--marks .ac-quick__icon { background: #052e1c; color: #4ade80; }
.ac-quick--exam .ac-quick__icon { background: #0c2744; color: #38bdf8; }
.ac-quick--sheet .ac-quick__icon { background: #3b2a0a; color: #fbbf24; }
.ac-quick--time .ac-quick__icon { background: #1e1b4b; color: #c4b5fd; }
.ac-quick--report .ac-quick__icon { background: #3b1530; color: #f9a8d4; }
.ac-quick--admission .ac-quick__icon { background: #062e2b; color: #2dd4bf; }

.ac-flow {
    background: #161b22;
    border: 1px solid #2a3340;
    border-radius: 16px;
    padding: 1.1rem 1.15rem 1.2rem;
    margin-bottom: 1.15rem;
    box-shadow: 0 10px 24px rgba(0, 0, 0, .25);
}
.ac-flow__title {
    margin: 0;
    font-size: 1.05rem;
    color: #f8fafc;
    border: 0 !important;
    padding: 0 !important;
}
.ac-flow__hint { margin: .2rem 0 0; color: #94a3b8; font-size: .85rem; }

.ac-steps {
    list-style: none;
    margin: 1rem 0 0;
    padding: 0;
    display: grid;
    grid-template-columns: repeat(6, 1fr);
    gap: .65rem;
}
@media (max-width: 991px) {
    .ac-steps { grid-template-columns: repeat(3, 1fr); }
}
@media (max-width: 575px) {
    .ac-steps { grid-template-columns: 1fr 1fr; }
}

.ac-step {
    display: flex;
    flex-direction: column;
    gap: .55rem;
    padding: .85rem .8rem;
    border-radius: 12px;
    background: #0f172a;
    border: 1px solid #2a3340;
}
.ac-step--focus {
    background: #0c2744;
    border-color: #1e3a5f;
}
.ac-step__num {
    width: 26px; height: 26px; border-radius: 50%;
    display: inline-flex; align-items: center; justify-content: center;
    font-size: .8rem; font-weight: 700;
    background: #0ea5e9; color: #fff;
}
.ac-step--focus .ac-step__num { background: #38bdf8; color: #0b0f14; }
.ac-step__name { font-weight: 700; font-size: .9rem; color: #f8fafc; }
.ac-step__desc { font-size: .75rem; color: #94a3b8; margin: .15rem 0 .45rem; min-height: 2.2em; }
.ac-step__btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: .35rem .65rem;
    border-radius: 8px;
    background: #121820;
    border: 1px solid #334155;
    color: #e2e8f0;
    text-decoration: none;
    font-size: .8rem;
    font-weight: 600;
}
.ac-step__btn:hover { background: #0ea5e9; color: #fff; border-color: #0ea5e9; }

.ac-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: .85rem;
}
@media (max-width: 991px) {
    .ac-grid { grid-template-columns: 1fr; }
}

.ac-panel {
    background: #161b22;
    border: 1px solid #2a3340;
    border-radius: 16px;
    padding: 1rem 1.05rem;
}
.ac-panel__title {
    margin: 0;
    font-size: 1rem;
    color: #f8fafc;
    border: 0 !important;
    padding: 0 !important;
}
.ac-panel__hint { margin: .15rem 0 .75rem; color: #94a3b8; font-size: .8rem; }
.ac-links { display: flex; flex-direction: column; gap: .45rem; }
.ac-links a {
    display: block;
    padding: .7rem .8rem;
    border-radius: 10px;
    text-decoration: none;
    background: #0f172a;
    border: 1px solid #2a3340;
    color: #e5e7eb;
}
.ac-links a:hover { border-color: #475569; background: #1f2937; color: #fff; }
.ac-links a strong { display: block; font-size: .9rem; color: #f8fafc; }
.ac-links a span { display: block; font-size: .75rem; color: #94a3b8; margin-top: .1rem; }
</style>
