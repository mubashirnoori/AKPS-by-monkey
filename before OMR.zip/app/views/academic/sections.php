<?php
// Variables: $sections,$editId,$sectionToEdit,$error
$editId = (int)($editId ?? 0);
$sectionToEdit = $sectionToEdit ?? null;
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Sections</h1>
        <div class="text-muted">Create, update and delete sections.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="row g-3 align-items-start mb-3">
    <div class="col-md-5">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-3"><?= $sectionToEdit ? 'Edit Section' : 'Create Section' ?></h2>
                <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=academic/sections'), ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="id" value="<?= $sectionToEdit ? (int)$sectionToEdit['id'] : '' ?>">

                    <label class="form-label">Section Name *</label>
                    <input class="form-control" name="name" value="<?= h($sectionToEdit['name'] ?? '') ?>" required>

                    <div class="mt-3 d-flex gap-2">
                        <button class="btn btn-primary w-100" type="submit"><?= $sectionToEdit ? 'Update' : 'Create' ?></button>
                    </div>

                    <?php if ($sectionToEdit): ?>
                        <div class="mt-2">
                            <a class="btn btn-outline-secondary w-100" href="<?= htmlspecialchars(base_url('/index.php?route=academic/sections'), ENT_QUOTES, 'UTF-8') ?>">Cancel</a>
                        </div>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-7">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <h2 class="h6 mb-0">Section List</h2>
                    <div class="text-muted small"><?= is_array($sections) ? count($sections) : 0 ?> total</div>
                </div>

                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th style="width: 200px;">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($sections)): ?>
                            <tr><td colspan="2" class="text-muted">No sections found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($sections as $s): ?>
                                <tr>
                                    <td class="fw-semibold"><?= h($s['name'] ?? '') ?></td>
                                    <td>
                                        <a class="btn btn-sm btn-outline-primary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/sections&id=' . (int)$s['id']), ENT_QUOTES, 'UTF-8') ?>">Edit</a>
                                        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=academic/sectionDelete'), ENT_QUOTES, 'UTF-8') ?>" class="d-inline" onsubmit="return confirm('Delete this section?')">
                                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                            <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
                                            <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

