<?php
// Variables: $student,$students,$studentId,$classSections,$classSectionId,$q,$totalMatches,$limit,$page,$totalPages,$allowedPerPage
$student = $student ?? null;
$settingsMap = [];
$schoolName  = 'ARC School';
$logoPath    = '';
try {
    if (class_exists('Database')) {
        $rows = Database::fetchAll('SELECT `key`, `value` FROM settings');
        foreach ($rows as $r) { $settingsMap[$r['key']] = $r['value']; }
    }
    $schoolName = $settingsMap['branding_school_name'] ?? $settingsMap['institute_name'] ?? 'ARC School';
    $logoPath   = $settingsMap['branding_logo_path'] ?? '';
} catch (Throwable $e) {}

$bulkStudents = $bulkStudents ?? [];

// One card's markup, shared by the single-card view and every card in the
// 4-up bulk print grid, so both stay visually identical.
if (!function_exists('render_idcard_markup')) {
    function render_idcard_markup(array $student, ?string $photoUrl, string $schoolName, string $logoPath): void
    {
        $fullName  = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
        $initials  = strtoupper(substr((string)($student['first_name'] ?? 'S'), 0, 1) . substr((string)($student['last_name'] ?? 'M'), 0, 1));
        $classInfo = trim(($student['current_class_name'] ?? '') . ' ' . ($student['current_section_name'] ?? ''));
        $rollNo    = (int)($student['roll_number'] ?? 0);
        ?>
        <div class="idcard">
            <!-- Golden stripe at top -->
            <div class="idcard-stripe"></div>

            <!-- Header with logo -->
            <div class="idcard-header">
                <?php if ($logoPath): ?>
                    <img src="<?= htmlspecialchars(base_url($logoPath), ENT_QUOTES, 'UTF-8') ?>" alt="Logo" class="idcard-logo">
                <?php else: ?>
                    <div class="idcard-logo-fallback"><i class="bi bi-mortarboard-fill"></i></div>
                <?php endif; ?>
                <div class="idcard-school"><?= h($schoolName) ?></div>
                <div class="idcard-subtitle">Student Identity Card</div>
            </div>

            <!-- Body -->
            <div class="idcard-body">
                <div class="idcard-avatar">
                    <?php if (!empty($photoUrl)): ?>
                        <img src="<?= h($photoUrl) ?>" alt="">
                    <?php else: ?>
                        <?= h($initials) ?>
                    <?php endif; ?>
                </div>
                <div class="idcard-name"><?= h($fullName) ?></div>
                <div class="idcard-class"><?= $classInfo !== '' ? h($classInfo) : '—' ?></div>

                <div class="idcard-fields">
                    <div class="idcard-field">
                        <span class="idcard-field-label">Adm. No</span>
                        <span class="idcard-field-val"><?= h($student['admission_no'] ?? '') ?: '—' ?></span>
                    </div>
                    <div class="idcard-field">
                        <span class="idcard-field-label">Father</span>
                        <span class="idcard-field-val"><?= !empty($student['father_name']) ? h($student['father_name']) : '—' ?></span>
                    </div>
                    <div class="idcard-field">
                        <span class="idcard-field-label">Roll No</span>
                        <span class="idcard-field-val"><?= $rollNo > 0 ? $rollNo : '—' ?></span>
                    </div>
                    <div class="idcard-field">
                        <span class="idcard-field-label">D.O.B</span>
                        <span class="idcard-field-val"><?= !empty($student['dob']) ? h(date('d M Y', strtotime((string)$student['dob']))) : '—' ?></span>
                    </div>
                    <div class="idcard-field">
                        <span class="idcard-field-label">Contact</span>
                        <span class="idcard-field-val"><?= !empty($student['phone']) ? h($student['phone']) : '—' ?></span>
                    </div>
                    <div class="idcard-field">
                        <span class="idcard-field-label">Session</span>
                        <span class="idcard-field-val"><?= date('Y') ?>–<?= date('Y') + 1 ?></span>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <div class="idcard-footer">
                <span class="idcard-id-badge">ID #<?= (int)$student['id'] ?></span>
                <span class="idcard-valid">Valid: <?= date('Y') ?>–<?= date('Y') + 1 ?></span>
            </div>

            <!-- Bottom stripe -->
            <div class="idcard-stripe"></div>
        </div>
        <?php
    }
}
?>
<style>
/* -------- ID CARD STYLES -------- */
.idcard-wrap { max-width: 380px; }

.idcard {
    width: 340px;
    border-radius: 18px;
    overflow: hidden;
    box-shadow: 0 12px 40px rgba(0,0,0,.18);
    font-family: 'Segoe UI', system-ui, sans-serif;
    background: #fff;
    border: none;
    position: relative;
}

/* Top strip with school branding */
.idcard-header {
    background: linear-gradient(135deg, #0f2156 0%, #1a3a7a 50%, #1e4db5 100%);
    padding: 16px 18px 14px;
    text-align: center;
    position: relative;
}
.idcard-header::after {
    content: '';
    position: absolute;
    bottom: -12px; left: 0; right: 0;
    height: 24px;
    background: #fff;
    border-radius: 50% 50% 0 0 / 100% 100% 0 0;
}
.idcard-logo {
    height: 48px;
    width: auto;
    border-radius: 8px;
    margin-bottom: 6px;
    background: rgba(255,255,255,.15);
    padding: 3px 6px;
}
.idcard-logo-fallback {
    width: 48px; height: 48px;
    border-radius: 12px;
    background: rgba(255,255,255,.2);
    display: inline-flex; align-items: center; justify-content: center;
    font-size: 1.5rem; color: #fff;
    margin-bottom: 6px;
}
.idcard-school {
    color: #fff;
    font-size: .78rem;
    font-weight: 700;
    letter-spacing: 1.2px;
    text-transform: uppercase;
    opacity: .92;
    line-height: 1.2;
}
.idcard-subtitle {
    color: rgba(255,255,255,.65);
    font-size: .62rem;
    letter-spacing: 2px;
    text-transform: uppercase;
    margin-top: 2px;
}

/* Body */
.idcard-body {
    padding: 24px 20px 18px;
    text-align: center;
    position: relative;
}

/* Avatar circle */
.idcard-avatar {
    width: 88px; height: 88px;
    border-radius: 50%;
    background: linear-gradient(135deg, #1a3a7a, #1e4db5);
    color: #fff;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.8rem; font-weight: 800;
    margin: 0 auto 10px;
    border: 3px solid #e8edf8;
    box-shadow: 0 4px 14px rgba(30,77,181,.2);
    overflow: hidden;
}
.idcard-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.idcard-name {
    font-size: 1.1rem;
    font-weight: 700;
    color: #0f2156;
    letter-spacing: -.2px;
}
.idcard-class {
    font-size: .78rem;
    color: #6b7280;
    margin-top: 2px;
}

/* Fields */
.idcard-fields {
    margin-top: 12px;
    text-align: left;
}
.idcard-field {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 5px 0;
    border-bottom: 1px solid #f1f5f9;
    font-size: .78rem;
}
.idcard-field:last-child { border-bottom: none; }
.idcard-field-label {
    color: #94a3b8;
    width: 80px;
    flex-shrink: 0;
    font-size: .72rem;
    text-transform: uppercase;
    letter-spacing: .5px;
}
.idcard-field-val {
    color: #1e293b;
    font-weight: 600;
}

/* Bottom strip */
.idcard-footer {
    background: #f8faff;
    border-top: 1px solid #e8edf8;
    padding: 8px 18px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.idcard-id-badge {
    font-size: .7rem;
    font-weight: 700;
    color: #1a3a7a;
    background: #e8edf8;
    border-radius: 20px;
    padding: 3px 10px;
}
.idcard-valid {
    font-size: .65rem;
    color: #94a3b8;
}

/* Magnetic stripe accent */
.idcard-stripe {
    height: 6px;
    background: linear-gradient(90deg, #0f2156, #1e4db5, #b89a4e, #1e4db5, #0f2156);
}

/* -------- BULK PRINT: 4 cards per A4 sheet -------- */
/* One .idcard-print-page = one physical sheet. Every card is forced to the
   SAME fixed size here (not just "auto"), because letting card height vary
   with how many optional fields a student has is what caused only 2 cards
   to fit per sheet for students with extra fields (DOB/contact) — the 2nd
   row silently overflowed onto its own page. A fixed size guarantees 2x2
   always fits within one A4 sheet. */
.idcard-print-page {
    display: grid;
    grid-template-columns: repeat(2, 88mm);
    grid-template-rows: repeat(2, 128mm);
    justify-content: center;
    align-content: center;
    gap: 6mm 8mm;
    page-break-after: always;
}
.idcard-print-page:last-of-type { page-break-after: auto; }
.idcard-cut-box {
    width: 88mm;
    height: 128mm;
    box-sizing: border-box;
    border: 1px dashed #aaa;
    border-radius: 14px;
    padding: 2mm;
    display: flex;
    align-items: center;
    justify-content: center;
    page-break-inside: avoid;
    break-inside: avoid;
    overflow: hidden;
}
/* Scaled-down card variant used only inside the print grid, sized in mm
   (not the 340px on-screen size) so it reliably fits the fixed cell above
   on every renderer, with a little headroom to spare. */
.idcard-print-page .idcard {
    width: 100%;
    height: 100%;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
}
.idcard-print-page .idcard-header { padding: 10px 12px 8px; }
.idcard-print-page .idcard-logo,
.idcard-print-page .idcard-logo-fallback { height: 34px; width: 34px; margin-bottom: 4px; }
.idcard-print-page .idcard-school { font-size: .68rem; }
.idcard-print-page .idcard-subtitle { font-size: .54rem; }
.idcard-print-page .idcard-body { flex: 1; padding: 14px 16px 8px; min-height: 0; }
.idcard-print-page .idcard-avatar { width: 64px; height: 64px; font-size: 1.25rem; margin-bottom: 6px; }
.idcard-print-page .idcard-name { font-size: .92rem; }
.idcard-print-page .idcard-class { font-size: .68rem; }
.idcard-print-page .idcard-fields { margin-top: 8px; }
.idcard-print-page .idcard-field { padding: 3px 0; font-size: .64rem; gap: 6px; }
.idcard-print-page .idcard-field-label { width: 62px; font-size: .58rem; }
.idcard-print-page .idcard-footer { padding: 5px 12px; }
.idcard-print-page .idcard-id-badge,
.idcard-print-page .idcard-valid { font-size: .58rem; }

/* On screen, stack bulk pages with a visible gap so they read as separate
   sheets; the print rule below removes that gap so the sheet boundary is
   only the physical paper edge. */
.idcard-print-page + .idcard-print-page { margin-top: 24px; padding-top: 24px; border-top: 2px dashed #d8dee8; }

@media print {
    .sms-no-print, .navbar, aside, nav, .nav-rail, .nav-rail-backdrop, .btn, form, .card.shadow-sm { display: none !important; }
    /* The dashboard's dark theme (body background, app shell, sidebar rail) is
       for on-screen use only — without this the page prints/PDFs with a black
       background around the card instead of white. */
    html, body, .app-shell, .app-shell__main, main {
        background: #fff !important;
        color: #000 !important;
        padding: 0 !important;
        margin: 0 !important;
    }
    .idcard-wrap { margin: 0 auto; }
    .idcard { box-shadow: none; border: 1px solid #ccc; }
    * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
    .idcard-header { background: #0f2156 !important; }
    .idcard-avatar { background: #1a3a7a !important; }
    .idcard-cut-box { border-color: #999; }
    .idcard-print-page + .idcard-print-page { margin-top: 0; padding-top: 0; border-top: none; }
    @page { size: A4; margin: 8mm; }
}
</style>

<!-- Controls (screen only) -->
<div class="sms-no-print">
    <div class="d-flex align-items-center justify-content-between mb-3">
        <div>
            <h1 class="h4 mb-0">Student ID Cards</h1>
            <div class="text-muted small">Filter, tick the students you need, then print — 4 cards per A4 sheet.</div>
        </div>
        <a class="btn btn-outline-secondary" href="<?= h(route_url('academic/index')) ?>">Back</a>
    </div>

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-body">
            <form method="get" action="<?= h(base_url('/index.php')) ?>" id="idcardSelectForm" data-bulk-select="idcards">
                <input type="hidden" name="route" value="academic/idCard">

                <!-- One filter row — class + search — both apply to the same list below. -->
                <div class="row g-2 align-items-end mb-3">
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Class</label>
                        <select name="class_section_id" class="form-select" onchange="this.form.submit()">
                            <option value="0">All classes</option>
                            <?php foreach (($classSections ?? []) as $cs): ?>
                                <option value="<?= (int)$cs['id'] ?>" <?= (int)($classSectionId ?? 0) === (int)$cs['id'] ? 'selected' : '' ?>>
                                    <?= h(($cs['class_name'] ?? '') . ' — ' . ($cs['section_name'] ?? '')) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-5">
                        <label class="form-label fw-semibold">Search</label>
                        <input type="text" name="q" class="form-control" autocomplete="off"
                               value="<?= h($q ?? '') ?>" placeholder="Name or admission no…">
                    </div>
                    <div class="col-md-3 d-grid">
                        <button class="btn btn-outline-primary" type="submit">
                            <i class="bi bi-funnel me-1"></i>Apply Filters
                        </button>
                    </div>
                </div>

                <!-- Selection is always visible here (it's the SAME form/list you print
                     from) and is deliberately kept when you change the class/search
                     filters above, so you can build one batch across several classes —
                     "Clear selection" resets it whenever you want a fresh batch. -->
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 p-2 mb-3 rounded"
                     style="background: var(--sms-surface-2, #f8faff); border: 1px solid var(--sms-border, #e8edf8);">
                    <div class="small text-muted">
                        <span class="badge text-bg-primary me-1" data-select-count>0 selected</span>
                        Selections carry over when you change filters — use <strong>Clear selection</strong> to start a new batch.
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <button class="btn btn-link btn-sm p-0" type="button" data-select-clear style="display:none;">Clear selection</button>
                        <button class="btn btn-success btn-sm" type="submit" name="print" value="1">
                            <i class="bi bi-printer me-1"></i>Print Selected
                        </button>
                    </div>
                </div>

                <?php if (!empty($students)): ?>
                <div class="table-responsive" style="max-height:380px;overflow-y:auto;">
                <table class="table table-sm table-striped mb-0">
                    <thead>
                    <tr>
                        <th style="width:40px;"><input type="checkbox" data-select-all></th>
                        <th style="width:60px;">#ID</th>
                        <th>Student</th>
                        <th>Admission</th>
                        <th>Class / Section</th>
                        <th style="width:60px;">Card</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($students as $s): ?>
                    <tr>
                        <td><input class="form-check-input" type="checkbox" data-select-item name="student_ids[]" value="<?= (int)$s['id'] ?>"></td>
                        <td class="text-muted small"><?= (int)$s['id'] ?></td>
                        <td><?= h(trim(($s['first_name'] ?? '') . ' ' . ($s['last_name'] ?? ''))) ?></td>
                        <td><?= h($s['admission_no'] ?? '') ?></td>
                        <td>
                            <?php if (!empty($s['current_class_name'])): ?>
                                <?= h($s['current_class_name'] . ' ' . ($s['current_section_name'] ?? '')) ?>
                            <?php else: ?>
                                <span class="text-muted">Unassigned</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a class="btn btn-sm btn-outline-secondary" title="Print just this one card" target="_blank"
                               href="<?= h(base_url('/index.php?route=academic/idCard&student_id=' . (int)$s['id'] . '&class_section_id=' . (int)($classSectionId ?? 0) . '&q=' . urlencode($q ?? ''))) ?>">
                                <i class="bi bi-printer"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                </div>

                <?php
                // Pagination footer — page size selector + prev/next + numbered pages.
                // These are plain links (not form submits) so the current selection,
                // restored client-side from storage on page load, survives a page change
                // exactly the way it already survives a class/search filter change.
                $curPage      = max(1, (int)($page ?? 1));
                $curPerPage   = (int)($limit ?? 20);
                $curTotal     = (int)($totalMatches ?? 0);
                $curTotalPgs  = max(1, (int)($totalPages ?? 1));
                $perPageOpts  = $allowedPerPage ?? [20, 30, 50, 100];
                $rangeStart   = $curTotal > 0 ? (($curPage - 1) * $curPerPage) + 1 : 0;
                $rangeEnd     = $curTotal > 0 ? min($curTotal, $rangeStart + count($students) - 1) : 0;

                $pageUrl = function (int $p) use ($classSectionId, $q, $curPerPage): string {
                    return base_url('/index.php?route=academic/idCard'
                        . '&class_section_id=' . (int)($classSectionId ?? 0)
                        . '&q=' . urlencode($q ?? '')
                        . '&per_page=' . (int)$curPerPage
                        . '&page=' . (int)$p);
                };
                ?>
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mt-3">
                    <div class="d-flex align-items-center gap-2 small text-muted">
                        <span>Showing <?= (int)$rangeStart ?>–<?= (int)$rangeEnd ?> of <?= (int)$curTotal ?></span>
                        <span class="d-flex align-items-center gap-1 ms-2">
                            <label for="idcardPerPage" class="mb-0">Per page</label>
                            <select id="idcardPerPage" name="per_page" class="form-select form-select-sm" style="width:auto;" onchange="this.form.submit()">
                                <?php foreach ($perPageOpts as $opt): ?>
                                    <option value="<?= (int)$opt ?>" <?= $curPerPage === (int)$opt ? 'selected' : '' ?>><?= (int)$opt ?></option>
                                <?php endforeach; ?>
                            </select>
                        </span>
                    </div>

                    <?php if ($curTotalPgs > 1): ?>
                    <nav aria-label="Student list pages">
                        <ul class="pagination pagination-sm mb-0">
                            <li class="page-item <?= $curPage <= 1 ? 'disabled' : '' ?>">
                                <a class="page-link" href="<?= h($pageUrl(max(1, $curPage - 1))) ?>">Prev</a>
                            </li>
                            <?php
                            // Compact numbered window around the current page.
                            $winStart = max(1, $curPage - 2);
                            $winEnd   = min($curTotalPgs, $curPage + 2);
                            if ($winStart > 1): ?>
                                <li class="page-item"><a class="page-link" href="<?= h($pageUrl(1)) ?>">1</a></li>
                                <?php if ($winStart > 2): ?><li class="page-item disabled"><span class="page-link">…</span></li><?php endif; ?>
                            <?php endif; ?>
                            <?php for ($p = $winStart; $p <= $winEnd; $p++): ?>
                                <li class="page-item <?= $p === $curPage ? 'active' : '' ?>">
                                    <a class="page-link" href="<?= h($pageUrl($p)) ?>"><?= (int)$p ?></a>
                                </li>
                            <?php endfor; ?>
                            <?php if ($winEnd < $curTotalPgs): ?>
                                <?php if ($winEnd < $curTotalPgs - 1): ?><li class="page-item disabled"><span class="page-link">…</span></li><?php endif; ?>
                                <li class="page-item"><a class="page-link" href="<?= h($pageUrl($curTotalPgs)) ?>"><?= (int)$curTotalPgs ?></a></li>
                            <?php endif; ?>
                            <li class="page-item <?= $curPage >= $curTotalPgs ? 'disabled' : '' ?>">
                                <a class="page-link" href="<?= h($pageUrl(min($curTotalPgs, $curPage + 1))) ?>">Next</a>
                            </li>
                        </ul>
                    </nav>
                    <div class="small text-muted">Page <?= (int)$curPage ?> of <?= (int)$curTotalPgs ?></div>
                    <?php endif; ?>
                </div>
                <?php else: ?>
                    <div class="text-muted small">No students to show — adjust the filters above.</div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div><!-- /sms-no-print -->


<?php if ($student && empty($bulkStudents)): ?>
<div class="sms-no-print d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0"><?= h(trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''))) ?></h1>
        <div class="text-muted small">ID #<?= (int)$student['id'] ?> — single card.</div>
    </div>
    <button class="btn btn-success" type="button" onclick="window.print()">
        <i class="bi bi-printer me-1"></i>Print ID Card
    </button>
</div>
<div class="idcard-wrap">
    <?php render_idcard_markup($student, $photoUrl ?? null, $schoolName, $logoPath); ?>
</div>
<script>
// This tab was opened specifically to print one card (from the "Card" icon
// in the selection table) — open the print dialog right away rather than
// making the person hunt for the button.
window.addEventListener('load', function () { window.print(); });
</script>
<?php endif; ?>

<?php if (!empty($bulkStudents)): ?>
<div class="sms-no-print d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">Bulk ID Cards</h1>
        <div class="text-muted small">
            <?= count($bulkStudents) ?> card<?= count($bulkStudents) === 1 ? '' : 's' ?> — 4 per A4 sheet. Print, then cut along the dashed guides.
        </div>
    </div>
    <div class="d-flex gap-2">
        <a class="btn btn-outline-secondary" href="<?= h(route_url('academic/idCard')) ?>">Clear results</a>
        <button class="btn btn-success" type="button" onclick="window.print()">
            <i class="bi bi-printer me-1"></i>Print <?= count($bulkStudents) ?> Card<?= count($bulkStudents) === 1 ? '' : 's' ?>
        </button>
    </div>
</div>

<?php foreach (array_chunk($bulkStudents, 4) as $pageEntries): ?>
<div class="idcard-print-page">
    <?php foreach ($pageEntries as $entry): ?>
    <div class="idcard-cut-box">
        <?php render_idcard_markup($entry['student'], $entry['photoUrl'], $schoolName, $logoPath); ?>
    </div>
    <?php endforeach; ?>
</div>
<?php endforeach; ?>

<script>
// Clicking "Print Selected" reloads the page with the print grid built —
// that reload IS the request to print, so open the print dialog right
// away instead of making the person hunt for a second button. Wait for
// full load (photos included) so nothing is missing when the dialog opens.
window.addEventListener('load', function () { window.print(); });
</script>

<?php endif; ?>