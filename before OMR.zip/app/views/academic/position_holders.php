<?php
// Variables: $examNames, $examName, $eligibleClasses, $schoolToppers, $classGroups
$examNames = $examNames ?? [];
$examName = $examName ?? '';
$eligibleClasses = $eligibleClasses ?? [];
$schoolToppers = $schoolToppers ?? [];
$classGroups = $classGroups ?? [];
?>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0 text-uppercase" style="letter-spacing:.5px;">Result — Position Holders Summary</h1>
        <div class="text-muted">School topper and class-wise position holders, generated live from recorded marks.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= h(base_url('/index.php?route=academic/index')) ?>">Back</a>
</div>

<?php if (empty($examNames)): ?>
<div class="card shadow-sm border-0"><div class="card-body">
    <div class="text-muted">No published exam results are available yet.</div>
</div></div>
<?php else: ?>

<form method="get" action="<?= h(base_url('/index.php')) ?>" class="card shadow-sm border-0 mb-3">
    <div class="card-body d-flex align-items-center gap-2 flex-wrap">
        <input type="hidden" name="route" value="academic/positionHolders">
        <label class="form-label mb-0 small text-muted">Exam</label>
        <select name="exam_name" class="form-select form-select-sm" style="max-width:320px;" onchange="this.form.submit()">
            <?php foreach ($examNames as $en): ?>
                <option value="<?= h($en) ?>" <?= $en === $examName ? 'selected' : '' ?>><?= h($en) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</form>

<!-- ===================== SCHOOL TOPPER — CLASSES 5TH TO 8TH (COMBINED) ===================== -->
<div class="card shadow-sm border-0 mb-4" style="background:linear-gradient(135deg, var(--sms-surface-2), var(--sms-surface)); border:1px solid var(--sms-primary) !important;">
    <div class="card-body">
        <h2 class="h6 mb-3" style="color:var(--sms-primary);">
            <i class="bi bi-trophy-fill"></i> School Topper — Classes <?= h(implode(' to ', [reset($eligibleClasses) ?: '', end($eligibleClasses) ?: ''])) ?> (Combined)
        </h2>

        <?php if (empty($schoolToppers)): ?>
            <div class="text-muted">No passing student found across classes <?= h(implode(', ', $eligibleClasses)) ?> for this exam.</div>
        <?php else: ?>
            <div class="d-flex flex-wrap gap-3">
                <?php foreach ($schoolToppers as $t): ?>
                    <div class="rounded-3 p-3" style="min-width:260px; flex:1 1 260px; background:var(--sms-surface); border:1px solid var(--sms-primary);">
                        <div class="fw-bold small mb-2" style="color:var(--sms-primary);"><i class="bi bi-award-fill"></i> Position: 1st</div>
                        <div class="fw-semibold fs-5"><?= h($t['name']) ?></div>
                        <?php if (!empty($t['father_name'])): ?>
                            <div class="text-muted small">Father's Name: <?= h($t['father_name']) ?></div>
                        <?php endif; ?>
                        <div class="text-muted small">Class: <?= h($t['class_name'] ?? '') ?> — Section: <?= h($t['section_name'] ?? '') ?></div>
                        <div class="text-muted small">Admission No: <?= h($t['admission_no'] ?? '') ?></div>
                        <div class="mt-2">
                            <span class="fw-bold fs-5"><?= h(format_mark($t['percentage'])) ?>%</span>
                            <span class="text-muted small">(<?= h(format_mark($t['total_obtained'])) ?> / <?= h(format_mark($t['total_max'])) ?>)</span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- ===================== CLASS-WISE POSITION HOLDERS (SENIOR CLASS FIRST) ===================== -->
<?php if (empty($classGroups)): ?>
<div class="card shadow-sm border-0"><div class="card-body">
    <div class="text-muted">No classes found for this exam.</div>
</div></div>
<?php else: ?>
    <?php foreach ($classGroups as $group): ?>
        <div class="card shadow-sm border-0 mb-3">
            <div class="card-header bg-transparent" style="border-bottom:2px solid var(--sms-primary);">
                <h2 class="h6 mb-0 text-uppercase" style="letter-spacing:.5px;">
                    Class <?= h($group['class_name']) ?> — Position Holders
                </h2>
            </div>
            <div class="card-body">
                <?php foreach ($group['sections'] as $sec): ?>
                    <?php if (count($group['sections']) > 1): ?>
                        <div class="fw-semibold small text-muted mb-2">Section <?= h($sec['section_name']) ?></div>
                    <?php endif; ?>

                    <?php if (empty($sec['rankings'])): ?>
                        <div class="text-muted small mb-3">No exam results have been recorded for this class yet.</div>
                    <?php else: ?>
                        <div class="table-responsive mb-2">
                            <table class="table table-sm table-striped mb-0 align-middle">
                                <thead>
                                    <tr>
                                        <th>Position</th>
                                        <th>Student Name</th>
                                        <th>Father's Name</th>
                                        <th>Class</th>
                                        <th>Section</th>
                                        <th>Admission No</th>
                                        <th class="text-end">Total Obtained</th>
                                        <th class="text-end">Total Marks</th>
                                        <th class="text-end">Percentage</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($sec['rankings'] as $r): ?>
                                        <tr>
                                            <td class="fw-bold"><?= h(ordinal((int)$r['rank'])) ?></td>
                                            <td><?= h($r['name']) ?></td>
                                            <td><?= h($r['father_name'] ?? '') ?></td>
                                            <td><?= h($group['class_name']) ?></td>
                                            <td><?= h($sec['section_name']) ?></td>
                                            <td><?= h($r['admission_no'] ?? '') ?></td>
                                            <td class="text-end"><?= h(format_mark($r['total_obtained'])) ?></td>
                                            <td class="text-end"><?= h(format_mark($r['total_max'])) ?></td>
                                            <td class="text-end fw-semibold"><?= h(format_mark($r['percentage'])) ?>%</td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>

                    <a class="btn btn-sm btn-outline-secondary mb-2" href="<?= h(base_url('/index.php?route=academic/classResult&exam_id=' . (int)$sec['exam_id'])) ?>">
                        <i class="bi bi-table"></i> View Full Class Result
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php endif; ?>
