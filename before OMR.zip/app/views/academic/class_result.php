<?php
// Variables: $exam, $subjects, $pool, $rankByStudent, $ownMarksByStudent
$exam = $exam ?? [];
$subjects = $subjects ?? [];
$pool = $pool ?? [];
$rankByStudent = $rankByStudent ?? [];
$ownMarksByStudent = $ownMarksByStudent ?? [];
?>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0 text-uppercase" style="letter-spacing:.5px;">
            Class <?= h($exam['class_name'] ?? '') ?><?= !empty($exam['section_name']) ? ' — ' . h($exam['section_name']) : '' ?> Result
        </h1>
        <div class="text-muted"><?= h($exam['exam_name'] ?? '') ?><?= !empty($exam['academic_year_label']) ? ' · ' . h($exam['academic_year_label']) : '' ?></div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= h(base_url('/index.php?route=academic/positionHolders')) ?>">Back to Position Holders</a>
</div>

<?php if (empty($pool)): ?>
<div class="card shadow-sm border-0"><div class="card-body">
    <div class="text-muted">No exam results have been recorded for this class yet.</div>
</div></div>
<?php else: ?>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-striped mb-0 align-middle">
                <thead>
                    <tr>
                        <th>Position</th>
                        <th>Student Name</th>
                        <th>Father's Name</th>
                        <th>Admission No</th>
                        <?php foreach ($subjects as $subj): ?>
                            <th class="text-end"><?= h($subj['name']) ?> (<?= h(format_mark($subj['total_marks'])) ?>)</th>
                        <?php endforeach; ?>
                        <th class="text-end">Total Obtained</th>
                        <th class="text-end">Total Marks</th>
                        <th class="text-end">Percentage</th>
                        <th>Result</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pool as $st): ?>
                        <?php $sid = (int)$st['student_id']; $pos = isset($rankByStudent[$sid]) ? ordinal($rankByStudent[$sid]) : ''; ?>
                        <tr>
                            <td class="fw-bold"><?= $pos !== '' ? h($pos) : '<span class="text-muted">—</span>' ?></td>
                            <td><?= h($st['name']) ?></td>
                            <td><?= h($st['father_name'] ?? '') ?></td>
                            <td><?= h($st['admission_no'] ?? '') ?></td>
                            <?php foreach ($subjects as $subj): ?>
                                <?php $score = $ownMarksByStudent[$sid][(int)$subj['id']]['score'] ?? null; ?>
                                <td class="text-end"><?= $score !== null ? h(format_mark($score)) : '<span class="text-muted">—</span>' ?></td>
                            <?php endforeach; ?>
                            <td class="text-end"><?= h(format_mark($st['total_obtained'])) ?></td>
                            <td class="text-end"><?= h(format_mark($st['total_max'])) ?></td>
                            <td class="text-end fw-semibold"><?= h(format_mark($st['percentage'])) ?>%</td>
                            <td>
                                <?php
                                $resultClass = $st['result'] === 'PASS' ? 'text-success' : ($st['result'] === 'FAIL' ? 'text-danger' : 'text-warning-emphasis');
                                ?>
                                <span class="fw-semibold <?= h($resultClass) ?>"><?= h($st['result']) ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php endif; ?>
