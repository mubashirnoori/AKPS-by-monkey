<?php
// Variables: $search,$subjects,$total,$page,$perPage,$subjectToEdit,$editId,$error,$classes,$allSubjectOptions
$search = $search ?? '';
$subjectToEdit = $subjectToEdit ?? null;
$classes = $classes ?? [];
$allSubjectOptions = $allSubjectOptions ?? [];
$page = max(1, (int)($page ?? 1));
$perPage = (int)($perPage ?? 50);
$totalPages = max(1, (int)ceil((int)($total ?? 0) / max(1, $perPage)));
$routeBase = base_url('/index.php');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Subjects</h1>
        <div class="text-muted">Create subjects for a specific class (e.g. Urdu for Prep only).</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <div class="row g-3 align-items-end">
            <div class="col-md-8">
                <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
                    <input type="hidden" name="route" value="academic/subjects">
                    <div class="col-7">
                        <label class="form-label">Search</label>
                        <input class="form-control" name="q" value="<?= h($search) ?>" placeholder="Subject name, code, or class">
                    </div>
                    <div class="col-3">
                        <label class="form-label">Show</label>
                        <select class="form-select" name="per_page" onchange="this.form.submit()">
                            <?php foreach ([10, 20, 50, 100, 200, 999] as $opt): ?>
                                <option value="<?= $opt ?>" <?= ($perPage == $opt) ? 'selected' : '' ?>>
                                    <?= $opt == 999 ? 'All' : $opt ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-2 d-grid">
                        <button class="btn btn-primary" type="submit">Search</button>
                    </div>
                </form>
            </div>
            <div class="col-md-4 d-flex justify-content-md-end">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#subjectFormModal" data-id="">
                    + Create Subject
                </button>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body" id="subjectListContainer">
        <?= $this->renderPartial('academic/_subject_list', [
            'search' => $search,
            'perPage' => $perPage,
            'page' => $page,
            'total' => $total,
            'subjects' => $subjects,
            'allSubjectOptions' => $allSubjectOptions,
        ]) ?>
    </div>
</div>

<!-- Create / Edit Subject Modal -->
<div class="modal fade" id="subjectFormModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form method="post" id="subjectForm" action="<?= htmlspecialchars(base_url('/index.php?route=academic/subjects'), ENT_QUOTES, 'UTF-8') ?>"
            data-ajax data-target="#subjectListContainer" data-close-modal="#subjectFormModal">
        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
        <input type="hidden" name="id" id="subject_id" value="">
        <div class="modal-header">
          <h5 class="modal-title" id="subjectFormModalLabel">Create Subject</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="row g-2">
            <div class="col-12">
                <label class="form-label">Class *</label>
                <select class="form-select" name="class_id" id="subject_class_id" required>
                    <option value="">Choose class…</option>
                    <?php foreach ($classes as $c): ?>
                        <option value="<?= (int)$c['id'] ?>"><?= h($c['name'] ?? '') ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12">
                <label class="form-label">Subject Code</label>
                <input class="form-control" name="subject_code" id="subject_code_input" value="">
            </div>
            <div class="col-12">
                <label class="form-label">Subject Name *</label>
                <input class="form-control" name="subject_name" id="subject_name_input" value="" required>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button class="btn btn-primary" type="submit" id="subjectFormSubmitBtn">Create</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Merge Duplicate Subject Modal -->

<div class="modal fade" id="mergeSubjectModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=academic/subjectMerge'), ENT_QUOTES, 'UTF-8') ?>"
            data-ajax data-target="#subjectListContainer" data-close-modal="#mergeSubjectModal"
            data-confirm="This moves all timetable, marks, and attendance records from the duplicate subject onto the one you keep, then deletes the duplicate. Continue?">
        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
        <input type="hidden" name="from_id" id="merge_from_id" value="">
        <div class="modal-header">
          <h5 class="modal-title">Merge Duplicate Subject</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p class="small text-muted">
            Merging <strong id="merge_from_name"></strong> into another subject moves every timetable entry,
            exam date-sheet row, mark, staff assignment, and attendance record onto the subject you pick below,
            then removes the duplicate. This can't be undone.
          </p>
          <label class="form-label">Keep this subject instead</label>
          <select class="form-select" name="into_id" id="merge_into_id" required>
            <option value="">Choose subject…</option>
            <?php
            $groupedMergeOptions = [];
            foreach ($allSubjectOptions as $opt) {
                $groupedMergeOptions[$opt['class_name'] ?? ''][] = $opt;
            }
            ?>
            <?php foreach ($groupedMergeOptions as $className => $opts): ?>
                <optgroup label="<?= h($className !== '' ? $className : 'No class assigned') ?>">
                    <?php foreach ($opts as $opt): ?>
                        <option value="<?= (int)$opt['id'] ?>" data-subject-id="<?= (int)$opt['id'] ?>">
                            <?= h($opt['subject_name'] ?? '') ?>
                        </option>
                    <?php endforeach; ?>
                </optgroup>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-danger">Merge &amp; Delete Duplicate</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
document.getElementById('subjectFormModal')?.addEventListener('show.bs.modal', function (event) {
    var btn = event.relatedTarget;
    var idVal = btn ? (btn.getAttribute('data-id') || '') : '';
    var isEdit = idVal !== '' && idVal !== '0';

    document.getElementById('subjectForm').reset();
    document.getElementById('subject_id').value = isEdit ? idVal : '';
    document.getElementById('subject_class_id').value = isEdit ? (btn.getAttribute('data-class-id') || '') : '';
    document.getElementById('subject_code_input').value = isEdit ? (btn.getAttribute('data-subject-code') || '') : '';
    document.getElementById('subject_name_input').value = isEdit ? (btn.getAttribute('data-subject-name') || '') : '';
    document.getElementById('subjectFormModalLabel').textContent = isEdit ? 'Edit Subject' : 'Create Subject';
    document.getElementById('subjectFormSubmitBtn').textContent = isEdit ? 'Update' : 'Create';
});

document.getElementById('mergeSubjectModal')?.addEventListener('show.bs.modal', function (event) {
    var btn = event.relatedTarget;
    if (!btn) return;
    var fromId = btn.getAttribute('data-from-id') || '';
    document.getElementById('merge_from_id').value = fromId;
    document.getElementById('merge_from_name').textContent = btn.getAttribute('data-from-name') || '';
    var intoSelect = document.getElementById('merge_into_id');
    Array.from(intoSelect.options).forEach(function (opt) {
        opt.disabled = (opt.value === fromId);
    });
    intoSelect.value = '';
});
</script>