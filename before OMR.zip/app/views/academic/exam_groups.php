<?php
// Variables: $types,$examTypeId,$groups
$groups = $groups ?? [];
$types = $types ?? [];
$groupsUrl = base_url('/index.php?route=academic/examGroups');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Exam Groups</h1>
        <div class="text-muted">Create groups and set custom pass / fail criteria for report cards.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=academic/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="academic/examGroups">
            <div class="col-md-6">
                <label class="form-label">Exam Type</label>
                <select class="form-select" name="exam_type_id" onchange="this.form.submit()">
                    <?php foreach ($types as $t): ?>
                        <option value="<?= (int)$t['id'] ?>" <?= ((int)$examTypeId === (int)$t['id']) ? 'selected' : '' ?>>
                            <?= h($t['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </form>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Create Exam Group</h2>
                <form method="post" action="<?= htmlspecialchars($groupsUrl, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="action" value="createGroup">
                    <input type="hidden" name="exam_type_id" value="<?= (int)$examTypeId ?>">
                    <input type="hidden" name="form_has_criteria" value="1">

                    <div class="mb-3">
                        <label class="form-label">Group Name *</label>
                        <input class="form-control" name="group_name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Sort Order</label>
                        <input class="form-control" name="sort_order" type="number" value="0">
                    </div>

                    <hr class="border-secondary opacity-25">
                    <div class="fw-semibold mb-2">Pass criteria</div>

                    <div class="mb-3">
                        <label class="form-label">Subject pass % *</label>
                        <input class="form-control" name="passing_percentage" type="number" step="0.01" min="0" max="100" value="50" required>
                        <div class="form-text">A subject below this % counts as failed.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Overall pass % (optional)</label>
                        <input class="form-control" name="overall_passing_percentage" type="number" step="0.01" min="0" max="100" placeholder="Same as subject % if blank">
                        <div class="form-text">Used when “Require overall %” is checked.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Fail if failed subjects reach</label>
                        <input class="form-control" name="max_failed_subjects" type="number" min="0" value="2">
                        <div class="form-text">Example: <strong>2</strong> = FAIL when 2 or more subjects are failed (overall % cannot override). <strong>0</strong> = must pass every subject.</div>
                    </div>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" name="require_overall_pass" id="create_req_overall" value="1" checked>
                        <label class="form-check-label" for="create_req_overall">Require overall % to pass</label>
                    </div>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" name="no_marks_is_fail" id="create_no_marks" value="1" checked>
                        <label class="form-check-label" for="create_no_marks">No marks recorded = FAIL</label>
                    </div>
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" name="force_grade_f_on_fail" id="create_force_f" value="1" checked>
                        <label class="form-check-label" for="create_force_f">Set final grade F when result is FAIL</label>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notes / description</label>
                        <input class="form-control" name="passing_description" placeholder="Shown for staff reference">
                    </div>
                    <button class="btn btn-primary w-100" type="submit">Create Group</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-3">Groups &amp; pass criteria</h2>
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0 align-middle">
                        <thead>
                        <tr>
                            <th>Group</th>
                            <th>Subject %</th>
                            <th>Overall %</th>
                            <th>Fail at</th>
                            <th style="width:140px;">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($groups)): ?>
                            <tr><td colspan="5" class="text-muted">No groups found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($groups as $g): ?>
                                <?php
                                $subjPct = $g['passing_percentage'] ?? 50;
                                $ovPct = $g['overall_passing_percentage'];
                                $ovDisp = ($ovPct !== null && $ovPct !== '') ? $ovPct : $subjPct;
                                $maxFail = $g['max_failed_subjects'] ?? 1;
                                ?>
                                <tr>
                                    <td>
                                        <div class="fw-semibold"><?= h($g['name'] ?? '') ?></div>
                                        <div class="text-muted small"><?= h($g['exam_type_name'] ?? '') ?></div>
                                    </td>
                                    <td><?= h((string)$subjPct) ?>%</td>
                                    <td><?= h((string)$ovDisp) ?>%</td>
                                    <td><?= (int)$maxFail ?></td>
                                    <td class="text-nowrap">
                                        <button type="button" class="btn btn-sm btn-outline-primary"
                                                data-bs-toggle="modal" data-bs-target="#editGroupModal"
                                                data-id="<?= (int)$g['id'] ?>"
                                                data-name="<?= h($g['name'] ?? '') ?>"
                                                data-sort="<?= (int)($g['sort_order'] ?? 0) ?>"
                                                data-pass="<?= h((string)$subjPct) ?>"
                                                data-overall="<?= h(($ovPct !== null && $ovPct !== '') ? (string)$ovPct : '') ?>"
                                                data-max-fail="<?= (int)$maxFail ?>"
                                                data-req-overall="<?= !empty($g['require_overall_pass']) || !isset($g['require_overall_pass']) ? '1' : '0' ?>"
                                                data-no-marks="<?= !empty($g['no_marks_is_fail']) || !isset($g['no_marks_is_fail']) ? '1' : '0' ?>"
                                                data-force-f="<?= !empty($g['force_grade_f_on_fail']) || !isset($g['force_grade_f_on_fail']) ? '1' : '0' ?>"
                                                data-desc="<?= h($g['passing_description'] ?? '') ?>">
                                            Edit
                                        </button>
                                        <form method="post" action="<?= htmlspecialchars($groupsUrl, ENT_QUOTES, 'UTF-8') ?>"
                                              class="d-inline" onsubmit="return confirm('Delete this exam group and its pass rule?');">
                                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                            <input type="hidden" name="action" value="deleteGroup">
                                            <input type="hidden" name="exam_type_id" value="<?= (int)$examTypeId ?>">
                                            <input type="hidden" name="group_id" value="<?= (int)$g['id'] ?>">
                                            <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="text-muted small mt-3">
                    <strong>Fail at N</strong> means: if the student fails N or more subjects, result is FAIL — overall percentage cannot make it PASS.
                    Subject pass % decides which subjects count as failed.
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editGroupModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <form method="post" action="<?= htmlspecialchars($groupsUrl, ENT_QUOTES, 'UTF-8') ?>">
        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
        <input type="hidden" name="action" value="updateGroup">
        <input type="hidden" name="exam_type_id" value="<?= (int)$examTypeId ?>">
        <input type="hidden" name="group_id" id="edit_group_id" value="">
        <input type="hidden" name="form_has_criteria" value="1">
        <div class="modal-header">
          <h5 class="modal-title">Edit group &amp; pass criteria</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="row g-3">
            <div class="col-md-8">
              <label class="form-label">Group Name *</label>
              <input class="form-control" name="group_name" id="edit_group_name" required>
            </div>
            <div class="col-md-4">
              <label class="form-label">Sort Order</label>
              <input class="form-control" name="sort_order" id="edit_group_sort" type="number">
            </div>
            <div class="col-md-6">
              <label class="form-label">Subject pass %</label>
              <input class="form-control" name="passing_percentage" id="edit_group_pass" type="number" step="0.01" min="0" max="100">
            </div>
            <div class="col-md-6">
              <label class="form-label">Overall pass % (optional)</label>
              <input class="form-control" name="overall_passing_percentage" id="edit_group_overall" type="number" step="0.01" min="0" max="100" placeholder="Same as subject %">
            </div>
            <div class="col-md-6">
              <label class="form-label">Fail if failed subjects reach</label>
              <input class="form-control" name="max_failed_subjects" id="edit_group_max_fail" type="number" min="0">
              <div class="form-text">2 = FAIL at 2+ failed subjects. 0 = must pass all.</div>
            </div>
            <div class="col-md-12">
              <div class="form-check mb-2">
                <input class="form-check-input" type="checkbox" name="require_overall_pass" id="edit_req_overall" value="1">
                <label class="form-check-label" for="edit_req_overall">Require overall % to pass</label>
              </div>
              <div class="form-check mb-2">
                <input class="form-check-input" type="checkbox" name="no_marks_is_fail" id="edit_no_marks" value="1">
                <label class="form-check-label" for="edit_no_marks">No marks recorded = FAIL</label>
              </div>
              <div class="form-check mb-2">
                <input class="form-check-input" type="checkbox" name="force_grade_f_on_fail" id="edit_force_f" value="1">
                <label class="form-check-label" for="edit_force_f">Set final grade F when result is FAIL</label>
              </div>
            </div>
            <div class="col-12">
              <label class="form-label">Notes / description</label>
              <input class="form-control" name="passing_description" id="edit_group_desc">
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
document.getElementById('editGroupModal')?.addEventListener('show.bs.modal', function (event) {
    var btn = event.relatedTarget;
    if (!btn) return;
    document.getElementById('edit_group_id').value = btn.getAttribute('data-id') || '';
    document.getElementById('edit_group_name').value = btn.getAttribute('data-name') || '';
    document.getElementById('edit_group_sort').value = btn.getAttribute('data-sort') || '0';
    document.getElementById('edit_group_pass').value = btn.getAttribute('data-pass') || '50';
    document.getElementById('edit_group_overall').value = btn.getAttribute('data-overall') || '';
    document.getElementById('edit_group_max_fail').value = btn.getAttribute('data-max-fail') || '2';
    document.getElementById('edit_req_overall').checked = btn.getAttribute('data-req-overall') === '1';
    document.getElementById('edit_no_marks').checked = btn.getAttribute('data-no-marks') === '1';
    document.getElementById('edit_force_f').checked = btn.getAttribute('data-force-f') === '1';
    document.getElementById('edit_group_desc').value = btn.getAttribute('data-desc') || '';
});
</script>
