<?php
// Variables: $invoices, $total, $page, $perPage, $studentId, $isParentView
$invoices = $invoices ?? [];
$total = (int)($total ?? 0);
$page = max(1, (int)($page ?? 1));
$perPage = (int)($perPage ?? 15);
$totalPages = max(1, (int)ceil($total / max(1, $perPage)));
$studentId = (int)($studentId ?? 0);
$isParentView = !empty($isParentView);
$backRoute = $isParentView ? 'portal/index' : 'portal/index';
$pageUrlBase = base_url('/index.php?route=portal/myFees') . ($isParentView ? '&student_id=' . $studentId : '');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">My Fee Invoices</h1>
        <div class="text-muted">All invoices, most recent first.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=portal/index') . ($isParentView ? '&student_id=' . $studentId : ''), ENT_QUOTES, 'UTF-8') ?>">Back to Portal</a>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <?php if (empty($invoices)): ?>
            <div class="portal-empty"><i class="bi bi-receipt"></i>No invoices yet.</div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-sm table-hover mb-0">
                <thead><tr><th>Invoice</th><th>Total</th><th>Paid</th><th>Pending</th><th>Status</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($invoices as $inv):
                    $paid = (float)($inv['collected_amount'] ?? 0);
                    $due = (float)($inv['total_due'] ?? 0);
                    $pending = max($due - $paid, 0);
                ?>
                    <tr>
                        <td class="fw-semibold"><?= h($inv['invoice_no'] ?? '') ?></td>
                        <td>Rs <?= number_format($due, 2) ?></td>
                        <td>Rs <?= number_format($paid, 2) ?></td>
                        <td class="<?= $pending > 0 ? 'text-danger fw-semibold' : 'text-success' ?>">Rs <?= number_format($pending, 2) ?></td>
                        <td><span class="badge text-bg-<?= ($inv['status'] ?? '') === 'paid' ? 'success' : (($inv['status'] ?? '') === 'cancelled' ? 'secondary' : 'warning') ?>"><?= h(ucfirst($inv['status'] ?? '')) ?></span></td>
                        <td>
                            <a class="btn btn-sm btn-outline-primary" title="View invoice details"
                               href="<?= htmlspecialchars(base_url('/index.php?route=portal/invoiceView&invoice_id=' . (int)$inv['id']), ENT_QUOTES, 'UTF-8') ?>">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php if ($totalPages > 1): ?>
<nav class="mt-3">
    <ul class="pagination justify-content-center">
        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                <a class="page-link" href="<?= htmlspecialchars($pageUrlBase . '&page=' . $p, ENT_QUOTES, 'UTF-8') ?>"><?= (int)$p ?></a>
            </li>
        <?php endfor; ?>
    </ul>
</nav>
<?php endif; ?>
