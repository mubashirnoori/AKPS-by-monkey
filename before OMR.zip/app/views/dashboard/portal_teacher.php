<?php
// Variables: $profile, $subjects, $classes, $attendance, $leaveRequests, $performance
$profile = $profile ?? [];
$subjects = $subjects ?? [];
$classes = $classes ?? [];
$attendance = $attendance ?? [];
$leaveRequests = $leaveRequests ?? [];
$performance = $performance ?? [];
$recentActivities = $recentActivities ?? [];
$salaryRecent = $salaryRecent ?? [];
$salaryTotalCount = (int)($salaryTotalCount ?? 0);
$feeClasses = $feeClasses ?? [];

$presentCount = 0;
foreach ($attendance as $a) {
    if (($a['status'] ?? '') === 'present') { $presentCount++; }
}
$attTotal = count($attendance);

$totalStudents = 0;
foreach ($classes as $c) { $totalStudents += (int)($c['student_count'] ?? 0); }

$latestSalary = $salaryRecent[0] ?? null;
$latestSalaryStatus = '—';
if ($latestSalary) {
    $net = (float)($latestSalary['net_amount'] ?? 0);
    $paid = (float)($latestSalary['total_paid'] ?? 0);
    $latestSalaryStatus = 'Unpaid';
    if ($paid >= $net && $net > 0) { $latestSalaryStatus = 'Paid'; }
    elseif ($paid > 0) { $latestSalaryStatus = 'Partial'; }
}

$pendingLeaveCount = 0;
foreach ($leaveRequests as $lr) {
    if (($lr['status'] ?? '') === 'pending') { $pendingLeaveCount++; }
}

// --- Chart data -----------------------------------------------------

// Attendance breakdown (donut): counts per status over the fetched window.
$attStatusCounts = ['present' => 0, 'absent' => 0, 'late' => 0, 'excused' => 0];
foreach ($attendance as $a) {
    $st = $a['status'] ?? '';
    if (isset($attStatusCounts[$st])) { $attStatusCounts[$st]++; }
}
$attStatusMeta = [
    'present' => ['label' => 'Present', 'color' => 'var(--sms-accent-green)'],
    'absent'  => ['label' => 'Absent',  'color' => 'var(--sms-accent-rose)'],
    'late'    => ['label' => 'Late',    'color' => 'var(--sms-accent-amber)'],
    'excused' => ['label' => 'Excused', 'color' => 'var(--sms-accent-teal)'],
];
$attDonutSegments = [];
if ($attTotal > 0) {
    $offset = 25;
    foreach ($attStatusCounts as $st => $cnt) {
        if ($cnt <= 0) { continue; }
        $pct = round(($cnt / $attTotal) * 100, 2);
        $attDonutSegments[] = [
            'pct' => $pct,
            'count' => $cnt,
            'offset' => $offset,
            'label' => $attStatusMeta[$st]['label'],
            'color' => $attStatusMeta[$st]['color'],
        ];
        $offset -= $pct;
    }
}

// Students per class (compact bar list) — reuse $classes, already loaded.
$classBarMax = 0;
foreach ($classes as $c) {
    $classBarMax = max($classBarMax, (int)($c['student_count'] ?? 0));
}
$classAccents = ['amber', 'violet', 'teal', 'green', 'rose', 'pink'];

// Salary — last up to 3 months, net vs. actually paid.
$salaryChart = array_slice(array_reverse($salaryRecent), -3);
$salaryMax = 0.01;
foreach ($salaryChart as $sr) {
    $salaryMax = max($salaryMax, (float)($sr['net_amount'] ?? 0));
}
$monthNames = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

// Latest performance rating (out of 5), if any report exists.
$latestPerformance = $performance[0] ?? null;

$fullName = $profile['full_name'] ?? '';
$initials = '';
foreach (preg_split('/\s+/', trim($fullName)) as $part) {
    if ($part !== '') { $initials .= strtoupper($part[0]); }
    if (strlen($initials) >= 2) { break; }
}

$photoUrl = staff_photo_url((int)($profile['id'] ?? 0));
?>

<div class="portal-hero">
    <div class="portal-hero__avatar">
        <?php if ($photoUrl): ?>
            <img src="<?= h($photoUrl) ?>" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">
        <?php else: ?>
            <?= h($initials ?: 'TC') ?>
        <?php endif; ?>
    </div>
    <div class="portal-hero__body">
        <p class="portal-hero__name"><?= $fullName !== '' ? h($fullName) : 'My Teaching Portal' ?></p>
        <div class="portal-hero__meta">
            <?= h($profile['title'] ?? '') ?>
            <?php if (!empty($profile['staff_code'])): ?> &middot; Staff #<?= h($profile['staff_code']) ?><?php endif; ?>
            <?php if (($profile['title'] ?? '') === '' && empty($profile['staff_code'])): ?>
                Showing only your assigned subjects, classes, and your own HR records.
            <?php endif; ?>
        </div>
    </div>
    <div class="portal-hero__right">
        <span class="badge text-bg-warning align-self-center"><i class="bi bi-easel2-fill me-1"></i>Teacher Portal</span>
    </div>
</div>

<div class="portal-kpis">
    <div class="portal-kpi portal-kpi--a">
        <div class="portal-kpi__label"><i class="bi bi-journal-bookmark"></i> My Subjects</div>
        <div class="portal-kpi__value"><?= count($subjects) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--c">
        <div class="portal-kpi__label"><i class="bi bi-people"></i> My Classes</div>
        <div class="portal-kpi__value"><?= count($classes) ?></div>
        <div class="portal-kpi__hint"><?= $totalStudents ?> students total</div>
    </div>
    <div class="portal-kpi portal-kpi--f">
        <div class="portal-kpi__label"><i class="bi bi-calendar-check"></i> My Attendance (30 days)</div>
        <div class="portal-kpi__value"><?= $attTotal > 0 ? round(($presentCount / $attTotal) * 100, 1) . '%' : '—' ?></div>
    </div>
    <div class="portal-kpi portal-kpi--b">
        <div class="portal-kpi__label"><i class="bi bi-cash-coin"></i> Latest Salary</div>
        <div class="portal-kpi__value"><?= h($latestSalaryStatus) ?></div>
        <div class="portal-kpi__hint"><?= $salaryTotalCount ?> month<?= $salaryTotalCount === 1 ? '' : 's' ?> on record</div>
    </div>
    <div class="portal-kpi portal-kpi--e">
        <div class="portal-kpi__label"><i class="bi bi-calendar-x"></i> Leave Requests</div>
        <div class="portal-kpi__value"><?= count($leaveRequests) ?></div>
        <div class="portal-kpi__hint"><?= $pendingLeaveCount ?> pending</div>
    </div>
    <div class="portal-kpi portal-kpi--d">
        <div class="portal-kpi__label"><i class="bi bi-pencil-square"></i> Enter Marks</div>
        <div class="portal-kpi__value" style="font-size:1rem;">
            <a class="btn btn-sm btn-primary mt-1" href="<?= htmlspecialchars(base_url('/index.php?route=academic/marksEntry'), ENT_QUOTES, 'UTF-8') ?>">Go <i class="bi bi-arrow-right"></i></a>
        </div>
    </div>
    <div class="portal-kpi portal-kpi--g">
        <div class="portal-kpi__label"><i class="bi bi-star"></i> Latest Performance</div>
        <?php if ($latestPerformance): ?>
            <?php $kpiRating = (int)($latestPerformance['rating'] ?? 0); ?>
            <div class="star-row" style="font-size:1.05rem;margin-top:.5rem;">
                <?php for ($si = 1; $si <= 5; $si++): ?>
                    <i class="bi <?= $si <= $kpiRating ? 'bi-star-fill filled' : 'bi-star' ?>"></i>
                <?php endfor; ?>
            </div>
            <?php if (!empty($latestPerformance['period_start']) && !empty($latestPerformance['period_end'])): ?>
                <div class="portal-kpi__hint"><?= h(date('M Y', strtotime($latestPerformance['period_start']))) ?> &ndash; <?= h(date('M Y', strtotime($latestPerformance['period_end']))) ?></div>
            <?php endif; ?>
        <?php else: ?>
            <div class="portal-kpi__value">—</div>
            <div class="portal-kpi__hint">No ratings yet</div>
        <?php endif; ?>
    </div>
</div>

<style>
.insight-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:1rem;margin-bottom:1.25rem;}
.insight-card{background:#12181f;border:1px solid rgba(255,255,255,.07);border-radius:14px;padding:1.1rem 1.15rem;}
.insight-card__title{display:flex;align-items:center;gap:.5rem;font-weight:700;color:#f8fafc;font-size:.88rem;margin-bottom:.9rem;}
.insight-card__title i{color:var(--sms-primary);}
.insight-empty{color:#64748b;font-size:.8rem;padding:1rem 0;text-align:center;}

.donut-wrap{display:flex;align-items:center;gap:1.1rem;}
.donut-svg{width:104px;height:104px;flex-shrink:0;}
.donut-legend{display:flex;flex-direction:column;gap:.4rem;min-width:0;}
.donut-legend__row{display:flex;align-items:center;gap:.45rem;font-size:.78rem;color:#cbd5e1;}
.donut-legend__dot{width:9px;height:9px;border-radius:50%;flex-shrink:0;}
.donut-legend__count{margin-left:auto;font-weight:700;color:#f1f5f9;padding-left:.5rem;}
.donut-center{font-size:3.4px;fill:#94a3b8;font-family:inherit;}
.donut-center-val{font-size:7.5px;font-weight:800;fill:#f8fafc;font-family:inherit;}

.bar-list{display:flex;flex-direction:column;gap:.55rem;max-height:186px;overflow-y:auto;padding-right:.3rem;}
.bar-list::-webkit-scrollbar{width:5px;}
.bar-list::-webkit-scrollbar-thumb{background:rgba(255,255,255,.12);border-radius:999px;}
.bar-list__row{display:flex;align-items:center;gap:.6rem;}
.bar-list__label{font-size:.76rem;color:#cbd5e1;min-width:76px;flex-shrink:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.bar-list__track{flex:1;height:8px;border-radius:999px;background:rgba(255,255,255,.06);overflow:hidden;}
.bar-list__fill{height:100%;border-radius:999px;}
.bar-list__value{font-size:.76rem;font-weight:700;color:#f1f5f9;min-width:22px;text-align:right;}

.salary-bars{display:flex;align-items:flex-end;gap:.9rem;height:120px;padding-top:.5rem;}
.salary-bar-col{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:100%;gap:.35rem;}
.salary-bar-stack{width:60%;max-width:34px;height:100%;display:flex;flex-direction:column-reverse;position:relative;background:rgba(255,255,255,.05);border-radius:6px 6px 0 0;overflow:hidden;}
.salary-bar-fill{width:100%;background:linear-gradient(180deg,var(--sms-accent-teal),var(--sms-primary));border-radius:6px 6px 0 0;}
.salary-bar-label{font-size:.68rem;color:#94a3b8;font-weight:600;}
.salary-bar-amt{font-size:.68rem;color:#f1f5f9;font-weight:700;}

.star-row{display:flex;gap:.15rem;font-size:1.2rem;color:#3a4557;}
.star-row i.filled{color:var(--sms-primary);}
.perf-period{font-size:.76rem;color:#94a3b8;margin-top:.4rem;}

.activity-feed{display:flex;flex-direction:column;gap:.7rem;max-height:230px;overflow-y:auto;}
.activity-feed__row{display:flex;align-items:flex-start;gap:.6rem;}
.activity-feed__dot{width:7px;height:7px;border-radius:50%;background:var(--sms-primary);margin-top:.4rem;flex-shrink:0;}
.activity-feed__body{min-width:0;}
.activity-feed__desc{font-size:.8rem;color:#e2e8f0;margin:0;line-height:1.35;}
.activity-feed__time{font-size:.68rem;color:#64748b;}
</style>

<div class="insight-grid">

    <div class="insight-card">
        <div class="insight-card__title"><i class="bi bi-calendar-check"></i> Attendance Breakdown (30 days)</div>
        <?php if (empty($attDonutSegments)): ?>
            <div class="insight-empty">No attendance records yet.</div>
        <?php else: ?>
        <div class="donut-wrap">
            <svg viewBox="0 0 42 42" class="donut-svg">
                <circle cx="21" cy="21" r="15.91549430919" fill="transparent" stroke="rgba(255,255,255,.07)" stroke-width="4"></circle>
                <?php foreach ($attDonutSegments as $seg): ?>
                    <circle cx="21" cy="21" r="15.91549430919" fill="transparent"
                        stroke="<?= $seg['color'] ?>" stroke-width="4"
                        stroke-dasharray="<?= $seg['pct'] ?> <?= 100 - $seg['pct'] ?>"
                        stroke-dashoffset="<?= $seg['offset'] ?>"></circle>
                <?php endforeach; ?>
                <text x="21" y="19.5" text-anchor="middle" class="donut-center-val"><?= $attTotal > 0 ? round(($presentCount / $attTotal) * 100) . '%' : '' ?></text>
                <text x="21" y="25.5" text-anchor="middle" class="donut-center">present</text>
            </svg>
            <div class="donut-legend">
                <?php foreach ($attDonutSegments as $seg): ?>
                    <div class="donut-legend__row">
                        <span class="donut-legend__dot" style="background: <?= $seg['color'] ?>;"></span>
                        <?= h($seg['label']) ?>
                        <span class="donut-legend__count"><?= $seg['count'] ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="insight-card">
        <div class="insight-card__title"><i class="bi bi-people"></i> Students per Class</div>
        <?php if (empty($classes)): ?>
            <div class="insight-empty">No classes assigned yet.</div>
        <?php else: ?>
        <div class="bar-list">
            <?php $ci = 0; foreach ($classes as $c): ?>
                <?php
                $cnt = (int)($c['student_count'] ?? 0);
                $pct = $classBarMax > 0 ? max(4, round(($cnt / $classBarMax) * 100)) : 0;
                $accent = $classAccents[$ci % count($classAccents)]; $ci++;
                $label = trim(($c['class_name'] ?? '') . ' ' . ($c['section_name'] ?? ''));
                ?>
                <div class="bar-list__row">
                    <span class="bar-list__label" title="<?= h($label) ?>"><?= h($label) ?></span>
                    <div class="bar-list__track">
                        <div class="bar-list__fill" style="width: <?= $pct ?>%; background: var(--sms-accent-<?= h($accent) ?>);"></div>
                    </div>
                    <span class="bar-list__value"><?= $cnt ?></span>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <?php if (!empty($salaryChart)): ?>
    <div class="insight-card">
        <div class="insight-card__title"><i class="bi bi-cash-coin"></i> Salary — Last <?= count($salaryChart) ?> Month<?= count($salaryChart) === 1 ? '' : 's' ?></div>
        <div class="salary-bars">
            <?php foreach ($salaryChart as $sr): ?>
                <?php
                $net = (float)($sr['net_amount'] ?? 0);
                $paid = min((float)($sr['total_paid'] ?? 0), $net);
                $netPct = max(4, round(($net / $salaryMax) * 100));
                $paidPct = $net > 0 ? round(($paid / $net) * $netPct) : 0;
                $mLabel = ($monthNames[(int)($sr['salary_month'] ?? 0)] ?? '') . ' ' . substr((string)($sr['salary_year'] ?? ''), -2);
                ?>
                <div class="salary-bar-col">
                    <span class="salary-bar-amt"><?= number_format($net, 0) ?></span>
                    <div class="salary-bar-stack" style="height: <?= $netPct ?>%;">
                        <div class="salary-bar-fill" style="height: <?= $net > 0 ? round(($paid / $net) * 100) : 0 ?>%;"></div>
                    </div>
                    <span class="salary-bar-label"><?= h(trim($mLabel)) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if (!empty($recentActivities)): ?>
    <div class="insight-card">
        <div class="insight-card__title"><i class="bi bi-clock-history"></i> My Recent Activities</div>
        <div class="activity-feed">
            <?php foreach ($recentActivities as $act): ?>
                <div class="activity-feed__row">
                    <span class="activity-feed__dot"></span>
                    <div class="activity-feed__body">
                        <p class="activity-feed__desc"><?= h((string)($act['description'] ?? $act['action'] ?? 'Activity')) ?></p>
                        <span class="activity-feed__time"><?= h(!empty($act['created_at']) ? date('d M, h:i A', strtotime((string)$act['created_at'])) : '') ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php else: ?>
    <div class="insight-card">
        <div class="insight-card__title"><i class="bi bi-clock-history"></i> My Recent Activities</div>
        <div class="insight-empty">Nothing recorded yet — actions you take (attendance, marks, leave requests) will show up here.</div>
    </div>
    <?php endif; ?>

</div>

<h2 class="h6 text-muted text-uppercase mb-2" style="letter-spacing:.04em;">Quick Access</h2>
<div class="portal-quicklinks">
    <a class="portal-quicklink" href="<?= h(route_url('portal/mySubjects')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--violet"><i class="bi bi-journal-bookmark"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Subjects &amp; Classes</p>
            <p class="portal-quicklink__hint">Headcounts &amp; attendance</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <?php if (!empty($feeClasses)): ?>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myFeeClasses')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--green"><i class="bi bi-cash-coin"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">Fee Collection Classes</p>
            <p class="portal-quicklink__hint"><?= count($feeClasses) ?> class<?= count($feeClasses) === 1 ? '' : 'es' ?></p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myFeeLedger')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--orange"><i class="bi bi-arrow-left-right"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Fee Ledger</p>
            <p class="portal-quicklink__hint">Collected, handed over &amp; balance</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <?php endif; ?>
    <a class="portal-quicklink" href="<?= h(route_url('portal/mySalary')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--blue"><i class="bi bi-cash-stack"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Salary</p>
            <p class="portal-quicklink__hint">Full payment history</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myPerformance')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--rose"><i class="bi bi-star"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Performance</p>
            <p class="portal-quicklink__hint"><?= count($performance) ?> report<?= count($performance) === 1 ? '' : 's' ?></p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myLeaves')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--amber"><i class="bi bi-calendar-x"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Leaves</p>
            <p class="portal-quicklink__hint">Apply &amp; view history</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
</div>
