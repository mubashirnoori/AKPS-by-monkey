<?php
// Admin dashboard. Existing finance data remains fully dynamic; the controller also
// provides lightweight school/attendance/announcement summaries for this view.
$fmt = static function ($n): string {
    return number_format((float)$n, 0);
};

$fees       = (float)($stats['fees_collected'] ?? 0);
$exp        = (float)($stats['expenses'] ?? 0);
$otherExp   = (float)($stats['other_expenses'] ?? 0);
$net        = (float)($stats['net_balance'] ?? ($fees - $exp - $otherExp));
$pending    = (float)($stats['pending_dues'] ?? 0);
$total      = $fees + $pending;
$students   = (int)($stats['students_enrolled'] ?? 0);
$staff      = (int)($stats['staff_count'] ?? 0);
$period     = (string)($stats['period_label'] ?? ('Year ' . date('Y')));

$dashboard  = $dashboard ?? [];
$classes    = (int)($dashboard['classes'] ?? 0);
$newAdmissions = (int)($dashboard['new_admissions'] ?? 0);
$attendance = $dashboard['attendance'] ?? ['present' => 0, 'absent' => 0, 'late' => 0, 'excused' => 0, 'total' => 0, 'rate' => 0];
$attendancePresent = (int)($attendance['present'] ?? 0);
$attendanceAbsent  = (int)($attendance['absent'] ?? 0);
$attendanceLate    = (int)($attendance['late'] ?? 0);
$attendanceExcused = (int)($attendance['excused'] ?? 0);
$attendanceTotal   = (int)($attendance['total'] ?? 0);
$attendanceRate    = (float)($attendance['rate'] ?? 0);
$announcements     = is_array($dashboard['announcements'] ?? null) ? $dashboard['announcements'] : [];
$activities        = is_array($dashboard['activities'] ?? null) ? $dashboard['activities'] : [];

$hour = (int)date('G');
$greeting = $hour < 12 ? 'Good morning' : ($hour < 18 ? 'Good afternoon' : 'Good evening');
$todayLabel = date('D, d M Y');

// Headline = how much of today's attendance has been taken (100% once every student is marked).
// The breakdown (present / absent / late / excused) is split across the students who were marked,
// so a fully marked day with 2 absent shows 100% taken: 99% present, 1% absent.
$attendanceMarked = (int)($attendance['marked_total'] ?? ($attendancePresent + $attendanceAbsent + $attendanceLate + $attendanceExcused));
$markedPct  = $attendanceTotal > 0 ? min(100, round(($attendanceMarked / $attendanceTotal) * 100, 1)) : 0;
$presentPct = $attendanceMarked > 0 ? round(($attendancePresent / $attendanceMarked) * 100, 1) : 0;
$absentPct  = $attendanceMarked > 0 ? round(($attendanceAbsent / $attendanceMarked) * 100, 1) : 0;
$latePct    = $attendanceMarked > 0 ? round(($attendanceLate / $attendanceMarked) * 100, 1) : 0;
$excusedPct = $attendanceMarked > 0 ? round(($attendanceExcused / $attendanceMarked) * 100, 1) : 0;
?>

<link rel="stylesheet" href="<?= h(base_url('/assets/css/dashboard-admin.css?v=5')) ?>">

<div class="adm-dash">
    <div class="adm-hero">
        <div>
            <div class="adm-eyebrow"><span class="adm-live-dot"></span> School overview</div>
            <h1><?= h($greeting) ?>, Admin! <span class="adm-wave">👋</span></h1>
            <p>Here's what's happening at your school today.</p>
        </div>
        <div class="adm-date-picker">
            <i class="bi bi-calendar3"></i>
            <span><?= h($todayLabel) ?></span>
            <span class="adm-date-separator"></span>
            <span><?= h($period) ?></span>
        </div>
    </div>

    <section class="adm-kpis" aria-label="School key metrics">
        <a class="adm-stat adm-stat--purple" href="<?= h(route_url('students/index')) ?>">
            <div class="adm-stat__icon"><i class="bi bi-mortarboard-fill"></i></div>
            <div class="adm-stat__body">
                <span>Students</span>
                <strong><?= h((string)$students) ?></strong>
                <small><i class="bi bi-arrow-up"></i> Active students</small>
            </div>
            <div class="adm-mini-chart adm-mini-chart--purple"><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
        </a>

        <a class="adm-stat adm-stat--green" href="<?= h(route_url('staff/index')) ?>">
            <div class="adm-stat__icon"><i class="bi bi-people-fill"></i></div>
            <div class="adm-stat__body">
                <span>Staff</span>
                <strong><?= h((string)$staff) ?></strong>
                <small>Active staff</small>
            </div>
            <div class="adm-mini-chart adm-mini-chart--green"><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
        </a>

        <a class="adm-stat adm-stat--amber" href="<?= h(route_url('academic/classSections')) ?>">
            <div class="adm-stat__icon"><i class="bi bi-book-half"></i></div>
            <div class="adm-stat__body">
                <span>Classes</span>
                <strong><?= h((string)$classes) ?></strong>
                <small>Total sections</small>
            </div>
            <div class="adm-mini-chart adm-mini-chart--amber"><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
        </a>

        <a class="adm-stat adm-stat--blue" href="<?= h(route_url('students/index')) ?>">
            <div class="adm-stat__icon"><i class="bi bi-calendar-check-fill"></i></div>
            <div class="adm-stat__body">
                <span>Attendance</span>
                <strong><?= h(number_format($markedPct, 1)) ?>%</strong>
                <small>Attendance taken today</small>
            </div>
            <div class="adm-mini-chart adm-mini-chart--blue"><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
        </a>

        <a class="adm-stat adm-stat--rose" href="<?= h(route_url('students/index')) ?>">
            <div class="adm-stat__icon"><i class="bi bi-person-plus-fill"></i></div>
            <div class="adm-stat__body">
                <span>New Admissions</span>
                <strong><?= h((string)$newAdmissions) ?></strong>
                <small>Created today</small>
            </div>
            <div class="adm-mini-chart adm-mini-chart--rose"><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
        </a>
    </section>

    <section class="adm-main-grid">
      <div class="adm-col adm-col-1">
        <div class="adm-card adm-overview-card">
            <div class="adm-card-head">
                <div>
                    <h2>School Overview</h2>
                    <p>Quick snapshot of your school operations</p>
                </div>
                <a class="adm-link" href="<?= h(route_url('reports/index')) ?>">View reports <i class="bi bi-arrow-right"></i></a>
            </div>

            <div class="adm-progress-list">
                <div class="adm-progress-row">
                    <div class="adm-progress-label"><span class="adm-progress-icon adm-progress-icon--purple"><i class="bi bi-mortarboard-fill"></i></span><span>Students</span><strong><?= h((string)$students) ?></strong></div>
                    <div class="adm-progress-track"><span style="width:100%"></span></div>
                </div>
                <div class="adm-progress-row">
                    <div class="adm-progress-label"><span class="adm-progress-icon adm-progress-icon--green"><i class="bi bi-people-fill"></i></span><span>Staff</span><strong><?= h((string)$staff) ?></strong></div>
                    <div class="adm-progress-track adm-progress-track--green"><span style="width:58%"></span></div>
                </div>
                <div class="adm-progress-row">
                    <div class="adm-progress-label"><span class="adm-progress-icon adm-progress-icon--amber"><i class="bi bi-book-half"></i></span><span>Class Sections</span><strong><?= h((string)$classes) ?></strong></div>
                    <div class="adm-progress-track adm-progress-track--amber"><span style="width:64%"></span></div>
                </div>
                <div class="adm-progress-row">
                    <div class="adm-progress-label"><span class="adm-progress-icon adm-progress-icon--blue"><i class="bi bi-calendar-check-fill"></i></span><span>Attendance Today</span><strong><?= h(number_format($markedPct, 1)) ?>%</strong></div>
                    <div class="adm-progress-track adm-progress-track--blue"><span style="width:<?= h((string)min(100, max(0, $markedPct))) ?>%"></span></div>
                </div>
            </div>
        </div>
      </div>

      <div class="adm-col adm-col-2">
        <div class="adm-card adm-actions-card">
            <div class="adm-card-head">
                <div><h2>Quick Actions</h2><p>Frequently used tools</p></div>
            </div>
            <div class="adm-actions-grid">
                <a href="<?= h(route_url('students/index')) ?>"><span class="adm-action-icon adm-action-icon--purple"><i class="bi bi-person-plus-fill"></i></span><b>Add Student</b></a>
                <a href="<?= h(route_url('staff/index')) ?>"><span class="adm-action-icon adm-action-icon--green"><i class="bi bi-person-badge-fill"></i></span><b>Manage Staff</b></a>
                <a href="<?= h(route_url('fees/collect')) ?>"><span class="adm-action-icon adm-action-icon--amber"><i class="bi bi-wallet2"></i></span><b>Collect Fee</b></a>
                <a href="<?= h(route_url('academic/exams')) ?>"><span class="adm-action-icon adm-action-icon--blue"><i class="bi bi-file-earmark-text-fill"></i></span><b>Create Exam</b></a>
                <a href="<?= h(route_url('notifications/announcements')) ?>"><span class="adm-action-icon adm-action-icon--rose"><i class="bi bi-megaphone-fill"></i></span><b>Announcement</b></a>
                <a href="<?= h(route_url('reports/index')) ?>"><span class="adm-action-icon adm-action-icon--violet"><i class="bi bi-bar-chart-fill"></i></span><b>Generate Report</b></a>
            </div>
        </div>
      </div>

      <div class="adm-col adm-col-3">
        <div class="adm-card adm-attendance-card">
            <div class="adm-card-head"><div><h2>Attendance Summary</h2><p><?= h($todayLabel) ?></p></div><a class="adm-link" href="<?= h(route_url('students/index')) ?>">View report</a></div>
            <div class="adm-attendance-content">
                <div class="adm-donut" style="--present:<?= h((string)$presentPct) ?>;--absent:<?= h((string)$absentPct) ?>;--late:<?= h((string)$latePct) ?>;--excused:<?= h((string)$excusedPct) ?>;">
                    <div><strong><?= h(number_format($markedPct, 1)) ?>%</strong><span>Marked</span></div>
                </div>
                <div class="adm-attendance-legend">
                    <div><span><i class="adm-dot adm-dot--green"></i>Present</span><b><?= h((string)$attendancePresent) ?></b><small><?= h(number_format($presentPct, 1)) ?>%</small></div>
                    <div><span><i class="adm-dot adm-dot--rose"></i>Absent</span><b><?= h((string)$attendanceAbsent) ?></b><small><?= h(number_format($absentPct, 1)) ?>%</small></div>
                    <div><span><i class="adm-dot adm-dot--amber"></i>Late</span><b><?= h((string)$attendanceLate) ?></b><small><?= h(number_format($latePct, 1)) ?>%</small></div>
                    <div><span><i class="adm-dot adm-dot--blue"></i>Excused</span><b><?= h((string)$attendanceExcused) ?></b><small><?= h(number_format($excusedPct, 1)) ?>%</small></div>
                </div>
            </div>
            <a class="adm-attendance-btn" href="<?= h(route_url('students/attendance')) ?>"><i class="bi bi-calendar-check"></i> Manage Attendance</a>
        </div>
      </div>
    </section>

    <section class="adm-main-grid adm-main-grid--row2">
      <div class="adm-col adm-col-1">
        <div class="adm-card adm-announcements-card">
            <div class="adm-card-head"><div><h2>Recent Announcements</h2><p>Latest messages from school administration</p></div><a class="adm-link" href="<?= h(route_url('notifications/announcements')) ?>">View all</a></div>
            <div class="adm-announcement-list">
                <?php if ($announcements): ?>
                    <?php foreach ($announcements as $a): ?>
                        <a class="adm-announcement" href="<?= h(route_url('notifications/announcements')) ?>">
                            <span class="adm-announcement-icon"><i class="bi bi-megaphone-fill"></i></span>
                            <span class="adm-announcement-body">
                                <b><?= h((string)($a['title'] ?? 'Announcement')) ?></b>
                                <small><?= h((string)($a['message'] ?? '')) ?></small>
                            </span>
                            <time><?= h(!empty($a['created_at']) ? date('d M', strtotime((string)$a['created_at'])) : '') ?></time>
                        </a>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="adm-empty"><i class="bi bi-megaphone"></i><span>No announcements yet.</span></div>
                <?php endif; ?>
            </div>
        </div>
      </div>

      <div class="adm-col adm-col-2">
        <div class="adm-card adm-activity-card">
            <div class="adm-card-head"><div><h2>Today's Activity</h2><p>Recent changes across the system</p></div><a class="adm-link" href="<?= h(route_url('reports/index')) ?>">View all</a></div>
            <div class="adm-activity-list">
                <?php if ($activities): ?>
                    <?php foreach ($activities as $activity): ?>
                        <div class="adm-activity">
                            <span class="adm-activity-dot adm-activity-dot--<?= h((string)($activity['tone'] ?? 'blue')) ?>"></span>
                            <div><small><?= h((string)($activity['time'] ?? 'Today')) ?></small><b><?= h((string)($activity['title'] ?? 'Activity')) ?></b><span><?= h((string)($activity['detail'] ?? '')) ?></span></div>
                            <i class="bi bi-check-circle-fill"></i>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="adm-empty"><i class="bi bi-activity"></i><span>No activity recorded yet today.</span></div>
                <?php endif; ?>
            </div>
        </div>
      </div>

      <div class="adm-col adm-col-3">
        <div class="adm-card adm-finance-card">
            <div class="adm-card-head adm-card-head--stack-mobile">
                <div><h2>Finance Overview</h2><p id="financeFeesSub"><?= h($period) ?></p></div>
                <div class="adm-chart-controls">
                    <span class="adm-legend"><i class="adm-legend-dot adm-legend-dot--fees"></i> Fees</span>
                    <span class="adm-legend"><i class="adm-legend-dot adm-legend-dot--payroll"></i> Payroll</span>
                    <span class="adm-legend"><i class="adm-legend-dot adm-legend-dot--other"></i> Other</span>
                    <select class="adm-select" id="financeMode" aria-label="Finance period">
                        <option value="year" selected>Year</option>
                        <option value="month">Month</option>
                    </select>
                    <select class="adm-select" id="financeYear" aria-label="Finance year"></select>
                    <select class="adm-select" id="financeMonth" aria-label="Finance month" hidden>
                        <?php /* Months in academic-year order: Mar .. Feb */ ?>
                        <?php for ($i = 0; $i < 12; $i++): $m = (($i + 2) % 12) + 1; ?>
                            <option value="<?= $m ?>" <?= (int)date('n') === $m ? 'selected' : '' ?>><?= h(date('M', mktime(0,0,0,$m,1))) ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>

            <div class="adm-finance-summary">
                <div><span>Collected</span><strong class="adm-money adm-money--green" id="foFeesValue">Rs <?= h($fmt($fees)) ?></strong></div>
                <div><span>Pending</span><strong class="adm-money adm-money--amber" id="foPendingValue">Rs <?= h($fmt($pending)) ?></strong></div>
                <div><span>Expenses</span><strong class="adm-money adm-money--rose" id="foExpenseValue">Rs <?= h($fmt($exp + $otherExp)) ?></strong></div>
                <div><span>Net Balance</span><strong class="adm-money adm-money--blue" id="foNetValue">Rs <?= h($fmt($net)) ?></strong></div>
            </div>

            <div class="adm-chart-wrap"><canvas id="financeChart"></canvas></div>
            <div class="adm-finance-foot"><span>Fees collected + pending dues</span><a href="<?= h(route_url('fees/invoices')) ?>">View finance report <i class="bi bi-arrow-right"></i></a></div>
        </div>
      </div>
    </section>

    <div class="adm-footer-note">
        <span><i class="bi bi-shield-check"></i> Admin overview · Data is live from your school system</span>
        <span>School Management System</span>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
(function () {
    const modeEl = document.getElementById('financeMode');
    const yearEl = document.getElementById('financeYear');
    const monthEl = document.getElementById('financeMonth');
    const subEl = document.getElementById('financeFeesSub');
    const feesEl = document.getElementById('foFeesValue');
    const pendingBase = <?= json_encode($pending) ?>;
    const pendingEl = document.getElementById('foPendingValue');
    // Calendar year in which the CURRENT academic year (Mar-Feb) started, from the server.
    const currentStart = <?= (int)($stats['period_year'] ?? date('Y')) ?>;
    const expenseEl = document.getElementById('foExpenseValue');
    const netEl = document.getElementById('foNetValue');
    const canvas = document.getElementById('financeChart');
    if (!canvas || typeof Chart === 'undefined') return;

    const chart = new Chart(canvas.getContext('2d'), {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                { label: 'Fees', data: [], borderColor: '#35d07f', backgroundColor: 'rgba(53,208,127,.12)', borderWidth: 2.5, tension: .35, fill: true, pointRadius: 2.5, pointHoverRadius: 5 },
                { label: 'Payroll', data: [], borderColor: '#ff5b78', backgroundColor: 'rgba(255,91,120,.08)', borderWidth: 2, tension: .35, fill: true, pointRadius: 2.5, pointHoverRadius: 5 },
                { label: 'Other', data: [], borderColor: '#f5b33d', backgroundColor: 'rgba(245,179,61,.06)', borderWidth: 2, tension: .35, fill: false, pointRadius: 2.5, pointHoverRadius: 5 }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#111b2a', titleColor: '#f8fafc', bodyColor: '#dbe5f2', padding: 12,
                    callbacks: { label: c => ' ' + c.dataset.label + ': Rs ' + Number(c.parsed.y || 0).toLocaleString() }
                }
            },
            scales: {
                x: { grid: { display: false }, border: { display: false }, ticks: { color: '#7f91a8', font: { size: 10 } } },
                y: { beginAtZero: true, border: { display: false }, grid: { color: 'rgba(148,163,184,.10)' }, ticks: { color: '#7f91a8', font: { size: 10 }, callback: v => Number(v) >= 1000 ? (Number(v)/1000) + 'k' : v } }
            }
        }
    });

    function money(n) { return 'Rs ' + Number(n || 0).toLocaleString(undefined, { maximumFractionDigits: 0 }); }
    function buildYears() {
        const y = currentStart;
        yearEl.innerHTML = '';
        for (let i = y - 5; i <= y; i++) {
            const option = document.createElement('option');
            // value = year the academic year STARTS; label shows the full span, e.g. 2026-2027
            option.value = i; option.textContent = i + '-' + (i + 1); if (i === y) option.selected = true;
            yearEl.appendChild(option);
        }
    }
    function syncMode() {
        const month = modeEl.value === 'month';
        monthEl.hidden = !month;
    }
    async function load() {
        const url = `<?= h(base_url('/index.php?route=dashboard/financeData')) ?>&mode=${encodeURIComponent(modeEl.value)}&year=${encodeURIComponent(yearEl.value)}&month=${encodeURIComponent(monthEl.value)}`;
        try {
            const response = await fetch(url, { headers: { Accept: 'application/json' } });
            const json = await response.json();
            if (!json || json.error || !Array.isArray(json.labels)) throw new Error('Finance data unavailable');
            chart.data.labels = json.labels;
            chart.data.datasets[0].data = json.values || [];
            chart.data.datasets[1].data = json.expenses || [];
            chart.data.datasets[2].data = json.other_expenses || [];
            // Label comes from the server (e.g. "Mar 2026 \u2013 Feb 2027" or "Jan 2027")
            subEl.textContent = json.label || '';
            // Pending now follows the selected period, same invoices as Collected
            if (pendingEl && typeof json.pending === 'number') pendingEl.textContent = money(json.pending);
            feesEl.textContent = money(json.total);
            expenseEl.textContent = money(Number(json.expenses_total || 0) + Number(json.other_expenses_total || 0));
            netEl.textContent = money(json.net);
            chart.update();
        } catch (error) {
            console.error(error);
            subEl.textContent = 'Finance data could not be loaded';
        }
    }
    modeEl.addEventListener('change', () => { syncMode(); load(); });
    yearEl.addEventListener('change', load);
    monthEl.addEventListener('change', load);
    buildYears(); syncMode(); load();
})();
</script>