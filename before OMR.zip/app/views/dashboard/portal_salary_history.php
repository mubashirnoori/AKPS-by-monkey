<?php
// Variables: $records, $total, $page, $perPage
$records = $records ?? [];
$total = (int)($total ?? 0);
$page = max(1, (int)($page ?? 1));
$perPage = (int)($perPage ?? 12);
$totalPages = max(1, (int)ceil($total / max(1, $perPage)));
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">My Salary History</h1>
        <div class="text-muted">All recorded months, most recent first.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=portal/index'), ENT_QUOTES, 'UTF-8') ?>">Back to Portal</a>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <?php if (empty($records)): ?>
            <div class="portal-empty"><i class="bi bi-cash-coin"></i>No salary records yet.</div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-sm table-hover mb-0">
                <thead><tr><th>Month</th><th>Gross</th><th>Deductions</th><th>Net</th><th>Paid</th><th>Status</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($records as $sd):
                    $net = (float)($sd['net_amount'] ?? 0);
                    $paid = (float)($sd['total_paid'] ?? 0);
                    $sStatus = 'Unpaid'; $sClass = 'danger';
                    if ($paid >= $net && $net > 0) { $sStatus = 'Paid'; $sClass = 'success'; }
                    elseif ($paid > 0) { $sStatus = 'Partial'; $sClass = 'warning'; }
                    $monthLabel = h(date('F', mktime(0, 0, 0, (int)$sd['salary_month'], 1))) . ' ' . (int)$sd['salary_year'];
                ?>
                    <tr>
                        <td class="fw-semibold"><?= $monthLabel ?></td>
                        <td>Rs <?= number_format((float)($sd['gross_amount'] ?? 0), 2) ?></td>
                        <td class="text-danger">Rs <?= number_format((float)($sd['deductions'] ?? 0), 2) ?></td>
                        <td>Rs <?= number_format($net, 2) ?></td>
                        <td>Rs <?= number_format($paid, 2) ?></td>
                        <td><span class="badge text-bg-<?= $sClass ?>"><?= $sStatus ?></span></td>
                        <td>
                            <a class="btn btn-sm btn-outline-primary" title="View salary details"
                               href="<?= htmlspecialchars(base_url('/index.php?route=portal/salaryView&salary_detail_id=' . (int)$sd['id']), ENT_QUOTES, 'UTF-8') ?>">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php if ($totalPages > 1): ?>
<nav class="mt-3">
    <ul class="pagination justify-content-center">
        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                <a class="page-link" href="<?= htmlspecialchars(base_url('/index.php?route=portal/mySalary&page=' . $p), ENT_QUOTES, 'UTF-8') ?>"><?= (int)$p ?></a>
            </li>
        <?php endfor; ?>
    </ul>
</nav>
<?php endif; ?>
