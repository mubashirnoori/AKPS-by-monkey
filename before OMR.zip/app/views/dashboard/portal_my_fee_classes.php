<?php
// Variables: $feeClasses
$feeClasses = $feeClasses ?? [];
?>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">Fee Collection Classes</h1>
        <div class="text-muted">Classes you're assigned to collect fees for.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=portal/index'), ENT_QUOTES, 'UTF-8') ?>">Back to Portal</a>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <?php if (empty($feeClasses)): ?>
            <div class="portal-empty"><i class="bi bi-cash-coin"></i>No classes assigned for fee collection yet.</div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-sm table-hover mb-0">
                <thead><tr><th>Class</th><th style="width:60px;"></th></tr></thead>
                <tbody>
                <?php foreach ($feeClasses as $fc): ?>
                    <tr>
                        <td><?= h(trim(($fc['class_name'] ?? '') . ' ' . ($fc['section_name'] ?? ''))) ?></td>
                        <td>
                            <a class="btn btn-sm btn-outline-primary" title="View students &amp; collect fees" href="<?= h(route_url('portal/feeClassStudents')) ?>&class_section_id=<?= (int)$fc['id'] ?>">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
