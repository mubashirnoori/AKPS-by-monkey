<?php
// Variables: $student, $exams, $examId, $card, $children, $selectedId
$student = $student ?? null;
$exams = $exams ?? [];
$examId = (int)($examId ?? 0);
$card = $card ?? null;
$children = $children ?? [];
$selectedId = (int)($selectedId ?? 0);

$settingsMap = [];
$schoolName  = 'ARC School';
$logoPath    = '';
try {
    if (class_exists('Database')) {
        $rows = Database::fetchAll('SELECT `key`, `value` FROM settings');
        foreach ($rows as $r) { $settingsMap[$r['key']] = $r['value']; }
    }
    $schoolName = $settingsMap['branding_school_name'] ?? $settingsMap['institute_name'] ?? 'ARC School';
    $logoPath   = $settingsMap['branding_logo_path'] ?? '';
} catch (Throwable $e) {}
?>
<style>
.cert-controls { margin-bottom: 1.2rem; }
.cert-page {
    background: #fff;
    border: 3px solid #1e3a5f;
    border-radius: 12px;
    max-width: 720px;
    margin: 0 auto;
    padding: 0;
    box-shadow: 0 6px 32px rgba(30,58,95,.13);
    overflow: hidden;
    font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif;
    color: #0f172a;
    --bs-body-color: #0f172a;
    --bs-table-color: #0f172a;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    min-height: 250mm;
}
.cert-page, .cert-page table, .cert-page td, .cert-page th, .cert-page strong { color: inherit; }
.cert-outer-border { border: 6px double #b89a4e; margin: 10px; border-radius: 8px; padding: 2rem 2.5rem 1.8rem; color: #0f172a; flex: 1; display: flex; flex-direction: column; }
.cert-school-title { font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif; text-align: center; font-size: 1.85rem; font-weight: 800; letter-spacing: .1em; color: #1e3a5f; margin: 0 0 .25rem; text-transform: uppercase; }
.cert-info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: .5rem 1.5rem; font-size: .88rem; margin: 1rem 0 1.25rem; padding: .85rem 1rem; background: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0; text-align: left; }
.cert-info-grid .lbl { color: #64748b; font-size: .72rem; text-transform: uppercase; letter-spacing: .06em; }
.cert-info-grid .val { font-weight: 700; color: #0f172a; }
.cert-logo { display: block; margin: .4rem auto .8rem; height: 72px; width: auto; border-radius: 8px; }
.cert-logo-fallback { width: 72px; height: 72px; border-radius: 50%; background: linear-gradient(135deg,#1e3a5f,#2563eb); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 2rem; margin: .4rem auto .8rem; }
.cert-title { font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif; text-align: center; font-size: 1.35rem; font-weight: 700; letter-spacing: 3px; text-transform: uppercase; color: #1e3a5f; border-top: 1.5px solid #b89a4e; border-bottom: 1.5px solid #b89a4e; padding: .4rem 0; margin: .6rem 0 1rem; }
.cert-subtitle { text-align: center; color: #6b7280; font-size: .9rem; margin-bottom: 1.2rem; font-style: italic; }
.cert-student-name { font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif; text-align: center; font-size: 1.7rem; font-weight: 700; color: #1e3a5f; }
.cert-summary { display: flex; justify-content: center; flex-wrap: wrap; gap: 1.5rem 2.5rem; margin-bottom: 1.2rem; padding: .9rem 1rem; background: #f8f5ec; border-radius: 8px; border: 1px solid #e9e0c5; }
.cert-summary-item { text-align: center; }
.cert-summary-item .val { font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif; font-size: 1.6rem; font-weight: 700; color: #1e3a5f; line-height: 1; }
.cert-summary-item .lbl { font-size: .72rem; text-transform: uppercase; letter-spacing: 1px; color: #9ca3af; margin-top: 3px; }
.cert-table { width: 100%; border-collapse: collapse; font-size: .88rem; margin-bottom: 1.2rem; color: #0f172a; }
.cert-table th { font-family: Calibri, Candara, 'Segoe UI', Optima, Arial, sans-serif; background: #1e3a5f !important; color: #fff !important; padding: .5rem .8rem; text-align: left; font-size: .78rem; letter-spacing: .8px; text-transform: uppercase; }
.cert-table td { padding: .45rem .8rem; border-bottom: 1px solid #f0e9d6; color: #0f172a !important; background: #fff; }
.cert-table tr:nth-child(even) td { background: #faf7f0 !important; color: #0f172a !important; }
.cert-table tr.cert-row-fail td { color: #9f1239 !important; }
.cert-grade-badge { display: inline-block; padding: 1px 8px; border-radius: 20px; font-size: .78rem; font-weight: 700; background: #1e3a5f; color: #fff !important; }
.cert-footer-note { text-align: center; font-size: .7rem; color: #9ca3af; margin-top: .8rem; }
@page { size: A4; margin: 10mm; }
@media print {
    .cert-controls, .navbar, aside, nav, .sms-no-print { display: none !important; }
    /* html's background (dashboard dark theme, --sms-bg) isn't scoped to
       screen-only in app.css, so resetting only <body> left a dark page
       showing through any stray overflow onto a second page. */
    html, body, .app-shell, .app-shell__main, main { background: #fff !important; }
    .cert-page { box-shadow: none; border-radius: 0; max-width: 100%; }
    * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
}
</style>

<div class="cert-controls sms-no-print">
    <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
        <div>
            <h1 class="h4 mb-0">My Report Card</h1>
            <div class="text-muted small">Only officially announced exams appear here.</div>
        </div>
        <div class="d-flex gap-2">
            <button type="button" class="btn btn-outline-primary" onclick="printReportCard()"><i class="bi bi-printer"></i> Print</button>
            <a class="btn btn-outline-secondary" href="<?= h(base_url('/index.php?route=portal/index')) ?>">Back to Portal</a>
        </div>
    </div>

    <?php if (count($children) > 1): ?>
    <ul class="nav portal-nav-pills mb-3">
        <?php foreach ($children as $c): ?>
            <li class="nav-item">
                <a class="nav-link <?= (int)$c['id'] === (int)$selectedId ? 'active' : '' ?>"
                   href="<?= h(base_url('/index.php?route=portal/myReportCard&student_id=' . (int)$c['id'])) ?>">
                    <?= h(trim(($c['first_name'] ?? '') . ' ' . ($c['last_name'] ?? ''))) ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
    <?php endif; ?>

    <?php if (!empty($exams)): ?>
    <form method="get" action="<?= h(base_url('/index.php')) ?>" class="card shadow-sm border-0 mb-3">
        <div class="card-body d-flex align-items-center gap-2 flex-wrap">
            <input type="hidden" name="route" value="portal/myReportCard">
            <?php if ($selectedId > 0): ?><input type="hidden" name="student_id" value="<?= (int)$selectedId ?>"><?php endif; ?>
            <label class="form-label mb-0 small text-muted">Exam</label>
            <select name="exam_id" class="form-select form-select-sm" style="max-width:320px;" onchange="this.form.submit()">
                <?php foreach ($exams as $e): ?>
                    <option value="<?= (int)$e['id'] ?>" <?= (int)$e['id'] === $examId ? 'selected' : '' ?>>
                        <?= h($e['exam_name'] ?? '') ?><?= !empty($e['scheduled_date']) ? ' — ' . h($e['scheduled_date']) : '' ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
    </form>
    <?php endif; ?>
</div>

<?php if (empty($exams)): ?>
    <div class="card shadow-sm border-0"><div class="card-body">
        <div class="portal-empty"><i class="bi bi-clipboard-data"></i>No published report cards yet.</div>
    </div></div>
<?php elseif ($student && $card): ?>
<?php
$fullName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
$className = trim((string)($student['current_class_name'] ?? ''));
$sectionName = trim((string)($student['current_section_name'] ?? ''));
$rollNo = (int)($student['roll_number'] ?? 0);
$studentMarks = $card['studentMarks'];
$overallGrade = $card['overallGrade'];
$resultStatus = $card['resultStatus'];
$studentRank = $card['studentRank'];
$isSchoolTopper = $card['isSchoolTopper'];
$combinedWith = $card['combinedWith'] ?? null;
$breakdown = $card['breakdown'] ?? [];

$resultLabel = static function (?string $status): string {
    if ($status === 'PROMOTE') {
        return 'PROMOTED';
    }
    return (string)$status;
};

$totalObtained = 0.0;
$totalMaxMarks = 0.0;
foreach ($studentMarks as $m) {
    $totalObtained += (float)($m['score'] ?? 0);
    $subTot = (float)($m['total_marks'] ?? 100);
    $totalMaxMarks += ($subTot > 0 ? $subTot : 100.0);
}
$overallPercentage = $totalMaxMarks > 0 ? round($totalObtained / $totalMaxMarks * 100, 1) : 0.0;
$examName = '';
foreach ($exams as $e) {
    if ((int)$e['id'] === $examId) { $examName = $e['exam_name'] ?? ''; break; }
}
?>
<div class="cert-print-scale-wrap" id="certScaleWrap">
<div class="cert-page">
  <div class="cert-outer-border">

    <h1 class="cert-school-title"><?= h($schoolName) ?></h1>

    <?php if ($logoPath): ?>
        <img src="<?= h(base_url($logoPath)) ?>" alt="School Logo" class="cert-logo">
    <?php else: ?>
        <div class="cert-logo-fallback"><i class="bi bi-mortarboard-fill"></i></div>
    <?php endif; ?>

    <div class="cert-title">Student Report Card</div>
    <div class="cert-subtitle"><?= h($examName) ?></div>
    <div class="cert-student-name"><?= h($fullName) ?></div>

    <div class="cert-info-grid">
        <div><div class="lbl">Class</div><div class="val"><?= $className !== '' ? h($className) : '—' ?></div></div>
        <div><div class="lbl">Section</div><div class="val"><?= $sectionName !== '' ? h($sectionName) : '—' ?></div></div>
        <div><div class="lbl">Roll number</div><div class="val"><?= $rollNo > 0 ? h((string)$rollNo) : '—' ?></div></div>
        <div><div class="lbl">Admission no.</div><div class="val"><?= h($student['admission_no'] ?? '') ?></div></div>
        <div><div class="lbl">Father's name</div><div class="val"><?= !empty($student['father_name']) ? h($student['father_name']) : '—' ?></div></div>
    </div>

    <table class="cert-table">
        <thead>
        <?php if ($combinedWith && !empty($breakdown)): ?>
            <tr><th>#</th><th>Subject</th><th><?= h($combinedWith) ?></th><th><?= h($examName) ?></th><th>Final Result</th><th>Total</th><th>%</th><th>Grade</th></tr>
        <?php else: ?>
            <tr><th>#</th><th>Subject</th><th>Obtained</th><th>Total</th><th>%</th><th>Grade</th></tr>
        <?php endif; ?>
        </thead>
        <tbody>
            <?php if (empty($studentMarks)): ?>
                <tr><td colspan="8" style="text-align:center;color:#9ca3af;padding:1.5rem;">No marks recorded for this exam.</td></tr>
            <?php else: ?>
                <?php foreach ($studentMarks as $i => $m): ?>
                    <?php
                    $score = (float)($m['score'] ?? 0);
                    $subTotal = (float)($m['total_marks'] ?? 100);
                    $subTotal = $subTotal > 0 ? $subTotal : 100.0;
                    $pct = round($score / $subTotal * 100, 1);
                    $bd = $breakdown[$m['subject_id']] ?? null;
                    ?>
                    <tr class="<?= empty($m['is_pass']) ? 'cert-row-fail' : '' ?>">
                        <td><?= $i + 1 ?></td>
                        <td><?= h($m['subject_name'] ?? '') ?></td>
                        <?php if ($combinedWith && !empty($breakdown)): ?>
                            <td><?= h(format_mark($bd['source']['score'] ?? 0)) ?></td>
                            <td><?= h(format_mark($bd['own']['score'] ?? 0)) ?></td>
                            <td><strong><?= h(format_mark($score)) ?></strong></td>
                        <?php else: ?>
                            <td><strong><?= h(format_mark($score)) ?></strong></td>
                        <?php endif; ?>
                        <td><?= h(format_mark($subTotal)) ?></td>
                        <td><?= h(format_mark($pct)) ?>%</td>
                        <td><span class="cert-grade-badge"><?= h($m['grade_letter'] ?? '—') ?></span></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="cert-summary">
        <div class="cert-summary-item">
            <div class="val"><?= h(format_mark($totalObtained)) ?></div>
            <div class="lbl">Total marks obtained</div>
        </div>
        <div class="cert-summary-item">
            <div class="val"><?= h(format_mark($totalMaxMarks)) ?></div>
            <div class="lbl">Total marks</div>
        </div>
        <div class="cert-summary-item">
            <div class="val"><?= h(format_mark($overallPercentage)) ?>%</div>
            <div class="lbl">Overall percentage</div>
        </div>
        <div class="cert-summary-item">
            <div class="val"><?= h((string)($overallGrade ?? '—')) ?></div>
            <div class="lbl">Final grade</div>
        </div>
        <?php if (!empty($studentRank)): ?>
        <div class="cert-summary-item">
            <div class="val"><?= h(ordinal((int)$studentRank)) ?> Position</div>
            <div class="lbl">In class</div>
        </div>
        <?php endif; ?>
        <?php if (!empty($isSchoolTopper)): ?>
        <div class="cert-summary-item">
            <div class="val" style="color:#b45309;">🏆</div>
            <div class="lbl">Whole-School Topper</div>
        </div>
        <?php endif; ?>
        <?php if (!empty($resultStatus)): ?>
        <?php
        $resultColor = $resultStatus === 'PASS' ? '#15803d'
            : ($resultStatus === 'PROMOTE' ? '#1d4ed8'
            : ($resultStatus === 'INCOMPLETE' ? '#a16207' : '#b91c1c'));
        ?>
        <div class="cert-summary-item">
            <div class="val" style="color:<?= $resultColor ?>"><?= h($resultLabel($resultStatus)) ?></div>
            <div class="lbl">Result</div>
        </div>
        <?php endif; ?>
    </div>

    <?php if ($combinedWith): ?>
    <div class="cert-footer-note" style="margin-top:auto;padding-top:.6rem;">Combined result: <?= h($combinedWith) ?> + <?= h($examName) ?></div>
    <?php endif; ?>

    <div class="cert-footer-note" style="<?= $combinedWith ? '' : 'margin-top:auto;padding-top:.6rem;' ?>"><?= h($schoolName) ?> — Confidential academic record</div>

  </div>
</div>
</div>
<script>
// See academic/certificate.php for the full explanation: beforeprint is
// unreliable on mobile, so the Print button triggers the fit-to-page
// scaling directly instead of depending on that event.
function printReportCard() {
    if (typeof window.fitReportCardToPage === 'function') { window.fitReportCardToPage(); }
    requestAnimationFrame(function () {
        requestAnimationFrame(function () {
            window.print();
        });
    });
}
(function () {
    var scaleWrap = document.getElementById('certScaleWrap');
    var page = scaleWrap ? scaleWrap.querySelector('.cert-page') : null;
    if (!scaleWrap || !page) { return; }

    var PAGE_WIDTH_PX  = (210 - 20) * (96 / 25.4);
    var PAGE_HEIGHT_PX = (297 - 20) * (96 / 25.4);

    function fitToOnePage() {
        page.style.transform = 'none';
        page.style.width = '';
        scaleWrap.style.height = '';
        scaleWrap.style.overflow = '';

        // Force the print-time width before measuring -- on a phone the
        // page renders at the narrow screen width on-screen, which gives
        // the wrong height and the wrong (or no) scale at print time.
        page.style.width = PAGE_WIDTH_PX + 'px';
        var naturalHeight = page.offsetHeight;

        if (naturalHeight > PAGE_HEIGHT_PX) {
            var scale = PAGE_HEIGHT_PX / naturalHeight;
            page.style.transformOrigin = 'top center';
            page.style.transform = 'scale(' + scale + ')';
            scaleWrap.style.height = (naturalHeight * scale) + 'px';
            scaleWrap.style.overflow = 'hidden';
        }
    }
    window.fitReportCardToPage = fitToOnePage;

    function resetFit() {
        page.style.transform = 'none';
        page.style.width = '';
        scaleWrap.style.height = '';
        scaleWrap.style.overflow = '';
    }

    window.addEventListener('beforeprint', fitToOnePage);
    window.addEventListener('afterprint', resetFit);
    document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible') { resetFit(); }
    });
})();
</script>
<?php endif; ?>