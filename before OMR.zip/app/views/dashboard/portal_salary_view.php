<?php
// Variables: $record, $payments, $totalPaid
$payments = $payments ?? [];
$net = (float)($record['net_amount'] ?? 0);
$gross = (float)($record['gross_amount'] ?? 0);
$deductions = (float)($record['deductions'] ?? 0);
$totalPaid = (float)($totalPaid ?? 0);
$pending = max($net - $totalPaid, 0);
$statusBadge = ($totalPaid >= $net && $net > 0) ? 'success' : ($totalPaid > 0 ? 'warning' : 'danger');
$statusLabel = ($totalPaid >= $net && $net > 0) ? 'Paid' : ($totalPaid > 0 ? 'Partial' : 'Unpaid');
$monthLabel = h(date('F', mktime(0, 0, 0, (int)($record['salary_month'] ?? 1), 1))) . ' ' . (int)($record['salary_year'] ?? date('Y'));
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Salary — <?= $monthLabel ?></h1>
        <?php if (!empty($record['salary_created_date'])): ?>
            <div class="text-muted">Salary date: <?= h($record['salary_created_date']) ?></div>
        <?php endif; ?>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=portal/mySalary'), ENT_QUOTES, 'UTF-8') ?>">Back to Salary History</a>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-3">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="text-muted small">Status</div>
                <div class="h5 mb-0"><span class="badge text-bg-<?= $statusBadge ?>"><?= $statusLabel ?></span></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="text-muted small">Net Payable</div>
                <div class="h5 mb-0">Rs <?= number_format($net, 2) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="text-muted small">Paid</div>
                <div class="h5 mb-0 text-success">Rs <?= number_format($totalPaid, 2) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="text-muted small">Pending</div>
                <div class="h5 mb-0 <?= $pending > 0 ? 'text-danger' : 'text-success' ?>">Rs <?= number_format($pending, 2) ?></div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Breakdown</h2>
                <div class="table-responsive">
                    <table class="table table-sm mb-0">
                        <tbody>
                            <tr><td>Gross</td><td class="text-end">Rs <?= number_format($gross, 2) ?></td></tr>
                            <tr><td>Deductions</td><td class="text-end text-danger">- Rs <?= number_format($deductions, 2) ?></td></tr>
                            <tr class="fw-semibold"><td>Net Payable</td><td class="text-end">Rs <?= number_format($net, 2) ?></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Payment History</h2>
                <div class="table-responsive">
                    <table class="table table-sm mb-0">
                        <thead><tr><th>Date</th><th>Amount</th><th>Method</th><th>Note</th></tr></thead>
                        <tbody>
                        <?php foreach ($payments as $p): ?>
                            <tr>
                                <td class="text-muted small"><?= h($p['paid_date'] ?? '') ?></td>
                                <td class="fw-semibold text-success">Rs <?= number_format((float)($p['amount'] ?? 0), 2) ?></td>
                                <td class="text-muted small"><?= h(ucfirst($p['method'] ?? '')) ?></td>
                                <td class="text-muted small"><?= h($p['note'] ?? '—') ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($payments)): ?>
                            <tr><td colspan="4" class="text-muted">No payments recorded yet.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
