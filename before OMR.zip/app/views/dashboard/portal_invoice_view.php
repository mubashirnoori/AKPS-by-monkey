<?php
// Variables: $invoice, $lines, $collections, $returnUrl
$lines = $lines ?? [];
$lineBalances = $lineBalances ?? [];
$collections = $collections ?? [];
$paid = (float)($invoice['collected_amount'] ?? 0);
$due = (float)($invoice['total_due'] ?? 0);
$pending = max($due - $paid, 0);
$statusBadge = ($invoice['status'] ?? '') === 'paid' ? 'success' : (($invoice['status'] ?? '') === 'cancelled' ? 'secondary' : 'warning');
$canCollectFee = !empty($canCollectFee);
$returnUrl = $returnUrl ?? null;
$returnParam = $returnUrl !== null ? ('&return=' . rawurlencode($returnUrl)) : '';
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Invoice <?= h($invoice['invoice_no'] ?? '') ?></h1>
        <div class="text-muted">
            <?= h(trim(($invoice['first_name'] ?? '') . ' ' . ($invoice['last_name'] ?? ''))) ?>
            <?php if (!empty($invoice['father_name'])): ?>
                &middot; Father: <?= h($invoice['father_name']) ?>
            <?php endif; ?>
            &middot; Admission #<?= h($invoice['admission_no'] ?? '') ?>
        </div>
    </div>
    <div class="d-flex gap-2">
        <?php if ($canCollectFee): ?>
            <a class="btn btn-outline-primary" href="<?= h(route_url('portal/feeInvoicePrint')) ?>&invoice_id=<?= (int)($invoice['id'] ?? 0) ?>" target="_blank">Print</a>
            <?php if ($pending > 0.001): ?>
                <a class="btn btn-success" href="#" data-collect-invoice-id="<?= (int)($invoice['id'] ?? 0) ?>" data-collect-endpoint="portal" title="Opens without leaving this page">Collect Payment</a>
            <?php endif; ?>
        <?php endif; ?>
        <?php if ($returnUrl !== null): ?>
            <a class="btn btn-outline-secondary" href="<?= h($returnUrl) ?>">Back to List</a>
        <?php endif; ?>
        <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=portal/index'), ENT_QUOTES, 'UTF-8') ?>">Back to Portal</a>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-3">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="text-muted small">Status</div>
                <div class="h5 mb-0"><span class="badge text-bg-<?= $statusBadge ?>"><?= h(ucfirst($invoice['status'] ?? '')) ?></span></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="text-muted small">Total</div>
                <div class="h5 mb-0">Rs <?= number_format($due, 2) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="text-muted small">Paid</div>
                <div class="h5 mb-0 text-success">Rs <?= number_format($paid, 2) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="text-muted small">Pending</div>
                <div class="h5 mb-0 <?= $pending > 0 ? 'text-danger' : 'text-success' ?>">Rs <?= number_format($pending, 2) ?></div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-7">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">What this invoice covers</h2>
                <div class="table-responsive">
                    <table class="table table-sm mb-0">
                        <thead><tr><th>Fee</th><th>Amount</th><th>Discount</th><th>Line Total</th><th>Paid</th><th>Pending</th><th>Status</th></tr></thead>
                        <tbody>
                        <?php foreach ($lines as $l): ?>
                            <?php
                            $lb = $lineBalances[(int)($l['id'] ?? 0)] ?? null;
                            $linePaid = (float)($lb['paid'] ?? 0);
                            $linePending = (float)($lb['pending'] ?? max((float)($l['line_total'] ?? 0) - $linePaid, 0));
                            $lineIsPaid = $linePending <= 0.001;
                            ?>
                            <tr class="<?= $lineIsPaid ? 'table-success' : '' ?>">
                                <td>
                                    <?= h($l['description'] ?: ($l['fee_category_name'] ?? '')) ?>
                                    <?php if (!empty($l['billing_month'])): ?>
                                        <span class="badge border ms-1" style="background: var(--sms-surface-2, #1f2937); color: var(--sms-text, #e5e7eb);">
                                            <?= h(date('F', mktime(0, 0, 0, (int)$l['billing_month'], 1))) ?><?= !empty($l['billing_year']) ? ' ' . h($l['billing_year']) : '' ?>
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>Rs <?= number_format((float)($l['base_amount'] ?? 0), 2) ?></td>
                                <td class="text-muted"><?= ((float)($l['discount_amount'] ?? 0)) > 0 ? '- Rs ' . number_format((float)$l['discount_amount'], 2) : '—' ?></td>
                                <td class="fw-semibold">Rs <?= number_format((float)($l['line_total'] ?? 0), 2) ?></td>
                                <td class="text-success">Rs <?= number_format($linePaid, 2) ?></td>
                                <td class="<?= $linePending > 0 ? 'text-danger fw-semibold' : 'text-success' ?>">Rs <?= number_format($linePending, 2) ?></td>
                                <td><span class="badge <?= $lineIsPaid ? 'text-bg-success' : 'text-bg-secondary' ?>"><?= $lineIsPaid ? 'Paid' : 'Unpaid' ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($lines)): ?>
                            <tr><td colspan="7" class="text-muted">No line items found.</td></tr>
                        <?php endif; ?>
                        <?php if ((float)($invoice['fine_applied'] ?? 0) > 0): ?>
                            <tr>
                                <td class="text-danger">Late fine</td>
                                <td colspan="5"></td>
                                <td class="fw-semibold text-danger">Rs <?= number_format((float)$invoice['fine_applied'], 2) ?></td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Payment History</h2>
                <div class="table-responsive">
                    <table class="table table-sm mb-0">
                        <thead><tr><th>Date</th><th>Amount</th><th>Method</th></tr></thead>
                        <tbody>
                        <?php foreach ($collections as $c): ?>
                            <tr>
                                <td class="text-muted small"><?= h($c['collected_at'] ?? '') ?></td>
                                <td class="fw-semibold">Rs <?= number_format((float)($c['amount'] ?? 0), 2) ?></td>
                                <td class="text-muted small"><?= h($c['method'] ?? '') ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($collections)): ?>
                            <tr><td colspan="3" class="text-muted">No payments recorded yet.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
