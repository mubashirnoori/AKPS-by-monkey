<?php
// Variables: $course, $studentId, $isParentView, $backUrl
$course = $course ?? [];
$resources = $course['resources'] ?? [];
$isParentView = $isParentView ?? false;
$backUrl = $backUrl ?? route_url('portal/index');

$typeLabels = ['video' => 'Video Lecture', 'live_class' => 'Live Class', 'document' => 'Document', 'link' => 'Reference Link'];
$typeIcon = ['video' => 'bi-play-circle', 'live_class' => 'bi-camera-video', 'document' => 'bi-file-earmark-text', 'link' => 'bi-link-45deg'];
$typeBadge = ['video' => 'primary', 'live_class' => 'danger', 'document' => 'secondary', 'link' => 'info'];

$totalCount = count($resources);
$trackedCount = 0;
$completedCount = 0;
foreach ($resources as $r) {
    if (($r['resource_type'] ?? '') === 'video' && ($r['source_type'] ?? 'link') === 'upload') {
        $trackedCount++;
        if ((float)($r['my_progress_percent'] ?? 0) >= 95) {
            $completedCount++;
        }
    }
}
?>

<input type="hidden" id="portalCsrfToken" value="<?= h(CSRF::token()) ?>">

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <a class="text-decoration-none text-muted small" href="<?= h($backUrl) ?>"><i class="bi bi-arrow-left me-1"></i>Back to My Portal</a>
        <h1 class="h4 mb-0 mt-1"><?= h($course['title'] ?? '') ?></h1>
        <?php if (!empty($course['description'])): ?>
            <div class="text-muted"><?= h($course['description']) ?></div>
        <?php endif; ?>
    </div>
    <span class="badge text-bg-dark border"><?= (int)$totalCount ?> item<?= $totalCount === 1 ? '' : 's' ?></span>
</div>

<?php if ($trackedCount > 0): ?>
    <div class="card shadow-sm border-0 portal-section">
        <div class="card-body">
            <div class="d-flex align-items-center justify-content-between mb-2">
                <span class="text-muted small">Your progress</span>
                <span class="text-muted small"><?= $completedCount ?> / <?= $trackedCount ?> lectures completed</span>
            </div>
            <div class="progress" style="height:8px;">
                <div class="progress-bar" style="width: <?= $trackedCount > 0 ? round(($completedCount / $trackedCount) * 100) : 0 ?>%;"></div>
            </div>
        </div>
    </div>
<?php endif; ?>

<div class="card shadow-sm border-0 portal-section">
    <div class="card-body">
        <div class="portal-section__head">
            <div class="portal-section__icon portal-section__icon--rose"><i class="bi bi-list-ol"></i></div>
            <p class="portal-section__title mb-0">Curriculum</p>
        </div>

        <?php if (empty($resources)): ?>
            <div class="portal-empty"><i class="bi bi-play-btn"></i>No lectures or materials posted yet. Check back soon.</div>
        <?php else: ?>
            <?php foreach ($resources as $i => $r):
                $type = $r['resource_type'] ?? 'link';
                $isUpcoming = ($type === 'live_class') && !empty($r['scheduled_at']) && strtotime($r['scheduled_at']) > time();
                $isTrackedVideo = ($type === 'video') && (($r['source_type'] ?? 'link') === 'upload');
                $itemId = 'curr-item-' . (int)$r['id'];
            ?>
                <div class="portal-curriculum-item<?= $i === 0 ? ' is-open' : '' ?>" id="<?= h($itemId) ?>">
                    <div class="portal-curriculum-item__head" data-toggle-item>
                        <div class="portal-curriculum-item__num"><?= $i + 1 ?></div>
                        <div>
                            <div class="portal-curriculum-item__title">
                                <i class="bi <?= h($typeIcon[$type] ?? 'bi-link-45deg') ?> me-1"></i>
                                <?= h($r['title'] ?? '') ?>
                                <span class="badge text-bg-<?= h($typeBadge[$type] ?? 'secondary') ?> ms-2"><?= h($typeLabels[$type] ?? $type) ?></span>
                            </div>
                            <div class="portal-curriculum-item__sub">
                                <?php if (!empty($r['scheduled_at'])): ?>
                                    <?= $isUpcoming ? 'Upcoming — ' : '' ?><?= h($r['scheduled_at']) ?>
                                <?php elseif ($isTrackedVideo): ?>
                                    <?= (float)($r['my_progress_percent'] ?? 0) ?>% watched
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if ($isTrackedVideo && (float)($r['my_progress_percent'] ?? 0) >= 95): ?>
                            <span class="badge text-bg-success ms-2"><i class="bi bi-check-lg"></i></span>
                        <?php endif; ?>
                        <i class="bi bi-chevron-down portal-curriculum-item__chevron"></i>
                    </div>

                    <div class="portal-curriculum-item__body">
                        <?php if (!empty($r['description'])): ?>
                            <div class="text-muted small mb-2"><?= h($r['description']) ?></div>
                        <?php endif; ?>

                        <?php if ($isTrackedVideo && !empty($r['resource_url'])): ?>
                            <video class="w-100 rounded video-progress-player" style="max-height:360px;background:#000;"
                                   controls preload="none"
                                   data-resource-id="<?= (int)$r['id'] ?>"
                                   data-resume="<?= (int)($r['my_last_position'] ?? 0) ?>"
                                   src="<?= h(base_url($r['resource_url'])) ?>"></video>
                            <div class="progress mt-2" style="height:6px;">
                                <div class="progress-bar video-progress-bar" style="width: <?= (float)($r['my_progress_percent'] ?? 0) ?>%;"></div>
                            </div>
                            <div class="text-muted small video-progress-label mt-1"><?= (float)($r['my_progress_percent'] ?? 0) ?>% watched</div>
                        <?php elseif (!empty($r['resource_url'])): ?>
                            <a class="btn btn-sm btn-<?= $type === 'live_class' ? ($isUpcoming ? 'danger' : 'outline-secondary') : 'outline-primary' ?>" href="<?= h($r['resource_url']) ?>" target="_blank" rel="noopener">
                                <?= $type === 'live_class' ? ($isUpcoming ? 'Join Live Class' : 'View Recording') : 'Open' ?>
                                <i class="bi bi-box-arrow-up-right ms-1"></i>
                            </a>
                        <?php else: ?>
                            <div class="text-muted small">No link attached to this item yet.</div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<script>
(function () {
    // Expand/collapse each curriculum item; only the item being opened loads its
    // video (preload="none" + no src swap needed since src is already set, the
    // browser just doesn't fetch until play/metadata is requested).
    document.querySelectorAll('[data-toggle-item]').forEach(function (head) {
        head.addEventListener('click', function () {
            head.closest('.portal-curriculum-item').classList.toggle('is-open');
        });
    });

    <?php if (!$isParentView && $trackedCount > 0): ?>
    var csrfToken = document.getElementById('portalCsrfToken');
    csrfToken = csrfToken ? csrfToken.value : '';
    var progressUrl = <?= json_encode(base_url('/index.php?route=portal/resourceProgress')) ?>;

    function sendProgress(resourceId, percent, position) {
        var body = new URLSearchParams({
            resource_id: resourceId,
            percent: percent.toFixed(1),
            position: Math.floor(position),
            csrf_token: csrfToken
        });
        fetch(progressUrl, { method: 'POST', body: body, credentials: 'same-origin' }).catch(function () {});
    }

    document.querySelectorAll('video.video-progress-player').forEach(function (video) {
        var resourceId = video.dataset.resourceId;
        var wrap = video.parentElement;
        var bar = wrap.querySelector('.video-progress-bar');
        var label = wrap.querySelector('.video-progress-label');
        var lastSentAt = 0;

        function updateUI(percent) {
            percent = Math.max(0, Math.min(100, percent));
            if (bar) { bar.style.width = percent + '%'; }
            if (label) { label.textContent = Math.round(percent) + '% watched'; }
            return percent;
        }

        video.addEventListener('loadedmetadata', function () {
            var resume = parseFloat(video.dataset.resume || '0');
            if (resume > 2 && video.duration && resume < video.duration - 2) {
                video.currentTime = resume;
            }
        });

        video.addEventListener('timeupdate', function () {
            if (!video.duration) { return; }
            var percent = updateUI((video.currentTime / video.duration) * 100);
            var now = Date.now();
            if (now - lastSentAt > 8000) {
                lastSentAt = now;
                sendProgress(resourceId, percent, video.currentTime);
            }
        });

        video.addEventListener('pause', function () {
            if (!video.duration) { return; }
            sendProgress(resourceId, (video.currentTime / video.duration) * 100, video.currentTime);
        });

        video.addEventListener('ended', function () {
            updateUI(100);
            sendProgress(resourceId, 100, video.duration || 0);
        });
    });
    <?php endif; ?>
})();
</script>
