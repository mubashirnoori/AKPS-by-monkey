<?php
// Variables: $subjects, $classes, $classTeacherSectionIds, $feeClasses
$subjects = $subjects ?? [];
$classes = $classes ?? [];
$classTeacherSectionIds = $classTeacherSectionIds ?? [];
$feeClasses = $feeClasses ?? [];

// --- Derived data for the KPI strip and the subject index ------------------

// Group subject rows by subject name so "English — 10th Arts" and
// "English — 10th Science" become one tile with two class chips, not two
// separate rows in a long flat table.
$subjectGroups = [];
foreach ($subjects as $s) {
    $name = (string)($s['subject_name'] ?? 'Untitled subject');
    if (!isset($subjectGroups[$name])) {
        $subjectGroups[$name] = [];
    }
    $subjectGroups[$name][] = (string)($s['class_name'] ?? '—');
}
ksort($subjectGroups, SORT_NATURAL | SORT_FLAG_CASE);

$totalStudents = 0;
$maxHeadcount = 0;
foreach ($classes as $c) {
    $count = (int)($c['student_count'] ?? 0);
    $totalStudents += $count;
    if ($count > $maxHeadcount) {
        $maxHeadcount = $count;
    }
}
$classCount = count($classes);
$avgPerClass = $classCount > 0 ? (int)round($totalStudents / $classCount) : 0;
$classTeacherCount = count($classTeacherSectionIds);
$accents = ['amber', 'violet', 'teal', 'green', 'rose', 'pink'];

// Subject name -> Bootstrap icon, matched by keyword so it degrades
// gracefully for subjects the school adds later (falls back to a plain book).
$subjectIconMap = [
    'english'    => 'bi-book',
    'urdu'       => 'bi-chat-square-text',
    'math'       => 'bi-calculator',
    'physic'     => 'bi-lightning-charge',
    'chemist'    => 'bi-eyedropper',
    'biology'    => 'bi-flower1',
    'islam'      => 'bi-moon-stars',
    'pak stud'   => 'bi-flag',
    'computer'   => 'bi-pc-display',
    'geography'  => 'bi-globe-asia-australia',
    'sociology'  => 'bi-people',
    'economic'   => 'bi-graph-up',
    'art'        => 'bi-palette',
];
// Wrapped in function_exists() because Controller::render() uses require()
// (not require_once) — this view is only ever included once per normal
// request, but the guard avoids a fatal "cannot redeclare" if that ever
// changes (e.g. a future admin "preview" screen that renders it twice).
if (!function_exists('subjectIcon')) {
    function subjectIcon(string $name, array $map): string
    {
        $needle = strtolower($name);
        foreach ($map as $key => $icon) {
            if (str_contains($needle, $key)) {
                return $icon;
            }
        }
        return 'bi-journal-bookmark';
    }
}

// Only the first 8 subject tiles show by default; "View All" reveals the
// rest client-side (no extra page/route needed since we already have the
// full list server-side).
$subjectTileLimit = 8;
$hasMoreSubjects = count($subjectGroups) > $subjectTileLimit;
?>

<style>
/* Scoped to .subjects-page only so the shared .portal-kpi / .portal-section
   rules used by every other portal page are left untouched. */
.subjects-page .portal-hero__avatar { font-size: 1.4rem; }

/* -- KPI strip: colored top edge + round icon avatar, matching the rest of
   the redesigned portal but with a slightly richer card face for this page. */
.subjects-page .portal-kpi {
    padding: 1.1rem 1.15rem;
    gap: 0.65rem;
}
.subjects-page .portal-kpi::before {
    top: 0; left: 0; right: 0; bottom: auto;
    width: 100%; height: 3px;
}
.subjects-page .portal-kpi__label {
    order: 2;
    color: #94a3b8;
    font-size: 0.8rem;
}
.subjects-page .portal-kpi__label i { display: none; }
.subjects-page .portal-kpi__value { order: 3; font-size: 1.7rem; }
.subjects-page .portal-kpi__hint { order: 4; }
.subjects-page .portal-kpi__icon {
    order: 1;
    width: 40px;
    height: 40px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.05rem;
    background: rgba(255, 255, 255, 0.06);
    color: var(--portal-kpi-accent, #b8873e);
    margin-bottom: 0.15rem;
}

/* -- Two-column layout: subjects on the left, headcounts on the right. On
   narrow screens they stack, subjects first. */
.subjects-layout {
    display: grid;
    grid-template-columns: 1.15fr 1fr;
    gap: 1.1rem;
    align-items: start;
}
@media (max-width: 991px) {
    .subjects-layout { grid-template-columns: 1fr; }
}

.subjects-page .portal-section__head { justify-content: space-between; }
.subjects-page .portal-section__head-left { display: flex; align-items: center; gap: 0.55rem; }

.subject-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 0.75rem;
}
@media (min-width: 576px) and (max-width: 991px) {
    .subject-grid { grid-template-columns: repeat(3, 1fr); }
}
@media (min-width: 1200px) {
    .subject-grid { grid-template-columns: repeat(4, 1fr); }
}

.subject-tile {
    position: relative;
    border-radius: 14px;
    padding: 0.95rem 1rem 0.85rem;
    background: #12181f;
    border: 1px solid rgba(255, 255, 255, 0.07);
    border-bottom: 3px solid var(--tile-accent, #b8873e);
    overflow: hidden;
    transition: transform 0.12s ease, border-color 0.12s ease;
}
.subject-tile:hover { transform: translateY(-2px); }

/* Tiles beyond the limit start hidden; JS toggles .subject-grid--expanded. */
.subject-tile--extra { display: none; }
.subject-grid--expanded .subject-tile--extra { display: block; }

.subject-tile__icon {
    width: 34px;
    height: 34px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    font-size: 1rem;
    background: var(--tile-accent-bg, rgba(184, 135, 62, 0.14));
    color: var(--tile-accent, #b8873e);
    margin-bottom: 0.6rem;
}

.subject-tile__name {
    font-weight: 700;
    color: #f8fafc;
    font-size: 0.92rem;
    line-height: 1.25;
}

.subject-tile__count {
    color: #64748b;
    font-size: 0.72rem;
    font-weight: 600;
    margin-top: 0.1rem;
}

.subject-tile__chips {
    display: flex;
    flex-wrap: wrap;
    gap: 0.3rem;
    margin-top: 0.55rem;
}

.subject-chip {
    display: inline-block;
    padding: 0.2rem 0.55rem;
    border-radius: 999px;
    font-size: 0.68rem;
    font-weight: 600;
    color: #94a3b8;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.08);
}

.subjects-view-all-link {
    display: block;
    text-align: center;
    margin-top: 0.9rem;
    font-size: 0.83rem;
    font-weight: 600;
}

/* -- Class headcounts: name + colored progress bar + count, filterable by
   the "All Classes / Class Teacher Only" select. */
.headcount-filter {
    font-size: 0.8rem;
    padding: 0.3rem 0.65rem;
    background: #12181f;
    color: #e2e8f0;
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 8px;
}

.headcount-list { display: flex; flex-direction: column; gap: 0.65rem; }

.headcount-row {
    display: grid;
    grid-template-columns: minmax(90px, auto) auto 1fr auto;
    align-items: center;
    gap: 0.75rem;
    padding: 0.15rem 0;
}
.headcount-row[hidden] { display: none; }

/* Only rendered for classes where the teacher is the Class Teacher — sits
   right next to the class name so it's obvious which class it belongs to,
   instead of a single generic button buried in Quick Actions. */
.headcount-row__action .btn { white-space: nowrap; }

.headcount-row__name {
    font-weight: 700;
    color: #f8fafc;
    font-size: 0.85rem;
    display: flex;
    align-items: center;
    gap: 0.4rem;
    flex-wrap: wrap;
}

.headcount-row__track {
    height: 8px;
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.06);
    overflow: hidden;
}
.headcount-row__fill {
    height: 100%;
    border-radius: 999px;
    background: var(--bar-accent, #b8873e);
}

.headcount-row__count {
    font-weight: 700;
    color: #e2e8f0;
    font-size: 0.85rem;
    min-width: 2.4rem;
    text-align: right;
}

.class-teacher-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.3rem;
    padding: 0.1rem 0.5rem;
    border-radius: 999px;
    font-size: 0.62rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.03em;
    color: #f4eee0;
    background: rgba(184, 135, 62, 0.18);
    border: 1px solid rgba(184, 135, 62, 0.35);
}

.headcount-summary {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 0.75rem;
    margin-top: 1.1rem;
    padding-top: 1rem;
    border-top: 1px solid rgba(255, 255, 255, 0.08);
}
.headcount-summary__stat { display: flex; align-items: center; gap: 0.55rem; }
.headcount-summary__icon {
    width: 34px;
    height: 34px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(45, 212, 191, 0.14);
    color: #2dd4bf;
    flex-shrink: 0;
}
.headcount-summary__label { font-size: 0.7rem; color: #64748b; font-weight: 600; }
.headcount-summary__value { font-size: 1.05rem; font-weight: 800; color: #f8fafc; }

.class-roll { display: flex; flex-direction: column; gap: 0.6rem; }
.class-roll__row {
    display: flex;
    align-items: center;
    gap: 0.9rem;
    padding: 0.7rem 0.9rem;
    border-radius: 12px;
    background: #12181f;
    border: 1px solid rgba(255, 255, 255, 0.06);
    flex-wrap: wrap;
}
.class-roll__name { font-weight: 700; color: #f8fafc; font-size: 0.9rem; min-width: 130px; }
.class-roll__action { margin-left: auto; }

/* -- Quick Actions strip at the bottom of the page. */
.quick-actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 0.75rem;
}
.quick-action-btn {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 0.5rem;
    padding: 0.9rem 1rem;
    border-radius: 12px;
    background: #12181f;
    border: 1px solid rgba(255, 255, 255, 0.07);
    text-decoration: none;
    transition: border-color 0.12s ease, transform 0.12s ease;
}
.quick-action-btn:hover { transform: translateY(-2px); border-color: rgba(255, 255, 255, 0.18); }
.quick-action-btn__icon {
    width: 34px;
    height: 34px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1rem;
    background: var(--qa-accent-bg, rgba(184, 135, 62, 0.14));
    color: var(--qa-accent, #b8873e);
}
.quick-action-btn__title { font-weight: 700; color: #f8fafc; font-size: 0.86rem; }
.quick-action-btn__sub { color: #64748b; font-size: 0.74rem; margin-top: -0.3rem; }

@media (max-width: 575px) {
    .class-roll__name { min-width: 100%; }
    .class-roll__action { margin-left: 0; width: 100%; }
    .class-roll__action .btn { width: 100%; }
    .headcount-row { grid-template-columns: 1fr; row-gap: 0.35rem; }
    .headcount-row__count { text-align: left; }
    .headcount-row__action { width: 100%; }
    .headcount-row__action .btn { width: 100%; }
}
</style>

<div class="subjects-page">

<div class="portal-hero">
    <div class="portal-hero__avatar"><i class="bi bi-journal-bookmark"></i></div>
    <div class="portal-hero__body">
        <p class="portal-hero__name">My Subjects &amp; Classes</p>
        <div class="portal-hero__meta">Everything you teach, at a glance.</div>
    </div>
    <div class="portal-hero__right">
        <a class="btn btn-outline-secondary btn-sm align-self-center" href="<?= htmlspecialchars(base_url('/index.php?route=portal/index'), ENT_QUOTES, 'UTF-8') ?>">
            <i class="bi bi-arrow-left me-1"></i>Back to Portal
        </a>
    </div>
</div>

<div class="portal-kpis">
    <div class="portal-kpi portal-kpi--a">
        <div class="portal-kpi__icon"><i class="bi bi-journal-bookmark"></i></div>
        <div class="portal-kpi__label">Subjects Taught</div>
        <div class="portal-kpi__value"><?= count($subjectGroups) ?></div>
        <div class="portal-kpi__hint">Unique subjects</div>
    </div>
    <div class="portal-kpi portal-kpi--c">
        <div class="portal-kpi__icon"><i class="bi bi-diagram-3"></i></div>
        <div class="portal-kpi__label">Class Assignments</div>
        <div class="portal-kpi__value"><?= count($subjects) ?></div>
        <div class="portal-kpi__hint">Subject&ndash;class combinations</div>
    </div>
    <div class="portal-kpi portal-kpi--b">
        <div class="portal-kpi__icon"><i class="bi bi-people"></i></div>
        <div class="portal-kpi__label">Students Taught</div>
        <div class="portal-kpi__value"><?= (int)$totalStudents ?></div>
        <div class="portal-kpi__hint">Across <?= $classCount ?> class<?= $classCount === 1 ? '' : 'es' ?></div>
    </div>
    <div class="portal-kpi portal-kpi--d">
        <div class="portal-kpi__icon"><i class="bi bi-award"></i></div>
        <div class="portal-kpi__label">Class Teacher Of</div>
        <div class="portal-kpi__value"><?= $classTeacherCount ?></div>
        <div class="portal-kpi__hint">Class<?= $classTeacherCount === 1 ? '' : 'es' ?></div>
    </div>
</div>

<div class="subjects-layout">

    <div class="card shadow-sm border-0 portal-section mb-0">
        <div class="card-body">
            <div class="portal-section__head">
                <div class="portal-section__head-left">
                    <div class="portal-section__icon portal-section__icon--violet"><i class="bi bi-journal-bookmark"></i></div>
                    <div>
                        <p class="portal-section__title mb-0">Subjects I Teach</p>
                        <p class="portal-section__sub">Click a subject to see the classes.</p>
                    </div>
                </div>
                <?php if ($hasMoreSubjects): ?>
                    <button type="button" class="btn btn-outline-secondary btn-sm" id="subjectsToggleTop" onclick="toggleSubjectGrid()">
                        View All <i class="bi bi-chevron-down ms-1"></i>
                    </button>
                <?php endif; ?>
            </div>

            <?php if (empty($subjectGroups)): ?>
                <div class="portal-empty"><i class="bi bi-journal-bookmark"></i>No subjects assigned yet. Ask an admin.</div>
            <?php else: ?>
            <div class="subject-grid" id="subjectGrid">
                <?php $i = 0; foreach ($subjectGroups as $subjectName => $classNames): ?>
                    <?php
                    $accent = $accents[$i % count($accents)];
                    $isExtra = $i >= $subjectTileLimit;
                    $i++;
                    ?>
                    <div class="subject-tile<?= $isExtra ? ' subject-tile--extra' : '' ?>" style="--tile-accent: var(--sms-accent-<?= h($accent) ?>); --tile-accent-bg: rgba(255,255,255,0.06);">
                        <div class="subject-tile__icon"><i class="bi <?= h(subjectIcon($subjectName, $subjectIconMap)) ?>"></i></div>
                        <div class="subject-tile__name"><?= h($subjectName) ?></div>
                        <div class="subject-tile__count"><?= count($classNames) ?> class<?= count($classNames) === 1 ? '' : 'es' ?></div>
                        <div class="subject-tile__chips">
                            <?php foreach ($classNames as $cn): ?>
                                <span class="subject-chip"><?= h($cn) ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php if ($hasMoreSubjects): ?>
                <a href="#" class="subjects-view-all-link" id="subjectsToggleBottom" onclick="toggleSubjectGrid(); return false;">
                    View all subjects <i class="bi bi-chevron-down ms-1"></i>
                </a>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="card shadow-sm border-0 portal-section mb-0">
        <div class="card-body">
            <div class="portal-section__head">
                <div class="portal-section__head-left">
                    <div class="portal-section__icon portal-section__icon--teal"><i class="bi bi-people"></i></div>
                    <div>
                        <p class="portal-section__title mb-0">Class Headcounts</p>
                        <p class="portal-section__sub">Overview of students in your assigned classes.</p>
                    </div>
                </div>
                <?php if (!empty($classTeacherSectionIds)): ?>
                    <select class="headcount-filter" id="headcountFilter" onchange="filterHeadcounts()">
                        <option value="all">All Classes</option>
                        <option value="class_teacher">Class Teacher Only</option>
                    </select>
                <?php endif; ?>
            </div>

            <?php if (empty($classes)): ?>
                <div class="portal-empty"><i class="bi bi-people"></i>No classes yet.</div>
            <?php else: ?>
            <div class="headcount-list" id="headcountList">
                <?php $j = 0; foreach ($classes as $c): ?>
                    <?php
                    $isClassTeacher = in_array((int)($c['class_section_id'] ?? 0), $classTeacherSectionIds, true);
                    $count = (int)($c['student_count'] ?? 0);
                    $pct = $maxHeadcount > 0 ? max(4, (int)round(($count / $maxHeadcount) * 100)) : 0;
                    $barAccent = $accents[$j % count($accents)];
                    $j++;
                    ?>
                    <div class="headcount-row" data-class-teacher="<?= $isClassTeacher ? '1' : '0' ?>" data-count="<?= $count ?>">
                        <div class="headcount-row__name">
                            <?= h(trim(($c['class_name'] ?? '') . ' ' . ($c['section_name'] ?? ''))) ?>
                            <?php if ($isClassTeacher): ?>
                                <span class="class-teacher-badge"><i class="bi bi-star-fill"></i>Class Teacher</span>
                            <?php endif; ?>
                        </div>
                        <?php if ($isClassTeacher): ?>
                            <div class="headcount-row__action">
                                <a class="btn btn-sm btn-outline-primary" href="<?= h(route_url('portal/takeAttendance')) ?>&class_section_id=<?= (int)$c['class_section_id'] ?>">
                                    <i class="bi bi-calendar2-check me-1"></i>Take Attendance
                                </a>
                            </div>
                        <?php endif; ?>
                        <div class="headcount-row__track">
                            <div class="headcount-row__fill" style="width: <?= $pct ?>%; --bar-accent: var(--sms-accent-<?= h($barAccent) ?>);"></div>
                        </div>
                        <div class="headcount-row__count"><?= $count ?></div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="headcount-summary">
                <div class="headcount-summary__stat">
                    <div class="headcount-summary__icon"><i class="bi bi-people-fill"></i></div>
                    <div>
                        <div class="headcount-summary__label">Total Students</div>
                        <div class="headcount-summary__value" id="summaryTotal"><?= (int)$totalStudents ?></div>
                    </div>
                </div>
                <div class="headcount-summary__stat">
                    <div class="headcount-summary__icon"><i class="bi bi-graph-up"></i></div>
                    <div>
                        <div class="headcount-summary__label">Average per Class</div>
                        <div class="headcount-summary__value" id="summaryAvg"><?= (int)$avgPerClass ?></div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

</div>

<div class="card shadow-sm border-0 portal-section">
    <div class="card-body">
        <div class="portal-section__head">
            <div class="portal-section__head-left">
                <div class="portal-section__icon portal-section__icon--amber"><i class="bi bi-lightning-charge"></i></div>
                <p class="portal-section__title mb-0">Quick Actions</p>
            </div>
        </div>
        <div class="quick-actions-grid">
            <a class="quick-action-btn" href="<?= htmlspecialchars(base_url('/index.php?route=academic/marksEntry'), ENT_QUOTES, 'UTF-8') ?>" style="--qa-accent: #4ade80; --qa-accent-bg: rgba(74,222,128,0.14);">
                <div class="quick-action-btn__icon"><i class="bi bi-pencil-square"></i></div>
                <div class="quick-action-btn__title">Enter Marks</div>
                <div class="quick-action-btn__sub">Add exam or assignment marks</div>
            </a>
            <a class="quick-action-btn" href="<?= h(route_url('portal/myTimetable')) ?>" style="--qa-accent: #fbbf24; --qa-accent-bg: rgba(251,191,36,0.14);">
                <div class="quick-action-btn__icon"><i class="bi bi-calendar-week"></i></div>
                <div class="quick-action-btn__title">My Timetable</div>
                <div class="quick-action-btn__sub">View my teaching schedule</div>
            </a>
            <a class="quick-action-btn" href="<?= h(route_url('portal/myLeaves')) ?>" style="--qa-accent: #fb7185; --qa-accent-bg: rgba(251,113,133,0.14);">
                <div class="quick-action-btn__icon"><i class="bi bi-calendar-x"></i></div>
                <div class="quick-action-btn__title">My Leaves</div>
                <div class="quick-action-btn__sub">Apply or view leave history</div>
            </a>
        </div>
    </div>
</div>

<?php if (!empty($feeClasses)): ?>
<div class="card shadow-sm border-0 portal-section">
    <div class="card-body">
        <div class="portal-section__head">
            <div class="portal-section__head-left">
                <div class="portal-section__icon portal-section__icon--green"><i class="bi bi-cash-coin"></i></div>
                <p class="portal-section__title mb-0">My Fee Collection Classes</p>
            </div>
        </div>
        <div class="class-roll">
            <?php foreach ($feeClasses as $fc): ?>
                <div class="class-roll__row">
                    <div class="class-roll__name"><?= h(trim(($fc['class_name'] ?? '') . ' ' . ($fc['section_name'] ?? ''))) ?></div>
                    <div class="class-roll__action">
                        <a class="btn btn-sm btn-outline-primary" title="View students &amp; collect fees" href="<?= h(route_url('portal/feeClassStudents')) ?>&class_section_id=<?= (int)$fc['id'] ?>">
                            <i class="bi bi-eye me-1"></i>View
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

</div>

<script>
// Expand/collapse the subject tile grid beyond the first <?= $subjectTileLimit ?> tiles.
// Pure client-side toggle — the full list is already rendered in the page,
// this just shows/hides it, so no extra request is needed.
function toggleSubjectGrid() {
    var grid = document.getElementById('subjectGrid');
    if (!grid) { return; }
    var expanded = grid.classList.toggle('subject-grid--expanded');
    var label = expanded
        ? 'Show fewer <i class="bi bi-chevron-up ms-1"></i>'
        : 'View All <i class="bi bi-chevron-down ms-1"></i>';
    var bottomLabel = expanded
        ? 'Show fewer subjects <i class="bi bi-chevron-up ms-1"></i>'
        : 'View all subjects <i class="bi bi-chevron-down ms-1"></i>';
    var topBtn = document.getElementById('subjectsToggleTop');
    var bottomLink = document.getElementById('subjectsToggleBottom');
    if (topBtn) { topBtn.innerHTML = label; }
    if (bottomLink) { bottomLink.innerHTML = bottomLabel; }
}

// Filter the headcount list to "Class Teacher Only" and recompute the
// Total Students / Average per Class summary for whatever is visible.
function filterHeadcounts() {
    var select = document.getElementById('headcountFilter');
    var rows = document.querySelectorAll('#headcountList .headcount-row');
    var onlyClassTeacher = select && select.value === 'class_teacher';
    var total = 0;
    var visibleCount = 0;

    rows.forEach(function (row) {
        var isClassTeacher = row.getAttribute('data-class-teacher') === '1';
        var show = !onlyClassTeacher || isClassTeacher;
        row.hidden = !show;
        if (show) {
            total += parseInt(row.getAttribute('data-count'), 10) || 0;
            visibleCount++;
        }
    });

    var totalEl = document.getElementById('summaryTotal');
    var avgEl = document.getElementById('summaryAvg');
    if (totalEl) { totalEl.textContent = total; }
    if (avgEl) { avgEl.textContent = visibleCount > 0 ? Math.round(total / visibleCount) : 0; }
}
</script>