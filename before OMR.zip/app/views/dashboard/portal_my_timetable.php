<?php
// Variables: $timetable, $showClassColumn
$timetable = $timetable ?? [];
$showClassColumn = $showClassColumn ?? false;

$dayNames = [
    1 => 'Monday',
    2 => 'Tuesday',
    3 => 'Wednesday',
    4 => 'Thursday',
    5 => 'Friday',
    6 => 'Saturday',
    7 => 'Sunday',
];
$dayColors = [
    1 => '#2563eb',
    2 => '#7c3aed',
    3 => '#0891b2',
    4 => '#059669',
    5 => '#d97706',
    6 => '#dc2626',
    7 => '#64748b',
];

// Group the teacher's timetable by day, matching the structured Admin timetable.
$grouped = [];
foreach ($timetable as $t) {
    $d = (int)($t['day_of_week'] ?? 0);
    if ($d > 0) {
        $grouped[$d][] = $t;
    }
}
ksort($grouped);

// Days whose schedule is identical are shown once (e.g. "Monday – Thursday");
// a day only gets its own block when it differs from the others.
$sigs = [];
foreach ($grouped as $d => $rows) {
    $sig = [];
    foreach ($rows as $t) {
        $sig[] = [
            substr((string)($t['start_time'] ?? ''), 0, 5),
            substr((string)($t['end_time'] ?? ''), 0, 5),
            (string)($t['subject_name'] ?? ''),
            (string)($t['room'] ?? ''),
            trim(($t['class_name'] ?? '') . ' ' . ($t['section_name'] ?? '')),
        ];
    }
    $sigs[md5(json_encode($sig))][] = $d;
}
$blocks = [];
foreach ($sigs as $days) {
    $first = $days[0];
    $consecutive = (end($days) - $first === count($days) - 1);
    if (count($days) === 1) {
        $label = $dayNames[$first] ?? 'Day ' . $first;
    } elseif ($consecutive && count($days) > 2) {
        $label = ($dayNames[$first] ?? $first) . ' – ' . ($dayNames[end($days)] ?? end($days));
    } else {
        $label = implode(', ', array_map(static fn($x) => $dayNames[$x] ?? 'Day ' . $x, $days));
    }
    $blocks[] = ['label' => $label, 'color' => count($days) > 1 ? '#2563eb' : ($dayColors[$first] ?? '#64748b'), 'rows' => $grouped[$first]];
}
?>

<style>
.tt-day-header {
    padding: .5rem .9rem;
    font-weight: 600;
    font-size: .85rem;
    letter-spacing: .02em;
    color: #fff;
    border-radius: .4rem;
    display: inline-flex;
    align-items: center;
    gap: .4rem;
}
.tt-table thead th {
    font-size: .72rem;
    text-transform: uppercase;
    letter-spacing: .04em;
    color: #6b7280;
    border-bottom: 2px solid #e5e7eb;
    background: #f9fafb;
}
.tt-table td { vertical-align: middle; }
.tt-subject-pill {
    display: inline-block;
    padding: .25rem .6rem;
    border-radius: 999px;
    background: #eef2ff;
    color: #3730a3;
    font-weight: 600;
    font-size: .8rem;
}
.tt-time-pill {
    font-variant-numeric: tabular-nums;
    color: #374151;
    font-weight: 500;
}
.tt-room-badge {
    background: #f1f5f9;
    color: #475569;
    border-radius: .35rem;
    padding: .15rem .5rem;
    font-size: .78rem;
}
.tt-class-badge {
    background: #f8fafc;
    color: #334155;
    border: 1px solid #e2e8f0;
    border-radius: .35rem;
    padding: .2rem .5rem;
    font-size: .8rem;
    font-weight: 500;
}
.tt-day-block { margin-bottom: 1.1rem; }
.tt-day-block:last-child { margin-bottom: 0; }
</style>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">My Timetable</h1>
        <div class="text-muted">Your weekly teaching schedule.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=portal/index'), ENT_QUOTES, 'UTF-8') ?>">Back to Portal</a>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <?php if (empty($blocks)): ?>
            <div class="portal-empty"><i class="bi bi-calendar-week"></i>No timetable published yet.</div>
        <?php else: ?>
            <?php foreach ($blocks as $blk): $rows = $blk['rows']; ?>
                <div class="tt-day-block">
                    <div class="tt-day-header mb-2" style="background: <?= h($blk['color']) ?>;">
                        <?= h($blk['label']) ?>
                        <span class="opacity-75">· <?= count($rows) ?> <?= count($rows) === 1 ? 'period' : 'periods' ?></span>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-sm tt-table mb-0 align-middle">
                            <thead>
                            <tr>
                                <th>Time</th>
                                <?php if ($showClassColumn): ?><th>Class</th><?php endif; ?>
                                <th>Subject</th>
                                <th>Room</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($rows as $t): ?>
                                <tr>
                                    <td class="tt-time-pill">
                                        <?= h(substr((string)($t['start_time'] ?? ''), 0, 5)) ?>
                                        – <?= h(substr((string)($t['end_time'] ?? ''), 0, 5)) ?>
                                    </td>
                                    <?php if ($showClassColumn): ?>
                                        <td>
                                            <span class="tt-class-badge">
                                                <?= h(trim(($t['class_name'] ?? '') . ' ' . ($t['section_name'] ?? ''))) ?>
                                            </span>
                                        </td>
                                    <?php endif; ?>
                                    <td><span class="tt-subject-pill"><?= h($t['subject_name'] ?? '') ?></span></td>
                                    <td>
                                        <?= !empty($t['room'])
                                            ? '<span class="tt-room-badge">' . h($t['room']) . '</span>'
                                            : '<span class="text-muted">—</span>' ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>