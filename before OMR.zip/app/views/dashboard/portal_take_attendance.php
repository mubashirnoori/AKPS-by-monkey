<?php
// Variables: $error, $classSections, $classSectionId, $attendanceDate, $students
$classSections = $classSections ?? [];
$students = $students ?? [];
$hasStudents = !empty($students);

// Attendance has actually been saved for this date only once at least one
// student has a real (non-null) status from the database — a fresh/unsaved
// date has every student's attendance_status as null. Used to keep the
// counts summary hidden until a real save has happened for this date.
$savedCounts = ['present' => 0, 'absent' => 0, 'late' => 0, 'excused' => 0];
$hasSavedAttendance = false;
foreach ($students as $st) {
    if (($st['attendance_status'] ?? null) !== null) {
        $hasSavedAttendance = true;
        $s = (string)$st['attendance_status'];
        if (isset($savedCounts[$s])) {
            $savedCounts[$s]++;
        }
    }
}
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Take Attendance</h1>
        <div class="text-muted small">Only classes where you are the assigned Class Teacher are shown here.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= h(route_url('portal/index')) ?>">Back to Portal</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="row g-3 align-items-end">
            <input type="hidden" name="route" value="portal/takeAttendance">
            <div class="col-md-5">
                <label class="form-label fw-semibold">Class *</label>
                <select class="form-select" name="class_section_id" required>
                    <?php foreach ($classSections as $cs): ?>
                        <option value="<?= (int)$cs['id'] ?>" <?= ((int)$classSectionId === (int)$cs['id']) ? 'selected' : '' ?>>
                            <?= h(($cs['class_name'] ?? '') . ' — ' . ($cs['section_name'] ?? '')) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold">Date *</label>
                <input class="form-control" type="date" name="attendance_date" value="<?= h($attendanceDate) ?>" required>
            </div>
            <div class="col-md-3 d-grid">
                <button class="btn btn-primary" type="submit">Load Students</button>
            </div>
        </form>
    </div>
</div>

<?php if (empty($classSections)): ?>
    <div class="alert alert-warning">You are not currently assigned as a Class Teacher for any class. Ask Admin to assign you in Academic → Class Sections.</div>
<?php elseif (!$hasStudents): ?>
    <div class="alert alert-warning">No students found in this class section.</div>
<?php else: ?>

<form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=portal/takeAttendance'), ENT_QUOTES, 'UTF-8') ?>">
    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
    <input type="hidden" name="class_section_id" value="<?= (int)$classSectionId ?>">
    <input type="hidden" name="attendance_date" value="<?= h($attendanceDate) ?>">

    <div class="card shadow-sm border-0">
        <div class="card-header bg-white d-flex align-items-center justify-content-between py-2">
            <div>
                <span class="fw-semibold sms-header-text"><?= h($attendanceDate) ?></span>
            </div>
            <div class="d-flex gap-2 align-items-center">
                <span class="text-muted small"><?= count($students) ?> students</span>
                <button type="button" class="btn btn-sm btn-outline-success" onclick="markAll('present')">All Present</button>
                <button type="button" class="btn btn-sm btn-outline-danger" onclick="markAll('absent')">All Absent</button>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-sm table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th style="width:50px;">#</th>
                            <th>Student</th>
                            <th>Father's Name</th>
                            <th style="width:100px;">Adm. No</th>
                            <th class="text-center" style="width:110px;"><span class="text-success">Present</span></th>
                            <th class="text-center" style="width:110px;"><span class="text-danger">Absent</span></th>
                            <th class="text-center" style="width:110px;"><span class="text-warning">Late</span></th>
                            <th class="text-center" style="width:110px;"><span class="text-secondary">Excused</span></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $i = 1; foreach ($students as $st): ?>
                        <?php
                        $sid = (int)$st['id'];
                        $cur = (string)($st['attendance_status'] ?? 'present');
                        if ($st['attendance_status'] === null) $cur = 'present';
                        ?>
                        <tr id="row_<?= $sid ?>" class="<?= $cur === 'absent' ? 'table-danger' : ($cur === 'late' ? 'table-warning' : ($cur === 'excused' ? 'table-secondary' : '')) ?>">
                            <td class="text-muted small"><?= $i++ ?></td>
                            <td class="fw-semibold"><?= h(($st['first_name'] ?? '') . ' ' . ($st['last_name'] ?? '')) ?></td>
                            <td class="text-muted small"><?= h($st['father_name'] ?? '') ?: '—' ?></td>
                            <td class="text-muted small"><?= h($st['admission_no'] ?? '') ?></td>
                            <?php foreach (['present','absent','late','excused'] as $status): ?>
                            <td class="text-center">
                                <input class="form-check-input att-radio" type="radio" name="status[<?= $sid ?>]" value="<?= $status ?>"
                                       data-row="row_<?= $sid ?>" data-status="<?= $status ?>" <?= $cur === $status ? 'checked' : '' ?> onchange="highlightRow(this)">
                            </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div class="small">
                <?php if ($hasSavedAttendance): ?>
                    <span class="text-muted me-2">Saved for <?= h($attendanceDate) ?>:</span>
                    <span class="text-success me-3">✓ Present: <strong><?= $savedCounts['present'] ?></strong></span>
                    <span class="text-danger me-3">✗ Absent: <strong><?= $savedCounts['absent'] ?></strong></span>
                    <span class="text-warning me-3">⏱ Late: <strong><?= $savedCounts['late'] ?></strong></span>
                    <span class="text-secondary">Excused: <strong><?= $savedCounts['excused'] ?></strong></span>
                <?php endif; ?>
            </div>
            <button class="btn btn-primary px-4" type="button" id="btn_open_save_confirm">Save Attendance</button>
        </div>
    </div>
</form>

<!-- Confirm Save Modal: counts are only shown here, right before the attendance is actually saved -->
<div class="modal fade" id="attendanceSummaryModal" tabindex="-1" aria-labelledby="attendanceSummaryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="attendanceSummaryModalLabel">Confirm Attendance</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="text-muted small mb-3">Please review the counts below before saving.</p>
                <ul class="list-group" id="att_summary_list">
                    <!-- Populated by JS -->
                </ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary px-4" id="btn_confirm_save">OK</button>
            </div>
        </div>
    </div>
</div>

<script>
function highlightRow(radio) {
    var row = document.getElementById(radio.dataset.row);
    row.className = '';
    if (radio.dataset.status === 'absent')  row.className = 'table-danger';
    if (radio.dataset.status === 'late')    row.className = 'table-warning';
    if (radio.dataset.status === 'excused') row.className = 'table-secondary';
}

function markAll(status) {
    document.querySelectorAll('input[type=radio][value="' + status + '"]').forEach(function(r) {
        r.checked = true;
        highlightRow(r);
    });
}

function getCounts() {
    var counts = {present:0, absent:0, late:0, excused:0};
    document.querySelectorAll('.att-radio:checked').forEach(function(r) {
        counts[r.value] = (counts[r.value] || 0) + 1;
    });
    return counts;
}

function buildSummaryHtml(counts) {
    var rows = [
        {key:'present',  label:'Present',  icon:'✓', cls:'text-success'},
        {key:'absent',   label:'Absent',   icon:'✗', cls:'text-danger'},
        {key:'late',     label:'Late',     icon:'⏱', cls:'text-warning'},
        {key:'excused',  label:'Excused',  icon:'—', cls:'text-secondary'}
    ];
    return rows.map(function(row) {
        return '<li class="list-group-item d-flex justify-content-between align-items-center">' +
                   '<span class="' + row.cls + '"><span class="me-2">' + row.icon + '</span>' + row.label + '</span>' +
                   '<span class="badge ' + row.cls.replace('text-', 'bg-') + ' rounded-pill fs-6">' + counts[row.key] + '</span>' +
               '</li>';
    }).join('');
}

document.getElementById('btn_open_save_confirm').addEventListener('click', function() {
    var counts = getCounts();
    document.getElementById('att_summary_list').innerHTML = buildSummaryHtml(counts);
    var modal = new bootstrap.Modal(document.getElementById('attendanceSummaryModal'));
    modal.show();
});

document.getElementById('btn_confirm_save').addEventListener('click', function() {
    // Actually submit the form now that the user has confirmed the counts
    document.querySelector('form[action*="portal/takeAttendance"]').submit();
});
</script>

<?php endif; ?>
