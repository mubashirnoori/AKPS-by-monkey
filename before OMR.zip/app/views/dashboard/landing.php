<?php
// Variables: $user, $modules
$user    = $user ?? [];
$modules = $modules ?? [];
$settingsMap = [];
try {
    if (class_exists('Database')) {
        $rows = Database::fetchAll('SELECT `key`, `value` FROM settings');
        foreach ($rows as $r) { $settingsMap[$r['key']] = $r['value']; }
    }
} catch (Throwable $e) {}
$schoolName = $settingsMap['branding_school_name'] ?? $settingsMap['institute_name'] ?? 'School Management System';
$logoPath   = $settingsMap['branding_logo_path'] ?? '';
?>
<style>
.landing-hero {
    background: linear-gradient(135deg, #1e3a5f 0%, #2563eb 60%, #3b82f6 100%);
    border-radius: 20px;
    padding: 2.5rem 2rem;
    color: #fff;
    margin-bottom: 2rem;
    position: relative;
    overflow: hidden;
}
.landing-hero::before {
    content: '';
    position: absolute;
    top: -40px; right: -40px;
    width: 220px; height: 220px;
    border-radius: 50%;
    background: rgba(255,255,255,.07);
}
.landing-hero::after {
    content: '';
    position: absolute;
    bottom: -60px; left: -20px;
    width: 180px; height: 180px;
    border-radius: 50%;
    background: rgba(255,255,255,.05);
}
.landing-avatar {
    width: 56px; height: 56px;
    border-radius: 50%;
    background: rgba(255,255,255,.2);
    display: flex; align-items: center; justify-content: center;
    font-size: 1.5rem; font-weight: 700;
    border: 2px solid rgba(255,255,255,.4);
}
.module-card {
    border: none;
    border-radius: 16px;
    transition: transform .18s ease, box-shadow .18s ease;
    cursor: pointer;
    box-shadow: 0 2px 12px rgba(0,0,0,.07);
    overflow: hidden;
    text-decoration: none;
    color: inherit;
    display: block;
}
.module-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 28px rgba(0,0,0,.13);
    color: inherit;
}
.module-card .icon-wrap {
    width: 52px; height: 52px;
    border-radius: 14px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.4rem;
    margin-bottom: .75rem;
}
.module-card .card-body { padding: 1.4rem; }
.module-label { font-weight: 700; font-size: 1rem; }
.module-arrow { opacity: .4; font-size: .85rem; }
.no-modules { text-align: center; padding: 3rem 1rem; color: #6b7280; }
</style>

<!-- Hero -->
<div class="landing-hero">
    <div class="d-flex align-items-center gap-3 mb-3" style="position:relative;z-index:1;">
        <?php if ($logoPath): ?>
            <img src="<?= htmlspecialchars(base_url($logoPath), ENT_QUOTES, 'UTF-8') ?>" alt="Logo"
                 style="height:48px;width:auto;border-radius:10px;background:#fff;padding:4px;">
        <?php else: ?>
            <div class="landing-avatar"><?= strtoupper(substr((string)($user['username'] ?? 'U'), 0, 1)) ?></div>
        <?php endif; ?>
        <div>
            <div style="font-size:.85rem;opacity:.75;">Welcome back</div>
            <div style="font-size:1.4rem;font-weight:700;"><?= h($user['username'] ?? 'User') ?></div>
        </div>
        <div class="ms-auto text-end" style="font-size:.85rem;opacity:.7;">
            <div><?= h($user['role_name'] ?? '') ?></div>
            <div><?= date('l, d M Y') ?></div>
        </div>
    </div>
    <div style="position:relative;z-index:1;opacity:.85;font-size:.95rem;">
        <?= h($schoolName) ?> — School Management Portal
    </div>
</div>

<!-- Accessible Modules -->
<?php if (empty($modules)): ?>
    <div class="no-modules">
        <i class="bi bi-lock-fill" style="font-size:3rem;display:block;margin-bottom:1rem;opacity:.3;"></i>
        <div class="fw-semibold mb-1">No modules accessible</div>
        <div class="text-muted small">Your account has no module permissions assigned.<br>Please contact your administrator.</div>
    </div>
<?php else: ?>
    <div class="mb-3">
        <h5 class="fw-semibold mb-1">Your Modules</h5>
        <div class="text-muted small">Select a module to get started</div>
    </div>
    <div class="row g-3">
        <?php foreach ($modules as $mod): ?>
            <div class="col-6 col-md-4 col-lg-3">
                <a href="<?= htmlspecialchars(route_url($mod['route']), ENT_QUOTES, 'UTF-8') ?>" class="module-card card">
                    <div class="card-body">
                        <div class="icon-wrap" style="background:<?= h($mod['color']) ?>18;color:<?= h($mod['color']) ?>;">
                            <i class="<?= h($mod['icon']) ?>"></i>
                        </div>
                        <div class="module-label"><?= h($mod['label']) ?></div>
                        <div class="module-arrow mt-1"><i class="bi bi-arrow-right-short"></i> Open</div>
                    </div>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
