<?php
// Variables: $rows, $total, $page, $perPage, $filters, $canManage
$rows = $rows ?? [];
$filters = $filters ?? ['q' => '', 'status' => ''];
$totalPages = max(1, (int)ceil(($total ?? 0) / max(1, $perPage ?? 30)));

$statusBadge = static function (string $status): string {
    return match ($status) {
        'sent'    => 'bg-success',
        'failed'  => 'bg-danger',
        'sending' => 'bg-info text-dark',
        default   => 'bg-secondary',
    };
};
$colspan = !empty($canManage) ? 8 : 6;
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">SMS History</h1>
        <div class="text-muted">
            <?php if (!empty($canManage)): ?>
                Every SMS sent through the system — direct messages, class blasts, announcements, OTPs and fee reminders.
            <?php else: ?>
                SMS messages you've personally sent.
            <?php endif; ?>
        </div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= h(route_url('portal/sendSms')) ?>">
        <i class="bi bi-chat-dots me-1"></i>Send SMS
    </a>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="portal/smsHistory">
            <div class="col-md-6">
                <label class="form-label small fw-semibold">Search (number or message)</label>
                <input type="text" name="q" class="form-control" value="<?= h($filters['q']) ?>" placeholder="03xx xxxxxxx or message text">
            </div>
            <div class="col-md-4">
                <label class="form-label small fw-semibold">Status</label>
                <select name="status" class="form-select">
                    <option value="">All statuses</option>
                    <?php foreach (['pending', 'sending', 'sent', 'failed'] as $s): ?>
                        <option value="<?= h($s) ?>" <?= $filters['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <button class="btn btn-primary w-100" type="submit">Filter</button>
            </div>
        </form>
    </div>
</div>

<?php if (!empty($canManage)): ?>
    <form method="post" action="<?= h(route_url('portal/smsHistoryBulkDelete')) ?>" id="smsHistoryForm"
          onsubmit="return smsHistoryConfirmBulkDelete(event);">
        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">

        <div class="d-flex align-items-center justify-content-between mb-2 px-1" id="smsHistoryBulkBar">
            <div class="small text-muted"><span id="smsHistorySelectedCount">0</span> selected</div>
            <button type="submit" class="btn btn-sm btn-outline-danger" id="smsHistoryBulkDeleteBtn" disabled>
                <i class="bi bi-trash me-1"></i>Delete Selected
            </button>
        </div>
<?php else: ?>
    <?php // Non-managers get a plain table, no bulk form / checkboxes. ?>
<?php endif; ?>

<div class="card shadow-sm border-0">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <?php if (!empty($canManage)): ?>
                        <th style="width:2.5rem;">
                            <input type="checkbox" class="form-check-input" id="smsHistorySelectAll" aria-label="Select all">
                        </th>
                    <?php endif; ?>
                    <th>Sent</th>
                    <th>To</th>
                    <th>Message</th>
                    <th>Purpose</th>
                    <th>Sender</th>
                    <th>Status</th>
                    <?php if (!empty($canManage)): ?><th></th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="<?= $colspan ?>" class="text-center text-muted py-4">No messages found.</td></tr>
                <?php endif; ?>
                <?php foreach ($rows as $row): ?>
                    <tr>
                        <?php if (!empty($canManage)): ?>
                            <td>
                                <input type="checkbox" class="form-check-input sms-history-checkbox"
                                       name="ids[]" value="<?= (int)$row['id'] ?>" form="smsHistoryForm"
                                       aria-label="Select message">
                            </td>
                        <?php endif; ?>
                        <td class="small text-nowrap"><?= h($row['sent_at'] ?? $row['created_at']) ?></td>
                        <td class="small font-monospace"><?= h($row['to_number_masked']) ?></td>
                        <td class="small" style="max-width:320px;white-space:normal;"><?= h($row['message']) ?></td>
                        <td class="small text-muted"><?= h($row['purpose']) ?></td>
                        <td class="small"><?= h($row['sender_name'] ?? 'System') ?></td>
                        <td>
                            <span class="badge <?= $statusBadge((string)$row['status']) ?>"><?= h(ucfirst((string)$row['status'])) ?></span>
                            <?php if (!empty($row['last_error'])): ?>
                                <div class="small text-danger mt-1"><?= h($row['last_error']) ?></div>
                            <?php endif; ?>
                        </td>
                        <?php if (!empty($canManage)): ?>
                            <td class="text-end">
                                <button type="submit" form="smsHistoryForm" class="btn btn-sm btn-outline-danger" title="Delete"
                                        formaction="<?= h(route_url('portal/smsHistoryDelete') . '&id=' . (int)$row['id']) ?>"
                                        formnovalidate
                                        onclick="return confirm('Delete this SMS history entry? This can\'t be undone.');">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php if (!empty($canManage)): ?>
    </form>

    <script>
    (function () {
        var selectAll = document.getElementById('smsHistorySelectAll');
        var checkboxes = function () { return Array.prototype.slice.call(document.querySelectorAll('.sms-history-checkbox')); };
        var countEl = document.getElementById('smsHistorySelectedCount');
        var bulkBtn = document.getElementById('smsHistoryBulkDeleteBtn');

        function refresh() {
            var boxes = checkboxes();
            var checked = boxes.filter(function (b) { return b.checked; });
            countEl.textContent = checked.length;
            bulkBtn.disabled = checked.length === 0;
            if (selectAll) {
                selectAll.checked = boxes.length > 0 && checked.length === boxes.length;
                selectAll.indeterminate = checked.length > 0 && checked.length < boxes.length;
            }
        }

        if (selectAll) {
            selectAll.addEventListener('change', function () {
                checkboxes().forEach(function (b) { b.checked = selectAll.checked; });
                refresh();
            });
        }
        checkboxes().forEach(function (b) { b.addEventListener('change', refresh); });
        refresh();

        window.smsHistoryConfirmBulkDelete = function (e) {
            // The per-row delete buttons submit this same form via
            // formaction, so only intercept when it's the bulk button.
            if (e.submitter && e.submitter.id !== 'smsHistoryBulkDeleteBtn') {
                return true;
            }
            var n = checkboxes().filter(function (b) { return b.checked; }).length;
            if (n === 0) {
                return false;
            }
            return confirm('Delete ' + n + ' selected SMS history ' + (n === 1 ? 'entry' : 'entries') + '? This can\'t be undone.');
        };
    })();
    </script>
<?php endif; ?>

<?php if ($totalPages > 1): ?>
    <nav class="mt-3">
        <ul class="pagination pagination-sm">
            <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                <li class="page-item <?= $p === (int)$page ? 'active' : '' ?>">
                    <a class="page-link" href="<?= h(route_url('portal/smsHistory')) ?>&page=<?= $p ?>&q=<?= urlencode($filters['q']) ?>&status=<?= urlencode($filters['status']) ?>"><?= $p ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
<?php endif; ?>