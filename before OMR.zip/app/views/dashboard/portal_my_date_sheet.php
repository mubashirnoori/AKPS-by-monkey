<?php
// Variables: $student, $sheets (each: exam, rows[subject_name, scheduled_date, start_time, end_time])
$sheets = $sheets ?? [];
$student = $student ?? [];
$fmtDate = function ($d) {
    $ts = $d ? strtotime((string)$d) : false;
    return $ts === false ? '—' : date('l, j M Y', $ts);
};
$fmtTime = function ($a, $b) {
    if (empty($a)) {
        return '—';
    }
    return substr((string)$a, 0, 5) . (!empty($b) ? ' – ' . substr((string)$b, 0, 5) : '');
};
$name = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
?>
<div class="mb-3">
    <h1 class="h4 mb-0">Date Sheet</h1>
    <div class="text-muted"><?= h($name) ?><?= !empty($student['roll_number']) ? ' · Roll No ' . h($student['roll_number']) : '' ?></div>
</div>

<?php if (!empty($loadError)): ?>
    <div class="alert alert-warning">The date sheet could not be loaded right now. Please try again later.</div>
<?php elseif (!$sheets): ?>
    <div class="alert alert-light border text-muted">No date sheet has been published for your class yet.</div>
<?php endif; ?>

<?php foreach ($sheets as $sh): $ex = $sh['exam'] ?? []; ?>
<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <h2 class="h6 mb-3">
            <?= h($ex['exam_name'] ?? '') ?>
            <?php if (!empty($ex['academic_year_label'])): ?><span class="text-muted fw-normal"> · <?= h($ex['academic_year_label']) ?></span><?php endif; ?>
        </h2>
        <div class="table-responsive">
            <table class="table table-sm align-middle mb-0">
                <thead><tr><th>Subject</th><th>Date</th><th>Time</th></tr></thead>
                <tbody>
                <?php foreach ($sh['rows'] as $r): ?>
                    <tr>
                        <td class="fw-semibold"><?= h($r['subject_name']) ?></td>
                        <td><?= h($fmtDate($r['scheduled_date'])) ?></td>
                        <td><?= h($fmtTime($r['start_time'], $r['end_time'])) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endforeach; ?>
