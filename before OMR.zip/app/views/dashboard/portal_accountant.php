<?php
// Variables: $today, $month, $pendingTotal, $recent, $topPending
$recent = $recent ?? [];
$topPending = $topPending ?? [];
?>

<div class="portal-hero">
    <div class="portal-hero__avatar"><i class="bi bi-cash-coin"></i></div>
    <div class="portal-hero__body">
        <p class="portal-hero__name">Accounts Portal</p>
        <div class="portal-hero__meta">Fee collection and dues only. Payroll, HR, and settings are managed by Admin.</div>
    </div>
    <div class="portal-hero__right">
        <a class="btn btn-primary btn-sm align-self-center" href="<?= htmlspecialchars(base_url('/index.php?route=fees/index'), ENT_QUOTES, 'UTF-8') ?>">Go to Fees Module <i class="bi bi-arrow-right"></i></a>
    </div>
</div>

<div class="portal-kpis">
    <div class="portal-kpi portal-kpi--b">
        <div class="portal-kpi__label"><i class="bi bi-wallet2"></i> Collected Today</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$today, 0) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--c">
        <div class="portal-kpi__label"><i class="bi bi-calendar3"></i> Collected This Month</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$month, 0) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--e">
        <div class="portal-kpi__label"><i class="bi bi-exclamation-triangle"></i> Total Pending Dues</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$pendingTotal, 0) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--a">
        <div class="portal-kpi__label"><i class="bi bi-clock-history"></i> Recent Collections</div>
        <div class="portal-kpi__value"><?= count($recent) ?></div>
        <div class="portal-kpi__hint">logged recently</div>
    </div>
    <div class="portal-kpi portal-kpi--f">
        <div class="portal-kpi__label"><i class="bi bi-people"></i> Students With Dues</div>
        <div class="portal-kpi__value"><?= count($topPending) ?>+</div>
        <div class="portal-kpi__hint">top pending list</div>
    </div>
</div>

<h2 class="h6 text-muted text-uppercase mb-2" style="letter-spacing:.04em;">Quick Access</h2>
<div class="portal-quicklinks">
    <a class="portal-quicklink" href="<?= htmlspecialchars(base_url('/index.php?route=fees/collect'), ENT_QUOTES, 'UTF-8') ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--green"><i class="bi bi-wallet2"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">Cash Collection</p>
            <p class="portal-quicklink__hint">Collect fees now</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= htmlspecialchars(base_url('/index.php?route=fees/invoices'), ENT_QUOTES, 'UTF-8') ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--blue"><i class="bi bi-receipt-cutoff"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">Invoices</p>
            <p class="portal-quicklink__hint">All invoices &amp; receipts</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= htmlspecialchars(base_url('/index.php?route=fees/pendingDues'), ENT_QUOTES, 'UTF-8') ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--rose"><i class="bi bi-exclamation-circle"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">Pending Dues</p>
            <p class="portal-quicklink__hint">Follow up on unpaid fees</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
</div>
