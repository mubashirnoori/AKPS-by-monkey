<?php
// Variables: $roleLabel
$roleLabel = $roleLabel ?? 'user';
?>

<div class="portal-hero">
    <div class="portal-hero__avatar"><i class="bi bi-link-45deg"></i></div>
    <div class="portal-hero__body">
        <p class="portal-hero__name">Account Not Linked Yet</p>
        <div class="portal-hero__meta"><?= h($roleLabel) ?> role</div>
    </div>
</div>

<div class="card shadow-sm border-0 portal-section">
    <div class="card-body text-center py-5">
        <i class="bi bi-link-45deg" style="font-size:2.5rem;opacity:.6;"></i>
        <h1 class="h5 mt-3">Your account isn't linked yet</h1>
        <p class="text-muted">
            Your login has the <strong><?= h($roleLabel) ?></strong> role, but it isn't linked to a
            <?= h(strtolower($roleLabel)) ?> record yet, so there's no data to show.
            Please ask your school admin to link your user account under
            <strong>Users &amp; Roles</strong>.
        </p>
    </div>
</div>
