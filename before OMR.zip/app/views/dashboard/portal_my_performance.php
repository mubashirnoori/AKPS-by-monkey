<?php
// Variables: $performance
$performance = $performance ?? [];
?>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">My Performance Reports</h1>
        <div class="text-muted">Reviews and ratings recorded by the school.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=portal/index'), ENT_QUOTES, 'UTF-8') ?>">Back to Portal</a>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <?php if (empty($performance)): ?>
            <div class="portal-empty"><i class="bi bi-star"></i>No performance reports yet.</div>
        <?php else: ?>
            <?php foreach ($performance as $p): ?>
                <div class="portal-resource-card">
                    <div class="d-flex justify-content-between">
                        <span class="fw-semibold"><?= h($p['period_start'] ?? '') ?> – <?= h($p['period_end'] ?? '') ?></span>
                        <span class="badge text-bg-info">Rating: <?= h($p['rating'] ?? '—') ?></span>
                    </div>
                    <?php if (!empty($p['summary'])): ?>
                        <div class="text-muted small mt-1"><?= h($p['summary']) ?></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
