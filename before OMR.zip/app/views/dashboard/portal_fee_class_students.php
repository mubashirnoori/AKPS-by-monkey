<?php
// Variables: $classSection, $invoices, $total, $page, $perPage, $classSectionId, $status, $month, $search
$classSection = $classSection ?? [];
$invoices = $invoices ?? [];
$total = (int)($total ?? 0);
$page = max(1, (int)($page ?? 1));
$perPage = (int)($perPage ?? 25);
$classSectionId = (int)($classSectionId ?? 0);
$status = (string)($status ?? '');
$month = (int)($month ?? 0);
$search = (string)($search ?? '');
$totalPages = max(1, (int)ceil($total / max(1, $perPage)));
$className = trim(($classSection['class_name'] ?? '') . ' — ' . ($classSection['section_name'] ?? ''));
$routeBase = base_url('/index.php?route=portal/feeClassStudents') . '&class_section_id=' . $classSectionId;

$pfcMonthNames = [
    1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June',
    7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December',
];

// The exact URL for this page in its current filtered/paginated state —
// carried as &return= on every View/Print/Collect Payment link below so
// coming back from any of them (including after actually recording a
// payment) lands right back here instead of resetting to page 1/All/blank.
$currentListUrl = $routeBase
    . '&status=' . rawurlencode($status)
    . '&month=' . $month
    . '&search=' . rawurlencode($search)
    . '&per_page=' . $perPage
    . '&page=' . $page;
$returnParam = '&return=' . rawurlencode($currentListUrl);
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Fee Collection — <?= h($className) ?></h1>
        <div class="text-muted small">Collect, view and print fee invoices for students in this class.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= h(route_url('portal/index')) ?>">Back to Portal</a>
</div>

<style>
.pfc-actions { display: flex; flex-direction: column; gap: 6px; }
.pfc-actions-row { display: flex; gap: 6px; }
.pfc-icon-btn { display: inline-flex; align-items: center; justify-content: center; width: 34px; padding: 0; }
.pfc-icon-btn i { font-size: 1rem; }
</style>

<div class="d-flex align-items-center justify-content-between mb-2 flex-wrap gap-2">
    <div class="text-muted small">
        Showing <?= count($invoices) ?> of <?= $total ?> invoice(s)
        <?php if ($total > 0 && $status === '' && $month === 0 && $search === ''): ?> — every invoice for this class, not just the latest per student<?php endif; ?>
    </div>
    <form method="get" class="d-flex align-items-center gap-2 flex-wrap">
        <input type="hidden" name="route" value="portal/feeClassStudents">
        <input type="hidden" name="class_section_id" value="<?= $classSectionId ?>">
        <label class="text-muted small mb-0">Status</label>
        <select name="status" class="form-select form-select-sm" style="width:auto;" onchange="this.form.submit()">
            <option value="" <?= $status === '' ? 'selected' : '' ?>>All</option>
            <option value="open" <?= $status === 'open' ? 'selected' : '' ?>>Unpaid (Open)</option>
            <option value="paid" <?= $status === 'paid' ? 'selected' : '' ?>>Paid</option>
            <option value="cancelled" <?= $status === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
        </select>
        <label class="text-muted small mb-0">Month</label>
        <select name="month" class="form-select form-select-sm" style="width:auto;" onchange="this.form.submit()">
            <option value="0" <?= $month === 0 ? 'selected' : '' ?>>All</option>
            <?php foreach ($pfcMonthNames as $num => $label): ?>
                <option value="<?= $num ?>" <?= $month === $num ? 'selected' : '' ?>><?= h($label) ?></option>
            <?php endforeach; ?>
        </select>
        <label class="text-muted small mb-0">Search</label>
        <input type="text" name="search" class="form-control form-control-sm" style="width:180px;"
               placeholder="Name, adm. no, roll no…" value="<?= h($search) ?>">
        <label class="text-muted small mb-0">Per page</label>
        <select name="per_page" class="form-select form-select-sm" style="width:auto;" onchange="this.form.submit()">
            <?php foreach ([25, 50, 100] as $opt): ?>
                <option value="<?= $opt ?>" <?= $perPage === $opt ? 'selected' : '' ?>><?= $opt ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="btn btn-sm btn-primary">Filter</button>
        <?php if ($status !== '' || $month !== 0 || $search !== ''): ?>
            <a class="btn btn-sm btn-outline-secondary" href="<?= h($routeBase . '&per_page=' . $perPage) ?>">Clear</a>
        <?php endif; ?>
    </form>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Student</th>
                        <th>Father's Name</th>
                        <th>Adm. No</th>
                        <th>Roll No</th>
                        <th>Invoice</th>
                        <th>Month</th>
                        <th class="text-end">Total Invoiced</th>
                        <th class="text-end">Collected</th>
                        <th class="text-end">Pending</th>
                        <th style="width:120px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($invoices)): ?>
                    <tr><td colspan="10" class="text-muted text-center py-3">No invoices found for this class.</td></tr>
                <?php else: ?>
                    <?php foreach ($invoices as $inv):
                        $rowStatus = (string)($inv['status'] ?? '');
                        $totalDue = (float)($inv['total_due'] ?? 0);
                        $collected = (float)($inv['collected_amount'] ?? 0);
                        $pending = max(0.0, $totalDue - $collected);
                    ?>
                        <tr>
                            <td class="fw-semibold"><?= h(($inv['first_name'] ?? '') . ' ' . ($inv['last_name'] ?? '')) ?></td>
                            <td class="text-muted small"><?= h($inv['father_name'] ?? '') ?: '—' ?></td>
                            <td class="text-muted small"><?= h($inv['admission_no'] ?? '') ?></td>
                            <td class="text-muted small"><?= h($inv['roll_number'] ?? '—') ?></td>
                            <td class="small">
                                <?= h($inv['invoice_no'] ?? '') ?>
                                <span class="badge <?= $rowStatus === 'paid' ? 'text-bg-success' : ($rowStatus === 'cancelled' ? 'text-bg-secondary' : 'text-bg-warning') ?> ms-1"><?= h(ucfirst($rowStatus)) ?></span>
                            </td>
                            <td class="text-muted small"><?= h(FeeInvoiceModel::formatBillingMonths($inv['billing_months_raw'] ?? null)) ?></td>
                            <td class="text-end">Rs <?= number_format($totalDue, 2) ?></td>
                            <td class="text-end text-success">Rs <?= number_format($collected, 2) ?></td>
                            <td class="text-end <?= $pending > 0 ? 'text-danger fw-semibold' : 'text-success' ?>">
                                Rs <?= number_format($pending, 2) ?>
                            </td>
                            <td>
                                <div class="pfc-actions">
                                    <div class="pfc-actions-row">
                                        <a class="btn btn-sm btn-outline-secondary pfc-icon-btn" href="<?= h(route_url('portal/invoiceView')) ?>&invoice_id=<?= (int)$inv['id'] ?><?= h($returnParam) ?>"
                                           title="View">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        <a class="btn btn-sm btn-outline-primary pfc-icon-btn" href="<?= h(route_url('portal/feeInvoicePrint')) ?>&invoice_id=<?= (int)$inv['id'] ?>" target="_blank"
                                           title="Print">
                                            <i class="bi bi-printer"></i>
                                        </a>
                                    </div>
                                    <?php if ($rowStatus !== 'paid' && $rowStatus !== 'cancelled'): ?>
                                        <a class="btn btn-sm btn-success" href="#" data-collect-invoice-id="<?= (int)$inv['id'] ?>" data-collect-endpoint="portal" title="Opens without leaving this page">Collect Payment</a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if ($totalPages > 1): ?>
<nav class="mt-3">
    <ul class="pagination justify-content-center flex-wrap">
        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <?php $url = $routeBase . '&per_page=' . $perPage . '&status=' . rawurlencode($status) . '&month=' . $month . '&search=' . rawurlencode($search) . '&page=' . $p; ?>
            <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                <a class="page-link" href="<?= h($url) ?>"><?= (int)$p ?></a>
            </li>
        <?php endfor; ?>
    </ul>
</nav>
<?php endif; ?>