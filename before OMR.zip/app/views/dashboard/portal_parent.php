<?php
// Variables: $children, $selectedId, $profile, $attendance, $results, $pendingResultsCount, $invoices, $courses
$children = $children ?? [];
$results = $results ?? [];
$pendingResultsCount = $pendingResultsCount ?? 0;
$invoices = $invoices ?? [];
$courses = $courses ?? [];

$selectedChild = null;
foreach ($children as $c) {
    if ((int)$c['id'] === (int)$selectedId) { $selectedChild = $c; break; }
}
$fullName = $selectedChild ? trim(($selectedChild['first_name'] ?? '') . ' ' . ($selectedChild['last_name'] ?? '')) : '';
$initials = '';
if ($selectedChild) {
    foreach ([$selectedChild['first_name'] ?? '', $selectedChild['last_name'] ?? ''] as $part) {
        if ($part !== '') { $initials .= strtoupper($part[0]); }
    }
}

$pendingFeeTotal = 0.0;
foreach ($invoices as $inv) {
    $pendingFeeTotal += max((float)($inv['total_due'] ?? 0) - (float)($inv['collected_amount'] ?? 0), 0);
}
?>

<div class="portal-hero">
    <div class="portal-hero__avatar"><?= h($initials ?: 'PT') ?></div>
    <div class="portal-hero__body">
        <p class="portal-hero__name"><?= $selectedChild ? h($fullName) : 'My Children' ?></p>
        <div class="portal-hero__meta">
            <?php if ($selectedChild): ?>
                <?= h(trim(($selectedChild['class_name'] ?? '') . ' ' . ($selectedChild['section_name'] ?? ''))) ?>
                &middot; Admission #<?= h($selectedChild['admission_no'] ?? '') ?>
            <?php else: ?>
                You can only see the students linked to your account.
            <?php endif; ?>
        </div>
    </div>
    <div class="portal-hero__right">
        <span class="badge text-bg-info align-self-center"><i class="bi bi-people-fill me-1"></i>Parent Portal</span>
    </div>
</div>

<?php if (empty($children)): ?>
    <div class="alert alert-info"><i class="bi bi-info-circle me-1"></i>No children are linked to your account yet. Please contact the school office.</div>
<?php else: ?>

<?php if (count($children) > 1): ?>
<ul class="nav portal-nav-pills mb-3">
    <?php foreach ($children as $c): ?>
        <li class="nav-item">
            <a class="nav-link <?= (int)$c['id'] === (int)$selectedId ? 'active' : '' ?>"
               href="<?= htmlspecialchars(base_url('/index.php?route=portal/index&student_id=' . (int)$c['id']), ENT_QUOTES, 'UTF-8') ?>">
                <?= h(trim(($c['first_name'] ?? '') . ' ' . ($c['last_name'] ?? ''))) ?>
                <span class="text-muted small">(<?= h(($c['class_name'] ?? '') . ' ' . ($c['section_name'] ?? '')) ?>)</span>
            </a>
        </li>
    <?php endforeach; ?>
</ul>
<?php endif; ?>

<?php if ($profile): ?>

    <?php if ($pendingResultsCount > 0): ?>
        <div class="alert alert-info d-flex align-items-center gap-2 mb-3">
            <i class="bi bi-hourglass-split fs-5"></i>
            <div>
                <?= $pendingResultsCount ?> exam<?= $pendingResultsCount > 1 ? 's' : '' ?> awaiting official result announcement for <?= h($fullName) ?>.
            </div>
        </div>
    <?php endif; ?>

    <div class="portal-kpis">
        <div class="portal-kpi portal-kpi--c">
            <div class="portal-kpi__label"><i class="bi bi-calendar-check"></i> Attendance (30 days)</div>
            <div class="portal-kpi__value"><?= $attendance['percentage'] !== null ? h($attendance['percentage']) . '%' : '—' ?></div>
        </div>
        <div class="portal-kpi portal-kpi--d">
            <div class="portal-kpi__label"><i class="bi bi-cash-coin"></i> Pending Fees</div>
            <div class="portal-kpi__value">Rs <?= number_format($pendingFeeTotal, 0) ?></div>
        </div>
        <div class="portal-kpi portal-kpi--a">
            <div class="portal-kpi__label"><i class="bi bi-clipboard-data"></i> Published Results</div>
            <div class="portal-kpi__value"><?= count($results) ?></div>
        </div>
        <div class="portal-kpi portal-kpi--f">
            <div class="portal-kpi__label"><i class="bi bi-play-btn"></i> Online Courses</div>
            <div class="portal-kpi__value"><?= count($courses) ?></div>
        </div>
    </div>

    <h2 class="h6 text-muted text-uppercase mb-2" style="letter-spacing:.04em;">Quick Access</h2>
    <div class="portal-quicklinks">
        <a class="portal-quicklink" href="<?= h(route_url('portal/myResults') . '&student_id=' . (int)$selectedId) ?>">
            <div class="portal-quicklink__icon portal-quicklink__icon--violet"><i class="bi bi-clipboard-data"></i></div>
            <div class="portal-quicklink__body">
                <p class="portal-quicklink__title">Results</p>
                <p class="portal-quicklink__hint">Announced exam scores</p>
            </div>
            <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
        </a>
        <a class="portal-quicklink" href="<?= h(route_url('portal/myReportCard') . '&student_id=' . (int)$selectedId) ?>">
            <div class="portal-quicklink__icon portal-quicklink__icon--violet"><i class="bi bi-file-earmark-text"></i></div>
            <div class="portal-quicklink__body">
                <p class="portal-quicklink__title">Report Card</p>
                <p class="portal-quicklink__hint">Printable official report card</p>
            </div>
            <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
        </a>
        <a class="portal-quicklink" href="<?= h(route_url('portal/myFees') . '&student_id=' . (int)$selectedId) ?>">
            <div class="portal-quicklink__icon portal-quicklink__icon--green"><i class="bi bi-receipt"></i></div>
            <div class="portal-quicklink__body">
                <p class="portal-quicklink__title">Fee Invoices</p>
                <p class="portal-quicklink__hint">Invoices &amp; payments</p>
            </div>
            <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
        </a>
        <a class="portal-quicklink" href="<?= h(route_url('portal/myCourses') . '&student_id=' . (int)$selectedId) ?>">
            <div class="portal-quicklink__icon portal-quicklink__icon--rose"><i class="bi bi-play-btn"></i></div>
            <div class="portal-quicklink__body">
                <p class="portal-quicklink__title">Online Courses</p>
                <p class="portal-quicklink__hint">Course library &amp; progress</p>
            </div>
            <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
        </a>
    </div>
<?php endif; ?>
<?php endif; ?>
