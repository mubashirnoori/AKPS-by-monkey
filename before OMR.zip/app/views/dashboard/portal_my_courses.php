<?php
// Variables: $courses, $studentId, $isParentView
$courses = $courses ?? [];
$studentId = (int)($studentId ?? 0);
$isParentView = $isParentView ?? false;
?>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">My Online Courses</h1>
        <div class="text-muted">Courses assigned to you, with progress tracking.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=portal/index'), ENT_QUOTES, 'UTF-8') ?>">Back to Portal</a>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <?php if (empty($courses)): ?>
            <div class="portal-empty"><i class="bi bi-play-btn"></i>No courses assigned yet.</div>
        <?php else: ?>
            <div class="portal-course-grid">
                <?php foreach ($courses as $c):
                    $resources = $c['resources'] ?? [];
                    $itemCount = count($resources);
                    $trackedTotal = 0;
                    $trackedDone = 0;
                    foreach ($resources as $r) {
                        if (($r['resource_type'] ?? '') === 'video' && ($r['source_type'] ?? 'link') === 'upload') {
                            $trackedTotal++;
                            if ((float)($r['my_progress_percent'] ?? 0) >= 95) { $trackedDone++; }
                        }
                    }
                    $courseHref = route_url('portal/course') . '&course_id=' . (int)$c['id'];
                    if ($isParentView) { $courseHref .= '&student_id=' . $studentId; }
                ?>
                    <div class="portal-course-card">
                        <div class="portal-course-card__icon"><i class="bi bi-play-btn"></i></div>
                        <p class="portal-course-card__title"><?= h($c['title'] ?? '') ?></p>
                        <div class="portal-course-card__desc"><?= h($c['description'] ?? ($itemCount . ' item' . ($itemCount === 1 ? '' : 's'))) ?></div>
                        <?php if ($trackedTotal > 0): ?>
                            <div class="progress" style="height:5px;">
                                <div class="progress-bar" style="width: <?= round(($trackedDone / $trackedTotal) * 100) ?>%;"></div>
                            </div>
                        <?php endif; ?>
                        <div class="portal-course-card__meta">
                            <span><i class="bi bi-collection-play me-1"></i><?= $itemCount ?> item<?= $itemCount === 1 ? '' : 's' ?></span>
                            <a class="portal-course-card__view" href="<?= h($courseHref) ?>" title="View course">
                                <i class="bi bi-eye"></i> View
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
