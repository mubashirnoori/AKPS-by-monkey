<?php
// Variables: $leaveRequests, $isTeacher
$leaveRequests = $leaveRequests ?? [];
$isTeacher = $isTeacher ?? false;
?>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">My Leaves</h1>
        <div class="text-muted">Apply for leave and track the status of past requests.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=portal/index'), ENT_QUOTES, 'UTF-8') ?>">Back to Portal</a>
</div>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0 portal-section">
            <div class="card-body">
                <div class="portal-section__head">
                    <div class="portal-section__icon portal-section__icon--amber"><i class="bi bi-calendar-x"></i></div>
                    <p class="portal-section__title mb-0">Apply for Leave</p>
                </div>
                <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=portal/leaveApply'), ENT_QUOTES, 'UTF-8') ?>" class="row g-2">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <div class="col-6">
                        <label class="form-label small">From</label>
                        <input class="form-control form-control-sm" type="date" name="from_date" required>
                    </div>
                    <div class="col-6">
                        <label class="form-label small">To</label>
                        <input class="form-control form-control-sm" type="date" name="to_date" required>
                    </div>
                    <div class="col-8">
                        <label class="form-label small"><?= $isTeacher ? 'Leave Type' : 'Reason' ?></label>
                        <input class="form-control form-control-sm" name="leave_type" placeholder="<?= $isTeacher ? 'e.g. Sick Leave, Casual Leave…' : 'e.g. Sick, Family event…' ?>">
                    </div>
                    <div class="col-4 d-flex align-items-end">
                        <button class="btn btn-primary btn-sm w-100" type="submit">Submit</button>
                    </div>
                    <div class="col-12">
                        <textarea class="form-control form-control-sm" name="note" rows="2" placeholder="Optional note"></textarea>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card shadow-sm border-0 portal-section">
            <div class="card-body">
                <div class="portal-section__head">
                    <div class="portal-section__icon portal-section__icon--rose"><i class="bi bi-clock-history"></i></div>
                    <p class="portal-section__title mb-0">Leave History</p>
                </div>
                <?php if (empty($leaveRequests)): ?>
                    <div class="portal-empty"><i class="bi bi-calendar-x"></i>No leave requests yet.</div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-sm table-hover mb-0">
                        <thead><tr><th>Type</th><th>From</th><th>To</th><th>Status</th></tr></thead>
                        <tbody>
                        <?php foreach ($leaveRequests as $lr): ?>
                            <tr>
                                <td><?= h($lr['leave_type'] ?? '') ?></td>
                                <td><?= h($lr['from_date'] ?? '') ?></td>
                                <td><?= h($lr['to_date'] ?? '') ?></td>
                                <td><span class="badge text-bg-<?= ($lr['status'] ?? '') === 'approved' ? 'success' : (($lr['status'] ?? '') === 'rejected' ? 'danger' : 'warning') ?>"><?= h(ucfirst($lr['status'] ?? '')) ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
