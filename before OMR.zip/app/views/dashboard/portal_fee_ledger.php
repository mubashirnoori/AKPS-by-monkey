<?php
// Variables: $ledger, $handovers, $recipients, $collectionSummary
$ledger = $ledger ?? ['collected' => 0, 'handed_over' => 0, 'pending_handover' => 0, 'net_balance' => 0];
$handovers = $handovers ?? [];
$recipients = $recipients ?? [];
$collectionSummary = $collectionSummary ?? ['to_collect' => 0, 'collected' => 0, 'pending' => 0, 'student_count' => 0];
$outstanding = (float)$ledger['net_balance'] - (float)$ledger['pending_handover'];
if ($outstanding < 0) { $outstanding = 0.0; }
$onBehalfCollections = $onBehalfCollections ?? [];
$onBehalfTotal = (int)($onBehalfTotal ?? count($onBehalfCollections));
$onBehalfPage = max(1, (int)($onBehalfPage ?? 1));
$onBehalfPerPage = (int)($onBehalfPerPage ?? 20);
$onBehalfTotalPages = max(1, (int)($onBehalfTotalPages ?? 1));
$onBehalfRouteBase = base_url('/index.php?route=portal/myFeeLedger');

$statusBadge = static function (string $status): string {
    $map = [
        'pending'   => 'bg-warning text-dark',
        'confirmed' => 'bg-success',
        'rejected'  => 'bg-danger',
    ];
    return $map[$status] ?? 'bg-secondary';
};
?>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">My Fee Ledger</h1>
        <div class="text-muted">What you've collected, what you've handed over, and your current balance.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=portal/index'), ENT_QUOTES, 'UTF-8') ?>">Back to Portal</a>
</div>

<?php if ((int)$collectionSummary['student_count'] > 0 || (float)$collectionSummary['to_collect'] > 0): ?>
<div class="mb-2">
    <div class="text-muted small fw-semibold text-uppercase">Fee Collection Progress — Your Assigned Classes</div>
</div>
<div class="portal-kpis mb-4">
    <div class="portal-kpi portal-kpi--c">
        <div class="portal-kpi__label"><i class="bi bi-flag"></i> Total To Collect</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$collectionSummary['to_collect'], 0) ?></div>
        <div class="portal-kpi__hint"><?= (int)$collectionSummary['student_count'] ?> student<?= (int)$collectionSummary['student_count'] === 1 ? '' : 's' ?> invoiced</div>
    </div>
    <div class="portal-kpi portal-kpi--b">
        <div class="portal-kpi__label"><i class="bi bi-cash-coin"></i> Collected So Far</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$collectionSummary['collected'], 0) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--e">
        <div class="portal-kpi__label"><i class="bi bi-hourglass-split"></i> Still Pending (From Students)</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$collectionSummary['pending'], 0) ?></div>
        <div class="portal-kpi__hint">Not yet paid by students</div>
    </div>
</div>
<?php endif; ?>

<div class="mb-2">
    <div class="text-muted small fw-semibold text-uppercase">Cash Handover Ledger</div>
</div>
<div class="portal-kpis">
    <div class="portal-kpi portal-kpi--b">
        <div class="portal-kpi__label"><i class="bi bi-wallet2"></i> Total Collected</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$ledger['collected'], 0) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--c">
        <div class="portal-kpi__label"><i class="bi bi-check-circle"></i> Handed Over (Confirmed)</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$ledger['handed_over'], 0) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--e">
        <div class="portal-kpi__label"><i class="bi bi-hourglass-split"></i> Pending Confirmation</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$ledger['pending_handover'], 0) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--a">
        <div class="portal-kpi__label"><i class="bi bi-cash-stack"></i> Net Balance (Still With You)</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$ledger['net_balance'], 0) ?></div>
        <div class="portal-kpi__hint">Collected minus confirmed handovers</div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0">
            <div class="card-header"><strong>Hand Over Cash</strong></div>
            <div class="card-body">
                <?php if ($outstanding <= 0): ?>
                    <div class="portal-empty"><i class="bi bi-check2-circle"></i>You have nothing outstanding right now.</div>
                <?php else: ?>
                    <p class="text-muted small">You still have <strong>Rs <?= number_format($outstanding, 2) ?></strong> not yet handed over or already pending confirmation.</p>
                    <form method="post" action="<?= htmlspecialchars(route_url('portal/handoverSubmit'), ENT_QUOTES, 'UTF-8') ?>">
                        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                        <div class="mb-3">
                            <label class="form-label">Amount</label>
                            <input class="form-control" type="number" step="0.01" min="0.01" max="<?= h((string)$outstanding) ?>" name="amount" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Handed to</label>
                            <select class="form-select" name="handed_over_to_user_id" required>
                                <option value="">Choose recipient…</option>
                                <?php foreach ($recipients as $r): ?>
                                    <option value="<?= (int)$r['id'] ?>"><?= h($r['username'] . ' (' . $r['role_name'] . ')') ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Note (optional)</label>
                            <input class="form-control" type="text" name="note" maxlength="255" placeholder="e.g. Class 5-A collections for October">
                        </div>
                        <button class="btn btn-primary w-100" type="submit">Submit Handover</button>
                        <div class="form-text">This will show as "Pending" until <?= h($recipients ? 'the recipient' : 'Admin/Principal') ?> confirms they received it.</div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card shadow-sm border-0">
            <div class="card-header"><strong>Handover History</strong></div>
            <div class="card-body p-0">
                <?php if (empty($handovers)): ?>
                    <div class="portal-empty"><i class="bi bi-arrow-left-right"></i>No handovers submitted yet.</div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th class="text-end">Amount</th>
                                <th>To</th>
                                <th>Status</th>
                                <th>Note</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($handovers as $ho): ?>
                                <tr>
                                    <td class="small"><?= h(date('d M Y, h:i A', strtotime($ho['created_at']))) ?></td>
                                    <td class="text-end fw-semibold">Rs <?= number_format((float)$ho['amount'], 2) ?></td>
                                    <td class="small"><?= h($ho['handed_to_name'] ?? '—') ?></td>
                                    <td><span class="badge <?= $statusBadge($ho['status']) ?>"><?= h(ucfirst($ho['status'])) ?></span></td>
                                    <td class="text-muted small">
                                        <?= h($ho['note'] ?? '') ?>
                                        <?php if ($ho['status'] === 'rejected' && !empty($ho['rejection_reason'])): ?>
                                            <div class="text-danger">Reason: <?= h($ho['rejection_reason']) ?></div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php if (!empty($onBehalfCollections)): ?>
<div class="row g-3 mt-1">
    <div class="col-12">
        <div class="card shadow-sm border-0">
            <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
                <strong>Collected On Your Behalf</strong>
                <span class="text-muted small">Showing <?= count($onBehalfCollections) ?> of <?= $onBehalfTotal ?></span>
            </div>
            <div class="card-body p-0">
                <div class="alert alert-info m-3 mb-0 py-2 px-3 small">
                    <i class="bi bi-info-circle me-1"></i>
                    These payments were taken by someone else (e.g. Admin at the counter) for your students, but are counted
                    in <strong>your</strong> "Total Collected" and balance above — since the cash never passed through your
                    hands, hand these over the same way as anything else you're holding, using the form above.
                </div>
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Student</th>
                                <th>Invoice</th>
                                <th class="text-end">Amount</th>
                                <th>Collected By</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($onBehalfCollections as $oc): ?>
                                <tr>
                                    <td class="small"><?= h(date('d M Y, h:i A', strtotime($oc['collected_at']))) ?></td>
                                    <td class="small"><?= h(trim(($oc['first_name'] ?? '') . ' ' . ($oc['last_name'] ?? ''))) ?> <span class="text-muted">(<?= h($oc['admission_no'] ?? '') ?>)</span></td>
                                    <td class="small"><?= h($oc['invoice_no'] ?? '') ?></td>
                                    <td class="text-end fw-semibold">Rs <?= number_format((float)$oc['amount'], 2) ?></td>
                                    <td class="small"><?= h($oc['entered_by_name'] ?? '—') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($onBehalfTotalPages > 1): ?>
                <nav class="p-2 border-top">
                    <ul class="pagination pagination-sm justify-content-center flex-wrap mb-0">
                        <?php $prevUrl = $onBehalfRouteBase . '&' . http_build_query(['ocpage' => max(1, $onBehalfPage - 1)]); ?>
                        <li class="page-item <?= $onBehalfPage <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="<?= h($prevUrl) ?>" aria-label="Previous">&laquo;</a>
                        </li>
                        <?php for ($p = 1; $p <= $onBehalfTotalPages; $p++): ?>
                            <?php $url = $onBehalfRouteBase . '&' . http_build_query(['ocpage' => $p]); ?>
                            <li class="page-item <?= $p === $onBehalfPage ? 'active' : '' ?>">
                                <a class="page-link" href="<?= h($url) ?>"><?= (int)$p ?></a>
                            </li>
                        <?php endfor; ?>
                        <?php $nextUrl = $onBehalfRouteBase . '&' . http_build_query(['ocpage' => min($onBehalfTotalPages, $onBehalfPage + 1)]); ?>
                        <li class="page-item <?= $onBehalfPage >= $onBehalfTotalPages ? 'disabled' : '' ?>">
                            <a class="page-link" href="<?= h($nextUrl) ?>" aria-label="Next">&raquo;</a>
                        </li>
                    </ul>
                </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
