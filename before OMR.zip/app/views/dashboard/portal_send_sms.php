<?php
// Variables: $error, $isScoped, $classOptions, $gatewayEnabled
$classOptions = $classOptions ?? [];
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Send SMS</h1>
        <div class="text-muted">
            Text a specific student/parent, a staff member, or a whole class directly — separate from Announcements.
            <?php if (!empty($isScoped)): ?>
                You can reach students/parents in the classes you teach or collect fees for, and any staff member.
            <?php endif; ?>
        </div>
    </div>
</div>

<?php if (empty($gatewayEnabled)): ?>
    <div class="alert alert-warning">The SMS gateway is currently turned off. Messages can be composed but won't send until it's enabled under Settings &gt; Notifications.</div>
<?php endif; ?>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="row g-3">
    <div class="col-lg-7">
        <div class="card shadow-sm border-0">
            <div class="card-header fw-semibold">Compose</div>
            <div class="card-body">
                <form method="post" id="smsForm" action="<?= h(route_url('portal/sendSms')) ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="recipient_type" id="smsRecipientType" value="">
                    <input type="hidden" name="recipient_id" id="smsRecipientId" value="">

                    <div class="mb-3">
                        <label class="form-label">Send to</label>
                        <div class="btn-group w-100" role="group">
                            <button type="button" class="btn btn-outline-primary sms-type-btn active" data-type="student">Student / Parent</button>
                            <button type="button" class="btn btn-outline-primary sms-type-btn" data-type="staff">Staff</button>
                            <button type="button" class="btn btn-outline-primary sms-type-btn" data-type="class">A Class</button>
                        </div>
                    </div>

                    <div class="mb-3" id="smsSearchWrap">
                        <label class="form-label">Search by name / admission no</label>
                        <div class="position-relative" style="z-index:20;">
                            <input type="text" id="smsSearchInput" class="form-control" autocomplete="off" placeholder="Type to search…">
                            <div id="smsDropdown"
                                 style="display:none;position:absolute;z-index:4000;top:100%;left:0;right:0;
                                        background:#fff;border:1px solid #dee2e6;border-radius:0 0 .5rem .5rem;
                                        max-height:280px;overflow-y:auto;box-shadow:0 12px 28px rgba(15,23,42,.18);"></div>
                        </div>
                    </div>

                    <div class="mb-3" id="smsClassWrap" style="display:none;">
                        <label class="form-label">Class / Section</label>
                        <select class="form-select" id="smsClassSelect">
                            <option value="">Choose...</option>
                            <?php foreach ($classOptions as $cs): ?>
                                <option value="<?= (int)$cs['id'] ?>"><?= h($cs['class_name'] . ' ' . $cs['section_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (empty($classOptions)): ?>
                            <div class="small text-muted mt-1">You're not assigned to teach or collect fees for any class yet.</div>
                        <?php endif; ?>
                    </div>

                    <div id="smsSelectedInfo" class="small text-muted mb-2">No recipient selected yet.</div>

                    <div id="smsContactsWrap" class="mb-3" style="display:none;">
                        <label class="form-label">Send to which number(s)?</label>
                        <div id="smsContactsList" class="border rounded p-2"></div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Message</label>
                        <textarea class="form-control" name="message" id="smsMessage" rows="4" maxlength="640" required></textarea>
                        <div class="small text-muted mt-1">Urdu/Arabic text and messages over ~160 characters are automatically split into multiple SMS segments.</div>
                    </div>

                    <button class="btn btn-primary" type="submit" id="smsSubmitBtn" disabled>Send SMS</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="card shadow-sm border-0">
            <div class="card-header fw-semibold">How this works</div>
            <div class="card-body small text-muted">
                <ul class="mb-0 ps-3">
                    <li>Pick <strong>Student / Parent</strong> to search a specific student and text their own phone and/or any linked guardian.</li>
                    <li>Pick <strong>Staff</strong> to search and message any staff member directly.</li>
                    <li>Pick <strong>A Class</strong> to send the same message to every student and guardian phone number on file for that class in one go.</li>
                    <li>Messages send from your own registered SMS device if you have one configured (Settings &gt; SMS Gateway Devices), otherwise the school's default device.</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<script>
(function () {
    const typeButtons   = document.querySelectorAll('.sms-type-btn');
    const searchWrap    = document.getElementById('smsSearchWrap');
    const classWrap     = document.getElementById('smsClassWrap');
    const searchInput   = document.getElementById('smsSearchInput');
    const dropdown      = document.getElementById('smsDropdown');
    const classSelect   = document.getElementById('smsClassSelect');
    const recipientType = document.getElementById('smsRecipientType');
    const recipientId   = document.getElementById('smsRecipientId');
    const selectedInfo  = document.getElementById('smsSelectedInfo');
    const contactsWrap  = document.getElementById('smsContactsWrap');
    const contactsList  = document.getElementById('smsContactsList');
    const submitBtn     = document.getElementById('smsSubmitBtn');
    const messageBox    = document.getElementById('smsMessage');

    const searchUrl  = <?= json_encode(base_url('/index.php?route=portal/smsSearch')) ?>;
    const contactUrl = <?= json_encode(base_url('/index.php?route=portal/smsContact')) ?>;

    let currentType = 'student';
    let timer;

    function resetSelection() {
        recipientId.value = '';
        contactsWrap.style.display = 'none';
        contactsList.innerHTML = '';
        selectedInfo.textContent = 'No recipient selected yet.';
        updateSubmitState();
    }

    function updateSubmitState() {
        const hasRecipient = !!recipientId.value;
        const hasContacts = currentType === 'class' ? true : contactsList.querySelectorAll('input[type=checkbox]:checked').length > 0;
        const hasMessage = messageBox.value.trim().length > 0;
        submitBtn.disabled = !(hasRecipient && hasContacts && hasMessage);
    }

    typeButtons.forEach(btn => {
        btn.addEventListener('click', function () {
            typeButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            currentType = this.dataset.type;
            recipientType.value = currentType;

            searchWrap.style.display = currentType === 'class' ? 'none' : '';
            classWrap.style.display = currentType === 'class' ? '' : 'none';
            searchInput.value = '';
            classSelect.value = '';
            dropdown.style.display = 'none';
            resetSelection();
        });
    });
    recipientType.value = currentType;

    function renderDropdown(results) {
        dropdown.innerHTML = '';
        if (!results || results.length === 0) {
            dropdown.innerHTML = '<div style="padding:.6rem 1rem;color:#6c757d;font-size:.85rem;">No matches</div>';
            dropdown.style.display = 'block';
            return;
        }
        results.forEach(r => {
            const item = document.createElement('div');
            item.style.cssText = 'padding:.5rem 1rem;cursor:pointer;border-bottom:1px solid #f1f3f5;';
            item.innerHTML = '<div>' + r.label.replace(/</g, '&lt;') + '</div>' +
                '<div class="text-muted" style="font-size:.78rem;">' + (r.meta || '').replace(/</g, '&lt;') + '</div>';
            item.addEventListener('mouseenter', () => item.style.background = '#f8f9fa');
            item.addEventListener('mouseleave', () => item.style.background = '#fff');
            item.addEventListener('click', () => {
                searchInput.value = r.label;
                dropdown.style.display = 'none';
                selectRecipient(currentType, r.id);
            });
            dropdown.appendChild(item);
        });
        dropdown.style.display = 'block';
    }

    searchInput.addEventListener('input', function () {
        clearTimeout(timer);
        const q = this.value.trim();
        resetSelection();
        if (q.length < 1) {
            dropdown.style.display = 'none';
            return;
        }
        timer = setTimeout(() => {
            fetch(searchUrl + '&type=' + encodeURIComponent(currentType) + '&q=' + encodeURIComponent(q))
                .then(r => r.json())
                .then(data => renderDropdown(data.results));
        }, 250);
    });

    document.addEventListener('click', function (e) {
        if (!searchWrap.contains(e.target)) {
            dropdown.style.display = 'none';
        }
    });

    classSelect.addEventListener('change', function () {
        resetSelection();
        if (this.value) {
            selectRecipient('class', this.value);
        }
    });

    function selectRecipient(type, id) {
        recipientId.value = id;
        fetch(contactUrl + '&type=' + encodeURIComponent(type) + '&id=' + encodeURIComponent(id))
            .then(r => r.json())
            .then(data => {
                if (data.error) {
                    selectedInfo.textContent = data.error;
                    resetSelection();
                    return;
                }
                let info = data.name;
                if (data.father_name) info += ' — Father: ' + data.father_name;
                if (data.admission_no) info += ' (Adm: ' + data.admission_no + ')';
                if (data.class_label) info += ' — ' + data.class_label;
                selectedInfo.textContent = info;

                contactsList.innerHTML = '';
                if (!data.contacts || data.contacts.length === 0) {
                    contactsList.innerHTML = '<div class="text-muted small">No phone number on file.</div>';
                    contactsWrap.style.display = '';
                    updateSubmitState();
                    return;
                }
                data.contacts.forEach((c, idx) => {
                    const wrap = document.createElement('div');
                    wrap.className = 'form-check';
                    const checked = type === 'class' ? 'checked disabled' : (idx === 0 ? 'checked' : '');
                    wrap.innerHTML = '<input class="form-check-input" type="checkbox" name="contact_keys[]" value="' + c.key + '" id="smsC' + idx + '" ' + checked + '>' +
                        '<label class="form-check-label" for="smsC' + idx + '">' + c.label.replace(/</g, '&lt;') + ' — <span class="text-muted">' + c.phone_masked + '</span></label>';
                    contactsList.appendChild(wrap);
                });
                contactsWrap.style.display = '';
                contactsList.querySelectorAll('input[type=checkbox]').forEach(cb => cb.addEventListener('change', updateSubmitState));
                updateSubmitState();
            });
    }

    messageBox.addEventListener('input', updateSubmitState);

    document.getElementById('smsForm').addEventListener('submit', function (e) {
        if (submitBtn.disabled) {
            e.preventDefault();
        }
    });
})();
</script>
