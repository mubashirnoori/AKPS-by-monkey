<?php
// Variables: $invoice, $lineBalances, $error, $returnUrl
$invoice = $invoice ?? null;
$lineBalances = $lineBalances ?? [];
$totalDue = (float)($invoice['total_due'] ?? 0);
$collected = (float)($invoice['collected_amount'] ?? 0);
$remaining = max(0, $totalDue - $collected);
$isPaid = ($invoice['status'] ?? '') === 'paid' || $remaining <= 0.001;
$returnUrl = $returnUrl ?? null;
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Collect Payment — <?= h($invoice['invoice_no'] ?? '') ?></h1>
        <div class="text-muted small">
            <?= h(trim(($invoice['first_name'] ?? '') . ' ' . ($invoice['last_name'] ?? ''))) ?>
            <?php if (!empty($invoice['father_name'])): ?>
                &middot; Father: <?= h($invoice['father_name']) ?>
            <?php endif; ?>
            &middot; Admission #<?= h($invoice['admission_no'] ?? '') ?>
        </div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= $returnUrl !== null ? h($returnUrl) : 'javascript:history.back()' ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="row g-3 mb-3">
    <div class="col-6 col-md-3">
        <div class="card shadow-sm border-0 h-100"><div class="card-body">
            <div class="text-muted small">Total Invoiced</div>
            <div class="fw-semibold fs-5">Rs <?= number_format($totalDue, 2) ?></div>
        </div></div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card shadow-sm border-0 h-100"><div class="card-body">
            <div class="text-muted small">Collected</div>
            <div class="fw-semibold fs-5 text-success">Rs <?= number_format($collected, 2) ?></div>
        </div></div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card shadow-sm border-0 h-100"><div class="card-body">
            <div class="text-muted small">Remaining</div>
            <div class="fw-semibold fs-5 <?= $remaining > 0 ? 'text-danger' : 'text-success' ?>">Rs <?= number_format($remaining, 2) ?></div>
        </div></div>
    </div>
</div>

<?php if ($isPaid): ?>
    <div class="alert alert-success"><i class="bi bi-check-circle-fill me-1"></i> This invoice is fully paid.</div>
<?php else: ?>
    <div class="card shadow-sm border-0">
        <div class="card-header bg-white fw-semibold">Record Payment</div>
        <div class="card-body">
            <form method="post" action="<?= h(route_url('portal/feeCollect')) ?>&invoice_id=<?= (int)($invoice['id'] ?? 0) ?>" id="collectPaymentForm">
                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                <input type="hidden" name="invoice_id" value="<?= (int)($invoice['id'] ?? 0) ?>">
                <?php if ($returnUrl !== null): ?>
                    <input type="hidden" name="return" value="<?= h($returnUrl) ?>">
                <?php endif; ?>

                <?php if (!empty($lineBalances)): ?>
                <div class="table-responsive mb-3">
                    <table class="table table-sm align-middle mb-0">
                        <thead>
                            <tr>
                                <th style="width:40px;"></th>
                                <th>Fee / Month</th>
                                <th class="text-end">Total</th>
                                <th class="text-end">Paid</th>
                                <th class="text-end">Pending</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($lineBalances as $line): ?>
                            <?php $pending = (float)($line['pending'] ?? 0); $isLinePaid = $pending <= 0.001; ?>
                            <tr class="<?= $isLinePaid ? 'table-success' : '' ?>">
                                <td>
                                    <?php if (!$isLinePaid): ?>
                                        <input type="checkbox" class="form-check-input month-check" name="line_ids[]" value="<?= (int)$line['id'] ?>" data-pending="<?= number_format($pending, 2, '.', '') ?>">
                                    <?php else: ?>
                                        <i class="bi bi-check-lg text-success"></i>
                                    <?php endif; ?>
                                </td>
                                <td class="small fw-semibold"><?= h($line['description'] ?? 'Fee') ?></td>
                                <td class="text-end small">Rs <?= number_format((float)($line['line_total'] ?? 0), 2) ?></td>
                                <td class="text-end small text-success">Rs <?= number_format((float)($line['paid'] ?? 0), 2) ?></td>
                                <td class="text-end small <?= $pending > 0 ? 'text-danger fw-semibold' : 'text-success' ?>">Rs <?= number_format($pending, 2) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                    <div class="alert alert-light border small">No month lines on this invoice — enter amount manually.</div>
                <?php endif; ?>

                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Payment Method</label>
                        <select name="method" class="form-select">
                            <option value="cash">Cash</option>
                            <option value="card">Card</option>
                            <option value="bank">Bank Transfer</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Amount (Rs)</label>
                        <input class="form-control" name="amount" id="collectAmount" type="number" step="0.01" min="0.01" value="<?= number_format($remaining, 2, '.', '') ?>" required>
                        <div class="form-text" id="collectAmountHint">Select months to auto-fill amount</div>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Notes (optional)</label>
                        <input class="form-control" name="notes" placeholder="e.g. Received at counter">
                    </div>
                </div>

                <button class="btn btn-success mt-3" type="submit" id="collectSubmitBtn"><i class="bi bi-cash-coin me-1"></i> Record Payment</button>
            </form>
        </div>
    </div>

    <script>
    (function () {
        const checks = () => Array.from(document.querySelectorAll('.month-check'));
        const amountEl = document.getElementById('collectAmount');
        const hintEl = document.getElementById('collectAmountHint');
        const fullRemaining = <?= json_encode(number_format($remaining, 2, '.', '')) ?>;

        function syncAmount() {
            const selected = checks().filter(c => c.checked);
            let sum = 0;
            selected.forEach(c => { sum += parseFloat(c.dataset.pending || '0') || 0; });
            if (selected.length > 0) {
                amountEl.value = sum.toFixed(2);
                hintEl.textContent = selected.length + ' month(s) selected — amount set to pending total';
            } else {
                amountEl.value = fullRemaining;
                hintEl.textContent = 'No months selected — pays invoice remaining (FIFO across months)';
            }
        }
        checks().forEach(c => c.addEventListener('change', syncAmount));

        // Guard against double-tap / double-click firing the same payment
        // twice: lock the button the instant the form is submitted, before
        // the network round-trip and redirect complete.
        const form = document.getElementById('collectPaymentForm');
        const submitBtn = document.getElementById('collectSubmitBtn');
        if (form && submitBtn) {
            form.addEventListener('submit', function (e) {
                if (form.dataset.submitted === '1') {
                    e.preventDefault();
                    return;
                }
                form.dataset.submitted = '1';
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Recording...';
            });
        }
    })();
    </script>
<?php endif; ?>
