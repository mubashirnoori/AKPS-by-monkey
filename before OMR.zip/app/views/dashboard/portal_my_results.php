<?php
// Variables: $results, $pendingResultsCount
$results = $results ?? [];
$pendingResultsCount = (int)($pendingResultsCount ?? 0);
?>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">My Results</h1>
        <div class="text-muted">Only officially announced results appear here.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=portal/index'), ENT_QUOTES, 'UTF-8') ?>">Back to Portal</a>
</div>

<?php if ($pendingResultsCount > 0): ?>
    <div class="alert alert-info d-flex align-items-center gap-2 mb-3">
        <i class="bi bi-hourglass-split fs-5"></i>
        <div><?= $pendingResultsCount ?> exam<?= $pendingResultsCount > 1 ? 's' : '' ?> awaiting official result announcement.</div>
    </div>
<?php endif; ?>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <?php if (empty($results)): ?>
            <div class="portal-empty"><i class="bi bi-clipboard-data"></i>No published results yet.</div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-sm table-hover mb-0">
                <thead><tr><th>Exam</th><th>Subject</th><th>Score</th><th>Grade</th><th>Date</th></tr></thead>
                <tbody>
                <?php foreach ($results as $r): ?>
                    <tr>
                        <td><?= h($r['exam_name'] ?? '') ?></td>
                        <td><?= h($r['subject_name'] ?? '') ?></td>
                        <td><?= h(format_mark($r['score'] ?? null)) ?></td>
                        <td><span class="badge text-bg-info"><?= h($r['grade_letter'] ?? '—') ?></span></td>
                        <td class="text-muted small"><?= h($r['scheduled_date'] ?? '') ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
