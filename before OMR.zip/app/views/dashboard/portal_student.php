<?php
// Variables: $profile, $attendance, $results, $pendingResultsCount, $invoices, $courses, $timetable, $leaveRequests, $announcements
$profile = $profile ?? [];
$attendance = $attendance ?? [];
$results = $results ?? [];
$pendingResultsCount = $pendingResultsCount ?? 0;
$invoices = $invoices ?? [];
$courses = $courses ?? [];
$timetable = $timetable ?? [];
$leaveRequests = $leaveRequests ?? [];
$announcements = $announcements ?? [];

$fullName = trim(($profile['first_name'] ?? '') . ' ' . ($profile['last_name'] ?? ''));
$initials = '';
foreach ([$profile['first_name'] ?? '', $profile['last_name'] ?? ''] as $part) {
    if ($part !== '') { $initials .= strtoupper($part[0]); }
}

$photoUrl = student_photo_url((int)($profile['id'] ?? 0));

$pendingFeeTotal = 0.0;
foreach ($invoices as $inv) {
    $pendingFeeTotal += max((float)($inv['total_due'] ?? 0) - (float)($inv['collected_amount'] ?? 0), 0);
}

$pendingLeaveCount = 0;
foreach ($leaveRequests as $lr) {
    if (($lr['status'] ?? '') === 'pending') { $pendingLeaveCount++; }
}

// Today's periods only, in schedule order (the query already orders by day_of_week, start_time).
$todayDow = (int)date('N'); // 1=Monday ... 7=Sunday, matches timetable_entries.day_of_week
$todayPeriods = array_values(array_filter($timetable, static function ($t) use ($todayDow) {
    return (int)($t['day_of_week'] ?? 0) === $todayDow;
}));
$rowBarColors = ['#38bdf8', '#4ade80', '#fb7185', '#fbbf24', '#c4b5fd', '#2dd4bf'];

$notifIconMap = [
    'leave_request' => 'bi-calendar2-x', 'leave_decision' => 'bi-calendar2-check',
    'inquiry' => 'bi-person-plus', 'complaint' => 'bi-flag',
    'fee' => 'bi-wallet2', 'fee_invoice' => 'bi-receipt', 'fee_payment' => 'bi-wallet2',
    'result_published' => 'bi-stats-chart', 'marks' => 'bi-stats-chart',
    'attendance' => 'bi-clipboard-check', 'notice' => 'bi-megaphone',
];

$today = date('Y-m-d');
?>

<div class="student-dash">

<div class="portal-hero">
    <div class="portal-hero__avatar">
        <?php if ($photoUrl): ?>
            <img src="<?= h($photoUrl) ?>" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">
        <?php else: ?>
            <?= h($initials ?: 'ST') ?>
        <?php endif; ?>
    </div>
    <div class="portal-hero__body">
        <p class="portal-hero__name">Welcome, <span class="portal-hero__name-highlight"><?= h($fullName) ?></span> <span class="portal-hero__wave">👋</span></p>
        <div class="portal-hero__meta">
            <?= h(trim(($profile['current_class_name'] ?? '') . ' ' . ($profile['current_section_name'] ?? ''))) ?>
            &middot; Admission #<?= h($profile['admission_no'] ?? '') ?>
            <?php if (!empty($profile['roll_number'])): ?> &middot; Roll #<?= h($profile['roll_number']) ?><?php endif; ?>
        </div>
    </div>
    <div class="portal-hero__right">
        <span class="btn btn-sm btn-outline-light" style="pointer-events:none;"><i class="bi bi-box-arrow-up-right me-1"></i>Student Portal</span>
    </div>
</div>

<?php if ($pendingResultsCount > 0): ?>
    <div class="alert alert-info d-flex align-items-center gap-2 mb-3">
        <i class="bi bi-hourglass-split fs-5"></i>
        <div>
            <?= $pendingResultsCount ?> exam<?= $pendingResultsCount > 1 ? 's' : '' ?> awaiting official result announcement.
            Marks will appear here as soon as the school publishes them.
        </div>
    </div>
<?php endif; ?>

<div class="portal-kpis">
    <div class="portal-kpi portal-kpi--c">
        <div class="portal-kpi__label">
            <span class="portal-kpi__icon portal-quicklink__icon--blue"><i class="bi bi-calendar-check"></i></span>
            Attendance (30 days)
        </div>
        <div class="portal-kpi__value"><?= $attendance['percentage'] !== null ? h($attendance['percentage']) . '%' : '—' ?></div>
        <div class="portal-kpi__hint"><?= (int)($attendance['present'] ?? 0) ?> present / <?= (int)($attendance['total'] ?? 0) ?> days</div>
    </div>
    <div class="portal-kpi portal-kpi--d">
        <div class="portal-kpi__label">
            <span class="portal-kpi__icon portal-quicklink__icon--amber"><i class="bi bi-cash-coin"></i></span>
            Pending Fees
        </div>
        <div class="portal-kpi__value">Rs <?= number_format($pendingFeeTotal, 0) ?></div>
        <div class="portal-kpi__hint"><?= count($invoices) ?> invoice<?= count($invoices) === 1 ? '' : 's' ?> total</div>
    </div>
    <div class="portal-kpi portal-kpi--a">
        <div class="portal-kpi__label">
            <span class="portal-kpi__icon portal-quicklink__icon--violet"><i class="bi bi-clipboard-data"></i></span>
            Published Results
        </div>
        <div class="portal-kpi__value"><?= count($results) ?></div>
        <div class="portal-kpi__hint"><?= $pendingResultsCount > 0 ? $pendingResultsCount . ' pending' : 'all announced' ?></div>
    </div>
    <div class="portal-kpi portal-kpi--f">
        <div class="portal-kpi__label">
            <span class="portal-kpi__icon portal-quicklink__icon--teal"><i class="bi bi-play-btn"></i></span>
            My Courses
        </div>
        <div class="portal-kpi__value"><?= count($courses) ?></div>
        <div class="portal-kpi__hint">assigned to you</div>
    </div>
    <div class="portal-kpi portal-kpi--e">
        <div class="portal-kpi__label">
            <span class="portal-kpi__icon portal-quicklink__icon--rose"><i class="bi bi-calendar-x"></i></span>
            Leave Requests
        </div>
        <div class="portal-kpi__value"><?= count($leaveRequests) ?></div>
        <div class="portal-kpi__hint"><?= $pendingLeaveCount ?> pending</div>
    </div>
</div>

<h2 class="h6 text-muted text-uppercase mb-2" style="letter-spacing:.04em;">Quick Access</h2>
<div class="portal-quicklinks">
    <a class="portal-quicklink" href="<?= h(route_url('portal/myResults')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--violet"><i class="bi bi-clipboard-data"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Results</p>
            <p class="portal-quicklink__hint">Announced exam scores</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myReportCard')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--violet"><i class="bi bi-file-earmark-text"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Report Card</p>
            <p class="portal-quicklink__hint">Printable official report card</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myTimetable')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--teal"><i class="bi bi-calendar-week"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Timetable</p>
            <p class="portal-quicklink__hint">Weekly class schedule</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myFees')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--green"><i class="bi bi-receipt"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Fees</p>
            <p class="portal-quicklink__hint">Invoices &amp; payments</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myCourses')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--rose"><i class="bi bi-play-btn"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Courses</p>
            <p class="portal-quicklink__hint">Online course library</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myLeaves')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--amber"><i class="bi bi-calendar-x"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Leaves</p>
            <p class="portal-quicklink__hint">Apply &amp; view history</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
</div>

<div class="psd-columns">

    <!-- My Timetable (Today) -->
    <div class="psd-panel">
        <div class="psd-panel__head">
            <i class="bi bi-calendar3 psd-panel__icon"></i>
            <p class="psd-panel__title">My Timetable (Today)</p>
        </div>
        <div class="psd-list">
            <?php if (empty($todayPeriods)): ?>
                <div class="psd-empty">No classes scheduled today.</div>
            <?php else: ?>
                <?php foreach ($todayPeriods as $i => $period): ?>
                    <div class="psd-row">
                        <div class="psd-row__bar" style="background:<?= h($rowBarColors[$i % count($rowBarColors)]) ?>;"></div>
                        <div class="psd-row__time"><?= h(date('g:i A', strtotime((string)($period['start_time'] ?? '')))) ?></div>
                        <div class="psd-row__body">
                            <p class="psd-row__title"><?= h($period['subject_name'] ?? '') ?></p>
                        </div>
                        <?php if (!empty($period['room'])): ?>
                            <span class="psd-pill" style="background:rgba(255,255,255,.06);color:#94a3b8;"><?= h($period['room']) ?></span>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <div class="psd-panel__foot">
            <a href="<?= h(route_url('portal/myTimetable')) ?>">View Full Timetable <i class="bi bi-chevron-right"></i></a>
        </div>
    </div>

    <!-- Latest Announcements -->
    <div class="psd-panel">
        <div class="psd-panel__head">
            <i class="bi bi-megaphone psd-panel__icon"></i>
            <p class="psd-panel__title">Latest Announcements</p>
            <a class="psd-panel__link" href="<?= h(route_url('notifications/index')) ?>">View All</a>
        </div>
        <div class="psd-list">
            <?php if (empty($announcements)): ?>
                <div class="psd-empty">No announcements yet.</div>
            <?php else: ?>
                <?php foreach ($announcements as $note): ?>
                    <?php $icon = $notifIconMap[$note['type'] ?? ''] ?? 'bi-bell'; ?>
                    <div class="psd-row">
                        <div class="psd-row__body">
                            <p class="psd-row__title">
                                <i class="bi <?= h($icon) ?> me-1" style="color:var(--sms-primary);"></i><?= h($note['title'] ?? '') ?>
                                <?php if (empty($note['is_read'])): ?><span class="psd-pill psd-pill--new">New</span><?php endif; ?>
                            </p>
                            <?php if (!empty($note['message'])): ?>
                                <p class="psd-row__sub"><?= h($note['message']) ?></p>
                            <?php endif; ?>
                        </div>
                        <div style="font-size:.66rem;color:#64748b;white-space:nowrap;padding-top:.15rem;flex-shrink:0;">
                            <?= h(date('d M Y', strtotime((string)($note['created_at'] ?? '')))) ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <div class="psd-panel__foot">
            <a href="<?= h(route_url('notifications/index')) ?>">View All Announcements <i class="bi bi-chevron-right"></i></a>
        </div>
    </div>

    <!-- My Fees -->
    <div class="psd-panel">
        <div class="psd-panel__head">
            <i class="bi bi-receipt psd-panel__icon"></i>
            <p class="psd-panel__title">My Fees</p>
            <a class="psd-panel__link" href="<?= h(route_url('portal/myFees')) ?>">View All</a>
        </div>
        <div class="psd-list">
            <?php if (empty($invoices)): ?>
                <div class="psd-empty">No fee invoices yet.</div>
            <?php else: ?>
                <?php foreach ($invoices as $inv):
                    $due = max((float)($inv['total_due'] ?? 0) - (float)($inv['collected_amount'] ?? 0), 0);
                    $status = $inv['status'] ?? 'open';
                    if ($status === 'paid') {
                        $pillClass = 'psd-pill--green'; $pillLabel = 'Paid';
                    } elseif ($status === 'cancelled') {
                        $pillClass = 'psd-pill--blue'; $pillLabel = 'Cancelled';
                    } elseif (!empty($inv['due_date']) && $inv['due_date'] < $today) {
                        $pillClass = 'psd-pill--rose'; $pillLabel = 'Overdue';
                    } else {
                        $pillClass = 'psd-pill--amber'; $pillLabel = 'Pending';
                    }
                    $dueDate = !empty($inv['due_date']) ? strtotime((string)$inv['due_date']) : null;
                ?>
                    <div class="psd-row">
                        <?php if ($dueDate): ?>
                            <div class="psd-datebadge">
                                <span class="psd-datebadge__day"><?= h(date('j', $dueDate)) ?></span>
                                <span class="psd-datebadge__month"><?= h(date('M', $dueDate)) ?></span>
                            </div>
                        <?php endif; ?>
                        <div class="psd-row__body">
                            <p class="psd-row__title"><?= h($inv['invoice_no'] ?? '') ?></p>
                            <p class="psd-row__sub">Rs <?= number_format($due, 0) ?> due</p>
                        </div>
                        <span class="psd-pill <?= h($pillClass) ?>"><?= h($pillLabel) ?></span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <div class="psd-panel__foot">
            <a href="<?= h(route_url('portal/myFees')) ?>">View All Invoices <i class="bi bi-chevron-right"></i></a>
        </div>
    </div>

</div>

</div>