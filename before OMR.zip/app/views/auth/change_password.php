<?php
// Variables: $error
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Change Password</h1>
        <div class="text-muted small">Update the password for your own login.</div>
    </div>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-6 col-lg-5">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <form method="post" action="<?= h(route_url('auth/changePassword')) ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Current Password</label>
                        <div class="input-group">
                            <input class="form-control" type="password" name="current_password" id="cp_current" required autocomplete="current-password">
                            <button class="btn btn-outline-secondary" type="button" onclick="togglePasswordVisibility('cp_current', this)"><i class="bi bi-eye"></i></button>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">New Password</label>
                        <div class="input-group">
                            <input class="form-control" type="password" name="new_password" id="cp_new" required minlength="6" autocomplete="new-password">
                            <button class="btn btn-outline-secondary" type="button" onclick="togglePasswordVisibility('cp_new', this)"><i class="bi bi-eye"></i></button>
                        </div>
                        <div class="form-text">At least 6 characters.</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Confirm New Password</label>
                        <div class="input-group">
                            <input class="form-control" type="password" name="confirm_password" id="cp_confirm" required minlength="6" autocomplete="new-password">
                            <button class="btn btn-outline-secondary" type="button" onclick="togglePasswordVisibility('cp_confirm', this)"><i class="bi bi-eye"></i></button>
                        </div>
                    </div>

                    <button class="btn btn-primary w-100" type="submit">Update Password</button>
                </form>
            </div>
        </div>
    </div>
</div>
