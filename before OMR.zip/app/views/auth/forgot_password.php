<?php
// Variables: $error, $sent
$settingsMap = [];
try {
    if (class_exists('Database')) {
        $rows = Database::fetchAll('SELECT `key`, `value` FROM settings');
        foreach ($rows as $r) { $settingsMap[$r['key']] = $r['value']; }
    }
} catch (Throwable $e) {}
$schoolName = $settingsMap['branding_school_name'] ?? $settingsMap['institute_name'] ?? 'School Management System';
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,500;0,600;1,500&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@500&display=swap');
:root{
    --chalk-bg:#232B26; --chalk-bg-2:#1b211d; --paper:#F4EEDC; --paper-shadow-line:#e3dac2;
    --ink:#1E2A3A; --ink-soft:#3d4c60; --margin-red:#A6352A; --chalk-white:#EDE9DD; --chalk-white-dim:#c9c4b3;
}
*{ box-sizing:border-box; }
html,body{ margin:0; padding:0; }
body{
    min-height:100vh;
    background: radial-gradient(ellipse at 20% 15%, rgba(255,255,255,0.035), transparent 40%),
                radial-gradient(ellipse at 80% 85%, rgba(255,255,255,0.03), transparent 45%),
                linear-gradient(180deg, var(--chalk-bg) 0%, var(--chalk-bg-2) 100%);
    display:flex; align-items:center; justify-content:center; padding:48px 20px;
    font-family:'IBM Plex Sans', sans-serif;
}
.login-stage{ width:100%; max-width:960px; display:flex; flex-direction:column; align-items:center; gap:34px; }
.chalk-heading{ text-align:center; color:var(--chalk-white); }
.chalk-heading .eyebrow{ font-family:'IBM Plex Mono', monospace; font-size:11px; letter-spacing:.16em; text-transform:uppercase; color:var(--chalk-white-dim); margin:0 0 10px; }
.chalk-heading h1{ font-family:'Lora', serif; font-weight:600; font-size:clamp(22px, 4vw, 30px); margin:0; }
.ledger{
    position:relative; width:100%; max-width:420px; background:var(--paper); border-radius:3px;
    padding:36px 34px 30px 56px;
    box-shadow: 0 1px 0 rgba(255,255,255,0.5) inset, 0 30px 60px -20px rgba(0,0,0,0.55), 0 8px 24px rgba(0,0,0,0.35);
}
.ledger::before{ content:''; position:absolute; top:0; bottom:0; left:26px; width:2px; background:var(--margin-red); opacity:.75; }
.ledger .holes{ position:absolute; left:11px; top:28px; bottom:28px; width:8px; display:flex; flex-direction:column; justify-content:space-between; }
.ledger .holes span{ display:block; width:8px; height:8px; border-radius:50%; background:var(--chalk-bg-2); box-shadow:inset 0 1px 2px rgba(0,0,0,.5); }
.ledger h2{ text-align:center; font-family:'Lora', serif; font-weight:600; font-size:19px; color:var(--ink); margin:0 0 2px; }
.ledger .tagline{ text-align:center; font-size:12.5px; color:var(--ink-soft); margin:0 0 26px; }
.field{ margin-bottom:18px; }
.field label{ display:block; font-family:'IBM Plex Mono', monospace; font-size:10.5px; letter-spacing:.12em; text-transform:uppercase; color:var(--margin-red); margin-bottom:7px; }
.field input{ width:100%; border:none; border-bottom:1.5px solid var(--paper-shadow-line); background:transparent; padding:8px 2px; font-family:'IBM Plex Sans', sans-serif; font-size:15px; color:var(--ink); outline:none; }
.field input:focus{ border-color:var(--ink); }
.signin{ width:100%; margin-top:10px; background:var(--ink); color:var(--paper); border:none; border-radius:2px; padding:12px 16px; font-family:'IBM Plex Sans', sans-serif; font-weight:600; font-size:14.5px; cursor:pointer; }
.signin:hover{ background:#15202e; }
.login-error{ background:#fbeceb; border:1px solid rgba(166,53,42,.35); color:var(--margin-red); font-size:13px; border-radius:3px; padding:10px 14px; margin-bottom:18px; }
.login-success{ background:#eaf7ef; border:1px solid rgba(22,163,74,.3); color:#166534; font-size:13px; border-radius:3px; padding:12px 14px; margin-bottom:6px; line-height:1.5; }
.foot-note{ text-align:center; margin-top:22px; font-family:'IBM Plex Mono', monospace; font-size:10.5px; letter-spacing:.06em; color:var(--ink-soft); opacity:.75; }
.foot-note a{ color:var(--ink-soft); }
</style>

<div class="login-stage">
    <div class="chalk-heading">
        <p class="eyebrow">School management portal</p>
        <h1><?= h($schoolName) ?></h1>
    </div>

    <div class="ledger">
        <div class="holes"><span></span><span></span><span></span><span></span><span></span></div>

        <h2>Forgot your password?</h2>
        <p class="tagline">Enter your username or email — we'll send a reset link and/or an SMS code</p>

        <?php if (!empty($error)): ?>
            <div class="login-error"><?= h($error) ?></div>
        <?php endif; ?>

        <?php if (!empty($sent)): ?>
            <div class="login-success">
                If that account exists, a reset link has been emailed (expires in 30 minutes, check spam too),
                and if a mobile number is on file, a 6-digit code has been texted to it (expires in 10 minutes).
            </div>
            <p class="foot-note" style="margin-top:14px;">
                Got a text? <a href="<?= htmlspecialchars(route_url('auth/verifyOtp'), ENT_QUOTES, 'UTF-8') ?>">Enter the SMS code</a>
            </p>
        <?php else: ?>
            <form method="post" action="<?= htmlspecialchars(route_url('auth/forgotPassword'), ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                <div class="field">
                    <label for="identifier">Username or Email</label>
                    <input class="form-control" id="identifier" name="identifier" required placeholder="Enter your username or email">
                </div>
                <button class="signin" type="submit">Send reset link</button>
            </form>
        <?php endif; ?>

        <p class="foot-note">
            <a href="<?= htmlspecialchars(route_url('auth/login'), ENT_QUOTES, 'UTF-8') ?>">Back to sign in</a>
        </p>
    </div>
</div>
