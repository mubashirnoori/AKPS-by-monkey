<?php
// Variables: $error, $title
$settingsMap = [];
try {
    if (class_exists('Database')) {
        $rows = Database::fetchAll('SELECT `key`, `value` FROM settings');
        foreach ($rows as $r) { $settingsMap[$r['key']] = $r['value']; }
    }
} catch (Throwable $e) {}
$schoolName = $settingsMap['branding_school_name'] ?? $settingsMap['institute_name'] ?? 'School Management System';
$logoPath   = $settingsMap['branding_logo_path'] ?? '';

// School locality, if set, becomes the small italic line under the name (e.g. "Bilamik Roundu").
$locality = trim((string)($settingsMap['branding_locality'] ?? ''));

// Seal monogram — first letter of up to 3 words in the school name — used only when there's no logo image.
$words = preg_split('/\s+/', trim($schoolName));
$initials = strtoupper(implode('', array_map(function ($w) { return $w !== '' ? mb_substr($w, 0, 1) : ''; }, array_slice($words, 0, 3))));

$establishedYear = trim((string)($settingsMap['branding_established_year'] ?? ''));
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,500;0,600;1,500&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@500&display=swap');

:root{
    --chalk-bg:#232B26;
    --chalk-bg-2:#1b211d;
    --paper:#F4EEDC;
    --paper-shadow-line:#e3dac2;
    --ink:#1E2A3A;
    --ink-soft:#3d4c60;
    --margin-red:#A6352A;
    --brass:#B8873E;
    --chalk-white:#EDE9DD;
    --chalk-white-dim:#c9c4b3;
}
*{ box-sizing:border-box; }
html,body{ margin:0; padding:0; }
body{
    min-height:100vh;
    background:
        radial-gradient(ellipse at 20% 15%, rgba(255,255,255,0.035), transparent 40%),
        radial-gradient(ellipse at 80% 85%, rgba(255,255,255,0.03), transparent 45%),
        linear-gradient(180deg, var(--chalk-bg) 0%, var(--chalk-bg-2) 100%);
    display:flex;
    align-items:center;
    justify-content:center;
    padding:48px 20px;
    font-family:'IBM Plex Sans', sans-serif;
}
.login-stage{
    width:100%;
    max-width:960px;
    display:flex;
    flex-direction:column;
    align-items:center;
    gap:34px;
}
.chalk-heading{ text-align:center; color:var(--chalk-white); }
.chalk-heading .eyebrow{
    font-family:'IBM Plex Mono', monospace;
    font-size:11px;
    letter-spacing:.16em;
    text-transform:uppercase;
    color:var(--chalk-white-dim);
    margin:0 0 10px;
}
.chalk-heading h1{
    font-family:'Lora', serif;
    font-weight:600;
    font-size:clamp(24px, 4vw, 34px);
    margin:0;
    letter-spacing:.2px;
}
.chalk-heading .sub{
    font-family:'Lora', serif;
    font-style:italic;
    font-weight:500;
    font-size:15px;
    color:var(--chalk-white-dim);
    margin:8px 0 0;
}

.ledger{
    position:relative;
    width:100%;
    max-width:420px;
    background:var(--paper);
    border-radius:3px;
    padding:44px 34px 30px 56px;
    box-shadow:
        0 1px 0 rgba(255,255,255,0.5) inset,
        0 30px 60px -20px rgba(0,0,0,0.55),
        0 8px 24px rgba(0,0,0,0.35);
}
.ledger::before{
    content:'';
    position:absolute;
    top:0; bottom:0; left:26px;
    width:2px;
    background:var(--margin-red);
    opacity:.75;
}
.ledger .holes{
    position:absolute;
    left:11px; top:28px; bottom:28px;
    width:8px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}
.ledger .holes span{
    display:block;
    width:8px; height:8px;
    border-radius:50%;
    background:var(--chalk-bg-2);
    box-shadow:inset 0 1px 2px rgba(0,0,0,.5);
}

.seal{
    width:76px; height:76px;
    margin:0 auto 18px;
    border-radius:50%;
    border:2px solid var(--brass);
    outline:1px solid rgba(184,135,62,.35);
    outline-offset:3px;
    display:flex;
    align-items:center;
    justify-content:center;
    position:relative;
    overflow:hidden;
    background:var(--paper);
    transform:rotate(-6deg);
    animation: sealPress .5s cubic-bezier(.2,1.4,.4,1) both;
}
@media (prefers-reduced-motion: reduce){ .seal{ animation:none; } }
@keyframes sealPress{
    0%{ transform:rotate(-6deg) scale(1.6); opacity:0; }
    60%{ opacity:1; }
    100%{ transform:rotate(-6deg) scale(1); opacity:1; }
}
.seal::after{
    content:'';
    position:absolute;
    inset:6px;
    border-radius:50%;
    border:1px dashed rgba(184,135,62,.55);
    pointer-events:none;
}
.seal img{ width:100%; height:100%; object-fit:cover; transform:rotate(6deg) scale(1.15); }
.seal .mono{
    font-family:'Lora', serif;
    font-weight:600;
    font-size:20px;
    color:var(--brass);
    letter-spacing:1px;
}

.ledger h2{
    text-align:center;
    font-family:'Lora', serif;
    font-weight:600;
    font-size:19px;
    color:var(--ink);
    margin:0 0 2px;
}
.ledger .tagline{
    text-align:center;
    font-size:12.5px;
    color:var(--ink-soft);
    margin:0 0 26px;
}

.field{ margin-bottom:18px; }
.field label{
    display:block;
    font-family:'IBM Plex Mono', monospace;
    font-size:10.5px;
    letter-spacing:.12em;
    text-transform:uppercase;
    color:var(--margin-red);
    margin-bottom:7px;
}
.field input{
    width:100%;
    border:none;
    border-bottom:1.5px solid var(--paper-shadow-line);
    background:transparent;
    padding:8px 2px;
    font-family:'IBM Plex Sans', sans-serif;
    font-size:15px;
    color:var(--ink);
    outline:none;
    transition:border-color .15s;
}
.field input::placeholder{ color:#a39c86; }
.field input:focus{ border-color:var(--ink); }

.field-password-wrap{ position:relative; display:flex; align-items:center; }
.field-password-wrap input{ padding-right:30px; }
.field-password-toggle{
    position:absolute;
    right:2px;
    background:none;
    border:none;
    padding:4px;
    color:var(--ink-soft);
    cursor:pointer;
    line-height:0;
}
.field-password-toggle:hover{ color:var(--ink); }

.signin{
    width:100%;
    margin-top:10px;
    background:var(--ink);
    color:var(--paper);
    border:none;
    border-radius:2px;
    padding:12px 16px;
    font-family:'IBM Plex Sans', sans-serif;
    font-weight:600;
    font-size:14.5px;
    letter-spacing:.02em;
    cursor:pointer;
    transition:transform .12s ease, background .15s;
}
.signin:hover{ background:#15202e; transform:translateY(-1px); }
.signin:active{ transform:translateY(0); }

.login-error{
    background:#fbeceb;
    border:1px solid rgba(166,53,42,.35);
    color:var(--margin-red);
    font-size:13px;
    border-radius:3px;
    padding:10px 14px;
    margin-bottom:18px;
}

.foot-note{
    text-align:center;
    margin-top:22px;
    font-family:'IBM Plex Mono', monospace;
    font-size:10.5px;
    letter-spacing:.06em;
    color:var(--ink-soft);
    opacity:.75;
}
</style>

<div class="login-stage">
    <div class="chalk-heading">
        <p class="eyebrow">School management portal</p>
        <h1><?= h($schoolName) ?></h1>
        <?php if ($locality !== ''): ?>
            <p class="sub"><?= h($locality) ?></p>
        <?php endif; ?>
    </div>

    <div class="ledger">
        <div class="holes"><span></span><span></span><span></span><span></span><span></span></div>

        <div class="seal">
            <?php if ($logoPath !== ''): ?>
                <img src="<?= htmlspecialchars(base_url($logoPath), ENT_QUOTES, 'UTF-8') ?>" alt="<?= h($schoolName) ?> seal">
            <?php else: ?>
                <span class="mono"><?= h($initials !== '' ? $initials : 'S') ?></span>
            <?php endif; ?>
        </div>

        <h2>Sign the register</h2>
        <p class="tagline">Enter your credentials to continue</p>

        <?php if (!empty($error)): ?>
            <div class="login-error"><?= h($error) ?></div>
        <?php endif; ?>

        <form method="post" action="<?= htmlspecialchars(route_url('auth/login'), ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">

            <div class="field">
                <label for="username">Username</label>
                <input class="form-control" id="username" name="username"
                       autocomplete="username" required placeholder="Enter your username">
            </div>

            <div class="field">
                <label for="password">Password</label>
                <div class="field-password-wrap">
                    <input class="form-control" id="password" name="password"
                           type="password" autocomplete="current-password" required placeholder="••••••••">
                    <button type="button" class="field-password-toggle" onclick="togglePasswordVisibility('password', this)" aria-label="Show password" tabindex="-1">
                        <i class="bi bi-eye"></i>
                    </button>
                </div>
            </div>

            <button class="signin" type="submit">Sign in</button>
        </form>

        <p class="foot-note" style="margin-top:14px;">
            <a href="<?= htmlspecialchars(route_url('auth/forgotPassword'), ENT_QUOTES, 'UTF-8') ?>" style="color:var(--ink-soft);">Forgot password?</a>
        </p>

        <p class="foot-note">
            <?= $establishedYear !== '' ? 'Est. records since ' . h($establishedYear) : '© ' . date('Y') . ' ' . h($schoolName) ?>
        </p>
    </div>
</div>
