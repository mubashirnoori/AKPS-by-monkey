<?php
// Variables expected: $content, $pageTitle
$settingsMap = [];
try {
    if (class_exists('Database')) {
        $rows = Database::fetchAll('SELECT `key`, `value` FROM settings');
        foreach ($rows as $r) {
            $settingsMap[(string)($r['key'] ?? '')] = (string)($r['value'] ?? '');
        }
    }
} catch (Throwable $e) {
    // Keep the page rendering even if settings are not readable.
}
$schoolName = $settingsMap['branding_school_name'] ?? $settingsMap['institute_name'] ?? 'SchoolSMS';
$faviconPath = $settingsMap['branding_favicon_path'] ?? '';
?><!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!-- Fixed viewport to match layout.php — see comment there for why (static tag — do not rewrite at runtime via JS). -->
    <meta name="viewport" content="width=1280">
    <title><?= h(($pageTitle ?? 'School Management System') . ' - ' . $schoolName) ?></title>
    <?php if ($faviconPath !== ''): ?>
        <link rel="icon" href="<?= htmlspecialchars(base_url($faviconPath), ENT_QUOTES, 'UTF-8') ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body>
<?php if (!empty($_SESSION['flash']['message'])): ?>
    <?php $flash = $_SESSION['flash']; unset($_SESSION['flash']); ?>
    <div class="alert alert-<?= h($flash['type'] ?? 'info') ?> alert-dismissible fade show m-0 rounded-0 text-center" role="alert">
        <?= h($flash['message']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>
<?= $content ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function togglePasswordVisibility(inputId, btn) {
    var input = document.getElementById(inputId);
    if (!input) return;
    var icon = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        if (icon) { icon.classList.remove('bi-eye'); icon.classList.add('bi-eye-slash'); }
    } else {
        input.type = 'password';
        if (icon) { icon.classList.remove('bi-eye-slash'); icon.classList.add('bi-eye'); }
    }
}
</script>
<script>
// See app/views/layout.php for details — registers the offline-fallback
// service worker so a connection-less app launch shows our own "You're
// offline" page instead of the WebView's default error screen.
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
        navigator.serviceWorker.register(
            '<?= htmlspecialchars(base_url('/service-worker.js'), ENT_QUOTES, 'UTF-8') ?>',
            { scope: '<?= htmlspecialchars(base_url('/'), ENT_QUOTES, 'UTF-8') ?>' }
        ).catch(function () {});
    });
}
</script>
</body>
</html>