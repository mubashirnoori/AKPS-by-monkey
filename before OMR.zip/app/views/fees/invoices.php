<?php
// Variables: $invoices, $q, $invoiceStatus, $studentStatus, $classSectionId, $classSections, $page, $perPage, $total, $listFilters
$q = (string)($q ?? '');
$invoiceStatus = (string)($invoiceStatus ?? '');
$studentStatus = (string)($studentStatus ?? '');
$classSectionId = (int)($classSectionId ?? 0);
$classSections = $classSections ?? [];
$page = max(1, (int)($page ?? 1));
$perPage = (int)($perPage ?? 20);
$total = (int)($total ?? 0);
$totalPages = max(1, (int)ceil($total / max(1, $perPage)));
$listFilters = $listFilters ?? [
    'q' => $q,
    'invoice_status' => $invoiceStatus,
    'student_status' => $studentStatus,
    'class_section_id' => $classSectionId,
    'per_page' => $perPage,
    'page' => $page,
];
$retQs = list_return_query($listFilters);
$routeBase = base_url('/index.php?route=fees/invoices');
?>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">Fee Invoices</h1>
        <div class="text-muted small">View, edit, print, and collect payments on invoices.</div>
    </div>
    <div class="d-flex gap-2">
        <a class="btn btn-primary" href="<?= h(route_url('fees/generateInvoices')) ?>">+ Generate Invoice</a>
        <a class="btn btn-outline-secondary" href="<?= h(list_url('fees/invoicesExportCsv', [
            'q' => $q,
            'invoice_status' => $invoiceStatus,
            'student_status' => $studentStatus,
            'class_section_id' => $classSectionId,
            'dl_token' => download_token(),
        ])) ?>"><i class="bi bi-download me-1"></i>Export CSV</a>
        <a class="btn btn-outline-secondary" href="<?= h(route_url('fees/index')) ?>">Back</a>
    </div>
</div>

<style>
.sms-inv-actions { display: inline-flex; align-items: center; gap: 6px; }
.sms-inv-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 34px; height: 34px; padding: 0; border-radius: 10px;
    border: 1px solid #334155; background: #0f172a; color: #cbd5e1;
    text-decoration: none; line-height: 1;
}
.sms-inv-btn i { font-size: 1rem; }
.sms-inv-btn:hover { background: #1f2937; border-color: #475569; color: #fff; }
.sms-inv-btn-view { color: #38bdf8; border-color: #1e3a5f; background: #0c2744; }
.sms-inv-btn-collect { color: #4ade80; border-color: #166534; background: #052e1c; }
.sms-inv-btn-danger { color: #fb7185; border-color: #7f1d1d; background: #3f1d1d; }
.sms-inv-actions form { display: inline; margin: 0; }
</style>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= h(base_url('/index.php')) ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="fees/invoices">
            <input type="hidden" name="sort" value="<?= h($listFilters['sort'] ?? '') ?>">
            <input type="hidden" name="dir" value="<?= h($listFilters['dir'] ?? 'asc') ?>">
            <div class="col-lg-3 col-md-6">
                <label class="form-label">Search</label>
                <input class="form-control" name="q" value="<?= h($q) ?>"
                       placeholder="Invoice no, name, admission, CNIC, ID…">
            </div>
            <div class="col-lg-2 col-md-6">
                <label class="form-label">Class / Section</label>
                <select class="form-select" name="class_section_id">
                    <option value="0">All classes</option>
                    <?php foreach ($classSections as $cs): ?>
                        <option value="<?= (int)$cs['id'] ?>" <?= $classSectionId === (int)$cs['id'] ? 'selected' : '' ?>>
                            <?= h($cs['class_name'] . ' ' . $cs['section_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-2 col-md-4">
                <label class="form-label">Invoice status</label>
                <select class="form-select" name="invoice_status">
                    <option value="" <?= $invoiceStatus === '' ? 'selected' : '' ?>>All</option>
                    <option value="open" <?= $invoiceStatus === 'open' ? 'selected' : '' ?>>Open</option>
                    <option value="paid" <?= $invoiceStatus === 'paid' ? 'selected' : '' ?>>Paid</option>
                    <option value="cancelled" <?= $invoiceStatus === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                </select>
            </div>
            <div class="col-lg-2 col-md-4">
                <label class="form-label">Student</label>
                <select class="form-select" name="student_status">
                    <option value="" <?= $studentStatus === '' ? 'selected' : '' ?>>All students</option>
                    <option value="active" <?= $studentStatus === 'active' ? 'selected' : '' ?>>Active only</option>
                    <option value="left" <?= $studentStatus === 'left' ? 'selected' : '' ?>>Left school</option>
                </select>
            </div>
            <div class="col-lg-1 col-md-4">
                <label class="form-label">Per page</label>
                <select class="form-select" name="per_page" onchange="this.form.submit()">
                    <?php foreach ([10, 20, 50, 100] as $opt): ?>
                        <option value="<?= $opt ?>" <?= $perPage === $opt ? 'selected' : '' ?>>
                            <?= $opt ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-lg-2 col-md-4 d-grid">
                <button class="btn btn-primary" type="submit">Search</button>
            </div>
        </form>
    </div>
</div>

<div id="invoiceListContainer">
<?= $this->renderPartial('fees/_invoice_list', [
    'invoices' => $invoices,
    'total' => $total,
    'q' => $q,
    'invoiceStatus' => $invoiceStatus,
    'studentStatus' => $studentStatus,
    'classSectionId' => $classSectionId,
    'page' => $page,
    'perPage' => $perPage,
    'listFilters' => $listFilters,
]) ?>
</div>

<script>
function smsInitInvoiceTooltips(root) {
    (root || document).querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function (el) {
        if (window.bootstrap && bootstrap.Tooltip) {
            var existing = bootstrap.Tooltip.getInstance(el);
            if (existing) existing.dispose();
            new bootstrap.Tooltip(el);
        }
    });
}
document.addEventListener('DOMContentLoaded', function () { smsInitInvoiceTooltips(document); });
document.addEventListener('ajax-content-updated', function (evt) {
    if (evt.detail.target && evt.detail.target.id === 'invoiceListContainer') {
        smsInitInvoiceTooltips(evt.detail.target);
    }
});
</script>