<?php
// Variables: $invoice, $listFilters
$invoice = $invoice ?? [];
$listFilters = $listFilters ?? recall_list_filters('fees_invoices', [
    'q' => '', 'invoice_status' => '', 'student_status' => '', 'class_section_id' => 0, 'per_page' => 20, 'page' => 1,
]);
$listBackUrl = list_url('fees/invoices', $listFilters);
?>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">Edit Invoice <?= h($invoice['invoice_no'] ?? '') ?></h1>
        <div class="text-muted small">
            <?= h(($invoice['first_name'] ?? '') . ' ' . ($invoice['last_name'] ?? '')) ?>
            &middot; <?= h($invoice['admission_no'] ?? '') ?>
        </div>
    </div>
    <div class="d-flex gap-2">
        <a class="btn btn-outline-secondary" href="<?= h($listBackUrl) ?>">Back to Invoices</a>
    </div>
</div>

<form method="post" action="<?= h(route_url('fees/invoiceEdit') . '&invoice_id=' . (int)($invoice['id'] ?? 0)) ?>">
    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
    <input type="hidden" name="invoice_id" value="<?= (int)($invoice['id'] ?? 0) ?>">
    <?php list_return_fields($listFilters); ?>

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-body">
            <h2 class="h6 mb-3">Invoice Details</h2>
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Due Date</label>
                    <input type="date" class="form-control" name="due_date"
                           value="<?= h($invoice['due_date'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Status</label>
                    <?php $status = $invoice['status'] ?? 'open'; ?>
                    <select class="form-select" name="status">
                        <option value="open" <?= $status === 'open' ? 'selected' : '' ?>>Open</option>
                        <option value="paid" <?= $status === 'paid' ? 'selected' : '' ?>>Paid</option>
                        <option value="cancelled" <?= $status === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Collected So Far</label>
                    <input type="text" class="form-control" disabled
                           value="Rs. <?= number_format((float)($invoice['collected_amount'] ?? 0), 2) ?>">
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-body">
            <h2 class="h6 mb-3">Line Items</h2>
            <div class="table-responsive">
                <table class="table table-sm align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Category</th>
                            <th class="text-end" style="width:160px;">Base Amount</th>
                            <th class="text-end" style="width:160px;">Discount</th>
                            <th class="text-end" style="width:140px;">Line Total</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($invoice['lines'])): ?>
                        <tr><td colspan="4" class="text-muted text-center py-3">No line items on this invoice.</td></tr>
                    <?php else: ?>
                        <?php foreach ($invoice['lines'] as $line): ?>
                            <tr>
                                <td>
                                    <?= h($line['category_name'] ?? ($line['description'] ?? '')) ?>
                                    <input type="hidden" name="line_id[]" value="<?= (int)$line['id'] ?>">
                                </td>
                                <td class="text-end">
                                    <input type="number" step="0.01" min="0" class="form-control form-control-sm text-end"
                                           name="base_amount[]" value="<?= h((string)($line['base_amount'] ?? 0)) ?>">
                                </td>
                                <td class="text-end">
                                    <input type="number" step="0.01" min="0" class="form-control form-control-sm text-end"
                                           name="discount_amount[]" value="<?= h((string)($line['discount_amount'] ?? 0)) ?>">
                                </td>
                                <td class="text-end text-muted"><?= h((string)($line['line_total'] ?? 0)) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="form-text mt-2">Totals recalculate automatically from base amount minus discount when you save.</div>
        </div>
    </div>

    <div class="d-flex gap-2">
        <button type="submit" class="btn btn-primary">Save Changes</button>
        <a class="btn btn-outline-secondary" href="<?= h($listBackUrl) ?>">Cancel</a>
    </div>
</form>
