<?php
$student = $student ?? [];
$invoices = $invoices ?? [];
$allLines = $allLines ?? [];
$allCollections = $allCollections ?? [];
$summary = $summary ?? [];
$pending = max(0, (float)($pending ?? 0));
$listFilters = $listFilters ?? [];
$listBackUrl = list_url('fees/invoices', $listFilters);
$studentId = (int)($student['id'] ?? 0);
$studentName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
$classDisplay = trim(
    (string)($student['current_class_name'] ?? '') . ' ' . (string)($student['current_section_name'] ?? '')
);
$totalCharged = (float)($summary['total_due'] ?? $summary['total_charged'] ?? 0);
$totalPaid = (float)($summary['total_paid'] ?? 0);
$invoiceCount = (int)($summary['invoice_count'] ?? 0);
$openCount = (int)($summary['pending_invoices'] ?? 0);
$paidCount = (int)($summary['paid_invoices'] ?? 0);
$canBulkDelete = RBAC::hasPermission('fees.manage') || RBAC::hasPermission('fees.invoice_delete');
$canBulkCollect = RBAC::hasPermission('fees.manage') || RBAC::hasPermission('fees.collect');
$bulkOnBehalf = $bulkOnBehalf ?? ['options' => [], 'defaultStaffId' => 0, 'show' => false];
$hasBulk = $canBulkDelete || $canBulkCollect;
$yearLabels = $yearLabels ?? [];

// Invoices: which academic years are present, and how many are open / closed.
$invYears = [];
$openInv = 0;
foreach ($invoices as $fiTmp) {
    $yid = (int)($fiTmp['academic_year_id'] ?? 0);
    $invYears[$yid] = $yearLabels[$yid] ?? ($yid > 0 ? 'Year #' . $yid : 'No year');
    if (($fiTmp['status'] ?? 'open') === 'open') { $openInv++; }
}
krsort($invYears);
$closedInv = count($invoices) - $openInv;
$defaultView = $openInv > 0 ? 'open' : 'all';

// Payments: payments made together (same minute, method, collector, note) become one receipt row.
$receipts = [];
foreach ($allCollections as $colTmp) {
    $key = date('Y-m-d H:i', strtotime((string)($colTmp['collected_at'] ?? 'now')))
        . '|' . ($colTmp['method'] ?? '') . '|' . ($colTmp['collected_by_name'] ?? '') . '|' . ($colTmp['notes'] ?? '');
    if (!isset($receipts[$key])) {
        $receipts[$key] = ['at' => (string)($colTmp['collected_at'] ?? ''), 'method' => $colTmp['method'] ?? 'cash',
            'by' => $colTmp['collected_by_name'] ?? 'Unknown user', 'total' => 0.0, 'items' => []];
    }
    $receipts[$key]['total'] += (float)($colTmp['amount'] ?? 0);
    $receipts[$key]['items'][] = $colTmp;
}
$receipts = array_values($receipts);
usort($receipts, static fn($a, $b) => strcmp($b['at'], $a['at']));
?>

<style>
.sms-inv-actions { display: inline-flex; align-items: center; gap: 6px; }
.sms-inv-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 34px; height: 34px; padding: 0; border-radius: 10px;
    border: 1px solid #334155; background: #0f172a; color: #cbd5e1;
    text-decoration: none; line-height: 1;
}
.sms-inv-btn i { font-size: 1rem; }
.sms-inv-btn:hover { background: #1f2937; border-color: #475569; color: #fff; }
.sms-inv-btn-view { color: #38bdf8; border-color: #1e3a5f; background: #0c2744; }
.sms-inv-btn-collect { color: #4ade80; border-color: #166534; background: #052e1c; }
.sms-inv-btn-danger { color: #fb7185; border-color: #7f1d1d; background: #3f1d1d; }
.sms-inv-actions form { display: inline; margin: 0; }
</style>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0"><?= h($studentName) ?></h1>
        <div class="text-muted small">
            All invoices for this student
            <?php if (($student['admission_no'] ?? '') !== ''): ?>
                · Adm <?= h($student['admission_no']) ?>
            <?php endif; ?>
            <?php if ($classDisplay !== ''): ?>
                · <?= h($classDisplay) ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <a class="btn btn-primary" href="<?= h(route_url('fees/generateInvoices') . '&mode=student&student_id=' . $studentId) ?>">+ Generate Invoice</a>
        <a class="btn btn-outline-secondary" href="<?= h($listBackUrl) ?>">← Back to students</a>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Invoices</div>
                <div class="fw-semibold"><?= $invoiceCount ?></div>
                <div class="text-muted small"><?= $openCount ?> open · <?= $paidCount ?> paid</div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Total Invoiced</div>
                <div class="fw-semibold">Rs. <?= number_format($totalCharged, 2) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Collected</div>
                <div class="fw-semibold">Rs. <?= number_format($totalPaid, 2) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Pending</div>
                <div class="fw-semibold <?= $pending > 0 ? 'text-danger' : 'text-success' ?>">
                    Rs. <?= number_format($pending, 2) ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <div class="d-flex align-items-center flex-wrap gap-2 mb-3">
            <h2 class="h6 mb-0 me-auto">Invoices</h2>
            <?php if ($hasBulk && $invoices): ?>
                <span class="text-muted small"><span id="siSelCount">0</span> selected</span>
                <button type="button" class="btn btn-sm btn-outline-secondary" id="siSelOpen">Select all unpaid</button>
                <?php if ($canBulkCollect): ?>
                    <button type="button" class="btn btn-sm btn-success" id="siBtnCollect" disabled>
                        <i class="bi bi-cash-coin"></i> Collect selected <span id="siCollectAmt"></span>
                    </button>
                <?php endif; ?>
                <?php if ($canBulkDelete): ?>
                    <button type="submit" form="siDelForm" class="btn btn-sm btn-outline-danger" id="siBtnDelete" disabled
                            onclick="var n=document.querySelectorAll('.si-sel:checked').length;return confirm('Delete '+n+' selected invoice(s)? Invoices that already have a payment are kept. This cannot be undone.');">
                        <i class="bi bi-trash"></i> Delete selected
                    </button>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php if ($invoices): ?>
        <div class="d-flex align-items-center flex-wrap gap-2 mb-3" id="siFilters" data-default="<?= h($defaultView) ?>">
            <div class="btn-group btn-group-sm" role="group" aria-label="Invoice status">
                <button type="button" class="btn btn-outline-secondary" data-view="open">Open (<?= $openInv ?>)</button>
                <button type="button" class="btn btn-outline-secondary" data-view="closed">Paid / closed (<?= $closedInv ?>)</button>
                <button type="button" class="btn btn-outline-secondary" data-view="all">All (<?= count($invoices) ?>)</button>
            </div>
            <?php if (count($invYears) > 1): ?>
            <select class="form-select form-select-sm" id="siYear" style="max-width:190px;">
                <option value="">All academic years</option>
                <?php foreach ($invYears as $yid => $ylabel): ?>
                    <option value="<?= (int)$yid ?>"><?= h($ylabel) ?></option>
                <?php endforeach; ?>
            </select>
            <?php endif; ?>
            <span class="text-muted small" id="siShown"></span>
        </div>
        <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <?php if ($hasBulk): ?><th style="width:32px;"><input type="checkbox" class="form-check-input" id="siSelAll" title="Select all"></th><?php endif; ?>
                        <th>Invoice No</th>
                        <th>Month</th>
                        <th class="text-end">Total</th>
                        <th class="text-end">Collected</th>
                        <th class="text-end">Pending</th>
                        <th>Status</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($invoices)): ?>
                    <tr><td colspan="8" class="text-muted py-3 text-center">No invoices for this student.</td></tr>
                <?php else: ?>
                    <?php foreach ($invoices as $fi): ?>
                        <?php
                        $iid = (int)($fi['id'] ?? 0);
                        $invNo = h($fi['invoice_no'] ?? '');
                        $due = (float)($fi['total_due'] ?? 0);
                        $collected = (float)($fi['collected_amount'] ?? 0);
                        $rowPending = max(0, $due - $collected);
                        $status = $fi['status'] ?? 'open';
                        $statusBadge = match ($status) {
                            'paid' => '<span class="badge bg-success">Paid</span>',
                            'cancelled' => '<span class="badge bg-secondary">Cancelled</span>',
                            default => '<span class="badge bg-warning text-dark">Open</span>',
                        };
                        $monthsRaw = [];
                        foreach ($fi['lines'] ?? [] as $ln) {
                            if (!empty($ln['billing_month'])) {
                                $monthsRaw[] = ((int)($ln['billing_year'] ?? 0)) . '-' . (int)$ln['billing_month'];
                            }
                        }
                        $monthLabel = FeeInvoiceModel::formatBillingMonths(implode(',', $monthsRaw));
                        ?>
                        <tr class="si-row" data-open="<?= $status === 'open' ? '1' : '0' ?>" data-year="<?= (int)($fi['academic_year_id'] ?? 0) ?>">
                            <?php if ($hasBulk): ?><td><input type="checkbox" class="form-check-input si-sel" form="siDelForm" name="invoice_ids[]" value="<?= $iid ?>"
                                   data-pending="<?= number_format($rowPending, 2, '.', '') ?>" data-open="<?= $status === 'open' && $rowPending > 0.001 ? '1' : '0' ?>"
                                   data-no="<?= $invNo ?>"></td><?php endif; ?>
                            <td class="fw-semibold">
                                <?= $invNo ?>
                                <div class="text-muted small fw-normal">ID: <?= $iid ?></div>
                            </td>
                            <td class="small">
                                <div class="text-muted"><?= h($monthLabel !== '' ? $monthLabel : '—') ?></div>
                                <?php foreach ($fi['lines'] ?? [] as $ln): if (!empty($ln['billing_month'])) { continue; } ?>
                                    <div class="mt-1">
                                        <span class="badge bg-info text-dark">+ <?= h($ln['description'] ?? ($ln['category_name'] ?? 'Fee')) ?></span>
                                        <span class="text-muted">Rs. <?= number_format((float)($ln['line_total'] ?? 0), 2) ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </td>
                            <td class="text-end">Rs. <?= number_format($due, 2) ?></td>
                            <td class="text-end">Rs. <?= number_format($collected, 2) ?></td>
                            <td class="text-end <?= $rowPending > 0.001 ? 'text-danger fw-semibold' : 'text-success' ?>">
                                Rs. <?= number_format($rowPending, 2) ?>
                            </td>
                            <td><?= $statusBadge ?></td>
                            <td class="text-center">
                                <div class="sms-inv-actions">
                                    <a class="sms-inv-btn sms-inv-btn-view"
                                       href="<?= h(route_url('fees/invoiceView') . '&invoice_id=' . $iid) ?>"
                                       title="View invoice">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a class="sms-inv-btn"
                                       href="<?= h(route_url('fees/invoiceEdit') . '&invoice_id=' . $iid) ?>"
                                       title="Edit">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a class="sms-inv-btn"
                                       href="<?= h(route_url('fees/invoicePrint') . '&invoice_id=' . $iid) ?>"
                                       target="_blank" title="Print">
                                        <i class="bi bi-printer"></i>
                                    </a>
                                    <?php if ($rowPending > 0.001): ?>
                                    <a class="sms-inv-btn sms-inv-btn-collect" href="#"
                                       data-collect-invoice-id="<?= $iid ?>"
                                       title="Collect payment">
                                        <i class="bi bi-cash-coin"></i>
                                    </a>
                                    <?php endif; ?>
                                    <form method="post" action="<?= h(route_url('fees/invoiceDelete')) ?>"
                                          onsubmit="return confirm('Delete invoice <?= $invNo ?> permanently?');">
                                        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                        <input type="hidden" name="invoice_id" value="<?= $iid ?>">
                                        <input type="hidden" name="return_student_id" value="<?= $studentId ?>">
                                        <button type="submit" class="sms-inv-btn sms-inv-btn-danger" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <h2 class="h6 mb-3">Payments</h2>
        <?php if (empty($allCollections)): ?>
            <div class="text-muted small">No payments recorded yet.</div>
        <?php else: ?>
            <?php $recLimit = 5; ?>
            <div class="list-group list-group-flush" id="siReceipts">
                <?php foreach ($receipts as $ri => $rc): $cnt = count($rc['items']); ?>
                    <div class="list-group-item px-0 si-receipt<?= $ri >= $recLimit ? ' d-none' : '' ?>">
                        <?php if ($cnt === 1): $c = $rc['items'][0]; ?>
                            <div class="d-flex justify-content-between align-items-start">
                                <span class="small">
                                    <?= h(date('d M Y H:i', strtotime($rc['at'] ?: 'now'))) ?> · <?= h($rc['method']) ?> · <?= h($c['invoice_no'] ?? '') ?>
                                    <?php if (!empty($c['months_label'])): ?><div class="text-muted"><?= h($c['months_label']) ?></div><?php endif; ?>
                                    <div class="text-muted"><i class="bi bi-person-badge me-1"></i><?= h($rc['by']) ?></div>
                                </span>
                                <strong>Rs. <?= number_format($rc['total'], 2) ?></strong>
                            </div>
                        <?php else: ?>
                            <details>
                                <summary class="d-flex justify-content-between align-items-start" style="cursor:pointer;">
                                    <span class="small">
                                        <?= h(date('d M Y H:i', strtotime($rc['at'] ?: 'now'))) ?> · <?= h($rc['method']) ?> · <?= $cnt ?> invoices
                                        <div class="text-muted"><i class="bi bi-person-badge me-1"></i><?= h($rc['by']) ?></div>
                                    </span>
                                    <strong>Rs. <?= number_format($rc['total'], 2) ?></strong>
                                </summary>
                                <div class="mt-2 ps-3 small">
                                    <?php foreach ($rc['items'] as $c): ?>
                                        <div class="d-flex justify-content-between text-muted">
                                            <span><?= h($c['months_label'] ?? '') !== '' ? h($c['months_label']) : h($c['invoice_no'] ?? '') ?></span>
                                            <span>Rs. <?= number_format((float)($c['amount'] ?? 0), 2) ?></span>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </details>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php if (count($receipts) > $recLimit): ?>
                <button type="button" class="btn btn-sm btn-outline-secondary mt-3" id="siMoreReceipts">
                    Show all <?= count($receipts) ?> payments
                </button>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>


<?php if ($hasBulk && $invoices): ?>
<!-- Bulk actions for the ticked invoices -->
<form id="siDelForm" method="post" action="<?= h(route_url('fees/invoiceBulkDelete')) ?>">
    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
    <input type="hidden" name="return_student_id" value="<?= $studentId ?>">
</form>

<?php if ($canBulkCollect): ?>
<style>
    #siCollectModal { z-index: 2100; }
    .modal-backdrop { z-index: 2090; }
</style>
<div class="modal fade" id="siCollectModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <form method="post" action="<?= h(route_url('fees/invoiceBulkCollect')) ?>" id="siCollectForm">
                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                <input type="hidden" name="return_student_id" value="<?= $studentId ?>">
                <div class="modal-header">
                    <h5 class="modal-title">Collect selected invoices</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="text-muted small mb-1">Each invoice below is paid in full:</div>
                    <div class="border rounded mb-3" style="max-height:200px;overflow:auto;">
                        <table class="table table-sm mb-0"><tbody id="siCollectList"></tbody></table>
                    </div>
                    <div id="siCollectIds"></div>
                    <div class="d-flex justify-content-between fw-semibold mb-3">
                        <span>Total to collect</span><span id="siCollectTotal">Rs. 0.00</span>
                    </div>
                    <?php if (!empty($bulkOnBehalf['show'])): ?>
                    <div class="mb-3">
                        <label class="form-label">Collecting on behalf of <span class="text-danger">*</span></label>
                        <select class="form-select" name="on_behalf_of_staff_id" required>
                            <option value="">— Select teacher/staff —</option>
                            <?php foreach ($bulkOnBehalf['options'] as $opt): $osid = (int)$opt['staff_profile_id']; ?>
                                <option value="<?= $osid ?>" <?= $osid === (int)$bulkOnBehalf['defaultStaffId'] ? 'selected' : '' ?>><?= h($opt['full_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    <div class="row g-2">
                        <div class="col-sm-5">
                            <label class="form-label">Method</label>
                            <select name="method" class="form-select">
                                <option value="cash">Cash</option>
                                <option value="card">Card</option>
                                <option value="bank">Bank Transfer</option>
                            </select>
                        </div>
                        <div class="col-sm-7">
                            <label class="form-label">Notes (optional)</label>
                            <input class="form-control" name="notes" placeholder="e.g. Received at counter">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success" id="siCollectGo"><i class="bi bi-cash-coin me-1"></i> Record payments</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
(function () {
    var all = function () { return Array.prototype.slice.call(document.querySelectorAll('.si-sel')).filter(function (c) { var r = c.closest('tr'); return !(r && r.classList.contains('d-none')); }); };
    var sel = function () { return all().filter(function (c) { return c.checked; }); };
    var money = function (n) { return 'Rs. ' + Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };

    function refresh() {
        var picked = sel(), n = picked.length, due = 0, open = 0;
        picked.forEach(function (c) { if (c.dataset.open === '1') { due += parseFloat(c.dataset.pending) || 0; open++; } });
        document.getElementById('siSelCount').textContent = n;
        var d = document.getElementById('siBtnDelete'); if (d) { d.disabled = n === 0; }
        var b = document.getElementById('siBtnCollect');
        if (b) { b.disabled = open === 0; document.getElementById('siCollectAmt').textContent = open ? '(' + money(due) + ')' : ''; }
        var a = document.getElementById('siSelAll'); if (a) { a.checked = n > 0 && n === all().length; }
    }

    document.addEventListener('change', function (e) {
        if (e.target.id === 'siSelAll') { all().forEach(function (c) { c.checked = e.target.checked; }); }
        if (e.target.classList && (e.target.classList.contains('si-sel') || e.target.id === 'siSelAll')) { refresh(); }
    });
    var so = document.getElementById('siSelOpen');
    if (so) { so.addEventListener('click', function () { all().forEach(function (c) { c.checked = c.dataset.open === '1'; }); refresh(); }); }

    var bc = document.getElementById('siBtnCollect');
    if (bc) {
        bc.addEventListener('click', function () {
            var rows = '', ids = '', total = 0;
            sel().forEach(function (c) {
                if (c.dataset.open !== '1') { return; }
                var p = parseFloat(c.dataset.pending) || 0; total += p;
                rows += '<tr><td class="small">' + c.dataset.no + '</td><td class="text-end small">' + money(p) + '</td></tr>';
                ids += '<input type="hidden" name="invoice_ids[]" value="' + c.value + '">';
            });
            document.getElementById('siCollectList').innerHTML = rows;
            document.getElementById('siCollectIds').innerHTML = ids;
            document.getElementById('siCollectTotal').textContent = money(total);
            bootstrap.Modal.getOrCreateInstance(document.getElementById('siCollectModal')).show();
        });
        document.getElementById('siCollectForm').addEventListener('submit', function () {
            document.getElementById('siCollectGo').disabled = true;
        });
    }
    refresh();
})();
</script>
<?php endif; ?>

<script>
(function () {
    // Invoice list filters: open / paid / all, and academic year.
    var box = document.getElementById('siFilters');
    if (box) {
        var view = box.dataset.default || 'all';
        var yearSel = document.getElementById('siYear');
        var rows = Array.prototype.slice.call(document.querySelectorAll('tr.si-row'));
        var shown = document.getElementById('siShown');
        var apply = function () {
            var y = yearSel ? yearSel.value : '', n = 0;
            rows.forEach(function (r) {
                var isOpen = r.dataset.open === '1';
                var ok = (view === 'all' || (view === 'open' && isOpen) || (view === 'closed' && !isOpen))
                      && (y === '' || r.dataset.year === y);
                r.classList.toggle('d-none', !ok);
                if (ok) { n++; }
            });
            box.querySelectorAll('[data-view]').forEach(function (b) { b.classList.toggle('active', b.dataset.view === view); });
            if (shown) { shown.textContent = 'Showing ' + n + ' of ' + rows.length; }
            // Hidden rows must never stay ticked (bulk collect / delete only act on what you can see).
            var first = null;
            document.querySelectorAll('.si-sel').forEach(function (c) { if (c.checked) { c.checked = false; } first = first || c; });
            if (first) { first.dispatchEvent(new Event('change', { bubbles: true })); }
        };
        box.addEventListener('click', function (e) {
            var b = e.target.closest('[data-view]');
            if (b) { view = b.dataset.view; apply(); }
        });
        if (yearSel) { yearSel.addEventListener('change', apply); }
        apply();
    }

    // Payments: show the latest few, the rest on request.
    var more = document.getElementById('siMoreReceipts');
    if (more) {
        more.addEventListener('click', function () {
            document.querySelectorAll('#siReceipts .si-receipt.d-none').forEach(function (r) { r.classList.remove('d-none'); });
            more.remove();
        });
    }
})();
</script>