<?php
// Variables: $invoiceOptions, $invoiceId, $invoice (now includes lines, fines, collections), $listFilters
$invoice   = $invoice ?? null;
$invoiceId = (int)($invoiceId ?? 0);
$listFilters = $listFilters ?? recall_list_filters('fees_invoices', [
    'q' => '', 'invoice_status' => '', 'student_status' => '', 'class_section_id' => 0, 'per_page' => 20, 'page' => 1,
]);
$listBackUrl = list_url('fees/invoices', $listFilters);
$showOnBehalfPicker = !empty($showOnBehalfPicker);
$onBehalfOptions = $onBehalfOptions ?? [];
$onBehalfDefaultStaffId = (int)($onBehalfDefaultStaffId ?? 0);
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Fee Collection</h1>
        <div class="text-muted small">Select months to collect, record payments, and manage fines.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars($listBackUrl, ENT_QUOTES, 'UTF-8') ?>">← Back to Invoices</a>
</div>

<!-- Invoice Selector -->
<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <label class="form-label fw-semibold">Select Invoice</label>
        <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="fees/collect">
            <div class="col-md-8">
                <select class="form-select" name="invoice_id" onchange="this.form.submit()">
                    <option value="0">— Choose an invoice —</option>
                    <?php foreach ($invoiceOptions as $opt): ?>
                        <?php
                        $oid     = (int)$opt['id'];
                        $label   = h($opt['invoice_no']) . ' — ' . h($opt['first_name'] . ' ' . $opt['last_name'])
                                 . ' (' . h($opt['admission_no']) . ')'
                                 . ' — Rs ' . number_format((float)$opt['total_due'], 2)
                                 . ' [' . strtoupper($opt['status'] ?? 'open') . ']';
                        ?>
                        <option value="<?= $oid ?>" <?= $oid === $invoiceId ? 'selected' : '' ?>>
                            <?= $label ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <button class="btn btn-outline-primary w-100" type="submit">Load Invoice</button>
            </div>
        </form>
    </div>
</div>

<?php if ($invoice): ?>
    <?php
    $status      = $invoice['status'] ?? 'open';
    $totalDue    = (float)($invoice['total_due'] ?? 0);
    $fineApplied = (float)($invoice['fine_applied'] ?? 0);
    $dueDate     = $invoice['due_date'] ?? null;
    $isOverdue   = $dueDate && date('Y-m-d') > $dueDate && $status === 'open';
    $isAlreadyPaid = $status === 'paid';
    $collected   = (float)($invoice['collected_amount'] ?? 0);
    $remaining   = max(0, $totalDue - $collected);
    $lines       = $invoice['lines'] ?? [];
    ?>

    <!-- Invoice Details Card -->
    <div class="card shadow-sm border-0 mb-3">
        <div class="card-header d-flex justify-content-between align-items-center">
            <strong>Invoice: <?= h($invoice['invoice_no'] ?? '') ?></strong>
            <?php
            $badgeClass = match($status) {
                'paid'      => 'bg-success',
                'cancelled' => 'bg-secondary',
                default     => ($isOverdue ? 'bg-danger' : 'bg-warning text-dark'),
            };
            $badgeText = strtoupper($isOverdue ? 'OVERDUE' : $status);
            ?>
            <span class="badge <?= $badgeClass ?>"><?= $badgeText ?></span>
        </div>
        <div class="card-body">
            <div class="row g-3 mb-3">
                <div class="col-6 col-md-3">
                    <div class="text-muted small">Student</div>
                    <div class="fw-semibold"><?= h(trim(($invoice['first_name'] ?? '') . ' ' . ($invoice['last_name'] ?? ''))) ?></div>
                    <div class="text-muted small"><?= h($invoice['admission_no'] ?? '') ?></div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="text-muted small">Total Invoiced</div>
                    <div class="fw-semibold fs-5">Rs <?= number_format($totalDue, 2) ?></div>
                    <?php if ($fineApplied > 0): ?>
                        <div class="text-danger small">Fine: Rs <?= number_format($fineApplied, 2) ?></div>
                    <?php endif; ?>
                </div>
                <div class="col-6 col-md-3">
                    <div class="text-muted small">Collected</div>
                    <div class="fw-semibold fs-5 text-success">Rs <?= number_format($collected, 2) ?></div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="text-muted small">Remaining</div>
                    <div class="fw-semibold fs-5 <?= $remaining > 0 ? 'text-danger' : 'text-success' ?>">
                        Rs <?= number_format($remaining, 2) ?>
                    </div>
                </div>
            </div>

            <?php if ($dueDate): ?>
                <div class="alert <?= $isOverdue ? 'alert-danger' : 'alert-info' ?> py-2 px-3 small mb-0">
                    <i class="bi bi-<?= $isOverdue ? 'exclamation-triangle-fill' : 'calendar-check' ?> me-1"></i>
                    Due date: <strong><?= h(date('d M Y', strtotime($dueDate))) ?></strong>
                    <?php if ($isOverdue): ?>
                        — <strong>Overdue by <?= (int)(((new DateTime())->diff(new DateTime($dueDate)))->days) ?> day(s).</strong>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if (!empty($invoice['collections'])): ?>
    <div class="card shadow-sm border-0 mb-3">
        <div class="card-header"><strong>Payment History</strong></div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-sm table-striped mb-0">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Months / Items</th>
                            <th class="text-end">Amount</th>
                            <th>Method</th>
                            <th>Collected by</th>
                            <th>Notes</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($invoice['collections'] as $col): ?>
                            <tr>
                                <td class="small"><?= h(date('d M Y H:i', strtotime($col['collected_at']))) ?></td>
                                <td class="small">
                                    <?php if (!empty($col['months_label'])): ?>
                                        <?= h($col['months_label']) ?>
                                    <?php else: ?>
                                        <span class="text-muted">General payment</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end fw-semibold text-success">Rs <?= number_format((float)$col['amount'], 2) ?></td>
                                <td><span class="badge border" style="background: var(--sms-surface-2, #1f2937); color: var(--sms-text, #e5e7eb);"><?= h(ucfirst($col['method'] ?? 'cash')) ?></span></td>
                                <td class="small">
                                    <?= h($col['collected_by_name'] ?? '—') ?>
                                    <?php if (!empty($col['entered_by_name'])): ?>
                                        <div class="text-muted" style="font-size: 0.75rem;">
                                            collected on their behalf by <?= h($col['entered_by_name']) ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td class="text-muted small"><?= h($col['notes'] ?? '') ?></td>
                                <td class="text-end">
                                    <form method="post" action="<?= htmlspecialchars(route_url('fees/collect'), ENT_QUOTES, 'UTF-8') ?>"
                                          onsubmit="return confirm('Remove this payment of Rs <?= number_format((float)$col['amount'], 2) ?>? This cannot be undone.');">
                                        <?php csrf_field(); ?>
                                        <input type="hidden" name="action" value="delete_payment">
                                        <input type="hidden" name="invoice_id" value="<?= $invoiceId ?>">
                                        <input type="hidden" name="collection_id" value="<?= (int)$col['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger" title="Remove this payment">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if (!empty($invoice['custom_fines'])): ?>
    <div class="card shadow-sm border-0 mb-3">
        <div class="card-header"><strong>Custom Fines</strong></div>
        <div class="card-body p-0">
            <table class="table table-sm table-striped mb-0">
                <thead><tr><th>Type</th><th class="text-end">Amount</th><th>Notes</th></tr></thead>
                <tbody>
                    <?php foreach ($invoice['custom_fines'] as $fine): ?>
                        <tr class="table-danger">
                            <td class="small"><?= h($fine['fine_type']) ?></td>
                            <td class="text-end fw-semibold text-danger">Rs <?= number_format((float)$fine['amount'], 2) ?></td>
                            <td class="text-muted small"><?= h($fine['notes'] ?? '') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

    <?php if (!$isAlreadyPaid): ?>
        <?php if ($remaining <= 0.001): ?>
            <div class="card shadow-sm border-0 mb-3">
                <div class="card-body d-flex flex-wrap align-items-start justify-content-between gap-3">
                    <div>
                        <h6 class="mb-1 text-success"><i class="bi bi-check2-circle me-1"></i> Nothing to collect</h6>
                        <p class="text-muted small mb-0">Fully discounted / waived. Close as paid.</p>
                    </div>
                    <form method="post" action="<?= htmlspecialchars(route_url('fees/collect'), ENT_QUOTES, 'UTF-8') ?>">
                        <?php csrf_field(); ?>
                        <input type="hidden" name="action" value="mark_settled">
                        <input type="hidden" name="invoice_id" value="<?= $invoiceId ?>">
                        <button class="btn btn-success" type="submit">
                            <i class="bi bi-patch-check me-1"></i> Mark as Paid
                        </button>
                    </form>
                </div>
            </div>
        <?php else: ?>
        <div class="row g-3 mb-3">
            <div class="col-lg-8">
                <div class="card shadow-sm border-0">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h6 class="mb-0">Collect by month</h6>
                        <span class="text-muted small">Tick the months being paid now</span>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?= htmlspecialchars(route_url('fees/collect'), ENT_QUOTES, 'UTF-8') ?>" id="collectPaymentForm">
                            <?php csrf_field(); ?>
                            <input type="hidden" name="action" value="record_payment">
                            <input type="hidden" name="invoice_id" value="<?= $invoiceId ?>">

                            <?php if (!empty($lines)): ?>
                            <div class="table-responsive mb-3">
                                <table class="table table-sm align-middle mb-0">
                                    <thead>
                                        <tr>
                                            <th style="width:40px;">
                                                <input type="checkbox" class="form-check-input" id="selectAllMonths" title="Select all unpaid">
                                            </th>
                                            <th>Fee / Month</th>
                                            <th class="text-end">Due</th>
                                            <th class="text-end">Paid</th>
                                            <th class="text-end">Pending</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($lines as $line): ?>
                                            <?php
                                            $lid = (int)$line['id'];
                                            $pendingLine = (float)($line['pending_amount'] ?? $line['line_total'] ?? 0);
                                            $paidLine = (float)($line['paid_amount'] ?? 0);
                                            $isLinePaid = !empty($line['is_paid']) || $pendingLine <= 0.001;
                                            ?>
                                            <tr class="<?= $isLinePaid ? 'table-success' : '' ?>">
                                                <td>
                                                    <?php if (!$isLinePaid): ?>
                                                        <input type="checkbox"
                                                               class="form-check-input month-check"
                                                               name="line_ids[]"
                                                               value="<?= $lid ?>"
                                                               data-pending="<?= number_format($pendingLine, 2, '.', '') ?>">
                                                    <?php else: ?>
                                                        <i class="bi bi-check-lg text-success"></i>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="small fw-semibold"><?= h($line['description'] ?? $line['category_name'] ?? 'Fee') ?></td>
                                                <td class="text-end small">Rs <?= number_format((float)$line['line_total'], 2) ?></td>
                                                <td class="text-end small text-success">Rs <?= number_format($paidLine, 2) ?></td>
                                                <td class="text-end small <?= $pendingLine > 0 ? 'text-danger fw-semibold' : 'text-success' ?>">
                                                    Rs <?= number_format($pendingLine, 2) ?>
                                                </td>
                                                <td>
                                                    <?php if ($isLinePaid): ?>
                                                        <span class="badge bg-success">Paid</span>
                                                    <?php elseif ($paidLine > 0): ?>
                                                        <span class="badge bg-warning text-dark">Partial</span>
                                                    <?php else: ?>
                                                        <span class="badge border" style="background: var(--sms-surface-2, #1f2937); color: var(--sms-text, #e5e7eb);">Unpaid</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="mb-3 d-flex flex-wrap gap-2">
                                <button type="button" class="btn btn-sm btn-outline-secondary" id="btnSelectUnpaid">Select unpaid</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary" id="btnClearMonths">Clear</button>
                            </div>
                            <?php else: ?>
                                <div class="alert alert-light border small">No month lines on this invoice — enter amount manually.</div>
                            <?php endif; ?>

                            <?php if ($showOnBehalfPicker): ?>
                            <div class="mb-3">
                                <label class="form-label">Collecting on behalf of <span class="text-danger">*</span></label>
                                <select class="form-select" name="on_behalf_of_staff_id" required>
                                    <option value="">— Select teacher/staff —</option>
                                    <?php foreach ($onBehalfOptions as $opt): ?>
                                        <?php $sid = (int)$opt['staff_profile_id']; ?>
                                        <option value="<?= $sid ?>" <?= $sid === $onBehalfDefaultStaffId ? 'selected' : '' ?>>
                                            <?= h($opt['full_name']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="form-text">
                                    This payment will count toward that teacher/principal's own fee ledger and balance —
                                    they'll see it as "collected on your behalf" until it's settled through the normal handover process.
                                </div>
                            </div>
                            <?php endif; ?>

                            <div class="row g-3">
                                <div class="col-md-4">
                                    <label class="form-label">Payment Method</label>
                                    <select name="method" class="form-select">
                                        <option value="cash">Cash</option>
                                        <option value="card">Card</option>
                                        <option value="bank">Bank Transfer</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Amount (Rs)</label>
                                    <input class="form-control" name="amount" id="collectAmount" type="number" step="0.01" min="0.01"
                                           value="<?= number_format($remaining, 2, '.', '') ?>" required>
                                    <div class="form-text" id="collectAmountHint">Select months to auto-fill amount</div>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label">Notes (optional)</label>
                                    <input class="form-control" name="notes" placeholder="e.g. Received at counter">
                                </div>
                            </div>

                            <button class="btn btn-success mt-3" type="submit" id="btnRecordPayment">
                                <i class="bi bi-cash-coin me-1"></i> Record Payment for Selected Months
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card shadow-sm border-0">
                    <div class="card-header"><h6 class="mb-0">Add Custom Fine</h6></div>
                    <div class="card-body">
                        <form method="post" action="<?= htmlspecialchars(route_url('fees/collect'), ENT_QUOTES, 'UTF-8') ?>">
                            <?php csrf_field(); ?>
                            <input type="hidden" name="action" value="add_fine">
                            <input type="hidden" name="invoice_id" value="<?= $invoiceId ?>">

                            <div class="mb-3">
                                <label class="form-label">Fine Type *</label>
                                <select name="fine_type" class="form-select" required>
                                    <option value="">-- Select Type --</option>
                                    <option value="Late Coming">Late Coming</option>
                                    <option value="Discipline">Discipline Fine</option>
                                    <option value="Miscellaneous">Miscellaneous</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Amount (Rs) *</label>
                                <input class="form-control" name="fine_amount" type="number" step="0.01" min="0.01" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Reason/Notes</label>
                                <textarea class="form-control" name="fine_notes" rows="2"></textarea>
                            </div>
                            <button class="btn btn-danger w-100" type="submit">
                                <i class="bi bi-exclamation-triangle me-1"></i> Add Fine
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <script>
        (function () {
            const checks = () => Array.from(document.querySelectorAll('.month-check'));
            const amountEl = document.getElementById('collectAmount');
            const hintEl = document.getElementById('collectAmountHint');
            const selectAll = document.getElementById('selectAllMonths');
            const fullRemaining = <?= json_encode(number_format($remaining, 2, '.', '')) ?>;

            function syncAmount() {
                const selected = checks().filter(c => c.checked);
                let sum = 0;
                selected.forEach(c => { sum += parseFloat(c.dataset.pending || '0') || 0; });
                if (selected.length > 0) {
                    amountEl.value = sum.toFixed(2);
                    hintEl.textContent = selected.length + ' month(s) selected — amount set to pending total';
                } else {
                    amountEl.value = fullRemaining;
                    hintEl.textContent = 'No months selected — pays invoice remaining (FIFO across months)';
                }
                if (selectAll) {
                    const unpaid = checks();
                    selectAll.checked = unpaid.length > 0 && unpaid.every(c => c.checked);
                }
            }

            checks().forEach(c => c.addEventListener('change', syncAmount));
            selectAll?.addEventListener('change', function () {
                checks().forEach(c => { c.checked = selectAll.checked; });
                syncAmount();
            });
            document.getElementById('btnSelectUnpaid')?.addEventListener('click', function () {
                checks().forEach(c => { c.checked = true; });
                syncAmount();
            });
            document.getElementById('btnClearMonths')?.addEventListener('click', function () {
                checks().forEach(c => { c.checked = false; });
                syncAmount();
            });

            document.getElementById('collectPaymentForm')?.addEventListener('submit', function (e) {
                const selected = checks().filter(c => c.checked);
                if (checks().length > 0 && selected.length === 0) {
                    if (!confirm('No months selected. Payment will be applied to unpaid months in order (FIFO). Continue?')) {
                        e.preventDefault();
                    }
                }
            });
        })();
        </script>
        <?php endif; ?>
    <?php else: ?>
        <div class="alert alert-success mb-3">
            <i class="bi bi-check-circle-fill me-1"></i>
            This invoice has been <strong>fully paid</strong>. No further action needed.
        </div>
        <?php if (!empty($lines)): ?>
        <div class="card shadow-sm border-0 mb-3">
            <div class="card-header"><strong>Fee Breakdown</strong></div>
            <div class="card-body p-0">
                <table class="table table-sm mb-0">
                    <thead><tr><th>Fee / Month</th><th class="text-end">Total</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php foreach ($lines as $line): ?>
                            <tr>
                                <td class="small"><?= h($line['description'] ?? 'Fee') ?></td>
                                <td class="text-end">Rs <?= number_format((float)$line['line_total'], 2) ?></td>
                                <td><span class="badge bg-success">Paid</span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    <?php endif; ?>

<?php elseif ($invoiceId > 0): ?>
    <div class="card shadow-sm border-0">
        <div class="card-body text-muted">Invoice #<?= $invoiceId ?> not found.</div>
    </div>
<?php else: ?>
    <div class="card shadow-sm border-0">
        <div class="card-body text-muted">Select an invoice above to manage payments and fines.</div>
    </div>
<?php endif; ?>
