<?php
// Variables: $search,$categories,$total,$categoryToEdit,$error
$categoryToEdit = $categoryToEdit ?? null;
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Fee Categories</h1>
        <div class="text-muted small">Manage fee categories used across assignments and invoices.</div>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#categoryModal" onclick="openCreate()">
            + New Category
        </button>
        <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=fees/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
    </div>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<?php
// If editing, auto-open modal with data
$editData = null;
if ($categoryToEdit):
    $editData = $categoryToEdit;
endif;
?>

<!-- Category Table -->
<div class="card shadow-sm border-0">
    <div class="card-body">
        <div class="d-flex align-items-center justify-content-between mb-3">
            <h2 class="h6 mb-0">All Categories <span class="badge bg-secondary ms-1"><?= (int)$total ?></span></h2>
            <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="d-flex gap-2">
            <input type="hidden" name="route" value="fees/categories">
                <input class="form-control form-control-sm" name="q" value="<?= h($search) ?>" placeholder="Search name…" style="width:200px;">
                <button class="btn btn-sm btn-outline-primary" type="submit">Search</button>
                <?php if ($search): ?><a class="btn btn-sm btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=fees/categories'), ENT_QUOTES, 'UTF-8') ?>">Clear</a><?php endif; ?>
            </form>
        </div>
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Type</th>
                        <th style="width:140px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($categories)): ?>
                    <tr><td colspan="4" class="text-muted py-3 text-center">No categories yet. Click <strong>+ New Category</strong> to add one.</td></tr>
                <?php else: ?>
                    <?php foreach ($categories as $c): ?>
                        <tr>
                            <td class="fw-semibold"><?= h($c['name'] ?? '') ?></td>
                            <td class="text-muted small"><?= h($c['description'] ?? '—') ?></td>
                            <td>
                                <?php if (!empty($c['is_one_time'])): ?>
                                    <span class="badge bg-warning text-dark">One-time</span>
                                <?php elseif (!empty($c['is_tuition'])): ?>
                                    <span class="badge bg-primary">Tuition</span>
                                <?php elseif (!empty($c['is_admission'])): ?>
                                    <span class="badge bg-info text-dark">Admission</span>
                                <?php else: ?>
                                    <span class="badge border" style="background: var(--sms-surface-2, #1f2937); color: var(--sms-text, #e5e7eb);">Recurring</span>
                                <?php endif; ?>
                                <?php if (!empty($c['no_discount'])): ?>
                                    <span class="badge bg-danger ms-1">No discount</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary"
                                    onclick="openEdit(<?= (int)$c['id'] ?>, <?= htmlspecialchars(json_encode($c['name'] ?? ''), ENT_QUOTES) ?>, <?= htmlspecialchars(json_encode($c['description'] ?? ''), ENT_QUOTES) ?>, <?= (int)(!empty($c['is_one_time'])) ?>, <?= (int)(!empty($c['is_admission'])) ?>, <?= (int)(!empty($c['is_tuition'])) ?>, <?= (int)($c['sort_order'] ?? 0) ?>, <?= (int)(!empty($c['no_discount'])) ?>)">
                                    Edit
                                </button>
                                <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=fees/categoryDelete'), ENT_QUOTES, 'UTF-8') ?>" class="d-inline" onsubmit="return confirm('Delete category «<?= h(addslashes($c['name'] ?? '')) ?>»?')">
                                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                    <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                                    <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ===== Category Modal ===== -->
<div class="modal fade" id="categoryModal" tabindex="-1" aria-labelledby="categoryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=fees/categories'), ENT_QUOTES, 'UTF-8') ?>" id="categoryForm">
                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                <input type="hidden" name="id" id="modal_id" value="">

                <div class="modal-header">
                    <h5 class="modal-title" id="categoryModalLabel">New Fee Category</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Category Name *</label>
                        <input type="text" class="form-control" name="name" id="modal_name"
                               placeholder="e.g. Tuition Fee, Admission Fee, Lab Fee…" required>
                        <div class="form-text">Type any name freely — no dropdown.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Description</label>
                        <input type="text" class="form-control" name="description" id="modal_description"
                               placeholder="Optional note">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Sort Order</label>
                        <input type="number" class="form-control" name="sort_order" id="modal_sort_order"
                               value="0" min="0" style="width:100px;">
                        <div class="form-text">Lower numbers appear first.</div>
                    </div>
                    <div class="border rounded p-3" style="background: var(--sms-surface-2, #1f2937); border-color: var(--sms-border, #2a3340) !important;">
                        <div class="fw-semibold mb-2 small text-uppercase text-muted">Fee Type Flags</div>
                        <div class="form-check mb-1">
                            <input class="form-check-input" type="checkbox" name="is_one_time" value="1" id="modal_is_one_time">
                            <label class="form-check-label" for="modal_is_one_time">
                                <strong>One-time fee</strong>
                                <span class="text-muted small d-block">Charged only once per student — never duplicated on future invoices.</span>
                            </label>
                        </div>
                        <div class="form-check mb-1">
                            <input class="form-check-input" type="checkbox" name="is_admission" value="1" id="modal_is_admission">
                            <label class="form-check-label" for="modal_is_admission">
                                <strong>Admission fee</strong>
                                <span class="text-muted small d-block">Marks this as an admission-type fee.</span>
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="is_tuition" value="1" id="modal_is_tuition">
                            <label class="form-check-label" for="modal_is_tuition">
                                <strong>Tuition / monthly fee</strong>
                                <span class="text-muted small d-block">Recurring monthly tuition charge.</span>
                            </label>
                        </div>
                    </div>
                    <div class="form-check mt-3">
                        <input class="form-check-input" type="checkbox" name="no_discount" value="1" id="modal_no_discount">
                        <label class="form-check-label" for="modal_no_discount">
                            <strong>Never discount this fee</strong>
                            <span class="text-muted small d-block">Skips this fee entirely when applying a student's discount — it always stays at full price, even for a 100%-discounted student.</span>
                        </label>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="modal_submit_btn">Create Category</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openCreate() {
    document.getElementById('categoryModalLabel').textContent = 'New Fee Category';
    document.getElementById('modal_submit_btn').textContent = 'Create Category';
    document.getElementById('modal_id').value = '';
    document.getElementById('modal_name').value = '';
    document.getElementById('modal_description').value = '';
    document.getElementById('modal_sort_order').value = '0';
    document.getElementById('modal_is_one_time').checked = false;
    document.getElementById('modal_is_admission').checked = false;
    document.getElementById('modal_is_tuition').checked = false;
    document.getElementById('modal_no_discount').checked = false;
}

function openEdit(id, name, description, isOneTime, isAdmission, isTuition, sortOrder, noDiscount) {
    document.getElementById('categoryModalLabel').textContent = 'Edit Fee Category';
    document.getElementById('modal_submit_btn').textContent = 'Save Changes';
    document.getElementById('modal_id').value = id;
    document.getElementById('modal_name').value = name;
    document.getElementById('modal_description').value = description;
    document.getElementById('modal_sort_order').value = sortOrder;
    document.getElementById('modal_is_one_time').checked = isOneTime == 1;
    document.getElementById('modal_is_admission').checked = isAdmission == 1;
    document.getElementById('modal_is_tuition').checked = isTuition == 1;
    document.getElementById('modal_no_discount').checked = noDiscount == 1;
    var modal = new bootstrap.Modal(document.getElementById('categoryModal'));
    modal.show();
}

<?php if ($categoryToEdit): ?>
// Auto-open edit modal if editing via URL
window.addEventListener('DOMContentLoaded', function() {
    openEdit(
        <?= (int)$categoryToEdit['id'] ?>,
        <?= json_encode($categoryToEdit['name'] ?? '') ?>,
        <?= json_encode($categoryToEdit['description'] ?? '') ?>,
        <?= (int)(!empty($categoryToEdit['is_one_time'])) ?>,
        <?= (int)(!empty($categoryToEdit['is_admission'])) ?>,
        <?= (int)(!empty($categoryToEdit['is_tuition'])) ?>,
        <?= (int)($categoryToEdit['sort_order'] ?? 0) ?>,
        <?= (int)(!empty($categoryToEdit['no_discount'])) ?>
    );
});
<?php endif; ?>
</script>
