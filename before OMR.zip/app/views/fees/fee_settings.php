<?php
// Variables: $discountRules,$fineRules,$feeSettingsStudents,$feeSettingsClasses
$feeSettingsStudents = $feeSettingsStudents ?? [];
$feeSettingsClasses  = $feeSettingsClasses  ?? [];
$discountRules = $discountRules ?? [];
$fineRules = $fineRules ?? [];
$settingsUrl = base_url('/index.php?route=fees/feeSettings');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Fee Settings</h1>
        <div class="text-muted">Manage discount and fine rules.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=fees/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="row g-3">
    <div class="col-lg-6">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-3">Create Discount Rule</h2>
                <form method="post" action="<?= htmlspecialchars($settingsUrl, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="action" value="discount_create">

                    <div class="mb-3">
                        <label class="form-label">Name *</label>
                        <input class="form-control" name="name" required>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Is Percent</label>
                            <select class="form-select" name="is_percent">
                                <option value="1" selected>Yes (percent)</option>
                                <option value="0">No (fixed amount)</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Amount *</label>
                            <input class="form-control" name="amount" type="number" step="0.01" min="0" required>
                        </div>
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Start Date</label>
                            <input class="form-control" name="start_date" type="date">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">End Date</label>
                            <input class="form-control" name="end_date" type="date">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <input class="form-control" name="description">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Apply Discount To *</label>
                        <select class="form-select" name="scope_type" id="discount_scope_type" onchange="toggleDiscountScope('discount_scope_type','discount_scope_class','discount_scope_student')">
                            <option value="student" selected>Multiple / Specific Students</option>
                            <option value="class">Entire Class / Section</option>
                            <option value="global">All Students (Global)</option>
                        </select>
                        <div class="form-text">
                            Example: Name = <em>100% Free</em>, Amount = <strong>100</strong>, then tick all free students from any classes.
                            Repeat for 75%, 50%, 25% tiers.
                        </div>
                    </div>
                    <div class="mb-3" id="discount_scope_class" style="display:none;">
                        <label class="form-label">Class / Section</label>
                        <select class="form-select" name="scope_class_section_id">
                            <option value="">— Choose class —</option>
                            <?php foreach ($feeSettingsClasses as $cs): ?>
                                <option value="<?= (int)$cs['id'] ?>">
                                    <?= h(($cs['class_name'] ?? '') . ' — ' . ($cs['section_name'] ?? '')) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3" id="discount_scope_student" style="display:block;">
                        <label class="form-label fw-semibold">Select Students *</label>
                        <div class="mb-2">
                            <select class="form-select form-select-sm" id="discount_class_filter" onchange="filterDiscountStudents()">
                                <option value="0">All classes</option>
                                <?php foreach ($feeSettingsClasses as $cs): ?>
                                    <option value="<?= (int)$cs['id'] ?>">
                                        <?= h(($cs['class_name'] ?? '') . ' — ' . ($cs['section_name'] ?? '')) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="d-flex gap-2 mb-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="toggleVisibleDiscountStudents(true)">Select visible</button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="toggleVisibleDiscountStudents(false)">Clear visible</button>
                            <span class="small text-muted align-self-center" id="discount_selected_count">0 selected</span>
                        </div>
                        <div class="border rounded p-2" style="max-height:260px;overflow-y:auto; background: var(--sms-surface-2, #1f2937); border-color: var(--sms-border, #2a3340) !important;">
                            <?php foreach ($feeSettingsStudents as $st): ?>
                                <?php
                                $sid = (int)$st['id'];
                                $csId = (int)($st['class_section_id'] ?? 0);
                                $label = trim(($st['first_name'] ?? '') . ' ' . ($st['last_name'] ?? ''));
                                $cls = $st['class_label'] ?? 'Unassigned';
                                ?>
                                <label class="d-flex align-items-start gap-2 mb-1 discount-student-row"
                                       data-class="<?= $csId ?>"
                                       style="font-size:.88rem;cursor:pointer;">
                                    <input type="checkbox" class="form-check-input mt-1 discount-student-cb"
                                           name="scope_student_ids[]" value="<?= $sid ?>"
                                           onchange="updateDiscountSelectedCount()">
                                    <span>
                                        <strong><?= h($label) ?></strong>
                                        <span class="text-muted">(<?= h($st['admission_no'] ?? '') ?>)</span>
                                        <br><span class="text-muted small"><?= h($cls) ?></span>
                                    </span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <button class="btn btn-primary w-100" type="submit">Save Discount Rule</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-3">Create Fine Rule</h2>
                <form method="post" action="<?= htmlspecialchars($settingsUrl, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="action" value="fine_create">
                    <div class="mb-3">
                        <label class="form-label">Fine Name *</label>
                        <input class="form-control" name="fine_name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Daily Fine Amount *</label>
                        <input class="form-control" name="daily_fine_amount" type="number" step="0.01" min="0" required value="0">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <input class="form-control" name="fine_description">
                    </div>
                    <button class="btn btn-primary w-100" type="submit">Save Fine Rule</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mt-1">
    <div class="col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Discount Rules</h2>
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0 align-middle">
                        <thead><tr><th>Name</th><th>Amount</th><th>Applies To</th><th>Action</th></tr></thead>
                        <tbody>
                        <?php if (empty($discountRules)): ?>
                            <tr><td colspan="4" class="text-muted">No discount rules.</td></tr>
                        <?php else: ?>
                            <?php foreach ($discountRules as $d): ?>
                                <?php
                                if (!empty($d['student_id'])) {
                                    $scope = '<span class="badge bg-info text-dark">Student: ' . h($d['student_name'] ?? 'ID '.(int)$d['student_id']) . '</span>';
                                    $scopeType = 'student';
                                } elseif (!empty($d['class_section_id'])) {
                                    $scope = '<span class="badge bg-primary">Class: ' . h($d['class_section_name'] ?? 'ID '.(int)$d['class_section_id']) . '</span>';
                                    $scopeType = 'class';
                                } else {
                                    $scope = '<span class="badge bg-secondary">Global</span>';
                                    $scopeType = 'global';
                                }
                                ?>
                                <tr>
                                    <td class="fw-semibold"><?= h($d['name'] ?? '') ?></td>
                                    <td class="text-muted small"><?= h((string)($d['amount'] ?? 0)) ?> <?= !empty($d['is_percent']) ? '%' : 'Rs' ?></td>
                                    <td><?= $scope ?></td>
                                    <td class="text-nowrap">
                                        <button type="button" class="btn btn-sm btn-outline-primary"
                                                data-bs-toggle="modal" data-bs-target="#editDiscountModal"
                                                data-id="<?= (int)$d['id'] ?>"
                                                data-name="<?= h($d['name'] ?? '') ?>"
                                                data-is-percent="<?= (int)($d['is_percent'] ?? 1) ?>"
                                                data-amount="<?= h((string)($d['amount'] ?? 0)) ?>"
                                                data-start="<?= h($d['start_date'] ?? '') ?>"
                                                data-end="<?= h($d['end_date'] ?? '') ?>"
                                                data-description="<?= h($d['description'] ?? '') ?>"
                                                data-scope="<?= h($scopeType) ?>"
                                                data-student="<?= (int)($d['student_id'] ?? 0) ?>"
                                                data-class="<?= (int)($d['class_section_id'] ?? 0) ?>">
                                            Edit
                                        </button>
                                        <form method="post" action="<?= htmlspecialchars($settingsUrl, ENT_QUOTES, 'UTF-8') ?>"
                                              onsubmit="return confirm('Delete this discount rule?')" class="d-inline">
                                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                            <input type="hidden" name="action" value="discount_delete">
                                            <input type="hidden" name="discount_id" value="<?= (int)$d['id'] ?>">
                                            <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Fine Rules</h2>
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0 align-middle">
                        <thead><tr><th>Name</th><th>Daily Fine</th><th>Action</th></tr></thead>
                        <tbody>
                        <?php if (empty($fineRules)): ?>
                            <tr><td colspan="3" class="text-muted">No fine rules.</td></tr>
                        <?php else: ?>
                            <?php foreach ($fineRules as $f): ?>
                                <tr>
                                    <td class="fw-semibold"><?= h($f['name'] ?? '') ?></td>
                                    <td class="text-muted small"><?= h((string)($f['daily_fine_amount'] ?? 0)) ?></td>
                                    <td class="text-nowrap">
                                        <button type="button" class="btn btn-sm btn-outline-primary"
                                                data-bs-toggle="modal" data-bs-target="#editFineModal"
                                                data-id="<?= (int)$f['id'] ?>"
                                                data-name="<?= h($f['name'] ?? '') ?>"
                                                data-amount="<?= h((string)($f['daily_fine_amount'] ?? 0)) ?>"
                                                data-description="<?= h($f['description'] ?? '') ?>">
                                            Edit
                                        </button>
                                        <form method="post" action="<?= htmlspecialchars($settingsUrl, ENT_QUOTES, 'UTF-8') ?>"
                                              onsubmit="return confirm('Delete this fine rule?')" class="d-inline">
                                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                            <input type="hidden" name="action" value="fine_delete">
                                            <input type="hidden" name="fine_id" value="<?= (int)$f['id'] ?>">
                                            <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Discount Modal -->
<div class="modal fade" id="editDiscountModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form method="post" action="<?= htmlspecialchars($settingsUrl, ENT_QUOTES, 'UTF-8') ?>">
        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
        <input type="hidden" name="action" value="discount_create">
        <input type="hidden" name="discount_id" id="edit_discount_id" value="">
        <div class="modal-header">
          <h5 class="modal-title">Edit Discount Rule</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Name *</label>
            <input class="form-control" name="name" id="edit_discount_name" required>
          </div>
          <div class="row g-2 mb-3">
            <div class="col-md-6">
              <label class="form-label">Is Percent</label>
              <select class="form-select" name="is_percent" id="edit_discount_is_percent">
                <option value="1">Yes (percent)</option>
                <option value="0">No (fixed amount)</option>
              </select>
            </div>
            <div class="col-md-6">
              <label class="form-label">Amount *</label>
              <input class="form-control" name="amount" id="edit_discount_amount" type="number" step="0.01" min="0" required>
            </div>
          </div>
          <div class="row g-2 mb-3">
            <div class="col-md-6">
              <label class="form-label">Start Date</label>
              <input class="form-control" name="start_date" id="edit_discount_start" type="date">
            </div>
            <div class="col-md-6">
              <label class="form-label">End Date</label>
              <input class="form-control" name="end_date" id="edit_discount_end" type="date">
            </div>
          </div>
          <div class="mb-3">
            <label class="form-label">Description</label>
            <input class="form-control" name="description" id="edit_discount_description">
          </div>
          <div class="mb-3">
            <label class="form-label fw-semibold">Apply Discount To *</label>
            <select class="form-select" name="scope_type" id="edit_discount_scope" onchange="toggleDiscountScope('edit_discount_scope','edit_discount_scope_class','edit_discount_scope_student')">
              <option value="global">All Students (Global)</option>
              <option value="class">Specific Class / Section</option>
              <option value="student">Specific Student</option>
            </select>
          </div>
          <div class="mb-3" id="edit_discount_scope_class" style="display:none;">
            <label class="form-label">Class / Section</label>
            <select class="form-select" name="scope_class_section_id" id="edit_discount_class">
              <option value="">— Choose class —</option>
              <?php foreach ($feeSettingsClasses as $cs): ?>
                <option value="<?= (int)$cs['id'] ?>"><?= h(($cs['class_name'] ?? '') . ' — ' . ($cs['section_name'] ?? '')) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3" id="edit_discount_scope_student" style="display:none;">
            <label class="form-label">Student</label>
            <select class="form-select" name="scope_student_id" id="edit_discount_student">
              <option value="">— Choose student —</option>
              <?php foreach ($feeSettingsStudents as $st): ?>
                <option value="<?= (int)$st['id'] ?>"><?= h(($st['first_name'] ?? '') . ' ' . ($st['last_name'] ?? '') . ' (' . ($st['admission_no'] ?? '') . ')') ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Update Discount</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Edit Fine Modal -->
<div class="modal fade" id="editFineModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form method="post" action="<?= htmlspecialchars($settingsUrl, ENT_QUOTES, 'UTF-8') ?>">
        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
        <input type="hidden" name="action" value="fine_create">
        <input type="hidden" name="fine_id" id="edit_fine_id" value="">
        <div class="modal-header">
          <h5 class="modal-title">Edit Fine Rule</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">Fine Name *</label>
            <input class="form-control" name="fine_name" id="edit_fine_name" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Daily Fine Amount *</label>
            <input class="form-control" name="daily_fine_amount" id="edit_fine_amount" type="number" step="0.01" min="0" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Description</label>
            <input class="form-control" name="fine_description" id="edit_fine_description">
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Update Fine Rule</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function toggleDiscountScope(selectId, classId, studentId) {
    var val = document.getElementById(selectId).value;
    document.getElementById(classId).style.display = val === 'class' ? '' : 'none';
    document.getElementById(studentId).style.display = val === 'student' ? '' : 'none';
}

function filterDiscountStudents() {
    var cs = document.getElementById('discount_class_filter').value;
    document.querySelectorAll('.discount-student-row').forEach(function (row) {
        var rowCs = row.getAttribute('data-class') || '0';
        row.style.display = (cs === '0' || rowCs === cs) ? '' : 'none';
    });
}

function toggleVisibleDiscountStudents(check) {
    document.querySelectorAll('.discount-student-row').forEach(function (row) {
        if (row.style.display === 'none') return;
        var cb = row.querySelector('.discount-student-cb');
        if (cb) cb.checked = !!check;
    });
    updateDiscountSelectedCount();
}

function updateDiscountSelectedCount() {
    var n = document.querySelectorAll('.discount-student-cb:checked').length;
    var el = document.getElementById('discount_selected_count');
    if (el) el.textContent = n + ' selected';
}

document.getElementById('editDiscountModal')?.addEventListener('show.bs.modal', function (event) {
    var btn = event.relatedTarget;
    if (!btn) return;
    document.getElementById('edit_discount_id').value = btn.getAttribute('data-id') || '';
    document.getElementById('edit_discount_name').value = btn.getAttribute('data-name') || '';
    document.getElementById('edit_discount_is_percent').value = btn.getAttribute('data-is-percent') || '1';
    document.getElementById('edit_discount_amount').value = btn.getAttribute('data-amount') || '';
    document.getElementById('edit_discount_start').value = btn.getAttribute('data-start') || '';
    document.getElementById('edit_discount_end').value = btn.getAttribute('data-end') || '';
    document.getElementById('edit_discount_description').value = btn.getAttribute('data-description') || '';
    document.getElementById('edit_discount_scope').value = btn.getAttribute('data-scope') || 'global';
    document.getElementById('edit_discount_student').value = btn.getAttribute('data-student') || '';
    document.getElementById('edit_discount_class').value = btn.getAttribute('data-class') || '';
    toggleDiscountScope('edit_discount_scope','edit_discount_scope_class','edit_discount_scope_student');
});

document.getElementById('editFineModal')?.addEventListener('show.bs.modal', function (event) {
    var btn = event.relatedTarget;
    if (!btn) return;
    document.getElementById('edit_fine_id').value = btn.getAttribute('data-id') || '';
    document.getElementById('edit_fine_name').value = btn.getAttribute('data-name') || '';
    document.getElementById('edit_fine_amount').value = btn.getAttribute('data-amount') || '';
    document.getElementById('edit_fine_description').value = btn.getAttribute('data-description') || '';
});

updateDiscountSelectedCount();
</script>
