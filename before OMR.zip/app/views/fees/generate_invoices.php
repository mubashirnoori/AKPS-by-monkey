<?php
// Variables: $mode, $feeCategories, $classSections, $students, $academicYears, $studentData, $error,
//            $selectedAcademicYearId, $prefillStudentId, $prefillClassSectionId, $classCounts, $invoicedMap
$mode = in_array(($mode ?? 'student'), ['student', 'class', 'onetime'], true) ? $mode : 'student';
$studentData = $studentData ?? null;
$error = $error ?? null;
$selectedAcademicYearId = (int)($selectedAcademicYearId ?? 0);
$prefillStudentId = (int)($prefillStudentId ?? 0);
$prefillClassSectionId = (int)($prefillClassSectionId ?? 0);
$classCounts = $classCounts ?? [];
$invoicedMap = $invoicedMap ?? [];
$academicYears = $academicYears ?? [];
$feeCategories = $feeCategories ?? [];
$classSections = $classSections ?? [];
$oneTimeFeeOptions = $oneTimeFeeOptions ?? [];
$billingMonthOptions = $billingMonthOptions ?? [];
$baseGen = route_url('fees/generateInvoices');
$jsonFlags = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;

$postMonths = array_map('intval', (array)($_POST['selected_months'] ?? []));
$postAdmission = !empty($_POST['include_admission']);
$postDup = !empty($_POST['allow_duplicate_admission']);

$studentsJson = [];
foreach (($students ?? []) as $st) {
    $studentsJson[] = [
        'id' => (int)$st['id'],
        'name' => trim(($st['first_name'] ?? '') . ' ' . ($st['last_name'] ?? '')),
        'adm' => (string)($st['admission_no'] ?? ''),
        'roll' => (string)($st['roll_number'] ?? ''),
        'cls' => trim((string)($st['current_class_name'] ?? '') . ' ' . (string)($st['current_section_name'] ?? '')),
        'inv' => $invoicedMap[(int)$st['id']] ?? [],
    ];
}
$yearsJson = [];
foreach ($academicYears as $y) {
    $yearsJson[(int)$y['id']] = (string)($y['start_date'] ?? '');
}
$classesJson = [];
foreach ($classSections as $cs) {
    $classesJson[(int)$cs['id']] = [
        'label' => ($cs['class_name'] ?? '') . ' — ' . ($cs['section_name'] ?? ''),
        'count' => (int)($classCounts[(int)$cs['id']] ?? 0),
    ];
}
?>
<style>
    .gi-modes { display: grid; grid-template-columns: repeat(3, 1fr); gap: .6rem; }
    @media (max-width: 720px) { .gi-modes { grid-template-columns: 1fr; } }
    .gi-mode { display: block; text-decoration: none; color: inherit; border: 1px solid var(--sms-input-border, #374151); border-radius: 12px; padding: .75rem 1rem; }
    .gi-mode:hover { border-color: var(--sms-primary, #b8873e); color: inherit; }
    .gi-mode.active { border-color: var(--sms-primary, #b8873e); background: rgba(184,135,62,.15); }
    .gi-mode .t { font-weight: 700; }
    .gi-mode .d { font-size: .82rem; color: var(--sms-muted, #8b95a5); }

    .gi-step { display: flex; gap: .85rem; padding: 1.1rem 0; border-top: 1px solid var(--sms-border, #2a3340); }
    .gi-step:first-of-type { border-top: 0; }
    .gi-num { flex: 0 0 30px; height: 30px; border-radius: 50%; background: var(--sms-primary, #b8873e); color: #fff; font-weight: 700; display: flex; align-items: center; justify-content: center; margin-top: 2px; }
    .gi-body { flex: 1; min-width: 0; }
    .gi-title { font-weight: 700; margin-bottom: .45rem; }

    .gi-picked { display: flex; align-items: center; gap: .75rem; border: 1px solid var(--sms-primary, #b8873e); background: rgba(184,135,62,.12); border-radius: 10px; padding: .55rem .85rem; }
    .gi-results { border: 1px solid var(--sms-input-border, #374151); border-radius: 10px; margin-top: .35rem; max-height: 260px; overflow: auto; background: var(--sms-surface, #1b2432); }
    .gi-result { display: flex; justify-content: space-between; gap: .75rem; width: 100%; text-align: left; background: none; border: 0; color: inherit; padding: .5rem .8rem; border-bottom: 1px solid var(--sms-border, #2a3340); }
    .gi-result:last-child { border-bottom: 0; }
    .gi-result:hover, .gi-result:focus { background: rgba(184,135,62,.18); outline: none; }
    .gi-result small { color: var(--sms-muted, #8b95a5); }

    .gi-months { display: grid; grid-template-columns: repeat(6, 1fr); gap: .5rem; }
    @media (max-width: 575px) { .gi-months { grid-template-columns: repeat(4, 1fr); } }
    .gi-chip input { position: absolute; opacity: 0; pointer-events: none; }
    .gi-chip span { display: flex; flex-direction: column; align-items: center; padding: .5rem .25rem; border: 1px solid var(--sms-input-border, #374151); border-radius: 10px; cursor: pointer; line-height: 1.15; user-select: none; }
    .gi-chip span b { font-size: 1rem; }
    .gi-chip span small { font-size: .72rem; color: var(--sms-muted, #8b95a5); }
    .gi-chip input:checked + span { background: var(--sms-primary, #b8873e); border-color: var(--sms-primary, #b8873e); color: #fff; }
    .gi-chip input:checked + span small { color: rgba(255,255,255,.85); }
    .gi-chip input:focus-visible + span { outline: 2px solid var(--sms-primary, #b8873e); outline-offset: 2px; }
    .gi-chip input:disabled + span { cursor: not-allowed; opacity: .55; background: repeating-linear-gradient(45deg, transparent 0 6px, rgba(255,255,255,.05) 6px 12px); }
    .gi-chip input:disabled + span small { color: #4ade80; }

    .gi-bar { position: sticky; bottom: 0; background: var(--sms-surface, #1b2432); border-top: 1px solid var(--sms-border, #2a3340); margin: 0 -1rem -1rem; padding: .85rem 1rem; display: flex; align-items: center; gap: 1rem; flex-wrap: wrap; border-radius: 0 0 12px 12px; }
    .gi-bar .sum { flex: 1; min-width: 220px; font-size: .95rem; }
</style>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">Generate Invoices</h1>
        <p class="text-muted small mb-0">Pick who, pick the months, check the summary, generate.</p>
    </div>
    <a class="btn btn-outline-secondary" href="<?= h(route_url('fees/invoices')) ?>">← Invoice List</a>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="gi-modes mb-3">
    <a class="gi-mode <?= $mode === 'student' ? 'active' : '' ?>" href="<?= h($baseGen . '&mode=student') ?>">
        <div class="t">One student</div>
        <div class="d">Monthly fees for a single student</div>
    </a>
    <a class="gi-mode <?= $mode === 'class' ? 'active' : '' ?>" href="<?= h($baseGen . '&mode=class') ?>">
        <div class="t">Whole class</div>
        <div class="d">Monthly fees for every student in a class</div>
    </a>
    <a class="gi-mode <?= $mode === 'onetime' ? 'active' : '' ?>" href="<?= h($baseGen . '&mode=onetime') ?>">
        <div class="t">One-time fee</div>
        <div class="d">Exam fee, admission etc. for a class</div>
    </a>
</div>

<?php if ($mode === 'onetime'): ?>
<!-- ===================== ONE-TIME FEE ===================== -->
<div class="card shadow-sm border-0 mb-3">
    <div class="card-body pb-3">
        <form method="post" action="<?= h(route_url('fees/applyOneTimeFee')) ?>" id="giOneForm">
            <?php csrf_field(); ?>
            <div class="gi-step">
                <div class="gi-num">1</div>
                <div class="gi-body">
                    <div class="gi-title">Which class?</div>
                    <select name="class_section_id" id="giOneClass" required class="form-select" style="max-width:360px;">
                        <option value="">— Choose class —</option>
                        <?php foreach ($classSections as $cs): $cid = (int)$cs['id']; ?>
                            <option value="<?= $cid ?>" <?= $prefillClassSectionId === $cid ? 'selected' : '' ?>>
                                <?= h(($cs['class_name'] ?? '') . ' — ' . ($cs['section_name'] ?? '')) ?> (<?= (int)($classCounts[$cid] ?? 0) ?> students)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="gi-step">
                <div class="gi-num">2</div>
                <div class="gi-body">
                    <div class="gi-title">Which fee?</div>
                    <select name="fee_category_id" id="giOneFee" required class="form-select" style="max-width:360px;">
                        <option value="">— Choose fee —</option>
                        <?php foreach ($feeCategories as $fc): if (empty($fc['is_one_time'])) { continue; } ?>
                            <option value="<?= (int)$fc['id'] ?>"><?= h($fc['name'] ?? '') ?><?= !empty($fc['no_discount']) ? ' (no discount)' : '' ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="mt-2" id="giOneLabelWrap" style="display:none;">
                        <select name="fee_label" id="giOneLabel" class="form-select" style="max-width:360px;"></select>
                        <div class="form-text" id="giOneLabelHelp"></div>
                    </div>
                    <div class="form-text">
                        Only fees marked “one-time” are listed. A fee can have several versions (for example First Term and
                        Final Term exam fee); each has its own amount under
                        <a href="<?= h(route_url('fees/assignments')) ?>">Fee Assignments</a>.
                        Anyone already charged the same fee this year is skipped.
                    </div>
                    <div class="form-check mt-2">
                        <input type="checkbox" class="form-check-input" name="allow_duplicate" value="1" id="giOneDup">
                        <label class="form-check-label" for="giOneDup">Charge again even if already invoiced for this fee</label>
                    </div>
                    <input type="hidden" name="academic_year_id" value="<?= (int)$selectedAcademicYearId ?>">
                </div>
            </div>
            <div class="gi-step">
                <div class="gi-num">3</div>
                <div class="gi-body">
                    <div class="gi-title">Bill it with which month?</div>
                    <select name="billing_month" id="giOneMonth" class="form-select" style="max-width:360px;">
                        <option value="">Latest open invoice (no month)</option>
                        <?php foreach ($billingMonthOptions as $bm):
                            $isNow = (int)$bm['month'] === (int)date('n') && (int)$bm['year'] === (int)date('Y'); ?>
                            <option value="<?= (int)$bm['month'] ?>" <?= $isNow ? 'selected' : '' ?>><?= h($bm['label']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text">
                        The fee goes on that month's invoice if it is still open. If that month is already paid, it gets its own
                        invoice for that month. It is never added to a different month's invoice.
                    </div>
                </div>
            </div>
            <div class="gi-bar">
                <div class="sum" id="giOneSum">Choose a class and a fee.</div>
                <button type="submit" class="btn btn-success px-4" id="giOneBtn" disabled>Apply fee to class</button>
            </div>
        </form>
    </div>
</div>
<script>
(function () {
    var CLASSES = <?= json_encode($classesJson, $jsonFlags) ?>;
    var FEES = <?= json_encode($oneTimeFeeOptions, $jsonFlags) ?>;
    var c = document.getElementById('giOneClass'), f = document.getElementById('giOneFee');
    var l = document.getElementById('giOneLabel'), lw = document.getElementById('giOneLabelWrap'), lh = document.getElementById('giOneLabelHelp');
    var m = document.getElementById('giOneMonth');
    var sum = document.getElementById('giOneSum'), btn = document.getElementById('giOneBtn');

    function money(n) { return 'Rs ' + Number(n).toLocaleString('en-US'); }
    // Fees (by label) that have an amount for this class; a class amount beats an "everyone" amount.
    function feesFor(classId, catId) {
        var byLabel = {};
        FEES.forEach(function (o) {
            if (String(o.fee_category_id) !== String(catId)) { return; }
            if (o.class_section_id !== null && String(o.class_section_id) !== String(classId)) { return; }
            var k = o.label.toLowerCase();
            if (!byLabel[k] || o.class_section_id !== null) { byLabel[k] = o; }
        });
        return Object.keys(byLabel).map(function (k) { return byLabel[k]; });
    }
    function fillLabels() {
        var keep = l.value;
        l.innerHTML = '';
        lw.style.display = 'none';
        if (!c.value || !f.value) { return; }
        var list = feesFor(c.value, f.value);
        lw.style.display = '';
        if (!list.length) {
            lh.textContent = 'No amount is set for this fee in this class yet. Add it under Fee Assignments first.';
            return;
        }
        lh.textContent = list.length > 1 ? 'This fee has several versions. Pick the one to charge.' : '';
        list.forEach(function (o) {
            var opt = document.createElement('option');
            opt.value = o.label;
            opt.textContent = (o.label || '(no label)') + ' \u2014 ' + money(o.amount);
            opt.setAttribute('data-amount', o.amount);
            if (o.label === keep) { opt.selected = true; }
            l.appendChild(opt);
        });
    }
    function when() { return m.value ? m.options[m.selectedIndex].text : 'the latest open invoice'; }
    function upd() {
        var ok = !!(c.value && f.value && l.options.length > 0);
        sum.textContent = '';
        if (!ok) {
            sum.textContent = 'Choose a class and a fee.';
        } else {
            // textContent only: labels are free text and must never be parsed as HTML.
            var parts = [[l.value || f.options[f.selectedIndex].text, 1], [' \u2192 all ', 0], [CLASSES[c.value].count, 1],
                         [' students of ', 0], [CLASSES[c.value].label, 1], [', billed with ', 0], [when(), 1]];
            parts.forEach(function (p) {
                var node = p[1] ? document.createElement('strong') : document.createElement('span');
                node.textContent = p[0];
                sum.appendChild(node);
            });
        }
        btn.disabled = !ok;
    }
    c.addEventListener('change', function () { fillLabels(); upd(); });
    f.addEventListener('change', function () { fillLabels(); upd(); });
    l.addEventListener('change', upd); m.addEventListener('change', upd);
    fillLabels(); upd();
    document.getElementById('giOneForm').addEventListener('submit', function (e) {
        var o = l.options[l.selectedIndex];
        var msg = 'Charge "' + (l.value || f.options[f.selectedIndex].text) + '" (' + money(o.getAttribute('data-amount')) + ') to every active student of '
                + CLASSES[c.value].label + ', billed with ' + when() + '?';
        if (!confirm(msg)) { e.preventDefault(); }
    });
})();
</script>

<?php else: ?>
<!-- ===================== MONTHLY FEES (student / class) ===================== -->
<div class="card shadow-sm border-0 mb-3">
    <div class="card-body pb-3">
        <form method="post" action="<?= h($baseGen . '&mode=' . rawurlencode($mode)) ?>" id="giForm" autocomplete="off">
            <?php csrf_field(); ?>
            <input type="hidden" name="mode" value="<?= h($mode) ?>">

            <!-- 1: who -->
            <div class="gi-step">
                <div class="gi-num">1</div>
                <div class="gi-body">
                    <?php if ($mode === 'student'): ?>
                        <div class="gi-title">Which student?</div>
                        <input type="hidden" name="student_id" id="giStudentId" value="<?= $prefillStudentId > 0 ? $prefillStudentId : '' ?>">
                        <div id="giPicked" class="gi-picked" style="display:none;">
                            <div class="flex-grow-1">
                                <div class="fw-semibold" id="giPickedName"></div>
                                <div class="small text-muted" id="giPickedMeta"></div>
                            </div>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="giChange">Change</button>
                        </div>
                        <div id="giSearchWrap">
                            <input type="search" id="giSearch" class="form-control" style="max-width:480px;"
                                   placeholder="Type name, admission no. or class…" autofocus>
                            <div class="gi-results" id="giResults" style="display:none;max-width:480px;"></div>
                        </div>
                    <?php else: ?>
                        <div class="gi-title">Which class?</div>
                        <select name="class_section_id" id="giClass" required class="form-select" style="max-width:360px;">
                            <option value="">— Choose class —</option>
                            <?php foreach ($classSections as $cs): $cid = (int)$cs['id']; ?>
                                <option value="<?= $cid ?>" <?= $prefillClassSectionId === $cid ? 'selected' : '' ?>>
                                    <?= h(($cs['class_name'] ?? '') . ' — ' . ($cs['section_name'] ?? '')) ?> (<?= (int)($classCounts[$cid] ?? 0) ?> students)
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="form-text">Every active student in this class gets an invoice. Months a student already has are skipped automatically.</div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- 2: months -->
            <div class="gi-step">
                <div class="gi-num">2</div>
                <div class="gi-body">
                    <div class="d-flex flex-wrap align-items-center gap-2 mb-2">
                        <div class="gi-title mb-0 me-2">Which months?</div>
                        <select name="academic_year_id" id="giYear" class="form-select form-select-sm" style="width:auto;" title="Academic year">
                            <option value="0">No academic year</option>
                            <?php foreach ($academicYears as $y): ?>
                                <option value="<?= (int)$y['id'] ?>" <?= (int)$y['id'] === $selectedAcademicYearId ? 'selected' : '' ?>>
                                    <?= h($y['academic_year_label'] ?? '') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <span class="ms-auto d-flex gap-1">
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="giAll">Whole year</button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="giToNow">Up to this month</button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="giNone">Clear</button>
                        </span>
                    </div>
                    <div class="gi-months" id="giMonths"></div>
                    <div class="form-text" id="giMonthNote"></div>

                    <details class="mt-3" <?= ($postAdmission || $postDup) ? 'open' : '' ?>>
                        <summary class="small text-muted" style="cursor:pointer;">Also charge admission / one-time fee</summary>
                        <div class="mt-2">
                            <div class="form-check">
                                <input type="checkbox" name="include_admission" value="1" class="form-check-input" id="giAdm" <?= $postAdmission ? 'checked' : '' ?>>
                                <label class="form-check-label" for="giAdm">Include admission / one-time fee on these invoices</label>
                            </div>
                            <div class="form-check">
                                <input type="checkbox" name="allow_duplicate_admission" value="1" class="form-check-input" id="giDup" <?= $postDup ? 'checked' : '' ?>>
                                <label class="form-check-label" for="giDup">Charge it again even if it was already invoiced</label>
                            </div>
                        </div>
                    </details>
                </div>
            </div>

            <?php if ($studentData && $mode === 'student'): ?>
                <div class="alert alert-info py-2 small mb-0">
                    Outstanding for <?= h(trim(($studentData['student']['first_name'] ?? '') . ' ' . ($studentData['student']['last_name'] ?? ''))) ?>:
                    <strong>Rs. <?= number_format((float)$studentData['balance'], 2) ?></strong>
                    · Pending invoices: <?= (int)($studentData['summary']['pending_invoices'] ?? 0) ?>
                    · Paid so far: Rs. <?= number_format((float)($studentData['summary']['total_paid'] ?? 0), 2) ?>
                </div>
            <?php endif; ?>

            <!-- summary + submit -->
            <div class="gi-bar mt-3">
                <div class="sum" id="giSum">Choose <?= $mode === 'class' ? 'a class' : 'a student' ?> and the months.</div>
                <button type="submit" class="btn <?= $mode === 'class' ? 'btn-success' : 'btn-primary' ?> px-4" id="giBtn" disabled>
                    <?= $mode === 'class' ? 'Generate for whole class' : 'Generate invoices' ?>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
(function () {
    var MODE = <?= json_encode($mode) ?>;
    var STUDENTS = <?= json_encode($studentsJson, $jsonFlags) ?>;
    var YEARS = <?= json_encode($yearsJson, $jsonFlags) ?>;       // academic year id -> start date
    var CLASSES = <?= json_encode($classesJson, $jsonFlags) ?>;
    var NAMES = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    var checked = {};
    <?php foreach ($postMonths as $pm): ?>checked[<?= (int)$pm ?>] = true;
    <?php endforeach; ?>

    var $ = function (id) { return document.getElementById(id); };
    var yearSel = $('giYear'), monthsBox = $('giMonths');
    var student = null;

    function esc(t) { var d = document.createElement('div'); d.textContent = t == null ? '' : String(t); return d.innerHTML; }

    function monthList() {
        var start = YEARS[yearSel.value] || '';
        var startMonth = 1, startYear = 0;
        if (start) { startMonth = parseInt(start.substr(5, 2), 10); startYear = parseInt(start.substr(0, 4), 10); }
        var out = [];
        for (var i = 0; i < 12; i++) {
            var m = ((startMonth - 1 + i) % 12) + 1;
            var yr = start ? (m >= startMonth ? startYear : startYear + 1) : 0;
            out.push({ m: m, y: yr });
        }
        return out;
    }
    function invoicedSet() {
        var set = {};
        if (MODE === 'student' && student) {
            student.inv.forEach(function (k) {
                var p = k.split('-');
                if (p[0] === yearSel.value) { set[parseInt(p[1], 10)] = true; }
            });
        }
        return set;
    }

    function renderMonths() {
        var inv = invoicedSet(), html = '', invCount = 0;
        monthList().forEach(function (o) {
            var isInv = !!inv[o.m];
            if (isInv) { invCount++; delete checked[o.m]; }
            html += '<label class="gi-chip"><input type="checkbox" name="selected_months[]" value="' + o.m + '"' +
                (checked[o.m] ? ' checked' : '') + (isInv ? ' disabled' : '') + '><span><b>' + NAMES[o.m - 1] + '</b><small>' +
                (isInv ? '✓ invoiced' : (o.y || '')) + '</small></span></label>';
        });
        monthsBox.innerHTML = html;
        $('giMonthNote').textContent = invCount
            ? invCount + ' month' + (invCount === 1 ? ' is' : 's are') + ' already invoiced for this student and cannot be selected again.'
            : (MODE === 'class' ? 'Months a student already has will be skipped for that student.' : '');
        refresh();
    }

    function selectedMonths() {
        var arr = [];
        monthsBox.querySelectorAll('input:checked').forEach(function (c) { arr.push(parseInt(c.value, 10)); });
        return arr;
    }
    function label(m) {
        var o = monthList().filter(function (x) { return x.m === m; })[0];
        return NAMES[m - 1] + (o && o.y ? ' ' + o.y : '');
    }

    function refresh() {
        var months = selectedMonths();
        var adm = $('giAdm').checked;
        var who = '', whoOk = false;
        if (MODE === 'student') {
            whoOk = !!student; who = student ? '<strong>' + esc(student.name) + '</strong>' : '';
        } else {
            var cid = $('giClass').value;
            whoOk = !!cid;
            who = cid ? 'all <strong>' + CLASSES[cid].count + '</strong> students of <strong>' + esc(CLASSES[cid].label) + '</strong>' : '';
        }
        var what = months.length ? months.map(label).join(', ') : '';
        if (adm) { what += (what ? ' + ' : '') + 'admission fee'; }
        var ok = whoOk && (months.length > 0 || adm);
        $('giSum').innerHTML = ok
            ? 'Creating invoices for <strong>' + esc(what) + '</strong> → ' + who
            : (whoOk ? 'Now pick at least one month.' : 'Choose ' + (MODE === 'class' ? 'a class' : 'a student') + ' and the months.');
        $('giBtn').disabled = !ok;
    }

    monthsBox.addEventListener('change', function (e) {
        var c = e.target;
        if (c && c.value) { if (c.checked) { checked[c.value] = true; } else { delete checked[c.value]; } }
        refresh();
    });
    yearSel.addEventListener('change', renderMonths);
    $('giAdm').addEventListener('change', refresh);
    $('giAll').addEventListener('click', function () {
        var inv = invoicedSet();
        monthList().forEach(function (o) { if (!inv[o.m]) { checked[o.m] = true; } });
        renderMonths();
    });
    $('giNone').addEventListener('click', function () { checked = {}; renderMonths(); });
    $('giToNow').addEventListener('click', function () {
        var inv = invoicedSet(), now = new Date(), nowKey = now.getFullYear() * 100 + (now.getMonth() + 1);
        checked = {};
        monthList().forEach(function (o) {
            var key = (o.y || now.getFullYear()) * 100 + o.m;
            if (key <= nowKey && !inv[o.m]) { checked[o.m] = true; }
        });
        renderMonths();
    });

    if (MODE === 'student') {
        var search = $('giSearch'), results = $('giResults');
        function pick(s) {
            student = s;
            $('giStudentId').value = s.id;
            $('giPickedName').textContent = s.name;
            $('giPickedMeta').textContent = [s.adm ? 'Adm ' + s.adm : '', s.roll ? 'Roll ' + s.roll : '', s.cls].filter(Boolean).join(' · ');
            $('giPicked').style.display = '';
            $('giSearchWrap').style.display = 'none';
            results.style.display = 'none';
            renderMonths();
        }
        function find() {
            var q = search.value.trim().toLowerCase();
            if (!q) { results.style.display = 'none'; return; }
            var words = q.split(/\s+/), out = [];
            for (var i = 0; i < STUDENTS.length && out.length < 12; i++) {
                var s = STUDENTS[i], hay = (s.name + ' ' + s.adm + ' ' + s.cls + ' ' + s.roll).toLowerCase();
                if (words.every(function (w) { return hay.indexOf(w) !== -1; })) { out.push(s); }
            }
            results.innerHTML = out.length ? out.map(function (s) {
                return '<button type="button" class="gi-result" data-id="' + s.id + '"><span>' + esc(s.name) + '</span><small>' +
                    esc((s.adm ? s.adm + ' · ' : '') + s.cls) + '</small></button>';
            }).join('') : '<div class="p-2 small text-muted">No student found.</div>';
            results.style.display = '';
        }
        search.addEventListener('input', find);
        results.addEventListener('click', function (e) {
            var b = e.target.closest('.gi-result');
            if (!b) { return; }
            var id = parseInt(b.getAttribute('data-id'), 10);
            STUDENTS.forEach(function (s) { if (s.id === id) { pick(s); } });
        });
        $('giChange').addEventListener('click', function () {
            student = null; $('giStudentId').value = '';
            $('giPicked').style.display = 'none'; $('giSearchWrap').style.display = '';
            search.value = ''; search.focus(); renderMonths();
        });
        var pre = parseInt($('giStudentId').value || '0', 10);
        if (pre) { STUDENTS.forEach(function (s) { if (s.id === pre) { student = s; } }); }
        if (student) { pick(student); }
    } else {
        $('giClass').addEventListener('change', refresh);
    }

    $('giForm').addEventListener('submit', function (e) {
        if (MODE === 'class' && !confirm('Generate invoices for ALL students in ' + CLASSES[$('giClass').value].label + '?')) { e.preventDefault(); }
    });

    renderMonths();
})();
</script>
<?php endif; ?>
