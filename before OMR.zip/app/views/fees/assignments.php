<?php
// Variables: $feeCategories, $classSections, $students, $assignments, $academicYears,
//            $feeGrid ['class'][class_section_id][category_id] => amount, ['global'][category_id] => amount,
//            $currentYearId, $error
$feeCategories = $feeCategories ?? [];
$classSections = $classSections ?? [];
$students = $students ?? [];
$assignments = $assignments ?? [];
$academicYears = $academicYears ?? [];
$feeGrid = $feeGrid ?? ['class' => [], 'global' => []];
$currentYearId = (int)($currentYearId ?? 0);

$postScope = (string)($_POST['scope_type'] ?? 'class');
if (!in_array($postScope, ['class', 'student', 'global'], true)) {
    $postScope = 'class';
}
$postCategory = (int)($_POST['fee_category_id'] ?? 0);
$postAmount = (string)($_POST['amount'] ?? '');
$postYear = isset($_POST['academic_year_id']) ? (int)$_POST['academic_year_id'] : $currentYearId;
$postClassIds = array_map('intval', (array)($_POST['class_section_ids'] ?? []));
$postStudentIds = array_map('intval', (array)($_POST['student_ids'] ?? []));
$postDescription = (string)($_POST['description'] ?? '');

$studentsJson = [];
foreach ($students as $st) {
    $studentsJson[] = [
        'id' => (int)$st['id'],
        'name' => trim(($st['first_name'] ?? '') . ' ' . ($st['last_name'] ?? '')),
        'adm' => (string)($st['admission_no'] ?? ''),
        'cls' => (string)($st['class_label'] ?? ''),
    ];
}
$jsonFlags = JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
?>
<style>
    /* The site's fixed top bar (z-index 2000) would otherwise sit on top of this modal and hide its title. */
    #assignModal { z-index: 2100; }
    .modal-backdrop { z-index: 2090; }

    .fa-grid-wrap { overflow: auto; max-height: 70vh; border: 1px solid var(--sms-border, #2a3340); border-radius: 10px; }
    .fa-grid { width: 100%; border-collapse: separate; border-spacing: 0; font-size: .92rem; }
    .fa-grid th, .fa-grid td { padding: .5rem .75rem; border-bottom: 1px solid var(--sms-border, #2a3340); white-space: nowrap; }
    .fa-grid thead th { position: sticky; top: 0; z-index: 2; background: var(--sms-surface-2, #1f2937); text-align: right; }
    .fa-grid thead th:first-child, .fa-grid tbody th { position: sticky; left: 0; text-align: left; background: var(--sms-surface-2, #1f2937); z-index: 1; }
    .fa-grid thead th:first-child { z-index: 3; }
    .fa-grid td { text-align: right; padding: 0; }
    .fa-cell { display: block; width: 100%; padding: .5rem .75rem; background: none; border: 0; color: inherit; text-align: right; cursor: pointer; font: inherit; }
    .fa-cell:hover { background: rgba(184,135,62,.18); }
    .fa-cell.empty { color: var(--sms-muted, #8b95a5); }
    .fa-cell .fa-edit { opacity: 0; font-size: .75rem; margin-right: .3rem; }
    .fa-cell:hover .fa-edit { opacity: .8; }
    .fa-global th, .fa-global td { background: rgba(184,135,62,.08); }

    .fa-step { display: flex; gap: .75rem; margin-bottom: 1.25rem; }
    .fa-step-num { flex: 0 0 28px; height: 28px; border-radius: 50%; background: var(--sms-primary, #b8873e); color: #fff; font-weight: 700; display: flex; align-items: center; justify-content: center; font-size: .85rem; margin-top: 2px; }
    .fa-step-body { flex: 1; min-width: 0; }
    .fa-step-title { font-weight: 700; margin-bottom: .4rem; }

    .fa-seg { display: flex; gap: .4rem; flex-wrap: wrap; }
    .fa-seg input { position: absolute; opacity: 0; pointer-events: none; }
    .fa-seg label { padding: .4rem .9rem; border: 1px solid var(--sms-input-border, #374151); border-radius: 999px; cursor: pointer; font-size: .9rem; }
    .fa-seg input:checked + label { background: var(--sms-primary, #b8873e); border-color: var(--sms-primary, #b8873e); color: #fff; font-weight: 600; }
    .fa-seg input:focus-visible + label { outline: 2px solid var(--sms-primary, #b8873e); outline-offset: 2px; }

    .fa-picker { border: 1px solid var(--sms-input-border, #374151); border-radius: 10px; padding: .6rem; }
    .fa-pick-list { max-height: 200px; overflow: auto; margin-top: .5rem; display: grid; grid-template-columns: repeat(auto-fill, minmax(190px, 1fr)); gap: .25rem .75rem; }
    .fa-pick-list.single { grid-template-columns: 1fr; }
    .fa-pick-item { display: flex; align-items: center; gap: .45rem; padding: .2rem .3rem; border-radius: 6px; cursor: pointer; font-size: .9rem; margin: 0; }
    .fa-pick-item:hover { background: rgba(184,135,62,.12); }
    .fa-pick-item small { color: var(--sms-muted, #8b95a5); }
    .fa-chips { display: flex; flex-wrap: wrap; gap: .3rem; margin-bottom: .4rem; }
    .fa-chip { background: rgba(184,135,62,.2); border-radius: 999px; padding: .1rem .2rem .1rem .65rem; font-size: .82rem; display: inline-flex; align-items: center; gap: .25rem; }
    .fa-chip button { border: 0; background: none; color: inherit; line-height: 1; padding: 0 .35rem; font-size: 1rem; cursor: pointer; }
    .fa-summary { background: rgba(184,135,62,.12); border-radius: 10px; padding: .6rem .9rem; font-size: .95rem; }
    #assignModal .modal-body { padding-bottom: .5rem; }
</style>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">Fee Assignments</h1>
        <div class="text-muted small">Set what each class pays. The newest fee you assign is the one used for new invoices.</div>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-primary" type="button" onclick="faOpen({})">+ Assign Fee</button>
        <a class="btn btn-outline-secondary" href="<?= h(base_url('/index.php?route=fees/index')) ?>">Back</a>
    </div>
</div>

<!-- ===================== CURRENT FEES (class x fee grid) ===================== -->
<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <div class="d-flex justify-content-between flex-wrap gap-2 mb-2">
            <h2 class="h6 mb-0">Current fees by class</h2>
            <span class="text-muted small">Click any amount to change it, or an empty cell to set it.</span>
        </div>

        <?php if (!$feeCategories): ?>
            <div class="text-muted">No fee categories yet. <a href="<?= h(route_url('fees/categories')) ?>">Create a fee category first</a>.</div>
        <?php else: ?>
        <div class="fa-grid-wrap">
            <table class="fa-grid">
                <thead>
                    <tr>
                        <th>Class</th>
                        <?php foreach ($feeCategories as $fc): ?>
                            <th><?= h($fc['name'] ?? '') ?><?= !empty($fc['is_one_time']) ? ' <span class="badge bg-secondary" style="font-weight:500;">one-time</span>' : '' ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($feeGrid['global'])): ?>
                    <tr class="fa-global">
                        <th>Everyone <span class="text-muted small">(all classes)</span></th>
                        <?php foreach ($feeCategories as $fc): $amt = $feeGrid['global'][(int)$fc['id']] ?? null; ?>
                            <td>
                                <button type="button" class="fa-cell <?= $amt === null ? 'empty' : '' ?>"
                                        onclick="faOpen({scope:'global',category:<?= (int)$fc['id'] ?>,amount:<?= $amt === null ? "''" : (float)$amt ?>})">
                                    <?= $amt === null ? '—' : '<i class="bi bi-pencil fa-edit"></i>' . number_format($amt, 0) ?>
                                </button>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                    <?php endif; ?>
                    <?php foreach ($classSections as $cs): $cid = (int)$cs['id']; ?>
                    <tr>
                        <th><?= h(($cs['class_name'] ?? '') . ' — ' . ($cs['section_name'] ?? '')) ?></th>
                        <?php foreach ($feeCategories as $fc):
                            $amt = $feeGrid['class'][$cid][(int)$fc['id']] ?? null; ?>
                            <td>
                                <button type="button" class="fa-cell <?= $amt === null ? 'empty' : '' ?>"
                                        onclick="faOpen({scope:'class',classId:<?= $cid ?>,category:<?= (int)$fc['id'] ?>,amount:<?= $amt === null ? "''" : (float)$amt ?>})">
                                    <?= $amt === null ? '—' : '<i class="bi bi-pencil fa-edit"></i>' . number_format($amt, 0) ?>
                                </button>
                            </td>
                        <?php endforeach; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="text-muted small mt-2">Amounts in Rs. Fees set for an individual student override the class amount — see the history below.</div>
        <?php endif; ?>
    </div>
</div>

<!-- ===================== HISTORY ===================== -->
<div class="card shadow-sm border-0">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
            <h2 class="h6 mb-0">All assignments (history) <span class="badge bg-secondary ms-1"><?= count($assignments) ?></span></h2>
            <input type="search" id="faHistFilter" class="form-control form-control-sm" style="max-width:260px;" placeholder="Filter by fee, class or student…">
        </div>
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle mb-0" id="faHistTable">
                <thead class="table-light">
                    <tr>
                        <th>Fee</th>
                        <th>Assigned to</th>
                        <th>Academic year</th>
                        <th class="text-end">Amount (Rs.)</th>
                        <th style="width:90px;"></th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$assignments): ?>
                    <tr><td colspan="5" class="text-muted py-3 text-center">No assignments yet. Click <strong>+ Assign Fee</strong> to create one.</td></tr>
                <?php endif; ?>
                <?php foreach ($assignments as $a):
                    if (!empty($a['student_id'])) {
                        $scope = $a['student_name'] ?? ('Student #' . (int)$a['student_id']);
                        $badge = '<span class="badge bg-info text-dark me-1">Student</span>';
                    } elseif (!empty($a['class_section_id'])) {
                        $scope = $a['class_section_name'] ?? ('Class #' . (int)$a['class_section_id']);
                        $badge = '<span class="badge bg-primary me-1">Class</span>';
                    } else {
                        $scope = 'All students';
                        $badge = '<span class="badge bg-secondary me-1">Everyone</span>';
                    } ?>
                    <tr>
                        <td class="fw-semibold"><?= h($a['fee_category_name'] ?? '') ?><?php if (trim((string)($a['description'] ?? '')) !== ''): ?><div class="small text-muted fw-normal"><?= h($a['description']) ?></div><?php endif; ?></td>
                        <td><?= $badge ?><span class="small"><?= h($scope) ?></span></td>
                        <td class="text-muted small"><?= h($a['academic_year_label'] ?? ($a['academic_year_id'] ? 'Year #' . $a['academic_year_id'] : 'Any')) ?></td>
                        <td class="text-end fw-semibold"><?= number_format((float)($a['amount'] ?? 0), 2) ?></td>
                        <td class="text-end">
                            <form method="post" action="<?= h(base_url('/index.php?route=fees/assignmentDelete')) ?>"
                                  onsubmit="return confirm('Delete this assignment?')" class="d-inline">
                                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                <input type="hidden" name="id" value="<?= (int)($a['id'] ?? 0) ?>">
                                <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ===================== ASSIGN FEE MODAL ===================== -->
<div class="modal fade" id="assignModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
        <div class="modal-content">
            <form method="post" action="<?= h(base_url('/index.php?route=fees/assignments')) ?>" id="faForm" autocomplete="off">
                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                <div class="modal-header">
                    <h5 class="modal-title">Assign fee</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger py-2"><?= h($error) ?></div>
                    <?php endif; ?>

                    <!-- 1 -->
                    <div class="fa-step">
                        <div class="fa-step-num">1</div>
                        <div class="fa-step-body">
                            <div class="fa-step-title">Which fee, and how much?</div>
                            <div class="row g-2">
                                <div class="col-sm-7">
                                    <select name="fee_category_id" id="faCategory" class="form-select" required>
                                        <option value="">— Choose fee —</option>
                                        <?php foreach ($feeCategories as $fc): ?>
                                            <option value="<?= (int)$fc['id'] ?>" <?= $postCategory === (int)$fc['id'] ? 'selected' : '' ?>>
                                                <?= h($fc['name'] ?? '') ?><?= !empty($fc['is_one_time']) ? ' (one-time)' : '' ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <?php if (!$feeCategories): ?>
                                        <div class="form-text"><a href="<?= h(route_url('fees/categories')) ?>">Create a category first</a></div>
                                    <?php endif; ?>
                                </div>
                                <div class="col-sm-5">
                                    <div class="input-group">
                                        <span class="input-group-text">Rs.</span>
                                        <input type="number" name="amount" id="faAmount" class="form-control" min="1" step="any"
                                               placeholder="Amount" value="<?= h($postAmount) ?>" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- 2 -->
                    <div class="fa-step">
                        <div class="fa-step-num">2</div>
                        <div class="fa-step-body">
                            <div class="fa-step-title">Who pays it?</div>
                            <div class="fa-seg mb-2">
                                <input type="radio" name="scope_type" id="faScopeClass" value="class" <?= $postScope === 'class' ? 'checked' : '' ?>><label for="faScopeClass">Classes</label>
                                <input type="radio" name="scope_type" id="faScopeStudent" value="student" <?= $postScope === 'student' ? 'checked' : '' ?>><label for="faScopeStudent">Individual students</label>
                                <input type="radio" name="scope_type" id="faScopeGlobal" value="global" <?= $postScope === 'global' ? 'checked' : '' ?>><label for="faScopeGlobal">Everyone</label>
                            </div>

                            <!-- classes -->
                            <div id="faPanelClass" class="fa-picker">
                                <div class="d-flex gap-2 flex-wrap align-items-center">
                                    <input type="search" id="faClassSearch" class="form-control form-control-sm" style="max-width:220px;" placeholder="Search class…">
                                    <button type="button" class="btn btn-sm btn-outline-secondary" id="faClassAll">Select all</button>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" id="faClassNone">Clear</button>
                                    <span class="text-muted small ms-auto"><span id="faClassCount">0</span> selected</span>
                                </div>
                                <div class="fa-pick-list" id="faClassList">
                                    <?php foreach ($classSections as $cs): $cid = (int)$cs['id']; ?>
                                        <label class="fa-pick-item" data-text="<?= h(strtolower(($cs['class_name'] ?? '') . ' ' . ($cs['section_name'] ?? ''))) ?>">
                                            <input type="checkbox" class="form-check-input m-0 fa-class-cb" name="class_section_ids[]" value="<?= $cid ?>"
                                                   <?= in_array($cid, $postClassIds, true) ? 'checked' : '' ?>>
                                            <span><?= h(($cs['class_name'] ?? '') . ' — ' . ($cs['section_name'] ?? '')) ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <!-- students -->
                            <div id="faPanelStudent" class="fa-picker" style="display:none;">
                                <div class="fa-chips" id="faStuChips"></div>
                                <input type="search" id="faStuSearch" class="form-control form-control-sm" placeholder="Type a name, admission no. or class to find students…">
                                <div class="fa-pick-list single" id="faStuList"></div>
                                <div id="faStuHidden"></div>
                            </div>

                            <!-- global -->
                            <div id="faPanelGlobal" class="text-muted small" style="display:none;">
                                This amount will apply to every student in every class (unless a class or student has its own amount).
                            </div>
                        </div>
                    </div>

                    <!-- 3 -->
                    <div class="fa-step mb-2">
                        <div class="fa-step-num">3</div>
                        <div class="fa-step-body">
                            <div class="fa-step-title">Academic year</div>
                            <select name="academic_year_id" class="form-select" style="max-width:320px;">
                                <option value="0">Any year</option>
                                <?php foreach ($academicYears as $y): ?>
                                    <option value="<?= (int)$y['id'] ?>" <?= $postYear === (int)$y['id'] ? 'selected' : '' ?>><?= h($y['academic_year_label'] ?? '') ?></option>
                                <?php endforeach; ?>
                            </select>
                            <label for="faLabel" class="form-label small mt-2 mb-1">Fee label <span class="text-muted">(optional)</span></label>
                            <input type="text" name="description" id="faLabel" class="form-control form-control-sm" maxlength="150"
                                   placeholder="e.g. First Term Exam Fee" value="<?= h($postDescription) ?>">
                            <div class="form-text">For one-time fees this is the name printed on the invoice. Give each exam, late fee etc. its own label so they are billed separately.</div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer d-block">
                    <div class="fa-summary mb-2" id="faSummary">Fill in the details above.</div>
                    <div class="d-flex justify-content-end gap-2">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="faSave" disabled>Save fee</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
(function () {
    var STUDENTS = <?= json_encode($studentsJson, $jsonFlags) ?>;
    var picked = {};   // student id -> student
    <?php foreach ($postStudentIds as $psid): if ($psid > 0): ?>
    (function (id) { STUDENTS.forEach(function (s) { if (s.id === id) { picked[id] = s; } }); })(<?= (int)$psid ?>);
    <?php endif; endforeach; ?>

    var $ = function (id) { return document.getElementById(id); };
    var form = $('faForm');
    var scopeInputs = form.querySelectorAll('input[name="scope_type"]');
    var classCbs = form.querySelectorAll('.fa-class-cb');

    function scope() {
        var v = 'class';
        scopeInputs.forEach(function (r) { if (r.checked) { v = r.value; } });
        return v;
    }
    function esc(t) { var d = document.createElement('div'); d.textContent = t == null ? '' : String(t); return d.innerHTML; }
    function fmt(n) { return Number(n).toLocaleString('en-US', { maximumFractionDigits: 2 }); }

    function renderStudents() {
        var q = $('faStuSearch').value.trim().toLowerCase();
        var html = '', shown = 0;
        for (var i = 0; i < STUDENTS.length && shown < 40; i++) {
            var s = STUDENTS[i];
            var hay = (s.name + ' ' + s.adm + ' ' + s.cls).toLowerCase();
            if (q && hay.indexOf(q) === -1) { continue; }
            if (!q && !picked[s.id] && shown >= 15) { break; }
            html += '<label class="fa-pick-item"><input type="checkbox" class="form-check-input m-0" data-sid="' + s.id + '"' +
                (picked[s.id] ? ' checked' : '') + '><span>' + esc(s.name) + ' <small>' + esc(s.adm) + (s.cls ? ' · ' + esc(s.cls) : '') + '</small></span></label>';
            shown++;
        }
        if (!html) { html = '<div class="text-muted small p-2">No students found.</div>'; }
        $('faStuList').innerHTML = html;
    }
    function renderChips() {
        var chips = '', hidden = '';
        Object.keys(picked).forEach(function (id) {
            chips += '<span class="fa-chip">' + esc(picked[id].name) + '<button type="button" data-rm="' + id + '" aria-label="Remove">&times;</button></span>';
            hidden += '<input type="hidden" name="student_ids[]" value="' + id + '">';
        });
        $('faStuChips').innerHTML = chips;
        $('faStuHidden').innerHTML = hidden;
    }

    function refresh() {
        var sc = scope();
        $('faPanelClass').style.display = sc === 'class' ? '' : 'none';
        $('faPanelStudent').style.display = sc === 'student' ? '' : 'none';
        $('faPanelGlobal').style.display = sc === 'global' ? '' : 'none';

        var nClass = 0; classCbs.forEach(function (c) { if (c.checked) { nClass++; } });
        var nStu = Object.keys(picked).length;
        $('faClassCount').textContent = nClass;

        var cat = $('faCategory'), catName = cat.selectedIndex > 0 ? cat.options[cat.selectedIndex].text.replace(/\s*\(one-time\)\s*$/, '') : '';
        var amt = parseFloat($('faAmount').value);
        var who = sc === 'class' ? (nClass + ' class' + (nClass === 1 ? '' : 'es'))
                : sc === 'student' ? (nStu + ' student' + (nStu === 1 ? '' : 's'))
                : 'everyone';
        var whoOk = sc === 'global' || (sc === 'class' && nClass > 0) || (sc === 'student' && nStu > 0);
        var ok = catName !== '' && amt > 0 && whoOk;

        $('faSummary').innerHTML = ok
            ? '<strong>' + esc(catName) + '</strong> · Rs. ' + fmt(amt) + ' → <strong>' + esc(who) + '</strong>'
            : 'Choose a fee and amount, then who pays it.';
        $('faSave').disabled = !ok;
    }

    form.addEventListener('input', refresh);
    form.addEventListener('change', function (e) {
        var sid = e.target.getAttribute && e.target.getAttribute('data-sid');
        if (sid) {
            sid = parseInt(sid, 10);
            if (e.target.checked) {
                STUDENTS.forEach(function (s) { if (s.id === sid) { picked[sid] = s; } });
            } else {
                delete picked[sid];
            }
            renderChips();
        }
        refresh();
    });
    $('faStuChips').addEventListener('click', function (e) {
        var id = e.target.getAttribute('data-rm');
        if (id) { delete picked[id]; renderChips(); renderStudents(); refresh(); }
    });
    $('faStuSearch').addEventListener('input', renderStudents);
    $('faClassSearch').addEventListener('input', function () {
        var q = this.value.trim().toLowerCase();
        $('faClassList').querySelectorAll('.fa-pick-item').forEach(function (l) {
            l.style.display = (!q || l.getAttribute('data-text').indexOf(q) !== -1) ? '' : 'none';
        });
    });
    $('faClassAll').addEventListener('click', function () {
        $('faClassList').querySelectorAll('.fa-pick-item').forEach(function (l) {
            if (l.style.display !== 'none') { l.querySelector('input').checked = true; }
        });
        refresh();
    });
    $('faClassNone').addEventListener('click', function () {
        classCbs.forEach(function (c) { c.checked = false; });
        refresh();
    });

    // Open the form, optionally prefilled from a grid cell: faOpen({scope, classId, category, amount})
    window.faOpen = function (o) {
        o = o || {};
        if (o.scope) {
            scopeInputs.forEach(function (r) { r.checked = (r.value === o.scope); });
            if (o.scope === 'class') {
                classCbs.forEach(function (c) { c.checked = (o.classId && parseInt(c.value, 10) === o.classId); });
            }
        }
        if (o.category) { $('faCategory').value = String(o.category); }
        if (o.amount !== undefined && o.amount !== '') { $('faAmount').value = o.amount; }
        else if (o.scope) { $('faAmount').value = ''; }
        refresh();
        bootstrap.Modal.getOrCreateInstance($('assignModal')).show();
        setTimeout(function () { var a = $('faAmount'); a.focus(); a.select(); }, 350);
    };

    // history filter
    $('faHistFilter').addEventListener('input', function () {
        var q = this.value.trim().toLowerCase();
        document.querySelectorAll('#faHistTable tbody tr').forEach(function (tr) {
            tr.style.display = (!q || tr.textContent.toLowerCase().indexOf(q) !== -1) ? '' : 'none';
        });
    });

    renderChips();
    renderStudents();
    refresh();
    <?php if (!empty($error)): ?>
    document.addEventListener('DOMContentLoaded', function () { bootstrap.Modal.getOrCreateInstance($('assignModal')).show(); });
    <?php endif; ?>
})();
</script>
