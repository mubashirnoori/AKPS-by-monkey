<?php
// Variables: $staff, $ledger, $handovers, $collections, $collectionSummary, $collectionsTotal, $collectionsPage, $collectionsPerPage, $collectionsTotalPages
$staff = $staff ?? [];
$ledger = $ledger ?? ['collected' => 0, 'handed_over' => 0, 'pending_handover' => 0, 'net_balance' => 0];
$handovers = $handovers ?? [];
$collections = $collections ?? [];
$collectionSummary = $collectionSummary ?? ['to_collect' => 0, 'collected' => 0, 'pending' => 0, 'student_count' => 0];
$collectionsTotal = (int)($collectionsTotal ?? count($collections));
$collectionsPage = max(1, (int)($collectionsPage ?? 1));
$collectionsPerPage = (int)($collectionsPerPage ?? 50);
$collectionsTotalPages = max(1, (int)($collectionsTotalPages ?? 1));
$collectionsRouteBase = base_url('/index.php?route=fees/teacherLedgerDetail&staff_profile_id=' . (int)($staff['id'] ?? 0));

$statusBadge = static function (string $status): string {
    $map = [
        'pending'   => 'bg-warning text-dark',
        'confirmed' => 'bg-success',
        'rejected'  => 'bg-danger',
    ];
    return $map[$status] ?? 'bg-secondary';
};
?>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0"><?= h($staff['full_name'] ?? '') ?></h1>
        <div class="text-muted"><?= h($staff['title'] ?? 'Fee collection ledger') ?></div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=fees/teacherLedger'), ENT_QUOTES, 'UTF-8') ?>">Back to Ledger</a>
</div>

<?php if ((int)$collectionSummary['student_count'] > 0 || (float)$collectionSummary['to_collect'] > 0): ?>
<div class="mb-2">
    <div class="text-muted small fw-semibold text-uppercase">Fee Collection Progress — Assigned Classes</div>
</div>
<div class="portal-kpis mb-4">
    <div class="portal-kpi portal-kpi--c">
        <div class="portal-kpi__label"><i class="bi bi-flag"></i> Total To Collect</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$collectionSummary['to_collect'], 0) ?></div>
        <div class="portal-kpi__hint"><?= (int)$collectionSummary['student_count'] ?> student<?= (int)$collectionSummary['student_count'] === 1 ? '' : 's' ?> invoiced</div>
    </div>
    <div class="portal-kpi portal-kpi--b">
        <div class="portal-kpi__label"><i class="bi bi-cash-coin"></i> Collected From Students</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$collectionSummary['collected'], 0) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--e">
        <div class="portal-kpi__label"><i class="bi bi-hourglass-split"></i> Still Pending</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$collectionSummary['pending'], 0) ?></div>
    </div>
</div>
<?php endif; ?>

<div class="mb-2">
    <div class="text-muted small fw-semibold text-uppercase">Cash Handover Ledger</div>
</div>
<div class="portal-kpis">
    <div class="portal-kpi portal-kpi--b">
        <div class="portal-kpi__label"><i class="bi bi-wallet2"></i> Collected</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$ledger['collected'], 0) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--c">
        <div class="portal-kpi__label"><i class="bi bi-check-circle"></i> Handed Over</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$ledger['handed_over'], 0) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--e">
        <div class="portal-kpi__label"><i class="bi bi-hourglass-split"></i> Pending</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$ledger['pending_handover'], 0) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--a">
        <div class="portal-kpi__label"><i class="bi bi-cash-stack"></i> Net Balance</div>
        <div class="portal-kpi__value">Rs <?= number_format((float)$ledger['net_balance'], 0) ?></div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-header"><strong>Handover History</strong></div>
            <div class="card-body p-0">
                <?php if (empty($handovers)): ?>
                    <div class="portal-empty"><i class="bi bi-arrow-left-right"></i>No handovers submitted.</div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th class="text-end">Amount</th>
                                <th>To</th>
                                <th>Status</th>
                                <?php if (RBAC::isAdmin()): ?><th class="text-end">Actions</th><?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($handovers as $ho): ?>
                                <tr>
                                    <td class="small"><?= h(date('d M Y, h:i A', strtotime($ho['created_at']))) ?></td>
                                    <td class="text-end fw-semibold">Rs <?= number_format((float)$ho['amount'], 2) ?></td>
                                    <td class="small"><?= h($ho['handed_to_name'] ?? '—') ?></td>
                                    <td><span class="badge <?= $statusBadge($ho['status']) ?>"><?= h(ucfirst($ho['status'])) ?></span></td>
                                    <?php if (RBAC::isAdmin()): ?>
                                    <td class="text-end text-nowrap">
                                        <button class="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="modal" data-bs-target="#editHandover<?= (int)$ho['id'] ?>" title="Edit">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button class="btn btn-sm btn-outline-danger" type="button" data-bs-toggle="modal" data-bs-target="#deleteHandover<?= (int)$ho['id'] ?>" title="Delete">
                                            <i class="bi bi-trash"></i>
                                        </button>

                                        <div class="modal fade" id="editHandover<?= (int)$ho['id'] ?>" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <form method="post" action="<?= h(route_url('fees/handoverUpdate')) ?>">
                                                        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                                        <input type="hidden" name="handover_id" value="<?= (int)$ho['id'] ?>">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Edit Handover</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="alert alert-warning small mb-3"><i class="bi bi-exclamation-triangle me-1"></i>Use this only to fix a mistake (wrong amount typed, etc). This changes the record directly, including on already-confirmed handovers.</div>
                                                            <div class="mb-3">
                                                                <label class="form-label">Amount</label>
                                                                <input class="form-control" type="number" step="0.01" min="0.01" name="amount" value="<?= h((string)$ho['amount']) ?>" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label class="form-label">Note</label>
                                                                <input class="form-control" type="text" name="note" maxlength="255" value="<?= h($ho['note'] ?? '') ?>">
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" class="btn btn-primary">Save Changes</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="modal fade" id="deleteHandover<?= (int)$ho['id'] ?>" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <form method="post" action="<?= h(route_url('fees/handoverDelete')) ?>">
                                                        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                                        <input type="hidden" name="handover_id" value="<?= (int)$ho['id'] ?>">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Delete Handover</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            Permanently delete this Rs <?= number_format((float)$ho['amount'], 2) ?> handover record (<?= h(ucfirst($ho['status'])) ?>)? This cannot be undone.
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                                            <button type="submit" class="btn btn-danger">Delete</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>


    <div class="col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-header d-flex align-items-center justify-content-between">
                <strong>Fee Collections</strong>
                <span class="text-muted small">Showing <?= count($collections) ?> of <?= (int)$collectionsTotal ?></span>
            </div>
            <div class="card-body p-0">
                <?php if (empty($collections)): ?>
                    <div class="portal-empty"><i class="bi bi-wallet2"></i>No fee collections recorded.</div>
                <?php else: ?>
                <div class="table-responsive" style="max-height:520px; overflow-y:auto;">
                    <table class="table table-sm table-striped mb-0">
                        <thead><tr><th>Date</th><th>Student</th><th>Invoice</th><th class="text-end">Amount</th></tr></thead>
                        <tbody>
                            <?php foreach ($collections as $c): ?>
                                <tr>
                                    <td class="small"><?= h(date('d M Y', strtotime($c['collected_at']))) ?></td>
                                    <td class="small"><?= h(trim(($c['first_name'] ?? '') . ' ' . ($c['last_name'] ?? ''))) ?></td>
                                    <td class="small"><?= h($c['invoice_no'] ?? '') ?></td>
                                    <td class="text-end">Rs <?= number_format((float)$c['amount'], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($collectionsTotalPages > 1): ?>
                <nav class="p-2 border-top">
                    <ul class="pagination pagination-sm justify-content-center flex-wrap mb-0">
                        <?php for ($p = 1; $p <= $collectionsTotalPages; $p++): ?>
                            <?php $url = $collectionsRouteBase . '&' . http_build_query(['cpage' => $p]); ?>
                            <li class="page-item <?= $p === $collectionsPage ? 'active' : '' ?>">
                                <a class="page-link" href="<?= h($url) ?>"><?= (int)$p ?></a>
                            </li>
                        <?php endfor; ?>
                    </ul>
                </nav>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
