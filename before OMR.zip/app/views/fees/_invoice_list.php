<?php
// Variables: $invoices (one row per student), $total, $q, $invoiceStatus, $studentStatus, $classSectionId, $page, $perPage, $listFilters
$invoices = $invoices ?? [];
$total = (int)($total ?? 0);
$q = (string)($q ?? '');
$invoiceStatus = (string)($invoiceStatus ?? '');
$studentStatus = (string)($studentStatus ?? '');
$classSectionId = (int)($classSectionId ?? 0);
$page = max(1, (int)($page ?? 1));
$perPage = (int)($perPage ?? 20);
$totalPages = max(1, (int)ceil($total / max(1, $perPage)));
$listFilters = $listFilters ?? [
    'q' => $q,
    'invoice_status' => $invoiceStatus,
    'student_status' => $studentStatus,
    'class_section_id' => $classSectionId,
    'per_page' => $perPage,
    'page' => $page,
];
$routeBase = base_url('/index.php?route=fees/invoices');
$sortKey = (string)($listFilters['sort'] ?? '');
$sortDir = (string)($listFilters['dir'] ?? 'asc');
$sortHeader = function (string $label, string $col) use ($routeBase, $q, $invoiceStatus, $studentStatus, $classSectionId, $perPage, $sortKey, $sortDir): string {
    $href = function (string $dir) use ($routeBase, $q, $invoiceStatus, $studentStatus, $classSectionId, $perPage, $col): string {
        $qs = array_filter([
            'q' => $q, 'invoice_status' => $invoiceStatus, 'student_status' => $studentStatus,
            'class_section_id' => $classSectionId, 'per_page' => $perPage, 'sort' => $col, 'dir' => $dir, 'page' => 1,
        ], static fn($v) => $v !== '' && $v !== 0 && $v !== null);
        return $routeBase . '&' . http_build_query($qs);
    };
    $upOn = ($sortKey === $col && $sortDir === 'asc');
    $downOn = ($sortKey === $col && $sortDir === 'desc');
    return h($label)
        . ' <span class="inv-sort">'
        . '<a href="' . h($href('asc')) . '" class="' . ($upOn ? 'on' : '') . '" title="Sort ' . h($label) . ': A to Z / smallest first"><i class="bi bi-caret-up-fill"></i></a>'
        . '<a href="' . h($href('desc')) . '" class="' . ($downOn ? 'on' : '') . '" title="Sort ' . h($label) . ': Z to A / largest first"><i class="bi bi-caret-down-fill"></i></a>'
        . '</span>';
};
$rangeStart = $total > 0 ? (($page - 1) * $perPage) + 1 : 0;
$rangeEnd = $total > 0 ? min($total, $rangeStart + count($invoices) - 1) : 0;
?>
<div class="text-muted small mb-2">
    <?php if ($total > 0): ?>
        Showing <?= $rangeStart ?>–<?= $rangeEnd ?> of <?= (int)$total ?> student(s)
    <?php else: ?>
        Showing 0 student(s)
    <?php endif; ?>
    <?php if ($q !== ''): ?> · filtered by "<?= h($q) ?>"<?php endif; ?>
    <?php if ($totalPages > 1): ?> · page <?= (int)$page ?> of <?= (int)$totalPages ?><?php endif; ?>
</div>

<style>
.inv-sort { display:inline-flex; flex-direction:column; line-height:.7; vertical-align:middle; margin-left:3px; }
.inv-sort a { color:inherit; opacity:.35; font-size:.62rem; text-decoration:none; line-height:.8; }
.inv-sort a:hover { opacity:.8; }
.inv-sort a.on { opacity:1; color:#d4a24c; }
</style>
<?php $canBulkDelete = RBAC::hasPermission('fees.manage') || RBAC::hasPermission('fees.invoice_delete'); ?>
<form method="post" action="<?= h(route_url('fees/invoiceBulkDelete')) ?>"
      onchange="var n=this.querySelectorAll('.sel-stu:checked').length;var c=this.querySelector('[data-sel-count]');if(c){c.textContent=n;}var b=this.querySelector('[data-bulk-del]');if(b){b.disabled=n===0;}">
<input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
<?php if ($canBulkDelete && $invoices): ?>
<div class="d-flex align-items-center gap-2 mb-2">
    <button type="submit" class="btn btn-sm btn-outline-danger" data-bulk-del disabled
            onclick="var n=this.form.querySelectorAll('.sel-stu:checked').length;return confirm('Delete ALL unpaid invoices of '+n+' selected student(s)? This cannot be undone. Invoices that have a payment are kept.');">
        <i class="bi bi-trash"></i> Delete selected (<span data-sel-count>0</span>)
    </button>
    <span class="text-muted small">Tick students below (or the box in the header to select this whole page).</span>
</div>
<?php endif; ?>
<div class="card shadow-sm border-0">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <?php if ($canBulkDelete): ?><th style="width:32px;"><input type="checkbox" class="form-check-input" title="Select all on this page"
                            onclick="var f=this.form;f.querySelectorAll('.sel-stu').forEach(function(c){c.checked=this.checked;}.bind(this));f.dispatchEvent(new Event('change',{bubbles:true}));"></th><?php endif; ?>
                        <th><?= $sortHeader('Student', 'student') ?></th>
                        <th><?= $sortHeader('Class', 'class') ?></th>
                        <th><?= $sortHeader('Months', 'months') ?></th>
                        <th class="text-end"><?= $sortHeader('Invoices', 'invoices') ?></th>
                        <th class="text-end"><?= $sortHeader('Total Invoiced', 'total') ?></th>
                        <th class="text-end"><?= $sortHeader('Collected', 'collected') ?></th>
                        <th class="text-end"><?= $sortHeader('Pending', 'pending') ?></th>
                        <th><?= $sortHeader('Status', 'status') ?></th>
                        <th class="text-center" style="width:70px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($invoices)): ?>
                    <tr><td colspan="10" class="text-muted py-4 text-center">No invoices found.</td></tr>
                <?php else: ?>
                    <?php foreach ($invoices as $fi): ?>
                        <?php
                        $pending = max(0, (float)($fi['total_due'] ?? 0) - (float)($fi['collected_amount'] ?? 0));
                        $isOverdue = !empty($fi['is_overdue']);
                        $status = $fi['status'] ?? 'open';
                        $statusBadge = match ($status) {
                            'paid'      => '<span class="badge bg-success">Paid</span>',
                            'cancelled' => '<span class="badge bg-secondary">Cancelled</span>',
                            default     => $isOverdue
                                ? '<span class="badge bg-danger">Overdue</span>'
                                : '<span class="badge bg-warning text-dark">Open</span>',
                        };
                        $isActiveStudent = (int)($fi['student_status'] ?? 1) === 1;
                        $sid = (int)($fi['student_id'] ?? $fi['id'] ?? 0);
                        $invoiceCount = (int)($fi['invoice_count'] ?? 0);
                        $openCount = (int)($fi['open_count'] ?? 0);
                        ?>
                        <tr class="<?= $isActiveStudent ? '' : 'table-secondary' ?>">
                            <?php if ($canBulkDelete): ?><td><input type="checkbox" class="form-check-input sel-stu" name="student_ids[]" value="<?= (int)$sid ?>"></td><?php endif; ?>
                            <td>
                                <div class="fw-semibold"><?= h(($fi['first_name'] ?? '') . ' ' . ($fi['last_name'] ?? '')) ?></div>
                                <div class="text-muted small"><?= h($fi['admission_no'] ?? '') ?></div>
                                <?php if (($fi['roll_number'] ?? '') !== ''): ?>
                                    <div class="text-muted small">Roll No: <?= h($fi['roll_number']) ?></div>
                                <?php endif; ?>
                                <?php if (!empty($fi['cnic_no'])): ?>
                                    <div class="text-muted small">CNIC: <?= h($fi['cnic_no']) ?></div>
                                <?php endif; ?>
                                <?php if ($isActiveStudent): ?>
                                    <span class="badge text-bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge text-bg-secondary">Left school</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-muted small"><?= h($fi['class_display'] ?? '—') ?></td>
                            <td class="text-muted small"><?= h($fi['billing_month_display'] ?? '—') ?></td>
                            <td class="text-end small">
                                <?= $invoiceCount ?>
                                <?php if ($openCount > 0 && $openCount !== $invoiceCount): ?>
                                    <div class="text-muted"><?= $openCount ?> open</div>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">Rs. <?= number_format((float)($fi['total_due'] ?? 0), 2) ?></td>
                            <td class="text-end">Rs. <?= number_format((float)($fi['collected_amount'] ?? 0), 2) ?></td>
                            <td class="text-end <?= $pending > 0 ? 'text-danger fw-semibold' : 'text-success' ?>">
                                Rs. <?= number_format($pending, 2) ?>
                            </td>
                            <td><?= $statusBadge ?></td>
                            <td class="text-center">
                                <a class="sms-inv-btn sms-inv-btn-view"
                                   href="<?= h(route_url('fees/studentInvoices') . '&student_id=' . $sid) ?>"
                                   title="View all invoices" data-bs-toggle="tooltip">
                                    <i class="bi bi-eye"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</form>

<?php if ($totalPages > 1): ?>
<?php
$queryCommon = [
    'q' => $q,
    'invoice_status' => $invoiceStatus,
    'student_status' => $studentStatus,
    'class_section_id' => $classSectionId,
    'per_page' => $perPage,
    'sort' => $sortKey,
    'dir' => $sortDir,
];
$pageUrl = function (int $p) use ($routeBase, $queryCommon): string {
    return $routeBase . '&' . http_build_query(array_merge($queryCommon, ['page' => $p]));
};

$window = 2;
$pagesToShow = [1, $totalPages];
for ($p = $page - $window; $p <= $page + $window; $p++) {
    if ($p >= 1 && $p <= $totalPages) {
        $pagesToShow[] = $p;
    }
}
$pagesToShow = array_values(array_unique($pagesToShow));
sort($pagesToShow);
?>
<nav class="mt-3" aria-label="Invoice pages">
    <ul class="pagination justify-content-center flex-wrap mb-2">
        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
            <a class="page-link" href="<?= $page > 1 ? h($pageUrl($page - 1)) : '#' ?>" aria-label="Previous">&laquo; Prev</a>
        </li>
        <?php $prevShown = 0; ?>
        <?php foreach ($pagesToShow as $p): ?>
            <?php if ($prevShown !== 0 && $p - $prevShown > 1): ?>
                <li class="page-item disabled"><span class="page-link">&hellip;</span></li>
            <?php endif; ?>
            <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                <a class="page-link" href="<?= h($pageUrl($p)) ?>"><?= (int)$p ?></a>
            </li>
            <?php $prevShown = $p; ?>
        <?php endforeach; ?>
        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
            <a class="page-link" href="<?= $page < $totalPages ? h($pageUrl($page + 1)) : '#' ?>" aria-label="Next">Next &raquo;</a>
        </li>
    </ul>
    <div class="text-center text-muted small">Page <?= (int)$page ?> of <?= (int)$totalPages ?></div>
</nav>
<?php endif; ?>
