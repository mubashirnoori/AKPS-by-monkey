<?php
// Variables: $rows, $q, $total, $page, $perPage, $totalPages
$q = $q ?? '';
$total = (int)($total ?? count($rows));
$page = max(1, (int)($page ?? 1));
$perPage = (int)($perPage ?? 50);
$totalPages = max(1, (int)($totalPages ?? 1));
$routeBase = base_url('/index.php?route=fees/pendingDues');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Pending Dues</h1>
        <div class="text-muted">Students with outstanding balances.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=fees/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="fees/pendingDues">
            <div class="col-md-5">
                <label class="form-label mb-1">Search student</label>
                <input class="form-control" name="q" value="<?= h($q) ?>" placeholder="Name or admission no…">
            </div>
            <div class="col-md-3 d-grid">
                <button class="btn btn-outline-primary" type="submit">Search</button>
            </div>
            <?php if ($q !== ''): ?>
            <div class="col-md-2 d-grid">
                <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=fees/pendingDues'), ENT_QUOTES, 'UTF-8') ?>">Clear</a>
            </div>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="text-muted small mb-2">
    Showing <?= count($rows) ?> of <?= (int)$total ?> student(s) with pending dues
    <?php if ($q !== ''): ?> · filtered by "<?= h($q) ?>"<?php endif; ?>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-striped mb-0">
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Admission</th>
                        <th>Pending Amount</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="3" class="text-muted">No pending dues.</td></tr>
                <?php else: ?>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td class="fw-semibold"><?= h(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? '')) ?></td>
                            <td class="text-muted small"><?= h($r['admission_no'] ?? '') ?></td>
                            <td class="fw-semibold"><?= h((string)($r['pending_amount'] ?? 0)) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if ($totalPages > 1): ?>
<nav class="mt-3">
    <ul class="pagination justify-content-center flex-wrap">
        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <?php $url = $routeBase . '&' . http_build_query(['q' => $q, 'page' => $p]); ?>
            <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                <a class="page-link" href="<?= h($url) ?>"><?= (int)$p ?></a>
            </li>
        <?php endfor; ?>
    </ul>
</nav>
<?php endif; ?>

