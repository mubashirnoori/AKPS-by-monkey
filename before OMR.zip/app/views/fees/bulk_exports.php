<?php
// Variables: $academicYears
$academicYears = $academicYears ?? [];
$statusOptions = [
    'open' => 'Open',
    'paid' => 'Paid',
    'cancelled' => 'Cancelled',
];
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Bulk Exports</h1>
        <div class="text-muted">Select one or more academic years and statuses, then download every matching invoice, or an invoices workbook, for all of them in one file.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= h(base_url('/index.php?route=fees/index')) ?>">Back</a>
</div>

<?php if (empty($academicYears)): ?>
<div class="card shadow-sm border-0"><div class="card-body">
    <div class="text-muted">No invoices found yet.</div>
</div></div>
<?php else: ?>

<!-- Each button below sets a hidden "route" field (via its data-route attribute) right
     before the form submits. We do NOT rely on formaction="...?route=..." because on a
     method="get" form, browsers discard any query string already present in the
     action/formaction URL and replace it entirely with the serialized form fields — so
     "route" would never actually reach the server and the app would fall back to its
     default route (the dashboard). Sending "route" as a real form field avoids that. -->
<form method="get" action="<?= h(base_url('/index.php')) ?>" class="card shadow-sm border-0 mb-3" id="bulkExportForm">
    <div class="card-body">
        <input type="hidden" name="route" id="bulkExportRoute" value="">
        <!-- Lets this export work even when the download request itself doesn't carry the
             session cookie (e.g. the mobile app's WebView wrapper handing the download off
             to the OS's native downloader) — see DownloadToken / Auth::requireLoginOrToken(). -->
        <input type="hidden" name="dl_token" value="<?= h(download_token()) ?>">

        <div class="row g-4 mb-3">
            <div class="col-md-8">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <label class="form-label mb-0 small text-muted">Academic years to include</label>
                    <div>
                        <button type="button" class="btn btn-link btn-sm p-0 me-2" id="bulkExportSelectAll">Select all</button>
                        <button type="button" class="btn btn-link btn-sm p-0" id="bulkExportSelectNone">Select none</button>
                    </div>
                </div>
                <div class="row g-2" style="max-height: 220px; overflow-y: auto;">
                    <?php foreach ($academicYears as $ay): ?>
                        <div class="col-md-6">
                            <div class="form-check">
                                <input class="form-check-input bulk-export-year-checkbox" type="checkbox" name="academic_year_ids[]" value="<?= h((string)$ay['id']) ?>" id="ay_<?= h((string)$ay['id']) ?>" checked>
                                <label class="form-check-label small" for="ay_<?= h((string)$ay['id']) ?>"><?= h($ay['academic_year_label']) ?></label>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="col-md-4">
                <label class="form-label mb-0 small text-muted d-block mb-2">Statuses to include</label>
                <?php foreach ($statusOptions as $value => $label): ?>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="statuses[]" value="<?= h($value) ?>" id="status_<?= h($value) ?>" checked>
                        <label class="form-check-label small" for="status_<?= h($value) ?>"><?= h($label) ?></label>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-md-4">
                <div class="card border-0 h-100" style="background: var(--sms-surface-2);">
                    <div class="card-body d-flex flex-column">
                        <h2 class="h6"><i class="bi bi-file-earmark-zip"></i> All Invoices (ZIP)</h2>
                        <p class="text-muted small flex-grow-1 mb-3">
                            One ZIP file, organised as <code>Academic Year / Month / Class - Section / Student (Admission No) / Invoice - {invoice_no}.html</code>
                            for every matching invoice — open an invoice in your browser and use Print &rarr; Save as PDF for a PDF copy.
                        </p>
                        <button type="submit" class="btn btn-primary bulk-export-submit" data-route="fees/bulkInvoicesDownload">
                            <i class="bi bi-download"></i> Download ZIP
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 h-100" style="background: var(--sms-surface-2);">
                    <div class="card-body d-flex flex-column">
                        <h2 class="h6"><i class="bi bi-file-earmark-spreadsheet"></i> Invoices Workbook (Excel)</h2>
                        <p class="text-muted small flex-grow-1 mb-3">
                            One Excel file covering every matching invoice: a Summary sheet (totals plus a class
                            breakdown per academic year/month), plus one full-detail sheet per academic year/month.
                        </p>
                        <button type="submit" class="btn btn-primary bulk-export-submit" data-route="fees/bulkInvoicesXlsDownload">
                            <i class="bi bi-download"></i> Download Excel
                        </button>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card border-0 h-100" style="background: var(--sms-surface-2);">
                    <div class="card-body d-flex flex-column">
                        <h2 class="h6"><i class="bi bi-file-earmark-text"></i> Invoices (CSV)</h2>
                        <p class="text-muted small flex-grow-1 mb-3">
                            One flat CSV, one row per invoice, with Academic Year / Month / Class - Section / Student
                            as leading columns — handy for importing into another spreadsheet or system.
                        </p>
                        <button type="submit" class="btn btn-primary bulk-export-submit" data-route="fees/bulkInvoicesCsvDownload">
                            <i class="bi bi-download"></i> Download CSV
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<script>
(function () {
    var form = document.getElementById('bulkExportForm');
    if (!form) return;
    var routeField = document.getElementById('bulkExportRoute');
    var yearBoxes = form.querySelectorAll('.bulk-export-year-checkbox');
    document.getElementById('bulkExportSelectAll').addEventListener('click', function () {
        yearBoxes.forEach(function (b) { b.checked = true; });
    });
    document.getElementById('bulkExportSelectNone').addEventListener('click', function () {
        yearBoxes.forEach(function (b) { b.checked = false; });
    });

    // Each download button just records which route it wants; the actual submit/validation
    // happens in the form's submit handler below (works with click, Enter key, etc).
    var submitButtons = form.querySelectorAll('.bulk-export-submit');
    submitButtons.forEach(function (btn) {
        btn.addEventListener('click', function () {
            routeField.value = btn.getAttribute('data-route');
        });
    });

    form.addEventListener('submit', function (e) {
        var anyChecked = Array.prototype.some.call(yearBoxes, function (b) { return b.checked; });
        if (!anyChecked) {
            e.preventDefault();
            alert('Select at least one academic year first.');
            return;
        }
        if (!routeField.value) {
            // Fallback safety net in case submit fired without a button click event
            // (e.g. pressing Enter in a text field) — default to the ZIP export.
            routeField.value = 'fees/bulkInvoicesDownload';
        }
    });
})();
</script>

<?php endif; ?>
