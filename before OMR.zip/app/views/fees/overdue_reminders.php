<?php
// Variables: $invoices, $smsEnabled, $page, $perPage, $total, $totalPages
$invoices = $invoices ?? [];
$page = $page ?? 1;
$totalPages = $totalPages ?? 1;
$total = $total ?? count($invoices);
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Overdue Fee Reminders</h1>
        <div class="text-muted">
            Select which students/guardians to warn about their unpaid, past-due invoice.
            No fine is applied — this is a reminder only.
        </div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(route_url('fees/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!$smsEnabled): ?>
<div class="alert alert-warning">
    SMS sending is currently switched off in <a href="<?= htmlspecialchars(base_url('/index.php?route=settings/notifications'), ENT_QUOTES, 'UTF-8') ?>">Settings &gt; Notifications</a>.
    Reminders won't actually go out until it's enabled there.
</div>
<?php endif; ?>

<form method="post" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" id="overdueRemindersForm"
      onsubmit="return confirm('Send an overdue-fee reminder SMS to the student and guardians of every invoice checked below?');">
    <input type="hidden" name="route" value="fees/overdueReminders">
    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-body d-flex align-items-center justify-content-between flex-wrap gap-2">
            <div>
                <strong><?= (int)$total ?></strong> overdue unpaid invoice<?= (int)$total === 1 ? '' : 's' ?> in total.
                <span class="text-muted small">(<?= count($invoices) ?> shown on this page)</span>
            </div>
            <button class="btn btn-primary" type="submit" id="sendRemindersBtn" disabled>Send Reminders to Selected</button>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-sm table-striped mb-0">
                    <thead>
                        <tr>
                            <th style="width:2rem;">
                                <input type="checkbox" class="form-check-input" id="selectAllCheckbox">
                            </th>
                            <th>Student</th>
                            <th>Admission</th>
                            <th>Invoice</th>
                            <th>Due Date</th>
                            <th>Days Overdue</th>
                            <th>Pending Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($invoices)): ?>
                        <tr><td colspan="8" class="text-muted">No overdue unpaid invoices.</td></tr>
                    <?php else: ?>
                        <?php foreach ($invoices as $inv): $alreadySent = !empty($inv['reminded_today']); ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="form-check-input reminder-checkbox"
                                           name="invoice_ids[]" value="<?= (int)$inv['id'] ?>"
                                           <?= $alreadySent ? 'disabled' : '' ?>>
                                </td>
                                <td class="fw-semibold"><?= h(($inv['first_name'] ?? '') . ' ' . ($inv['last_name'] ?? '')) ?></td>
                                <td class="text-muted small"><?= h($inv['admission_no'] ?? '') ?></td>
                                <td><?= h($inv['invoice_no'] ?? '') ?></td>
                                <td><?= h($inv['due_date'] ?? '') ?></td>
                                <td><?= h((string)($inv['days_overdue'] ?? '')) ?></td>
                                <td class="fw-semibold"><?= h(number_format((float)($inv['pending_amount'] ?? 0), 2)) ?></td>
                                <td>
                                    <?php if ($alreadySent): ?>
                                        <span class="badge text-bg-secondary">Already reminded today</span>
                                    <?php else: ?>
                                        <span class="badge text-bg-warning">Pending reminder</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</form>

<?php if ($totalPages > 1): ?>
<nav class="mt-3">
    <ul class="pagination justify-content-center flex-wrap">
        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <?php $url = base_url('/index.php') . '?' . http_build_query(['route' => 'fees/overdueReminders', 'page' => $p]); ?>
            <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                <a class="page-link" href="<?= h($url) ?>"><?= (int)$p ?></a>
            </li>
        <?php endfor; ?>
    </ul>
</nav>
<?php endif; ?>

<script>
(function () {
    var selectAll = document.getElementById('selectAllCheckbox');
    var checkboxes = Array.prototype.slice.call(document.querySelectorAll('.reminder-checkbox:not(:disabled)'));
    var sendBtn = document.getElementById('sendRemindersBtn');

    function updateSendBtn() {
        var anyChecked = checkboxes.some(function (cb) { return cb.checked; });
        sendBtn.disabled = !anyChecked;
    }

    if (selectAll) {
        selectAll.addEventListener('change', function () {
            checkboxes.forEach(function (cb) { cb.checked = selectAll.checked; });
            updateSendBtn();
        });
    }

    checkboxes.forEach(function (cb) {
        cb.addEventListener('change', function () {
            if (!cb.checked && selectAll) {
                selectAll.checked = false;
            }
            updateSendBtn();
        });
    });

    updateSendBtn();
})();
</script>
