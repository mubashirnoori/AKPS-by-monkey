<?php
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Fees & Finance</h1>
        <div class="text-muted">Fee categories, assignments, invoices, cash collection and pending dues.</div>
    </div>
</div>

<div class="row g-3">
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(base_url('/index.php?route=fees/categories'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="fw-semibold mb-1">Fee Categories</div>
                    <div class="text-muted small">Add/edit/delete categories</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(base_url('/index.php?route=fees/assignments'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="fw-semibold mb-1">Fee Assignments</div>
                    <div class="text-muted small">Assign per student/class/global</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(route_url('fees/generateInvoices'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="fw-semibold mb-1">Generate invoices</div>
                    <div class="text-muted small">Student or class batch, tuition &amp; admission</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(route_url('fees/invoices'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="fw-semibold mb-1">Invoices</div>
                    <div class="text-muted small">View, print, and collect</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(base_url('/index.php?route=fees/collect'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="fw-semibold mb-1">Cash Collection</div>
                    <div class="text-muted small">Record cash payments</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(base_url('/index.php?route=fees/pendingDues'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="fw-semibold mb-1">Pending Dues</div>
                    <div class="text-muted small">Outstanding balances</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(route_url('fees/overdueReminders'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="fw-semibold mb-1">Overdue Fee Reminders</div>
                    <div class="text-muted small">Send an SMS warning — no fine applied</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(base_url('/index.php?route=fees/feeSettings'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="fw-semibold mb-1">Fee Settings</div>
                    <div class="text-muted small">Discount and fine rules</div>
                </div>
            </div>
        </a>
    </div>
    <?php if (RBAC::hasPermission('fees.handover_confirm')): ?>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(route_url('fees/teacherLedger'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="fw-semibold mb-1">Teacher Fee Collections</div>
                    <div class="text-muted small">Collected vs. handed over, per teacher</div>
                </div>
            </div>
        </a>
    </div>
    <?php endif; ?>
</div>

