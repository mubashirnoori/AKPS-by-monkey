<?php
// Variables: $ledgerRows, $pending, $collectionSummaries, $academicYears, $academicYearId, $ledgerPage, $ledgerTotalPages
$ledgerRows = $ledgerRows ?? [];
$pending = $pending ?? [];
$collectionSummaries = $collectionSummaries ?? [];
$academicYears = $academicYears ?? [];
$academicYearId = $academicYearId ?? 0;
$ledgerPage = $ledgerPage ?? 1;
$ledgerTotalPages = $ledgerTotalPages ?? 1;

$totalCollected = array_sum(array_column($ledgerRows, 'collected'));
$totalHandedOver = array_sum(array_column($ledgerRows, 'handed_over'));
$totalBalance = array_sum(array_column($ledgerRows, 'net_balance'));

$overallSummary = $overallSummary ?? ['to_collect' => 0, 'collected' => 0, 'pending' => 0];
$totalToCollect = (float)$overallSummary['to_collect'];
$totalStudentCollected = (float)$overallSummary['collected'];
$totalStudentPending = (float)$overallSummary['pending'];
?>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">Teacher Fee Collections</h1>
        <div class="text-muted">Who collected how much, what they've handed over, and what's still outstanding.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=fees/index'), ENT_QUOTES, 'UTF-8') ?>">Back to Fees</a>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body py-2">
        <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="d-flex align-items-center gap-2 flex-wrap">
            <input type="hidden" name="route" value="fees/teacherLedger">
            <label class="form-label mb-0 fw-semibold small">Academic Year</label>
            <select class="form-select form-select-sm" style="width:auto;" name="academic_year_id" onchange="this.form.submit()">
                <option value="0" <?= $academicYearId === 0 ? 'selected' : '' ?>>All years</option>
                <?php foreach ($academicYears as $ay): ?>
                    <option value="<?= (int)$ay['id'] ?>" <?= $academicYearId === (int)$ay['id'] ? 'selected' : '' ?>>
                        <?= h($ay['academic_year_label'] ?? '') ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <noscript><button class="btn btn-sm btn-outline-primary" type="submit">Apply</button></noscript>
        </form>
    </div>
</div>

<?php if (!empty($collectionSummaries)): ?>
<div class="mb-2">
    <div class="text-muted small fw-semibold text-uppercase">Fee Collection Progress — All Assigned Classes</div>
</div>
<div class="portal-kpis mb-4">
    <div class="portal-kpi portal-kpi--c">
        <div class="portal-kpi__label"><i class="bi bi-flag"></i> Total To Collect</div>
        <div class="portal-kpi__value">Rs <?= number_format($totalToCollect, 0) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--b">
        <div class="portal-kpi__label"><i class="bi bi-cash-coin"></i> Collected From Students</div>
        <div class="portal-kpi__value">Rs <?= number_format($totalStudentCollected, 0) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--e">
        <div class="portal-kpi__label"><i class="bi bi-hourglass-split"></i> Still Pending</div>
        <div class="portal-kpi__value">Rs <?= number_format($totalStudentPending, 0) ?></div>
    </div>
</div>
<?php endif; ?>

<div class="mb-2">
    <div class="text-muted small fw-semibold text-uppercase">Cash Handover Ledger</div>
</div>
<div class="portal-kpis">
    <div class="portal-kpi portal-kpi--b">
        <div class="portal-kpi__label"><i class="bi bi-wallet2"></i> Total Collected (All Teachers)</div>
        <div class="portal-kpi__value">Rs <?= number_format($totalCollected, 0) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--c">
        <div class="portal-kpi__label"><i class="bi bi-check-circle"></i> Total Handed Over</div>
        <div class="portal-kpi__value">Rs <?= number_format($totalHandedOver, 0) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--e">
        <div class="portal-kpi__label"><i class="bi bi-hourglass-split"></i> Pending Confirmations</div>
        <div class="portal-kpi__value"><?= count($pending) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--a">
        <div class="portal-kpi__label"><i class="bi bi-cash-stack"></i> Total Outstanding</div>
        <div class="portal-kpi__value">Rs <?= number_format($totalBalance, 0) ?></div>
        <div class="portal-kpi__hint">Still with teachers, unconfirmed</div>
    </div>
</div>

<?php if (!empty($pending)): ?>
<div class="card shadow-sm border-0 mb-3">
    <div class="card-header"><strong>Pending Handovers — Awaiting Your Confirmation</strong></div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-sm table-striped mb-0 align-middle">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Staff</th>
                        <th class="text-end">Amount</th>
                        <th>Handed to</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pending as $p): ?>
                        <tr>
                            <td class="small"><?= h(date('d M Y, h:i A', strtotime($p['created_at']))) ?></td>
                            <td><?= h($p['staff_name'] ?? '') ?></td>
                            <td class="text-end fw-semibold">Rs <?= number_format((float)$p['amount'], 2) ?></td>
                            <td class="small"><?= h($p['handed_to_name'] ?? '—') ?></td>
                            <td class="text-end">
                                <form method="post" action="<?= htmlspecialchars(route_url('fees/handoverConfirm'), ENT_QUOTES, 'UTF-8') ?>" class="d-inline">
                                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                    <input type="hidden" name="handover_id" value="<?= (int)$p['id'] ?>">
                                    <button class="btn btn-sm btn-success" type="submit" onclick="return confirm('Confirm you received Rs <?= number_format((float)$p['amount'], 2) ?> from <?= h(addslashes($p['staff_name'] ?? '')) ?>?');">
                                        <i class="bi bi-check-lg"></i> Confirm
                                    </button>
                                </form>
                                <button class="btn btn-sm btn-outline-danger" type="button" data-bs-toggle="modal" data-bs-target="#rejectModal<?= (int)$p['id'] ?>">
                                    <i class="bi bi-x-lg"></i> Reject
                                </button>

                                <div class="modal fade" id="rejectModal<?= (int)$p['id'] ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form method="post" action="<?= htmlspecialchars(route_url('fees/handoverReject'), ENT_QUOTES, 'UTF-8') ?>">
                                                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                                <input type="hidden" name="handover_id" value="<?= (int)$p['id'] ?>">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Reject Handover</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <label class="form-label">Reason (optional, shown to the teacher)</label>
                                                    <input class="form-control" type="text" name="reason" maxlength="255">
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                                    <button type="submit" class="btn btn-danger">Reject</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="card shadow-sm border-0">
    <div class="card-header"><strong>All Teachers / Principal — Collection Ledger</strong></div>
    <div class="card-body p-0">
        <?php if (empty($ledgerRows)): ?>
            <div class="portal-empty"><i class="bi bi-cash-coin"></i><?= $academicYearId > 0 ? 'No fee collections recorded by any teacher for this academic year.' : 'No fee collections recorded by any teacher yet.' ?></div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-sm table-striped mb-0 align-middle">
                <thead>
                    <tr>
                        <th>Staff</th>
                        <th class="text-end">To Collect</th>
                        <th class="text-end">Collected (Students)</th>
                        <th class="text-end">Pending (Students)</th>
                        <th class="text-end">Handed Over</th>
                        <th class="text-end">Handover Pending</th>
                        <th class="text-end">Net Balance</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($ledgerRows as $row): ?>
                        <?php $cs = $collectionSummaries[(int)$row['staff_profile_id']] ?? ['to_collect' => 0, 'collected' => 0, 'pending' => 0]; ?>
                        <tr>
                            <td>
                                <?= h($row['full_name'] ?? '') ?>
                                <?php if (!empty($row['title'])): ?><span class="text-muted small">— <?= h($row['title']) ?></span><?php endif; ?>
                            </td>
                            <td class="text-end">Rs <?= number_format((float)$cs['to_collect'], 2) ?></td>
                            <td class="text-end">Rs <?= number_format((float)$cs['collected'], 2) ?></td>
                            <td class="text-end text-warning">Rs <?= number_format((float)$cs['pending'], 2) ?></td>
                            <td class="text-end text-success">Rs <?= number_format((float)$row['handed_over'], 2) ?></td>
                            <td class="text-end text-warning">Rs <?= number_format((float)$row['pending_handover'], 2) ?></td>
                            <td class="text-end fw-semibold <?= (float)$row['net_balance'] > 0 ? 'text-danger' : 'text-success' ?>">
                                Rs <?= number_format((float)$row['net_balance'], 2) ?>
                            </td>
                            <td class="text-end">
                                <a class="btn btn-sm btn-outline-primary" href="<?= h(route_url('fees/teacherLedgerDetail')) ?>&staff_profile_id=<?= (int)$row['staff_profile_id'] ?>">
                                    <i class="bi bi-eye"></i> Details
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php if ($ledgerTotalPages > 1): ?>
<nav class="mt-3">
    <ul class="pagination pagination-sm justify-content-center flex-wrap">
        <?php for ($p = 1; $p <= $ledgerTotalPages; $p++): ?>
            <?php $pUrl = base_url('/index.php?route=fees/teacherLedger&academic_year_id=' . $academicYearId . '&page=' . $p); ?>
            <li class="page-item <?= $p === $ledgerPage ? 'active' : '' ?>">
                <a class="page-link" href="<?= h($pUrl) ?>"><?= (int)$p ?></a>
            </li>
        <?php endfor; ?>
    </ul>
</nav>
<?php endif; ?>
