<?php
$invoice = $invoice ?? [];
$lines   = $invoice['lines'] ?? [];
$fines   = $invoice['custom_fines'] ?? [];

// Load school branding
$schoolName = 'School';
$logoPath   = '';
try {
    $settingRows = Database::fetchAll(
        "SELECT `key`, `value` FROM settings WHERE `key` IN ('branding_school_name','institute_name','branding_logo_path')"
    );
    foreach ($settingRows as $sr) {
        $k = (string)($sr['key'] ?? '');
        $v = (string)($sr['value'] ?? '');
        if ($k === 'branding_school_name' && $v !== '') $schoolName = $v;
        elseif ($k === 'institute_name' && $schoolName === 'School' && $v !== '') $schoolName = $v;
        elseif ($k === 'branding_logo_path') $logoPath = $v;
    }
} catch (Throwable $e) {}

$studentName   = trim(($invoice['first_name'] ?? '') . ' ' . ($invoice['last_name'] ?? ''));
$admissionNo   = $invoice['admission_no'] ?? '';
$invoiceNo     = $invoice['invoice_no'] ?? '';
$issuedAt      = $invoice['issued_at'] ?? '';
$dueDate       = $invoice['due_date'] ?? '';
$status        = ucfirst($invoice['status'] ?? 'open');
$totalDue      = (float)($invoice['total_due'] ?? 0);
$totalDiscount = (float)($invoice['total_discount'] ?? 0);
$fineApplied   = (float)($invoice['fine_applied'] ?? 0);
$collected     = (float)($invoice['collected_amount'] ?? 0);
$pending       = max(0, $totalDue - $collected);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Invoice <?= h($invoiceNo) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
        body { background: #fff; }
        @media print {
            .no-print { display: none !important; }
            body { margin: 0; }
            .invoice-wrap { padding: 10mm 15mm; }
        }
        .invoice-wrap { max-width: 720px; margin: 0 auto; padding: 2rem 1.5rem; }
        .school-header { border-bottom: 2px solid #333; padding-bottom: 1rem; margin-bottom: 1.5rem; }
        .invoice-title { font-size: 1.4rem; font-weight: 700; letter-spacing: 1px; text-transform: uppercase; }
        .label-col { color: #666; font-size: 0.82rem; }
        .amount-col { font-weight: 600; }
        .total-row { border-top: 2px solid #333; font-weight: 700; font-size: 1.05rem; }
        .pending-row { background: #fff3cd; }
        .stamp { display:inline-block; border: 3px solid green; color: green; padding: 4px 16px;
                 font-weight: 700; font-size: 1rem; letter-spacing: 2px; transform: rotate(-8deg);
                 border-radius: 4px; }
        .stamp.unpaid { border-color: #dc3545; color: #dc3545; }
    </style>
</head>
<body>

<!-- Print Button — hidden on print -->
<div class="no-print text-center py-3 bg-light border-bottom d-flex justify-content-center gap-3 align-items-center">
    <span class="text-muted small">Invoice ready to print</span>
    <button class="btn btn-primary px-4" onclick="window.print()">🖨 Print / Save as PDF</button>
    <a class="btn btn-outline-secondary" href="<?= h(route_url('fees/invoices')) ?>">← Back to Invoices</a>
</div>

<div class="invoice-wrap">

    <!-- School Header -->
    <div class="school-header d-flex align-items-center gap-3">
        <?php if ($logoPath !== ''): ?>
            <img src="<?= htmlspecialchars(base_url($logoPath), ENT_QUOTES, 'UTF-8') ?>"
                 alt="Logo" style="max-height:60px;width:auto;">
        <?php endif; ?>
        <div>
            <div style="font-size:1.3rem;font-weight:700;"><?= h($schoolName) ?></div>
            <div class="text-muted small">Fee Invoice</div>
        </div>
        <div class="ms-auto text-end">
            <div class="invoice-title">Invoice</div>
            <div class="text-muted small"><?= h($invoiceNo) ?></div>
        </div>
    </div>

    <!-- Student & Invoice Meta -->
    <div class="row mb-4">
        <div class="col-6">
            <div class="label-col mb-1">Billed To</div>
            <div class="fw-semibold fs-6"><?= h($studentName) ?></div>
            <div class="text-muted small">Admission No: <?= h($admissionNo) ?></div>
        </div>
        <div class="col-6 text-end">
            <div class="mb-1"><span class="label-col">Issue Date: </span><?= h($issuedAt) ?></div>
            <div class="mb-1"><span class="label-col">Due Date: </span><?= h($dueDate ?: '—') ?></div>
            <div>
                <?php if (strtolower($status) === 'paid'): ?>
                    <span class="stamp">PAID</span>
                <?php else: ?>
                    <span class="stamp unpaid"><?= h(strtoupper($status)) ?></span>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Invoice Lines -->
    <table class="table table-sm table-bordered mb-0">
        <thead class="table-dark">
            <tr>
                <th style="width:30%;">Fee Category</th>
                <th>Description</th>
                <th class="text-end" style="width:110px;">Amount (Rs.)</th>
                <th class="text-end" style="width:110px;">Paid (Rs.)</th>
                <th class="text-end" style="width:110px;">Pending (Rs.)</th>
                <th class="text-center" style="width:80px;">Status</th>
            </tr>
        </thead>
        <tbody>
        <?php if (empty($lines)): ?>
            <tr><td colspan="6" class="text-muted text-center">No line items.</td></tr>
        <?php else: ?>
            <?php foreach ($lines as $l): ?>
                <?php
                $linePaid = (float)($l['paid_amount'] ?? 0);
                $linePending = (float)($l['pending_amount'] ?? max((float)($l['line_total'] ?? 0) - $linePaid, 0));
                $lineIsPaid = !empty($l['is_paid']) || $linePending <= 0.001;
                ?>
                <tr class="<?= $lineIsPaid ? 'table-success' : '' ?>">
                    <td class="fw-semibold"><?= h($l['fee_category_name'] ?? $l['category_name'] ?? '') ?></td>
                    <td class="text-muted small"><?= h($l['description'] ?? '') ?></td>
                    <td class="text-end">Rs. <?= number_format((float)($l['base_amount'] ?? $l['line_total'] ?? 0), 2) ?></td>
                    <td class="text-end text-success">Rs. <?= number_format($linePaid, 2) ?></td>
                    <td class="text-end <?= $linePending > 0 ? 'text-danger fw-semibold' : 'text-success' ?>">Rs. <?= number_format($linePending, 2) ?></td>
                    <td class="text-center">
                        <span class="badge <?= $lineIsPaid ? 'text-bg-success' : 'text-bg-secondary' ?>"><?= $lineIsPaid ? 'Paid' : 'Unpaid' ?></span>
                    </td>
                </tr>
                <?php if ((float)($l['discount_amount'] ?? 0) > 0): ?>
                <tr class="table-success">
                    <td class="text-success small ps-4">↳ Discount</td>
                    <td class="text-success small"></td>
                    <td class="text-end text-success small">- Rs. <?= number_format((float)$l['discount_amount'], 2) ?></td>
                    <td colspan="3"></td>
                </tr>
                <?php endif; ?>
            <?php endforeach; ?>
        <?php endif; ?>

        <?php foreach ($fines as $fine): ?>
            <tr class="table-warning">
                <td class="fw-semibold text-warning-emphasis">Fine — <?= h($fine['fine_type'] ?? '') ?></td>
                <td class="text-muted small"><?= h($fine['notes'] ?? '') ?></td>
                <td class="text-end fw-semibold" colspan="4">Rs. <?= number_format((float)($fine['amount'] ?? 0), 2) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if ($fineApplied > 0 && empty($fines)): ?>
            <tr class="table-warning">
                <td class="fw-semibold text-warning-emphasis">Late Fine</td>
                <td class="text-muted small">Auto-applied for overdue</td>
                <td class="text-end fw-semibold" colspan="4">Rs. <?= number_format($fineApplied, 2) ?></td>
            </tr>
        <?php endif; ?>
        </tbody>
        <tfoot>
            <?php if ($totalDiscount > 0): ?>
            <tr class="table-success">
                <td colspan="5" class="text-end text-success fw-semibold">Total Discount</td>
                <td class="text-end text-success fw-semibold">- Rs. <?= number_format($totalDiscount, 2) ?></td>
            </tr>
            <?php endif; ?>
            <tr class="total-row">
                <td colspan="5" class="text-end">Total Invoiced</td>
                <td class="text-end">Rs. <?= number_format($totalDue, 2) ?></td>
            </tr>
            <?php if ($collected > 0): ?>
            <tr>
                <td colspan="5" class="text-end text-success">Amount Paid</td>
                <td class="text-end text-success">- Rs. <?= number_format($collected, 2) ?></td>
            </tr>
            <?php endif; ?>
            <tr class="pending-row">
                <td colspan="5" class="text-end fw-bold">Balance Pending</td>
                <td class="text-end fw-bold">Rs. <?= number_format($pending, 2) ?></td>
            </tr>
        </tfoot>
    </table>

    <!-- Footer -->
    <div class="mt-4 pt-3 border-top d-flex justify-content-between align-items-end">
        <div class="text-muted small">
            Generated by <?= h($schoolName) ?><br>
            Printed: <?= date('d M Y, h:i A') ?>
        </div>
        <div class="text-end">
            <div style="border-top:1px solid #999;width:180px;padding-top:4px;font-size:0.8rem;color:#666;">
                Authorised Signature
            </div>
        </div>
    </div>

</div>
</body>
</html>
