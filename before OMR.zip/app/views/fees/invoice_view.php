<?php
$invoice = $invoice ?? [];
$lines = $invoice['lines'] ?? [];
$fines = $invoice['custom_fines'] ?? [];
$collections = $invoice['collections'] ?? [];
$invoiceId = (int)($invoice['id'] ?? 0);
$studentName = trim(($invoice['first_name'] ?? '') . ' ' . ($invoice['last_name'] ?? ''));
$totalDue = (float)($invoice['total_due'] ?? 0);
$collected = (float)($invoice['collected_amount'] ?? 0);
$pending = max(0, $totalDue - $collected);
$status = (string)($invoice['status'] ?? 'open');
$listFilters = $listFilters ?? recall_list_filters('fees_invoices', [
    'q' => '', 'invoice_status' => '', 'student_status' => '', 'class_section_id' => 0, 'per_page' => 20, 'page' => 1,
]);
$listBackUrl = list_url('fees/invoices', $listFilters);
$retQs = list_return_query($listFilters);
?>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">Invoice <?= h($invoice['invoice_no'] ?? '') ?></h1>
        <div class="text-muted small">Invoice details for <?= h($studentName) ?></div>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <a class="btn btn-outline-dark" href="<?= h(route_url('fees/invoicePrint') . '&invoice_id=' . $invoiceId) ?>" target="_blank">🖨 Print</a>
        <?php if (!empty($whatsappRecipients) && count($whatsappRecipients) === 1): ?>
        <a class="btn btn-success js-wa-share" href="<?= h($whatsappRecipients[0]['url']) ?>" target="_blank" rel="noopener">
            <i class="bi bi-whatsapp me-1"></i>Send via WhatsApp
        </a>
        <?php elseif (!empty($whatsappRecipients)): ?>
        <div class="btn-group">
            <button type="button" class="btn btn-success dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-whatsapp me-1"></i>Send via WhatsApp
            </button>
            <ul class="dropdown-menu">
                <?php foreach ($whatsappRecipients as $rec): ?>
                    <li><a class="dropdown-item js-wa-share" href="<?= h($rec['url']) ?>" target="_blank" rel="noopener"><?= h($rec['label']) ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php else: ?>
        <button class="btn btn-outline-secondary" type="button" disabled title="No valid mobile number on file for this student">
            <i class="bi bi-whatsapp me-1"></i>Send via WhatsApp
        </button>
        <?php endif; ?>
        <a class="btn btn-primary" href="#" data-collect-invoice-id="<?= $invoiceId ?>" title="Opens without leaving this page">Collect Payment</a>
        <a class="btn btn-outline-secondary btn-sm" href="<?= h(route_url('fees/collect') . '&invoice_id=' . $invoiceId . $retQs) ?>">Full collection page</a>
        <a class="btn btn-outline-secondary" href="<?= h($listBackUrl) ?>">← Back</a>
        <?php if (RBAC::hasPermission('fees.manage')): ?>
        <form method="post" action="<?= h(route_url('fees/invoiceDelete')) ?>" class="d-inline"
              onsubmit="return confirm('Delete invoice <?= h($invoice['invoice_no'] ?? '') ?> permanently? This also removes all its payment records.');">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
            <input type="hidden" name="invoice_id" value="<?= $invoiceId ?>">
            <?php list_return_fields($listFilters); ?>
            <button type="submit" class="btn btn-outline-danger"><i class="bi bi-trash me-1"></i>Delete Invoice</button>
        </form>
        <?php endif; ?>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Student</div>
                <div class="fw-semibold"><?= h($studentName) ?></div>
                <div class="text-muted small"><?= h($invoice['admission_no'] ?? '') ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Status</div>
                <div class="fw-semibold text-capitalize"><?= h($status) ?></div>
                <div class="text-muted small">Due: <?= h($invoice['due_date'] ?? '—') ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Total Invoiced</div>
                <div class="fw-semibold">Rs. <?= number_format($totalDue, 2) ?></div>
                <div class="text-muted small">Collected: Rs. <?= number_format($collected, 2) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <div class="text-muted small">Pending</div>
                <div class="fw-semibold <?= $pending > 0 ? 'text-danger' : 'text-success' ?>">
                    Rs. <?= number_format($pending, 2) ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <h2 class="h6 mb-3">Fee Lines</h2>
        <div class="table-responsive" style="max-height: 340px; overflow-y: auto;">
            <table class="table table-sm table-striped mb-0">
                <thead style="position: sticky; top: 0; z-index: 1; background: var(--sms-surface, #1a2230);">
                <tr>
                    <th>Description</th>
                    <th class="text-end">Base</th>
                    <th class="text-end">Discount</th>
                    <th class="text-end">Line Total</th>
                </tr>
                </thead>
                <tbody>
                <?php if (empty($lines)): ?>
                    <tr><td colspan="4" class="text-muted">No lines.</td></tr>
                <?php else: ?>
                    <?php foreach ($lines as $line): ?>
                        <tr>
                            <td><?= h($line['description'] ?? ($line['category_name'] ?? '')) ?></td>
                            <td class="text-end">Rs. <?= number_format((float)($line['base_amount'] ?? 0), 2) ?></td>
                            <td class="text-end">Rs. <?= number_format((float)($line['discount_amount'] ?? 0), 2) ?></td>
                            <td class="text-end fw-semibold">Rs. <?= number_format((float)($line['line_total'] ?? 0), 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if ((float)($invoice['fine_applied'] ?? 0) > 0): ?>
            <div class="mt-2 text-danger small">Automatic fine applied: Rs. <?= number_format((float)$invoice['fine_applied'], 2) ?></div>
        <?php endif; ?>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-6">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-3">Custom Fines</h2>
                <?php if (empty($fines)): ?>
                    <div class="text-muted small">No custom fines.</div>
                <?php else: ?>
                    <ul class="list-group list-group-flush" style="max-height: 320px; overflow-y: auto;">
                        <?php foreach ($fines as $f): ?>
                            <li class="list-group-item px-0 d-flex justify-content-between">
                                <span><?= h($f['fine_type'] ?? 'Fine') ?></span>
                                <strong>Rs. <?= number_format((float)($f['amount'] ?? 0), 2) ?></strong>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-3">Collections</h2>
                <?php if (empty($collections)): ?>
                    <div class="text-muted small">No payments recorded yet.</div>
                <?php else: ?>
                    <ul class="list-group list-group-flush" style="max-height: 320px; overflow-y: auto;">
                        <?php foreach ($collections as $c): ?>
                            <li class="list-group-item px-0 d-flex justify-content-between align-items-start">
                                <span class="small">
                                    <?= h(date('d M Y H:i', strtotime((string)($c['collected_at'] ?? 'now')))) ?> &middot; <?= h($c['method'] ?? 'cash') ?>
                                    <br>
                                    <span class="text-muted">
                                        <i class="bi bi-person-badge me-1"></i><?= h($c['collected_by_name'] ?? 'Unknown user') ?>
                                    </span>
                                </span>
                                <span class="d-flex align-items-center gap-2">
                                    <strong>Rs. <?= number_format((float)($c['amount'] ?? 0), 2) ?></strong>
                                    <?php if (RBAC::hasPermission('fees.manage')): ?>
                                    <form method="post" action="<?= h(route_url('fees/collectionDelete')) ?>" class="d-inline"
                                          onsubmit="return confirm('Remove this Rs <?= number_format((float)($c['amount'] ?? 0), 2) ?> payment? Use this to undo a duplicate/mistaken entry.');">
                                        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                        <input type="hidden" name="invoice_id" value="<?= $invoiceId ?>">
                                        <input type="hidden" name="collection_id" value="<?= (int)($c['id'] ?? 0) ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger py-0 px-1" title="Remove this payment">
                                            <i class="bi bi-trash small"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>