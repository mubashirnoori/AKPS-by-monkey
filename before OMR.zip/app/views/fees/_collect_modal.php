<?php
// Variables: $invoice, $invoiceId, $onBehalfOptions, $onBehalfDefaultStaffId, $showOnBehalfPicker
// Rendered as a bare HTML fragment (no layout) and injected into the "Collect Payment" modal body.
$invoice = $invoice ?? [];
$invoiceId = (int)($invoiceId ?? 0);
$showOnBehalfPicker = !empty($showOnBehalfPicker);
$onBehalfOptions = $onBehalfOptions ?? [];
$onBehalfDefaultStaffId = (int)($onBehalfDefaultStaffId ?? 0);

$status = $invoice['status'] ?? 'open';
$totalDue = (float)($invoice['total_due'] ?? 0);
$collected = (float)($invoice['collected_amount'] ?? 0);
$remaining = max(0, $totalDue - $collected);
$lines = $invoice['lines'] ?? [];
$studentName = trim(($invoice['first_name'] ?? '') . ' ' . ($invoice['last_name'] ?? ''));
?>
<div class="mb-3">
    <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
        <div>
            <div class="fw-semibold"><?= h($invoice['invoice_no'] ?? '') ?></div>
            <div class="text-muted small"><?= h($studentName) ?> (<?= h($invoice['admission_no'] ?? '') ?>)</div>
        </div>
        <div class="text-end">
            <div class="text-muted small">Remaining</div>
            <div class="fw-semibold fs-5 <?= $remaining > 0 ? 'text-danger' : 'text-success' ?>">Rs <?= number_format($remaining, 2) ?></div>
        </div>
    </div>
</div>

<div id="collectModalAlert"></div>

<?php if ($status === 'paid' || $remaining <= 0.001): ?>
    <div class="alert alert-success mb-0"><i class="bi bi-check-circle-fill me-1"></i> This invoice is fully paid — nothing left to collect.</div>
<?php else: ?>
<form id="collectModalForm" data-invoice-id="<?= $invoiceId ?>">
    <?php csrf_field(); ?>
    <input type="hidden" name="action" value="record_payment">
    <input type="hidden" name="invoice_id" value="<?= $invoiceId ?>">

    <?php if (!empty($lines)): ?>
    <div class="table-responsive mb-3" style="max-height: 220px; overflow-y: auto;">
        <table class="table table-sm align-middle mb-0">
            <thead>
                <tr>
                    <th style="width:40px;">
                        <input type="checkbox" class="form-check-input" id="modalSelectAllMonths" title="Select all unpaid">
                    </th>
                    <th>Fee / Month</th>
                    <th class="text-end">Pending</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($lines as $line): ?>
                    <?php
                    $lid = (int)($line['id'] ?? 0);
                    $paidLine = (float)($line['paid'] ?? 0);
                    $lineTotal = (float)($line['line_total'] ?? 0);
                    $pendingLine = max(0, $lineTotal - $paidLine);
                    $isLinePaid = $pendingLine <= 0.001;
                    ?>
                    <tr>
                        <td>
                            <?php if (!$isLinePaid): ?>
                                <input type="checkbox" class="form-check-input modal-month-check"
                                       name="line_ids[]" value="<?= $lid ?>"
                                       data-pending="<?= number_format($pendingLine, 2, '.', '') ?>">
                            <?php else: ?>
                                <i class="bi bi-check-lg text-success"></i>
                            <?php endif; ?>
                        </td>
                        <td class="small"><?= h($line['description'] ?? $line['category_name'] ?? 'Fee') ?></td>
                        <td class="text-end small <?= $pendingLine > 0 ? 'text-danger fw-semibold' : 'text-success' ?>">Rs <?= number_format($pendingLine, 2) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
        <div class="alert alert-light border small">No month lines on this invoice — enter amount manually.</div>
    <?php endif; ?>

    <?php if ($showOnBehalfPicker): ?>
    <div class="mb-3">
        <label class="form-label">Collecting on behalf of <span class="text-danger">*</span></label>
        <select class="form-select" name="on_behalf_of_staff_id" required>
            <option value="">— Select teacher/staff —</option>
            <?php foreach ($onBehalfOptions as $opt): ?>
                <?php $sid = (int)$opt['staff_profile_id']; ?>
                <option value="<?= $sid ?>" <?= $sid === $onBehalfDefaultStaffId ? 'selected' : '' ?>>
                    <?= h($opt['full_name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
        <div class="form-text">Counts toward that teacher/principal's own fee ledger and balance.</div>
    </div>
    <?php endif; ?>

    <div class="row g-3">
        <div class="col-md-4">
            <label class="form-label">Method</label>
            <select name="method" class="form-select">
                <option value="cash">Cash</option>
                <option value="card">Card</option>
                <option value="bank">Bank Transfer</option>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label">Amount (Rs)</label>
            <input class="form-control" name="amount" id="modalCollectAmount" type="number" step="0.01" min="0.01"
                   value="<?= number_format($remaining, 2, '.', '') ?>" required>
        </div>
        <div class="col-md-4">
            <label class="form-label">Notes (optional)</label>
            <input class="form-control" name="notes" placeholder="e.g. Received at counter">
        </div>
    </div>

    <div class="d-flex justify-content-end gap-2 mt-4">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
        <button class="btn btn-success" type="submit" id="modalBtnRecordPayment">
            <i class="bi bi-cash-coin me-1"></i> Record Payment
        </button>
    </div>
</form>

<script>
(function () {
    const checks = () => Array.from(document.querySelectorAll('#collectModalForm .modal-month-check'));
    const amountEl = document.getElementById('modalCollectAmount');
    const selectAll = document.getElementById('modalSelectAllMonths');
    const fullRemaining = <?= json_encode(number_format($remaining, 2, '.', '')) ?>;

    function syncAmount() {
        const selected = checks().filter(c => c.checked);
        let sum = 0;
        selected.forEach(c => { sum += parseFloat(c.dataset.pending || '0') || 0; });
        amountEl.value = selected.length > 0 ? sum.toFixed(2) : fullRemaining;
        if (selectAll) {
            const unpaid = checks();
            selectAll.checked = unpaid.length > 0 && unpaid.every(c => c.checked);
        }
    }

    checks().forEach(c => c.addEventListener('change', syncAmount));
    selectAll?.addEventListener('change', function () {
        checks().forEach(c => { c.checked = selectAll.checked; });
        syncAmount();
    });
})();
</script>
<?php endif; ?>
