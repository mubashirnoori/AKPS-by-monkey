<?php
// Variables: start_date,end_date,classSectionId,classSections,rows,summary,page,perPage,totalPages
$routeBase = base_url('/index.php');
$summary = $summary ?? ['total' => 0, 'present' => 0, 'absent' => 0, 'late' => 0, 'excused' => 0, 'holiday' => 0];
$page = $page ?? 1;
$perPage = $perPage ?? 50;
$totalPages = $totalPages ?? 1;
$attendedCount = $summary['present'] + $summary['late'];
// Holiday days are excluded from the denominator — they were never a chance to attend.
$ratableCount = $summary['total'] - $summary['holiday'];
$attendanceRate = $ratableCount > 0 ? round(($attendedCount / $ratableCount) * 100, 1) : 0;

$statusBadge = static function (string $status): string {
    $map = [
        'present' => 'bg-success',
        'absent'  => 'bg-danger',
        'late'    => 'bg-warning text-dark',
        'excused' => 'bg-info text-dark',
        'holiday' => 'bg-primary',
    ];
    return $map[$status] ?? 'bg-secondary';
};

// Build the base query params (minus 'page') once so pagination links can just tack a page number on.
$pageQueryBase = ['route' => 'reports/studentAttendance', 'start_date' => $start_date, 'end_date' => $end_date, 'class_section_id' => $classSectionId];
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Student Attendance Report</h1>
        <div class="text-muted">Export CSV or print to PDF.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=reports/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="portal-kpis mb-3">
    <div class="portal-kpi portal-kpi--c">
        <div class="portal-kpi__label"><i class="bi bi-list-check"></i> Total Records</div>
        <div class="portal-kpi__value"><?= number_format($summary['total']) ?></div>
        <div class="portal-kpi__hint"><?= h($start_date) ?> — <?= h($end_date) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--b">
        <div class="portal-kpi__label"><i class="bi bi-check-circle"></i> Present</div>
        <div class="portal-kpi__value"><?= number_format($summary['present']) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--e">
        <div class="portal-kpi__label"><i class="bi bi-x-circle"></i> Absent</div>
        <div class="portal-kpi__value"><?= number_format($summary['absent']) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--d">
        <div class="portal-kpi__label"><i class="bi bi-clock-history"></i> Late</div>
        <div class="portal-kpi__value"><?= number_format($summary['late']) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--c">
        <div class="portal-kpi__label"><i class="bi bi-calendar-event"></i> Holiday</div>
        <div class="portal-kpi__value"><?= number_format($summary['holiday']) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--a">
        <div class="portal-kpi__label"><i class="bi bi-graph-up"></i> Attendance Rate</div>
        <div class="portal-kpi__value"><?= $attendanceRate ?>%</div>
        <div class="portal-kpi__hint">Present + Late, of non-holiday days</div>
    </div>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="reports/studentAttendance">
            <div class="col-md-3">
                <label class="form-label">Start</label>
                <input class="form-control" type="date" name="start_date" value="<?= h($start_date) ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">End</label>
                <input class="form-control" type="date" name="end_date" value="<?= h($end_date) ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Class/Section</label>
                <select class="form-select" name="class_section_id">
                    <option value="0">All</option>
                    <?php foreach ($classSections as $cs): ?>
                        <option value="<?= (int)$cs['id'] ?>" <?= ((int)$classSectionId === (int)$cs['id']) ? 'selected' : '' ?>>
                            <?= h($cs['class_name'] . ' ' . $cs['section_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2 d-grid">
                <button class="btn btn-primary" type="submit">Load</button>
            </div>
        </form>

        <div class="mt-3 d-flex gap-2">
            <?php
            // $routeBase is bare '/index.php' with no '?route=' — the form works because
            // it has a hidden route input, but this link has no form to supply one, so it
            // was missing '?route=reports/studentAttendance' entirely and 404'd (the '&'
            // with no preceding '?' makes '&start_date=...' part of the path, not a query
            // string).
            $q = http_build_query(['route' => 'reports/studentAttendance', 'start_date'=>$start_date,'end_date'=>$end_date,'class_section_id'=>$classSectionId,'export'=>'csv']);
            ?>
            <a class="btn btn-outline-primary btn-sm" href="<?= htmlspecialchars($routeBase . '?' . $q, ENT_QUOTES, 'UTF-8') ?>">Export CSV</a>
            <button class="btn btn-outline-secondary btn-sm" type="button" onclick="window.print()">Print</button>
        </div>

        <hr class="my-3">

        <form method="get" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="reports/studentAttendance">
            <input type="hidden" name="export" value="grid_csv">
            <input type="hidden" name="class_section_id" value="<?= (int)$classSectionId ?>">
            <div class="col-auto">
                <label class="form-label mb-0 fw-semibold">Attendance Register (Excel-style grid)</label>
                <div class="text-muted small">One row per student, one column per day — Sundays/configured holidays fill in automatically as "H".</div>
            </div>
            <div class="col-md-2">
                <label class="form-label">Start</label>
                <input class="form-control" type="date" name="grid_start" value="<?= h($start_date) ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">End</label>
                <input class="form-control" type="date" name="grid_end" value="<?= h($end_date) ?>">
            </div>
            <div class="col-md-3 form-check ms-2 mt-4">
                <input type="hidden" name="sunday_off" value="0">
                <input class="form-check-input" type="checkbox" name="sunday_off" id="sundayOffStudent" value="1" checked>
                <label class="form-check-label" for="sundayOffStudent">Mark Sundays as holiday</label>
            </div>
            <div class="col-md-2 d-grid">
                <button class="btn btn-primary btn-sm" type="submit">Export Register</button>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-header bg-white d-flex align-items-center justify-content-between flex-wrap gap-2">
        <strong>Records</strong>
        <span class="text-muted small">
            <?php if ($summary['total'] > 0): ?>
                Showing <?= number_format((($page - 1) * $perPage) + 1) ?>–<?= number_format(min($page * $perPage, $summary['total'])) ?> of <?= number_format($summary['total']) ?>
            <?php else: ?>
                No records
            <?php endif; ?>
        </span>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-striped mb-0">
                <thead>
                <tr><th>Date</th><th>Student</th><th>Admission</th><th>Class</th><th>Status</th></tr>
                </thead>
                <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="5" class="text-muted">No records.</td></tr>
                <?php else: ?>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td><?= h($r['attendance_date'] ?? '') ?></td>
                            <td class="fw-semibold"><?= h(trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? ''))) ?></td>
                            <td><?= h($r['admission_no'] ?? '') ?></td>
                            <td class="text-muted small"><?= h(trim(($r['class_name'] ?? '') . ' ' . ($r['section_name'] ?? ''))) ?></td>
                            <td><span class="badge <?= $statusBadge($r['status'] ?? '') ?>"><?= h(ucfirst($r['status'] ?? '')) ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if ($totalPages > 1): ?>
<nav class="mt-3">
    <ul class="pagination pagination-sm justify-content-center flex-wrap">
        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
            <a class="page-link" href="<?= h($routeBase . '?' . http_build_query(array_merge($pageQueryBase, ['page' => max(1, $page - 1)]))) ?>">Previous</a>
        </li>
        <?php
        // Windowed page numbers (current ± 2) so a wide date range doesn't turn the
        // pager itself into another long list — this is the same fix the report needed.
        $windowStart = max(1, $page - 2);
        $windowEnd = min($totalPages, $page + 2);
        if ($windowStart > 1): ?>
            <li class="page-item"><a class="page-link" href="<?= h($routeBase . '?' . http_build_query(array_merge($pageQueryBase, ['page' => 1]))) ?>">1</a></li>
            <?php if ($windowStart > 2): ?><li class="page-item disabled"><span class="page-link">…</span></li><?php endif; ?>
        <?php endif; ?>
        <?php for ($p = $windowStart; $p <= $windowEnd; $p++): ?>
            <li class="page-item <?= $p === (int)$page ? 'active' : '' ?>">
                <a class="page-link" href="<?= h($routeBase . '?' . http_build_query(array_merge($pageQueryBase, ['page' => $p]))) ?>"><?= $p ?></a>
            </li>
        <?php endfor; ?>
        <?php if ($windowEnd < $totalPages): ?>
            <?php if ($windowEnd < $totalPages - 1): ?><li class="page-item disabled"><span class="page-link">…</span></li><?php endif; ?>
            <li class="page-item"><a class="page-link" href="<?= h($routeBase . '?' . http_build_query(array_merge($pageQueryBase, ['page' => $totalPages]))) ?>"><?= $totalPages ?></a></li>
        <?php endif; ?>
        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
            <a class="page-link" href="<?= h($routeBase . '?' . http_build_query(array_merge($pageQueryBase, ['page' => min($totalPages, $page + 1)]))) ?>">Next</a>
        </li>
    </ul>
</nav>
<?php endif; ?>