<?php
// Variables expected: $content, $pageTitle, $flash, $user
$settingsMap = [];
try {
    if (class_exists('Database')) {
        $rows = Database::fetchAll('SELECT `key`, `value` FROM settings');
        foreach ($rows as $r) {
            $settingsMap[(string)($r['key'] ?? '')] = (string)($r['value'] ?? '');
        }
    }
} catch (Throwable $e) {
    // Keep layout rendering even if settings are not readable.
}
$schoolName = $settingsMap['branding_school_name'] ?? $settingsMap['institute_name'] ?? 'SchoolSMS';
$logoPath = $settingsMap['branding_logo_path'] ?? '';
$faviconPath = $settingsMap['branding_favicon_path'] ?? '';
$currentRoute = (string)($_GET['route'] ?? 'dashboard/index');
$routeClass = 'route-' . preg_replace('/[^a-z0-9]+/i', '-', strtolower($currentRoute));
$routeStartsWith = static function (string $prefix) use ($currentRoute): bool {
    return strpos($currentRoute, $prefix) === 0;
};
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!--
        Fixed (non-device-width) viewport, intentional.
        This app is primarily viewed through an Android WebView wrapper set up
        to show the desktop/laptop layout on mobile screens. "width=device-width"
        lets the WebView report the real (narrow) screen width on its first
        layout pass, which can race ahead of CSS settling and briefly render
        the mobile (<991px) breakpoint until a click/reflow corrects it.
        Fixing the width to 1280 removes that race: the page always lays out
        at 1280 CSS px and the WebView auto-scales it to fit the real screen.

        Deliberately a STATIC tag — do not rewrite it at runtime via JS.
        An earlier version of this computed the exact fit-to-screen scale in
        a small script and mutated this tag's content after load, to lock
        pinch/double-tap zoom at that value. That caused a worse problem:
        mutating the viewport meta after the WebView had already started
        rendering triggered an intermittent GPU tile-seam artifact (a thin
        vertical line that would appear after scrolling and clear on
        refresh) — a known WebView quirk around live viewport changes.
        Double-tap-zoom is instead prevented via `touch-action: manipulation`
        on <html> in app.css, which needs no viewport mutation at all and
        doesn't have this side effect.
        Do NOT add maximum-scale/minimum-scale/user-scalable=no as static
        values either — pinning the scale to a fixed number (e.g. 1.0)
        breaks the "shrink 1280px down to fit this screen" behavior, so the
        page renders at true 1:1 size and only a small, off-center slice of
        it is visible (this was the original login-page cropping bug).
        If a genuine mobile-web (not WebView) audience is ever needed, this
        should switch back to width=device-width and the CSS breakpoints
        should be relied on normally.
    -->
    <meta name="viewport" content="width=1280">
    <title><?= h(($pageTitle ?? 'School Management System') . ' - ' . $schoolName) ?></title>
    <?php if ($faviconPath !== ''): ?>
        <link rel="icon" href="<?= htmlspecialchars(base_url($faviconPath), ENT_QUOTES, 'UTF-8') ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= htmlspecialchars(base_url('/assets/css/app.css?v=29'), ENT_QUOTES, 'UTF-8') ?>">
    <link rel="stylesheet" href="<?= htmlspecialchars(base_url('/assets/css/nav-rail.css?v=6'), ENT_QUOTES, 'UTF-8') ?>">
</head>
<body class="<?= h($routeClass) ?>">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">

    <button class="btn btn-light d-lg-none me-2" onclick="toggleSidebar()">
        <i class="bi bi-list"></i>
    </button>

    <a class="navbar-brand" href="<?= htmlspecialchars(route_url('dashboard/index'), ENT_QUOTES, 'UTF-8') ?>">
            <?php if ($logoPath !== ''): ?>
                <img src="<?= htmlspecialchars(base_url($logoPath), ENT_QUOTES, 'UTF-8') ?>" alt="Logo" style="height:28px;width:auto;margin-right:8px;vertical-align:middle;">
            <?php endif; ?>
            <?= h($schoolName) ?>
        </a>
        <?php
        $navAvatarUrl = $user ? user_avatar_url((int)($user['id'] ?? 0)) : null;
        $navInitials = '';
        foreach (preg_split('/\s+/', trim((string)($user['username'] ?? ''))) as $part) {
            if ($part !== '') { $navInitials .= mb_strtoupper(mb_substr($part, 0, 1)); }
            if (mb_strlen($navInitials) >= 2) { break; }
        }
        ?>
        <?php if ($user): ?>
            <button type="button" id="smsRefreshBtn" class="btn ms-auto me-2" title="Refresh page" aria-label="Refresh page" onclick="window.location.reload()"
                    style="width:38px;height:38px;border-radius:50%;background:#2c3646;outline:2px solid rgba(255,255,255,0.18);outline-offset:1px;display:flex;align-items:center;justify-content:center;padding:0;">
                <i class="bi bi-arrow-clockwise" style="color:#e5e7eb;font-size:1.1rem;"></i>
            </button>
            <div class="dropdown me-2" id="notifBell">
                <button class="btn position-relative" type="button" id="notifBellBtn" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Notifications" style="width:38px;height:38px;border-radius:50%;background:#2c3646;outline:2px solid rgba(255,255,255,0.18);outline-offset:1px;display:flex;align-items:center;justify-content:center;padding:0;">
                    <i class="bi bi-bell" style="color:#e5e7eb;font-size:1.1rem;"></i>
                    <span class="badge rounded-pill position-absolute top-0 start-100 translate-middle" id="notifBadge" style="display:none;font-size:.6rem;background:var(--sms-margin-red);color:#fecdd3;"></span>
                </button>
                <div class="dropdown-menu dropdown-menu-end p-0 account-dropdown-menu" style="width:340px;max-height:420px;overflow-y:auto;" id="notifDropdown">
                    <div class="d-flex align-items-center justify-content-between px-3 py-2" style="border-bottom:1px solid var(--sms-border);">
                        <span class="fw-semibold small" style="color:var(--sms-heading);font-family:'Lora',serif;">Notifications</span>
                        <a href="<?= htmlspecialchars(route_url('notifications/index'), ENT_QUOTES, 'UTF-8') ?>" class="small" style="color:var(--sms-primary);text-decoration:none;">View all</a>
                    </div>
                    <div id="notifList" class="small text-center py-4" style="color:var(--sms-muted);">Loading…</div>
                </div>
            </div>
            <style>
                #notifList .notif-item:hover { background: rgba(255,255,255,0.06) !important; }
                #notifList .notif-item:last-child { border-bottom: none !important; }
            </style>
            <div class="dropdown account-dropdown">
                <button class="btn account-avatar-btn" type="button" id="accountMenuBtn" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Account menu">
                    <?php if ($navAvatarUrl): ?>
                        <img src="<?= h($navAvatarUrl) ?>" alt="">
                    <?php else: ?>
                        <span><?= h($navInitials ?: '?') ?></span>
                    <?php endif; ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end account-dropdown-menu" aria-labelledby="accountMenuBtn">
                    <li><span class="dropdown-item-text account-role"><i class="bi bi-person-circle me-2"></i><?= h($user['role_name'] ?? '') ?></span></li>
                    <li><a class="dropdown-item" href="<?= htmlspecialchars(route_url('auth/changePassword'), ENT_QUOTES, 'UTF-8') ?>"><i class="bi bi-key me-2"></i>Change Password</a></li>
                    <li>
                        <form method="post" action="<?= htmlspecialchars(route_url('auth/logout'), ENT_QUOTES, 'UTF-8') ?>">
                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                            <button type="submit" class="dropdown-item"><i class="bi bi-box-arrow-right me-2"></i>Logout</button>
                        </form>
                    </li>
                </ul>
            </div>
        <?php else: ?>
            <a class="btn btn-outline-light btn-sm ms-auto" href="<?= htmlspecialchars(route_url('auth/login'), ENT_QUOTES, 'UTF-8') ?>">Login</a>
        <?php endif; ?>
    </div>
</nav>

<?php
$menuItems = $user ? require __DIR__ . '/../config/menu.php' : [];

/** Whether the current user can see this menu entry — same permission logic as before. */
$menuVisible = static function (array $item): bool {
    if ($item['key'] === 'dashboard') {
        return true;
    }
    $perm = $item['permission'] ?? null;
    if ($perm === null) {
        return true;
    }
    foreach ((array)$perm as $p) {
        if (RBAC::hasPermission($p)) {
            return true;
        }
    }
    return false;
};

$visibleMenu = array_values(array_filter($menuItems, $menuVisible));
foreach ($visibleMenu as &$menuItem) {
    if ($menuItem['label'] === null) {
        $menuItem['label'] = RBAC::isAdmin() ? 'Dashboard' : 'My Portal';
    }
}
unset($menuItem);

// Which top-level item is "active" for the current URL, so its flyout is open on page load.
$activeMenuKey = null;
foreach ($visibleMenu as $item) {
    $prefix = $item['prefix'] ?? ($item['key'] . '/');
    if ($item['key'] === 'dashboard') {
        if ($routeStartsWith('dashboard/') || $routeStartsWith('portal/')) {
            $activeMenuKey = 'dashboard';
        }
        continue;
    }
    if ($prefix !== null && $routeStartsWith($prefix)) {
        $activeMenuKey = $item['key'];
    }
}

/** Whether the current user can see this specific child link — falls back to "visible" when the child has no 'permission' key (same as before this key existed). */
$childVisible = static function (array $child): bool {
    $perm = $child['permission'] ?? null;
    if ($perm === null) {
        return true;
    }
    foreach ((array)$perm as $p) {
        if (RBAC::hasPermission($p)) {
            return true;
        }
    }
    return false;
};

$childHref = static function (array $child): string {
    if (!empty($child['href'])) {
        return base_url('/' . ltrim((string)$child['href'], '/'));
    }
    return route_url((string)$child['route']);
};
?>

<div class="nav-rail-backdrop" id="navRailBackdrop" onclick="closeSidebar()"></div>

<div class="app-shell">
    <?php if ($user): ?>
        <nav class="nav-rail" id="navRail" aria-label="Main navigation">
            <?php foreach ($visibleMenu as $item):
                $hasChildren = !empty(array_filter($item['children'], $childVisible));
                $label = $item['label'];
                $isActive = $activeMenuKey === $item['key'];
            ?>
                <?php if ($hasChildren): ?>
                    <button type="button"
                            class="nav-rail__item <?= $isActive ? 'is-active' : '' ?>"
                            data-rail-toggle="<?= h($item['key']) ?>"
                            aria-expanded="false">
                        <i class="bi <?= h($item['icon']) ?>"></i>
                        <span class="nav-rail__label"><?= h($label) ?></span>
                    </button>
                <?php else: ?>
                    <a class="nav-rail__item <?= $isActive ? 'is-active' : '' ?>"
                       href="<?= htmlspecialchars(route_url($item['route']), ENT_QUOTES, 'UTF-8') ?>">
                        <i class="bi <?= h($item['icon']) ?>"></i>
                        <span class="nav-rail__label"><?= h($label) ?></span>
                    </a>
                <?php endif; ?>
            <?php endforeach; ?>
        </nav>

        <?php foreach ($visibleMenu as $item): if (empty($item['children'])) continue; $isActive = $activeMenuKey === $item['key']; $visibleChildren = array_filter($item['children'], $childVisible); if (empty($visibleChildren)) continue; ?>
            <div class="nav-flyout" data-flyout="<?= h($item['key']) ?>">
                <div class="nav-flyout__inner">
                    <div class="nav-flyout__title"><?= h($item['label']) ?></div>
                    <?php foreach ($visibleChildren as $child): $childRoute = (string)$child['route']; ?>
                        <a class="nav-flyout__link <?= $currentRoute === $childRoute ? 'is-active' : '' ?>"
                           href="<?= htmlspecialchars($childHref($child), ENT_QUOTES, 'UTF-8') ?>"
                           <?php if (!empty($child['target'])): ?>target="<?= h($child['target']) ?>" rel="noopener"<?php endif; ?>>
                            <i class="bi <?= h($child['icon']) ?>"></i>
                            <span><?= h($child['label']) ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <main class="app-shell__main">
        <?php if (!empty($flash['message'])): ?>
            <div class="alert alert-<?= h($flash['type'] ?? 'info') ?> alert-dismissible fade show" role="alert" id="smsFlashAlert" style="transition: opacity .4s ease;">
                <?= h($flash['message']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <script>
            setTimeout(function () {
                var el = document.getElementById('smsFlashAlert');
                if (!el) return;
                el.style.opacity = '0';
                setTimeout(function () { el.remove(); }, 400);
            }, 3000);
            </script>
        <?php endif; ?>
        <?= $content ?>
    </main>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= h(base_url('/assets/js/ajax-forms.js?v=3')) ?>"></script>
<script src="<?= h(base_url('/assets/js/bulk-select.js?v=1')) ?>"></script>
<script src="<?= h(base_url('/assets/js/whatsapp-share.js?v=2')) ?>"></script>

<script>
// Keep --header-h in sync with the real navbar height. The navbar is
// position:fixed and every rail/flyout/drawer offset below it uses this
// variable (falling back to 56px) instead of a hardcoded number, so a
// taller navbar (e.g. a school name that wraps to two lines on a narrow
// screen) can never make those panels overlap it.
(function () {
    var navbarEl = document.querySelector('nav.navbar');
    function syncHeaderHeight() {
        if (!navbarEl) return;
        var h = navbarEl.offsetHeight || 56;
        document.documentElement.style.setProperty('--header-h', h + 'px');
    }
    syncHeaderHeight();
    window.addEventListener('resize', syncHeaderHeight);
    window.addEventListener('orientationchange', syncHeaderHeight);
    if (window.ResizeObserver && navbarEl) {
        new ResizeObserver(syncHeaderHeight).observe(navbarEl);
    }
})();

function toggleSidebar() {
    var rail = document.getElementById('navRail');
    if (!rail) return;
    if (rail.classList.contains('is-active')) {
        closeSidebar();
    } else {
        openSidebar();
    }
}

function openSidebar() {
    var rail = document.getElementById('navRail');
    var backdrop = document.getElementById('navRailBackdrop');
    if (rail) rail.classList.add('is-active');
    if (backdrop) backdrop.classList.add('is-active');
    document.body.classList.add('sidebar-open');
}

function closeSidebar() {
    var rail = document.getElementById('navRail');
    var backdrop = document.getElementById('navRailBackdrop');
    if (rail) rail.classList.remove('is-active');
    if (backdrop) backdrop.classList.remove('is-active');
    document.body.classList.remove('sidebar-open');
    closeAllFlyouts();
}

function closeAllFlyouts() {
    document.querySelectorAll('.nav-flyout.is-open').forEach(function (el) {
        el.classList.remove('is-open');
    });
    document.querySelectorAll('.nav-rail__item.is-open').forEach(function (el) {
        el.classList.remove('is-open');
        el.setAttribute('aria-expanded', 'false');
    });
}

// Click a rail item that has children -> open/close its flyout panel (no navigation).
// Click a rail item with no children -> it's a plain <a>, browser navigates normally.
document.querySelectorAll('[data-rail-toggle]').forEach(function (btn) {
    btn.addEventListener('click', function () {
        var key = btn.getAttribute('data-rail-toggle');
        var flyout = document.querySelector('.nav-flyout[data-flyout="' + key + '"]');
        if (!flyout) return;
        var willOpen = !flyout.classList.contains('is-open');
        closeAllFlyouts();
        if (willOpen) {
            flyout.classList.add('is-open');
            btn.classList.add('is-open');
            btn.setAttribute('aria-expanded', 'true');
            // On mobile the rail drawer is already open when this is tapped; keep it open
            // so the flyout (which slides in from the same edge) is reachable.
        }
    });
});

// Escape closes everything.
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeSidebar();
});

// Clicking any actual page link inside the flyout closes it right away (the page is
// navigating anyway; this just avoids the panel staying visibly open behind it).
document.querySelectorAll('.nav-flyout__link').forEach(function (link) {
    link.addEventListener('click', function () {
        closeAllFlyouts();
    });
});

// Tapping a real link inside the mobile drawer/flyout should close the drawer after
// navigation is triggered (the page unloads anyway; this just avoids a stale-open flash).
document.addEventListener('click', function (e) {
    var rail = document.getElementById('navRail');
    if (!rail || !rail.classList.contains('is-active')) return;
    if (e.target.closest('.nav-flyout__link') || e.target.closest('.nav-rail__item[href]')) {
        closeSidebar();
    }
});

// The flyout now floats over the page instead of pushing it, so clicking anywhere outside
// the rail/flyout should close it (standard overlay behavior).
document.addEventListener('click', function (e) {
    if (e.target.closest('.nav-rail') || e.target.closest('.nav-flyout')) return;
    closeAllFlyouts();
});
</script>

<script>
function togglePasswordVisibility(inputId, btn) {
    var input = document.getElementById(inputId);
    if (!input) return;
    var icon = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        if (icon) { icon.classList.remove('bi-eye'); icon.classList.add('bi-eye-slash'); }
    } else {
        input.type = 'password';
        if (icon) { icon.classList.remove('bi-eye-slash'); icon.classList.add('bi-eye'); }
    }
}
</script>

<script>
<?php if ($user): ?>
(function () {
    var pollUrl = <?= json_encode(route_url('notifications/poll')) ?>;
    var markReadUrl = <?= json_encode(route_url('notifications/markRead')) ?>;
    var csrfToken = <?= json_encode(CSRF::token()) ?>;
    var badge = document.getElementById('notifBadge');
    var list = document.getElementById('notifList');
    var bellBtn = document.getElementById('notifBellBtn');

    var iconMap = {
        leave_request: 'bi-calendar2-x', leave_decision: 'bi-calendar2-check', inquiry: 'bi-person-plus', complaint: 'bi-flag',
        fee: 'bi-wallet2', fee_invoice: 'bi-receipt', fee_payment: 'bi-wallet2', result_published: 'bi-stats-chart',
        marks: 'bi-stats-chart', attendance: 'bi-clipboard-check', notice: 'bi-megaphone'
    };

    function escapeHtml(s) {
        var d = document.createElement('div');
        d.textContent = s || '';
        return d.innerHTML;
    }

    function render(data) {
        var count = data.unread || 0;
        if (badge) {
            if (count > 0) {
                badge.textContent = count > 99 ? '99+' : String(count);
                badge.style.display = '';
            } else {
                badge.style.display = 'none';
            }
        }
        if (!list) return;
        var items = data.notifications || [];
        if (items.length === 0) {
            list.innerHTML = '<div class="text-center py-4 small" style="color:var(--sms-muted);">No notifications yet.</div>';
            return;
        }
        list.innerHTML = items.map(function (n) {
            var icon = iconMap[n.type] || 'bi-bell';
            var unread = !n.is_read;
            var rowStyle = 'white-space:normal;color:var(--sms-text);padding:10px 16px;border-bottom:1px solid rgba(255,255,255,0.06);' +
                (unread ? 'background:rgba(184,135,62,0.10);' : '');
            return '<a href="#" class="d-flex gap-2 align-items-start notif-item" data-id="' + n.id +
                '" data-link="' + escapeHtml(n.link || '') + '" style="' + rowStyle + '">' +
                '<i class="bi ' + icon + ' mt-1" style="color:var(--sms-primary);"></i>' +
                '<span class="flex-grow-1"><span class="d-block fw-semibold small" style="color:var(--sms-heading);">' + escapeHtml(n.title) + '</span>' +
                (n.message ? '<span class="d-block small" style="color:var(--sms-muted);">' + escapeHtml(n.message) + '</span>' : '') +
                '</span></a>';
        }).join('');

        list.querySelectorAll('.notif-item').forEach(function (item) {
            item.addEventListener('click', function (e) {
                e.preventDefault();
                var id = item.getAttribute('data-id');
                var link = item.getAttribute('data-link');
                fetch(markReadUrl, {
                    method: 'POST',
                    headers: { 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'id=' + encodeURIComponent(id) + '&csrf_token=' + encodeURIComponent(csrfToken)
                }).finally(function () {
                    if (link) { window.location.href = link; }
                    else { refresh(); }
                });
            });
        });
    }

    function refresh() {
        fetch(pollUrl, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (r) { return r.json(); })
            .then(render)
            .catch(function () {});
    }

    if (bellBtn) {
        bellBtn.addEventListener('click', refresh);
    }
    refresh();
    setInterval(refresh, 60000); // keep the unread badge fresh without needing a page reload
})();
<?php endif; ?>
</script>

<!-- "Collect Payment" popup: opened from any element with data-collect-invoice-id="<id>"
     so collecting a payment doesn't navigate away from the invoice list/detail page.
     Everything else (fines, delete payment, mark settled, picking an invoice from
     scratch) still lives on the full fees/collect page. -->
<div class="modal fade" id="collectPaymentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Collect Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="collectPaymentModalBody">
                <div class="text-center text-muted py-4"><div class="spinner-border spinner-border-sm me-2"></div>Loading…</div>
            </div>
        </div>
    </div>
</div>

<script>
(function () {
    var modalEl = document.getElementById('collectPaymentModal');
    if (!modalEl) return;
    var bodyEl = document.getElementById('collectPaymentModalBody');
    var bsModal = new bootstrap.Modal(modalEl);
    // Two backends can feed this same popup: the admin/accountant "fees.manage"
    // endpoint (default), and the Teacher Portal endpoint, which stays scoped to
    // classes that teacher is assigned to collect fees for. A trigger picks which
    // one via data-collect-endpoint="portal"; anything else (or omitted) uses admin.
    var collectModalUrls = {
        admin: <?= json_encode(route_url('fees/collectModal')) ?>,
        portal: <?= json_encode(route_url('portal/feeCollectModal')) ?>
    };
    var activeCollectModalUrl = collectModalUrls.admin;

    function loadInvoice(invoiceId, endpoint) {
        activeCollectModalUrl = collectModalUrls[endpoint] || collectModalUrls.admin;
        bodyEl.innerHTML = '<div class="text-center text-muted py-4"><div class="spinner-border spinner-border-sm me-2"></div>Loading…</div>';
        bsModal.show();
        fetch(activeCollectModalUrl + '&invoice_id=' + encodeURIComponent(invoiceId), { credentials: 'same-origin' })
            .then(function (r) { return r.text(); })
            .then(function (html) { bodyEl.innerHTML = html; })
            .catch(function () {
                bodyEl.innerHTML = '<div class="alert alert-danger mb-0">Couldn\'t load this invoice — try again.</div>';
            });
    }

    // Event delegation: works for any current or future trigger on the page,
    // including rows swapped in by the invoice list's own AJAX refresh.
    document.addEventListener('click', function (e) {
        var trigger = e.target.closest('[data-collect-invoice-id]');
        if (!trigger) return;
        e.preventDefault();
        loadInvoice(trigger.getAttribute('data-collect-invoice-id'), trigger.getAttribute('data-collect-endpoint'));
    });

    // Submit handler is delegated too, since the form is injected after page load.
    document.addEventListener('submit', function (e) {
        var form = e.target.closest('#collectModalForm');
        if (!form) return;
        e.preventDefault();

        var btn = document.getElementById('modalBtnRecordPayment');
        var alertBox = document.getElementById('collectModalAlert');
        var originalBtnHtml = btn ? btn.innerHTML : '';
        if (btn) {
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span> Recording…';
        }
        if (alertBox) { alertBox.innerHTML = ''; }

        fetch(activeCollectModalUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            body: new FormData(form),
        })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data.success) {
                    if (alertBox) {
                        alertBox.innerHTML = '<div class="alert alert-success py-2 px-3 small mb-3">' + data.message + '</div>';
                    }
                    setTimeout(function () {
                        window.location.reload();
                    }, 700);
                } else {
                    if (btn) { btn.disabled = false; btn.innerHTML = originalBtnHtml; }
                    if (alertBox) {
                        alertBox.innerHTML = '<div class="alert alert-danger py-2 px-3 small mb-3">' + (data.message || 'Something went wrong.') + '</div>';
                    }
                }
            })
            .catch(function () {
                if (btn) { btn.disabled = false; btn.innerHTML = originalBtnHtml; }
                if (alertBox) {
                    alertBox.innerHTML = '<div class="alert alert-danger py-2 px-3 small mb-3">Network error — please try again.</div>';
                }
            });
    });
})();
</script>

<script>
// Registers the offline-fallback service worker (see /public/service-worker.js
// and /public/offline.html). Once installed, if the WebView ever tries to open
// this app with no internet connection, it shows our own "You're offline" page
// instead of Android's generic "Webpage not available" error screen. Safe to
// run on every page load — the browser/WebView only re-installs it when the
// file on the server actually changes.
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
        navigator.serviceWorker.register(
            '<?= htmlspecialchars(base_url('/service-worker.js'), ENT_QUOTES, 'UTF-8') ?>',
            { scope: '<?= htmlspecialchars(base_url('/'), ENT_QUOTES, 'UTF-8') ?>' }
        ).catch(function () { /* Not fatal — app works as before, just without the offline page. */ });
    });
}
</script>

</body>
</html>