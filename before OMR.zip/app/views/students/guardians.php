<?php
// Variables: $student, $guardians, $listFilters
$studentId = (int)($student['id'] ?? 0);
$studentName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
$listFilters = $listFilters ?? recall_list_filters('students', [
    'q' => '', 'class_section_id' => 0, 'student_status' => 'active', 'per_page' => 10, 'page' => 1,
]);
$listBackUrl = list_url('students/index', $listFilters);
$retQs = list_return_query($listFilters);
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Guardians</h1>
        <div class="text-muted"><?= h($studentName) ?> (<?= h($student['admission_no'] ?? '') ?>)</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars($listBackUrl, ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="row g-3">
    <div class="col-lg-7">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-3">Linked Guardians</h2>

                <?php if (empty($guardians)): ?>
                    <div class="text-muted">No guardians linked yet.</div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm table-striped mb-0">
                            <thead>
                                <tr>
                                    <th>Guardian</th>
                                    <th>Relation</th>
                                    <th>Phone</th>
                                    <th style="width: 120px;">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($guardians as $g): ?>
                                <tr>
                                    <td><?= h($g['full_name'] ?? '') ?></td>
                                    <td><?= h($g['relation'] ?? '') ?></td>
                                    <td><?= h($g['phone'] ?? '') ?></td>
                                    <td>
                                        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=students/guardiansRemove'), ENT_QUOTES, 'UTF-8') ?>" onsubmit="return confirm('Unlink this guardian?')">
                                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                            <input type="hidden" name="student_id" value="<?= (int)$studentId ?>">
                                            <input type="hidden" name="guardian_id" value="<?= (int)($g['id'] ?? 0) ?>">
                                            <?php list_return_fields($listFilters); ?>
                                            <button class="btn btn-sm btn-outline-danger" type="submit">Remove</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-3">Add Guardian</h2>
                <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=students/guardiansAdd'), ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="student_id" value="<?= (int)$studentId ?>">
                    <?php list_return_fields($listFilters); ?>

                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input class="form-control" name="full_name" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Relation</label>
                        <input class="form-control" name="relation" placeholder="Father/Mother/Guardian">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Phone</label>
                        <input class="form-control" name="phone">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input class="form-control" name="email">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Address</label>
                        <input class="form-control" name="address">
                    </div>

                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="is_primary" value="1" id="is_primary">
                            <label class="form-check-label" for="is_primary">Primary guardian</label>
                        </div>
                    </div>

                    <button class="btn btn-primary w-100" type="submit">Link Guardian</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mt-1">
    <div class="col-lg-7">
        <div class="card shadow-sm border-0 sms-overflow-visible">
            <div class="card-body">
                <h2 class="h6 mb-1">Link Existing Guardian</h2>
                <div class="text-muted small mb-3">
                    Use this for a sibling already at the school — linking the <strong>same</strong> guardian record
                    here (instead of adding a new one) means one parent login will see both children in their portal.
                </div>
                <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=students/guardiansLinkExisting'), ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="student_id" value="<?= (int)$studentId ?>">
                    <?php list_return_fields($listFilters); ?>

                    <div class="mb-3">
                        <label class="form-label">Guardian</label>
                        <div class="combo" data-combo-root data-combo-type="existing-guardian">
                            <input type="text" class="form-control combo-input" placeholder="Type a guardian's name or phone…" autocomplete="off">
                            <input type="hidden" name="existing_guardian_id" value="0">
                            <div class="combo-menu list-group shadow-sm"></div>
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="is_primary" value="1" id="is_primary_existing">
                            <label class="form-check-label" for="is_primary_existing">Primary guardian</label>
                        </div>
                    </div>

                    <button class="btn btn-outline-primary w-100" type="submit">Link Existing Guardian</button>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
.combo { position: relative; }
.combo-menu {
    display: none;
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    z-index: 40;
    max-height: 420px; /* comfortably fits the 10 results the server now returns */
    overflow-y: auto;
    margin-top: 2px;
}
.combo-menu .list-group-item { cursor: pointer; }
</style>
<script>
(function () {
    var SEARCH_URL = <?= json_encode(base_url('/index.php?route=students/guardianSearch') . '&student_id=' . $studentId, JSON_UNESCAPED_SLASHES) ?>;

    function escapeHtml(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    // Live database search (max 10 results, server-side) instead of
    // preloading every unlinked guardian into the page and filtering
    // client-side — that used to cap out at 500 and hide the rest.
    function initCombo(root) {
        var input = root.querySelector('.combo-input');
        var hidden = root.querySelector('input[type=hidden]');
        var menu = root.querySelector('.combo-menu');
        var debounceTimer = null;
        var requestSeq = 0;

        function renderMatches(matches) {
            menu.innerHTML = '';
            if (matches.length === 0) {
                var empty = document.createElement('div');
                empty.className = 'list-group-item text-muted small';
                empty.textContent = 'No matches';
                menu.appendChild(empty);
            }
            matches.forEach(function (item) {
                var a = document.createElement('a');
                a.href = '#';
                a.className = 'list-group-item list-group-item-action py-1 px-2';
                a.innerHTML = '<div>' + escapeHtml(item.label) + '</div>' +
                    (item.sub ? '<div class="text-muted small">' + escapeHtml(item.sub) + '</div>' : '');
                a.addEventListener('mousedown', function (e) {
                    e.preventDefault();
                    hidden.value = item.id;
                    input.value = item.label;
                    menu.style.display = 'none';
                });
                menu.appendChild(a);
            });
            menu.style.display = 'block';
        }

        function search(filter) {
            var seq = ++requestSeq;
            var url = SEARCH_URL + '&q=' + encodeURIComponent(filter || '');
            fetch(url, { credentials: 'same-origin' })
                .then(function (res) { return res.json(); })
                .then(function (matches) {
                    if (seq !== requestSeq) { return; }
                    renderMatches(matches);
                })
                .catch(function () {
                    if (seq !== requestSeq) { return; }
                    menu.innerHTML = '<div class="list-group-item text-danger small">Search failed — try again</div>';
                    menu.style.display = 'block';
                });
        }

        input.addEventListener('focus', function () { search(input.value); });
        input.addEventListener('input', function () {
            hidden.value = 0;
            clearTimeout(debounceTimer);
            var value = input.value;
            debounceTimer = setTimeout(function () { search(value); }, 250);
        });
        input.addEventListener('blur', function () {
            setTimeout(function () { menu.style.display = 'none'; }, 150);
        });
    }

    document.querySelectorAll('[data-combo-type="existing-guardian"]').forEach(function (el) {
        initCombo(el);
    });
})();
</script>

