<?php
// Variables: $student, $guardians, $invoices, $totalDue, $totalCollected, $pendingBalance, $classHistory, $listFilters
$student = $student ?? [];
$guardians = $guardians ?? [];
$invoices = $invoices ?? [];
$classHistory = $classHistory ?? [];
$retQs = list_return_query($listFilters ?? []);
$id = (int)($student['id'] ?? 0);

$_pFiles = glob(dirname(__DIR__, 3) . '/public/uploads/students/' . $id . '.*') ?: [];
$_pFile = !empty($_pFiles) ? $_pFiles[0] : null;
$photoSrc = $_pFile ? base_url('/uploads/students/' . basename($_pFile)) . '?v=' . filemtime($_pFile) : '';
$initials = strtoupper(substr((string)($student['first_name'] ?? 'S'), 0, 1) . substr((string)($student['last_name'] ?? ''), 0, 1));

$fullName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
$isActive = (int)($student['status'] ?? 1) === 1;

$feeVal = (float)($student['fee_discount_percent'] ?? 0);
$feeIsPct = (int)($student['fee_discount_is_percent'] ?? 1) === 1;

$editUrl = base_url('/index.php?route=students/edit&id=' . $id . $retQs);
$guardiansAddUrl = base_url('/index.php?route=students/guardians&student_id=' . $id . $retQs);
$backUrl = base_url('/index.php?route=students/index' . $retQs);

$latestInvoiceId = !empty($invoices) ? (int)($invoices[0]['id'] ?? 0) : 0;
$collectUrl = $latestInvoiceId > 0
    ? base_url('/index.php?route=fees/collect&invoice_id=' . $latestInvoiceId)
    : base_url('/index.php?route=fees/generateInvoices&q=' . rawurlencode((string)($student['admission_no'] ?? '')));
$collectLabel = $latestInvoiceId > 0 ? 'Collect Fee' : 'Generate Invoice';
?>

<div class="mb-3">
    <a class="text-decoration-none small text-muted" href="<?= h($backUrl) ?>"><i class="bi bi-arrow-left me-1"></i>Back to Students</a>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <div class="d-flex flex-wrap align-items-center gap-3">
            <?php if ($photoSrc): ?>
                <img src="<?= h($photoSrc) ?>" alt="" style="width:72px;height:72px;border-radius:50%;object-fit:cover;">
            <?php else: ?>
                <div style="width:72px;height:72px;border-radius:50%;background:#eef2ff;display:flex;align-items:center;justify-content:center;font-size:1.4rem;font-weight:700;color:#3b55e0;">
                    <?= h($initials) ?>
                </div>
            <?php endif; ?>

            <div class="flex-grow-1">
                <div class="d-flex align-items-center gap-2 flex-wrap">
                    <h1 class="h4 mb-0"><?= h($fullName) ?></h1>
                    <?php if ($isActive): ?>
                        <span class="badge text-bg-success">Active</span>
                    <?php else: ?>
                        <span class="badge text-bg-secondary">Left school</span>
                    <?php endif; ?>
                </div>
                <div class="text-muted small mt-1">
                    Admission #<?= h($student['admission_no'] ?? '') ?>
                    <?php if (!empty($student['current_class_name'])): ?>
                        &middot; <?= h($student['current_class_name'] . ' ' . $student['current_section_name']) ?>
                        <?php if (!empty($student['roll_number'])): ?> &middot; Roll #<?= (int)$student['roll_number'] ?><?php endif; ?>
                    <?php else: ?>
                        &middot; <span class="text-muted">Unassigned class</span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="d-flex gap-2">
                <a class="btn btn-outline-primary btn-sm" href="<?= h($editUrl) ?>"><i class="bi bi-pencil me-1"></i>Edit Student</a>
                <?php if ($latestInvoiceId > 0): ?>
                <a class="btn btn-primary btn-sm" href="#" data-collect-invoice-id="<?= $latestInvoiceId ?>"><i class="bi bi-wallet2 me-1"></i>Collect Fee</a>
                <?php else: ?>
                <a class="btn btn-primary btn-sm" href="<?= h($collectUrl) ?>"><i class="bi bi-wallet2 me-1"></i><?= h($collectLabel) ?></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Quick stats -->
<div class="row g-3 mb-3">
    <div class="col-6 col-lg-3">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="text-muted small">Total Invoiced</div>
                <div class="fs-5 fw-semibold">Rs <?= number_format($totalDue ?? 0, 0) ?></div>
            </div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="text-muted small">Total Collected</div>
                <div class="fs-5 fw-semibold text-success">Rs <?= number_format($totalCollected ?? 0, 0) ?></div>
            </div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="text-muted small">Pending Balance</div>
                <div class="fs-5 fw-semibold <?= (($pendingBalance ?? 0) > 0) ? 'text-danger' : '' ?>">Rs <?= number_format($pendingBalance ?? 0, 0) ?></div>
            </div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <div class="text-muted small">Fee Discount</div>
                <div class="fs-5 fw-semibold">
                    <?php if ($feeVal <= 0): ?>
                        <span class="text-muted">Full fee</span>
                    <?php elseif ($feeIsPct): ?>
                        <?= rtrim(rtrim(number_format($feeVal, 2, '.', ''), '0'), '.') ?>%
                    <?php else: ?>
                        Rs <?= number_format($feeVal, 0) ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Tabs -->
<ul class="nav nav-tabs mb-3" id="studentProfileTabs" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-overview" type="button">Overview</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-fees" type="button">Fees &amp; Invoices</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-guardians" type="button">Guardians (<?= count($guardians) ?>)</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-classhistory" type="button">Class History (<?= count($classHistory) ?>)</button>
    </li>
</ul>

<div class="tab-content">

    <!-- Overview: personal + academic -->
    <div class="tab-pane fade show active" id="tab-overview" role="tabpanel">
        <div class="row g-3">
            <div class="col-lg-6">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-white fw-semibold d-flex justify-content-between align-items-center">
                        Personal Details
                        <a class="small" href="<?= h($editUrl) ?>">Edit</a>
                    </div>
                    <div class="card-body">
                        <dl class="row mb-0">
                            <dt class="col-5 text-muted fw-normal">Father's Name</dt>
                            <dd class="col-7"><?= h($student['father_name'] ?? '—') ?: '—' ?></dd>

                            <dt class="col-5 text-muted fw-normal">Gender</dt>
                            <dd class="col-7"><?= h($student['gender'] ?? '—') ?></dd>

                            <dt class="col-5 text-muted fw-normal">Date of Birth</dt>
                            <dd class="col-7"><?= h($student['dob'] ?? '—') ?: '—' ?></dd>

                            <dt class="col-5 text-muted fw-normal">Phone</dt>
                            <dd class="col-7"><?= h($student['phone'] ?? '—') ?: '—' ?></dd>

                            <dt class="col-5 text-muted fw-normal">Address</dt>
                            <dd class="col-7"><?= h($student['address'] ?? '—') ?: '—' ?></dd>

                            <dt class="col-5 text-muted fw-normal">CNIC / B-Form No.</dt>
                            <dd class="col-7"><?= h($student['cnic_no'] ?? '—') ?: '—' ?></dd>
                        </dl>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="card shadow-sm border-0 h-100">
                    <div class="card-header bg-white fw-semibold d-flex justify-content-between align-items-center">
                        Academic Details
                        <a class="small" href="<?= h($editUrl) ?>">Edit</a>
                    </div>
                    <div class="card-body">
                        <dl class="row mb-0">
                            <dt class="col-5 text-muted fw-normal">Admission No.</dt>
                            <dd class="col-7"><?= h($student['admission_no'] ?? '—') ?></dd>

                            <dt class="col-5 text-muted fw-normal">Class / Section</dt>
                            <dd class="col-7">
                                <?php if (!empty($student['current_class_name'])): ?>
                                    <?= h($student['current_class_name'] . ' ' . $student['current_section_name']) ?>
                                <?php else: ?>
                                    <span class="text-muted">Unassigned</span>
                                <?php endif; ?>
                            </dd>

                            <dt class="col-5 text-muted fw-normal">Roll No.</dt>
                            <dd class="col-7"><?= (int)($student['roll_number'] ?? 0) ?: '—' ?></dd>

                            <dt class="col-5 text-muted fw-normal">Board Reg. No.</dt>
                            <dd class="col-7"><?= h($student['board_registration_no'] ?? '—') ?: '—' ?></dd>

                            <dt class="col-5 text-muted fw-normal">Status</dt>
                            <dd class="col-7"><?= $isActive ? 'Active' : 'Left school' ?></dd>

                            <dt class="col-5 text-muted fw-normal">Enrolled Since</dt>
                            <dd class="col-7"><?= h(substr((string)($student['created_at'] ?? ''), 0, 10)) ?: '—' ?></dd>
                        </dl>
                        <div class="mt-2">
                            <a class="btn btn-outline-secondary btn-sm" href="<?= h(base_url('/index.php?route=students/attendance&class_section_id=' . (int)($student['current_class_section_id'] ?? 0))) ?>">
                                <i class="bi bi-calendar2-check me-1"></i>Class Attendance Register
                            </a>
                            <a class="btn btn-outline-secondary btn-sm" href="<?= h(base_url('/index.php?route=students/promotions')) ?>">
                                <i class="bi bi-arrow-up-circle me-1"></i>Promotions
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Fees & Invoices -->
    <div class="tab-pane fade" id="tab-fees" role="tabpanel">
        <div class="card shadow-sm border-0">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped mb-0">
                        <thead>
                        <tr>
                            <th>Invoice #</th>
                            <th>Issued</th>
                            <th>Status</th>
                            <th class="text-end">Total Invoiced</th>
                            <th class="text-end">Collected</th>
                            <th class="text-end">Balance</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($invoices)): ?>
                            <tr><td colspan="7" class="text-muted text-center py-3">No invoices yet.</td></tr>
                        <?php else: foreach ($invoices as $inv): ?>
                            <?php $bal = (float)($inv['total_due'] ?? 0) - (float)($inv['collected_amount'] ?? 0); ?>
                            <tr>
                                <td><?= h($inv['invoice_no'] ?? '') ?></td>
                                <td><?= h(substr((string)($inv['issued_at'] ?? ''), 0, 10)) ?></td>
                                <td>
                                    <?php $st = (string)($inv['status'] ?? 'open'); ?>
                                    <span class="badge text-bg-<?= $st === 'paid' ? 'success' : ($st === 'cancelled' ? 'secondary' : 'warning') ?>"><?= h(ucfirst($st)) ?></span>
                                </td>
                                <td class="text-end">Rs <?= number_format((float)($inv['total_due'] ?? 0), 0) ?></td>
                                <td class="text-end">Rs <?= number_format((float)($inv['collected_amount'] ?? 0), 0) ?></td>
                                <td class="text-end <?= $bal > 0 ? 'text-danger' : '' ?>">Rs <?= number_format($bal, 0) ?></td>
                                <td class="text-end">
                                    <a class="btn btn-sm btn-outline-primary" href="<?= h(base_url('/index.php?route=fees/invoiceView&invoice_id=' . (int)$inv['id'])) ?>">View</a>
                                </td>
                            </tr>
                        <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Guardians -->
    <div class="tab-pane fade" id="tab-guardians" role="tabpanel">
        <div class="d-flex justify-content-end mb-2">
            <a class="btn btn-sm btn-primary" href="<?= h($guardiansAddUrl) ?>"><i class="bi bi-person-plus me-1"></i>Manage Guardians</a>
        </div>
        <div class="row g-3">
            <?php if (empty($guardians)): ?>
                <div class="col-12">
                    <div class="card shadow-sm border-0"><div class="card-body text-muted">No guardians linked yet.</div></div>
                </div>
            <?php else: foreach ($guardians as $g): ?>
                <div class="col-md-6">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <div class="fw-semibold"><?= h($g['full_name'] ?? '') ?></div>
                                    <div class="text-muted small"><?= h($g['relation'] ?? '') ?></div>
                                </div>
                                <?php if (!empty($g['is_primary'])): ?>
                                    <span class="badge text-bg-info">Primary</span>
                                <?php endif; ?>
                            </div>
                            <div class="mt-2 small">
                                <?php if (!empty($g['phone'])): ?><div><i class="bi bi-telephone me-1"></i><?= h($g['phone']) ?></div><?php endif; ?>
                                <?php if (!empty($g['email'])): ?><div><i class="bi bi-envelope me-1"></i><?= h($g['email']) ?></div><?php endif; ?>
                                <?php if (!empty($g['address'])): ?><div><i class="bi bi-geo-alt me-1"></i><?= h($g['address']) ?></div><?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; endif; ?>
        </div>
    </div>

    <!-- Class History -->
    <div class="tab-pane fade" id="tab-classhistory" role="tabpanel">
        <div class="card shadow-sm border-0">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-striped mb-0">
                        <thead>
                        <tr>
                            <th>Date</th>
                            <th>Class / Section</th>
                            <th>Roll No.</th>
                            <th>Moved By</th>
                            <th>Note</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($classHistory)): ?>
                            <tr><td colspan="5" class="text-muted text-center py-3">No class history yet.</td></tr>
                        <?php else: foreach ($classHistory as $i => $ch): ?>
                            <tr>
                                <td><?= h(substr((string)($ch['assigned_at'] ?? ''), 0, 16)) ?></td>
                                <td>
                                    <?= h(trim(($ch['class_name'] ?? '') . ' ' . ($ch['section_name'] ?? ''))) ?: '<span class="text-muted">Unknown</span>' ?>
                                    <?php if ($i === 0): ?><span class="badge text-bg-success ms-1">Current</span><?php endif; ?>
                                </td>
                                <td><?= (int)($ch['roll_number'] ?? 0) ?: '—' ?></td>
                                <td><?= h($ch['assigned_by_username'] ?? '—') ?: '—' ?></td>
                                <td class="text-muted small"><?= h($ch['note'] ?? '') ?: '—' ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>
