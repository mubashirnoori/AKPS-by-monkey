<?php
// Variables: $q,$status,$inquiries,$total,$page,$perPage,$classes,$sections
$totalPages = max(1, (int)ceil((int)$total / (int)$perPage));
$routeBase = base_url('/index.php');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Inquiries</h1>
        <div class="text-muted">Admission request tracking.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=students/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="students/inquiries">
            <div class="col-md-6">
                <label class="form-label">Search</label>
                <input class="form-control" name="q" value="<?= h($q) ?>" placeholder="Inquiry no, name, phone...">
            </div>
            <div class="col-md-3">
                <label class="form-label">Status</label>
                <select class="form-select" name="status">
                    <option value="">All</option>
                    <?php foreach (['new','reviewed','approved','rejected','converted'] as $st): ?>
                        <option value="<?= h($st) ?>" <?= $status === $st ? 'selected' : '' ?>><?= h($st) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 d-grid">
                <button class="btn btn-primary" type="submit">Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Create Inquiry</h2>
                <form method="post" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <div class="mb-3">
                        <label class="form-label">Inquiry No (optional)</label>
                        <input class="form-control" name="inquiry_no" placeholder="Auto-generated if empty">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">First Name</label>
                        <input class="form-control" name="requested_first_name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Last Name</label>
                        <input class="form-control" name="requested_last_name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Phone</label>
                        <input class="form-control" name="phone">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input class="form-control" name="email">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Requested Class</label>
                        <select class="form-select" name="requested_class_id">
                            <option value="0">Not set</option>
                            <?php foreach ($classes as $c): ?>
                                <option value="<?= (int)$c['id'] ?>"><?= h($c['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Requested Section</label>
                        <select class="form-select" name="requested_section_id">
                            <option value="0">Not set</option>
                            <?php foreach ($sections as $s): ?>
                                <option value="<?= (int)$s['id'] ?>"><?= h($s['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notes</label>
                        <textarea class="form-control" name="notes" rows="3"></textarea>
                    </div>
                    <button class="btn btn-primary w-100" type="submit">Create</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-3">Inquiry List</h2>
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0">
                        <thead>
                            <tr>
                                <th>Inquiry No</th>
                                <th>Student</th>
                                <th>Contact</th>
                                <th>Requested</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($inquiries as $i): ?>
                            <tr>
                                <td><?= h($i['inquiry_no'] ?? '') ?></td>
                                <td><?= h(($i['requested_first_name'] ?? '') . ' ' . ($i['requested_last_name'] ?? '')) ?></td>
                                <td><?= h($i['phone'] ?? '') ?></td>
                                <td class="text-muted">
                                    <?php
                                    $cls = !empty($i['class_name']) ? $i['class_name'] : '';
                                    $sec = !empty($i['section_name']) ? $i['section_name'] : '';
                                    ?>
                                    <?= h(trim($cls . ' ' . $sec)) ?>
                                </td>
                                <td>
                                    <span class="badge text-bg-secondary"><?= h($i['status'] ?? '') ?></span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($inquiries)): ?>
                            <tr><td colspan="5" class="text-muted">No inquiries found.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($totalPages > 1): ?>
                    <nav class="mt-3">
                        <ul class="pagination justify-content-center mb-0">
                            <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                                <?php
                                    $query = array_merge(['q' => $q, 'status' => $status], ['page' => $p]);
                                    $url = $routeBase . '&' . http_build_query($query);
                                ?>
                                <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                                    <a class="page-link" href="<?= htmlspecialchars($url, ENT_QUOTES, 'UTF-8') ?>"><?= (int)$p ?></a>
                                </li>
                            <?php endfor; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

