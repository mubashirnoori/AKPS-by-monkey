<?php
// Variables: $students, $q, $classSectionId, $studentStatus, $total, $page, $perPage, $classSections, $listFilters
$studentStatus = (string)($studentStatus ?? 'active');
$perPage = (int)($perPage ?? 10); // fallback safety
$totalPages = max(1, (int)ceil((int)$total / (int)$perPage));
$listFilters = $listFilters ?? [
    'q' => $q ?? '',
    'class_section_id' => (int)($classSectionId ?? 0),
    'student_status' => $studentStatus,
    'per_page' => $perPage,
    'page' => (int)($page ?? 1),
];
$retQs = list_return_query($listFilters);
$listBackUrl = list_url('students/index', $listFilters);

$routeBase = base_url('/index.php');
?>

<div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
    <div>
        <h1 class="h4 mb-0">Students</h1>
        <div class="text-muted">Search, filter, manage and import student data.</div>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <a class="btn btn-outline-primary" href="<?= htmlspecialchars(base_url('/index.php?route=students/create' . $retQs), ENT_QUOTES, 'UTF-8') ?>">Add Student</a>
        <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=students/import'), ENT_QUOTES, 'UTF-8') ?>">Import CSV</a>
        <a class="btn btn-outline-secondary" href="<?= h(list_url('students/exportCsv', [
            'q' => $q ?? '',
            'class_section_id' => (int)($classSectionId ?? 0),
            'student_status' => $studentStatus,
            'dl_token' => download_token(),
        ])) ?>"><i class="bi bi-download me-1"></i>Export CSV</a>
        <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=students/uploadPhoto'), ENT_QUOTES, 'UTF-8') ?>"><i class="bi bi-camera me-1"></i>Upload Photo</a>
        <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=students/promotions'), ENT_QUOTES, 'UTF-8') ?>">Promotions</a>
        <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=students/attendance'), ENT_QUOTES, 'UTF-8') ?>">Attendance</a>
        <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=students/leaves'), ENT_QUOTES, 'UTF-8') ?>">Leave Requests</a>
    </div>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="students/index">

            <div class="col-md-3">
                <label class="form-label">Search</label>
                <input class="form-control" name="q" value="<?= h($q) ?>" placeholder="Admission no, name, ID…" />
            </div>

            <div class="col-md-3">
                <label class="form-label">Class / Section</label>
                <select class="form-select" name="class_section_id">
                    <option value="0">All</option>
                    <?php foreach ($classSections as $cs): ?>
                        <option value="<?= (int)$cs['id'] ?>" <?= ((int)$classSectionId === (int)$cs['id']) ? 'selected' : '' ?>>
                            <?= h($cs['class_name'] . ' ' . $cs['section_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-2">
                <label class="form-label">Status</label>
                <select class="form-select" name="student_status">
                    <option value="active" <?= $studentStatus === 'active' ? 'selected' : '' ?>>Active</option>
                    <option value="left" <?= $studentStatus === 'left' ? 'selected' : '' ?>>Left school</option>
                    <option value="all" <?= $studentStatus === 'all' ? 'selected' : '' ?>>All</option>
                </select>
            </div>

            <div class="col-md-2">
                <label class="form-label">Show</label>
                <select class="form-select" name="per_page" onchange="this.form.submit()">
                    <?php foreach ([10,20,50,100,200,999] as $opt): ?>
                        <option value="<?= $opt ?>" <?= ($perPage == $opt) ? 'selected' : '' ?>>
                            <?= $opt == 999 ? 'All' : $opt ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-2 d-grid">
                <button class="btn btn-primary" type="submit">Search</button>
            </div>
        </form>

        <div class="mt-3 d-flex gap-2 flex-wrap">
            <a class="btn btn-outline-primary btn-sm" href="<?= htmlspecialchars(base_url('/index.php?route=students/inquiries'), ENT_QUOTES, 'UTF-8') ?>">Inquiries</a>
            <a class="btn btn-outline-primary btn-sm" href="<?= htmlspecialchars(base_url('/index.php?route=students/complaints'), ENT_QUOTES, 'UTF-8') ?>">Complaints</a>
            <a class="btn btn-outline-primary btn-sm" href="<?= htmlspecialchars(base_url('/index.php?route=students/assessmentSettings'), ENT_QUOTES, 'UTF-8') ?>">Assessment Settings</a>
            <a class="btn btn-outline-primary btn-sm" href="<?= htmlspecialchars(base_url('/index.php?route=students/studentFormFields'), ENT_QUOTES, 'UTF-8') ?>">Student Forms</a>
        </div>
    </div>
</div>

<div id="studentListContainer">
<?= $this->renderPartial('students/_student_list', [
    'students' => $students,
    'total' => $total,
    'page' => $page,
    'perPage' => $perPage,
    'q' => $q,
    'classSectionId' => $classSectionId,
    'studentStatus' => $studentStatus,
    'classSections' => $classSections,
    'listFilters' => $listFilters,
]) ?>
</div>
