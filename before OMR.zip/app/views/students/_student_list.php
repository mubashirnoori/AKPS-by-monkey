<?php
// Variables: $students, $total, $page, $perPage, $q, $classSectionId, $studentStatus, $classSections, $listFilters
$students = $students ?? [];
$total = (int)($total ?? 0);
$page = max(1, (int)($page ?? 1));
$perPage = (int)($perPage ?? 10);
$q = $q ?? '';
$classSectionId = (int)($classSectionId ?? 0);
$studentStatus = $studentStatus ?? 'active';
$classSections = $classSections ?? [];
$listFilters = $listFilters ?? [
    'q' => $q,
    'class_section_id' => $classSectionId,
    'student_status' => $studentStatus,
    'per_page' => $perPage,
    'page' => $page,
];
$totalPages = max(1, (int)ceil($total / max(1, $perPage)));
$retQs = list_return_query($listFilters);
$routeBase = base_url('/index.php');
$bulkDeleteUrl = base_url('/index.php?route=students/bulkDelete');
$bulkAssignUrl = base_url('/index.php?route=students/bulkAssignClass');
?>
<?php if (!empty($students)): ?>
<form method="post" action="<?= htmlspecialchars($bulkAssignUrl, ENT_QUOTES, 'UTF-8') ?>" id="bulkStudentsForm"
      data-ajax data-target="#studentListContainer" data-bulk-select="students">
<input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
<?php list_return_fields($listFilters); ?>

<div class="card shadow-sm border-0 mb-3">
<div class="card-body">

<div class="d-flex align-items-center gap-2 mb-2">
    <span class="badge text-bg-primary" data-select-count></span>
    <button class="btn btn-link btn-sm p-0" type="button" data-select-clear style="display:none;">Clear selection</button>
</div>

<div class="row g-3 align-items-end">

<div class="col-md-5">
    <label class="form-label mb-1">Assign target class</label>
    <select class="form-select" name="class_section_id">
        <option value="">Choose...</option>
        <?php foreach ($classSections as $cs): ?>
            <option value="<?= (int)$cs['id'] ?>"><?= h($cs['class_name'] . ' ' . $cs['section_name']) ?></option>
        <?php endforeach; ?>
    </select>
</div>

<div class="col-md-4">
    <label class="form-label mb-1">Assignment note (optional)</label>
    <input class="form-control" name="assignment_note" placeholder="e.g. Promotion to next grade" />
</div>

<div class="col-md-3 d-grid">
    <button class="btn btn-primary btn-sm" type="submit"
        formaction="<?= htmlspecialchars($bulkAssignUrl, ENT_QUOTES, 'UTF-8') ?>">
        Assign selected
    </button>

    <div class="mt-2 d-grid">
        <button class="btn btn-danger btn-sm" type="submit"
            formaction="<?= htmlspecialchars($bulkDeleteUrl, ENT_QUOTES, 'UTF-8') ?>"
            data-confirm="Deactivate selected students? (All their records are preserved - this can be undone from Edit Student.)">
            Delete selected
        </button>
    </div>
</div>

</div>
</div>
</div>

<div class="card shadow-sm border-0">
<div class="card-body p-0">
<div class="table-responsive">
<table class="table table-striped mb-0">

<thead>
<tr>
    <th style="width:50px;"><input type="checkbox" data-select-all></th>
    <th style="width:52px;">Photo</th>
    <th>#ID</th>
    <th>Admission</th>
    <th>Roll No</th>
    <th>Student</th>
    <th>Father</th>
    <th>Class / Section</th>
    <th>Fee</th>
    <th>Phone</th>
    <th>Status</th>
    <th style="width:200px;">Actions</th>
</tr>
</thead>

<tbody>
<?php foreach ($students as $s): ?>
<?php
$_pFiles  = glob(dirname(__DIR__, 3) . '/public/uploads/students/' . (int)$s['id'] . '.*') ?: [];
$_pFile   = !empty($_pFiles) ? $_pFiles[0] : null;
$hasPhoto = $_pFile !== null;
$photoSrc = $hasPhoto ? base_url('/uploads/students/' . basename($_pFile)) . '?v=' . filemtime($_pFile) : '';
$initials  = strtoupper(substr((string)($s['first_name'] ?? 'S'), 0, 1) . substr((string)($s['last_name'] ?? ''), 0, 1));
?>
<tr>
<td>
<input class="form-check-input" type="checkbox" data-select-item name="student_ids[]" value="<?= (int)$s['id'] ?>">
</td>
<td>
<?php if ($hasPhoto): ?>
    <img src="<?= h($photoSrc) ?>" alt=""
         style="width:38px;height:38px;border-radius:50%;object-fit:cover;border:2px solid var(--sms-border, #37455c);">
<?php else: ?>
    <div style="width:38px;height:38px;border-radius:50%;background:var(--sms-surface-2, #222c3c);display:flex;
                align-items:center;justify-content:center;font-size:.7rem;font-weight:700;
                color:var(--sms-primary, #b8873e);border:2px solid var(--sms-border, #37455c);" title="No photo">
        <?= h($initials) ?>
    </div>
<?php endif; ?>
</td>
<td class="text-muted small"><?= (int)$s['id'] ?></td>
<td><?= h($s['admission_no'] ?? '') ?></td>
<td><?= (int)($s['roll_number'] ?? 0) ?: '—' ?></td>
<td><?= h(($s['first_name'] ?? '') . ' ' . ($s['last_name'] ?? '')) ?></td>
<td>
<?php if (!empty($s['father_name'])): ?>
<?= h($s['father_name']) ?>
<?php else: ?>
<span class="text-muted">—</span>
<?php endif; ?>
</td>

<td>
<?php if (!empty($s['current_class_name'])): ?>
<?= h($s['current_class_name'] . ' ' . $s['current_section_name']) ?>
<?php else: ?>
<span class="text-muted">Unassigned</span>
<?php endif; ?>
</td>

<td>
<?php
$feeVal = (float)($s['fee_discount_percent'] ?? 0);
$feeIsPct = (int)($s['fee_discount_is_percent'] ?? 1) === 1;
if ($feeVal <= 0): ?>
    <span class="text-muted small">Full</span>
<?php elseif ($feeIsPct && $feeVal >= 100): ?>
    <span class="badge text-bg-success">Free</span>
<?php elseif ($feeIsPct): ?>
    <span class="badge text-bg-info"><?= rtrim(rtrim(number_format($feeVal, 2, '.', ''), '0'), '.') ?>% off</span>
<?php else: ?>
    <span class="badge text-bg-warning">Rs <?= number_format($feeVal, 0) ?> off</span>
<?php endif; ?>
</td>

<td><?= h($s['phone'] ?? '') ?></td>

<td>
<?php if ((int)($s['status'] ?? 1) === 1): ?>
    <span class="badge text-bg-success">Active</span>
<?php else: ?>
    <span class="badge text-bg-secondary">Left school</span>
<?php endif; ?>
</td>

<td>
<a class="btn btn-sm btn-outline-secondary" title="View full profile"
href="<?= htmlspecialchars(base_url('/index.php?route=students/profile&id=' . (int)$s['id'] . $retQs), ENT_QUOTES, 'UTF-8') ?>"><i class="bi bi-eye"></i></a>

<a class="btn btn-sm btn-outline-primary"
href="<?= htmlspecialchars(base_url('/index.php?route=students/edit&id=' . (int)$s['id'] . $retQs), ENT_QUOTES, 'UTF-8') ?>">Edit</a>
</td>

</tr>
<?php endforeach; ?>
</tbody>

</table>
</div>
</div>
</div>

</form>
<?php else: ?>
<div class="card shadow-sm border-0">
<div class="card-body text-muted">No students found.</div>
</div>
<?php endif; ?>

<?php
// Pagination — carries q / class_section_id / student_status / per_page on every page link.
if ($totalPages > 1):
$queryCommon = [
    'q' => $q,
    'class_section_id' => $classSectionId ?: 0,
    'student_status' => $studentStatus,
    'per_page' => $perPage,
];
?>

<nav class="mt-3">
<ul class="pagination justify-content-center">

<?php for ($p = 1; $p <= $totalPages; $p++): ?>
<?php
$query = array_merge(['route' => 'students/index'], $queryCommon, ['page' => $p]);
$url = $routeBase . '?' . http_build_query($query);
?>

<li class="page-item <?= $p === $page ? 'active' : '' ?>">
<a class="page-link" href="<?= htmlspecialchars($url, ENT_QUOTES, 'UTF-8') ?>">
<?= (int)$p ?>
</a>
</li>

<?php endfor; ?>

</ul>
</nav>

<?php endif; ?>