<?php
// Variables: $student (array|null)
$student = $student ?? null;

// Build photo URL if student has a photo on disk
$photoUrl = null;
if ($student) {
    $_pFiles = glob(dirname(__DIR__, 3) . '/public/uploads/students/' . (int)$student['id'] . '.*') ?: [];
    $_pFile  = !empty($_pFiles) ? $_pFiles[0] : null;
    $photoUrl = $_pFile ? base_url('/uploads/students/' . basename($_pFile)) . '?v=' . filemtime($_pFile) : null;
}
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Upload Student Photo</h1>
        <div class="text-muted">Upload or replace a student's profile photo used in the ID card.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=students/index'), ENT_QUOTES, 'UTF-8') ?>">Back to Students</a>
</div>

<?php if (!empty($_SESSION['flash'])): ?>
    <?php $flash = $_SESSION['flash']; unset($_SESSION['flash']); ?>
    <div class="alert alert-<?= h($flash['type']) ?> alert-dismissible fade show" role="alert">
        <?= h($flash['message']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- ── Step 1: Search for a student ─────────────────────────────────── -->
<div class="card shadow-sm border-0 mb-4">
    <div class="card-header fw-semibold" style="background: var(--sms-surface-2, #1f2937); color: var(--sms-text, #e5e7eb);">Step 1 — Search &amp; Select Student</div>
    <div class="card-body">
        <div class="mb-2">
            <label class="form-label">Search by name or admission number</label>
            <input type="text" id="photoSearchInput" class="form-control" placeholder="Start typing…" autocomplete="off"
                   value="<?= $student ? h(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? '')) : '' ?>">
        </div>
        <div id="photoSearchResults" class="list-group mb-2" style="display:none;max-height:260px;overflow-y:auto;"></div>

        <?php if ($student): ?>
        <div class="alert alert-info py-2 mb-0" id="selectedStudentInfo">
            <strong>Selected:</strong>
            <?= h(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? '')) ?>
            &nbsp;|&nbsp; Adm. No: <strong><?= h($student['admission_no'] ?? '') ?></strong>
            &nbsp;|&nbsp; Class: <strong><?= h(($student['current_class_name'] ?? '') . ' ' . ($student['current_section_name'] ?? '')) ?></strong>
            &nbsp;|&nbsp; ID: <strong>#<?= (int)$student['id'] ?></strong>
        </div>
        <?php else: ?>
        <div class="text-muted small" id="selectedStudentInfo">No student selected yet.</div>
        <?php endif; ?>
    </div>
</div>

<!-- ── Step 2: Upload photo (only shown when student is selected) ──── -->
<?php if ($student): ?>
<div class="card shadow-sm border-0 mb-4">
    <div class="card-header fw-semibold" style="background: var(--sms-surface-2, #1f2937); color: var(--sms-text, #e5e7eb);">Step 2 — Upload Photo</div>
    <div class="card-body">
        <div class="row g-4 align-items-start">

            <!-- Current photo preview -->
            <div class="col-md-3 text-center">
                <p class="text-muted small mb-2">Current Photo</p>
                <div style="width:120px;height:120px;border-radius:50%;overflow:hidden;background:#e8edf8;margin:0 auto;
                            display:flex;align-items:center;justify-content:center;font-size:2rem;font-weight:700;color:#1a3a7a;border:3px solid #d1d9f0;">
                    <?php if ($photoUrl): ?>
                        <img src="<?= h($photoUrl) ?>" style="width:100%;height:100%;object-fit:cover;" alt="Current photo">
                    <?php else: ?>
                        <?= strtoupper(substr((string)($student['first_name'] ?? 'S'), 0, 1) . substr((string)($student['last_name'] ?? 'M'), 0, 1)) ?>
                    <?php endif; ?>
                </div>
                <?php if ($photoUrl): ?>
                    <p class="text-success small mt-2 mb-0"><i class="bi bi-check-circle"></i> Photo on file</p>
                <?php else: ?>
                    <p class="text-muted small mt-2 mb-0">No photo yet</p>
                <?php endif; ?>
            </div>

            <!-- Upload form -->
            <div class="col-md-9">
                <form method="post" enctype="multipart/form-data"
                      action="<?= htmlspecialchars(base_url('/index.php?route=students/uploadPhotoStore'), ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="student_id" value="<?= (int)$student['id'] ?>">

                    <label class="form-label fw-semibold">Select image file</label>
                    <input type="file" name="photo" id="photoFileInput" class="form-control mb-1" accept="image/jpeg,image/png,image/webp,image/gif" required>
                    <p class="text-muted small mb-3">Accepted: JPEG, PNG, WebP, GIF. Recommended: square crop, minimum 200×200 px. Max ~5 MB.</p>

                    <!-- Live preview -->
                    <div id="previewWrap" style="display:none;margin-bottom:1rem;">
                        <p class="text-muted small mb-1">Preview:</p>
                        <img id="previewImg" src="" alt="Preview"
                             style="width:120px;height:120px;border-radius:50%;object-fit:cover;border:3px solid var(--sms-primary, #b8873e);">
                    </div>

                    <button class="btn btn-primary" type="submit">
                        <i class="bi bi-upload me-1"></i>
                        <?= $photoUrl ? 'Replace Photo' : 'Upload Photo' ?>
                    </button>
                </form>
            </div>

        </div>
    </div>
</div>
<?php else: ?>
<div class="card shadow-sm border-0 mb-4">
    <div class="card-body text-muted">Search and select a student above to upload their photo.</div>
</div>
<?php endif; ?>

<script>
(function () {
    const input   = document.getElementById('photoSearchInput');
    const results = document.getElementById('photoSearchResults');
    let timer;

    input.addEventListener('input', function () {
        clearTimeout(timer);
        const q = this.value.trim();
        if (q.length < 2) { results.style.display = 'none'; return; }
        timer = setTimeout(() => {
            fetch(<?= json_encode(base_url('/index.php?route=students/searchJson&q=')) ?> + encodeURIComponent(q))
                .then(r => r.json())
                .then(data => {
                    results.innerHTML = '';
                    if (!data.results || data.results.length === 0) {
                        results.innerHTML = '<div class="list-group-item text-muted">No students found</div>';
                        results.style.display = 'block';
                        return;
                    }
                    data.results.forEach(st => {
                        const a = document.createElement('a');
                        a.href = <?= json_encode(base_url('/index.php?route=students/uploadPhoto&student_id=')) ?> + st.id;
                        a.className = 'list-group-item list-group-item-action';
                        a.innerHTML = `<strong>${st.name}</strong> <span class="text-muted small">| Adm: ${st.admission_no} | ${st.class}</span>`;
                        results.appendChild(a);
                    });
                    results.style.display = 'block';
                });
        }, 280);
    });

    document.addEventListener('click', function (e) {
        if (!results.contains(e.target) && e.target !== input) {
            results.style.display = 'none';
        }
    });

    // Live preview
    const fileInput  = document.getElementById('photoFileInput');
    const previewWrap = document.getElementById('previewWrap');
    const previewImg  = document.getElementById('previewImg');

    if (fileInput) {
        fileInput.addEventListener('change', function () {
            const file = this.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = e => {
                previewImg.src = e.target.result;
                previewWrap.style.display = 'block';
            };
            reader.readAsDataURL(file);
        });
    }
})();
</script>
