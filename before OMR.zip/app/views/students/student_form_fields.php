<?php
// Variables: $fields
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Student Forms (Custom Fields)</h1>
        <div class="text-muted">Manage extra fields for student profiles.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=students/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Create New Field</h2>
                <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=students/studentFormFields'), ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="action" value="create">

                    <div class="mb-3">
                        <label class="form-label">Field Key (unique)</label>
                        <input class="form-control" name="field_key" required placeholder="e.g. emergency_contact">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Label</label>
                        <input class="form-control" name="label_text" required placeholder="Emergency Contact">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Field Type</label>
                        <select class="form-select" name="field_type">
                            <?php foreach (['text','number','date','select','textarea'] as $t): ?>
                                <option value="<?= h($t) ?>"><?= h($t) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Options (for select)</label>
                        <textarea class="form-control" name="options_text" rows="3" placeholder="Comma-separated options"></textarea>
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="is_required" value="1" id="is_required">
                            <label class="form-check-label" for="is_required">Required</label>
                        </div>
                    </div>

                    <button class="btn btn-primary w-100" type="submit">Create Field</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Existing Fields</h2>
                <div class="table-responsive">
                    <table class="table table-striped table-sm align-middle">
                        <thead>
                        <tr>
                            <th>Key</th>
                            <th>Label</th>
                            <th>Type</th>
                            <th>Required</th>
                            <th style="width: 220px;">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($fields as $f): ?>
                            <tr>
                                <td class="fw-semibold"><?= h($f['field_key'] ?? '') ?></td>
                                <td>
                                    <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=students/studentFormFieldsUpdate'), ENT_QUOTES, 'UTF-8') ?>">
                                        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                        <input type="hidden" name="id" value="<?= (int)$f['id'] ?>">
                                        <input type="hidden" name="options_text" value="<?= h($f['options_text'] ?? '') ?>">
                                        <input class="form-control form-control-sm" name="label_text" value="<?= h($f['label_text'] ?? '') ?>">
                                </td>
                                <td>
                                        <select class="form-select form-select-sm" name="field_type">
                                            <?php foreach (['text','number','date','select','textarea'] as $t): ?>
                                                <option value="<?= h($t) ?>" <?= ($f['field_type'] ?? '') === $t ? 'selected' : '' ?>><?= h($t) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                </td>
                                <td>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="is_required" value="1" <?= !empty($f['is_required']) ? 'checked' : '' ?>>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex gap-2">
                                        <button class="btn btn-sm btn-primary" type="submit">Save</button>
                                    </form>
                                        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=students/studentFormFieldsDelete'), ENT_QUOTES, 'UTF-8') ?>" onsubmit="return confirm('Delete this field?')">
                                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                            <input type="hidden" name="id" value="<?= (int)$f['id'] ?>">
                                            <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($fields)): ?>
                            <tr><td colspan="5" class="text-muted">No custom fields yet.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="text-muted small mt-2">
                    After creating fields, edit each student to set their values via <a href="<?= htmlspecialchars(base_url('/index.php?route=students/studentFormValues&student_id=' . ($fields[0]['id'] ?? 0)), ENT_QUOTES, 'UTF-8') ?>">Student Form Values</a>.
                </div>
            </div>
        </div>
    </div>
</div>

