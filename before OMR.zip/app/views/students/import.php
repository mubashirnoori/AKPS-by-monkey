<?php
// Variables: $error, $classSections
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Import Students</h1>
        <div class="text-muted">Upload a CSV file with student data and class assignments.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=students/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-header">
        <h5 class="mb-0">📋 CSV Format Guide</h5>
    </div>
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-6">
                <h6>Required Columns (must have):</h6>
                <ul class="small">
                    <li><code>admission_no</code> (or <code>admission_number</code>, <code>admission</code>)</li>
                    <li><code>full_name</code> (or <code>student_name</code>, <code>name</code>)</li>
                    <li><code>roll_number</code> (or <code>roll_no</code>, <code>roll</code>) - can be blank</li>
                </ul>
            </div>
            <div class="col-md-6">
                <h6>Optional Columns (class assignment):</h6>
                <ul class="small">
                    <li><code>class_section_id</code> - Use exact ID from database</li>
                    <li><code>class</code> + <code>section</code> - Use class and section names</li>
                    <li><code>gender</code>, <code>dob</code>, <code>phone</code>, <code>address</code></li>
                </ul>
            </div>
        </div>

        <div class="mt-3 p-3 rounded" style="background: var(--sms-surface-2, #1f2937); color: var(--sms-text, #e5e7eb);">
            <h6>Example CSV:</h6>
            <code style="font-size: 11px; display: block; overflow-x: auto;">
admission_no,full_name,roll_number,class,section,gender,dob,phone<br>
STU001,Ahmed Ali,1,Class 10,A,M,2010-05-15,03001234567<br>
STU002,Fatima Khan,2,Class 10,A,F,2010-06-20,03109876543<br>
STU003,Hassan Ahmad,3,Class 10,B,M,2010-07-10,03201111111
            </code>
        </div>

        <div class="alert alert-info mt-3 mb-0">
            <i class="bi bi-info-circle me-2"></i>
            <strong>Tips:</strong>
            <ul class="small mb-0 mt-2">
                <li>Class assignment can be done via <code>class + section</code> columns OR <code>class_section_id</code> column</li>
                <li>If no class info in CSV, use the "Default Class / Section" dropdown below</li>
                <li>Roll number is optional but recommended (must be unique within each class)</li>
                <li>Column names are case-insensitive (admission_no, ADMISSION_NO, Admission_No all work)</li>
                <li>Rows with missing admission_no or full_name are skipped</li>
                <li>Duplicate admission_no will UPDATE existing student, others will CREATE new</li>
            </ul>
        </div>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=students/import'), ENT_QUOTES, 'UTF-8') ?>" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">

            <div class="row g-3 align-items-end">
                <div class="col-md-7">
                    <label class="form-label"><strong>Select CSV File *</strong></label>
                    <input class="form-control" type="file" name="csv_file" accept=".csv,text/csv" required>
                    <div class="form-text">
                        Maximum 10 MB. Format: CSV (comma-separated values)
                    </div>
                </div>
                <div class="col-md-5">
                    <label class="form-label">Default Class / Section <small class="text-muted">(optional)</small></label>
                    <select class="form-select" name="default_class_section_id">
                        <option value="0">Leave blank (use CSV class/section columns)</option>
                        <?php foreach ($classSections as $cs): ?>
                            <option value="<?= (int)$cs['id'] ?>"><?= h($cs['class_name'] . ' - ' . $cs['section_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text">
                        Used only if CSV doesn't have class/section info
                    </div>
                </div>
            </div>

            <div class="mt-3">
                <button class="btn btn-primary" type="submit">
                    <i class="bi bi-upload me-2"></i> Import / Update Students
                </button>
                <small class="text-muted d-block mt-2">
                    ⏱️ Time depends on file size (typically 1-2 seconds for 100 students)
                </small>
            </div>
        </form>
    </div>
</div>
