<?php
// Variables: $grades
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Assessment Settings</h1>
        <div class="text-muted">Edit grade boundaries (A+, A, B, ...).</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=students/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=students/assessmentSettings'), ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">

            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th>Grade</th>
                            <th>Min Score</th>
                            <th>Max Score</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($grades as $g): ?>
                        <tr>
                            <td class="fw-semibold"><?= h($g['grade_letter'] ?? '') ?></td>
                            <td>
                                <input class="form-control form-control-sm" type="number" step="0.01" name="min_score[<?= (int)$g['id'] ?>]" value="<?= h($g['min_score'] ?? 0) ?>" required>
                            </td>
                            <td>
                                <input class="form-control form-control-sm" type="number" step="0.01" name="max_score[<?= (int)$g['id'] ?>]" value="<?= h($g['max_score'] ?? 0) ?>" required>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <button class="btn btn-primary" type="submit">Save Settings</button>
        </form>
    </div>
</div>

