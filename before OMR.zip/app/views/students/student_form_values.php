<?php
// Variables: $student, $fieldsValues
$student = $student ?? [];
$studentId = (int)($student['id'] ?? 0);
$studentName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));

function parseOptionsText(string $optionsText): array {
    $parts = array_map('trim', explode(',', $optionsText));
    return array_values(array_filter($parts, fn($p) => $p !== ''));
}
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Student Form Values</h1>
        <div class="text-muted"><?= h($studentName) ?></div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=students/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=students/studentFormValues&student_id=' . $studentId), ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">

            <?php
            $fieldsByKey = [];
            foreach ($fieldsValues as $fv) {
                $fieldsByKey[(string)($fv['field_key'] ?? '')] = $fv;
            }
            ?>

            <?php if (empty($fieldsByKey)): ?>
                <div class="text-muted">No custom fields defined yet.</div>
            <?php else: ?>
                <div class="row g-3">
                    <?php foreach ($fieldsByKey as $key => $f): ?>
                        <?php $ft = (string)($f['field_type'] ?? 'text'); $value = (string)($f['value_text'] ?? ''); ?>
                        <div class="col-md-6">
                            <label class="form-label">
                                <?= h($f['label_text'] ?? $key) ?>
                                <?php if (!empty($f['is_required'])): ?>
                                    <span class="text-danger">*</span>
                                <?php endif; ?>
                            </label>
                            <?php if ($ft === 'textarea'): ?>
                                <textarea class="form-control" rows="3" name="field_<?= h($key) ?>" <?= !empty($f['is_required']) ? 'required' : '' ?>><?= h($value) ?></textarea>
                            <?php elseif ($ft === 'select'): ?>
                                <?php $opts = parseOptionsText((string)($f['options_text'] ?? '')); ?>
                                <select class="form-select" name="field_<?= h($key) ?>" <?= !empty($f['is_required']) ? 'required' : '' ?>>
                                    <option value="">Choose...</option>
                                    <?php foreach ($opts as $opt): ?>
                                        <option value="<?= h($opt) ?>" <?= $value === $opt ? 'selected' : '' ?>><?= h($opt) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            <?php else: ?>
                                <input class="form-control" type="<?= h($ft === 'number' ? 'number' : ($ft === 'date' ? 'date' : 'text')) ?>" name="field_<?= h($key) ?>" value="<?= h($value) ?>" <?= !empty($f['is_required']) ? 'required' : '' ?>>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="mt-3">
                    <button class="btn btn-primary" type="submit">Save Values</button>
                </div>
            <?php endif; ?>
        </form>
    </div>
</div>

