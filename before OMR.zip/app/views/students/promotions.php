<?php
// Variables: $classSections, $students
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Student Promotions</h1>
        <div class="text-muted">Promote selected students to a new class/section.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=students/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=students/promotions'), ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">

            <div class="row g-3 align-items-end">
                <div class="col-md-6">
                    <label class="form-label">Target Class / Section</label>
                    <select class="form-select" name="to_class_section_id" required>
                        <option value="">Choose...</option>
                        <?php foreach ($classSections as $cs): ?>
                            <option value="<?= (int)$cs['id'] ?>"><?= h($cs['class_name'] . ' ' . $cs['section_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Note (optional)</label>
                    <input class="form-control" name="note" placeholder="e.g. Promotion for academic year 2025-2026">
                </div>
            </div>

            <hr>

            <div class="mb-2 d-flex gap-2 flex-wrap align-items-end">
                <div>
                    <label class="form-label mb-1">Filter by current class</label>
                    <select class="form-select form-select-sm" style="max-width:220px;" id="promo_class_filter">
                        <option value="0">All classes</option>
                        <?php foreach ($classSections as $cs): ?>
                            <option value="<?= (int)$cs['id'] ?>"><?= h($cs['class_name'] . ' ' . $cs['section_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="form-label mb-1">Search</label>
                    <input type="text" class="form-control form-control-sm" style="max-width:240px;"
                           id="promo_search" placeholder="Name or admission no..."
                           onkeydown="if(event.key==='Enter'){event.preventDefault();filterPromoStudents();}">
                </div>
                <button type="button" class="btn btn-sm btn-primary" onclick="filterPromoStudents()">Apply Filter</button>
                <button type="button" class="btn btn-sm btn-outline-secondary" onclick="toggleVisiblePromoStudents(true)">Select visible</button>
                <button type="button" class="btn btn-sm btn-outline-secondary" onclick="toggleVisiblePromoStudents(false)">Clear visible</button>
                <span class="small text-muted align-self-center" id="promo_selected_count">0 selected</span>
            </div>

            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th style="width: 50px;">Select</th>
                            <th>Admission</th>
                            <th>Student</th>
                            <th>Current Class / Section</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $st): ?>
                            <?php
                            $stLabel = trim(($st['first_name'] ?? '') . ' ' . ($st['last_name'] ?? ''));
                            $stCsId = (int)($st['current_class_section_id'] ?? 0);
                            ?>
                            <tr class="promo-student-row"
                                data-class="<?= $stCsId ?>"
                                data-search="<?= h(strtolower($stLabel . ' ' . ($st['admission_no'] ?? ''))) ?>">
                                <td>
                                    <input class="form-check-input promo-student-cb" type="checkbox" name="student_ids[]" value="<?= (int)$st['id'] ?>" onchange="updatePromoSelectedCount()">
                                </td>
                                <td><?= h($st['admission_no'] ?? '') ?></td>
                                <td><?= h($stLabel) ?></td>
                                <td>
                                    <?php if (!empty($st['current_class_name'])): ?>
                                        <?= h($st['current_class_name'] . ' ' . $st['current_section_name']) ?>
                                    <?php else: ?>
                                        <span class="text-muted">Unassigned</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                <button class="btn btn-primary" type="submit" onclick="return confirm('Promote selected students?')">Promote Selected</button>
            </div>
        </form>
    </div>
</div>

<script>
function filterPromoStudents() {
    var cs = document.getElementById('promo_class_filter').value;
    var qEl = document.getElementById('promo_search');
    var q = qEl ? qEl.value.trim().toLowerCase() : '';
    document.querySelectorAll('.promo-student-row').forEach(function (row) {
        var rowCs = row.getAttribute('data-class') || '0';
        var rowText = row.getAttribute('data-search') || '';
        var classMatch = (cs === '0' || rowCs === cs);
        var searchMatch = (q === '' || rowText.indexOf(q) !== -1);
        row.style.display = (classMatch && searchMatch) ? '' : 'none';
    });
}
function toggleVisiblePromoStudents(check) {
    document.querySelectorAll('.promo-student-row').forEach(function (row) {
        if (row.style.display === 'none') return;
        var cb = row.querySelector('.promo-student-cb');
        if (cb) cb.checked = !!check;
    });
    updatePromoSelectedCount();
}
function updatePromoSelectedCount() {
    var n = document.querySelectorAll('.promo-student-cb:checked').length;
    var el = document.getElementById('promo_selected_count');
    if (el) el.textContent = n + ' selected';
}
</script>