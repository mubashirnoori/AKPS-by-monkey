<?php
// Variables: $q,$status,$complaints,$total,$page,$perPage,$students
$totalPages = max(1, (int)ceil((int)$total / (int)$perPage));
$routeBase = base_url('/index.php');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Complaints</h1>
        <div class="text-muted">Record and resolve student complaints.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=students/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="students/complaints">
            <div class="col-md-6">
                <label class="form-label">Search</label>
                <input class="form-control" name="q" value="<?= h($q) ?>" placeholder="Title or description...">
            </div>
            <div class="col-md-3">
                <label class="form-label">Status</label>
                <select class="form-select" name="status">
                    <option value="">All</option>
                    <?php foreach (['open','in_review','resolved','closed'] as $st): ?>
                        <option value="<?= h($st) ?>" <?= $status === $st ? 'selected' : '' ?>><?= h($st) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 d-grid">
                <button class="btn btn-primary" type="submit">Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Record Complaint</h2>
                <form method="post" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <div class="mb-3">
                        <label class="form-label">Student</label>
                        <select class="form-select" name="student_id">
                            <option value="">Not set</option>
                            <?php foreach ($students as $st): ?>
                                <option value="<?= (int)$st['id'] ?>">
                                    <?= h(($st['first_name'] ?? '') . ' ' . ($st['last_name'] ?? '') . ' (' . ($st['admission_no'] ?? '') . ')') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Title</label>
                        <input class="form-control" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Complaint</label>
                        <textarea class="form-control" name="complaint_text" rows="4" required></textarea>
                    </div>
                    <button class="btn btn-primary w-100" type="submit">Save Complaint</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Complaint List</h2>
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0">
                        <thead>
                        <tr>
                            <th>Title</th>
                            <th>Status</th>
                            <th style="width: 260px;">Resolve</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($complaints as $c): ?>
                            <tr>
                                <td>
                                    <div class="fw-semibold"><?= h($c['title'] ?? '') ?></div>
                                    <div class="text-muted small">
                                        <?php
                                        $studentLine = trim(($c['student_first_name'] ?? '') . ' ' . ($c['student_last_name'] ?? ''));
                                        ?>
                                        <?= h($studentLine) ?>
                                    </div>
                                </td>
                                <td><span class="badge text-bg-secondary"><?= h($c['status'] ?? '') ?></span></td>
                                <td>
                                    <?php if (($c['status'] ?? '') === 'resolved'): ?>
                                        <div class="text-muted small"><?= h($c['resolution_text'] ?? '') ?></div>
                                    <?php else: ?>
                                        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=students/complaintResolve'), ENT_QUOTES, 'UTF-8') ?>" class="d-flex gap-2">
                                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                            <input type="hidden" name="complaint_id" value="<?= (int)$c['id'] ?>">
                                            <input type="text" name="resolution_text" class="form-control form-control-sm" placeholder="Resolution text" required>
                                            <button class="btn btn-sm btn-outline-success" type="submit">Resolve</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($complaints)): ?>
                            <tr><td colspan="3" class="text-muted">No complaints found.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($totalPages > 1): ?>
                    <nav class="mt-3">
                        <ul class="pagination justify-content-center mb-0">
                            <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                                <?php
                                $query = array_merge(['q' => $q, 'status' => $status], ['page' => $p]);
                                $url = $routeBase . '&' . http_build_query($query);
                                ?>
                                <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                                    <a class="page-link" href="<?= htmlspecialchars($url, ENT_QUOTES, 'UTF-8') ?>"><?= (int)$p ?></a>
                                </li>
                            <?php endfor; ?>
                        </ul>
                    </nav>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>

