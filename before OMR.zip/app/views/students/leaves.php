<?php
// Variables: status, q, leaves, canApproveLong, scopedToOwnClass
$leaves = $leaves ?? [];
$canApproveLong = $canApproveLong ?? true;
$scopedToOwnClass = $scopedToOwnClass ?? false;
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Student Leave Requests</h1>
        <div class="text-muted small">
            <?php if ($scopedToOwnClass): ?>
                Showing leave requests for students in your own class only. You can approve or reject leaves of <strong>2 days or fewer</strong> here — longer leaves need Admin/Principal approval.
            <?php else: ?>
                Submitted by students from their own portal — approve or reject here.
            <?php endif; ?>
        </div>
    </div>
    <?php if (!$scopedToOwnClass): ?>
        <a class="btn btn-outline-secondary" href="<?= h(route_url('students/index')) ?>">Back</a>
    <?php endif; ?>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="students/leaves">
            <div class="col-md-5">
                <label class="form-label fw-semibold">Search Student</label>
                <input class="form-control" name="q" value="<?= h($q) ?>" placeholder="Name…">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold">Status</label>
                <select class="form-select" name="status">
                    <option value="">All</option>
                    <?php foreach (['pending', 'approved', 'rejected'] as $st): ?>
                        <option value="<?= $st ?>" <?= $status === $st ? 'selected' : '' ?>><?= ucfirst($st) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 d-grid">
                <button class="btn btn-outline-primary" type="submit">Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Student</th>
                        <th>Reason</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Days</th>
                        <th>Status</th>
                        <th style="width:280px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($leaves)): ?>
                    <tr><td colspan="7" class="text-muted text-center py-4">No student leave requests yet.</td></tr>
                <?php else: ?>
                    <?php foreach ($leaves as $lr):
                        $lStatus = $lr['status'] ?? 'pending';
                        $badgeClass = match ($lStatus) {
                            'approved' => 'bg-success',
                            'rejected' => 'bg-danger',
                            default    => 'bg-warning text-dark',
                        };
                        $days = '—';
                        if (!empty($lr['from_date']) && !empty($lr['to_date'])) {
                            $diff = (strtotime($lr['to_date']) - strtotime($lr['from_date'])) / 86400 + 1;
                            $days = max(0, (int)$diff);
                        }
                    ?>
                        <tr>
                            <td>
                                <div class="fw-semibold"><?= h(trim(($lr['student_first_name'] ?? '') . ' ' . ($lr['student_last_name'] ?? ''))) ?></div>
                                <div class="text-muted small"><?= h($lr['student_admission_no'] ?? '') ?></div>
                            </td>
                            <td class="small"><?= h($lr['leave_type'] ?? 'Leave') ?><?php if (!empty($lr['note'])): ?><div class="text-muted small"><?= h($lr['note']) ?></div><?php endif; ?></td>
                            <td class="small"><?= h($lr['from_date'] ?? '') ?></td>
                            <td class="small"><?= h($lr['to_date'] ?? '') ?></td>
                            <td class="small text-center"><?= $days ?></td>
                            <td><span class="badge <?= $badgeClass ?>"><?= ucfirst($lStatus) ?></span></td>
                            <td>
                                <?php if ($lStatus === 'pending'): ?>
                                    <?php $isShortLeave = $days !== '—' && (int)$days <= 2; ?>
                                    <?php if ($canApproveLong || $isShortLeave): ?>
                                        <form method="post" action="<?= h(route_url('students/approveLeave')) ?>"
                                              class="d-flex gap-1 align-items-center"
                                              onsubmit="return confirm('Save leave decision?')">
                                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                            <input type="hidden" name="leave_request_id" value="<?= (int)$lr['id'] ?>">
                                            <select class="form-select form-select-sm" name="decision" style="width:120px;" required>
                                                <option value="approved">Approve</option>
                                                <option value="rejected">Reject</option>
                                            </select>
                                            <input class="form-control form-control-sm" name="decision_note"
                                                   placeholder="Note" style="width:130px;" required>
                                            <button class="btn btn-sm btn-outline-primary" type="submit">Save</button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-muted small fst-italic">Needs Admin/Principal approval (over 2 days)</span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted small"><?= h($lr['latest_decision'] ?? $lStatus) ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
