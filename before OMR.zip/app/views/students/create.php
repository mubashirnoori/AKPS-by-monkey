<?php
// Variables: $classSections, $error, $old, $listFilters
$old = $old ?? [];
$selectedClassSectionId = (int)($old['class_section_id'] ?? 0);
$listFilters = $listFilters ?? recall_list_filters('students', [
    'q' => '', 'class_section_id' => 0, 'student_status' => 'active', 'per_page' => 10, 'page' => 1,
]);
$listBackUrl = list_url('students/index', $listFilters);
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Add Student</h1>
        <div class="text-muted">Create student record and assign class/section.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars($listBackUrl, ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <form method="post" enctype="multipart/form-data" action="<?= htmlspecialchars(base_url('/index.php?route=students/store'), ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
            <?php list_return_fields($listFilters); ?>

            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Admission No</label>
                    <input class="form-control" name="admission_no" value="<?= h($old['admission_no'] ?? '') ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">First Name</label>
                    <input class="form-control" name="first_name" value="<?= h($old['first_name'] ?? '') ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Last Name</label>
                    <input class="form-control" name="last_name" value="<?= h($old['last_name'] ?? '') ?>" required>
                </div>

                <div class="col-md-3">
                    <label class="form-label">Gender</label>
                    <select class="form-select" name="gender">
                        <?php
                        $g = (string)($old['gender'] ?? 'M');
                        foreach (['M' => 'Male', 'F' => 'Female', 'Other' => 'Other'] as $key => $label):
                        ?>
                            <option value="<?= h($key) ?>" <?= $g === $key ? 'selected' : '' ?>><?= h($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">DOB</label>
                    <input class="form-control" name="dob" type="date" value="<?= h($old['dob'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Phone</label>
                    <input class="form-control" name="phone" value="<?= h($old['phone'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Class / Section</label>
                    <select class="form-select" name="class_section_id" required>
                        <option value="">Choose...</option>
                        <?php foreach ($classSections as $cs): ?>
                            <option value="<?= (int)$cs['id'] ?>"><?= h($cs['class_name'] . ' ' . $cs['section_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Father's Name</label>
                    <input class="form-control" name="father_name" value="<?= h($old['father_name'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">CNIC Number</label>
                    <input class="form-control" name="cnic_no" value="<?= h($old['cnic_no'] ?? '') ?>" placeholder="e.g. 17301-1234567-1">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Board Registration No.</label>
                    <input class="form-control" name="board_registration_no" value="<?= h($old['board_registration_no'] ?? '') ?>" placeholder="e.g. BISE-2024-12345">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Roll Number <span class="text-muted small">(unique in class)</span></label>
                    <input class="form-control" name="roll_number" type="number" min="1" value="<?= (int)($old['roll_number'] ?? 0) ?: '' ?>" placeholder="e.g. 12">
                </div>

                <div class="col-md-12">
                    <label class="form-label">Address</label>
                    <input class="form-control" name="address" value="<?= h($old['address'] ?? '') ?>">
                </div>
            </div>

            <hr class="my-4">
            <h2 class="h6 mb-1">Fee Discount</h2>
            <p class="text-muted small mb-3">Optional. Applied automatically when invoices are generated. Leave value at 0 for full fee.</p>
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Type</label>
                    <?php $fdIsPct = (int)($old['fee_discount_is_percent'] ?? 1) === 1; ?>
                    <select class="form-select" name="fee_discount_is_percent" id="feeDiscountType">
                        <option value="1" <?= $fdIsPct ? 'selected' : '' ?>>Percentage (%)</option>
                        <option value="0" <?= !$fdIsPct ? 'selected' : '' ?>>Fixed amount (Rs)</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Value</label>
                    <?php $fd = (float)($old['fee_discount_percent'] ?? 0); ?>
                    <input class="form-control" name="fee_discount_percent" id="feeDiscountValue" type="number" min="0" step="0.01"
                           value="<?= $fd > 0 ? h((string)$fd) : '0' ?>" placeholder="0">
                    <div class="form-text" id="feeDiscountHint"><?= $fdIsPct ? 'e.g. 25, 50, or 100 for free' : 'Fixed Rs amount off each invoice' ?></div>
                </div>
            </div>

            <hr>

            <div class="mb-3">
                <h2 class="h6 mb-2">Profile Photo <span class="text-muted fw-normal">(optional)</span></h2>
                <div class="row g-3 align-items-center">
                    <div class="col-auto">
                        <div id="createPhotoPreviewWrap" style="width:80px;height:80px;border-radius:50%;overflow:hidden;
                             background:#e8edf8;display:flex;align-items:center;justify-content:center;
                             font-size:1.5rem;font-weight:700;color:#1a3a7a;border:3px solid #d1d9f0;">
                            <span id="createPhotoInitials">?</span>
                            <img id="createPhotoPreviewImg" src="" alt="" style="display:none;width:100%;height:100%;object-fit:cover;">
                        </div>
                    </div>
                    <div class="col">
                        <input type="file" name="photo" id="createPhotoInput" class="form-control" accept="image/jpeg,image/png,image/webp,image/gif">
                        <div class="text-muted small mt-1">JPEG, PNG, WebP or GIF. Square crop recommended. You can also upload later via <em>Upload Photo</em>.</div>
                    </div>
                </div>
            </div>

            <hr>

            <div class="mb-3">
                <div class="form-check mb-2">
                    <input class="form-check-input" type="checkbox" name="create_login" id="student_create_login" value="1" onchange="document.getElementById('studentLoginFields').style.display = this.checked ? 'flex' : 'none'">
                    <label class="form-check-label fw-semibold" for="student_create_login">Also create a login account for this student</label>
                </div>
                <div class="row g-3" id="studentLoginFields" style="display:none;">
                    <div class="col-md-3">
                        <label class="form-label">Role</label>
                        <select class="form-select" name="login_role">
                            <option value="Student" selected>Student</option>
                            <option value="Parent">Parent</option>
                            <option value="Teacher">Teacher</option>
                            <option value="Accountant">Accountant</option>
                        </select>
                        <div class="form-text">Can be changed later in Users.</div>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Username</label>
                        <input class="form-control" name="login_username" placeholder="Defaults to admission number">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Password</label>
                        <div class="input-group">
                            <input class="form-control" type="password" name="login_password" id="student_login_password" placeholder="Leave blank to auto-generate">
                            <button class="btn btn-outline-secondary" type="button" onclick="togglePasswordVisibility('student_login_password', this)"><i class="bi bi-eye"></i></button>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Email</label>
                        <input class="form-control" name="login_email">
                    </div>
                </div>
            </div>

            <hr>

            <div class="mb-3">
                <h2 class="h6 mb-2">Optional Guardian</h2>
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Full Name</label>
                        <input class="form-control" name="guardian_full_name">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Relation</label>
                        <input class="form-control" name="guardian_relation" placeholder="Father/Mother/Guardian">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Phone</label>
                        <input class="form-control" name="guardian_phone">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Email</label>
                        <input class="form-control" name="guardian_email">
                    </div>
                    <div class="col-md-12">
                        <label class="form-label">Address</label>
                        <input class="form-control" name="guardian_address">
                    </div>
                    <div class="col-md-12">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="guardian_is_primary" id="guardian_is_primary" value="1">
                            <label class="form-check-label" for="guardian_is_primary">Mark as primary guardian</label>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-check mb-2">
                            <input class="form-check-input" type="checkbox" name="guardian_create_login" id="guardian_create_login" value="1" onchange="document.getElementById('guardianLoginFields').style.display = this.checked ? 'flex' : 'none'">
                            <label class="form-check-label fw-semibold" for="guardian_create_login">Also create a login account for this guardian</label>
                        </div>
                        <div class="row g-3" id="guardianLoginFields" style="display:none;">
                            <div class="col-md-4">
                                <label class="form-label">Username</label>
                                <input class="form-control" name="guardian_login_username" placeholder="Defaults to phone number">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Password</label>
                                <div class="input-group">
                                    <input class="form-control" type="password" name="guardian_login_password" id="guardian_login_password" placeholder="Leave blank to auto-generate">
                                    <button class="btn btn-outline-secondary" type="button" onclick="togglePasswordVisibility('guardian_login_password', this)"><i class="bi bi-eye"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="d-flex gap-2">
                <button class="btn btn-primary" type="submit">Create Student</button>
                <a class="btn btn-outline-secondary" href="<?= htmlspecialchars($listBackUrl, ENT_QUOTES, 'UTF-8') ?>">Cancel</a>
            </div>
        </form>
    </div>
</div>

<script>
(function () {
    // Live initials in avatar as user types name
    const fnInput = document.querySelector('input[name="first_name"]');
    const lnInput = document.querySelector('input[name="last_name"]');
    const initialsEl = document.getElementById('createPhotoInitials');
    function updateInitials() {
        const f = (fnInput?.value || '').trim();
        const l = (lnInput?.value || '').trim();
        initialsEl.textContent = ((f[0] || '') + (l[0] || '')).toUpperCase() || '?';
    }
    fnInput?.addEventListener('input', updateInitials);
    lnInput?.addEventListener('input', updateInitials);

    // Live photo preview
    const fileInput  = document.getElementById('createPhotoInput');
    const previewImg = document.getElementById('createPhotoPreviewImg');
    const initEl     = document.getElementById('createPhotoInitials');
    fileInput?.addEventListener('change', function () {
        const file = this.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = e => {
            previewImg.src = e.target.result;
            previewImg.style.display = 'block';
            initEl.style.display = 'none';
        };
        reader.readAsDataURL(file);
    });

    const typeSel = document.getElementById('feeDiscountType');
    const valInp = document.getElementById('feeDiscountValue');
    const hint = document.getElementById('feeDiscountHint');
    function syncFeeHint() {
        const isPct = typeSel?.value === '1';
        if (hint) hint.textContent = isPct ? 'e.g. 25, 50, or 100 for free' : 'Fixed amount off the invoice';
        if (valInp) {
            valInp.max = isPct ? '100' : '';
            if (isPct && parseFloat(valInp.value || '0') > 100) valInp.value = '100';
        }
    }
    typeSel?.addEventListener('change', syncFeeHint);
    syncFeeHint();
})();
</script>

