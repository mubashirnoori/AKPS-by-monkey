<?php
// Variables: $moduleName
?>
<div class="card shadow-sm border-0">
    <div class="card-body">
        <h2 class="h5 mb-1"><?= h($moduleName) ?></h2>
        <div class="text-muted">This module is not fully implemented yet. The system foundation is complete.</div>
    </div>
</div>

