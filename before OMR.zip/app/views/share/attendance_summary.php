<?php
// Variables: $student (StudentModel::getById row), $start, $end (Y-m-d), $records, $summary, $schoolName, $logoPath
$student = $student ?? [];
$studentName = trim(($student['first_name'] ?? '') . ' ' . ($student['last_name'] ?? ''));
$className = trim(($student['current_class_name'] ?? '') . ' ' . ($student['current_section_name'] ?? ''));
$summary = $summary ?? ['total' => 0, 'present' => 0, 'absent' => 0, 'late' => 0, 'excused' => 0, 'holiday' => 0];
$attendedCount = $summary['present'] + $summary['late'];
$ratableCount = $summary['total'] - $summary['holiday'];
$attendanceRate = $ratableCount > 0 ? round(($attendedCount / $ratableCount) * 100, 1) : null;

$statusLabel = static function (string $status): string {
    $map = ['present' => 'Present', 'absent' => 'Absent', 'late' => 'Late', 'excused' => 'Leave', 'holiday' => 'Holiday'];
    return $map[$status] ?? ucfirst($status);
};
$statusBadgeClass = static function (string $status): string {
    $map = [
        'present' => 'bg-success',
        'absent'  => 'bg-danger',
        'late'    => 'bg-warning text-dark',
        'excused' => 'bg-info text-dark',
        'holiday' => 'bg-primary',
    ];
    return $map[$status] ?? 'bg-secondary';
};
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Attendance - <?= h($studentName) ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <style>
        body { background: #f4f6f8; }
        .wrap { max-width: 640px; margin: 0 auto; padding: 1.25rem 1rem 3rem; }
        .school-header { text-align: center; margin-bottom: 1rem; }
        .school-header img { max-height: 56px; margin-bottom: .5rem; }
        .kpi { text-align: center; }
        .kpi .num { font-size: 1.4rem; font-weight: 700; }
        .kpi .lbl { font-size: .75rem; color: #666; text-transform: uppercase; letter-spacing: .04em; }
    </style>
</head>
<body>
<div class="wrap">
    <div class="school-header">
        <?php if (!empty($logoPath)): ?><img src="<?= h($logoPath) ?>" alt=""><?php endif; ?>
        <div class="fw-bold"><?= h($schoolName ?? 'School') ?></div>
        <div class="text-muted small">Attendance Summary</div>
    </div>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body">
            <div class="fw-semibold fs-5"><?= h($studentName) ?></div>
            <div class="text-muted small">
                <?= h($className) ?><?= $className !== '' && !empty($student['admission_no']) ? ' &middot; ' : '' ?>
                <?= !empty($student['admission_no']) ? 'Admission No: ' . h($student['admission_no']) : '' ?>
            </div>
            <div class="text-muted small mt-1"><?= h($start) ?> to <?= h($end) ?></div>
        </div>
    </div>

    <div class="row row-cols-3 g-2 mb-3 text-center">
        <div class="col"><div class="card border-0 shadow-sm p-2 kpi"><div class="num text-success"><?= (int)$summary['present'] ?></div><div class="lbl">Present</div></div></div>
        <div class="col"><div class="card border-0 shadow-sm p-2 kpi"><div class="num text-danger"><?= (int)$summary['absent'] ?></div><div class="lbl">Absent</div></div></div>
        <div class="col"><div class="card border-0 shadow-sm p-2 kpi"><div class="num text-warning"><?= (int)$summary['late'] ?></div><div class="lbl">Late</div></div></div>
    </div>

    <?php if ($attendanceRate !== null): ?>
    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body text-center">
            <div class="lbl text-muted small">ATTENDANCE RATE</div>
            <div class="num" style="font-size:1.6rem; font-weight:700;"><?= h((string)$attendanceRate) ?>%</div>
        </div>
    </div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white fw-semibold small">Day by day</div>
        <div class="list-group list-group-flush">
            <?php if (empty($records)): ?>
                <div class="list-group-item text-muted small">No attendance records in this range.</div>
            <?php else: ?>
                <?php foreach ($records as $r): ?>
                    <div class="list-group-item d-flex justify-content-between align-items-center py-2">
                        <span class="small"><?= h(date('D, d M Y', strtotime((string)$r['attendance_date']))) ?></span>
                        <span class="badge <?= $statusBadgeClass((string)$r['status']) ?>"><?= h($statusLabel((string)$r['status'])) ?></span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="text-center text-muted small mt-4">Shared from <?= h($schoolName ?? 'School') ?>'s student portal.</div>
</div>
</body>
</html>
