<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Link Not Available</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="d-flex align-items-center justify-content-center" style="min-height: 100vh;">
        <div class="text-center p-4">
            <div class="display-1 mb-3">🔗</div>
            <h1 class="h4 mb-2">This link isn't available anymore</h1>
            <p class="text-muted mb-0">It may have expired, or the record it pointed to is no longer available.</p>
            <p class="text-muted">Please contact the school office if you need this again.</p>
        </div>
    </div>
</body>
</html>
