<?php
// Variables: $settings, $hasSmtpPassword, $error
$settings = $settings ?? [];
$hasSmtpPassword = $hasSmtpPassword ?? false;
$smtpEnabled = !empty($settings['smtp_enabled']) && $settings['smtp_enabled'] === '1';
$smtpAuth = !isset($settings['smtp_auth']) || $settings['smtp_auth'] !== '0'; // default on
$smtpVerify = !isset($settings['smtp_verify_cert']) || $settings['smtp_verify_cert'] !== '0'; // default on
$smtpEncryption = $settings['smtp_encryption'] ?? 'tls';
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Notifications</h1>
        <div class="text-muted">Sender address and SMTP credentials for outgoing email, plus SMS gateway credentials.</div>
    </div>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<form method="post" action="<?= htmlspecialchars(route_url('settings/notifications'), ENT_QUOTES, 'UTF-8') ?>">
    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-header bg-white fw-semibold">Announcement Delivery Channels</div>
        <div class="card-body">
            <div class="text-muted small mb-3">
                Choose which channels an announcement goes out on, in addition to the notification bell (which every
                recipient always gets). SMS uses the registered mobile number on file for each recipient (student /
                guardian / staff); email uses their registered email address. Both require the corresponding
                gateway below to be configured and enabled.
            </div>
            <div class="row g-3">
                <div class="col-md-4">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" id="announce_channel_push" name="announce_channel_push" value="1" <?= (!isset($settings['announce_channel_push']) || $settings['announce_channel_push'] === '1') ? 'checked' : '' ?>>
                        <label class="form-check-label small fw-semibold" for="announce_channel_push">Push notification</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" id="announce_channel_sms" name="announce_channel_sms" value="1" <?= (($settings['announce_channel_sms'] ?? '0') === '1') ? 'checked' : '' ?>>
                        <label class="form-check-label small fw-semibold" for="announce_channel_sms">SMS (registered phone number)</label>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" id="announce_channel_email" name="announce_channel_email" value="1" <?= (($settings['announce_channel_email'] ?? '0') === '1') ? 'checked' : '' ?>>
                        <label class="form-check-label small fw-semibold" for="announce_channel_email">Email</label>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-header bg-white fw-semibold">Email — Sender</div>
        <div class="card-body">
            <div class="text-muted small mb-3">Used as the "From" address on password-reset and other system emails.</div>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">From Email</label>
                    <input type="email" class="form-control" name="mail_from_email" value="<?= h($settings['mail_from_email'] ?? '') ?>" placeholder="no-reply@yourdomain.com">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">From Name</label>
                    <input type="text" class="form-control" name="mail_from_name" value="<?= h($settings['mail_from_name'] ?? '') ?>" placeholder="Your School Name">
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-header bg-white fw-semibold">Email — Outgoing Server (SMTP)</div>
        <div class="card-body">
            <div class="text-muted small mb-3">
                When disabled, the system falls back to your server's built-in <code>mail()</code> function, which many
                hosts block or send to spam. Turning this on and pointing it at a real SMTP account (Gmail, Outlook,
                SendGrid, Mailgun, your hosting provider's mail server, etc.) is the most reliable way to get email
                delivered.
            </div>

            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" role="switch" id="smtp_enabled" name="smtp_enabled" value="1" <?= $smtpEnabled ? 'checked' : '' ?>>
                <label class="form-check-label small fw-semibold" for="smtp_enabled">Send email via SMTP</label>
            </div>

            <div class="row g-3">
                <div class="col-md-8">
                    <label class="form-label small fw-semibold">SMTP Host</label>
                    <input type="text" class="form-control" name="smtp_host" value="<?= h($settings['smtp_host'] ?? '') ?>" placeholder="smtp.gmail.com / smtp.office365.com / mail.yourdomain.com">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold">SMTP Port</label>
                    <input type="number" min="1" max="65535" class="form-control" name="smtp_port" value="<?= h($settings['smtp_port'] ?? '587') ?>" placeholder="587">
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Encryption</label>
                    <select class="form-select" name="smtp_encryption">
                        <option value="tls" <?= $smtpEncryption === 'tls' ? 'selected' : '' ?>>STARTTLS (usually port 587)</option>
                        <option value="ssl" <?= $smtpEncryption === 'ssl' ? 'selected' : '' ?>>SSL / implicit TLS (usually port 465)</option>
                        <option value="none" <?= $smtpEncryption === 'none' ? 'selected' : '' ?>>None (port 25, not recommended)</option>
                    </select>
                </div>
                <div class="col-md-6 d-flex align-items-end">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" id="smtp_verify_cert" name="smtp_verify_cert" value="1" <?= $smtpVerify ? 'checked' : '' ?>>
                        <label class="form-check-label small" for="smtp_verify_cert">Verify SSL certificate (leave on unless your mail server uses a self-signed certificate)</label>
                    </div>
                </div>

                <div class="col-12"><hr class="my-1"></div>

                <div class="col-12">
                    <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" role="switch" id="smtp_auth" name="smtp_auth" value="1" <?= $smtpAuth ? 'checked' : '' ?>>
                        <label class="form-check-label small fw-semibold" for="smtp_auth">Server requires authentication (almost always yes)</label>
                    </div>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-semibold">SMTP Username</label>
                    <input type="text" class="form-control" name="smtp_username" value="<?= h($settings['smtp_username'] ?? '') ?>" autocomplete="off" placeholder="your account or full email address">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">SMTP Password</label>
                    <input
                        type="password"
                        class="form-control font-monospace"
                        name="smtp_password"
                        autocomplete="new-password"
                        placeholder="<?= $hasSmtpPassword ? '•••••••• (leave blank to keep current password)' : 'Enter SMTP account password / app password' ?>"
                    >
                    <?php if ($hasSmtpPassword): ?>
                        <div class="form-check mt-2">
                            <input class="form-check-input" type="checkbox" id="smtp_password_clear" name="smtp_password_clear" value="1">
                            <label class="form-check-label small text-danger" for="smtp_password_clear">Remove saved password</label>
                        </div>
                    <?php else: ?>
                        <div class="form-text small">No password saved yet.</div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="text-muted small mt-3">
                Tip: for Gmail / Google Workspace, use port 587 with STARTTLS and an
                <a href="https://myaccount.google.com/apppasswords" target="_blank" rel="noopener">app password</a>
                (not your normal login password) once 2-Step Verification is on.
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-header bg-white fw-semibold">SMS Gateway — Android Device Relay</div>
        <div class="card-body">
            <div class="text-muted small mb-3">
                No paid SMS API needed. This server writes messages to a queue; a phone with a SIM installed
                polls <code>api/sms_gateway.php</code> and sends them as real SMS through its own network.
            </div>

            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" role="switch" id="sms_enabled" name="sms_enabled" value="1" <?= !empty($settings['sms_enabled']) && $settings['sms_enabled'] === '1' ? 'checked' : '' ?>>
                <label class="form-check-label small fw-semibold" for="sms_enabled">Enable SMS sending (notifications + password-reset OTP)</label>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-md-4">
                    <label class="form-label small fw-semibold" for="sms_send_interval_seconds">Delay Between Sends (seconds)</label>
                    <input type="number" class="form-control" id="sms_send_interval_seconds" name="sms_send_interval_seconds"
                           min="0" max="3600" step="1"
                           value="<?= h($settings['sms_send_interval_seconds'] ?? '60') ?>">
                    <div class="form-text small">
                        Minimum gap between messages from the same device. <strong>0</strong> disables pacing (not
                        recommended); anything else is floored at 2s. Default is 60s — one message per minute.
                    </div>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold" for="sms_limit_per_15min">15-Minute Cap</label>
                    <input type="number" class="form-control" id="sms_limit_per_15min" name="sms_limit_per_15min"
                           min="0" step="1"
                           value="<?= h($settings['sms_limit_per_15min'] ?? '150') ?>">
                    <div class="form-text small">Hard stop on messages sent per device in any rolling 15 minutes. 0 disables this cap.</div>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold" for="sms_limit_per_hour">Hourly Cap</label>
                    <input type="number" class="form-control" id="sms_limit_per_hour" name="sms_limit_per_hour"
                           min="0" step="1"
                           value="<?= h($settings['sms_limit_per_hour'] ?? '250') ?>">
                    <div class="form-text small">Hard stop on messages sent per device in any rolling 1 hour. 0 disables this cap.</div>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-semibold" for="sms_limit_per_day">Daily Cap</label>
                    <input type="number" class="form-control" id="sms_limit_per_day" name="sms_limit_per_day"
                           min="0" step="1"
                           value="<?= h($settings['sms_limit_per_day'] ?? '750') ?>">
                    <div class="form-text small">Hard stop on messages sent per device in any rolling 24 hours. 0 disables this cap.</div>
                </div>
                <div class="col-12">
                    <div class="text-muted small">
                        Together these keep a device under your carrier's own block thresholds even during a large,
                        sustained blast — the delay alone can't guarantee the daily cap (one message/minute for a
                        full day is 1,440 messages, well past a 750/day limit), so once any window fills up the
                        gateway simply waits it out before handing that device another message. The defaults above
                        match Zong's own stated thresholds — lower them for extra safety margin if you like.
                    </div>
                </div>
            </div>

            <div class="alert alert-info small mb-0 d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div>
                    Relay phones (numbers + tokens), including one per staff member so their notifications go out
                    under their own number, are now managed on their own page.
                </div>
                <a class="btn btn-sm btn-primary" href="<?= htmlspecialchars(route_url('settings/smsDevices'), ENT_QUOTES, 'UTF-8') ?>">
                    Manage SMS Gateway Devices <i class="bi bi-arrow-right ms-1"></i>
                </a>
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-header bg-white fw-semibold">SMS Gateway — Commercial Provider (optional)</div>
        <div class="card-body">
            <div class="text-muted small mb-3">Only needed if you'd rather pay a provider (Twilio, etc.) instead of the free Android relay above. Leave blank if you're using the relay phone.</div>

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Provider</label>
                    <input type="text" class="form-control" name="sms_provider" value="<?= h($settings['sms_provider'] ?? '') ?>" placeholder="e.g. Twilio">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">Sender ID / From Number</label>
                    <input type="text" class="form-control" name="sms_sender_id" value="<?= h($settings['sms_sender_id'] ?? '') ?>" placeholder="e.g. SCHOOLSMS or +923xxxxxxxxx">
                </div>
                <div class="col-md-12">
                    <label class="form-label small fw-semibold">API Endpoint</label>
                    <input type="text" class="form-control" name="sms_api_endpoint" value="<?= h($settings['sms_api_endpoint'] ?? '') ?>" placeholder="https://api.yourprovider.com/send">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">API Key</label>
                    <input type="text" class="form-control font-monospace" name="sms_api_key" value="<?= h($settings['sms_api_key'] ?? '') ?>" autocomplete="off">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-semibold">API Secret</label>
                    <input type="password" class="form-control font-monospace" name="sms_api_secret" value="<?= h($settings['sms_api_secret'] ?? '') ?>" autocomplete="off">
                </div>
            </div>
        </div>
    </div>

    <button type="submit" class="btn btn-primary">Save Notification Settings</button>
</form>

<div class="card shadow-sm border-0 mt-3">
    <div class="card-header bg-white fw-semibold">Send a Test SMS</div>
    <div class="card-body">
        <div class="text-muted small mb-3">Save your settings above first. This queues a message — it actually sends once your relay phone's poller script picks it up.</div>
        <form method="post" action="<?= htmlspecialchars(route_url('settings/smsTest'), ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-center">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
            <div class="col-auto">
                <input type="text" class="form-control" name="test_number" placeholder="03145525749" required>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-outline-primary">Queue Test SMS</button>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm border-0 mt-3">
    <div class="card-header bg-white fw-semibold">Send a Test Email</div>
    <div class="card-body">
        <div class="text-muted small mb-3">Save your settings above first, then send a test to confirm delivery works before relying on it for password resets.</div>
        <form method="post" action="<?= htmlspecialchars(route_url('settings/smtpTest'), ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-center">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
            <div class="col-auto">
                <input type="email" class="form-control" name="test_email" placeholder="you@yourdomain.com" required>
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-outline-primary">Send Test Email</button>
            </div>
        </form>
    </div>
</div>
