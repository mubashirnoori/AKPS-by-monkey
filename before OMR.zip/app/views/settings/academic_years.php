<?php
// Variables: years, error
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Academic Years</h1>
        <div class="text-muted">Create and select the active academic year.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=settings/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <h2 class="h6 mb-3">Create Academic Year</h2>
        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=settings/academicYears'), ENT_QUOTES, 'UTF-8') ?>" class="row g-3 align-items-end">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
            <div class="col-md-4">
                <label class="form-label">Label *</label>
                <input class="form-control" name="academic_year_label" placeholder="2025-2026" required>
            </div>
            <div class="col-md-3">
                <label class="form-label">Session Name</label>
                <input class="form-control" name="session_name">
            </div>
            <div class="col-md-2">
                <label class="form-label">Start</label>
                <input class="form-control" type="date" name="start_date">
            </div>
            <div class="col-md-2">
                <label class="form-label">End</label>
                <input class="form-control" type="date" name="end_date">
            </div>
            <div class="col-md-1">
                <label class="form-label">Active</label>
                <select class="form-select" name="is_active">
                    <option value="0">No</option>
                    <option value="1">Yes</option>
                </select>
            </div>
            <div class="col-12">
                <button class="btn btn-primary" type="submit">Create</button>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <h2 class="h6 mb-3">Existing Years</h2>
        <div id="academicYearListContainer">
        <?= $this->renderPartial('settings/_academic_year_list', [
            'years' => $years,
        ]) ?>
        </div>
    </div>
</div>

