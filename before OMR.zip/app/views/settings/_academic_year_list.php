<?php
// Variables: $years
$years = $years ?? [];
?>
<div class="table-responsive">
    <table class="table table-sm table-striped mb-0">
        <thead>
            <tr><th>Label</th><th>Session</th><th>Dates</th><th>Active</th><th style="width:160px;">Action</th></tr>
        </thead>
        <tbody>
        <?php if (empty($years)): ?>
            <tr><td colspan="5" class="text-muted">No academic years.</td></tr>
        <?php else: ?>
            <?php foreach ($years as $y): ?>
                <tr>
                    <td class="fw-semibold"><?= h($y['academic_year_label'] ?? '') ?></td>
                    <td class="text-muted small"><?= h($y['session_name'] ?? '') ?></td>
                    <td class="text-muted small"><?= h($y['start_date'] ?? '') ?> - <?= h($y['end_date'] ?? '') ?></td>
                    <td><?= !empty($y['is_active']) ? '<span class="badge text-bg-success">Active</span>' : '<span class="badge text-bg-secondary">No</span>' ?></td>
                    <td>
                        <?php if (empty($y['is_active'])): ?>
                            <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=settings/academicYears'), ENT_QUOTES, 'UTF-8') ?>"
                                  data-ajax data-target="#academicYearListContainer">
                                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                <input type="hidden" name="set_active_id" value="<?= (int)$y['id'] ?>">
                                <button class="btn btn-sm btn-outline-primary" type="submit">Set Active</button>
                            </form>
                        <?php else: ?>
                            <span class="text-muted small">Current</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
