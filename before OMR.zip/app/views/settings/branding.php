<?php
// Variables: $settings, $error
$settings = $settings ?? [];
$schoolName = $settings['branding_school_name'] ?? 'SchoolSMS';
$logoPath = $settings['branding_logo_path'] ?? '';
$faviconPath = $settings['branding_favicon_path'] ?? '';
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Branding</h1>
        <div class="text-muted">Update school name, logo and favicon.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=settings/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=settings/branding'), ENT_QUOTES, 'UTF-8') ?>" enctype="multipart/form-data" class="row g-3">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">

            <div class="col-md-8">
                <label class="form-label">School Name</label>
                <input class="form-control" name="branding_school_name" value="<?= h($schoolName) ?>" required>
            </div>

            <div class="col-md-6">
                <label class="form-label">Logo (PNG/JPG/SVG/WEBP)</label>
                <input class="form-control" type="file" name="branding_logo" accept=".png,.jpg,.jpeg,.webp,image/png,image/jpeg,image/webp">
                <?php if ($logoPath !== ''): ?>
                    <div class="mt-2">
                        <img src="<?= htmlspecialchars(base_url($logoPath), ENT_QUOTES, 'UTF-8') ?>" alt="Logo" style="max-height:60px; width:auto;">
                    </div>
                <?php endif; ?>
            </div>

            <div class="col-md-6">
                <label class="form-label">Favicon (ICO/PNG/JPG/SVG/WEBP)</label>
                <input class="form-control" type="file" name="branding_favicon" accept=".ico,.png,.jpg,.jpeg,.webp,image/x-icon,image/png,image/jpeg,image/webp">
                <?php if ($faviconPath !== ''): ?>
                    <div class="mt-2">
                        <img src="<?= htmlspecialchars(base_url($faviconPath), ENT_QUOTES, 'UTF-8') ?>" alt="Favicon" style="max-height:32px; width:auto;">
                    </div>
                <?php endif; ?>
            </div>

            <div class="col-12">
                <button class="btn btn-primary" type="submit">Save Branding</button>
            </div>
        </form>
    </div>
</div>
