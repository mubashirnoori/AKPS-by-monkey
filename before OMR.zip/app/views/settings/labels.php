<?php
// Variables: module, rows, error
$routeBase = base_url('/index.php?route=settings/labels');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Label Management</h1>
        <div class="text-muted">Override module field labels.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=settings/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label">Module</label>
                <select class="form-select" name="module" onchange="this.form.submit()">
                    <?php foreach (['students','academic','fees','staff','users','reports','settings'] as $m): ?>
                        <option value="<?= h($m) ?>" <?= $module === $m ? 'selected' : '' ?>><?= h($m) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </form>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Create / Update Label</h2>
                <form method="post" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="module" value="<?= h($module) ?>">
                    <div class="mb-3">
                        <label class="form-label">Field Key *</label>
                        <input class="form-control" name="field_key" required placeholder="e.g. admission_no">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Label *</label>
                        <input class="form-control" name="label_text" required placeholder="Admission Number">
                    </div>
                    <button class="btn btn-primary w-100" type="submit">Save</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Overrides</h2>
                <div id="labelListContainer">
                <?= $this->renderPartial('settings/_label_list', [
                    'rows' => $rows,
                    'module' => $module,
                    'routeBase' => $routeBase,
                ]) ?>
                </div>
            </div>
        </div>
    </div>
</div>

