<?php
// Variables: $rows, $module, $routeBase
$rows = $rows ?? [];
$module = $module ?? '';
$routeBase = $routeBase ?? base_url('/index.php?route=settings/labels');
?>
<div class="table-responsive">
    <table class="table table-sm table-striped mb-0">
        <thead>
            <tr><th>Field</th><th>Label</th><th style="width:120px;">Delete</th></tr>
        </thead>
        <tbody>
        <?php if (empty($rows)): ?>
            <tr><td colspan="3" class="text-muted">No overrides.</td></tr>
        <?php else: ?>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="fw-semibold"><?= h($r['field_key'] ?? '') ?></td>
                    <td><?= h($r['label_text'] ?? '') ?></td>
                    <td>
                        <form method="post" action="<?= htmlspecialchars($routeBase . '&module=' . rawurlencode($module), ENT_QUOTES, 'UTF-8') ?>"
                              data-ajax data-target="#labelListContainer" data-confirm="Delete label override?">
                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                            <input type="hidden" name="module" value="<?= h($module) ?>">
                            <input type="hidden" name="delete_id" value="<?= (int)$r['id'] ?>">
                            <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
