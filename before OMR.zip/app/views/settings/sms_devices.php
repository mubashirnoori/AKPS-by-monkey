<?php
// Variables: $devices, $error, $endpointUrl
$devices = $devices ?? [];
$error = $error ?? null;
$endpointUrl = $endpointUrl ?? '';
$staffSearchUrl = base_url('/index.php?route=settings/smsDeviceStaffSearch');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">SMS Gateway Devices</h1>
        <div class="text-muted">
            Each device below is a phone running the relay app, sending real SMS through its own SIM. Assign one to a
            staff member so their notifications go out under their own number, or leave it unassigned to share the
            default device.
        </div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(route_url('settings/notifications'), ENT_QUOTES, 'UTF-8') ?>">
        <i class="bi bi-arrow-left me-1"></i>Back to Notifications
    </a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <label class="form-label small fw-semibold">Endpoint every device polls</label>
        <input type="text" class="form-control font-monospace" readonly value="<?= h($endpointUrl) ?>" onclick="this.select()">
        <div class="form-text small">
            Point your Android app at this URL. Each device authenticates with its own token below
            (header <code>X-Gateway-Token</code>, or <code>?token=</code> if your app can't set headers) — not a school
            login. See the comment at the top of <code>api/sms_gateway.php</code> for the full request/response contract.
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0 sms-overflow-visible">
            <div class="card-body">
                <h2 class="h6 mb-3" id="deviceFormTitle">Add a Device</h2>
                <form method="post" action="<?= htmlspecialchars(route_url('settings/smsDevices'), ENT_QUOTES, 'UTF-8') ?>" id="deviceForm">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="route" value="settings/smsDevices">
                    <input type="hidden" name="form_action" value="save">
                    <input type="hidden" name="device_id" id="device_id" value="0">

                    <div class="mb-3">
                        <label class="form-label">Label</label>
                        <input type="text" class="form-control" name="label" id="device_label" placeholder="e.g. Mr. Ali's Phone, or Admin Office" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Assign to Staff Member <span class="text-muted small">(optional)</span></label>
                        <div class="combo" data-combo-root data-combo-type="staff">
                            <input type="text" class="form-control combo-input" id="device_staff_input" placeholder="Type a staff member's name…" autocomplete="off">
                            <input type="hidden" name="staff_profile_id" id="device_staff_id" value="0">
                            <div class="combo-menu list-group shadow-sm"></div>
                        </div>
                        <div class="form-text small">Leave blank for a spare/shared device not tied to one person.</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Phone Number <span class="text-muted small">(for your reference)</span></label>
                        <input type="text" class="form-control" name="phone_number" id="device_phone" placeholder="03145525749">
                        <div class="form-text small">Whatever SIM is physically in the phone is what actually sends — this field is just a record of which number that is, so you and other admins know at a glance. Changing it here doesn't reprovision anything on the phone itself.</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select class="form-select" name="status" id="device_status">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive (stops receiving messages)</option>
                        </select>
                    </div>

                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" role="switch" name="is_default" id="device_is_default" value="1">
                        <label class="form-check-label" for="device_is_default">
                            Default device — catches OTPs, fee reminders, and any staff announcement sent by someone with no personal device
                        </label>
                        <div class="form-text small">Exactly one device should be the default. Marking this one default will un-mark whichever device currently holds it.</div>
                    </div>

                    <div class="d-flex gap-2">
                        <button class="btn btn-primary" type="submit">Save Device</button>
                        <button class="btn btn-outline-secondary d-none" type="button" id="deviceFormCancel">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">All Devices</h2>
                <?php if (empty($devices)): ?>
                    <div class="text-muted small">No devices yet — add one on the left.</div>
                <?php endif; ?>
                <?php foreach ($devices as $d): ?>
                    <?php
                    $staffLabel = $d['staff_name'] ? ($d['staff_name'] . (!empty($d['staff_code']) ? ' (' . $d['staff_code'] . ')' : '')) : '';
                    $lastSeen = $d['last_seen_at'] ? date('M j, g:i A', strtotime((string)$d['last_seen_at'])) : 'Never polled yet';
                    ?>
                    <div class="border rounded-3 p-3 mb-2 d-flex justify-content-between align-items-start flex-wrap gap-2"
                         data-device-row
                         data-id="<?= (int)$d['id'] ?>"
                         data-label="<?= h($d['label']) ?>"
                         data-staff-id="<?= (int)$d['staff_profile_id'] ?>"
                         data-staff-label="<?= h($staffLabel) ?>"
                         data-phone="<?= h($d['phone_number']) ?>"
                         data-status="<?= h($d['status']) ?>"
                         data-is-default="<?= (int)$d['is_default'] ?>">
                        <div>
                            <div class="fw-semibold">
                                <?= h($d['label']) ?>
                                <?php if ((int)$d['is_default'] === 1): ?>
                                    <span class="badge text-bg-primary ms-1">Default</span>
                                <?php endif; ?>
                                <?php if ($d['status'] === 'inactive'): ?>
                                    <span class="badge text-bg-secondary ms-1">Inactive</span>
                                <?php endif; ?>
                            </div>
                            <div class="text-muted small">
                                <?= $staffLabel !== '' ? h($staffLabel) : '<span class="fst-italic">Not assigned to a staff member</span>' ?>
                                <?php if (!empty($d['phone_number'])): ?> · <?= h($d['phone_number']) ?><?php endif; ?>
                            </div>
                            <div class="text-muted small">Last polled: <?= h($lastSeen) ?></div>
                            <div class="input-group input-group-sm mt-2" style="max-width: 420px;">
                                <span class="input-group-text">Token</span>
                                <input type="text" class="form-control font-monospace" readonly value="<?= h($d['token']) ?>" onclick="this.select()">
                            </div>
                        </div>
                        <div class="d-flex flex-column gap-1">
                            <button type="button" class="btn btn-sm btn-outline-primary" data-edit-device>Edit</button>
                            <form method="post" action="<?= htmlspecialchars(route_url('settings/smsDevices'), ENT_QUOTES, 'UTF-8') ?>" onsubmit="return confirm('Regenerate this device\'s token? The app on that phone will need updating with the new token or it will stop working.');">
                                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                <input type="hidden" name="route" value="settings/smsDevices">
                                <input type="hidden" name="form_action" value="regenerate_token">
                                <input type="hidden" name="device_id" value="<?= (int)$d['id'] ?>">
                                <button class="btn btn-sm btn-outline-warning w-100" type="submit">Regenerate Token</button>
                            </form>
                            <?php if ((int)$d['is_default'] !== 1): ?>
                                <form method="post" action="<?= htmlspecialchars(route_url('settings/smsDevices'), ENT_QUOTES, 'UTF-8') ?>" onsubmit="return confirm('Remove this device? Any personal messages queued for it will just wait for the default device instead.');">
                                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                    <input type="hidden" name="route" value="settings/smsDevices">
                                    <input type="hidden" name="form_action" value="delete">
                                    <input type="hidden" name="device_id" value="<?= (int)$d['id'] ?>">
                                    <button class="btn btn-sm btn-outline-danger w-100" type="submit">Delete</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<style>
.combo { position: relative; }
.combo-menu {
    position: absolute;
    left: 0;
    right: 0;
    z-index: 40;
    max-height: 420px; /* comfortably fits the 10 results the server now returns */
    overflow-y: auto;
    display: none;
}
</style>

<script>
(function () {
    var SEARCH_URL = <?= json_encode($staffSearchUrl, JSON_UNESCAPED_SLASHES) ?>;

    function escapeHtml(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    function initCombo(root) {
        var input = root.querySelector('.combo-input');
        var hidden = root.querySelector('input[type=hidden]');
        var menu = root.querySelector('.combo-menu');
        var debounceTimer = null;
        var requestSeq = 0;

        function renderMatches(matches) {
            menu.innerHTML = '';
            if (matches.length === 0) {
                var empty = document.createElement('div');
                empty.className = 'list-group-item text-muted small';
                empty.textContent = 'No matches';
                menu.appendChild(empty);
            }
            matches.forEach(function (item) {
                var a = document.createElement('a');
                a.href = '#';
                a.className = 'list-group-item list-group-item-action py-1 px-2';
                a.innerHTML = '<div>' + escapeHtml(item.label) + '</div>' +
                    (item.sub ? '<div class="text-muted small">' + escapeHtml(item.sub) + '</div>' : '');
                a.addEventListener('mousedown', function (e) {
                    e.preventDefault();
                    hidden.value = item.id;
                    input.value = item.label;
                    menu.style.display = 'none';
                });
                menu.appendChild(a);
            });
            menu.style.display = 'block';
        }

        function search(filter) {
            var seq = ++requestSeq;
            var url = SEARCH_URL + '&q=' + encodeURIComponent(filter || '');
            fetch(url, { credentials: 'same-origin' })
                .then(function (res) { return res.json(); })
                .then(function (matches) {
                    if (seq !== requestSeq) { return; }
                    renderMatches(matches);
                })
                .catch(function () {
                    if (seq !== requestSeq) { return; }
                    menu.innerHTML = '<div class="list-group-item text-danger small">Search failed — try again</div>';
                    menu.style.display = 'block';
                });
        }

        input.addEventListener('focus', function () { search(input.value); });
        input.addEventListener('input', function () {
            hidden.value = 0;
            clearTimeout(debounceTimer);
            var value = input.value;
            debounceTimer = setTimeout(function () { search(value); }, 250);
        });
        input.addEventListener('blur', function () {
            setTimeout(function () { menu.style.display = 'none'; }, 150);
        });
    }

    document.querySelectorAll('[data-combo-type="staff"]').forEach(function (el) { initCombo(el); });

    // Edit-device: fill the form on the left from the clicked row's data-* attributes.
    var form = document.getElementById('deviceForm');
    var titleEl = document.getElementById('deviceFormTitle');
    var cancelBtn = document.getElementById('deviceFormCancel');

    function resetForm() {
        form.reset();
        document.getElementById('device_id').value = '0';
        document.getElementById('device_staff_id').value = '0';
        document.getElementById('device_staff_input').value = '';
        titleEl.textContent = 'Add a Device';
        cancelBtn.classList.add('d-none');
    }

    document.querySelectorAll('[data-edit-device]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var row = btn.closest('[data-device-row]');
            document.getElementById('device_id').value = row.dataset.id;
            document.getElementById('device_label').value = row.dataset.label;
            document.getElementById('device_staff_id').value = row.dataset.staffId;
            document.getElementById('device_staff_input').value = row.dataset.staffLabel;
            document.getElementById('device_phone').value = row.dataset.phone;
            document.getElementById('device_status').value = row.dataset.status;
            document.getElementById('device_is_default').checked = row.dataset.isDefault === '1';
            titleEl.textContent = 'Edit "' + row.dataset.label + '"';
            cancelBtn.classList.remove('d-none');
            form.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    });

    cancelBtn.addEventListener('click', resetForm);
})();
</script>
