<?php ?>

<div class="mb-3">
    <h1 class="h4 mb-0">Settings</h1>
    <div class="text-muted">Global settings, institute info, labels, data reset, backup/restore.</div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <div class="d-flex align-items-start gap-3">
            <i class="bi bi-info-circle fs-4 text-muted"></i>
            <div>
                <div class="fw-semibold mb-1">View-only access</div>
                <div class="text-muted small">
                    Your account can see that Settings exists, but changing any setting
                    requires the "Settings manage" permission. Ask an administrator to grant
                    it from Users &amp; Roles if you need to make changes here.
                </div>
            </div>
        </div>
    </div>
</div>
