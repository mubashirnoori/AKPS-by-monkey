<?php
// Variables: error
$routeBase = base_url('/index.php?route=settings/backup');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Backup & Restore</h1>
        <div class="text-muted">Export SQL and restore from SQL.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=settings/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="row g-3">
    <div class="col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Backup (Export SQL)</h2>
                <a class="btn btn-primary" href="<?= htmlspecialchars($routeBase . '&download=sql&dl_token=' . urlencode(download_token()), ENT_QUOTES, 'UTF-8') ?>">Download SQL Backup</a>
                <div class="text-muted small mt-2">This exports schema + data from the configured database.</div>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Restore (Import SQL)</h2>
                <form method="post" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <div class="mb-3">
                        <label class="form-label">SQL File</label>
                        <input class="form-control" type="file" name="sql_file" accept=".sql,text/plain" required>
                    </div>
                    <button class="btn btn-danger" type="submit" onclick="return confirm('Restore will run SQL statements and may overwrite tables. Continue?')">Restore Database</button>
                </form>
            </div>
        </div>
    </div>
</div>

