<?php
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Clean Data</h1>
        <div class="text-muted">Reset specific modules without deleting the system.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=settings/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <div class="alert alert-warning">
            These actions delete module data. Use Backup first.
        </div>

        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=settings/cleanData'), ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
            <div class="col-md-6">
                <label class="form-label">Module</label>
                <select class="form-select" name="module" required>
                    <option value="attendance">Attendance (students + staff)</option>
                    <option value="marks">Marks</option>
                    <option value="fees">Fees (invoices + collections)</option>
                    <option value="inquiries">Inquiries</option>
                    <option value="complaints">Complaints</option>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Type <strong>DELETE</strong> to confirm</label>
                <input class="form-control" type="text" name="confirm_text" id="cleanDataConfirmText" autocomplete="off" placeholder="DELETE">
            </div>
            <div class="col-12 d-grid">
                <button class="btn btn-danger" type="submit" id="cleanDataSubmitBtn" disabled>Clean Data — this cannot be undone</button>
            </div>
        </form>
    </div>
</div>

<script>
(function () {
    var input = document.getElementById('cleanDataConfirmText');
    var btn = document.getElementById('cleanDataSubmitBtn');
    if (!input || !btn) { return; }
    input.addEventListener('input', function () {
        btn.disabled = input.value.trim() !== 'DELETE';
    });
})();
</script>

