<?php
// Variables: settings
$settings = $settings ?? [];
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Institute Info</h1>
        <div class="text-muted">Update institute name and contact details.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=settings/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=settings/institute'), ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">

            <div class="mb-3">
                <label class="form-label">Institute Name</label>
                <input class="form-control" name="institute_name" value="<?= h($settings['institute_name'] ?? 'SchoolSMS Institute') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Contact</label>
                <input class="form-control" name="institute_contact" value="<?= h($settings['institute_contact'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Address</label>
                <textarea class="form-control" name="institute_address" rows="3"><?= h($settings['institute_address'] ?? '') ?></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Policies</label>
                <textarea class="form-control" name="institute_policies" rows="4"><?= h($settings['institute_policies'] ?? '') ?></textarea>
            </div>

            <button class="btn btn-primary" type="submit">Save</button>
        </form>
    </div>
</div>

