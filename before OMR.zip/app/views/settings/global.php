<?php
// Variables: settings, years
$settings = $settings ?? [];
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Global Settings</h1>
        <div class="text-muted">System-wide preferences.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=settings/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=settings/global'), ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">

            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Timezone</label>
                    <input class="form-control" name="app_timezone" value="<?= h($settings['app_timezone'] ?? 'UTC') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Currency</label>
                    <input class="form-control" name="currency" value="<?= h($settings['currency'] ?? 'BDT') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Date Format</label>
                    <input class="form-control" name="date_format" value="<?= h($settings['date_format'] ?? 'Y-m-d') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Active Academic Year (label)</label>
                    <input class="form-control" name="academic_year_active" value="<?= h($settings['academic_year_active'] ?? '') ?>" placeholder="e.g. 2025-2026">
                    <div class="form-text">Reference label only (UI); the active flag is managed in Academic Years.</div>
                </div>
                <div class="col-12">
                    <label class="form-label">Holidays</label>
                    <!-- Still saved as comma-separated Y-m-d dates in settings.holidays, so
                         every report/attendance page that reads it keeps working unchanged. -->
                    <input type="hidden" name="holidays" id="holidaysInput" value="<?= h($settings['holidays'] ?? '') ?>">
                    <div id="holidayCal" class="hcal">
                        <div class="hcal__cal">
                            <div class="hcal__head">
                                <button type="button" class="hcal__nav" data-nav="-1" aria-label="Previous month"><i class="bi bi-chevron-left"></i></button>
                                <strong id="hcalTitle"></strong>
                                <button type="button" class="hcal__nav" data-nav="1" aria-label="Next month"><i class="bi bi-chevron-right"></i></button>
                            </div>
                            <div class="hcal__grid" id="hcalGrid"></div>
                            <div class="hcal__legend">
                                <span><i class="hcal__dot hcal__dot--hol"></i> Holiday</span>
                                <span><i class="hcal__dot hcal__dot--today"></i> Today</span>
                                <span class="ms-auto">Click a day to mark / unmark</span>
                            </div>
                        </div>
                        <div class="hcal__list">
                            <div class="d-flex align-items-center justify-content-between mb-2">
                                <strong id="hcalCount"></strong>
                                <button type="button" class="hcal__clear" id="hcalClear">Clear all</button>
                            </div>
                            <div class="hcal__filters">
                                <select id="hcalYear" class="form-select form-select-sm" aria-label="Year"></select>
                                <select id="hcalMonth" class="form-select form-select-sm" aria-label="Month"></select>
                            </div>
                            <div id="hcalChips" class="hcal__chips"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-3">
                <button class="btn btn-primary" type="submit">Save</button>
            </div>
        </form>
    </div>
</div>

<style>
    .hcal { display: grid; grid-template-columns: minmax(280px, 380px) 1fr; gap: 1.25rem; background: var(--sms-input-bg, #161d27); border: 1px solid var(--sms-border, #37455c); border-radius: .75rem; padding: 1rem; }
    @media (max-width: 767px) { .hcal { grid-template-columns: 1fr; } }
    .hcal__head { display: flex; align-items: center; justify-content: space-between; margin-bottom: .6rem; color: var(--sms-heading, #f4eee0); }
    .hcal__nav { width: 2rem; height: 2rem; border: 1px solid var(--sms-border, #37455c); border-radius: .5rem; background: transparent; color: var(--sms-text, #e6e1d3); line-height: 1; }
    .hcal__nav:hover { border-color: var(--sms-primary, #b8873e); color: var(--sms-primary, #b8873e); }
    .hcal__grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; text-align: center; }
    .hcal__dow { font-size: .7rem; letter-spacing: .04em; text-transform: uppercase; color: var(--sms-muted, #97a2b5); padding: .2rem 0 .35rem; }
    .hcal__day { aspect-ratio: 1; border: 1px solid transparent; border-radius: .5rem; background: transparent; color: var(--sms-text, #e6e1d3); font-size: .9rem; outline: none; }
    .hcal__day:hover { background: rgba(184, 135, 62, .15); }
    .hcal__day:focus-visible { border-color: var(--sms-primary, #b8873e); }
    .hcal__day.is-sun { color: var(--sms-muted, #97a2b5); opacity: .7; }
    .hcal__day.is-today { border-color: var(--sms-primary, #b8873e); }
    .hcal__day.is-hol { background: var(--sms-margin-red, #a6352a); border-color: var(--sms-margin-red, #a6352a); color: #fff; font-weight: 600; opacity: 1; }
    .hcal__legend { display: flex; flex-wrap: wrap; gap: .9rem; margin-top: .75rem; font-size: .75rem; color: var(--sms-muted, #97a2b5); }
    .hcal__dot { display: inline-block; width: .7rem; height: .7rem; border-radius: .2rem; vertical-align: -1px; margin-right: .25rem; }
    .hcal__dot--hol { background: var(--sms-margin-red, #a6352a); }
    .hcal__dot--today { border: 2px solid var(--sms-primary, #b8873e); }
    .hcal__list { border-left: 1px solid var(--sms-border, #37455c); padding-left: 1.25rem; min-width: 0; }
    @media (max-width: 767px) { .hcal__list { border-left: 0; padding-left: 0; border-top: 1px solid var(--sms-border, #37455c); padding-top: 1rem; } }
    .hcal__list strong { color: var(--sms-heading, #f4eee0); }
    .hcal__filters { display: flex; gap: .5rem; margin-bottom: .6rem; }
    .hcal__filters .form-select { width: auto; min-width: 7rem; }
    .hcal__clear { background: none; border: 0; padding: 0; font-size: .8rem; color: var(--sms-accent-rose, #d97873); }
    .hcal__clear:hover { text-decoration: underline; }
    .hcal__chips { max-height: 290px; overflow-y: auto; padding-right: .4rem; scrollbar-width: thin; scrollbar-color: var(--sms-border, #37455c) transparent; }
    @media (max-width: 767px) { .hcal__chips { max-height: 240px; } }
    .hcal__month { font-size: .72rem; letter-spacing: .04em; text-transform: uppercase; color: var(--sms-muted, #97a2b5); margin: .6rem 0 .3rem; }
    .hcal__month:first-child { margin-top: 0; }
    .hcal__chip { display: inline-flex; align-items: center; gap: .35rem; margin: 0 .35rem .35rem 0; padding: .15rem .35rem .15rem .6rem; border: 1px solid var(--sms-border, #37455c); border-radius: 999px; font-size: .82rem; color: var(--sms-text, #e6e1d3); background: var(--sms-surface, #1a2230); }
    .hcal__chip button { border: 0; background: none; color: var(--sms-muted, #97a2b5); line-height: 1; padding: 0 .2rem; font-size: 1rem; }
    .hcal__chip button:hover { color: var(--sms-accent-rose, #d97873); }
    .hcal__empty { color: var(--sms-muted, #97a2b5); font-size: .85rem; }
</style>
<script>
(function () {
    var input = document.getElementById('holidaysInput');
    if (!input) return;
    var grid = document.getElementById('hcalGrid'), title = document.getElementById('hcalTitle'),
        count = document.getElementById('hcalCount'), chips = document.getElementById('hcalChips');
    var names = ['January','February','March','April','May','June','July','August','September','October','November','December'];
    var short = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    var days = {};
    input.value.split(',').forEach(function (d) { d = d.trim(); if (/^\d{4}-\d{2}-\d{2}$/.test(d)) days[d] = true; });
    var now = new Date(), year = now.getFullYear(), month = now.getMonth();
    function pad(n) { return (n < 10 ? '0' : '') + n; }
    var todayKey = now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate());

    var yearSel = document.getElementById('hcalYear'), monthSel = document.getElementById('hcalMonth');
    var filterMonth = month; // 'all' months is -1; defaults to the current month
    function fillSelects() {
        var ys = {}; ys[year] = true; ys[now.getFullYear()] = true;
        Object.keys(days).forEach(function (k) { ys[k.slice(0, 4)] = true; });
        var list = Object.keys(ys).map(Number).sort();
        yearSel.innerHTML = list.map(function (y) { return '<option value="' + y + '"' + (y === year ? ' selected' : '') + '>' + y + '</option>'; }).join('');
        monthSel.innerHTML = '<option value="-1"' + (filterMonth === -1 ? ' selected' : '') + '>All months</option>' +
            names.map(function (n, i) { return '<option value="' + i + '"' + (i === filterMonth ? ' selected' : '') + '>' + n + '</option>'; }).join('');
    }
    function renderList() {
        var keys = Object.keys(days).sort();
        input.value = keys.join(',');
        count.textContent = keys.length + ' holiday' + (keys.length === 1 ? '' : 's') + ' marked';
        fillSelects();
        var shown = keys.filter(function (k) {
            return parseInt(k.slice(0, 4), 10) === year && (filterMonth === -1 || parseInt(k.slice(5, 7), 10) - 1 === filterMonth);
        });
        if (!shown.length) { chips.innerHTML = '<div class="hcal__empty">No holidays ' + (filterMonth === -1 ? 'in ' + year : 'in ' + names[filterMonth] + ' ' + year) + '.</div>'; return; }
        var html = '', last = '';
        shown.forEach(function (k) {
            var y = k.slice(0, 4), m = parseInt(k.slice(5, 7), 10), d = parseInt(k.slice(8), 10), label = names[m - 1] + ' ' + y;
            if (filterMonth === -1 && label !== last) { html += '<div class="hcal__month">' + label + '</div>'; last = label; }
            html += '<span class="hcal__chip">' + d + ' ' + short[m - 1] + '<button type="button" data-rm="' + k + '" aria-label="Remove ' + k + '">&times;</button></span>';
        });
        chips.innerHTML = html;
    }
    function renderCal() {
        title.textContent = names[month] + ' ' + year;
        var html = '';
        ['Su','Mo','Tu','We','Th','Fr','Sa'].forEach(function (d) { html += '<div class="hcal__dow">' + d + '</div>'; });
        var first = new Date(year, month, 1).getDay(), total = new Date(year, month + 1, 0).getDate();
        for (var i = 0; i < first; i++) html += '<div></div>';
        for (var d = 1; d <= total; d++) {
            var key = year + '-' + pad(month + 1) + '-' + pad(d), dow = (first + d - 1) % 7;
            html += '<button type="button" class="hcal__day' + (dow === 0 ? ' is-sun' : '') + (key === todayKey ? ' is-today' : '') + (days[key] ? ' is-hol' : '') + '" data-date="' + key + '">' + d + '</button>';
        }
        grid.innerHTML = html;
    }
    grid.addEventListener('click', function (e) {
        var b = e.target.closest('[data-date]');
        if (!b) return;
        var k = b.getAttribute('data-date');
        if (days[k]) delete days[k]; else days[k] = true;
        b.classList.toggle('is-hol', !!days[k]);
        renderList();
    });
    chips.addEventListener('click', function (e) {
        var b = e.target.closest('[data-rm]');
        if (!b) return;
        delete days[b.getAttribute('data-rm')];
        renderList(); renderCal();
    });
    document.querySelectorAll('#holidayCal [data-nav]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            month += parseInt(btn.getAttribute('data-nav'), 10);
            if (month < 0) { month = 11; year--; } else if (month > 11) { month = 0; year++; }
            if (filterMonth !== -1) filterMonth = month;
            renderCal(); renderList();
        });
    });
    yearSel.addEventListener('change', function () { year = parseInt(yearSel.value, 10); renderCal(); renderList(); });
    monthSel.addEventListener('change', function () {
        filterMonth = parseInt(monthSel.value, 10);
        if (filterMonth !== -1) month = filterMonth;
        renderCal(); renderList();
    });
    document.getElementById('hcalClear').addEventListener('click', function () {
        if (!Object.keys(days).length || !confirm('Remove all marked holidays?')) return;
        days = {}; renderList(); renderCal();
    });
    renderList(); renderCal();
})();
</script>