<?php
// Variables: $notifications, $page, $perPage
$notifications = $notifications ?? [];

/** Icon per notification type — falls back to a generic bell. */
$typeIcon = static function (string $type): string {
    $map = [
        'leave_request'    => 'bi-calendar2-x',
        'leave_decision'   => 'bi-calendar2-check',
        'inquiry'          => 'bi-person-plus',
        'complaint'        => 'bi-flag',
        'fee'              => 'bi-wallet2',
        'fee_invoice'      => 'bi-receipt',
        'fee_payment'      => 'bi-wallet2',
        'result_published' => 'bi-stats-chart',
        'marks'            => 'bi-stats-chart',
        'attendance'       => 'bi-clipboard-check',
        'notice'           => 'bi-megaphone',
    ];
    return $map[$type] ?? 'bi-bell';
};
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Notifications</h1>
        <div class="text-muted small">Everything that needs your attention or has recently changed.</div>
    </div>
    <?php if (!empty($notifications)): ?>
        <form method="post" action="<?= htmlspecialchars(route_url('notifications/markAllRead'), ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
            <button type="submit" class="btn btn-outline-secondary btn-sm">Mark all as read</button>
        </form>
    <?php endif; ?>
</div>

<div class="card shadow-sm border-0">
    <div class="list-group list-group-flush">
        <?php if (empty($notifications)): ?>
            <div class="text-muted text-center py-5">
                <i class="bi bi-bell-slash" style="font-size:1.8rem;"></i>
                <div class="mt-2">Nothing here yet.</div>
            </div>
        <?php endif; ?>
        <?php foreach ($notifications as $n): ?>
            <a href="#"
               class="list-group-item list-group-item-action d-flex gap-3 align-items-start notif-row"
               data-id="<?= (int)$n['id'] ?>"
               data-link="<?= h($n['link'] ?? '') ?>"
               style="<?= empty($n['is_read']) ? 'background:rgba(184,135,62,0.10);' : '' ?>">
                <i class="bi <?= h($typeIcon((string)$n['type'])) ?> fs-5 mt-1" style="color:var(--sms-primary);"></i>
                <div class="flex-grow-1">
                    <div class="fw-semibold" style="color:var(--sms-heading);"><?= h($n['title']) ?></div>
                    <?php if (!empty($n['message'])): ?>
                        <div class="text-muted small"><?= h($n['message']) ?></div>
                    <?php endif; ?>
                    <div class="text-muted small mt-1"><?= h(date('d M Y, h:i A', strtotime((string)$n['created_at']))) ?></div>
                </div>
                <?php if (empty($n['is_read'])): ?>
                    <span class="badge rounded-pill text-bg-primary align-self-center">New</span>
                <?php endif; ?>
            </a>
        <?php endforeach; ?>
    </div>
</div>

<?php if (count($notifications) >= $perPage): ?>
    <div class="d-flex justify-content-end mt-3">
        <a class="btn btn-outline-secondary btn-sm" href="<?= h(route_url('notifications/index')) ?>&page=<?= (int)$page + 1 ?>">Older →</a>
    </div>
<?php endif; ?>

<script>
document.querySelectorAll('.notif-row').forEach(function (row) {
    row.addEventListener('click', function (e) {
        e.preventDefault();
        var id = row.getAttribute('data-id');
        var link = row.getAttribute('data-link');
        fetch(<?= json_encode(route_url('notifications/markRead')) ?>, {
            method: 'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest', 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'id=' + encodeURIComponent(id) + '&csrf_token=' + encodeURIComponent(<?= json_encode(CSRF::token()) ?>)
        }).finally(function () {
            if (link) { window.location.href = link; }
            else { row.style.background = ''; }
        });
    });
});
</script>
