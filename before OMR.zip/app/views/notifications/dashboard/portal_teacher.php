<?php
// Variables: $profile, $subjects, $classes, $attendance, $leaveRequests, $performance
$profile = $profile ?? [];
$subjects = $subjects ?? [];
$classes = $classes ?? [];
$attendance = $attendance ?? [];
$leaveRequests = $leaveRequests ?? [];
$performance = $performance ?? [];
$salaryRecent = $salaryRecent ?? [];
$salaryTotalCount = (int)($salaryTotalCount ?? 0);
$feeClasses = $feeClasses ?? [];

$presentCount = 0;
foreach ($attendance as $a) {
    if (($a['status'] ?? '') === 'present') { $presentCount++; }
}
$attTotal = count($attendance);

$totalStudents = 0;
foreach ($classes as $c) { $totalStudents += (int)($c['student_count'] ?? 0); }

$latestSalary = $salaryRecent[0] ?? null;
$latestSalaryStatus = '—';
if ($latestSalary) {
    $net = (float)($latestSalary['net_amount'] ?? 0);
    $paid = (float)($latestSalary['total_paid'] ?? 0);
    $latestSalaryStatus = 'Unpaid';
    if ($paid >= $net && $net > 0) { $latestSalaryStatus = 'Paid'; }
    elseif ($paid > 0) { $latestSalaryStatus = 'Partial'; }
}

$pendingLeaveCount = 0;
foreach ($leaveRequests as $lr) {
    if (($lr['status'] ?? '') === 'pending') { $pendingLeaveCount++; }
}

$fullName = $profile['full_name'] ?? '';
$initials = '';
foreach (preg_split('/\s+/', trim($fullName)) as $part) {
    if ($part !== '') { $initials .= strtoupper($part[0]); }
    if (strlen($initials) >= 2) { break; }
}

$photoUrl = staff_photo_url((int)($profile['id'] ?? 0));
?>

<div class="portal-hero">
    <div class="portal-hero__avatar">
        <?php if ($photoUrl): ?>
            <img src="<?= h($photoUrl) ?>" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">
        <?php else: ?>
            <?= h($initials ?: 'TC') ?>
        <?php endif; ?>
    </div>
    <div class="portal-hero__body">
        <p class="portal-hero__name"><?= $fullName !== '' ? h($fullName) : 'My Teaching Portal' ?></p>
        <div class="portal-hero__meta">
            <?= h($profile['title'] ?? '') ?>
            <?php if (!empty($profile['staff_code'])): ?> &middot; Staff #<?= h($profile['staff_code']) ?><?php endif; ?>
            <?php if (($profile['title'] ?? '') === '' && empty($profile['staff_code'])): ?>
                Showing only your assigned subjects, classes, and your own HR records.
            <?php endif; ?>
        </div>
    </div>
    <div class="portal-hero__right">
        <span class="badge text-bg-warning align-self-center"><i class="bi bi-easel2-fill me-1"></i>Teacher Portal</span>
    </div>
</div>

<div class="portal-kpis">
    <div class="portal-kpi portal-kpi--a">
        <div class="portal-kpi__label"><i class="bi bi-journal-bookmark"></i> My Subjects</div>
        <div class="portal-kpi__value"><?= count($subjects) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--c">
        <div class="portal-kpi__label"><i class="bi bi-people"></i> My Classes</div>
        <div class="portal-kpi__value"><?= count($classes) ?></div>
        <div class="portal-kpi__hint"><?= $totalStudents ?> students total</div>
    </div>
    <div class="portal-kpi portal-kpi--f">
        <div class="portal-kpi__label"><i class="bi bi-calendar-check"></i> My Attendance (30 days)</div>
        <div class="portal-kpi__value"><?= $attTotal > 0 ? round(($presentCount / $attTotal) * 100, 1) . '%' : '—' ?></div>
    </div>
    <div class="portal-kpi portal-kpi--b">
        <div class="portal-kpi__label"><i class="bi bi-cash-coin"></i> Latest Salary</div>
        <div class="portal-kpi__value"><?= h($latestSalaryStatus) ?></div>
        <div class="portal-kpi__hint"><?= $salaryTotalCount ?> month<?= $salaryTotalCount === 1 ? '' : 's' ?> on record</div>
    </div>
    <div class="portal-kpi portal-kpi--e">
        <div class="portal-kpi__label"><i class="bi bi-calendar-x"></i> Leave Requests</div>
        <div class="portal-kpi__value"><?= count($leaveRequests) ?></div>
        <div class="portal-kpi__hint"><?= $pendingLeaveCount ?> pending</div>
    </div>
    <div class="portal-kpi portal-kpi--d">
        <div class="portal-kpi__label"><i class="bi bi-pencil-square"></i> Enter Marks</div>
        <div class="portal-kpi__value" style="font-size:1rem;">
            <a class="btn btn-sm btn-primary mt-1" href="<?= htmlspecialchars(base_url('/index.php?route=academic/marksEntry'), ENT_QUOTES, 'UTF-8') ?>">Go <i class="bi bi-arrow-right"></i></a>
        </div>
    </div>
</div>

<h2 class="h6 text-muted text-uppercase mb-2" style="letter-spacing:.04em;">Quick Access</h2>
<div class="portal-quicklinks">
    <a class="portal-quicklink" href="<?= h(route_url('portal/mySubjects')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--violet"><i class="bi bi-journal-bookmark"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Subjects &amp; Classes</p>
            <p class="portal-quicklink__hint">Headcounts &amp; attendance</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <?php if (!empty($feeClasses)): ?>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myFeeClasses')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--green"><i class="bi bi-cash-coin"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">Fee Collection Classes</p>
            <p class="portal-quicklink__hint"><?= count($feeClasses) ?> class<?= count($feeClasses) === 1 ? '' : 'es' ?></p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <?php endif; ?>
    <a class="portal-quicklink" href="<?= h(route_url('portal/mySalary')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--blue"><i class="bi bi-cash-stack"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Salary</p>
            <p class="portal-quicklink__hint">Full payment history</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myPerformance')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--rose"><i class="bi bi-star"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Performance</p>
            <p class="portal-quicklink__hint"><?= count($performance) ?> report<?= count($performance) === 1 ? '' : 's' ?></p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myLeaves')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--amber"><i class="bi bi-calendar-x"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Leaves</p>
            <p class="portal-quicklink__hint">Apply &amp; view history</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
</div>
