<?php
// Variables: $stats
$fmt = static function ($n): string {
    return number_format((float)$n, 0);
};
$fees = (float)($stats['fees_collected'] ?? 0);
$exp  = (float)($stats['expenses'] ?? 0);
$otherExp = (float)($stats['other_expenses'] ?? 0);
$net  = (float)($stats['net_balance'] ?? ($fees - $exp - $otherExp));
$pending = (float)($stats['pending_dues'] ?? 0);
$totalAmount = $fees + $pending;
$students = (int)($stats['students_enrolled'] ?? 0);
$staff = (int)($stats['staff_count'] ?? 0);
$monthLabel = (string)($stats['period_label'] ?? ('Year ' . date('Y')));
?>

<div class="fo-dash">
    <div class="fo-dash__head">
        <div>
            <div class="fo-dash__eyebrow">Finance overview</div>
            <h1 class="fo-dash__title">Dashboard</h1>
            <p class="fo-dash__sub">
                Fees collected − payroll − other expenses = net balance
                · <span id="foPeriodLabel"><?= h($monthLabel) ?></span>
            </p>
        </div>
        <div class="fo-dash__actions">
            <a href="<?= h(route_url('fees/collect')) ?>">Collect fees</a>
            <a href="<?= h(route_url('fees/invoices')) ?>">Invoices</a>
            <a href="<?= h(route_url('staff/payroll')) ?>">Payroll</a>
            <a href="<?= h(route_url('expenses/index')) ?>">Other Expenses</a>
        </div>
    </div>

    <div class="fo-kpis">
        <div class="fo-kpi fo-kpi--students">
            <div class="fo-kpi__label">Active students</div>
            <div class="fo-kpi__value"><?= (int)$students ?></div>
        </div>
        <div class="fo-kpi fo-kpi--fees">
            <div class="fo-kpi__label">Fees collected <span class="fo-kpi__hint" id="foFeesHint">(period)</span></div>
            <div class="fo-kpi__value" id="foFeesValue">Rs <?= h($fmt($fees)) ?></div>
        </div>
        <div class="fo-kpi fo-kpi--payroll">
            <div class="fo-kpi__label">Payroll <span class="fo-kpi__hint" id="foPayHint">(period)</span></div>
            <div class="fo-kpi__value" id="foPayValue">Rs <?= h($fmt($exp)) ?></div>
        </div>
        <div class="fo-kpi fo-kpi--payroll">
            <div class="fo-kpi__label">Other Expenses <span class="fo-kpi__hint" id="foOtherExpHint">(<?= (int)date('Y') ?>)</span></div>
            <div class="fo-kpi__value" id="foOtherExpValue">Rs <?= h($fmt($otherExp)) ?></div>
        </div>
        <div class="fo-kpi fo-kpi--net">
            <div class="fo-kpi__label">Net balance <span class="fo-kpi__hint">(fees − payroll − other)</span></div>
            <div class="fo-kpi__value" id="foNetValue">Rs <?= h($fmt($net)) ?></div>
        </div>
        <div class="fo-kpi fo-kpi--dues">
            <div class="fo-kpi__label">Pending dues <span class="fo-kpi__hint">(all open)</span></div>
            <div class="fo-kpi__value" id="foPendingValue">Rs <?= h($fmt($pending)) ?></div>
        </div>
        <div class="fo-kpi fo-kpi--total">
            <div class="fo-kpi__label">Total amount <span class="fo-kpi__hint">(collected + pending)</span></div>
            <div class="fo-kpi__value" id="foTotalValue">Rs <?= h($fmt($totalAmount)) ?></div>
        </div>
        <div class="fo-kpi fo-kpi--staff">
            <div class="fo-kpi__label">Staff</div>
            <div class="fo-kpi__value"><?= (int)$staff ?></div>
        </div>
    </div>

    <div class="fo-chart">
        <div class="fo-chart__top">
            <div>
                <h2 class="fo-chart__title">Fees vs expenses</h2>
                <p class="fo-chart__hint" id="financeFeesSub">Year <?= (int)date('Y') ?></p>
            </div>
            <div class="fo-chart__controls">
                <div class="fo-legend">
                    <span><i class="fo-dot fo-dot--fees"></i> Fees</span>
                    <span><i class="fo-dot fo-dot--pay"></i> Payroll</span>
                </div>
                <select class="form-select form-select-sm fo-select" id="financeMode" aria-label="Mode">
                    <option value="year" selected>Year</option>
                    <option value="month">Month</option>
                </select>
                <select class="form-select form-select-sm fo-select" id="financeYear" aria-label="Year"></select>
                <select class="form-select form-select-sm fo-select" id="financeMonth" aria-label="Month" hidden>
                    <?php for ($m = 1; $m <= 12; $m++): ?>
                        <option value="<?= $m ?>" <?= (int)date('n') === $m ? 'selected' : '' ?>>
                            <?= h(date('M', mktime(0, 0, 0, $m, 1))) ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
        </div>
        <div class="fo-chart__canvas">
            <canvas id="financeChart"></canvas>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
(function () {
    const modeEl = document.getElementById('financeMode');
    const yearEl = document.getElementById('financeYear');
    const monthEl = document.getElementById('financeMonth');
    const subEl = document.getElementById('financeFeesSub');
    const periodLabelEl = document.getElementById('foPeriodLabel');
    const feesValueEl = document.getElementById('foFeesValue');
    const payValueEl = document.getElementById('foPayValue');
    const otherExpValueEl = document.getElementById('foOtherExpValue');
    const netValueEl = document.getElementById('foNetValue');
    const totalValueEl = document.getElementById('foTotalValue');
    const pendingBase = <?= json_encode($pending) ?>;
    const ctx = document.getElementById('financeChart').getContext('2d');

    function moneyRs(n) {
        return 'Rs ' + Number(n || 0).toLocaleString(undefined, { maximumFractionDigits: 0 });
    }

    const chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [
                {
                    label: 'Fees',
                    data: [],
                    backgroundColor: '#22c55e',
                    borderRadius: 8,
                    maxBarThickness: 28,
                    categoryPercentage: 0.65,
                    barPercentage: 0.9,
                },
                {
                    label: 'Payroll',
                    data: [],
                    backgroundColor: '#f43f5e',
                    borderRadius: 8,
                    maxBarThickness: 28,
                    categoryPercentage: 0.65,
                    barPercentage: 0.9,
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 400 },
            interaction: { mode: 'index', intersect: false },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { color: '#94a3b8', font: { size: 11 } }
                },
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(148,163,184,0.15)' },
                    border: { display: false },
                    ticks: {
                        color: '#94a3b8',
                        font: { size: 11 },
                        callback: (v) => {
                            if (v >= 1000) return (v / 1000) + 'k';
                            return v;
                        }
                    }
                }
            },
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#0f172a',
                    titleColor: '#e2e8f0',
                    bodyColor: '#f8fafc',
                    padding: 12,
                    callbacks: {
                        label: (c) => ' ' + c.dataset.label + ': Rs ' + Number(c.parsed.y || 0).toLocaleString()
                    }
                }
            }
        }
    });

    function buildYears() {
        const y = new Date().getFullYear();
        yearEl.innerHTML = '';
        for (let i = y - 5; i <= y; i++) {
            const o = document.createElement('option');
            o.value = String(i);
            o.textContent = String(i);
            if (i === y) o.selected = true;
            yearEl.appendChild(o);
        }
    }

    function syncMode() {
        const isMonth = modeEl.value === 'month';
        monthEl.hidden = !isMonth;
        chart.config.type = isMonth ? 'line' : 'bar';
        chart.data.datasets.forEach((ds, i) => {
            const fee = i === 0;
            if (isMonth) {
                ds.borderColor = fee ? '#22c55e' : '#f43f5e';
                ds.backgroundColor = fee ? 'rgba(34,197,94,0.15)' : 'rgba(244,63,94,0.15)';
                ds.borderWidth = 2;
                ds.tension = 0.35;
                ds.pointRadius = 3;
                ds.fill = true;
            } else {
                ds.borderWidth = 0;
                ds.backgroundColor = fee ? '#22c55e' : '#f43f5e';
                ds.fill = false;
            }
        });
        chart.update();
    }

    async function load() {
        const mode = modeEl.value;
        const year = yearEl.value;
        const month = monthEl.value;
        const url = `<?= base_url('/index.php?route=dashboard/financeData') ?>&mode=${encodeURIComponent(mode)}&year=${encodeURIComponent(year)}&month=${encodeURIComponent(month)}`;
        try {
            const res = await fetch(url, { headers: { Accept: 'application/json' } });
            const json = await res.json();
            if (!json || json.error || !Array.isArray(json.labels)) throw new Error('bad');

            // Full year always (like reference) — do not trim empty months
            chart.data.labels = json.labels;
            chart.data.datasets[0].data = json.values;
            chart.data.datasets[1].data = Array.isArray(json.expenses) ? json.expenses : json.labels.map(() => 0);

            if (mode === 'year') {
                const label = 'Year ' + json.year;
                subEl.textContent = label;
                if (periodLabelEl) periodLabelEl.textContent = label;
            } else {
                const names = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
                const label = names[(json.month || 1) - 1] + ' ' + json.year;
                subEl.textContent = label;
                if (periodLabelEl) periodLabelEl.textContent = label;
            }

            // Keep KPI cards in sync with chart period (Fees − Payroll − Other Expenses = Net)
            if (feesValueEl) feesValueEl.textContent = moneyRs(json.total);
            if (payValueEl) payValueEl.textContent = moneyRs(json.expenses_total);
            if (otherExpValueEl) otherExpValueEl.textContent = moneyRs(json.other_expenses_total);
            if (netValueEl) netValueEl.textContent = moneyRs(json.net);
            if (totalValueEl) totalValueEl.textContent = moneyRs(Number(json.total || 0) + Number(pendingBase || 0));

            chart.update();
        } catch (e) {
            console.error(e);
            subEl.textContent = 'Could not load chart';
        }
    }

    modeEl.addEventListener('change', () => { syncMode(); load(); });
    yearEl.addEventListener('change', load);
    monthEl.addEventListener('change', load);

    buildYears();
    syncMode();
    load();
})();
</script>
