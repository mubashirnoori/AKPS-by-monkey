<?php
// Variables: $subjects, $classes, $classTeacherSectionIds, $feeClasses
$subjects = $subjects ?? [];
$classes = $classes ?? [];
$classTeacherSectionIds = $classTeacherSectionIds ?? [];
$feeClasses = $feeClasses ?? [];
?>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">My Subjects &amp; Classes</h1>
        <div class="text-muted">Everything you teach, at a glance.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=portal/index'), ENT_QUOTES, 'UTF-8') ?>">Back to Portal</a>
</div>

<div class="card shadow-sm border-0 portal-section">
    <div class="card-body">
        <div class="portal-section__head">
            <div class="portal-section__icon portal-section__icon--violet"><i class="bi bi-journal-bookmark"></i></div>
            <p class="portal-section__title mb-0">My Subjects &amp; Classes</p>
        </div>
        <?php if (empty($subjects)): ?>
            <div class="portal-empty"><i class="bi bi-journal-bookmark"></i>No subjects assigned yet. Ask an admin.</div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-sm table-hover mb-0">
                <thead><tr><th>Subject</th><th>Class</th></tr></thead>
                <tbody>
                <?php foreach ($subjects as $s): ?>
                    <tr>
                        <td><?= h($s['subject_name'] ?? '') ?></td>
                        <td class="text-muted"><?= h($s['class_name'] ?? '—') ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class="card shadow-sm border-0 portal-section">
    <div class="card-body">
        <div class="portal-section__head">
            <div class="portal-section__icon portal-section__icon--teal"><i class="bi bi-people"></i></div>
            <p class="portal-section__title mb-0">My Classes — Headcount</p>
        </div>
        <?php if (empty($classes)): ?>
            <div class="portal-empty"><i class="bi bi-people"></i>No classes yet.</div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-sm table-hover mb-0">
                <thead><tr><th>Class</th><th>Students</th><th style="width:170px;"></th></tr></thead>
                <tbody>
                <?php foreach ($classes as $c): ?>
                    <?php $isClassTeacher = in_array((int)($c['class_section_id'] ?? 0), $classTeacherSectionIds, true); ?>
                    <tr>
                        <td><?= h(trim(($c['class_name'] ?? '') . ' ' . ($c['section_name'] ?? ''))) ?></td>
                        <td><span class="badge text-bg-secondary"><?= (int)($c['student_count'] ?? 0) ?></span></td>
                        <td class="text-end">
                            <?php if ($isClassTeacher): ?>
                                <a class="btn btn-sm btn-outline-primary" href="<?= h(route_url('portal/takeAttendance')) ?>&class_section_id=<?= (int)$c['class_section_id'] ?>">
                                    <i class="bi bi-calendar-check me-1"></i>Take Attendance
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php if (!empty($feeClasses)): ?>
<div class="card shadow-sm border-0 portal-section">
    <div class="card-body">
        <div class="portal-section__head">
            <div class="portal-section__icon portal-section__icon--green"><i class="bi bi-cash-coin"></i></div>
            <p class="portal-section__title mb-0">My Fee Collection Classes</p>
        </div>
        <div class="table-responsive">
            <table class="table table-sm table-hover mb-0">
                <thead><tr><th>Class</th><th style="width:60px;"></th></tr></thead>
                <tbody>
                <?php foreach ($feeClasses as $fc): ?>
                    <tr>
                        <td><?= h(trim(($fc['class_name'] ?? '') . ' ' . ($fc['section_name'] ?? ''))) ?></td>
                        <td>
                            <a class="btn btn-sm btn-outline-primary" title="View students &amp; collect fees" href="<?= h(route_url('portal/feeClassStudents')) ?>&class_section_id=<?= (int)$fc['id'] ?>">
                                <i class="bi bi-eye"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>
