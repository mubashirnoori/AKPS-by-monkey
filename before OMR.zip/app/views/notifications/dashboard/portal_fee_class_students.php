<?php
// Variables: $classSection, $students
$classSection = $classSection ?? [];
$students = $students ?? [];
$className = trim(($classSection['class_name'] ?? '') . ' — ' . ($classSection['section_name'] ?? ''));
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Fee Collection — <?= h($className) ?></h1>
        <div class="text-muted small">Collect, view and print fee invoices for students in this class.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= h(route_url('portal/index')) ?>">Back to Portal</a>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Student</th>
                        <th>Adm. No</th>
                        <th>Roll No</th>
                        <th>Latest Invoice</th>
                        <th class="text-end">Pending Balance</th>
                        <th style="width:260px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($students)): ?>
                    <tr><td colspan="6" class="text-muted text-center py-3">No students found in this class.</td></tr>
                <?php else: ?>
                    <?php foreach ($students as $st): ?>
                        <?php $invoice = $st['latest_invoice'] ?? null; ?>
                        <tr>
                            <td class="fw-semibold"><?= h(($st['first_name'] ?? '') . ' ' . ($st['last_name'] ?? '')) ?></td>
                            <td class="text-muted small"><?= h($st['admission_no'] ?? '') ?></td>
                            <td class="text-muted small"><?= h($st['roll_number'] ?? '—') ?></td>
                            <td class="small">
                                <?php if ($invoice): ?>
                                    <?= h($invoice['invoice_no'] ?? '') ?>
                                    <span class="badge <?= ($invoice['status'] ?? '') === 'paid' ? 'text-bg-success' : 'text-bg-warning' ?> ms-1"><?= h(ucfirst($invoice['status'] ?? '')) ?></span>
                                <?php else: ?>
                                    <span class="text-muted">No invoice</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end <?= (float)($st['pending_balance'] ?? 0) > 0 ? 'text-danger fw-semibold' : 'text-success' ?>">
                                Rs <?= number_format((float)($st['pending_balance'] ?? 0), 2) ?>
                            </td>
                            <td>
                                <?php if ($invoice): ?>
                                    <a class="btn btn-sm btn-outline-secondary" href="<?= h(route_url('portal/invoiceView')) ?>&invoice_id=<?= (int)$invoice['id'] ?>">View</a>
                                    <a class="btn btn-sm btn-success" href="<?= h(route_url('portal/feeCollect')) ?>&invoice_id=<?= (int)$invoice['id'] ?>">Collect Payment</a>
                                    <a class="btn btn-sm btn-outline-primary" href="<?= h(route_url('portal/feeInvoicePrint')) ?>&invoice_id=<?= (int)$invoice['id'] ?>" target="_blank">Print</a>
                                <?php else: ?>
                                    <span class="text-muted small">No invoice to act on</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
