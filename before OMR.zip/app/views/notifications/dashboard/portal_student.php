<?php
// Variables: $profile, $attendance, $results, $pendingResultsCount, $invoices, $courses, $timetable, $leaveRequests
$profile = $profile ?? [];
$attendance = $attendance ?? [];
$results = $results ?? [];
$pendingResultsCount = $pendingResultsCount ?? 0;
$invoices = $invoices ?? [];
$courses = $courses ?? [];
$timetable = $timetable ?? [];
$leaveRequests = $leaveRequests ?? [];

$fullName = trim(($profile['first_name'] ?? '') . ' ' . ($profile['last_name'] ?? ''));
$initials = '';
foreach ([$profile['first_name'] ?? '', $profile['last_name'] ?? ''] as $part) {
    if ($part !== '') { $initials .= strtoupper($part[0]); }
}

$photoUrl = student_photo_url((int)($profile['id'] ?? 0));

$pendingFeeTotal = 0.0;
foreach ($invoices as $inv) {
    $pendingFeeTotal += max((float)($inv['total_due'] ?? 0) - (float)($inv['collected_amount'] ?? 0), 0);
}

$pendingLeaveCount = 0;
foreach ($leaveRequests as $lr) {
    if (($lr['status'] ?? '') === 'pending') { $pendingLeaveCount++; }
}
?>

<div class="portal-hero">
    <div class="portal-hero__avatar">
        <?php if ($photoUrl): ?>
            <img src="<?= h($photoUrl) ?>" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">
        <?php else: ?>
            <?= h($initials ?: 'ST') ?>
        <?php endif; ?>
    </div>
    <div class="portal-hero__body">
        <p class="portal-hero__name">Welcome, <?= h($fullName) ?></p>
        <div class="portal-hero__meta">
            <?= h(trim(($profile['current_class_name'] ?? '') . ' ' . ($profile['current_section_name'] ?? ''))) ?>
            &middot; Admission #<?= h($profile['admission_no'] ?? '') ?>
            <?php if (!empty($profile['roll_number'])): ?> &middot; Roll #<?= h($profile['roll_number']) ?><?php endif; ?>
        </div>
    </div>
    <div class="portal-hero__right">
        <span class="badge text-bg-primary align-self-center"><i class="bi bi-mortarboard-fill me-1"></i>Student Portal</span>
    </div>
</div>

<?php if ($pendingResultsCount > 0): ?>
    <div class="alert alert-info d-flex align-items-center gap-2 mb-3">
        <i class="bi bi-hourglass-split fs-5"></i>
        <div>
            <?= $pendingResultsCount ?> exam<?= $pendingResultsCount > 1 ? 's' : '' ?> awaiting official result announcement.
            Marks will appear here as soon as the school publishes them.
        </div>
    </div>
<?php endif; ?>

<div class="portal-kpis">
    <div class="portal-kpi portal-kpi--c">
        <div class="portal-kpi__label"><i class="bi bi-calendar-check"></i> Attendance (30 days)</div>
        <div class="portal-kpi__value"><?= $attendance['percentage'] !== null ? h($attendance['percentage']) . '%' : '—' ?></div>
        <div class="portal-kpi__hint"><?= (int)($attendance['present'] ?? 0) ?> present / <?= (int)($attendance['total'] ?? 0) ?> days</div>
    </div>
    <div class="portal-kpi portal-kpi--d">
        <div class="portal-kpi__label"><i class="bi bi-cash-coin"></i> Pending Fees</div>
        <div class="portal-kpi__value">Rs <?= number_format($pendingFeeTotal, 0) ?></div>
        <div class="portal-kpi__hint"><?= count($invoices) ?> invoice<?= count($invoices) === 1 ? '' : 's' ?> total</div>
    </div>
    <div class="portal-kpi portal-kpi--a">
        <div class="portal-kpi__label"><i class="bi bi-clipboard-data"></i> Published Results</div>
        <div class="portal-kpi__value"><?= count($results) ?></div>
        <div class="portal-kpi__hint"><?= $pendingResultsCount > 0 ? $pendingResultsCount . ' pending' : 'all announced' ?></div>
    </div>
    <div class="portal-kpi portal-kpi--f">
        <div class="portal-kpi__label"><i class="bi bi-play-btn"></i> My Courses</div>
        <div class="portal-kpi__value"><?= count($courses) ?></div>
        <div class="portal-kpi__hint">assigned to you</div>
    </div>
    <div class="portal-kpi portal-kpi--e">
        <div class="portal-kpi__label"><i class="bi bi-calendar-x"></i> Leave Requests</div>
        <div class="portal-kpi__value"><?= count($leaveRequests) ?></div>
        <div class="portal-kpi__hint"><?= $pendingLeaveCount ?> pending</div>
    </div>
</div>

<h2 class="h6 text-muted text-uppercase mb-2" style="letter-spacing:.04em;">Quick Access</h2>
<div class="portal-quicklinks">
    <a class="portal-quicklink" href="<?= h(route_url('portal/myResults')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--violet"><i class="bi bi-clipboard-data"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Results</p>
            <p class="portal-quicklink__hint">Announced exam scores</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myReportCard')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--violet"><i class="bi bi-file-earmark-text"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Report Card</p>
            <p class="portal-quicklink__hint">Printable official report card</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myTimetable')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--teal"><i class="bi bi-calendar-week"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Timetable</p>
            <p class="portal-quicklink__hint">Weekly class schedule</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myFees')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--green"><i class="bi bi-receipt"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Fees</p>
            <p class="portal-quicklink__hint">Invoices &amp; payments</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myCourses')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--rose"><i class="bi bi-play-btn"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Courses</p>
            <p class="portal-quicklink__hint">Online course library</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
    <a class="portal-quicklink" href="<?= h(route_url('portal/myLeaves')) ?>">
        <div class="portal-quicklink__icon portal-quicklink__icon--amber"><i class="bi bi-calendar-x"></i></div>
        <div class="portal-quicklink__body">
            <p class="portal-quicklink__title">My Leaves</p>
            <p class="portal-quicklink__hint">Apply &amp; view history</p>
        </div>
        <i class="bi bi-chevron-right portal-quicklink__arrow"></i>
    </a>
</div>
