<?php
// Variables: $error, $classSections, $recent
$classSections = $classSections ?? [];
$recent = $recent ?? [];

$audienceLabels = [
    'everyone' => 'Everyone (staff + parents + students)',
    'staff'    => 'Staff only',
    'parents'  => 'Parents / guardians only',
    'students' => 'Students only',
    'class'    => 'A specific class',
];
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Announcements</h1>
        <div class="text-muted">Send a notice to the bell icon, plus push / SMS / email — whichever channels are turned on under Settings &gt; Notifications.</div>
    </div>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="row g-3">
    <div class="col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-header fw-semibold">New Announcement</div>
            <div class="card-body">
                <form method="post" action="<?= htmlspecialchars(route_url('notifications/announcements'), ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">

                    <div class="mb-3">
                        <label class="form-label">Title</label>
                        <input class="form-control" name="title" maxlength="150" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Message</label>
                        <textarea class="form-control" name="message" rows="4" maxlength="1000" required></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Send to</label>
                        <select class="form-select" name="audience" id="announceAudience" onchange="document.getElementById('announceClassPicker').style.display = this.value === 'class' ? '' : 'none';">
                            <option value="">Choose...</option>
                            <?php foreach ($audienceLabels as $val => $label): ?>
                                <option value="<?= h($val) ?>"><?= h($label) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3" id="announceClassPicker" style="display:none;">
                        <label class="form-label">Class / Section</label>
                        <select class="form-select" name="class_section_id">
                            <option value="">Choose...</option>
                            <?php foreach ($classSections as $cs): ?>
                                <option value="<?= (int)$cs['id'] ?>"><?= h($cs['class_name'] . ' ' . $cs['section_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="text-muted small mb-3">
                        Every recipient gets it in their notification bell right away. Which of Push / SMS / Email
                        also fire is controlled under
                        <a href="<?= htmlspecialchars(route_url('settings/notifications'), ENT_QUOTES, 'UTF-8') ?>">Settings &gt; Notifications</a>
                        — SMS and email use each recipient's registered phone number / email on file.
                    </div>

                    <button class="btn btn-primary" type="submit">Send Announcement</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card shadow-sm border-0">
            <div class="card-header fw-semibold">Recently Sent</div>
            <div class="card-body p-0" id="announcementListContainer">
                <?= $this->renderPartial('notifications/_announcement_list', [
                    'recent' => $recent,
                    'audienceLabels' => $audienceLabels,
                ]) ?>
            </div>
        </div>
    </div>
</div>
