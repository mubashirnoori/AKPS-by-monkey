<?php
// Variables: $recent, $audienceLabels
$recent = $recent ?? [];
$audienceLabels = $audienceLabels ?? [];
?>
<div class="table-responsive">
    <table class="table table-sm table-striped mb-0">
        <thead>
            <tr>
                <th>Title</th>
                <th>Audience</th>
                <th>Recipients</th>
                <th>Push</th>
                <th>SMS</th>
                <th>Email</th>
                <th>Sent</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($recent as $a): ?>
            <?php
            $audienceText = $audienceLabels[$a['audience']] ?? h($a['audience']);
            if ($a['audience'] === 'class' && !empty($a['class_name'])) {
                $audienceText = h($a['class_name'] . ' ' . $a['section_name']);
            }
            ?>
            <tr>
                <td class="fw-semibold"><?= h($a['title']) ?></td>
                <td class="text-muted small"><?= $audienceText ?></td>
                <td><?= (int)$a['recipient_count'] ?></td>
                <td><?= (int)$a['push_sent_count'] ?></td>
                <td><?= (int)($a['sms_sent_count'] ?? 0) ?></td>
                <td><?= (int)($a['email_sent_count'] ?? 0) ?></td>
                <td class="text-muted small"><?= h($a['created_at']) ?></td>
                <td class="text-end">
                    <form method="post" action="<?= h(route_url('notifications/announcementDelete')) ?>"
                          data-ajax data-target="#announcementListContainer"
                          data-confirm="Delete the announcement &quot;<?= h(addslashes($a['title'])) ?>&quot;? This only removes it from this history list — it won't unsend or recall it." class="d-inline">
                        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                        <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                        <button class="btn btn-sm btn-outline-danger" type="submit" title="Delete">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($recent)): ?>
            <tr><td colspan="8" class="text-muted">No announcements sent yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
