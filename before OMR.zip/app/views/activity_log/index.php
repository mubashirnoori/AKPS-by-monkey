<?php
// Variables: logs, total, page, perPage, roles, filters
$logs = $logs ?? [];
$roles = $roles ?? [];
$filters = $filters ?? ['q' => '', 'role' => '', 'date_from' => '', 'date_to' => ''];
$totalPages = max(1, (int)ceil(($total ?? 0) / max(1, $perPage ?? 30)));
$page = $page ?? 1;
?>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">Activity Log</h1>
        <div class="text-muted">Who did what, and when — across the whole system.</div>
    </div>
    <a class="btn btn-primary" href="<?= h(base_url('/index.php?route=' . rawurlencode('activityLog/exportCsv') . '&' . http_build_query($filters + ['dl_token' => download_token()]))) ?>">
        <i class="bi bi-download me-1"></i> Export CSV
    </a>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= h(base_url('/index.php')) ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="activityLog/index">
            <div class="col-md-4">
                <label class="form-label small fw-semibold">Search</label>
                <input type="text" class="form-control" name="q" value="<?= h($filters['q']) ?>" placeholder="Username, action, or description">
            </div>
            <div class="col-md-2">
                <label class="form-label small fw-semibold">Role</label>
                <select class="form-select" name="role">
                    <option value="">All roles</option>
                    <?php foreach ($roles as $r): ?>
                        <option value="<?= h($r['role_name']) ?>" <?= $filters['role'] === $r['role_name'] ? 'selected' : '' ?>><?= h($r['role_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label small fw-semibold">From</label>
                <input type="date" class="form-control" name="date_from" value="<?= h($filters['date_from']) ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label small fw-semibold">To</label>
                <input type="date" class="form-control" name="date_to" value="<?= h($filters['date_to']) ?>">
            </div>
            <div class="col-md-2 d-flex gap-2">
                <button type="submit" class="btn btn-outline-primary flex-fill">Filter</button>
                <a class="btn btn-outline-secondary" href="<?= h(base_url('/index.php?route=' . rawurlencode('activityLog/index'))) ?>">Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="table-responsive">
        <table class="table table-sm table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th style="width:170px;">Date / Time</th>
                    <th>Staff</th>
                    <th style="width:120px;">Role</th>
                    <th>Activity</th>
                    <th style="width:120px;">IP</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($logs)): ?>
                <tr><td colspan="5" class="text-muted text-center py-4">No activity recorded yet<?= ($filters['q'] || $filters['role'] || $filters['date_from'] || $filters['date_to']) ? ' for this filter.' : '.' ?></td></tr>
            <?php else: ?>
                <?php foreach ($logs as $log): ?>
                    <tr>
                        <td class="text-muted small"><?= h(date('d M Y, h:i A', strtotime((string)$log['created_at']))) ?></td>
                        <td class="fw-semibold"><?= h($log['username'] ?? '—') ?></td>
                        <td><span class="badge bg-secondary-subtle text-secondary"><?= h($log['role_name'] ?? '—') ?></span></td>
                        <td>
                            <div><?= h($log['description'] ?? '') ?></div>
                            <div class="text-muted small font-monospace"><?= h($log['action'] ?? '') ?></div>
                        </td>
                        <td class="text-muted small"><?= h($log['ip_address'] ?? '—') ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($totalPages > 1): ?>
<?php
    // Windowed pagination: always show first/last + a few pages around the
    // current one, with "…" gaps — instead of every page number in a row,
    // which overflowed the screen once there were more than ~15 pages.
    $window = 2;
    $pagesToShow = [1, $totalPages];
    for ($p = $page - $window; $p <= $page + $window; $p++) {
        if ($p >= 1 && $p <= $totalPages) {
            $pagesToShow[] = $p;
        }
    }
    $pagesToShow = array_unique($pagesToShow);
    sort($pagesToShow);

    $pageUrl = static function (int $p) use ($filters): string {
        return base_url('/index.php?' . http_build_query(array_merge(['route' => 'activityLog/index'], $filters, ['page' => $p])));
    };
?>
<nav class="mt-3">
    <ul class="pagination pagination-sm justify-content-center flex-wrap">
        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
            <a class="page-link" href="<?= h($pageUrl(max(1, $page - 1))) ?>">&laquo; Prev</a>
        </li>
        <?php $prev = 0; ?>
        <?php foreach ($pagesToShow as $p): ?>
            <?php if ($prev !== 0 && $p - $prev > 1): ?>
                <li class="page-item disabled"><span class="page-link">&hellip;</span></li>
            <?php endif; ?>
            <li class="page-item <?= $p === (int)$page ? 'active' : '' ?>">
                <a class="page-link" href="<?= h($pageUrl($p)) ?>"><?= $p ?></a>
            </li>
            <?php $prev = $p; ?>
        <?php endforeach; ?>
        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
            <a class="page-link" href="<?= h($pageUrl(min($totalPages, $page + 1))) ?>">Next &raquo;</a>
        </li>
    </ul>
</nav>
<?php endif; ?>
