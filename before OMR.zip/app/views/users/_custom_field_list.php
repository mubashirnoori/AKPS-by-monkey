<?php
// Variables: $fields, $scope
$fields = $fields ?? [];
$scope = $scope ?? 'user';
?>
<div class="table-responsive">
    <table class="table table-sm table-striped mb-0">
        <thead>
            <tr>
                <th>Key</th>
                <th>Label</th>
                <th>Type</th>
                <th>Required</th>
                <th style="width: 120px;">Delete</th>
            </tr>
        </thead>
        <tbody>
        <?php if (empty($fields)): ?>
            <tr><td colspan="5" class="text-muted">No fields yet.</td></tr>
        <?php else: ?>
            <?php foreach ($fields as $f): ?>
                <tr>
                    <td class="fw-semibold"><?= h($f['field_key'] ?? '') ?></td>
                    <td><?= h($f['label_text'] ?? '') ?></td>
                    <td class="text-muted small"><?= h($f['field_type'] ?? '') ?></td>
                    <td><?= !empty($f['is_required']) ? '<span class="badge text-bg-primary">Yes</span>' : '<span class="badge text-bg-secondary">No</span>' ?></td>
                    <td>
                        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=users/customFields&scope=' . $scope), ENT_QUOTES, 'UTF-8') ?>"
                              data-ajax data-target="#customFieldListContainer" data-confirm="Delete field?">
                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= (int)($f['id'] ?? 0) ?>">
                            <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
