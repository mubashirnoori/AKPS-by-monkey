<?php
// Variables: roles,userToEdit,editId,error,users,q,roleFilter,statusFilter,page,perPage,total
$userToEdit = $userToEdit ?? null;
$roles = $roles ?? [];
$totalPages = max(1, (int)ceil(((int)$total) / (int)$perPage));
$routeBase = base_url('/index.php?route=users/users');

// --- Searchable "Link to Record" combo boxes ---
// These search the database live (see UsersController::linkSearchAction)
// instead of preloading every student/staff/guardian into the page, so they
// keep working correctly no matter how many thousand records the school has.
$linkedStudentId = (int)($linkedStudentId ?? 0);
$linkedStaffId = (int)($linkedStaffId ?? 0);
$linkedGuardianId = (int)($linkedGuardianId ?? 0);
$linkedParentStudentId = (int)($linkedParentStudentId ?? 0);
$linkedParentStudentLabel = $linkedParentStudentLabel ?? '';
$linkedStudentLabel = $linkedStudentLabel ?? '';
$linkedStaffLabel = $linkedStaffLabel ?? '';
$linkedGuardianLabel = $linkedGuardianLabel ?? '';
$linkSearchUrl = base_url('/index.php?route=users/linkSearch') . '&edit_id=' . (int)($userToEdit['id'] ?? 0);
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">User Management</h1>
        <div class="text-muted">Create accounts, manage roles and permissions access.</div>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-outline-primary" type="button" data-bs-toggle="modal" data-bs-target="#bulkGenerateModal">
            <i class="bi bi-person-plus me-1"></i>Generate Missing Logins
        </button>
        <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=users/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
    </div>
</div>

<div class="modal fade" id="bulkGenerateModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="post" action="<?= h(route_url('users/bulkGenerate')) ?>">
                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                <div class="modal-header">
                    <h5 class="modal-title">Generate Missing Logins</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="text-muted small">Creates a login (username + auto-generated password), with the matching role, for every record below that doesn't already have one. You'll get a one-time list of the new usernames/passwords to share with them.</p>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" name="include_students" id="bg_students" value="1" checked>
                        <label class="form-check-label" for="bg_students">Students without a login <span class="text-muted">(role: Student)</span></label>
                    </div>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" name="include_staff" id="bg_staff" value="1" checked>
                        <label class="form-check-label" for="bg_staff">Staff without a login <span class="text-muted">(role: Teacher)</span></label>
                    </div>
                    <div class="form-check mb-1">
                        <input class="form-check-input" type="checkbox" name="include_guardians" id="bg_guardians" value="1" checked>
                        <label class="form-check-label" for="bg_guardians">Guardians without a login <span class="text-muted">(role: Parent)</span></label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Generate</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>


<div class="card shadow-sm border-0 mb-3 sms-overflow-visible">
    <div class="card-body">
        <h2 class="h6 mb-3"><?= $userToEdit ? 'Edit User' : 'Create New User' ?></h2>
        <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=users/users'), ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
            <input type="hidden" name="id" value="<?= $userToEdit ? (int)$userToEdit['id'] : '' ?>">

            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Username *</label>
                    <input class="form-control" name="username" value="<?= h($userToEdit['username'] ?? '') ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Email</label>
                    <input class="form-control" name="email" value="<?= h($userToEdit['email'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Role *</label>
                    <select class="form-select" name="role_id" required>
                        <?php foreach ($roles as $r): ?>
                            <?php $selected = $userToEdit && (int)($userToEdit['role_id'] ?? 0) === (int)$r['id']; ?>
                            <option value="<?= (int)$r['id'] ?>" <?= $selected ? 'selected' : '' ?>><?= h($r['name'] ?? '') ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Status</label>
                    <select class="form-select" name="status">
                        <option value="1" <?= (!$userToEdit || (int)($userToEdit['status'] ?? 1) === 1) ? 'selected' : '' ?>>Active</option>
                        <option value="0" <?= ($userToEdit && (int)($userToEdit['status'] ?? 1) === 0) ? 'selected' : '' ?>>Inactive</option>
                    </select>
                </div>
                <div class="col-md-9">
                    <label class="form-label"><?= $userToEdit ? 'Password (leave empty to keep current)' : 'Password *' ?></label>
                    <div class="input-group">
                        <input class="form-control" name="password" type="password" id="userFormPassword" <?= $userToEdit ? '' : 'required' ?>>
                        <button class="btn btn-outline-secondary" type="button" onclick="togglePasswordVisibility('userFormPassword', this)"><i class="bi bi-eye"></i></button>
                    </div>
                </div>
            </div>

            <hr class="my-3">
            <h3 class="h6">Link to Record <span class="text-muted small fw-normal">(controls what this login can see in their portal)</span></h3>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Link to Student</label>
                    <div class="combo" data-combo-root data-combo-type="student">
                        <input type="text" class="form-control combo-input" placeholder="Type a student's name or admission #…" autocomplete="off"
                               value="<?= h($linkedStudentLabel ?? '') ?>">
                        <input type="hidden" name="link_student_id" value="<?= (int)($linkedStudentId ?? 0) ?>">
                        <div class="combo-menu list-group shadow-sm"></div>
                    </div>
                    <div class="form-text">For the Student role — shows only this student's own results/fees/courses.</div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Link to Staff Member</label>
                    <div class="combo" data-combo-root data-combo-type="staff">
                        <input type="text" class="form-control combo-input" placeholder="Type a staff member's name…" autocomplete="off"
                               value="<?= h($linkedStaffLabel ?? '') ?>">
                        <input type="hidden" name="link_staff_id" value="<?= (int)($linkedStaffId ?? 0) ?>">
                        <div class="combo-menu list-group shadow-sm"></div>
                    </div>
                    <div class="form-text">For the Teacher role — scopes marks entry to their assigned classes.</div>
                </div>
                <div class="col-md-8">
                    <label class="form-label">Link to Parent — search by student</label>
                    <div class="combo" data-combo-root data-combo-type="parent">
                        <input type="text" class="form-control combo-input" placeholder="Type the student's name (or father's name)…" autocomplete="off"
                               value="<?= h($linkedParentStudentLabel ?? '') ?>">
                        <input type="hidden" name="link_parent_student_id" id="linkParentStudentId" value="<?= (int)($linkedParentStudentId ?? 0) ?>">
                        <div class="combo-menu list-group shadow-sm"></div>
                    </div>
                    <div class="form-text" id="parentComboPreview">
                        For the Parent role — search for the <strong>student</strong>, not the guardian. If that student
                        already has a guardian on file, this links to them; otherwise one is created automatically using
                        the student's Father's Name.
                    </div>
                </div>
                <div class="col-md-4 d-flex align-items-end">
                    <div class="w-100">
                        <a href="#advancedGuardianPicker" class="small" data-bs-toggle="collapse">Advanced: link a specific existing guardian record instead ▾</a>
                    </div>
                </div>
                <div class="col-12 collapse<?= (($linkedGuardianId ?? 0) > 0 && ($linkedParentStudentId ?? 0) === 0) ? ' show' : '' ?>" id="advancedGuardianPicker">
                    <div class="card bg-body-tertiary border-0">
                        <div class="card-body">
                            <label class="form-label">Link to a specific Guardian record</label>
                            <div class="combo" data-combo-root data-combo-type="guardian">
                                <input type="text" class="form-control combo-input" placeholder="Type a guardian's name…" autocomplete="off"
                                       value="<?= h($linkedGuardianLabel ?? '') ?>">
                                <input type="hidden" name="link_guardian_id" value="<?= (int)($linkedGuardianId ?? 0) ?>">
                                <div class="combo-menu list-group shadow-sm"></div>
                            </div>
                            <div class="form-text">Overrides the student search above. Use this only for edge cases — e.g. giving the mother her own separate login when the father already has one, or a guardian with no student linked yet.</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mt-3 d-flex gap-2">
                <button class="btn btn-primary" type="submit"><?= $userToEdit ? 'Save User' : 'Create User' ?></button>
                <?php if ($userToEdit): ?>
                    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=users/users'), ENT_QUOTES, 'UTF-8') ?>">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end mb-3">
            <input type="hidden" name="route" value="users/users">
            <div class="col-md-4">
                <label class="form-label">Search</label>
                <input class="form-control" name="q" value="<?= h($q) ?>" placeholder="Username">
            </div>
            <div class="col-md-3">
                <label class="form-label">Role</label>
                <select class="form-select" name="role_id">
                    <option value="0">All</option>
                    <?php foreach ($roles as $r): ?>
                        <option value="<?= (int)$r['id'] ?>" <?= ((int)$roleFilter === (int)$r['id']) ? 'selected' : '' ?>><?= h($r['name'] ?? '') ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Status</label>
                <select class="form-select" name="status">
                    <option value="-1" <?= ((int)$statusFilter === -1) ? 'selected' : '' ?>>All</option>
                    <option value="1" <?= ((int)$statusFilter === 1) ? 'selected' : '' ?>>Active</option>
                    <option value="0" <?= ((int)$statusFilter === 0) ? 'selected' : '' ?>>Inactive</option>
                </select>
            </div>
            <div class="col-md-1">
                <label class="form-label">Per page</label>
                <select class="form-select" name="per_page">
                    <?php foreach ([10, 25, 50, 100] as $pp): ?>
                        <option value="<?= $pp ?>" <?= ((int)$perPage === $pp) ? 'selected' : '' ?>><?= $pp ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2 d-grid">
                <button class="btn btn-primary" type="submit">Filter</button>
            </div>
        </form>

        <div id="userListContainer">
        <?= $this->renderPartial('users/_user_list', [
            'users' => $users,
            'total' => $total,
            'q' => $q,
            'roleFilter' => $roleFilter,
            'statusFilter' => $statusFilter,
            'page' => $page,
            'perPage' => $perPage,
            'roles' => $roles,
        ]) ?>
        </div>
    </div>
</div>

<style>
.combo { position: relative; }
.combo-menu {
    display: none;
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    z-index: 40;
    max-height: 420px; /* comfortably fits the 10 results the server now returns */
    overflow-y: auto;
    margin-top: 2px;
}
.combo-menu .list-group-item { cursor: pointer; }
</style>
<script>
(function () {
    var SEARCH_URL = <?= json_encode($linkSearchUrl, JSON_UNESCAPED_SLASHES) ?>;

    function escapeHtml(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    // Live database search (max 10 results, server-side) instead of
    // preloading every record into the page and filtering client-side.
    function initCombo(root, type, onSelect) {
        var input = root.querySelector('.combo-input');
        var hidden = root.querySelector('input[type=hidden]');
        var menu = root.querySelector('.combo-menu');
        var debounceTimer = null;
        var requestSeq = 0;

        function renderMatches(matches) {
            menu.innerHTML = '';
            if (matches.length === 0) {
                var empty = document.createElement('div');
                empty.className = 'list-group-item text-muted small';
                empty.textContent = 'No matches';
                menu.appendChild(empty);
            }
            matches.forEach(function (item) {
                var a = document.createElement('a');
                a.href = '#';
                a.className = 'list-group-item list-group-item-action py-1 px-2';
                a.innerHTML = '<div>' + escapeHtml(item.label) + '</div>' +
                    (item.sub ? '<div class="text-muted small">' + escapeHtml(item.sub) + '</div>' : '');
                a.addEventListener('mousedown', function (e) {
                    e.preventDefault();
                    hidden.value = item.id;
                    input.value = item.label;
                    menu.style.display = 'none';
                    if (onSelect) { onSelect(item); }
                });
                menu.appendChild(a);
            });
            menu.style.display = 'block';
        }

        function search(filter) {
            var seq = ++requestSeq;
            var url = SEARCH_URL + '&type=' + encodeURIComponent(type) + '&q=' + encodeURIComponent(filter || '');
            fetch(url, { credentials: 'same-origin' })
                .then(function (res) { return res.json(); })
                .then(function (matches) {
                    if (seq !== requestSeq) { return; } // a newer keystroke already fired
                    renderMatches(matches);
                })
                .catch(function () {
                    if (seq !== requestSeq) { return; }
                    menu.innerHTML = '<div class="list-group-item text-danger small">Search failed — try again</div>';
                    menu.style.display = 'block';
                });
        }

        input.addEventListener('focus', function () { search(input.value); });
        input.addEventListener('input', function () {
            hidden.value = 0; // typing invalidates the previous pick until one is clicked again
            clearTimeout(debounceTimer);
            var value = input.value;
            debounceTimer = setTimeout(function () { search(value); }, 250);
        });
        input.addEventListener('blur', function () {
            setTimeout(function () { menu.style.display = 'none'; }, 150);
        });
    }

    document.querySelectorAll('[data-combo-type="student"]').forEach(function (el) { initCombo(el, 'student'); });
    document.querySelectorAll('[data-combo-type="staff"]').forEach(function (el) { initCombo(el, 'staff'); });
    document.querySelectorAll('[data-combo-type="guardian"]').forEach(function (el) { initCombo(el, 'guardian'); });
    document.querySelectorAll('[data-combo-type="parent"]').forEach(function (el) {
        initCombo(el, 'parent', function (item) {
            var preview = document.getElementById('parentComboPreview');
            if (preview) {
                preview.innerHTML = item.sub
                    ? '<strong>' + escapeHtml(item.label) + '</strong> — ' + escapeHtml(item.sub)
                    : 'Selected ' + escapeHtml(item.label);
            }
        });
    });
})();
</script>

