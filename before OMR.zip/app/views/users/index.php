<?php
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Users & Roles</h1>
        <div class="text-muted">Authentication accounts, RBAC permissions and custom fields.</div>
    </div>
</div>

<div class="row g-3">
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(base_url('/index.php?route=users/users'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="fw-semibold mb-1">Users</div>
                    <div class="text-muted small">Create/update/delete accounts</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(base_url('/index.php?route=users/roles'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="fw-semibold mb-1">Roles & Permissions</div>
                    <div class="text-muted small">Role capabilities management</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(base_url('/index.php?route=users/customFields&scope=user'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="fw-semibold mb-1">Custom Fields</div>
                    <div class="text-muted small">Define extra profile fields</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(base_url('/index.php?route=users/attendance'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-body">
                    <div class="fw-semibold mb-1">My Attendance</div>
                    <div class="text-muted small">View attendance records</div>
                </div>
            </div>
        </a>
    </div>
</div>

