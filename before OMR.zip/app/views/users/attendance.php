<?php
// Variables: mode, rows, start_date, end_date
$routeBase = base_url('/index.php?route=users/attendance');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">My Attendance</h1>
        <div class="text-muted">View your attendance records.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=users/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label">Start</label>
                <input class="form-control" type="date" name="start_date" value="<?= h($start_date) ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">End</label>
                <input class="form-control" type="date" name="end_date" value="<?= h($end_date) ?>">
            </div>
            <div class="col-md-4 d-grid">
                <button class="btn btn-primary" type="submit">Load</button>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <?php if ($mode === ''): ?>
            <div class="text-muted">No linked staff/student profile found for this user.</div>
        <?php else: ?>
            <div class="text-muted small mb-2">Mode: <span class="fw-semibold"><?= h($mode) ?></span></div>
            <div class="table-responsive">
                <table class="table table-sm table-striped mb-0">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($rows)): ?>
                        <tr><td colspan="2" class="text-muted">No attendance records found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($rows as $r): ?>
                            <tr>
                                <td><?= h($r['attendance_date'] ?? '') ?></td>
                                <td class="fw-semibold"><?= h($r['status'] ?? '') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

