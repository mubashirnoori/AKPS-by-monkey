<?php
// Variables: $created
$created = $created ?? [];
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Generated Logins</h1>
        <div class="text-muted small">These passwords are shown once only — copy or print this list now. After you leave this page they can't be retrieved (only reset).</div>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-outline-secondary" type="button" onclick="window.print()"><i class="bi bi-printer me-1"></i>Print</button>
        <a class="btn btn-primary" href="<?= h(route_url('users/users')) ?>">Back to Users</a>
    </div>
</div>

<?php if (empty($created)): ?>
    <div class="alert alert-info">No missing logins were found for the selected record types — everyone already has an account.</div>
<?php else: ?>
    <div class="alert alert-warning"><i class="bi bi-exclamation-triangle me-1"></i>Created <?= count($created) ?> new login(s). Share these credentials with each person and ask them to change their password after first login.</div>

    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr><th>Type</th><th>Name</th><th>Username</th><th>Password</th></tr>
                </thead>
                <tbody>
                <?php foreach ($created as $c): ?>
                    <tr>
                        <td><span class="badge text-bg-secondary"><?= h($c['type'] ?? '') ?></span></td>
                        <td><?= h($c['name'] ?? '') ?></td>
                        <td class="font-monospace"><?= h($c['username'] ?? '') ?></td>
                        <td class="font-monospace"><?= h($c['password'] ?? '') ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>
