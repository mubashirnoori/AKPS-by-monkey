<?php
// Variables: roles,permissions,role,selectedRoleId,selectedPermIds,error
$role = $role ?? null;
$selectedPermIds = $selectedPermIds ?? [];

// Group permissions by their key's module prefix (the part before the first
// '.') so the checklist reads like the sidebar's sections instead of a flat
// list of raw permission_key strings — e.g. 'academic.marks_entry' and
// 'academic.report_cards' both land under an "Academic" heading.
$groupLabels = [
    'dashboard' => 'Dashboard',
    'students' => 'Students',
    'academic' => 'Academic',
    'fees' => 'Fees',
    'expenses' => 'Expenses',
    'staff' => 'Staff',
    'attendance' => 'Attendance',
    'users' => 'Users & Roles',
    'reports' => 'Reports',
    'settings' => 'Settings',
    'activity_log' => 'Activity Log',
    'notifications' => 'Notifications',
    'portal' => 'Portal',
];
$groups = [];
foreach ($permissions as $p) {
    $prefix = strstr((string)($p['permission_key'] ?? ''), '.', true) ?: 'other';
    $groups[$prefix][] = $p;
}
// Keep a stable, sensible order: known modules first (in the order above), then anything unrecognized.
$orderedGroupKeys = array_values(array_intersect(array_keys($groupLabels), array_keys($groups)));
foreach (array_keys($groups) as $g) {
    if (!in_array($g, $orderedGroupKeys, true)) {
        $orderedGroupKeys[] = $g;
    }
}
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Roles & Permissions</h1>
        <div class="text-muted">Assign capabilities to roles (RBAC).</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=users/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="route" value="users/roles">
            <div class="col-md-6">
                <label class="form-label">Select Role</label>
                <select class="form-select" name="role_id" onchange="this.form.submit()">
                    <?php foreach ($roles as $r): ?>
                        <option value="<?= (int)$r['id'] ?>" <?= ((int)$selectedRoleId === (int)$r['id']) ? 'selected' : '' ?>>
                            <?= h($r['name'] ?? '') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </form>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-4">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-3">Create Role</h2>
                <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=users/roles'), ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="action" value="create_role">
                    <div class="mb-3">
                        <label class="form-label">Role Name *</label>
                        <input class="form-control" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" rows="3"></textarea>
                    </div>
                    <button class="btn btn-primary w-100" type="submit">Create</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-body">
                <h2 class="h6 mb-3">Permission Assignment</h2>
                <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=users/roles'), ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="action" value="save_permissions">
                    <input type="hidden" name="role_id" value="<?= (int)$selectedRoleId ?>">

                    <div class="mb-3 text-muted small">
                        Assign permissions for role: <span class="fw-semibold"><?= h($role['name'] ?? '') ?></span> —
                        each item below corresponds to a page or action in the sidebar; uncheck anything this role shouldn't be able to see or do.
                    </div>

                    <div class="accordion" id="permGroups">
                    <?php foreach ($orderedGroupKeys as $gi => $groupKey): ?>
                        <?php
                        $groupPerms = $groups[$groupKey];
                        $groupLabel = $groupLabels[$groupKey] ?? ucfirst(str_replace('_', ' ', $groupKey));
                        $checkedInGroup = 0;
                        foreach ($groupPerms as $gp) {
                            if (!empty($selectedPermIds[(int)($gp['id'] ?? 0)])) { $checkedInGroup++; }
                        }
                        $collapseId = 'permGroup' . $gi;
                        ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button <?= $checkedInGroup === 0 ? 'collapsed' : '' ?>" type="button" data-bs-toggle="collapse" data-bs-target="#<?= $collapseId ?>">
                                    <span class="fw-semibold"><?= h($groupLabel) ?></span>
                                    <span class="text-muted small ms-2" data-group-count="<?= h($groupKey) ?>"><?= $checkedInGroup ?> of <?= count($groupPerms) ?> enabled</span>
                                </button>
                            </h2>
                            <div id="<?= $collapseId ?>" class="accordion-collapse collapse <?= $checkedInGroup > 0 ? 'show' : '' ?>" data-bs-parent="#permGroups">
                                <div class="accordion-body p-0">
                                    <div class="px-3 pt-2">
                                        <button type="button" class="btn btn-link btn-sm p-0" onclick="toggleGroup('<?= h($groupKey) ?>', true)">Select all</button>
                                        <span class="text-muted mx-1">·</span>
                                        <button type="button" class="btn btn-link btn-sm p-0" onclick="toggleGroup('<?= h($groupKey) ?>', false)">Select none</button>
                                    </div>
                                    <table class="table table-sm table-striped align-middle mb-0">
                                        <tbody>
                                        <?php foreach ($groupPerms as $p): ?>
                                            <?php $pid = (int)($p['id'] ?? 0); $checked = !empty($selectedPermIds[$pid]); ?>
                                            <tr>
                                                <td style="width: 50px;">
                                                    <input class="form-check-input perm-checkbox" data-group="<?= h($groupKey) ?>" type="checkbox" name="permission_ids[]" value="<?= $pid ?>" <?= $checked ? 'checked' : '' ?>>
                                                </td>
                                                <td class="fw-semibold" style="width: 220px;">
                                                    <?= h($p['permission_name'] ?? $p['permission_key'] ?? '') ?>
                                                </td>
                                                <td class="text-muted small"><?= h($p['permission_description'] ?? '') ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    </div>

                    <div class="mt-3">
                        <button class="btn btn-primary" type="submit">Save Permissions</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function toggleGroup(groupKey, on) {
    document.querySelectorAll('.perm-checkbox[data-group="' + groupKey + '"]').forEach(function (cb) {
        cb.checked = on;
    });
    updateGroupCount(groupKey);
}
function updateGroupCount(groupKey) {
    var boxes = document.querySelectorAll('.perm-checkbox[data-group="' + groupKey + '"]');
    var checked = [...boxes].filter(function (cb) { return cb.checked; }).length;
    var label = document.querySelector('[data-group-count="' + groupKey + '"]');
    if (label) { label.textContent = checked + ' of ' + boxes.length + ' enabled'; }
}
document.addEventListener('change', function (evt) {
    if (evt.target.classList && evt.target.classList.contains('perm-checkbox')) {
        updateGroupCount(evt.target.dataset.group);
    }
});
</script>

