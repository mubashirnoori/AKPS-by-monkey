<?php
// Variables: scope, fields, error
$fields = $fields ?? [];
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Custom Fields</h1>
        <div class="text-muted">Manage custom fields for scope: <?= h($scope) ?></div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=users/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="users/customFields">
            <div class="col-md-4">
                <label class="form-label">Scope</label>
                <select class="form-select" name="scope" onchange="this.form.submit()">
                    <?php foreach (['user','student','staff'] as $s): ?>
                        <option value="<?= h($s) ?>" <?= $scope === $s ? 'selected' : '' ?>><?= h($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </form>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Create Field</h2>
                <form method="post" action="<?= htmlspecialchars(base_url('/index.php?route=users/customFields'), ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="action" value="create">
                    <input type="hidden" name="scope" value="<?= h($scope) ?>">

                    <div class="mb-3">
                        <label class="form-label">Field Key *</label>
                        <input class="form-control" name="field_key" required placeholder="e.g. emergency_contact">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Label *</label>
                        <input class="form-control" name="label_text" required placeholder="Emergency Contact">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Field Type</label>
                        <select class="form-select" name="field_type">
                            <?php foreach (['text','number','date','select','textarea'] as $t): ?>
                                <option value="<?= h($t) ?>"><?= h($t) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Options (for select)</label>
                        <textarea class="form-control" name="options_text" rows="3" placeholder="Comma-separated options"></textarea>
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="is_required" value="1" id="is_required">
                            <label class="form-check-label" for="is_required">Required</label>
                        </div>
                    </div>
                    <button class="btn btn-primary w-100" type="submit">Create</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <h2 class="h6 mb-3">Existing Fields</h2>
                <div id="customFieldListContainer">
                <?= $this->renderPartial('users/_custom_field_list', [
                    'fields' => $fields,
                    'scope' => $scope,
                ]) ?>
                </div>
            </div>
        </div>
    </div>
</div>

