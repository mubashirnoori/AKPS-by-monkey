<?php
// Variables: $users, $total, $q, $roleFilter, $statusFilter, $page, $perPage, $roles
$users = $users ?? [];
$total = (int)($total ?? 0);
$q = $q ?? '';
$roleFilter = (int)($roleFilter ?? 0);
$statusFilter = (int)($statusFilter ?? -1);
$page = max(1, (int)($page ?? 1));
$perPage = (int)($perPage ?? 10);
$roles = $roles ?? [];
$totalPages = max(1, (int)ceil($total / max(1, $perPage)));
$routeBase = base_url('/index.php?route=users/users');
$bulkUrl = base_url('/index.php?route=users/users');
?>
<form method="post" action="<?= htmlspecialchars($bulkUrl, ENT_QUOTES, 'UTF-8') ?>"
      id="bulkUsersForm" data-ajax data-target="#userListContainer" data-bulk-select="users">
    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
    <input type="hidden" name="action" id="bulkUsersAction" value="">
    <input type="hidden" name="q" value="<?= h($q) ?>">
    <input type="hidden" name="filter_role_id" value="<?= (int)$roleFilter ?>">
    <input type="hidden" name="filter_status" value="<?= (int)$statusFilter ?>">
    <input type="hidden" name="page" value="<?= (int)$page ?>">
    <input type="hidden" name="per_page" value="<?= (int)$perPage ?>">

    <div class="d-flex align-items-center gap-2 mb-2">
        <span class="badge text-bg-primary" data-select-count></span>
        <button class="btn btn-link btn-sm p-0" type="button" data-select-clear style="display:none;">Clear selection</button>
    </div>

    <div class="row g-2 align-items-end mb-2">
        <div class="col-md-4">
            <label class="form-label">Role for bulk assign</label>
            <select class="form-select" name="role_id" required>
                <?php foreach ($roles as $r): ?>
                    <option value="<?= (int)$r['id'] ?>"><?= h($r['name'] ?? '') ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-8 d-flex gap-2 justify-content-md-end">
            <button class="btn btn-primary btn-sm" type="submit"
                    onclick="document.getElementById('bulkUsersAction').value='bulk_assign';">
                Assign Role
            </button>
            <button class="btn btn-danger btn-sm" type="submit"
                    onclick="document.getElementById('bulkUsersAction').value='bulk_delete'; if (!confirm('Delete selected users?')) { event.preventDefault(); }">
                Delete Users
            </button>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-sm table-striped mb-0">
            <thead>
                <tr>
                    <th style="width: 60px;"><input type="checkbox" data-select-all></th>
                    <th style="width: 48px;"></th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th style="width: 160px;">Edit</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($users as $u): ?>
                <?php
                $photoUrl = staff_photo_url((int)($u['staff_profile_id'] ?? 0));
                $initials = '';
                foreach (preg_split('/\s+/', trim((string)($u['username'] ?? ''))) as $part) {
                    if ($part !== '') { $initials .= mb_strtoupper(mb_substr($part, 0, 1)); }
                    if (mb_strlen($initials) >= 2) { break; }
                }
                ?>
                <tr>
                    <td><input class="form-check-input" type="checkbox" data-select-item name="user_ids[]" value="<?= (int)$u['id'] ?>"></td>
                    <td>
                        <?php if ($photoUrl): ?>
                            <img src="<?= h($photoUrl) ?>" alt="" class="rounded-circle" style="width:32px;height:32px;object-fit:cover;">
                        <?php else: ?>
                            <span class="rounded-circle bg-secondary-subtle text-secondary d-inline-flex align-items-center justify-content-center fw-semibold" style="width:32px;height:32px;font-size:12px;"><?= h($initials ?: '?') ?></span>
                        <?php endif; ?>
                    </td>
                    <td class="fw-semibold"><?= h($u['username'] ?? '') ?></td>
                    <td class="text-muted small"><?= h($u['role_name'] ?? '') ?></td>
                    <td><?= !empty($u['status']) ? '<span class="badge text-bg-success">Active</span>' : '<span class="badge text-bg-secondary">Inactive</span>' ?></td>
                    <td>
                        <a class="btn btn-sm btn-outline-primary" href="<?= htmlspecialchars(base_url('/index.php?route=users/users&id=' . (int)$u['id']), ENT_QUOTES, 'UTF-8') ?>">Edit</a>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($users)): ?>
                <tr><td colspan="6" class="text-muted">No users found.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</form>

<div class="d-flex align-items-center justify-content-between mt-3">
    <div class="text-muted small">
        <?php if ($total > 0): ?>
            Showing <?= (($page - 1) * $perPage) + 1 ?>–<?= min($page * $perPage, $total) ?> of <?= $total ?> users
        <?php else: ?>
            No users found.
        <?php endif; ?>
    </div>
</div>

<?php if ($totalPages > 1): ?>
    <?php
    $queryCommon = ['q' => $q, 'role_id' => $roleFilter ?: 0, 'status' => $statusFilter ?: 0, 'per_page' => $perPage];
    ?>
    <nav class="mt-2">
        <ul class="pagination justify-content-center">
            <?php for ($p = 1; $p <= $totalPages; $p++): ?>
                <?php $url = $routeBase . '&' . http_build_query(array_merge($queryCommon, ['page' => $p])); ?>
                <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                    <a class="page-link" href="<?= htmlspecialchars($url, ENT_QUOTES, 'UTF-8') ?>"><?= (int)$p ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
<?php endif; ?>
