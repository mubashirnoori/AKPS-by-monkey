<?php
// Variables: $error, $categories, $categoryUsage, $expenses, $total, $month, $year, $categoryId, $search
$categories = $categories ?? [];
$categoryUsage = $categoryUsage ?? [];
$expenses = $expenses ?? [];
$total = (float)($total ?? 0);
$month = (int)($month ?? date('n'));
$year = (int)($year ?? date('Y'));
$categoryId = (int)($categoryId ?? 0);
$search = $search ?? '';
$canManage = RBAC::hasPermission('expenses.manage');

$monthNames = [1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
               7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'];
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Other Expenses</h1>
        <div class="text-muted small">Printing, sports materials, repairs and other miscellaneous school expenses. Included in the Dashboard's Net Balance, alongside Payroll.</div>
    </div>
    <?php if ($canManage): ?>
    <button class="btn btn-outline-secondary" type="button" data-bs-toggle="modal" data-bs-target="#categoriesModal">
        <i class="bi bi-tags me-1"></i>Manage Categories
    </button>
    <?php endif; ?>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<!-- Month/Year/Category Filter -->
<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= h(base_url('/index.php')) ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="expenses/index">
            <div class="col-md-3">
                <label class="form-label fw-semibold">Month</label>
                <select class="form-select" name="expense_month">
                    <?php foreach ($monthNames as $num => $name): ?>
                        <option value="<?= $num ?>" <?= $num === $month ? 'selected' : '' ?>><?= $name ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label fw-semibold">Year</label>
                <input class="form-control" type="number" name="expense_year" value="<?= $year ?>" min="2000" max="2100">
            </div>
            <div class="col-md-3">
                <label class="form-label fw-semibold">Category</label>
                <select class="form-select" name="category_id">
                    <option value="0">All categories</option>
                    <?php foreach ($categories as $c): ?>
                        <option value="<?= (int)$c['id'] ?>" <?= $categoryId === (int)$c['id'] ? 'selected' : '' ?>><?= h($c['name'] ?? '') ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label fw-semibold">Search</label>
                <input class="form-control" name="q" value="<?= h($search) ?>" placeholder="Description…">
            </div>
            <div class="col-md-2 d-grid">
                <button class="btn btn-primary" type="submit">Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="row g-3">
    <?php if ($canManage): ?>
    <div class="col-lg-4">
        <div class="card shadow-sm border-0 h-100">
            <div class="card-header bg-white fw-semibold">Record Expense</div>
            <div class="card-body">
                <form method="post" action="<?= h(route_url('expenses/index')) ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="action" value="create">

                    <div class="mb-3">
                        <label class="form-label fw-semibold d-flex justify-content-between align-items-center">
                            Category *
                            <a href="javascript:void(0)" class="small" data-bs-toggle="modal" data-bs-target="#categoriesModal">+ New category</a>
                        </label>
                        <select class="form-select" name="expense_category_id" required>
                            <option value="">— Select category —</option>
                            <?php foreach ($categories as $c): ?>
                                <option value="<?= (int)$c['id'] ?>"><?= h($c['name'] ?? '') ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (empty($categories)): ?>
                            <div class="form-text text-warning">No categories yet — click "+ New category" above to add one.</div>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Description</label>
                        <input class="form-control" name="description" placeholder="e.g. Printed report cards">
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Amount (Rs.) *</label>
                        <input class="form-control" name="amount" type="number" step="0.01" min="0.01" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Date *</label>
                        <input class="form-control" type="date" name="expense_date" value="<?= date('Y-m-d') ?>" required>
                    </div>

                    <button class="btn btn-primary w-100" type="submit">Save Expense</button>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="col-lg-<?= $canManage ? 8 : 12 ?>">
        <div class="card shadow-sm border-0">
            <div class="card-header bg-white d-flex align-items-center justify-content-between">
                <span class="fw-semibold"><?= h($monthNames[$month] ?? '') ?> <?= $year ?></span>
                <span class="text-muted small">Total: <strong>Rs <?= number_format($total, 2) ?></strong></span>
            </div>
            <div class="table-responsive">
                <table class="table table-sm table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Date</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th class="text-end">Amount</th>
                            <?php if ($canManage): ?><th style="width:140px;">Actions</th><?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($expenses)): ?>
                        <tr><td colspan="<?= $canManage ? 5 : 4 ?>" class="text-muted text-center py-3">No expenses recorded for this period.</td></tr>
                    <?php else: ?>
                        <?php foreach ($expenses as $e): ?>
                            <tr>
                                <td class="text-muted small"><?= h($e['expense_date'] ?? '') ?></td>
                                <td><?= h($e['category_name'] ?? '') ?></td>
                                <td class="text-muted small"><?= h($e['description'] ?? '—') ?></td>
                                <td class="text-end fw-semibold">Rs <?= number_format((float)($e['amount'] ?? 0), 2) ?></td>
                                <?php if ($canManage): ?>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#editExpenseModal"
                                            onclick='openEditExpense(<?= json_encode([
                                                "id" => (int)$e["id"],
                                                "category_id" => (int)$e["expense_category_id"],
                                                "description" => $e["description"] ?? "",
                                                "amount" => (float)($e["amount"] ?? 0),
                                                "expense_date" => $e["expense_date"] ?? "",
                                            ], JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>Edit</button>
                                    <form method="post" action="<?= h(route_url('expenses/index')) ?>" class="d-inline" onsubmit="return confirm('Delete this expense?')">
                                        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= (int)$e['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                    </form>
                                </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php if ($canManage): ?>
<!-- Edit Expense Modal -->
<div class="modal fade" id="editExpenseModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="post" action="<?= h(route_url('expenses/index')) ?>">
                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" id="editExpenseId">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Expense</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Category *</label>
                        <select class="form-select" name="expense_category_id" id="editExpenseCategory" required>
                            <?php foreach ($categories as $c): ?>
                                <option value="<?= (int)$c['id'] ?>"><?= h($c['name'] ?? '') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Description</label>
                        <input class="form-control" name="description" id="editExpenseDescription">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Amount (Rs.) *</label>
                        <input class="form-control" name="amount" id="editExpenseAmount" type="number" step="0.01" min="0.01" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Date *</label>
                        <input class="form-control" type="date" name="expense_date" id="editExpenseDate" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
function openEditExpense(e) {
    document.getElementById('editExpenseId').value = e.id;
    document.getElementById('editExpenseCategory').value = e.category_id;
    document.getElementById('editExpenseDescription').value = e.description;
    document.getElementById('editExpenseAmount').value = e.amount;
    document.getElementById('editExpenseDate').value = e.expense_date;
}
</script>

<!-- Manage Categories Modal -->
<div class="modal fade" id="categoriesModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Manage Expense Categories</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <form method="post" action="<?= h(route_url('expenses/index')) ?>" class="d-flex gap-2 mb-3">
                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                    <input type="hidden" name="action" value="add_category">
                    <input class="form-control" name="name" placeholder="New category name" required>
                    <button type="submit" class="btn btn-primary text-nowrap">+ Add</button>
                </form>

                <table class="table table-sm align-middle mb-0">
                    <tbody>
                    <?php if (empty($categories)): ?>
                        <tr><td class="text-muted text-center py-2">No categories yet.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($categories as $c): ?>
                        <?php $usage = $categoryUsage[(int)$c['id']] ?? 0; ?>
                        <tr>
                            <td>
                                <form method="post" action="<?= h(route_url('expenses/index')) ?>" class="d-flex gap-1">
                                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                    <input type="hidden" name="action" value="rename_category">
                                    <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                                    <input class="form-control form-control-sm" name="name" value="<?= h($c['name'] ?? '') ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-secondary text-nowrap">Save</button>
                                </form>
                            </td>
                            <td class="text-muted small text-nowrap"><?= $usage ?> expense<?= $usage === 1 ? '' : 's' ?></td>
                            <td class="text-end">
                                <form method="post" action="<?= h(route_url('expenses/index')) ?>"
                                      onsubmit="return confirm('Delete this category?<?= $usage > 0 ? ' It is used by ' . $usage . ' expense(s) and cannot be deleted until those are reassigned or removed.' : '' ?>')">
                                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                    <input type="hidden" name="action" value="delete_category">
                                    <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger" <?= $usage > 0 ? 'disabled title="In use — reassign or delete its expenses first"' : '' ?>>Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
