<?php
http_response_code(403);
// No cache-busting query string on this page's own URL (unlike app.css?v=NN), so
// without explicit no-store headers a browser/webview can silently keep serving an
// old cached copy of this exact response across edits.
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
$backRoute = RBAC::isAdmin() ? 'dashboard/index' : 'portal/index';
$backLabel = RBAC::isAdmin() ? 'Dashboard' : 'Portal';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <title>Wrong Place</title>
    <style>
@import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');

*{ box-sizing:border-box; }
html,body{
    margin:0; padding:0;
    width:100%;
    max-width:100%;
    overflow-x:hidden;
}
body{
    font-family:'Nunito', 'Segoe UI', sans-serif;
    background: linear-gradient(160deg, #eef6f2 0%, #e3f2ea 55%, #dcefe5 100%);
    /* No min-height:100vh / flex centering here on purpose. This app's
       webview appears to compute 100vh much taller than what's actually
       visible on screen, so vertically centering a short card inside it
       pushes the card far below the fold (you'd have to scroll or zoom
       out to find it). Anchoring near the top with padding avoids that
       entirely — the card is visible immediately, same as it was before
       any vh-based centering was introduced. */
    padding:40px 16px;
}

.card{
    position:relative;
    width:100%;
    max-width:560px;
    margin:0 auto;
    background:#ffffff;
    border-radius:28px;
    padding:56px 48px 44px;
    text-align:center;
    box-shadow: 0 30px 70px -25px rgba(22,101,52,0.25), 0 10px 30px rgba(22,101,52,0.08);
}

.illustration{ position:relative; width:220px; height:200px; margin:0 auto 18px; }
.illustration .halo{
    position:absolute; inset:0;
    background:#eaf7ef;
    border-radius:50%;
    transform:scale(0.82);
}
.illustration svg{ position:relative; width:100%; height:100%; }

h1{
    font-size:26px;
    font-weight:800;
    color:#1f2937;
    margin:6px 0 14px;
    letter-spacing:.1px;
}
h1 .accent{ color:#16a34a; }

p.lede{
    font-size:16.5px;
    color:#6b7280;
    margin:0 0 22px;
    font-weight:600;
}
p.lede .role{ color:#16a34a; font-weight:800; }

.divider{
    width:64px;
    height:2px;
    background:#dcefe5;
    margin:0 auto 22px;
    border-radius:2px;
}

p.hint{
    font-size:15px;
    line-height:1.6;
    color:#8b94a3;
    font-weight:600;
    margin:0 0 30px;
    max-width:380px;
    margin-left:auto;
    margin-right:auto;
}

.back-btn{
    display:inline-flex;
    align-items:center;
    gap:10px;
    justify-content:center;
    background:linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
    color:#ffffff;
    text-decoration:none;
    border:none;
    border-radius:14px;
    padding:15px 30px;
    font-family:'Nunito', sans-serif;
    font-weight:800;
    font-size:16px;
    cursor:pointer;
    box-shadow: 0 10px 24px -6px rgba(22,163,74,0.55);
    transition: transform .15s ease, box-shadow .15s ease;
}
.back-btn i{ font-size:15px; }
.back-btn:hover{ transform:translateY(-2px); box-shadow: 0 14px 28px -6px rgba(22,163,74,0.6); }
.back-btn:active{ transform:translateY(0); }

@media (max-width:480px){
    .card{ padding:40px 18px 32px; border-radius:22px; }
    h1{ font-size:21px; }
    .illustration{ width:170px; height:155px; }
}
    </style>
</head>
<body>
    <div class="card">
        <div class="illustration">
            <div class="halo"></div>
            <svg viewBox="0 0 220 200" fill="none" xmlns="http://www.w3.org/2000/svg">
                <!-- scattered marks -->
                <circle cx="24" cy="118" r="6" stroke="#bfe3cf" stroke-width="3" fill="none"/>
                <circle cx="196" cy="70" r="6.5" stroke="#bfe3cf" stroke-width="3" fill="none"/>
                <g stroke="#bfe3cf" stroke-width="3" stroke-linecap="round">
                    <path d="M55 46 L64 55 M64 46 L55 55"/>
                    <path d="M160 132 L169 141 M169 132 L160 141"/>
                </g>

                <!-- leaves -->
                <path d="M40 128c22-4 34 8 34 26-24 2-38-10-34-26z" fill="#cdeada"/>
                <path d="M48 152c18-10 34-2 38 14-20 8-36 0-38-14z" fill="#cdeada"/>
                <path d="M180 128c-22-4-34 8-34 26 24 2 38-10 34-26z" fill="#cdeada"/>
                <path d="M172 152c-18-10-34-2-38 14 20 8 36 0 38-14z" fill="#cdeada"/>

                <!-- folded map -->
                <g>
                    <path d="M60 108l35-12 35 12 30-11v66l-30 11-35-12-35 12-30-11V97z" fill="#eaf7ef" stroke="#bcdfcb" stroke-width="2"/>
                    <path d="M95 96v78M130 108v78" stroke="#bcdfcb" stroke-width="2"/>
                    <path d="M72 140c14-8 24 6 38 0s24-10 38 2" stroke="#16a34a" stroke-width="2.5" stroke-dasharray="1 7" stroke-linecap="round" fill="none"/>
                    <path d="M138 132l10 10M148 132l-10 10" stroke="#16a34a" stroke-width="3" stroke-linecap="round"/>
                </g>

                <!-- pin -->
                <path d="M110 20c-16 0-29 13-29 29 0 21 29 51 29 51s29-30 29-51c0-16-13-29-29-29z" fill="#16a34a"/>
                <circle cx="110" cy="49" r="11" fill="#ffffff"/>
            </svg>
        </div>

        <h1><span class="accent">Oops!</span> You're in the Wrong Place <span aria-hidden="true">😊</span></h1>
        <p class="lede">This section isn't available for your <span class="role"><?= h(ucfirst(RBAC::roleName() ?: 'account')) ?></span> account.</p>

        <div class="divider"></div>

        <p class="hint">Use the navigation menu to access features available for your account.</p>

        <a class="back-btn" href="<?= htmlspecialchars(route_url($backRoute), ENT_QUOTES, 'UTF-8') ?>">
            <i class="bi bi-arrow-left"></i> Back to <?= h($backLabel) ?>
        </a>
    </div>
</body>
</html>