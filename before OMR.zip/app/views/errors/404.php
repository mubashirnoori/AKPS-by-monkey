<?php
http_response_code(404);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <title>Not Found</title>
</head>
<body class="bg-light">
<div class="container py-5">
    <div class="card shadow-sm">
        <div class="card-body">
            <h3 class="card-title mb-2">404 Not Found</h3>
            <p class="card-text">The requested page does not exist.</p>
            <a class="btn btn-primary" href="<?= htmlspecialchars(route_url('dashboard/index'), ENT_QUOTES, 'UTF-8') ?>">Go home</a>
        </div>
    </div>
</div>
</body>
</html>

