<?php
// Variables: error, status, q, leaves, staffOptions
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Leave Requests</h1>
        <div class="text-muted small">Submit and approve staff leave requests.</div>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addLeaveModal">+ New Request</button>
        <a class="btn btn-outline-secondary" href="<?= h(route_url('staff/index')) ?>">Back</a>
    </div>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<!-- Filter bar -->
<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="staff/leaves">
            <div class="col-md-5">
                <label class="form-label fw-semibold">Search Staff</label>
                <input class="form-control" name="q" value="<?= h($q) ?>" placeholder="Name…">
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold">Status</label>
                <select class="form-select" name="status">
                    <option value="">All</option>
                    <?php foreach (['pending','approved','rejected'] as $st): ?>
                        <option value="<?= $st ?>" <?= $status === $st ? 'selected' : '' ?>><?= ucfirst($st) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3 d-grid">
                <button class="btn btn-outline-primary" type="submit">Filter</button>
            </div>
        </form>
    </div>
</div>

<!-- Leave List -->
<div id="leaveListContainer">
<?= $this->renderPartial('staff/_leave_list', [
    'leaves' => $leaves,
    'q' => $q,
    'status' => $status,
]) ?>
</div>

<!-- New Leave Modal -->
<div class="modal fade" id="addLeaveModal" tabindex="-1" aria-labelledby="addLeaveModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="post" action="<?= h(route_url('staff/leaves')) ?>">
                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                <input type="hidden" name="action" value="create">
                <div class="modal-header">
                    <h5 class="modal-title" id="addLeaveModalLabel">New Leave Request</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Staff Member *</label>
                        <select class="form-select" name="staff_profile_id" required>
                            <option value="">— Select staff —</option>
                            <?php foreach ($staffOptions as $st): ?>
                                <option value="<?= (int)$st['id'] ?>">
                                    <?= h(($st['full_name'] ?? '') . ($st['title'] ? ' · ' . $st['title'] : '')) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Leave Type</label>
                        <input class="form-control" name="leave_type" placeholder="e.g. Sick Leave, Casual Leave…">
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label fw-semibold">From Date *</label>
                            <input class="form-control" type="date" name="from_date" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-semibold">To Date *</label>
                            <input class="form-control" type="date" name="to_date" required>
                        </div>
                    </div>
                    <div class="mb-1">
                        <label class="form-label fw-semibold">Note / Reason</label>
                        <textarea class="form-control" name="note" rows="3" placeholder="Optional reason…"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Submit Request</button>
                </div>
            </form>
        </div>
    </div>
</div>
