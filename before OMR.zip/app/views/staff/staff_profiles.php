<?php
// Variables: $staff, $search, $error
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Staff Profiles</h1>
        <div class="text-muted small">Create staff records used for attendance, leaves and payroll.</div>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addStaffModal">+ Add Staff</button>
        <a class="btn btn-outline-secondary" href="<?= h(route_url('staff/index')) ?>">Back</a>
    </div>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <div class="d-flex align-items-center justify-content-between mb-3">
            <h2 class="h6 mb-0">All Staff</h2>
            <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="route" value="staff/staffProfiles">
                <input class="form-control form-control-sm" name="q" value="<?= h($search) ?>" placeholder="Search name…" style="width:200px;">
                <button class="btn btn-sm btn-outline-primary" type="submit">Search</button>
                <?php if ($search): ?><a class="btn btn-sm btn-outline-secondary" href="<?= h(route_url('staff/staffProfiles')) ?>">Clear</a><?php endif; ?>
            </form>
        </div>
        <div id="staffProfileListContainer">
        <?= $this->renderPartial('staff/_staff_profile_list', [
            'staff' => $staff,
            'search' => $search,
        ]) ?>
        </div>
    </div>
</div>

<!-- Add Staff Modal -->
<div class="modal fade" id="addStaffModal" tabindex="-1" aria-labelledby="addStaffModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="post" action="<?= h(route_url('staff/staffProfiles')) ?>" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                <div class="modal-header">
                    <h5 class="modal-title" id="addStaffModalLabel">Add New Staff Member</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3 text-center">
                        <label class="form-label fw-semibold d-block">Photo</label>
                        <input class="form-control" type="file" name="photo" accept="image/*">
                        <div class="form-text">Optional — JPG, PNG, WEBP or GIF.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Full Name *</label>
                        <input class="form-control" name="full_name" required placeholder="e.g. Ahmed Khan">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Title / Role</label>
                        <input class="form-control" name="title" placeholder="e.g. Mathematics Teacher">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Phone</label>
                        <input class="form-control" name="phone" placeholder="03XX-XXXXXXX">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Address</label>
                        <input class="form-control" name="address" placeholder="Optional">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Basic Salary (Rs.)</label>
                        <input class="form-control" name="basic_salary" type="number" step="0.01" min="0" value="0" placeholder="e.g. 30000">
                        <div class="form-text">Auto-fills the amount when assigning this staff member's monthly salary in Payroll.</div>
                    </div>
                    <hr>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" name="create_login" id="staff_create_login" value="1" onchange="document.getElementById('staffLoginFields').style.display = this.checked ? 'block' : 'none'">
                        <label class="form-check-label fw-semibold" for="staff_create_login">Also create a login account for this staff member</label>
                    </div>
                    <div id="staffLoginFields" style="display:none;">
                        <div class="mb-2">
                            <label class="form-label">Role</label>
                            <select class="form-select" name="login_role">
                                <option value="Teacher" selected>Teacher</option>
                                <option value="Accountant">Accountant</option>
                                <option value="Admin">Admin</option>
                            </select>
                            <div class="form-text">Can be changed later in Users.</div>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Username</label>
                            <input class="form-control" name="login_username" placeholder="Defaults from full name">
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Password</label>
                            <div class="input-group">
                                <input class="form-control" type="password" name="login_password" id="staff_login_password" placeholder="Leave blank to auto-generate">
                                <button class="btn btn-outline-secondary" type="button" onclick="togglePasswordVisibility('staff_login_password', this)"><i class="bi bi-eye"></i></button>
                            </div>
                        </div>
                        <div class="mb-1">
                            <label class="form-label">Email</label>
                            <input class="form-control" name="login_email">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create Staff</button>
                </div>
            </form>
        </div>
    </div>
</div>
