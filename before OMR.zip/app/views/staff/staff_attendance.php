<?php
// Variables: error, attendance_date, search, rows
$rows = $rows ?? [];
$hasRows = !empty($rows);
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Staff Attendance</h1>
        <div class="text-muted small">Mark daily attendance for all staff members.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= h(route_url('staff/index')) ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<!-- Date selector -->
<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="row g-3 align-items-end">
    <input type="hidden" name="route" value="staff/staffAttendance">

    <div class="col-md-4">
        <label class="form-label fw-semibold">Date *</label>
        <input class="form-control" type="date" name="attendance_date"
               value="<?= h($attendance_date) ?>" onchange="this.form.submit()">
    </div>

    <div class="col-md-5">
        <label class="form-label fw-semibold">Search Staff</label>
        <input class="form-control" name="q" value="<?= h($search) ?>" placeholder="Name…">
    </div>

    <div class="col-md-3 d-grid">
        <button class="btn btn-primary" type="submit">Load</button>
    </div>
</form>
    </div>
</div>

<?php if (!$hasRows): ?>
    <div class="alert alert-warning">No staff profiles found. <a href="<?= h(route_url('staff/staffProfiles')) ?>">Add staff members first</a>.</div>
<?php else: ?>

<form method="post" action="<?= h(route_url('staff/staffAttendance')) ?>" data-ajax id="staffAttForm">
    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
    <input type="hidden" name="attendance_date" value="<?= h($attendance_date) ?>">
    <input type="hidden" name="q" value="<?= h($search) ?>">
    <input type="hidden" name="mark_holiday" id="staffMarkHolidayFlag" value="">

    <?php if (!empty($isConfiguredHoliday)): ?>
        <div class="alert alert-info"><i class="bi bi-calendar-event"></i> <?= h($attendance_date) ?> is set as a holiday under Global Settings.</div>
    <?php endif; ?>

    <div class="card shadow-sm border-0">
        <div class="card-header bg-white d-flex align-items-center justify-content-between py-2">
            <div class="fw-semibold sms-header-text"><?= h($attendance_date) ?> <span class="text-muted fw-normal small ms-2"><?= count($rows) ?> staff</span></div>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-sm btn-outline-success" onclick="markAll('present')">All Present</button>
                <button type="button" class="btn btn-sm btn-outline-danger" onclick="markAll('absent')">All Absent</button>
                <button type="button" class="btn btn-sm btn-outline-info" onclick="markHoliday()"><i class="bi bi-calendar-event"></i> Mark All Holiday</button>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-sm table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Staff Member</th>
                            <th class="text-center" style="width:100px;"><span class="text-success">Present</span></th>
                            <th class="text-center" style="width:100px;"><span class="text-danger">Absent</span></th>
                            <th class="text-center" style="width:100px;"><span class="text-warning">Late</span></th>
                            <th class="text-center" style="width:100px;"><span class="text-secondary">Excused</span></th>
                            <th class="text-center" style="width:100px;"><span class="text-info">Holiday</span></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $i = 1; foreach ($rows as $r):
                        $sid = (int)$r['staff_profile_id'];
                        $cur = (string)($r['attendance_status'] ?? 'present');
                        if ($r['attendance_status'] === null) $cur = 'present';
                    ?>
                        <tr id="srow_<?= $sid ?>" class="<?= $cur === 'absent' ? 'table-danger' : ($cur === 'late' ? 'table-warning' : ($cur === 'excused' ? 'table-secondary' : ($cur === 'holiday' ? 'table-info' : ''))) ?>">
                            <td class="text-muted small"><?= $i++ ?></td>
                            <td>
                                <div class="fw-semibold"><?= h($r['full_name'] ?? '') ?></div>
                                <?php if ($r['title'] ?? ''): ?>
                                    <div class="text-muted small"><?= h($r['title']) ?></div>
                                <?php endif; ?>
                            </td>
                            <?php foreach (['present','absent','late','excused','holiday'] as $status): ?>
                            <td class="text-center">
                                <input class="form-check-input staff-radio"
                                       type="radio"
                                       name="status[<?= $sid ?>]"
                                       value="<?= $status ?>"
                                       data-row="srow_<?= $sid ?>"
                                       data-status="<?= $status ?>"
                                       <?= $cur === $status ? 'checked' : '' ?>
                                       onchange="highlightRow(this)">
                            </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer bg-white d-flex justify-content-between align-items-center">
            <div class="text-muted small" id="staff_att_summary"></div>
            <button class="btn btn-primary px-4" type="submit">Save Attendance</button>
        </div>
    </div>
</form>

<script>
function highlightRow(radio) {
    var row = document.getElementById(radio.dataset.row);
    row.className = '';
    if (radio.dataset.status === 'absent')  row.className = 'table-danger';
    if (radio.dataset.status === 'late')    row.className = 'table-warning';
    if (radio.dataset.status === 'excused') row.className = 'table-secondary';
    if (radio.dataset.status === 'holiday') row.className = 'table-info';
    updateSummary();
}
function markAll(status) {
    document.querySelectorAll('input[type=radio][value="' + status + '"].staff-radio').forEach(function(r) {
        r.checked = true;
        highlightRow(r);
    });
}
function markHoliday() {
    if (!confirm('Mark all staff as Holiday for <?= h($attendance_date) ?>? This replaces any attendance already saved for this date.')) return;
    document.getElementById('staffMarkHolidayFlag').value = '1';
    var form = document.getElementById('staffAttForm');
    if (form.requestSubmit) { form.requestSubmit(); } else { form.submit(); }
}
function updateSummary() {
    var counts = {present:0, absent:0, late:0, excused:0, holiday:0};
    document.querySelectorAll('.staff-radio:checked').forEach(function(r) {
        counts[r.value] = (counts[r.value] || 0) + 1;
    });
    document.getElementById('staff_att_summary').innerHTML =
        '<span class="text-success me-3">✓ Present: <strong>' + counts.present + '</strong></span>' +
        '<span class="text-danger me-3">✗ Absent: <strong>' + counts.absent + '</strong></span>' +
        '<span class="text-warning me-3">⏱ Late: <strong>' + counts.late + '</strong></span>' +
        '<span class="text-secondary me-3">Excused: <strong>' + counts.excused + '</strong></span>' +
        '<span class="text-info">Holiday: <strong>' + counts.holiday + '</strong></span>';
}
updateSummary();
</script>

<?php endif; ?>
