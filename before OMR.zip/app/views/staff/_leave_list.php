<?php
// Variables: $leaves, $q, $status
$leaves = $leaves ?? [];
$q = $q ?? '';
$status = $status ?? '';
?>
<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Staff Member</th>
                        <th>Leave Type</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Days</th>
                        <th>Status</th>
                        <th style="width:280px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($leaves)): ?>
                    <tr><td colspan="7" class="text-muted text-center py-4">No leave requests. Click <strong>+ New Request</strong> to add one.</td></tr>
                <?php else: ?>
                    <?php foreach ($leaves as $lr):
                        $lStatus = $lr['status'] ?? 'pending';
                        $badgeClass = match($lStatus) {
                            'approved' => 'bg-success',
                            'rejected' => 'bg-danger',
                            default    => 'bg-warning text-dark',
                        };
                        // Calculate days
                        $days = '—';
                        if (!empty($lr['from_date']) && !empty($lr['to_date'])) {
                            $diff = (strtotime($lr['to_date']) - strtotime($lr['from_date'])) / 86400 + 1;
                            $days = max(0, (int)$diff);
                        }
                    ?>
                        <tr>
                            <td>
                                <div class="fw-semibold"><?= h($lr['staff_full_name'] ?? '') ?></div>
                                <div class="text-muted small"><?= h($lr['staff_title'] ?? '') ?></div>
                            </td>
                            <td class="small"><?= h($lr['leave_type'] ?? 'Leave') ?></td>
                            <td class="small"><?= h($lr['from_date'] ?? '') ?></td>
                            <td class="small"><?= h($lr['to_date'] ?? '') ?></td>
                            <td class="small text-center"><?= $days ?></td>
                            <td><span class="badge <?= $badgeClass ?>"><?= ucfirst($lStatus) ?></span></td>
                            <td>
                                <?php if ($lStatus === 'pending'): ?>
                                    <form method="post" action="<?= h(route_url('staff/approveLeave')) ?>"
                                          class="d-flex gap-1 align-items-center"
                                          data-ajax data-target="#leaveListContainer"
                                          data-confirm="Save leave decision?">
                                        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                        <input type="hidden" name="leave_request_id" value="<?= (int)$lr['id'] ?>">
                                        <input type="hidden" name="q" value="<?= h($q) ?>">
                                        <input type="hidden" name="status" value="<?= h($status) ?>">
                                        <select class="form-select form-select-sm" name="decision" style="width:120px;" required>
                                            <option value="approved">Approve</option>
                                            <option value="rejected">Reject</option>
                                        </select>
                                        <input class="form-control form-control-sm" name="decision_note"
                                               placeholder="Note" style="width:130px;" required>
                                        <button class="btn btn-sm btn-outline-primary" type="submit">Save</button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-muted small"><?= h($lr['latest_decision'] ?? $lStatus) ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
