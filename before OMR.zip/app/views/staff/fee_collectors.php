<?php
// Variables: $staffOptions, $classSections, $staffId, $assignedIds, $assignmentsByClassSection
$staffOptions = $staffOptions ?? [];
$classSections = $classSections ?? [];
$assignedIds = $assignedIds ?? [];
$assignmentsByClassSection = $assignmentsByClassSection ?? [];
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Fee Collection Assignments</h1>
        <div class="text-muted small">Pick a staff member, then choose which classes they can collect fees for from the Teacher Portal.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= h(route_url('staff/index')) ?>">Back</a>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="staff/feeCollectors">
            <div class="col-md-6">
                <label class="form-label fw-semibold">Staff Member</label>
                <select class="form-select" name="staff_profile_id" required>
                    <option value="">— Select staff —</option>
                    <?php foreach ($staffOptions as $st): ?>
                        <option value="<?= (int)$st['id'] ?>" <?= ((int)$staffId === (int)$st['id']) ? 'selected' : '' ?>>
                            <?= h(($st['full_name'] ?? '') . ($st['title'] ? ' · ' . $st['title'] : '')) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2 d-grid">
                <button class="btn btn-primary" type="submit">Load</button>
            </div>
        </form>
    </div>
</div>

<?php if ($staffId > 0): ?>
    <div class="card shadow-sm border-0">
        <div class="card-header bg-white fw-semibold">Classes Assigned for Fee Collection</div>
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr><th>Class</th><th>Section</th><th style="width:120px;">Status</th></tr>
                </thead>
                <tbody>
                <?php if (empty($classSections)): ?>
                    <tr><td colspan="3" class="text-muted text-center py-3">No class sections found.</td></tr>
                <?php else: ?>
                    <?php foreach ($classSections as $cs): ?>
                        <?php $isAssigned = in_array((int)$cs['id'], $assignedIds, true); ?>
                        <tr>
                            <td><?= h($cs['class_name'] ?? '') ?></td>
                            <td><?= h($cs['section_name'] ?? '') ?></td>
                            <td>
                                <form method="post" action="<?= h(route_url('staff/feeCollectors')) ?>">
                                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                    <input type="hidden" name="staff_profile_id" value="<?= (int)$staffId ?>">
                                    <input type="hidden" name="class_section_id" value="<?= (int)$cs['id'] ?>">
                                    <input type="hidden" name="mode" value="<?= $isAssigned ? 'unassign' : 'assign' ?>">
                                    <button type="submit" class="btn btn-sm <?= $isAssigned ? 'btn-success' : 'btn-outline-secondary' ?>">
                                        <?= $isAssigned ? '✓ Assigned' : 'Assign' ?>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php else: ?>
    <div class="card shadow-sm border-0">
        <div class="card-header bg-white fw-semibold d-flex align-items-center justify-content-between">
            <span>All Classes — Fee Collector Overview</span>
            <span class="text-muted small fw-normal">Classes with no teacher assigned are highlighted</span>
        </div>
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Class</th>
                        <th>Section</th>
                        <th style="width:320px;">Teacher</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($classSections)): ?>
                    <tr><td colspan="3" class="text-muted text-center py-3">No class sections found.</td></tr>
                <?php else: ?>
                    <?php foreach ($classSections as $cs): ?>
                        <?php
                        $csId = (int)$cs['id'];
                        $assignedStaff = $assignmentsByClassSection[$csId] ?? [];
                        $isUnassigned = empty($assignedStaff);
                        // A class can technically have more than one collector assigned; the
                        // dropdown below shows/edits the primary (first) one. Any extra
                        // co-assigned teachers are listed underneath so nothing is hidden.
                        $primary = $assignedStaff[0] ?? null;
                        $extraStaff = $isUnassigned ? [] : array_slice($assignedStaff, 1);
                        ?>
                        <tr class="<?= $isUnassigned ? 'table-warning' : '' ?>">
                            <td><?= h($cs['class_name'] ?? '') ?></td>
                            <td><?= h($cs['section_name'] ?? '') ?></td>
                            <td>
                                <form method="post" action="<?= h(route_url('staff/feeCollectors')) ?>" class="d-flex gap-2">
                                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                    <input type="hidden" name="class_section_id" value="<?= $csId ?>">
                                    <input type="hidden" name="from_overview" value="1">
                                    <select class="form-select form-select-sm" name="staff_profile_id" required>
                                        <option value="" <?= $isUnassigned ? 'selected' : '' ?>>— Select teacher —</option>
                                        <?php foreach ($staffOptions as $st): ?>
                                            <?php $isPrimary = $primary && (int)$primary['id'] === (int)$st['id']; ?>
                                            <option value="<?= (int)$st['id'] ?>" <?= $isPrimary ? 'selected' : '' ?>>
                                                <?= h(($st['full_name'] ?? '') . ($st['title'] ? ' · ' . $st['title'] : '')) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" name="mode" value="assign" class="btn btn-sm btn-primary text-nowrap">
                                        <?= $isUnassigned ? 'Assign' : 'Change' ?>
                                    </button>
                                    <?php if (!$isUnassigned): ?>
                                        <button type="submit" name="mode" value="unassign" class="btn btn-sm btn-outline-danger" title="Remove <?= h($primary['full_name'] ?? '') ?> from this class" onclick="return confirm('Remove this teacher from this class?');">&times;</button>
                                    <?php endif; ?>
                                </form>
                                <?php if (!empty($extraStaff)): ?>
                                    <div class="small text-muted mt-1">
                                        Also assigned:
                                        <?php foreach ($extraStaff as $st): ?>
                                            <span class="badge text-bg-secondary"><?= h($st['full_name'] ?? '') ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>
