<?php ?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Staff & HR</h1>
        <div class="text-muted small">Staff profiles, attendance, leave, performance and payroll.</div>
    </div>
</div>

<div class="row g-3">
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= h(route_url('staff/staffProfiles')) ?>">
            <div class="card shadow-sm border-0 h-100 card-hover">
                <div class="card-body">
                    <div class="fs-3 mb-2">👤</div>
                    <div class="fw-semibold mb-1">Staff Profiles</div>
                    <div class="text-muted small">Add and manage staff members.</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= h(route_url('staff/staffAttendance')) ?>">
            <div class="card shadow-sm border-0 h-100 card-hover">
                <div class="card-body">
                    <div class="fs-3 mb-2">📋</div>
                    <div class="fw-semibold mb-1">Staff Attendance</div>
                    <div class="text-muted small">Daily attendance tracking.</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= h(route_url('staff/leaves')) ?>">
            <div class="card shadow-sm border-0 h-100 card-hover">
                <div class="card-body">
                    <div class="fs-3 mb-2">🗓️</div>
                    <div class="fw-semibold mb-1">Leave Requests</div>
                    <div class="text-muted small">Submit and approve leave.</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= h(route_url('staff/performance')) ?>">
            <div class="card shadow-sm border-0 h-100 card-hover">
                <div class="card-body">
                    <div class="fs-3 mb-2">⭐</div>
                    <div class="fw-semibold mb-1">Performance</div>
                    <div class="text-muted small">Record performance summaries and ratings.</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= h(route_url('staff/feeCollectors')) ?>">
            <div class="card shadow-sm border-0 h-100 card-hover">
                <div class="card-body">
                    <div class="fs-3 mb-2">🧾</div>
                    <div class="fw-semibold mb-1">Fee Collection Assignments</div>
                    <div class="text-muted small">Assign classes to staff for Teacher Portal fee collection.</div>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= h(route_url('staff/payroll')) ?>">
            <div class="card shadow-sm border-0 h-100 card-hover">
                <div class="card-body">
                    <div class="fs-3 mb-2">💵</div>
                    <div class="fw-semibold mb-1">Payroll</div>
                    <div class="text-muted small">Monthly salary details and payment history.</div>
                </div>
            </div>
        </a>
    </div>
</div>

<style>
.card-hover { transition: box-shadow 0.15s, transform 0.15s; cursor: pointer; }
.card-hover:hover { box-shadow: 0 4px 16px rgba(0,0,0,0.12) !important; transform: translateY(-2px); }
</style>
