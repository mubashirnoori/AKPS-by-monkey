<?php
// Variables: error, q, staffOptions, reports, scoresByReport
$reports = $reports ?? [];
$scoresByReport = $scoresByReport ?? [];
$indicators = PerformanceModel::INDICATORS;
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Performance Reports</h1>
        <div class="text-muted small">One scorecard per staff member per month: see what they did in the portal, then score each indicator.</div>
    </div>
    <div class="d-flex gap-2">
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPerfModal">+ Add Report</button>
        <a class="btn btn-outline-secondary" href="<?= h(route_url('staff/index')) ?>">Back</a>
    </div>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<!-- Filter -->
<div class="card shadow-sm border-0 mb-3">
    <div class="card-body py-2">
        <form method="get" action="<?= htmlspecialchars(base_url('/index.php'), ENT_QUOTES, 'UTF-8') ?>" class="d-flex gap-2 align-items-center">
            <input type="hidden" name="route" value="staff/performance">
            <input class="form-control form-control-sm" name="q" value="<?= h($q) ?>" placeholder="Search staff name…" style="max-width:260px;">
            <button class="btn btn-sm btn-outline-primary" type="submit">Search</button>
            <?php if ($q): ?><a class="btn btn-sm btn-outline-secondary" href="<?= h(route_url('staff/performance')) ?>">Clear</a><?php endif; ?>
        </form>
    </div>
</div>

<!-- Reports Table -->
<div class="card shadow-sm border-0">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Staff Member</th>
                        <th>Month</th>
                        <th class="text-center" style="width:150px;">Score</th>
                        <th>Summary</th>
                        <th style="width:210px;"></th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($reports)): ?>
                    <tr><td colspan="5" class="text-muted text-center py-4">No reports yet. Click <strong>+ Add Report</strong> to create one.</td></tr>
                <?php else: ?>
                    <?php foreach ($reports as $r):
                        $rating = (int)($r['rating'] ?? 0);
                        $stars = $rating > 0 ? str_repeat('★', min($rating, 5)) . str_repeat('☆', max(0, 5 - $rating)) : '—';
                        $sc = $scoresByReport[(int)$r['id']] ?? [];
                        $ov = $sc ? PerformanceModel::overall(array_map(fn($x) => $x['score'], $sc)) : null;
                        $isMonth = $r['period_start'] && date('Y-m-01', strtotime($r['period_start'])) === $r['period_start'] && $r['period_end'] === date('Y-m-t', strtotime($r['period_start']));
                    ?>
                        <tr>
                            <td>
                                <div class="fw-semibold"><?= h($r['full_name'] ?? '') ?></div>
                                <div class="text-muted small"><?= h($r['title'] ?? '') ?></div>
                            </td>
                            <td class="text-muted small">
                                <?php if ($isMonth): ?><?= h(date('F Y', strtotime($r['period_start']))) ?>
                                <?php else: ?><?= $r['period_start'] ? h($r['period_start']) . ' → ' . h($r['period_end'] ?? '') : '—' ?><?php endif; ?>
                            </td>
                            <td class="text-center">
                                <?php if ($ov): ?><div class="fw-semibold"><?= (int)$ov['percent'] ?>%</div><?php endif; ?>
                                <span class="text-warning" title="<?= $rating ?>/5"><?= $stars ?></span>
                            </td>
                            <td class="text-muted small"><?= h($r['summary'] ?? '') ?></td>
                            <td class="text-end text-nowrap">
                                <?php if ($sc): ?>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="collapse" data-bs-target="#perfd<?= (int)$r['id'] ?>">Details</button>
                                <?php endif; ?>
                                <?php if ($isMonth): ?>
                                    <button type="button" class="btn btn-sm btn-outline-primary perf-edit" data-bs-toggle="modal" data-bs-target="#addPerfModal"
                                            data-staff="<?= (int)$r['staff_profile_id'] ?>" data-month="<?= h(substr($r['period_start'], 0, 7)) ?>">Edit</button>
                                <?php endif; ?>
                                <form method="post" action="<?= h(route_url('staff/performance')) ?>" class="d-inline"
                                      onsubmit="return confirm('Delete this performance report? This cannot be undone.');">
                                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                    <input type="hidden" name="delete_report_id" value="<?= (int)$r['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php if ($sc): ?>
                        <tr class="collapse" id="perfd<?= (int)$r['id'] ?>">
                            <td colspan="5" class="small">
                                <div class="row g-2">
                                <?php foreach ($indicators as $key => $meta): $c = $sc[$key] ?? null; if (!$c) { continue; } ?>
                                    <div class="col-md-6 d-flex justify-content-between gap-2 border-bottom py-1">
                                        <span><?= h($meta[0]) ?><?php if ($c['note'] !== ''): ?> <span class="text-muted">— <?= h($c['note']) ?></span><?php endif; ?></span>
                                        <strong><?= $c['score'] === null ? 'N/A' : (int)$c['score'] . '/5' ?></strong>
                                    </div>
                                <?php endforeach; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add Performance Modal -->
<div class="modal fade" id="addPerfModal" tabindex="-1" aria-labelledby="addPerfModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <form method="post" id="perfForm" action="<?= h(route_url('staff/performance')) ?>">
                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                <div class="modal-header">
                    <h5 class="modal-title" id="addPerfModalLabel">Monthly Performance Report</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3 mb-3">
                        <div class="col-md-8">
                            <label class="form-label fw-semibold">Staff Member *</label>
                            <select class="form-select" name="staff_profile_id" id="perfStaff" required>
                                <option value="">— Select staff —</option>
                                <?php foreach ($staffOptions as $st): ?>
                                    <option value="<?= (int)$st['id'] ?>">
                                        <?= h(($st['full_name'] ?? '') . ($st['title'] ? ' · ' . $st['title'] : '')) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Month *</label>
                            <input class="form-control" type="month" name="month" id="perfMonth" value="<?= h(date('Y-m')) ?>" max="<?= h(date('Y-m')) ?>" required>
                        </div>
                    </div>

                    <div id="perfMsg" class="text-muted small">Pick a staff member to see what they did in the portal this month.</div>

                    <div id="perfBody" class="d-none">
                        <div class="alert alert-info py-2 small mb-3" id="perfSaved" hidden>A report for this month already exists. Saving will replace it.</div>

                        <div class="pf-bar">
                            <div class="pf-legend">
                                <span><b>5</b> Excellent</span><span><b>4</b> Good</span><span><b>3</b> Satisfactory</span><span><b>2</b> Needs improvement</span><span><b>1</b> Poor</span>
                            </div>
                            <button type="button" class="btn btn-sm btn-outline-primary" id="perfAuto" title="Fills the scores the portal can work out. You can still change every one.">Auto-calculate scores</button>
                        </div>

                        <div id="perfRows"></div>

                        <details class="pf-days">
                            <summary>Day-by-day activity</summary>
                            <div class="table-responsive mt-2" style="max-height:240px;overflow:auto;">
                                <table class="table table-sm table-striped mb-0 small">
                                    <thead><tr><th>Date</th><th>Own attendance</th><th class="text-center">Attendance taken</th><th class="text-center">Marks</th><th class="text-center">Fee receipts</th><th class="text-center">Portal</th></tr></thead>
                                    <tbody id="perfDays"></tbody>
                                </table>
                            </div>
                        </details>

                        <label class="form-label fw-semibold mt-3">Summary <span class="text-muted fw-normal">(optional)</span></label>
                        <textarea class="form-control" name="summary" id="perfSummary" rows="2" placeholder="Achievements, areas of improvement…"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="me-auto">
                        <div class="pf-overall">Overall <strong id="perfOverall">—</strong></div>
                        <div class="text-danger small" id="perfErr"></div>
                    </div>
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="perfSave" disabled>Save Report</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    /* The site's fixed top bar (z-index 2000) would otherwise sit on top of this tall modal and hide its title. */
    #addPerfModal { z-index: 2100; }
    .modal-backdrop { z-index: 2090; }
    /* The <form> sits between .modal-content and .modal-body, so make it the scrolling flex column. */
    #perfForm { display: flex; flex-direction: column; min-height: 0; max-height: calc(100vh - 3.5rem); }
    #perfForm .modal-body { flex: 1 1 auto; overflow-y: auto; min-height: 0; }
    .pf-bar { display: flex; align-items: center; justify-content: space-between; gap: .75rem; flex-wrap: wrap; margin-bottom: .75rem; }
    .pf-legend { display: flex; flex-wrap: wrap; gap: .3rem .9rem; font-size: .75rem; color: var(--sms-muted, #97a2b5); }
    .pf-legend b { color: var(--sms-primary, #b8873e); margin-right: .15rem; }
    .pf-item { border: 1px solid var(--sms-border, #37455c); border-radius: .6rem; padding: .75rem .9rem; margin-bottom: .6rem; background: var(--sms-input-bg, #161d27); }
    .pf-item__top { display: flex; align-items: flex-start; justify-content: space-between; gap: .75rem; flex-wrap: wrap; }
    .pf-item__title { font-weight: 600; color: var(--sms-heading, #f4eee0); }
    .pf-item__help { font-size: .75rem; color: var(--sms-muted, #97a2b5); }
    .pf-item__evidence { font-size: .82rem; margin-top: .4rem; padding: .4rem .6rem; border-left: 3px solid var(--sms-border, #37455c); background: rgba(127,127,127,.07); border-radius: 0 .35rem .35rem 0; }
    .pf-auto { display: inline-block; margin-left: .35rem; padding: .05rem .4rem; border-radius: 999px; font-size: .68rem; background: rgba(184,135,62,.2); color: var(--sms-primary, #b8873e); }
    .pf-score { display: inline-flex; gap: .3rem; flex-shrink: 0; }
    .pf-score input { position: absolute; opacity: 0; pointer-events: none; }
    .pf-score label { min-width: 2.1rem; text-align: center; padding: .3rem .5rem; border: 1px solid var(--sms-border, #37455c); border-radius: .45rem; cursor: pointer; font-weight: 600; font-size: .85rem; user-select: none; }
    .pf-score label:hover { border-color: var(--sms-primary, #b8873e); }
    .pf-score input:checked + label { background: var(--sms-primary, #b8873e); border-color: var(--sms-primary, #b8873e); color: #fff; }
    .pf-score input:checked + label.pf-na { background: #6b7688; border-color: #6b7688; }
    .pf-score input:focus-visible + label { outline: 2px solid var(--sms-primary, #b8873e); outline-offset: 1px; }
    .pf-score label.pf-na { font-weight: 500; }
    .pf-note { margin-top: .5rem; padding: .3rem .6rem !important; min-height: 0 !important; height: auto !important; font-size: .85rem; }
    .pf-days { border: 1px solid var(--sms-border, #37455c); border-radius: .5rem; padding: .5rem .75rem; margin-top: .25rem; }
    .pf-days summary { cursor: pointer; font-weight: 600; font-size: .9rem; }
    .pf-overall { font-size: 1.05rem; }
    .pf-overall strong { color: var(--sms-primary, #b8873e); }
</style>

<script>
(function () {
    var staffSel = document.getElementById('perfStaff'), monthIn = document.getElementById('perfMonth'),
        msg = document.getElementById('perfMsg'), body = document.getElementById('perfBody'),
        rows = document.getElementById('perfRows'), days = document.getElementById('perfDays'),
        overall = document.getElementById('perfOverall'), saveBtn = document.getElementById('perfSave'),
        err = document.getElementById('perfErr'), savedNote = document.getElementById('perfSaved'),
        summary = document.getElementById('perfSummary');
    var url = <?= json_encode(route_url('staff/performanceEvidence')) ?>;
    var names = {1: 'Poor', 2: 'Needs improvement', 3: 'Satisfactory', 4: 'Good', 5: 'Excellent'};
    var token = 0, current = null;

    function esc(t) { var d = document.createElement('div'); d.textContent = t == null ? '' : String(t); return d.innerHTML; }
    function value(k) { var c = rows.querySelector('input[name="score[' + k + ']"]:checked'); return c ? c.value : ''; }
    function setValue(k, v) { var r = rows.querySelector('input[name="score[' + k + ']"][value="' + v + '"]'); if (r) r.checked = true; }
    function calc() {
        var sum = 0, n = 0;
        rows.querySelectorAll('input[type=radio]:checked').forEach(function (r) { var v = parseInt(r.value, 10); if (v >= 1 && v <= 5) { sum += v; n++; } });
        overall.textContent = n ? Math.round(sum / n / 5 * 100) + '%  ·  ' + Math.max(1, Math.min(5, Math.round(sum / n))) + ' / 5' : '—';
    }
    function reset(text) {
        body.classList.add('d-none'); saveBtn.disabled = true; msg.textContent = text; msg.classList.remove('d-none'); overall.textContent = '—';
    }
    function load() {
        err.textContent = '';
        if (!staffSel.value || !monthIn.value) { reset('Pick a staff member to see what they did in the portal this month.'); return; }
        var my = ++token;
        reset('Loading…');
        fetch(url + '&staff_profile_id=' + encodeURIComponent(staffSel.value) + '&month=' + encodeURIComponent(monthIn.value), {credentials: 'same-origin'})
            .then(function (r) { return r.json(); })
            .then(function (d) {
                if (my !== token) return;
                if (d.error) { reset(d.error); return; }
                current = d;
                var saved = d.saved ? d.saved.scores : null, html = '';
                Object.keys(d.labels).forEach(function (k) {
                    var ind = d.indicators[k];
                    var note = saved && saved[k] ? saved[k].note : '';
                    var btns = '';
                    [5, 4, 3, 2, 1].forEach(function (n) {
                        btns += '<input type="radio" name="score[' + k + ']" id="s_' + k + n + '" value="' + n + '"><label for="s_' + k + n + '" title="' + names[n] + '">' + n + '</label>';
                    });
                    btns += '<input type="radio" name="score[' + k + ']" id="s_' + k + 'na" value="na"><label class="pf-na" for="s_' + k + 'na" title="Does not apply">N/A</label>';
                    html += '<div class="pf-item"><div class="pf-item__top"><div><div class="pf-item__title">' + esc(d.labels[k].label) + '</div>' +
                        '<div class="pf-item__help">' + esc(d.labels[k].help) + '</div></div><div class="pf-score">' + btns + '</div></div>' +
                        '<div class="pf-item__evidence">' + esc(ind.evidence) + (ind.suggested ? '<span class="pf-auto">auto: ' + ind.suggested + '</span>' : '') + '</div>' +
                        '<input class="form-control form-control-sm pf-note" name="note[' + k + ']" maxlength="255" placeholder="Note (optional)" value="' + esc(note).replace(/"/g, '&quot;') + '"></div>';
                });
                rows.innerHTML = html;
                // Scores start empty; only a saved report pre-fills them. Auto-calculate fills the rest on request.
                if (saved) Object.keys(saved).forEach(function (k) { setValue(k, saved[k].score === null ? 'na' : saved[k].score); });
                var dh = '';
                d.days.forEach(function (x) {
                    var st = x.own ? x.own.charAt(0).toUpperCase() + x.own.slice(1) : '—';
                    dh += '<tr' + (x.off ? ' class="text-muted"' : '') + '><td>' + esc(x.date) + ' ' + esc(x.dow) + (x.off ? ' (off)' : '') + '</td><td>' + esc(st) + '</td><td class="text-center">' +
                        (x.classes || '—') + '</td><td class="text-center">' + (x.marks || '—') + '</td><td class="text-center">' + (x.fees || '—') + '</td><td class="text-center">' + (x.active ? '✓' : '—') + '</td></tr>';
                });
                days.innerHTML = dh;
                summary.value = d.saved ? d.saved.summary : '';
                savedNote.hidden = !d.saved;
                msg.classList.add('d-none'); body.classList.remove('d-none'); saveBtn.disabled = false; calc();
            })
            .catch(function () { if (my === token) reset('Could not load the activity. Please try again.'); });
    }
    // Edit: open the form on that staff member + month; the saved scores load into it.
    document.querySelectorAll('.perf-edit').forEach(function (btn) {
        btn.addEventListener('click', function () {
            staffSel.value = btn.getAttribute('data-staff');
            monthIn.value = btn.getAttribute('data-month');
            load();
        });
    });
    staffSel.addEventListener('change', load);
    monthIn.addEventListener('change', load);
    rows.addEventListener('change', calc);
    // Fills only what the portal can work out (the "auto" badges) and the indicators that do not
    // apply to this person (N/A). Teaching and conduct stay for you to score.
    document.getElementById('perfAuto').addEventListener('click', function () {
        if (!current) return;
        Object.keys(current.indicators).forEach(function (k) {
            var ind = current.indicators[k];
            if (ind.suggested) setValue(k, ind.suggested);
            else if (ind.na) setValue(k, 'na');
        });
        calc();
    });
    document.getElementById('perfForm').addEventListener('submit', function (e) {
        var missing = Object.keys(current ? current.indicators : {}).filter(function (k) { return value(k) === ''; });
        if (missing.length) {
            e.preventDefault();
            err.textContent = 'Choose a score (or N/A) for every indicator (' + missing.length + ' left).';
            var first = rows.querySelector('input[name="score[' + missing[0] + ']"]');
            if (first) first.closest('.pf-item').scrollIntoView({block: 'center'});
        }
    });
    <?php if (!empty($error)): ?>
    document.addEventListener('DOMContentLoaded', function () { new bootstrap.Modal(document.getElementById('addPerfModal')).show(); });
    <?php endif; ?>
})();
</script>