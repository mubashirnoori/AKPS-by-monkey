<?php
// Variables: $staff, $search
$staff = $staff ?? [];
$search = $search ?? '';
?>
<div class="text-muted small mb-2">
    <span class="badge bg-secondary"><?= count($staff) ?></span> staff member(s)
    <?php if ($search !== ''): ?> · filtered by "<?= h($search) ?>"<?php endif; ?>
</div>
<div class="table-responsive">
    <table class="table table-sm table-hover align-middle mb-0">
        <thead class="table-light">
            <tr>
                <th style="width:56px;"></th>
                <th>Full Name</th>
                <th>Title / Role</th>
                <th>Phone</th>
                <th>Address</th>
                <th style="width:130px;">Basic Salary</th>
                <th style="width:260px;">Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php if (empty($staff)): ?>
            <tr><td colspan="7" class="text-muted text-center py-3">No staff profiles yet. Click <strong>+ Add Staff</strong> to create one.</td></tr>
        <?php else: ?>
            <?php foreach ($staff as $s): ?>
                <?php
                $photoUrl = staff_photo_url((int)$s['id']);
                $initials = '';
                foreach (preg_split('/\s+/', trim((string)($s['full_name'] ?? ''))) as $part) {
                    if ($part !== '') { $initials .= mb_strtoupper(mb_substr($part, 0, 1)); }
                    if (mb_strlen($initials) >= 2) { break; }
                }
                ?>
                <tr>
                    <td>
                        <?php if ($photoUrl): ?>
                            <img src="<?= h($photoUrl) ?>" alt="" class="rounded-circle" style="width:36px;height:36px;object-fit:cover;">
                        <?php else: ?>
                            <span class="rounded-circle bg-secondary-subtle text-secondary d-inline-flex align-items-center justify-content-center fw-semibold" style="width:36px;height:36px;font-size:13px;"><?= h($initials ?: '?') ?></span>
                        <?php endif; ?>
                    </td>
                    <td class="fw-semibold"><?= h($s['full_name'] ?? '') ?></td>
                    <td class="text-muted small"><?= h($s['title'] ?? '—') ?></td>
                    <td class="small"><?= h($s['phone'] ?? '—') ?></td>
                    <td class="text-muted small"><?= h($s['address'] ?? '—') ?></td>
                    <td class="small">Rs <?= number_format((float)($s['basic_salary'] ?? 0), 2) ?></td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary" type="button"
                                data-bs-toggle="modal" data-bs-target="#editStaffModal"
                                data-id="<?= (int)$s['id'] ?>"
                                data-name="<?= h($s['full_name'] ?? '') ?>"
                                data-title="<?= h($s['title'] ?? '') ?>"
                                data-phone="<?= h($s['phone'] ?? '') ?>"
                                data-address="<?= h($s['address'] ?? '') ?>"
                                data-photo="<?= h($photoUrl ?? '') ?>"
                                data-initials="<?= h($initials ?: '?') ?>"
                                onclick="openEditStaffModal(this)">Edit</button>
                        <button class="btn btn-sm btn-outline-secondary" type="button"
                                data-bs-toggle="modal" data-bs-target="#salaryModal"
                                data-id="<?= (int)$s['id'] ?>" data-name="<?= h($s['full_name'] ?? '') ?>"
                                data-salary="<?= (float)($s['basic_salary'] ?? 0) ?>"
                                onclick="openSalaryModal(this)">Salary</button>
                        <a class="btn btn-sm btn-outline-primary" href="<?= h(route_url('staff/feeCollectors')) ?>&staff_profile_id=<?= (int)$s['id'] ?>">Fee Classes</a>
                        <form method="post" action="<?= h(route_url('staff/staffProfileDelete')) ?>"
                              data-ajax data-target="#staffProfileListContainer"
                              data-confirm="Delete <?= h(addslashes($s['full_name'] ?? '')) ?>?" class="d-inline">
                            <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                            <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
                            <input type="hidden" name="q" value="<?= h($search) ?>">
                            <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- Edit Staff Modal (shared by all rows) -->
<div class="modal fade" id="editStaffModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="post" action="<?= h(route_url('staff/staffProfileUpdate')) ?>" enctype="multipart/form-data"
                  data-ajax data-target="#staffProfileListContainer" data-close-modal="#editStaffModal">
                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                <input type="hidden" name="id" id="editStaffId" value="">
                <input type="hidden" name="q" value="<?= h($search) ?>">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Staff — <span id="editStaffName"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3 text-center">
                        <div id="editStaffPhotoPreviewWrap" class="mb-2">
                            <img id="editStaffPhotoPreview" src="" alt="" class="rounded-circle d-none" style="width:72px;height:72px;object-fit:cover;">
                            <span id="editStaffInitialsPreview" class="rounded-circle bg-secondary-subtle text-secondary d-inline-flex align-items-center justify-content-center fw-semibold" style="width:72px;height:72px;font-size:22px;"></span>
                        </div>
                        <label class="form-label fw-semibold d-block">Photo</label>
                        <input class="form-control" type="file" name="photo" accept="image/*">
                        <div class="form-text">Leave blank to keep the current photo.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Full Name *</label>
                        <input class="form-control" name="full_name" id="editStaffFullName" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Title / Role</label>
                        <input class="form-control" name="title" id="editStaffTitle">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Phone</label>
                        <input class="form-control" name="phone" id="editStaffPhone">
                    </div>
                    <div class="mb-1">
                        <label class="form-label fw-semibold">Address</label>
                        <input class="form-control" name="address" id="editStaffAddress">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Set Basic Salary Modal (shared by all rows) -->
<div class="modal fade" id="salaryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="post" action="<?= h(route_url('staff/setBasicSalary')) ?>">
                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                <input type="hidden" name="id" id="salaryModalId" value="">
                <input type="hidden" name="q" value="<?= h($search) ?>">
                <div class="modal-header">
                    <h5 class="modal-title">Set Basic Salary — <span id="salaryModalName"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <label class="form-label fw-semibold">Basic Salary (Rs.)</label>
                    <input class="form-control" type="number" step="0.01" min="0" name="basic_salary" id="salaryModalAmount" required>
                    <div class="form-text">Auto-fills the amount in Payroll → Assign Salary. Still editable there.</div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
function openSalaryModal(btn) {
    document.getElementById('salaryModalId').value = btn.dataset.id;
    document.getElementById('salaryModalName').textContent = btn.dataset.name;
    document.getElementById('salaryModalAmount').value = btn.dataset.salary;
}

function openEditStaffModal(btn) {
    document.getElementById('editStaffId').value = btn.dataset.id;
    document.getElementById('editStaffName').textContent = btn.dataset.name;
    document.getElementById('editStaffFullName').value = btn.dataset.name;
    document.getElementById('editStaffTitle').value = btn.dataset.title;
    document.getElementById('editStaffPhone').value = btn.dataset.phone;
    document.getElementById('editStaffAddress').value = btn.dataset.address;

    var img = document.getElementById('editStaffPhotoPreview');
    var initials = document.getElementById('editStaffInitialsPreview');
    if (btn.dataset.photo) {
        img.src = btn.dataset.photo;
        img.classList.remove('d-none');
        initials.classList.add('d-none');
    } else {
        img.classList.add('d-none');
        initials.textContent = btn.dataset.initials || '?';
        initials.classList.remove('d-none');
    }
}
</script>
