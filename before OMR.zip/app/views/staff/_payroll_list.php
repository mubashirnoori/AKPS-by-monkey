<?php
// Variables: rows, summary, counts, yearOverview, month, year, monthName, q
$rows         = $rows ?? [];
$summary      = $summary ?? ['staff' => 0, 'with_salary' => 0, 'net' => 0, 'paid' => 0, 'pending' => 0];
$counts       = $counts ?? ['all' => 0, 'not_generated' => 0, 'unpaid' => 0, 'partial' => 0, 'paid' => 0];
$yearOverview = $yearOverview ?? [];
$month        = (int)($month ?? date('n'));
$year         = (int)($year ?? date('Y'));
$monthName    = $monthName ?? $month;
$q            = $q ?? '';

$shortMonths = [1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'];

$statusMeta = [
    'not_generated' => ['Not generated', 'bg-secondary'],
    'unpaid'        => ['Unpaid',        'bg-danger'],
    'partial'       => ['Partial',       'bg-warning text-dark'],
    'paid'          => ['Paid',          'bg-success'],
];

$paidPct = $summary['net'] > 0 ? min(100, round($summary['paid'] / $summary['net'] * 100)) : 0;
$payableCount = $counts['unpaid'] + $counts['partial'];
?>

<!-- Year strip: which months are paid / pending -->
<div class="card shadow-sm border-0 mb-3">
    <div class="card-body py-3">
        <div class="d-flex flex-wrap align-items-center justify-content-between mb-2">
            <div class="fw-semibold">Year <?= $year ?> at a glance</div>
            <div class="small text-muted">
                <span class="badge bg-success">&nbsp;</span> all paid
                <span class="badge bg-warning ms-2">&nbsp;</span> some pending
                <span class="badge bg-danger ms-2">&nbsp;</span> nothing paid
                <span class="badge bg-secondary ms-2">&nbsp;</span> no salaries yet
            </div>
        </div>
        <div class="row row-cols-4 row-cols-md-6 row-cols-xl-12 g-2">
            <?php foreach ($shortMonths as $num => $label):
                $ov = $yearOverview[$num] ?? null;
                if (!$ov) {
                    $cls = 'btn-outline-secondary'; $sub = '—';
                } else {
                    $allPaid = (int)$ov['paid_count'] >= (int)$ov['staff_count'];
                    $cls = $allPaid ? 'btn-outline-success' : ((float)$ov['paid_total'] > 0 ? 'btn-outline-warning' : 'btn-outline-danger');
                    $sub = (int)$ov['paid_count'] . '/' . (int)$ov['staff_count'] . ' paid';
                }
                if ($num === $month) { $cls = str_replace('btn-outline-', 'btn-', $cls); }
            ?>
                <div class="col">
                    <a class="btn btn-sm <?= $cls ?> w-100 py-1 lh-sm"
                       href="<?= h(base_url('/index.php?route=staff/payroll&salary_month=' . $num . '&salary_year=' . $year)) ?>">
                        <span class="fw-semibold"><?= $label ?></span><br>
                        <span style="font-size:0.7rem;"><?= h($sub) ?></span>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Summary for the selected month -->
<div class="row g-3 mb-3">
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100"><div class="card-body py-3">
            <div class="small text-muted">Staff with salary</div>
            <div class="fs-4 fw-semibold"><?= (int)$summary['with_salary'] ?> <span class="fs-6 text-muted">of <?= (int)$summary['staff'] ?></span></div>
            <?php if ($counts['not_generated'] > 0): ?>
                <div class="small text-warning"><?= (int)$counts['not_generated'] ?> still to set up</div>
            <?php else: ?>
                <div class="small text-success">All staff set up</div>
            <?php endif; ?>
        </div></div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100"><div class="card-body py-3">
            <div class="small text-muted">Total payable</div>
            <div class="fs-4 fw-semibold">Rs. <?= number_format($summary['net'], 0) ?></div>
            <div class="small text-muted"><?= h($monthName) ?> <?= $year ?></div>
        </div></div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100"><div class="card-body py-3">
            <div class="small text-muted">Paid</div>
            <div class="fs-4 fw-semibold text-success">Rs. <?= number_format($summary['paid'], 0) ?></div>
            <div class="progress mt-1" style="height:6px;"><div class="progress-bar bg-success" style="width:<?= $paidPct ?>%"></div></div>
        </div></div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="card border-0 shadow-sm h-100"><div class="card-body py-3">
            <div class="small text-muted">Pending</div>
            <div class="fs-4 fw-semibold <?= $summary['pending'] > 0 ? 'text-danger' : 'text-success' ?>">Rs. <?= number_format($summary['pending'], 0) ?></div>
            <div class="small text-muted"><?= $payableCount ?> staff waiting for payment</div>
        </div></div>
    </div>
</div>

<!-- Staff table -->
<div class="card shadow-sm border-0">
    <div class="card-header bg-white">
        <div class="d-flex flex-wrap gap-2 align-items-center justify-content-between">
            <div class="d-flex flex-wrap gap-1" id="payrollFilters">
                <?php
                $pills = ['all' => 'All', 'unpaid' => 'Unpaid', 'partial' => 'Partial', 'paid' => 'Paid', 'not_generated' => 'Not generated'];
                foreach ($pills as $key => $label): ?>
                    <button type="button" class="btn btn-sm btn-outline-secondary" data-filter="<?= $key ?>">
                        <?= $label ?> <span class="badge bg-secondary ms-1"><?= (int)$counts[$key] ?></span>
                    </button>
                <?php endforeach; ?>
            </div>
            <div class="d-flex flex-wrap gap-2 align-items-center">
                <input type="search" class="form-control form-control-sm" id="payrollSearch" placeholder="Search staff…" style="width:180px;">
                <?php if ($counts['not_generated'] > 0): ?>
                    <form method="post" action="<?= h(base_url('/index.php')) ?>" class="d-inline"
                          onsubmit="return confirm('Create <?= h($monthName) ?> <?= $year ?> salaries for the <?= (int)$counts['not_generated'] ?> staff who have none?\n\nAmounts are copied from each person\'s most recent salary (or their basic salary). Nothing is paid yet.');">
                        <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                        <input type="hidden" name="route" value="staff/payroll">
                        <input type="hidden" name="action" value="generate_all">
                        <input type="hidden" name="salary_month" value="<?= $month ?>">
                        <input type="hidden" name="salary_year" value="<?= $year ?>">
                        <button class="btn btn-sm btn-outline-primary" type="submit">⚡ Generate for all staff</button>
                    </form>
                <?php endif; ?>
                <button type="button" class="btn btn-sm btn-success" id="bulkPayBtn" disabled>Pay selected</button>
            </div>
        </div>
    </div>

    <div class="card-body p-0">
        <?php if (empty($rows)): ?>
            <div class="p-4 text-muted text-center">No staff profiles found. Add staff first, then come back to run payroll.</div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" id="payrollTable">
                <thead>
                    <tr>
                        <th style="width:36px;"><input type="checkbox" class="form-check-input" id="payrollCheckAll" title="Select all visible unpaid"></th>
                        <th>Staff</th>
                        <th class="text-end">Gross</th>
                        <th class="text-end">Deductions</th>
                        <th class="text-end">Net</th>
                        <th class="text-end">Paid</th>
                        <th class="text-end">Balance</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($rows as $r):
                    $st = $r['status'];
                    $hasDetail = !empty($r['detail_id']);
                    $detailId = (int)($r['detail_id'] ?? 0);
                    $gross = (float)($r['gross_amount'] ?? 0);
                    $deduct = (float)($r['deductions'] ?? 0);
                    $salaryDate = $r['salary_created_date'] ?: date('Y-m-d');
                    $payList = array_map(static function ($p) {
                        return [
                            'date' => !empty($p['paid_date']) ? date('d M Y', strtotime($p['paid_date'])) : '—',
                            'amount' => number_format((float)$p['amount'], 2),
                            'method' => ucfirst((string)($p['method'] ?? '')),
                            'note' => (string)($p['note'] ?? ''),
                        ];
                    }, $r['payments']);
                ?>
                    <tr data-status="<?= h($st) ?>" data-name="<?= h(strtolower($r['full_name'] ?? '')) ?>">
                        <td>
                            <?php if ($r['balance'] > 0 && $hasDetail): ?>
                                <input type="checkbox" class="form-check-input payroll-check"
                                       data-id="<?= $detailId ?>" data-balance="<?= h((string)$r['balance']) ?>"
                                       data-name="<?= h($r['full_name']) ?>">
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="fw-semibold"><?= h($r['full_name']) ?></div>
                            <?php if (!empty($r['title'])): ?><div class="small text-muted"><?= h($r['title']) ?></div><?php endif; ?>
                        </td>
                        <?php if ($hasDetail): ?>
                            <td class="text-end"><?= number_format($gross, 2) ?></td>
                            <td class="text-end <?= $deduct > 0 ? 'text-danger' : 'text-muted' ?>"><?= number_format($deduct, 2) ?></td>
                            <td class="text-end fw-semibold"><?= number_format($r['net'], 2) ?></td>
                            <td class="text-end text-success"><?= number_format($r['paid'], 2) ?></td>
                            <td class="text-end <?= $r['balance'] > 0 ? 'text-danger fw-semibold' : 'text-muted' ?>"><?= number_format($r['balance'], 2) ?></td>
                        <?php else: ?>
                            <td colspan="5" class="text-muted small text-center">No salary set for <?= h($monthName) ?> <?= $year ?></td>
                        <?php endif; ?>
                        <td>
                            <span class="badge <?= $statusMeta[$st][1] ?>"><?= $statusMeta[$st][0] ?></span>
                            <?php if ($st === 'paid' && !empty($r['last_paid'])): ?>
                                <div class="small text-muted"><?= h(date('d M Y', strtotime($r['last_paid']))) ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="text-end text-nowrap">
                            <?php if (!$hasDetail): ?>
                                <button type="button" class="btn btn-sm btn-primary"
                                        data-salary-modal data-mode="new"
                                        data-staff-id="<?= (int)$r['staff_profile_id'] ?>" data-name="<?= h($r['full_name']) ?>"
                                        data-gross="<?= h((string)(float)$r['basic_salary']) ?>" data-deduct="0"
                                        data-date="<?= h(date('Y-m-d')) ?>">Set salary</button>
                            <?php else: ?>
                                <?php if ($r['balance'] > 0): ?>
                                    <button type="button" class="btn btn-sm btn-success"
                                            data-pay-modal data-id="<?= $detailId ?>" data-name="<?= h($r['full_name']) ?>"
                                            data-net="<?= h((string)$r['net']) ?>" data-paid="<?= h((string)$r['paid']) ?>"
                                            data-balance="<?= h((string)$r['balance']) ?>">Pay</button>
                                <?php endif; ?>
                                <button type="button" class="btn btn-sm btn-outline-secondary" title="Payment history"
                                        data-history-modal data-name="<?= h($r['full_name']) ?>"
                                        data-payments="<?= h(json_encode($payList)) ?>">🧾</button>
                                <button type="button" class="btn btn-sm btn-outline-secondary" title="Edit salary"
                                        data-salary-modal data-mode="edit"
                                        data-staff-id="<?= (int)$r['staff_profile_id'] ?>" data-name="<?= h($r['full_name']) ?>"
                                        data-gross="<?= h((string)$gross) ?>" data-deduct="<?= h((string)$deduct) ?>"
                                        data-date="<?= h($salaryDate) ?>">✏️</button>
                                <form method="post" action="<?= h(base_url('/index.php')) ?>" class="d-inline"
                                      data-ajax data-target="#payrollListContainer"
                                      data-confirm="Delete <?= h(addslashes($r['full_name'])) ?>'s <?= h($monthName) ?> <?= $year ?> salary record and ALL its payment history? This cannot be undone.">
                                    <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                                    <input type="hidden" name="route" value="staff/payroll">
                                    <input type="hidden" name="action" value="delete_detail">
                                    <input type="hidden" name="salary_month" value="<?= $month ?>">
                                    <input type="hidden" name="salary_year" value="<?= $year ?>">
                                    <input type="hidden" name="salary_detail_id" value="<?= $detailId ?>">
                                    <button class="btn btn-sm btn-outline-danger" type="submit" title="Delete salary record">🗑️</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                    <tr id="payrollNoMatch" style="display:none;"><td colspan="9" class="text-center text-muted p-4">No staff match this filter.</td></tr>
                </tbody>
                <tfoot>
                    <tr class="fw-semibold">
                        <td colspan="4" class="text-end">Totals (<?= h($monthName) ?> <?= $year ?>)</td>
                        <td class="text-end">Rs. <?= number_format($summary['net'], 2) ?></td>
                        <td class="text-end text-success"><?= number_format($summary['paid'], 2) ?></td>
                        <td class="text-end text-danger"><?= number_format($summary['pending'], 2) ?></td>
                        <td colspan="2"></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>
