<?php
// Variables: error, month, year, payrollData
$month = (int)($month ?? date('n'));
$year  = (int)($year ?? date('Y'));
$payrollData = $payrollData ?? [];

$monthNames = [1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',
               7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'];
$monthName = $monthNames[$month] ?? $month;

$prevM = $month === 1 ? 12 : $month - 1;  $prevY = $month === 1 ? $year - 1 : $year;
$nextM = $month === 12 ? 1 : $month + 1;  $nextY = $month === 12 ? $year + 1 : $year;
$navUrl = static function (int $m, int $y): string {
    return base_url('/index.php?route=staff/payroll&salary_month=' . $m . '&salary_year=' . $y);
};
$yearFrom = min($year, (int)date('Y')) - 5;
$yearTo   = max($year, (int)date('Y')) + 1;
$formAction = base_url('/index.php');
$modalFieldStyle = 'background: var(--sms-surface-2, #1f2937); color: var(--sms-text, #e5e7eb); border-color: var(--sms-border, #2a3340);';
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Payroll</h1>
        <div class="text-muted small">Pick a month, see who is paid and who is pending, and record payments.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= h(route_url('staff/index')) ?>">Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= h($error) ?></div>
<?php endif; ?>

<!-- Month navigator -->
<div class="card shadow-sm border-0 mb-3">
    <div class="card-body py-3">
        <form method="get" action="<?= h($formAction) ?>" class="d-flex flex-wrap align-items-center gap-2" id="payrollNavForm">
            <input type="hidden" name="route" value="staff/payroll">
            <a class="btn btn-outline-secondary" href="<?= h($navUrl($prevM, $prevY)) ?>" title="Previous month">‹</a>
            <select class="form-select w-auto" name="salary_month" onchange="this.form.submit()" aria-label="Month">
                <?php foreach ($monthNames as $num => $name): ?>
                    <option value="<?= $num ?>" <?= $num === $month ? 'selected' : '' ?>><?= $name ?></option>
                <?php endforeach; ?>
            </select>
            <select class="form-select w-auto" name="salary_year" onchange="this.form.submit()" aria-label="Year">
                <?php for ($y = $yearTo; $y >= $yearFrom; $y--): ?>
                    <option value="<?= $y ?>" <?= $y === $year ? 'selected' : '' ?>><?= $y ?></option>
                <?php endfor; ?>
            </select>
            <a class="btn btn-outline-secondary" href="<?= h($navUrl($nextM, $nextY)) ?>" title="Next month">›</a>
            <a class="btn btn-outline-primary ms-md-2" href="<?= h($navUrl((int)date('n'), (int)date('Y'))) ?>">This month</a>
            <div class="ms-md-auto fs-5 fw-semibold"><?= h($monthName) ?> <?= $year ?></div>
        </form>
    </div>
</div>

<div id="payrollListContainer">
    <?= $this->renderPartial('staff/_payroll_list', $payrollData) ?>
</div>

<!-- Pay one staff member -->
<div class="modal fade" id="payModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="post" action="<?= h($formAction) ?>" data-ajax data-target="#payrollListContainer" data-close-modal="#payModal">
                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                <input type="hidden" name="route" value="staff/payroll">
                <input type="hidden" name="action" value="pay">
                <input type="hidden" name="salary_month" value="<?= $month ?>">
                <input type="hidden" name="salary_year" value="<?= $year ?>">
                <input type="hidden" name="staff_salary_detail_id" id="pay_detail_id">
                <div class="modal-header">
                    <h5 class="modal-title">Record payment — <span id="pay_name"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row text-center mb-3 small">
                        <div class="col-4"><div class="text-muted">Net</div><div class="fw-semibold" id="pay_net"></div></div>
                        <div class="col-4"><div class="text-muted">Paid</div><div class="fw-semibold text-success" id="pay_paid"></div></div>
                        <div class="col-4"><div class="text-muted">Balance</div><div class="fw-semibold text-danger" id="pay_balance"></div></div>
                    </div>
                    <div class="row g-2">
                        <div class="col-6">
                            <label class="form-label">Date paid *</label>
                            <input class="form-control" type="date" name="paid_date" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label">Method</label>
                            <select class="form-select" name="method">
                                <option value="cash">Cash</option>
                                <option value="bank">Bank</option>
                                <option value="card">Card</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Amount (Rs.) *</label>
                            <input class="form-control" type="number" name="amount" id="pay_amount" step="0.01" min="0.01" required>
                            <div class="form-text">Pre-filled with the full balance. Lower it to record a partial payment.</div>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Note</label>
                            <input class="form-control" name="note" placeholder="Optional">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Record payment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Pay several at once -->
<div class="modal fade" id="bulkPayModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="post" action="<?= h($formAction) ?>" data-ajax data-target="#payrollListContainer" data-close-modal="#bulkPayModal">
                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                <input type="hidden" name="route" value="staff/payroll">
                <input type="hidden" name="action" value="bulk_pay">
                <input type="hidden" name="salary_month" value="<?= $month ?>">
                <input type="hidden" name="salary_year" value="<?= $year ?>">
                <div id="bulk_ids"></div>
                <div class="modal-header">
                    <h5 class="modal-title">Pay selected staff</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-2">Each person will be paid their <strong>full remaining balance</strong> for <?= h($monthName) ?> <?= $year ?>.</p>
                    <ul class="small mb-3" id="bulk_list" style="max-height:160px; overflow:auto;"></ul>
                    <div class="fw-semibold mb-3">Total: <span id="bulk_total"></span></div>
                    <div class="row g-2">
                        <div class="col-6">
                            <label class="form-label">Date paid *</label>
                            <input class="form-control" type="date" name="paid_date" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label">Method</label>
                            <select class="form-select" name="method">
                                <option value="cash">Cash</option>
                                <option value="bank">Bank</option>
                                <option value="card">Card</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Note</label>
                            <input class="form-control" name="note" placeholder="Optional">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Confirm payments</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Set / edit salary (saves for the month shown above; updates if it already exists) -->
<div class="modal fade" id="salaryModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="post" action="<?= h($formAction) ?>">
                <input type="hidden" name="csrf_token" value="<?= h(CSRF::token()) ?>">
                <input type="hidden" name="route" value="staff/payroll">
                <input type="hidden" name="action" value="create_detail">
                <input type="hidden" name="salary_month" value="<?= $month ?>">
                <input type="hidden" name="salary_year" value="<?= $year ?>">
                <input type="hidden" name="staff_profile_id" id="sal_staff_id">
                <div class="modal-header">
                    <h5 class="modal-title"><span id="sal_title"></span> — <?= h($monthName) ?> <?= $year ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3 fw-semibold" id="sal_name"></div>
                    <div class="mb-3">
                        <label class="form-label">Salary date</label>
                        <input type="date" class="form-control" name="salary_created_date" id="sal_date">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Gross amount (Rs.) *</label>
                        <input class="form-control" name="gross_amount" id="sal_gross" type="number" step="0.01" min="0.01" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Deductions (Rs.)</label>
                        <input class="form-control" name="deductions" id="sal_deduct" type="number" step="0.01" min="0" value="0">
                    </div>
                    <div>
                        <label class="form-label">Net payable (Rs.)</label>
                        <input class="form-control" id="sal_net" style="<?= $modalFieldStyle ?>" type="text" readonly>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save salary</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Payment history -->
<div class="modal fade" id="historyModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Payment history — <span id="hist_name"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="text-muted" id="hist_empty">No payments recorded yet.</div>
                <div class="table-responsive">
                    <table class="table table-sm mb-0" id="hist_table">
                        <thead><tr><th>Date</th><th class="text-end">Amount</th><th>Method</th><th>Note</th></tr></thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
(function () {
    var state = { filter: 'all', search: '' };

    function $(id) { return document.getElementById(id); }
    function money(n) { return 'Rs. ' + (parseFloat(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
    function showModal(id) { bootstrap.Modal.getOrCreateInstance($(id)).show(); }

    // ---- Filter pills + live search (client-side, so no reload) ----
    function applyFilter() {
        var table = $('payrollTable');
        if (!table) return;
        var visible = 0;
        table.querySelectorAll('tbody tr[data-status]').forEach(function (tr) {
            var okStatus = state.filter === 'all' || tr.dataset.status === state.filter;
            var okName = !state.search || tr.dataset.name.indexOf(state.search) !== -1;
            tr.style.display = (okStatus && okName) ? '' : 'none';
            if (okStatus && okName) visible++;
            else { var cb = tr.querySelector('.payroll-check'); if (cb) cb.checked = false; }
        });
        $('payrollNoMatch').style.display = visible ? 'none' : '';
        document.querySelectorAll('#payrollFilters [data-filter]').forEach(function (b) {
            var on = b.dataset.filter === state.filter;
            b.classList.toggle('btn-primary', on);
            b.classList.toggle('btn-outline-secondary', !on);
        });
        var s = $('payrollSearch'); if (s && s.value !== state.search) s.value = state.search;
        updateSelection();
    }

    // ---- Row selection for "Pay selected" ----
    function checked() { return Array.prototype.slice.call(document.querySelectorAll('.payroll-check:checked')); }
    function updateSelection() {
        var n = checked().length, btn = $('bulkPayBtn');
        if (btn) { btn.disabled = n === 0; btn.textContent = n ? 'Pay selected (' + n + ')' : 'Pay selected'; }
        var all = $('payrollCheckAll');
        if (all) {
            var boxes = Array.prototype.filter.call(document.querySelectorAll('.payroll-check'), function (c) { return c.closest('tr').style.display !== 'none'; });
            all.checked = boxes.length > 0 && boxes.every(function (c) { return c.checked; });
        }
    }

    document.addEventListener('click', function (e) {
        var t = e.target.closest('[data-filter],[data-pay-modal],[data-salary-modal],[data-history-modal],#bulkPayBtn');
        if (!t) return;

        if (t.dataset.filter) { state.filter = t.dataset.filter; applyFilter(); return; }

        if (t.hasAttribute('data-pay-modal')) {
            $('pay_detail_id').value = t.dataset.id;
            $('pay_name').textContent = t.dataset.name;
            $('pay_net').textContent = money(t.dataset.net);
            $('pay_paid').textContent = money(t.dataset.paid);
            $('pay_balance').textContent = money(t.dataset.balance);
            var amt = $('pay_amount');
            amt.max = t.dataset.balance; amt.value = parseFloat(t.dataset.balance).toFixed(2);
            showModal('payModal');
        } else if (t.hasAttribute('data-salary-modal')) {
            $('sal_staff_id').value = t.dataset.staffId;
            $('sal_title').textContent = t.dataset.mode === 'edit' ? 'Edit salary' : 'Set salary';
            $('sal_name').textContent = t.dataset.name;
            $('sal_date').value = t.dataset.date;
            var g = parseFloat(t.dataset.gross) || 0;
            $('sal_gross').value = g > 0 ? g.toFixed(2) : '';
            $('sal_deduct').value = (parseFloat(t.dataset.deduct) || 0).toFixed(2);
            calcNet();
            showModal('salaryModal');
        } else if (t.hasAttribute('data-history-modal')) {
            $('hist_name').textContent = t.dataset.name;
            var list = []; try { list = JSON.parse(t.dataset.payments || '[]'); } catch (err) {}
            var body = $('hist_table').querySelector('tbody'); body.innerHTML = '';
            list.forEach(function (p) {
                var tr = document.createElement('tr');
                [p.date, 'Rs. ' + p.amount, p.method, p.note || '—'].forEach(function (v, i) {
                    var td = document.createElement('td'); td.textContent = v;
                    if (i === 1) td.className = 'text-end text-success fw-semibold';
                    tr.appendChild(td);
                });
                body.appendChild(tr);
            });
            $('hist_empty').style.display = list.length ? 'none' : '';
            $('hist_table').style.display = list.length ? '' : 'none';
            showModal('historyModal');
        } else if (t.id === 'bulkPayBtn') {
            var boxes = checked(), ids = $('bulk_ids'), ul = $('bulk_list'), total = 0;
            ids.innerHTML = ''; ul.innerHTML = '';
            boxes.forEach(function (c) {
                var i = document.createElement('input');
                i.type = 'hidden'; i.name = 'detail_ids[]'; i.value = c.dataset.id; ids.appendChild(i);
                var li = document.createElement('li');
                li.textContent = c.dataset.name + ' — ' + money(c.dataset.balance); ul.appendChild(li);
                total += parseFloat(c.dataset.balance) || 0;
            });
            $('bulk_total').textContent = money(total);
            showModal('bulkPayModal');
        }
    });

    document.addEventListener('input', function (e) {
        if (e.target.id === 'payrollSearch') { state.search = e.target.value.trim().toLowerCase(); applyFilter(); }
        if (e.target.id === 'sal_gross' || e.target.id === 'sal_deduct') calcNet();
    });
    document.addEventListener('change', function (e) {
        if (e.target.id === 'payrollCheckAll') {
            document.querySelectorAll('.payroll-check').forEach(function (c) {
                if (c.closest('tr').style.display !== 'none') c.checked = e.target.checked;
            });
        }
        if (e.target.classList && (e.target.classList.contains('payroll-check') || e.target.id === 'payrollCheckAll')) updateSelection();
    });

    function calcNet() {
        var g = parseFloat($('sal_gross').value) || 0, d = parseFloat($('sal_deduct').value) || 0;
        $('sal_net').value = (g - d).toFixed(2);
    }

    // After an AJAX pay/delete the list is re-rendered: keep the filter and search the user had.
    document.addEventListener('ajax-content-updated', function (evt) {
        var target = evt.detail && evt.detail.target;
        if (target && target.id === 'payrollListContainer') applyFilter();
    });
    document.addEventListener('DOMContentLoaded', applyFilter);
    if (document.readyState !== 'loading') applyFilter();
})();
</script>
