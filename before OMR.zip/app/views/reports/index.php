<?php
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Reports</h1>
        <div class="text-muted">Student, exam, fees, staff reports and custom generator.</div>
    </div>
</div>

<div class="row g-3">
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(base_url('/index.php?route=reports/studentAttendance'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100"><div class="card-body">
                <div class="fw-semibold mb-1">Student Attendance</div>
                <div class="text-muted small">Daily attendance report + CSV/Print</div>
            </div></div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(base_url('/index.php?route=reports/examMarks'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100"><div class="card-body">
                <div class="fw-semibold mb-1">Exam Marks</div>
                <div class="text-muted small">Marks/grades report + CSV/Print</div>
            </div></div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(base_url('/index.php?route=reports/feeCollections'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100"><div class="card-body">
                <div class="fw-semibold mb-1">Fee Collections</div>
                <div class="text-muted small">Collections report + CSV/Print</div>
            </div></div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(base_url('/index.php?route=reports/staffAttendance'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100"><div class="card-body">
                <div class="fw-semibold mb-1">Staff Attendance</div>
                <div class="text-muted small">Attendance report + CSV/Print</div>
            </div></div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(base_url('/index.php?route=reports/expenses'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100"><div class="card-body">
                <div class="fw-semibold mb-1">Expenses</div>
                <div class="text-muted small">Other expenses + salaries + CSV/Print</div>
            </div></div>
        </a>
    </div>
    <div class="col-md-6 col-lg-4">
        <a class="text-decoration-none" href="<?= htmlspecialchars(base_url('/index.php?route=reports/customGenerator'), ENT_QUOTES, 'UTF-8') ?>">
            <div class="card shadow-sm border-0 h-100"><div class="card-body">
                <div class="fw-semibold mb-1">Custom Generator</div>
                <div class="text-muted small">Choose dataset + export</div>
            </div></div>
        </a>
    </div>
</div>

