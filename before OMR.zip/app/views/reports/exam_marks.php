<?php
// Variables: exams, subjects, examId, subjectId, rows
$routeBase = base_url('/index.php');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Exam Marks Report</h1>
        <div class="text-muted">Export CSV or print to PDF.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=reports/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="reports/examMarks">
            <div class="col-md-6">
                <label class="form-label">Exam</label>
                <select class="form-select" name="exam_id" onchange="this.form.submit()">
                    <?php foreach ($exams as $e): ?>
                        <option value="<?= (int)$e['id'] ?>" <?= ((int)$examId === (int)$e['id']) ? 'selected' : '' ?>><?= h($e['exam_name'] ?? '') ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label">Subject</label>
                <select class="form-select" name="subject_id" onchange="this.form.submit()">
                    <?php foreach ($subjects as $s): ?>
                        <option value="<?= (int)$s['id'] ?>" <?= ((int)$subjectId === (int)$s['id']) ? 'selected' : '' ?>><?= h($s['subject_name'] ?? '') ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </form>

        <div class="mt-3 d-flex gap-2">
            <?php $q = http_build_query(['exam_id'=>$examId,'subject_id'=>$subjectId,'export'=>'csv','dl_token'=>download_token()]); ?>
            <a class="btn btn-outline-primary btn-sm" href="<?= htmlspecialchars($routeBase . '&' . $q, ENT_QUOTES, 'UTF-8') ?>">Export CSV</a>
            <button class="btn btn-outline-secondary btn-sm" type="button" onclick="window.print()">Print</button>
        </div>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-striped mb-0">
                <thead>
                <tr><th>Rank</th><th>Admission</th><th>Student</th><th>Score</th><th>Total</th><th>%</th><th>Grade</th></tr>
                </thead>
                <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="7" class="text-muted">No marks.</td></tr>
                <?php else: ?>
                    <?php $rank = 1; foreach ($rows as $r): ?>
                        <?php
                        $tot = (float)($r['total_marks'] ?? 100);
                        $pct = $tot > 0 ? round((float)($r['score'] ?? 0) / $tot * 100, 1) : 0;
                        ?>
                        <tr>
                            <td class="text-muted"><?= $rank++ ?></td>
                            <td><?= h($r['admission_no'] ?? '') ?></td>
                            <td class="fw-semibold"><?= h(trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? ''))) ?></td>
                            <td><strong><?= h(format_mark($r['score'] ?? 0)) ?></strong></td>
                            <td class="text-muted"><?= h(format_mark($tot)) ?></td>
                            <td><?= h((string)$pct) ?>%</td>
                            <td><span class="badge bg-secondary"><?= h($r['grade_letter'] ?? '—') ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

