<?php
// Variables: dataset, start_date, end_date, headers, rows, total, page, perPage, totalPages
$total = (int)($total ?? count($rows));
$page = max(1, (int)($page ?? 1));
$perPage = (int)($perPage ?? 100);
$totalPages = max(1, (int)($totalPages ?? 1));
$routeBase = base_url('/index.php');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Custom Report Generator</h1>
        <div class="text-muted">Select a dataset, optionally narrow by date, and export.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=reports/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="reports/customGenerator">
            <div class="col-md-3">
                <label class="form-label">Dataset</label>
                <select class="form-select" name="dataset" onchange="this.form.submit()">
                    <?php foreach (['students' => 'Students', 'invoices' => 'Invoices', 'complaints' => 'Complaints'] as $k => $lbl): ?>
                        <option value="<?= h($k) ?>" <?= $dataset === $k ? 'selected' : '' ?>><?= h($lbl) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">From date</label>
                <input type="date" class="form-control" name="start_date" value="<?= h($start_date ?? '') ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">To date</label>
                <input type="date" class="form-control" name="end_date" value="<?= h($end_date ?? '') ?>">
            </div>
            <div class="col-md-3 d-grid">
                <button class="btn btn-outline-primary" type="submit">Apply</button>
            </div>

            <?php $exportQs = http_build_query(['route' => 'reports/customGenerator', 'dataset' => $dataset, 'start_date' => $start_date ?? '', 'end_date' => $end_date ?? '', 'export' => 'csv', 'dl_token' => download_token()]); ?>
            <div class="col-md-6 d-grid mt-2">
                <a class="btn btn-outline-success" href="<?= htmlspecialchars($routeBase . '?' . $exportQs, ENT_QUOTES, 'UTF-8') ?>">
                    <i class="bi bi-download"></i> Export CSV (all <?= (int)$total ?> matching row<?= $total === 1 ? '' : 's' ?>)
                </a>
            </div>
            <div class="col-md-6 d-grid mt-2">
                <button class="btn btn-outline-secondary" type="button" onclick="window.print()">Print</button>
            </div>
        </form>
    </div>
</div>

<div class="text-muted small mb-2">
    Showing <?= count($rows) ?> of <?= (int)$total ?> row(s)
    <?php if (($start_date ?? '') !== '' || ($end_date ?? '') !== ''): ?>
        · date filtered
    <?php endif; ?>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-striped mb-0">
                <thead>
                <tr>
                    <?php foreach ($headers as $h): ?>
                        <th><?= h($h) ?></th>
                    <?php endforeach; ?>
                </tr>
                </thead>
                <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="<?= (int)max(1,count($headers)) ?>" class="text-muted">No rows.</td></tr>
                <?php else: ?>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <?php foreach ($headers as $h): ?>
                                <td><?= h($r[$h] ?? '') ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if ($totalPages > 1): ?>
<nav class="mt-3">
    <ul class="pagination justify-content-center flex-wrap">
        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <?php $url = $routeBase . '?' . http_build_query(['route' => 'reports/customGenerator', 'dataset' => $dataset, 'start_date' => $start_date ?? '', 'end_date' => $end_date ?? '', 'page' => $p]); ?>
            <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                <a class="page-link" href="<?= h($url) ?>"><?= (int)$p ?></a>
            </li>
        <?php endfor; ?>
    </ul>
</nav>
<?php endif; ?>
