<?php
// Variables: start_date, end_date, type, rows, summary
$routeBase = base_url('/index.php?route=reports/expenses');
$summary = $summary ?? ['other_expenses' => 0.0, 'salaries' => 0.0, 'total' => 0.0, 'count' => 0];
$type = $type ?? 'all';

$typeBadge = static function (string $t): string {
    $cls = $t === 'Salary' ? 'info text-dark' : 'warning text-dark';
    return '<span class="badge bg-' . $cls . '">' . h($t) . '</span>';
};
?>

<div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
    <div>
        <h1 class="h4 mb-0">Expenses Report</h1>
        <div class="text-muted">Other Expenses + Salary Payments, combined — export CSV or print to PDF.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= h(base_url('/index.php?route=reports/index')) ?>">Back</a>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= h(base_url('/index.php')) ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="reports/expenses">
            <div class="col-md-3">
                <label class="form-label">Start</label>
                <input class="form-control" type="date" name="start_date" value="<?= h($start_date) ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">End</label>
                <input class="form-control" type="date" name="end_date" value="<?= h($end_date) ?>">
            </div>
            <div class="col-md-3">
                <label class="form-label">Type</label>
                <select class="form-select" name="type">
                    <option value="all" <?= $type === 'all' ? 'selected' : '' ?>>All</option>
                    <option value="expense" <?= $type === 'expense' ? 'selected' : '' ?>>Other Expenses only</option>
                    <option value="salary" <?= $type === 'salary' ? 'selected' : '' ?>>Salaries only</option>
                </select>
            </div>
            <div class="col-md-2 d-grid">
                <button class="btn btn-primary" type="submit">Load</button>
            </div>
        </form>

        <div class="mt-3 d-flex gap-2">
            <?php $exportUrl = $routeBase . '&' . http_build_query(['start_date' => $start_date, 'end_date' => $end_date, 'type' => $type, 'export' => 'csv', 'dl_token' => download_token()]); ?>
            <a class="btn btn-outline-primary btn-sm" href="<?= h($exportUrl) ?>"><i class="bi bi-download me-1"></i>Export CSV</a>
            <button class="btn btn-outline-secondary btn-sm" type="button" onclick="window.print()">Print</button>
        </div>
    </div>
</div>

<div class="row g-3 mb-3">
    <div class="col-6 col-md-3">
        <div class="card shadow-sm border-0 h-100"><div class="card-body">
            <div class="text-muted small">Other Expenses</div>
            <div class="h5 mb-0"><?= number_format($summary['other_expenses'], 2) ?></div>
        </div></div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card shadow-sm border-0 h-100"><div class="card-body">
            <div class="text-muted small">Salaries Paid</div>
            <div class="h5 mb-0"><?= number_format($summary['salaries'], 2) ?></div>
        </div></div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card shadow-sm border-0 h-100"><div class="card-body">
            <div class="text-muted small">Total Outgoing</div>
            <div class="h5 mb-0"><?= number_format($summary['total'], 2) ?></div>
        </div></div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card shadow-sm border-0 h-100"><div class="card-body">
            <div class="text-muted small">Entries</div>
            <div class="h5 mb-0"><?= (int)$summary['count'] ?></div>
        </div></div>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-striped mb-0">
                <thead>
                <tr>
                    <th>Date</th>
                    <th>Type</th>
                    <th>Category</th>
                    <th>Details</th>
                    <th>Amount</th>
                    <th>Method</th>
                </tr>
                </thead>
                <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="6" class="text-muted">No expenses in this date range.</td></tr>
                <?php else: ?>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td><?= h($r['date']) ?></td>
                            <td><?= $typeBadge($r['type']) ?></td>
                            <td><?= h($r['category']) ?></td>
                            <td><?= h($r['details']) ?></td>
                            <td class="fw-semibold"><?= number_format($r['amount'], 2) ?></td>
                            <td class="text-muted small"><?= h($r['method'] ?: '—') ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
                <?php if (!empty($rows)): ?>
                <tfoot>
                <tr class="fw-semibold">
                    <td colspan="4" class="text-end">Total</td>
                    <td><?= number_format($summary['total'], 2) ?></td>
                    <td></td>
                </tr>
                </tfoot>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>
