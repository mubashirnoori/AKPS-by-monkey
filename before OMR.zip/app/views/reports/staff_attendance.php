<?php
// Variables: start_date,end_date,rows,summary,page,perPage,totalPages
$routeBase = base_url('/index.php');
$summary = $summary ?? ['total' => 0, 'present' => 0, 'absent' => 0, 'late' => 0, 'excused' => 0, 'holiday' => 0];
$page = $page ?? 1;
$perPage = $perPage ?? 50;
$totalPages = $totalPages ?? 1;
$attendedCount = $summary['present'] + $summary['late'];
$ratableCount = $summary['total'] - $summary['holiday'];
$attendanceRate = $ratableCount > 0 ? round(($attendedCount / $ratableCount) * 100, 1) : 0;

$statusBadge = static function (string $status): string {
    $map = [
        'present' => 'bg-success',
        'absent'  => 'bg-danger',
        'late'    => 'bg-warning text-dark',
        'excused' => 'bg-info text-dark',
        'holiday' => 'bg-primary',
    ];
    return $map[$status] ?? 'bg-secondary';
};

$pageQueryBase = ['route' => 'reports/staffAttendance', 'start_date' => $start_date, 'end_date' => $end_date];
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Staff Attendance Report</h1>
        <div class="text-muted">Export CSV or print to PDF.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=reports/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="portal-kpis mb-3">
    <div class="portal-kpi portal-kpi--c">
        <div class="portal-kpi__label"><i class="bi bi-list-check"></i> Total Records</div>
        <div class="portal-kpi__value"><?= number_format($summary['total']) ?></div>
        <div class="portal-kpi__hint"><?= h($start_date) ?> — <?= h($end_date) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--b">
        <div class="portal-kpi__label"><i class="bi bi-check-circle"></i> Present</div>
        <div class="portal-kpi__value"><?= number_format($summary['present']) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--e">
        <div class="portal-kpi__label"><i class="bi bi-x-circle"></i> Absent</div>
        <div class="portal-kpi__value"><?= number_format($summary['absent']) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--d">
        <div class="portal-kpi__label"><i class="bi bi-clock-history"></i> Late</div>
        <div class="portal-kpi__value"><?= number_format($summary['late']) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--c">
        <div class="portal-kpi__label"><i class="bi bi-calendar-event"></i> Holiday</div>
        <div class="portal-kpi__value"><?= number_format($summary['holiday']) ?></div>
    </div>
    <div class="portal-kpi portal-kpi--a">
        <div class="portal-kpi__label"><i class="bi bi-graph-up"></i> Attendance Rate</div>
        <div class="portal-kpi__value"><?= $attendanceRate ?>%</div>
        <div class="portal-kpi__hint">Present + Late, of non-holiday days</div>
    </div>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="reports/staffAttendance">
            <div class="col-md-4">
                <label class="form-label">Start</label>
                <input class="form-control" type="date" name="start_date" value="<?= h($start_date) ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">End</label>
                <input class="form-control" type="date" name="end_date" value="<?= h($end_date) ?>">
            </div>
            <div class="col-md-2 d-grid">
                <button class="btn btn-primary" type="submit">Load</button>
            </div>
        </form>

        <div class="mt-3 d-flex gap-2">
            <?php
            // Same fix as reports/student_attendance.php — the link was missing
            // '?route=reports/staffAttendance' entirely (see comment there), which 404'd.
            $q = http_build_query(['route' => 'reports/staffAttendance', 'start_date'=>$start_date,'end_date'=>$end_date,'export'=>'csv','dl_token'=>download_token()]);
            ?>
            <a class="btn btn-outline-primary btn-sm" href="<?= htmlspecialchars($routeBase . '?' . $q, ENT_QUOTES, 'UTF-8') ?>">Export CSV</a>
            <button class="btn btn-outline-secondary btn-sm" type="button" onclick="window.print()">Print</button>
        </div>

        <hr class="my-3">

        <form method="get" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="reports/staffAttendance">
            <input type="hidden" name="export" value="grid_xlsx">
            <input type="hidden" name="dl_token" value="<?= h(download_token()) ?>">
            <div class="col-auto">
                <label class="form-label mb-0 fw-semibold">Attendance Register (Excel, colored)</label>
                <div class="text-muted small">Sundays/configured holidays fill in automatically as "H". Downloads as a colored .xlsx (green Present, red Absent, pink Holiday).</div>
            </div>
            <div class="col-md-2">
                <label class="form-label">Start</label>
                <input class="form-control" type="date" name="grid_start" value="<?= h($start_date) ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">End</label>
                <input class="form-control" type="date" name="grid_end" value="<?= h($end_date) ?>">
            </div>
            <div class="col-md-3 form-check ms-2 mt-4">
                <input type="hidden" name="sunday_off" value="0">
                <input class="form-check-input" type="checkbox" name="sunday_off" id="sundayOffStaff" value="1" checked>
                <label class="form-check-label" for="sundayOffStaff">Mark Sundays as holiday</label>
            </div>
            <div class="col-md-2 d-grid">
                <button class="btn btn-primary btn-sm" type="submit">Export Register (.xlsx)</button>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-header bg-white d-flex align-items-center justify-content-between flex-wrap gap-2">
        <strong>Records</strong>
        <span class="text-muted small">
            <?php if ($summary['total'] > 0): ?>
                Showing <?= number_format((($page - 1) * $perPage) + 1) ?>–<?= number_format(min($page * $perPage, $summary['total'])) ?> of <?= number_format($summary['total']) ?>
            <?php else: ?>
                No records
            <?php endif; ?>
        </span>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-striped mb-0">
                <thead>
                <tr><th>Date</th><th>Staff</th><th>Title</th><th>Status</th></tr>
                </thead>
                <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="4" class="text-muted">No records.</td></tr>
                <?php else: ?>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td><?= h($r['attendance_date'] ?? '') ?></td>
                            <td class="fw-semibold"><?= h($r['full_name'] ?? '') ?></td>
                            <td class="text-muted small"><?= h($r['title'] ?? '') ?></td>
                            <td><span class="badge <?= $statusBadge($r['status'] ?? '') ?>"><?= h(ucfirst($r['status'] ?? '')) ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php if ($totalPages > 1): ?>
<nav class="mt-3">
    <ul class="pagination pagination-sm justify-content-center flex-wrap">
        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
            <a class="page-link" href="<?= h($routeBase . '?' . http_build_query(array_merge($pageQueryBase, ['page' => max(1, $page - 1)]))) ?>">Previous</a>
        </li>
        <?php
        $windowStart = max(1, $page - 2);
        $windowEnd = min($totalPages, $page + 2);
        if ($windowStart > 1): ?>
            <li class="page-item"><a class="page-link" href="<?= h($routeBase . '?' . http_build_query(array_merge($pageQueryBase, ['page' => 1]))) ?>">1</a></li>
            <?php if ($windowStart > 2): ?><li class="page-item disabled"><span class="page-link">…</span></li><?php endif; ?>
        <?php endif; ?>
        <?php for ($p = $windowStart; $p <= $windowEnd; $p++): ?>
            <li class="page-item <?= $p === (int)$page ? 'active' : '' ?>">
                <a class="page-link" href="<?= h($routeBase . '?' . http_build_query(array_merge($pageQueryBase, ['page' => $p]))) ?>"><?= $p ?></a>
            </li>
        <?php endfor; ?>
        <?php if ($windowEnd < $totalPages): ?>
            <?php if ($windowEnd < $totalPages - 1): ?><li class="page-item disabled"><span class="page-link">…</span></li><?php endif; ?>
            <li class="page-item"><a class="page-link" href="<?= h($routeBase . '?' . http_build_query(array_merge($pageQueryBase, ['page' => $totalPages]))) ?>"><?= $totalPages ?></a></li>
        <?php endif; ?>
        <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
            <a class="page-link" href="<?= h($routeBase . '?' . http_build_query(array_merge($pageQueryBase, ['page' => min($totalPages, $page + 1)]))) ?>">Next</a>
        </li>
    </ul>
</nav>
<?php endif; ?>