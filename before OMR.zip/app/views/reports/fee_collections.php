<?php
// Variables: start_date,end_date,rows
$routeBase = base_url('/index.php');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
    <div>
        <h1 class="h4 mb-0">Fee Collections Report</h1>
        <div class="text-muted">Export CSV or print to PDF.</div>
    </div>
    <a class="btn btn-outline-secondary" href="<?= htmlspecialchars(base_url('/index.php?route=reports/index'), ENT_QUOTES, 'UTF-8') ?>">Back</a>
</div>

<div class="card shadow-sm border-0 mb-3">
    <div class="card-body">
        <form method="get" action="<?= htmlspecialchars($routeBase, ENT_QUOTES, 'UTF-8') ?>" class="row g-2 align-items-end">
            <input type="hidden" name="route" value="reports/feeCollections">
            <div class="col-md-4">
                <label class="form-label">Start</label>
                <input class="form-control" type="date" name="start_date" value="<?= h($start_date) ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">End</label>
                <input class="form-control" type="date" name="end_date" value="<?= h($end_date) ?>">
            </div>
            <div class="col-md-2 d-grid">
                <button class="btn btn-primary" type="submit">Load</button>
            </div>
        </form>

        <div class="mt-3 d-flex gap-2">
            <?php $q = http_build_query(['start_date'=>$start_date,'end_date'=>$end_date,'export'=>'csv','dl_token'=>download_token()]); ?>
            <a class="btn btn-outline-primary btn-sm" href="<?= htmlspecialchars($routeBase . '&' . $q, ENT_QUOTES, 'UTF-8') ?>">Export CSV</a>
            <button class="btn btn-outline-secondary btn-sm" type="button" onclick="window.print()">Print</button>
        </div>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-striped mb-0">
                <thead>
                <tr><th>Collected At</th><th>Invoice</th><th>Student</th><th>Admission</th><th>Amount</th><th>Method</th></tr>
                </thead>
                <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="6" class="text-muted">No collections.</td></tr>
                <?php else: ?>
                    <?php foreach ($rows as $r): ?>
                        <tr>
                            <td><?= h($r['collected_at'] ?? '') ?></td>
                            <td class="fw-semibold"><?= h($r['invoice_no'] ?? '') ?></td>
                            <td><?= h(trim(($r['first_name'] ?? '') . ' ' . ($r['last_name'] ?? ''))) ?></td>
                            <td class="text-muted small"><?= h($r['admission_no'] ?? '') ?></td>
                            <td><?= h((string)($r['amount'] ?? 0)) ?></td>
                            <td><?= h($r['method'] ?? '') ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

