# Role-Based Access Control + Student/Teacher/Parent/Accountant Portals

## Latest update: results-publish gate + portal redesign

**Critical fix — marks were visible before official announcement.** Whatever
a teacher/admin entered in Marks Entry was immediately visible on the
Student/Parent portal, with no "publish" step. Fixed:
- `exams` has a new `results_published` flag (default OFF — including for
  every exam that already has marks entered, so nothing leaks retroactively).
- **Academic → Exams** now has a **Publish Results** / **Unpublish** button
  per exam, with a confirmation prompt before publishing ("students and
  parents will immediately be able to see their marks").
- `PortalModel::studentResults()` only returns marks for exams with
  `results_published = 1`. Both the Student and Parent portals now show a
  neutral status banner — *"N exam(s) awaiting official result
  announcement"* — when there are unpublished marks, without revealing any
  score. The banner disappears once published.
- Migration: `db/migrate_v9_results_publish.sql` (also appended to
  `schema.sql`).

**Portal redesign — Student, Parent, Teacher, Accountant.** The portals were
using plain generic Bootstrap cards while the rest of the app (the Admin
financial dashboard) had a custom, polished look — that mismatch was the
"doesn't look good" problem. Rather than inventing a new style, I extended
the app's *existing* dashboard design system (the `.fo-dash`/`.fo-kpi`
classes) into a matching `.portal-*` set in `public/assets/css/app.css`:
- A hero header per portal (avatar initials, name, role badge).
- Colored KPI tiles (attendance %, pending fees, published results count,
  courses, etc. — different metrics per role).
- Icon-led section cards instead of plain `<h6>` headers.
- Consistent empty states with icons instead of a bare "No X yet." line.
- Parent's child-switcher is now pill-style tabs instead of a plain link row.

All existing functionality (leave apply, invoice eye-icon, tracked video
player, timetable, courses) was preserved exactly — this was a visual
rebuild, not a feature change.

## Already-fixed by the time this update was written

Two issues that came up in conversation — the Generate Invoices "Months"
panel rendering with unreadable white-on-white checkboxes, and no way to
tell a Feb-2026 invoice apart from a Feb-2027 invoice under a different
Academic Year — were **already fixed** in the project state this update
builds on (`FeeService::resolveBillingYear()` now derives the correct
calendar year from the selected Academic Year's start date, and the Months
panel uses the app's dark theme variables). Verified clean; no further
action was needed there.

---

## What changed

**1. New self-service portals** (`app/controllers/PortalController.php`, views in
`app/views/dashboard/portal_*.php`). After login, non-Admin roles are sent to
`route=portal/index` instead of the admin dashboard:

- **Student** — own profile, attendance %, exam results, fee invoices (paid/pending),
  timetable, and any Online Courses assigned to them. Nothing else.
- **Parent** — same as Student, but for each of their own linked children only
  (switch between children with tabs).
- **Teacher** — their assigned subjects/classes, headcount per class, their own
  attendance/leave/performance records, and a scoped link into Marks Entry.
- **Accountant** — fee collection totals (today/month), pending dues, recent
  collections — nothing from HR/payroll/settings/users.
- **Admin** — unchanged, still sees the full institute-wide financial dashboard.

**2. Row-level scoping added to existing screens**, not just new pages:
- `academic/marksEntry` now restricts a Teacher's class/subject dropdowns — and
  blocks the save — to only their own assigned subjects (`staff_subject_assignments`).
- `academic/certificate` (report card printing) previously had **no permission
  check at all** — any logged-in user (including a Student) could view another
  student's report card by editing the URL. Now requires `academic.manage`, and a
  Teacher can only print for students in their own classes.
- `academic/idCard` previously had **no permission check at all** and listed every
  student with photo + personal details. Now Admin-only.
- Institute-wide setup screens (Subjects, Exam Types/Groups, Grade Settings,
  Classes/Sections, Teacher-Subject Assignment, full Timetable management) are
  now Admin-only, since Teacher only needs Marks Entry day-to-day.

**3. Tightened role permissions** (`db/schema.sql` "v4" section / standalone
`db/migrate_v4_portal_rbac.sql`):
- Removed `reports.view` from Student, Parent, Teacher, Accountant — that
  permission opened school-wide reports (all students' attendance/marks, and
  even other staff's attendance) to any of those roles.
- Removed `students.view` / `fees.view` from Parent, and `students.view` from
  Teacher — those exposed the **full admin list of every student** in the
  school. Portal replaces this with each person's own scoped data.
- Added a new `portal.access` permission, granted to all five roles.

**4. Sidebar now hides modules a role can't use** (`app/views/layout.php`) —
previously every nav link (Students, Fees, Staff & HR, Users & Roles, Reports,
Settings) was shown to every logged-in user regardless of permission.

**5. "Link to Record" on Users & Roles** (`Users & Roles → Users`) — this is the
important part to actually use the system:
- The schema already had `students.user_id`, `staff_profiles.user_id`,
  `guardians.user_id`, but nothing in the app ever set them.
- The Create/Edit User form now has three dropdowns: *Link to Student*, *Link to
  Staff Member*, *Link to Guardian*. This is what tells the Portal "this login
  belongs to this student/teacher/parent." **A Student/Teacher/Parent login with
  no link shows a friendly "not linked yet" screen instead of data.**

**6. Online Courses** (new, under Academic → "Online Courses"): Admin/Teacher can
create a course and assign it to specific students; a Teacher can only assign to
students in their own classes. Assigned students see it on their Student Portal.

## To apply this on your server

1. Upload the updated files (overwrite the old ones).
2. Re-run `db/schema.sql` (via `install/install.php`, or import it again — every
   statement is written to be safe to re-run) **or** just import the smaller
   `db/migrate_v4_portal_rbac.sql` if you don't want to touch anything else.
3. Go to **Users & Roles → Users**, edit each Student/Teacher/Parent account, and
   set its "Link to Record" dropdown. Until this is done, that login sees the
   "not linked yet" placeholder.
4. Ask anyone already logged in to log out and back in — permission checks are
   cached per session, so an existing session may not see the new restrictions
   until it refreshes.

## New: Online Course Resources (lectures, live classes, documents)

Under **Academic → Online Courses**, each course now has a **Resources**
button (Admin + Teacher). There you can add:
- **Video Lecture** — a recorded lecture link
- **Live Class** — a scheduled Zoom/Meet/Teams link with a date/time; the
  Student portal shows "Upcoming" and a red **Join** button before it starts,
  and **Recording** afterward
- **Document** — a PDF/notes link
- **Link** — any reference link

Assigned students (and their parents, via the Parent portal) see these listed
under each course, ordered by scheduled time.

## New: Apply for Leave (Student + Teacher self-service)

- **Teacher portal** and **Student portal** now have an "Apply for Leave" form
  (from/to date, type, note). Submitting it always uses the logged-in
  person's own linked staff/student record — never a posted ID — so nobody
  can file leave on someone else's behalf.
- Staff leave requests still land in the existing **Staff & HR → Leave
  Requests** admin screen, unchanged.
- Student leave requests land in a new **Students → Leave Requests** admin
  screen (Admin only), with the same approve/reject flow.
- Both portals show a "My Leave Requests" list with status (pending/approved/
  rejected).

## Fix: Guardian linking UX (Users & Roles → Users)

Previously the "Link to Guardian" dropdown just listed guardian names —
impossible to tell which parent belonged to which student in a large list.
Now:
- Each guardian option shows **"Parent of: <child names>"**, or a
  **"⚠ no child linked yet"** warning if that guardian hasn't been attached to
  any student yet (via Students → Guardians).
- The **Link to Student** dropdown now reciprocally shows **"— Guardian:
  <name>"** next to each student, so you can cross-check from either side.

## New: Invoice detail view (eye icon) on Student/Parent portals

Good catch — the fee table only showed totals, with no way to see *which*
months an invoice actually covers. Each row now has an eye icon that opens a
detail page showing:
- Every line item, with the billing month shown as a small badge (e.g.
  "Tuition — August 2026") — this is exactly the `billing_month` data the v5
  fix added, now surfaced instead of only being used internally for
  duplicate-prevention.
- Any late fine applied.
- Full payment history (date, amount, method).

It's a new scoped endpoint (`PortalController::invoiceViewAction`) rather
than reusing the Admin/Accountant invoice screen — it independently verifies
the invoice belongs to the logged-in student, or one of the logged-in
guardian's own linked children, before showing anything.

## New: Video Upload (not just links) + Watch-Progress Tracker

You were right — a pasted link is the only thing that existed before, and
there was no way to know how much a student actually watched. Both are now
in **Academic → Online Courses → Resources**, for the "Video Lecture" type:

- **Choose "Paste a Link" or "Upload Video File"** when adding a video.
  Uploads go to `public/uploads/course_videos/` on your own server (MP4,
  WebM, OGG, or MOV).
- **Only uploaded videos can be tracked** — this is a hard technical limit,
  not a choice: an external YouTube/Vimeo link plays in a page we don't
  control, so there's no reliable way to read its progress. An uploaded video
  plays in a native player on your own server, which *can* be tracked. The
  resource list marks each video "Uploaded — tracked" or "External link" so
  this is obvious at a glance.
- **The Student portal** now shows an inline video player (not just an "Open"
  button) for uploaded videos, with a live progress bar underneath. It
  resumes from where they left off, and reports progress to the server every
  ~8 seconds and on pause/finish — never on every single frame, to keep it
  light. A video is marked "completed" once they've watched 95%+ (rewinding
  to re-watch a section never lowers their recorded percentage).
- **The Parent portal** shows the same progress bar (read-only) for their
  child, without a tracking script of its own.
- **Admin/Teacher** gets a **"Progress"** button on any uploaded video in the
  Resources screen, showing every assigned student's % watched, completion
  status, and last-updated time.

One practical note: video files can be large, and your server's PHP upload
limit (`upload_max_filesize` / `post_max_size` in php.ini) still applies —
if an upload is rejected for being too large, the form tells you plainly and
suggests pasting a link instead (untracked, but works for any size).

## Fix: "Link to Record" UI/UX overhaul + Parent linking via Father's Name

The old screen used three giant native `<select>` dropdowns — with hundreds of
guardians, most showing "⚠ no child linked yet", it was genuinely hard to find
the right one. Two changes:

1. **All three pickers are now type-to-search comboboxes** (Student, Staff,
   and the advanced Guardian override) — type a few letters, click the match.
   No more scrolling a 500-item list.
2. **Parent linking is now student-first, not guardian-first.** The main
   control is *"Link to Parent — search by student"*: you search for the
   **student**, not a disconnected guardian record. On save:
   - If that student already has a guardian on file, the login links to them.
   - If not, one is **auto-created from the student's Father's Name** (already
     on the student's profile) — no separate guardian record needs to exist
     first.
   - A collapsed **"Advanced: link a specific existing guardian record
     instead"** section still exists underneath for edge cases (e.g. giving
     the mother her own separate login).

Related: `father_name`, `cnic_no`, `board_registration_no`, `roll_number`,
`fee_discount_percent`, `fee_discount_is_percent` were already columns on your
live `students` table (used throughout student create/edit) but were never in
`db/schema.sql` — that would've made a fresh install fail. Added in the v7
migration; it's a no-op on your existing database.

## Fix: overlapping leave requests

Your screenshot showed two identical pending "Sick, 2026-07-20 to
2026-07-21" requests — there was no check stopping that. Now, applying for
leave (Student portal, Teacher portal, or the Admin "Staff & HR → Leave
Requests" form) checks for an existing **pending or approved** request for
the same person whose dates overlap at all — e.g. already have 20–25 June on
file, you can't also submit 22–26 June. You get a clear message naming the
conflicting request instead. Rejected/old requests don't block new ones.

## Re: invoice months already covered for any range

You also asked: if you invoice a student March–August, can you still
accidentally generate August alone, or April–August, later? **No — this was
already handled by the v5 fix above.** The duplicate check runs per
individual month, not per date range, so it doesn't matter whether the
original invoice was one month or a six-month range, or whether the repeat
attempt is a single month or a different range — every month is checked
against what's already been invoiced (open/paid) for that student, and only
the genuinely new months go on a new invoice.

## Fix: duplicate invoices for a month already paid/invoiced

You asked directly about this, so it gets its own section. **Before this fix,
the answer was no** — `FeeService::createStudentInvoice()` only checked for
duplicates on one-time fees (like Admission Fee). Monthly/tuition fee lines had
**no duplicate check at all**: if you generated August for a whole class, then
generated August again later (whole class or that one student), it silently
created a second August invoice with no warning.

Now (v5 migration — new `billing_month`/`billing_year` columns on
`fee_invoice_lines`):

- **Single student**: if every selected month/fee for that student is already
  invoiced (status `open` or `paid`), you get a clear message instead of a
  duplicate invoice, e.g. *"Nothing to invoice — already billed: Tuition -
  August (already paid, invoice INV-20260801-abc123)"*. If only *some* months
  are duplicates, those are skipped and only the new months go on the new
  invoice — the success message lists which ones were skipped and why.
- **Whole class**: same logic runs per student. The summary message now
  distinguishes "created", "already up to date" (nothing new to bill), and
  real failures, e.g. *"Created 18 invoice(s) for the class (5 already up to
  date). Some months were already invoiced and skipped for: Ali Raza:
  Tuition - August (already paid, invoice INV-...)"*.

This only affects **newly generated** invoices going forward — it doesn't
retroactively scan/tag old invoice lines (their `billing_month` will be
`NULL`), so very old August invoices created before this update won't be
detected as duplicates if you re-run generation for them. Only invoices
created after this update carries the month/year tag needed for detection.

## Known limitations (given the scope of this pass)

- Report-card printing (`academic/certificate`) is scoped for Teacher by class,
  but Admin can still print for anyone (by design). Student/Parent don't get a
  printable certificate — they see their results in the Portal instead; wiring
  up a self-print certificate view is a reasonable next step if you want it.
- Accountant still sees **all** students' fee data (that's the job), but nothing
  from Staff/HR/Payroll/Settings/Users.
- "Teacher's classes" are derived from `staff_subject_assignments` (which
  subjects they teach); there's no separate "homeroom/class teacher" concept in
  the schema, so if a teacher should see a class they don't formally teach a
  subject in, that link needs to be added via Teacher Assignments first.
