# Project Structure Map — Akhoon Zada School Management System

Read this before diving into the code. It's a plain PHP MVC app (no framework, no
Composer dependencies) — everything is hand-rolled: routing, DB access, auth, views.
That's not a criticism; it means there's no framework documentation to go read
separately — this file + the core files listed below IS the whole framework.

---

## 1. Request lifecycle (read this first — everything else builds on it)

```
Browser request
      │
      ▼
public/index.php                one file every request goes through
      │  - starts the session (hardened cookie flags)
      │  - require's every app/core/*.php file
      │  - registers a global exception handler (never leaks error details)
      │  - hands off to Router
      ▼
app/core/Router.php             reads ?route=controller/action from GET or POST
      │  - "academic/subjects"  →  AcademicController::subjectsAction()
      │  - no route given       →  defaults to dashboard/index
      ▼
app/controllers/*Controller.php the action method runs:
      │  1. Auth::requireLogin()        — bounce to login if not authenticated
      │  2. $this->requirePermission()  — bounce to 403 if role lacks the permission
      │  3. $this->requireCsrf()        — on POST, validate the CSRF token
      │  4. talk to a Model for data
      │  5. $this->render('folder/view', [...data])
      ▼
app/views/layout.php            the shell: sidebar, navbar, flash messages —
      │                         wraps whatever view the controller picked
      ▼
app/views/<folder>/<view>.php   the actual page content, receives $data as
                                 local variables (extract()'d)
```

There is **no separate routes file** — the route string directly maps to a class name
and method name by convention (`students/import` → `StudentsController::importAction()`).
To find "what happens when I click X", search the view for the link's `route=` value,
then jump straight to that method name in the matching controller.

---

## 2. Directory map

```
/
├── index.php                    → just redirects to /public/ (safety net if the
│                                   webserver's doc root is misconfigured to "/")
├── config/
│   └── config.php                app name, DB credentials, mail sender, session
│                                  settings, timezone. Read via require() wherever
│                                  needed — not a singleton, just an array.
├── db/
│   ├── schema.sql                 the full CREATE TABLE statements — the closest
│   │                               thing to documentation of what data exists
│   ├── seed_admin_user.sql        creates the first admin login
│   └── migrate_*.sql              one file per incremental schema change, named
│                                   after what it adds. Most are also applied
│                                   automatically at runtime by an "ensureX()"
│                                   method in the relevant model (see §4) — these
│                                   .sql files are the manual fallback for hosts
│                                   where the DB user lacks ALTER privileges.
├── public/                       ← this is the actual web root (doc root should
│   │                               point here, not to the project root)
│   ├── index.php                  bootstraps the whole app (see §1)
│   ├── admin_tools/                one-off maintenance scripts, NOT part of the
│   │                               normal app flow — see CODE_REVIEW.md, these
│   │                               should be deleted once used
│   ├── assets/                    CSS/JS/images served directly
│   └── uploads/                   student/staff photos, course videos, branding
│                                   assets, backup files — .htaccess here blocks
│                                   anything from executing as PHP
├── app/
│   ├── core/                     the "framework" — read every file in here once,
│   │                               they're all short
│   │   ├── Router.php             ?route= → Controller::action() dispatch
│   │   ├── Controller.php         base class every controller extends: render(),
│   │   │                           renderPartial() (AJAX fragments), requirePermission(),
│   │   │                           requireCsrf(), jsonResponse()
│   │   ├── Auth.php               login/logout, session timeout, current user
│   │   ├── RBAC.php               permission checks + role helpers (isAdmin(),
│   │   │                           isTeacher(), currentStudentId(), etc.) — this is
│   │   │                           also where "which class-sections does this
│   │   │                           teacher teach" type scoping logic lives
│   │   ├── CSRF.php                token generate/validate
│   │   ├── Database.php            thin mysqli wrapper — execute()/fetchAll()/
│   │   │                           fetchOne(), always via prepared statements
│   │   ├── Mailer.php / SmtpMailer.php   outgoing email (password reset, etc.)
│   │   └── helpers.php             global functions used everywhere: h() (escape
│   │                               output), route_url(), redirect_route(),
│   │                               csrf_field(), log_activity(), photo URL helpers
│   ├── config/
│   │   └── menu.php               sidebar navigation structure — one array,
│   │                               drives what each role sees. Edit this to
│   │                               add/remove/reorder sidebar items; permission
│   │                               checks here decide visibility per role.
│   ├── controllers/               one file per module (see §3)
│   ├── models/                    one file per DB entity (see §4) — this is
│   │                               where all SQL lives. Controllers never write
│   │                               raw SQL themselves except in a couple of
│   │                               reporting/export actions.
│   ├── services/                  cross-cutting logic that spans multiple models
│   │   ├── FeeService.php          invoice total recalculation, shared by several
│   │   │                           fee-related controller actions
│   │   └── UserAccountService.php  creating a login account linked to a
│   │                               student/staff/guardian record
│   └── views/                     one folder per module, mirrors controllers/
│       ├── layout.php              the authenticated-page shell (sidebar/navbar)
│       ├── layout_bare.php         standalone page shell (login, password reset —
│       │                           no sidebar/navbar)
│       ├── errors/                 403.php, 404.php
│       ├── academic/, fees/, students/, staff/, users/, settings/,
│       │   reports/, expenses/, activity_log/, dashboard/, auth/
│       │                           page templates + `_partial.php` files (leading
│       │                           underscore = AJAX-fragment partial, rendered
│       │                           via renderPartial() instead of render(), no
│       │                           layout wrapper)
│       └── stubs/                  placeholder pages for not-yet-built features
```

---

## 3. Controllers — one per module

| Controller | Covers |
|---|---|
| `AuthController` | login, logout, forgot/reset password, change password |
| `DashboardController` | the landing page after login (role-specific KPIs) |
| `AcademicController` | classes, sections, subjects, timetable, exams, marks entry, date sheet, online courses — the biggest controller |
| `StudentsController` | student CRUD, guardians, admissions, CSV import, complaints, inquiries |
| `StaffController` | staff CRUD, staff photos, payroll |
| `FeesController` | fee categories, invoices, collection, pending dues, bulk exports |
| `ExpensesController` | school expense tracking |
| `UsersController` | login accounts + role assignment (distinct from `StudentsController`/`StaffController`, which manage the *person* records) |
| `PortalController` | the self-service dashboards Students/Parents/Teachers/Accountants see — "my fees", "my subjects", "my salary", "my performance", etc. |
| `ReportsController` | attendance/marks/fees/staff-attendance report generation + CSV export |
| `SettingsController` | branding, labels, custom fields, backup/restore, clean-data |
| `ActivityLogController` | the audit trail — every `log_activity()` call anywhere in the app ends up here |
| `portal_teacher.php` | ⚠️ not actually a controller — see CODE_REVIEW.md §3. It's a view fragment that happens to live in this folder; don't expect a `PortalTeacherController` class here. |

---

## 4. Models — one per DB entity, this is where the SQL lives

Naming is 1:1 with what they manage: `StudentModel`, `StaffProfileModel`, `SubjectModel`,
`ClassSectionModel`, `FeeInvoiceModel`, `FeeCategoryModel`, `FeeAssignmentModel`,
`ExamModel`, `ExamSubjectScheduleModel`, `MarkModel`, `AttendanceModel`,
`StaffAttendanceModel`, `TimetableModel`, `GuardianModel`, `ComplaintsModel`,
`InquiriesModel`, `LeaveRequestModel`, `ExpenseModel`, `StaffPayrollModel`,
`StaffSubjectAssignmentModel`, `StaffFeeClassModel`, `OnlineCourseModel`,
`PerformanceModel`, `CustomFieldModel`, `PortalModel` (aggregates data for the
self-service dashboards across several tables).

**Pattern worth knowing:** several models have an `ensureXColumn()` /
`ensureXTable()` method (e.g. `SubjectModel::ensureClassIdColumn()`,
`ExamSubjectScheduleModel::ensureTable()`) that runs automatically the first time
the model is used and applies a schema change if it hasn't been applied yet
(`ALTER TABLE ... ADD COLUMN IF NOT EXISTS`-style, wrapped in try/catch so it's a
no-op if already applied or if the DB user lacks privileges). This is why some
`db/migrate_*.sql` files are described as "optional" — the app self-migrates on
first use; the `.sql` file is the manual fallback. When you add a new one of these,
follow the existing pattern (static `$done` flag, try/catch, backfill logic if
needed) rather than assuming a migration must be run by hand.

---

## 5. Roles & permission model

- Roles live in the `roles` table; permissions in `permissions`; the join table
  `role_permissions` maps which role has which permission.
- `RBAC::hasPermission('fees.manage')` is the check used everywhere — permission
  keys read like `<module>.<verb>` (`academic.manage`, `fees.view`, `settings.manage`,
  `academic.bulk_export`, etc.).
- Five roles exist in practice: **Admin**, **Teacher** (also covers Principal),
  **Student**, **Parent**, **Accountant**. `RBAC::isAdmin()` / `isTeacher()` /
  `isStudent()` / `isParent()` / `isAccountant()` are convenience wrappers over the
  role name for the places that need role-specific behavior rather than a generic
  permission check.
- Non-admin roles are automatically scoped to *their own* data:
  `RBAC::currentStudentId()`, `currentGuardianId()`, `currentStaffProfileId()`,
  `currentGuardianChildIds()`, `currentTeacherSubjectIds()`,
  `currentTeacherClassSectionIds()` all resolve "who is this logged-in user, in
  terms of the domain tables" — every portal controller action uses these instead
  of trusting an ID from the URL.

---

## 6. Where things are NOT

A few things a reviewer coming from a framework-based app might look for and not find:

- **No `routes.php`** — routes are the class/method names themselves (§1).
- **No ORM** — models call `Database::execute()`/`fetchAll()`/`fetchOne()` directly
  with hand-written SQL.
- **No Composer / `vendor/`** — the only third-party code is what's under `public/assets/`
  (CSS/JS) and whatever the mailer classes need; there's no PHP package manager involved.
- **No test suite** — nothing under a `tests/` folder currently exists.
- **No `.env` file** — config is a plain PHP array in `config/config.php` (see
  CODE_REVIEW.md re: moving secrets out of this file).

---

## 7. Suggested reading order for a new reviewer

1. `public/index.php` — the whole bootstrap in ~80 lines.
2. `app/core/Router.php`, `Controller.php`, `Auth.php`, `RBAC.php`, `CSRF.php`,
   `Database.php`, `helpers.php` — all short, all worth reading in full.
3. `app/config/menu.php` — tells you every page that exists and who can see it,
   without reading a single controller.
4. Pick one module end-to-end, e.g. Fees: `FeesController.php` →
   `FeeInvoiceModel.php` / `FeeService.php` → `app/views/fees/*.php`. Once one
   module's shape makes sense, the rest follow the same pattern.
5. `db/schema.sql` alongside whichever model you're reading — it's the fastest way
   to see what columns/constraints actually exist without hunting through migration
   history.
