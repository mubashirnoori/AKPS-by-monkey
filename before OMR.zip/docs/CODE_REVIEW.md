# Code Review — Akhoon Zada School Management System

**Scope:** `app/`, `public/`, `config/`, `db/`
**Method:** Manual review of every core framework file (`app/core/*`), all 13 controllers,
targeted grep sweeps across all views/models for known bug patterns (SQL concatenation,
unescaped output, missing auth checks, dangerous PHP functions, file-upload validation),
and spot checks of representative views.
**Not covered:** a line-by-line read of all ~1.1 MB of view templates — see "What wasn't
fully checked" at the end.

Severity key: 🔴 High &nbsp; 🟠 Medium &nbsp; 🟡 Low

---

## Update — fixed in this pass

Everything below marked 🔴/🟠/🟡 in this document has now been fixed in code **except
one**, which needs action on your end because it's not something I can do from inside
your codebase:

- ❗ **DB password rotation — still needs you to do this.** I moved the credential to
  support an environment-variable override (`config/config.php` now reads `getenv('DB_PASS')`
  first, falling back to the old hardcoded value), but the *plaintext value itself is
  still sitting in the file* as the fallback, and it left your server once already in
  the zip you uploaded. Rotating it is a server-side action only you can do — see the
  comment block at the top of `config/config.php` for the exact steps.

Fixed: the `debug`/`display_errors` gap, the branding/logo upload's MIME validation
(and SVG removed from what it accepts), CSV formula-injection guard on every export,
the Router's path-building whitelist, per-IP login throttling, logout now requires
CSRF like everything else, the two leftover `public/admin_tools/` scripts are deleted,
the orphaned `app/controllers/portal_teacher.php` is deleted (see "What was actually
wrong with the Teacher portal" below), the duplicated admin-only-permission check is
now a single `RBAC::requireAdmin()`, the "Clean Data" wipe now requires typing `DELETE`
to confirm (both client- and server-side), and the SQL backup-restore statement
splitter is now quote-aware instead of a naive `;`-plus-newline regex.

---

## What was actually wrong with the Teacher portal

Short answer: **nothing is currently broken for teachers.** What I found is dead code
that could confuse a future developer, not a live bug — but it's worth explaining
precisely, since it's exactly the kind of thing that looks alarming until you trace it.

There were **two different files** both named `portal_teacher.php`:

- `app/views/dashboard/portal_teacher.php` (146 lines) — the one that's actually
  rendered. `PortalController::renderTeacher()` calls
  `$this->render('dashboard/portal_teacher', [...])`, and `Controller::render()`
  resolves that to this exact file. This is a clean KPI-cards-plus-quick-links hub:
  subject/class counts, attendance %, salary status, then links out to separate pages
  for the details (My Subjects & Classes, Fee Collection Classes, My Salary, My
  Performance, My Leaves).
- `app/controllers/portal_teacher.php` (283 lines, now deleted) — an **older, unused**
  version of the same page: it put everything directly on one long page instead —
  full subject table, class headcounts with an inline "Take Attendance" button,
  fee-collection classes, full salary history table, performance reports, and an
  inline "Apply for Leave" form, all on a single dashboard. This matches a comment
  already sitting in `app/config/menu.php` describing exactly this change: the
  detail tables used to live directly on the dashboard, then got moved to their own
  pages under "My Portal" — this file is the leftover "before" version of that move
  that never got deleted.

I confirmed nothing was actually lost in that move — "Take Attendance" is now on the
My Subjects & Classes page, fee collection is on its own page, salary history has its
own page, and the leave-apply form is on My Leaves. Every feature in the old file is
still reachable from the new one, just organized differently.

The only real problem was that this dead file sat inside `app/controllers/` — despite
being a view template, not a controller — where it could mislead anyone editing "the
teacher portal" into changing a file that's never actually loaded. It's deleted now.

---

## 1. Fixed already (in this pass)

### 🔴 Could return to a logged-out account via the Back button
**File:** `app/core/Auth.php`

Logout was actually working correctly server-side — `logout()` clears `$_SESSION`,
expires the cookie, and calls `session_destroy()`. The bug was that the app never sent
`Cache-Control` headers, so after logging out, pressing **Back** could redisplay the
previous page straight from the browser's cache. No request ever reached the server, so
the "are you still logged in?" check never ran — you were looking at a screenshot, not a
live page (any button click or refresh would have sent you straight to the login page).

**Fix applied:** `Auth::requireLogin()` now sends
`Cache-Control: no-store, no-cache, must-revalidate, max-age=0`, `Pragma: no-cache`, and
`Expires: 0` on every authenticated page. This forces the browser to re-request the page
from the server on Back/Forward, so the destroyed session is caught immediately.

### 🟠 Subject names were globally unique instead of per-class
**File:** `app/models/SubjectModel.php`, `app/controllers/AcademicController.php`
(fixed in the previous session — noted here for completeness.) `subjects.subject_name`
had a school-wide `UNIQUE` constraint, so "Urdu" could only exist once in the entire
system. Rescoped to `UNIQUE (class_id, subject_name)` plus an app-level duplicate check
with a friendly error message.

---

## 2. Security findings

### 🔴 Live database password committed in plaintext
**File:** `config/config.php`

```php
'db' => [
    'user' => 'u897128490_sms',
    'pass' => '••••••••••••',   // real production password, in plaintext
    ...
```

This file was inside the project zip. Anyone who ends up with a copy of the codebase
(a backup, a shared zip, a git repo, a contractor's laptop) has your live DB credentials.
Your root `.htaccess` does block direct HTTP access to `config/` as long as
`AllowOverride` is enabled on the server — but that's the only thing standing between
this file and the public internet.

**Recommended:**
1. **Rotate the database password now**, since it left your server in this zip.
2. Move credentials out of version-controlled code entirely — read from environment
   variables (`getenv('DB_PASS')`) or a `.env` file that's excluded from any zip/git
   export you create.
3. Verify on the live server that `AllowOverride All` is actually set for this vhost —
   if it isn't, your `.htaccess` rules are silently ignored and `config/config.php` is
   directly downloadable.

### 🟠 `debug` config flag is dead code — errors may still leak to visitors
**File:** `config/config.php`, `public/index.php`

`'debug' => true` is set but never read anywhere in the app. Your custom
`set_exception_handler()` in `public/index.php` is good — it always shows a generic
message and never leaks exception details. But that handler only catches thrown
exceptions. It does **not** control PHP's own `display_errors` setting, which is never
explicitly turned off in code. If the live server's `php.ini` has `display_errors = On`
(common on shared hosting), a raw PHP warning, notice, or fatal error (e.g. a `TypeError`
from a bad argument) can print a file path and stack trace directly into the page,
bypassing your handler entirely.

**Recommended:** in `public/index.php`, right after loading config:
```php
ini_set('display_errors', $config['app']['debug'] ? '1' : '0');
error_reporting(E_ALL);
ini_set('log_errors', '1');
```
This makes the existing `debug` flag actually do something, and guarantees production
never shows raw PHP errors regardless of server defaults.

### 🟠 Branding/logo upload trusts the file extension, not the file content
**File:** `app/controllers/SettingsController.php` (`brandingAction`, ~line 180)

Every other upload in the app (staff photo, student photo, course video) validates the
**actual file content** via `mime_content_type($tmpName)` and derives the saved
extension from that — so the extension is never attacker-chosen. The branding/logo
upload is the one exception: it takes `pathinfo($origName, PATHINFO_EXTENSION)` — the
extension the uploader *typed in the filename* — and only checks that string against an
allow-list. It also allows `.svg`.

Two issues:
- An SVG file can contain `<script>` tags. If a malicious or compromised admin account
  uploads a crafted "logo.svg", and the file is ever opened directly (not just embedded
  as an `<img>`, e.g. someone right-clicks → "open image in new tab", or it's linked
  elsewhere), the script runs in your site's origin — stored XSS.
- Renaming a non-image file to end in `.png` etc. would currently pass this check
  (the saved filename's *extension* is still forced to a safe value, so this specific
  path can't be used to get a `.php` file executed — but it's still validating the
  wrong thing).

**Recommended:** check `mime_content_type()` here too, the same way `StaffController`
and `StudentsController` already do, and consider dropping `svg` from the allow-list (or
sanitizing it with an SVG-scrubbing library) unless you specifically need vector logos.

### 🟠 Leftover one-off scripts in the public webroot
**File:** `public/admin_tools/backfill_teacher_assignments.php`,
`public/admin_tools/import_timetable_2026.php`

Both are properly gated (`Auth::requireLogin()` + `academic.manage` permission check),
so they're not open to the public — but both are:
- **State-changing GET endpoints with no CSRF token.** Visiting the URL runs a bulk
  database write. If a logged-in admin's browser loads that URL from somewhere else
  (an `<img>` tag on another site, a malicious link), the action fires without their
  intent. Low real-world impact here since both operations are additive/idempotent, but
  it's the same class of bug CSRF protection exists to prevent everywhere else in the app.
- **Explicitly marked "delete this file afterwards" in their own comments**, and both
  are still present. They bypass the app's router entirely, which also means they won't
  show up in any route-level review of "what pages exist."

**Recommended:** delete both now that the one-time imports are done (that's literally
what their own docblocks say to do). If you need to keep this kind of tooling around,
route it through the normal Router/Controller flow instead of a standalone script in
`public/`, so it gets CSRF protection and shows up in the same place as everything else.

### 🟡 CSV exports don't neutralize formula-injection characters
**Files:** every `fputcsv()` call — `ReportsController.php`, `FeesController.php`,
`ActivityLogController.php`, `AcademicController.php`

If any exported field (a student/guardian name, a remark, a description) starts with
`=`, `+`, `-`, or `@`, Excel/LibreOffice will interpret it as a formula when the CSV is
opened, not display it as text. This is the standard "CSV injection" issue — low severity
here since input mostly comes from staff-entered data, not the public, but cheap to fix
and worth doing everywhere you `fputcsv()`:
```php
function csv_safe($v) {
    $v = (string)$v;
    return $v !== '' && in_array($v[0], ['=', '+', '-', '@'], true) ? "'" . $v : $v;
}
```

### 🟡 Router builds the controller file path from the raw `route` parameter
**File:** `app/core/Router.php`

```php
$controllerClass = ucfirst($controllerPart) . 'Controller';
$controllerFile = __DIR__ . '/../controllers/' . $controllerClass . '.php';
```
`$controllerPart` comes straight from `$_GET['route']`/`$_POST['route']` with no
character whitelist before it's concatenated into a filesystem path. In practice this is
low-risk — there's no `../SomethingController.php` file anywhere in the project for an
attacker to reach, and PHP class-name resolution limits what actually loads — but it's
one string-whitelist check away from being airtight:
```php
if (!preg_match('/^[A-Za-z0-9_]+$/', $controllerPart)) { /* 404 */ }
```

### 🟡 Login lockout is per-account, not per-IP
**File:** `app/core/Auth.php`

Five failed attempts locks *that username* for a minute — good. But an attacker can
still try many different usernames from a single IP with no throttling at all, since
nothing tracks failed attempts by IP/source. Consider adding a lightweight IP-based rate
limit in front of `loginAction` (even a simple "N failures per IP per minute" counter
in a table or cache) as a second layer.

### 🟡 Logout is not CSRF-protected
**File:** `app/controllers/AuthController.php` (`logoutAction`)

Purely a nuisance-level issue (forcing someone's session to log out isn't a
confidentiality/integrity risk the way other CSRF issues are), but it's inconsistent
with the rest of the app, where every state-changing action requires a CSRF token.

---

## 3. Functional / correctness issues

### 🟠 SQL backup restore splits on a naive delimiter
**File:** `app/controllers/SettingsController.php` (`backupAction`, restore branch)

```php
$parts = array_filter(array_map('trim', preg_split('/;\\s*\\n/', $sql)));
```
This splits the uploaded `.sql` file on `;` followed by a newline. Any statement whose
**data** contains a semicolon immediately followed by a newline (a text field with a
multi-line value, for instance) will be cut in half mid-statement, corrupting the
restore silently or throwing a confusing error partway through. This is an inherent risk
of hand-rolled SQL splitting — worth being aware of before relying on this for a real
disaster-recovery restore. A proper fix means either shelling out to the `mysql` CLI
(if available on the host) or using a dedicated SQL-statement splitter instead of a
regex.

### 🟡 `cleanDataAction` — destructive action, single click to confirm
**File:** `app/controllers/SettingsController.php`

CSRF-protected and permission-gated, so it's not exploitable — but from a "protect the
admin from themselves" angle, wiping all attendance/marks/fees/complaints/inquiries data
for a module currently only needs the one confirm dialog the frontend JS shows. For
something this irreversible, consider requiring the admin to type the module name (or
similar) to confirm, the way GitHub does for repo deletion.

### 🟡 `portal_teacher.php` is a view, not a controller
**File:** `app/controllers/portal_teacher.php`

This file is 283 lines of HTML-rendering PHP that gets `require`'d as a fragment (it
expects `$profile`, `$subjects`, etc. to already be in scope) — it's a **view partial**,
not a `*Controller` class, despite living in `app/controllers/` and despite the Router
building class names like `PortalTeacherController` from any URL that would reach it.
It never actually gets routed to directly; something elsewhere `require`s it as a
template. Purely a maintainability issue (see the structure map for the recommended fix)
but worth flagging because anyone skimming `app/controllers/` for "what pages exist"
will be misled by it.

### 🟡 `RBAC::requireAdminOnly()`-style guards are duplicated per controller
Only `AcademicController` currently defines a private `requireAdminOnly()` helper.
Other controllers that need the same "admin only" restriction either don't have it or
would need to redefine it. Worth promoting to `RBAC::requireAdmin()` (a static method
next to `RBAC::requirePermission()`) so it's defined once and available everywhere.

---

## 4. What's already solid (so nothing here gets "fixed" by accident)

- **SQL injection:** every single query in every model uses `mysqli` prepared
  statements via the `Database::execute()`/`fetchAll()`/`fetchOne()` wrappers. No raw
  string-concatenated queries were found anywhere in `app/` (the only raw `->query()`
  calls are the backup/restore feature, which is inherent to what that feature does, and
  is permission + CSRF gated).
- **XSS:** the `h()` helper (`htmlspecialchars(..., ENT_QUOTES, 'UTF-8')`) is used
  consistently. Targeted searches for common user-text fields (name, address, remarks,
  email, phone, guardian/relation fields, etc.) echoed without `h()` came back empty.
- **CSRF:** `CSRF::validate()` uses `hash_equals()` (timing-safe comparison) and is
  called on effectively every state-changing POST action.
- **Auth:** bcrypt password hashing, `session_regenerate_id(true)` on login (prevents
  session fixation), account lockout after 5 failed attempts, single-use
  password-reset tokens that expire in 30 minutes and are looked up by hash (not stored
  in plaintext), and the forgot-password flow deliberately gives an identical response
  whether or not the account exists (no username/email enumeration).
- **IDOR:** every Parent/Student portal endpoint checked (`myFeesAction`, course detail,
  `resolvePortalStudentId()`, etc.) verifies a requested `student_id` is actually one of
  the logged-in guardian's own children before using it — never trusts the ID from the
  URL directly.
- **File uploads (everywhere except the branding logo, see above):** extension is
  derived from a validated `mime_content_type()` check, not from user input, so a
  renamed malicious file can't get an executable extension.
- **`public/uploads/.htaccess`** blocks `.php`/`.phtml`/`.cgi`/etc. from executing even
  inside the uploads folder — solid defense-in-depth if a future bug ever did let
  something dangerous get uploaded.
- **No dangerous PHP functions** (`eval`, `exec`, `system`, `shell_exec`, `passthru`,
  `unserialize`) appear anywhere in the codebase.
- Root `.htaccess` already locks down `config/`, `app/`, `db/`, `samples/` from direct
  HTTP access and blocks serving `.sql`/`.env`/`.log`/`.bak`/`.zip` by extension anywhere.

---

## 5. What wasn't fully checked

Given the size of the codebase (~1.1 MB across ~14 view directories), this pass covered
every core/framework file and every controller in full, plus targeted pattern searches
across all views and models for the bug classes above. It did **not** include a
line-by-line manual read of every view template. If you want that level of coverage,
the highest-value next targets would be:
- `app/views/fees/` and `app/views/students/` (largest, most fields, most money-handling)
- Any view that renders data entered through the public-facing parts of the site (there
  currently are none reachable without login, per this review — worth double-checking
  that stays true as features are added)

---

## 6. Priority order if you want to fix things one at a time

1. Rotate the DB password (5 minutes, highest real-world risk if this zip ever leaks).
2. Delete the two `public/admin_tools/*.php` one-off scripts.
3. Wire up `display_errors` to the `debug` config flag.
4. Fix the branding/logo upload to check real MIME type.
5. Everything else (CSV injection guard, Router whitelist, per-IP login throttle,
   backup/restore statement splitting) — no urgency, do opportunistically.
