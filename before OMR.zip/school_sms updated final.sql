-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2026 at 03:33 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `school_sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic_years`
--

CREATE TABLE `academic_years` (
  `id` int(11) NOT NULL,
  `academic_year_label` varchar(20) NOT NULL,
  `session_name` varchar(50) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `academic_years`
--

INSERT INTO `academic_years` (`id`, `academic_year_label`, `session_name`, `start_date`, `end_date`, `is_active`, `created_at`) VALUES
(1, '2026-2027', '2026', '2026-03-02', '2026-12-30', 1, '2026-03-30 18:02:13');

-- --------------------------------------------------------

--
-- Table structure for table `attendance_records`
--

CREATE TABLE `attendance_records` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `class_section_id` int(11) NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `attendance_date` date NOT NULL,
  `status` enum('present','absent','late','excused') NOT NULL DEFAULT 'present',
  `created_by_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance_records`
--

INSERT INTO `attendance_records` (`id`, `student_id`, `class_section_id`, `subject_id`, `attendance_date`, `status`, `created_by_user_id`, `created_at`) VALUES
(1, 496, 1, NULL, '2026-03-30', 'absent', 4, '2026-03-30 00:07:26'),
(2, 485, 1, NULL, '2026-03-30', 'present', 4, '2026-03-30 00:07:26'),
(3, 491, 1, NULL, '2026-03-30', 'present', 4, '2026-03-30 00:07:26'),
(4, 490, 1, NULL, '2026-03-30', 'present', 4, '2026-03-30 00:07:26'),
(5, 497, 1, NULL, '2026-03-30', 'present', 4, '2026-03-30 00:07:26'),
(6, 484, 1, NULL, '2026-03-30', 'present', 4, '2026-03-30 00:07:26'),
(7, 486, 1, NULL, '2026-03-30', 'present', 4, '2026-03-30 00:07:26'),
(8, 481, 1, NULL, '2026-03-30', 'present', 4, '2026-03-30 00:07:26'),
(9, 493, 1, NULL, '2026-03-30', 'late', 4, '2026-03-30 00:07:26'),
(10, 494, 1, NULL, '2026-03-30', 'late', 4, '2026-03-30 00:07:26'),
(11, 483, 1, NULL, '2026-03-30', 'present', 4, '2026-03-30 00:07:26'),
(12, 489, 1, NULL, '2026-03-30', 'present', 4, '2026-03-30 00:07:26'),
(13, 498, 1, NULL, '2026-03-30', 'present', 4, '2026-03-30 00:07:26'),
(14, 488, 1, NULL, '2026-03-30', 'excused', 4, '2026-03-30 00:07:26'),
(15, 495, 1, NULL, '2026-03-30', 'excused', 4, '2026-03-30 00:07:26'),
(16, 482, 1, NULL, '2026-03-30', 'present', 4, '2026-03-30 00:07:26'),
(17, 487, 1, NULL, '2026-03-30', 'present', 4, '2026-03-30 00:07:26'),
(18, 492, 1, NULL, '2026-03-30', 'present', 4, '2026-03-30 00:07:26'),
(19, 496, 1, NULL, '2026-03-29', 'present', 4, '2026-03-30 12:55:51'),
(20, 485, 1, NULL, '2026-03-29', 'present', 4, '2026-03-30 12:55:51'),
(21, 491, 1, NULL, '2026-03-29', 'late', 4, '2026-03-30 12:55:51'),
(22, 490, 1, NULL, '2026-03-29', 'late', 4, '2026-03-30 12:55:51'),
(23, 497, 1, NULL, '2026-03-29', 'present', 4, '2026-03-30 12:55:51'),
(24, 484, 1, NULL, '2026-03-29', 'absent', 4, '2026-03-30 12:55:51'),
(25, 486, 1, NULL, '2026-03-29', 'present', 4, '2026-03-30 12:55:51'),
(26, 481, 1, NULL, '2026-03-29', 'absent', 4, '2026-03-30 12:55:51'),
(27, 493, 1, NULL, '2026-03-29', 'present', 4, '2026-03-30 12:55:51'),
(28, 494, 1, NULL, '2026-03-29', 'present', 4, '2026-03-30 12:55:51'),
(29, 483, 1, NULL, '2026-03-29', 'absent', 4, '2026-03-30 12:55:51'),
(30, 489, 1, NULL, '2026-03-29', 'present', 4, '2026-03-30 12:55:51'),
(31, 498, 1, NULL, '2026-03-29', 'absent', 4, '2026-03-30 12:55:51'),
(32, 488, 1, NULL, '2026-03-29', 'present', 4, '2026-03-30 12:55:51'),
(33, 495, 1, NULL, '2026-03-29', 'excused', 4, '2026-03-30 12:55:51'),
(34, 482, 1, NULL, '2026-03-29', 'present', 4, '2026-03-30 12:55:51'),
(35, 487, 1, NULL, '2026-03-29', 'excused', 4, '2026-03-30 12:55:51'),
(36, 492, 1, NULL, '2026-03-29', 'absent', 4, '2026-03-30 12:55:51');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `name`) VALUES
(14, '10th Arts'),
(13, '10th Science'),
(15, '1st Year Arts'),
(4, '2nd'),
(16, '2nd Year Arts'),
(5, '3rd'),
(6, '4th'),
(7, '5th'),
(8, '6th'),
(9, '7th'),
(10, '8th'),
(12, '9th Arts'),
(11, '9th Science'),
(1, 'Nursery'),
(3, 'One Class'),
(2, 'Prep');

-- --------------------------------------------------------

--
-- Table structure for table `class_sections`
--

CREATE TABLE `class_sections` (
  `id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `academic_year_id` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class_sections`
--

INSERT INTO `class_sections` (`id`, `class_id`, `section_id`, `academic_year_id`, `start_date`, `end_date`) VALUES
(1, 1, 1, NULL, '2026-03-02', '2026-12-31'),
(2, 2, 1, NULL, '2026-03-02', '2026-03-31'),
(3, 3, 1, NULL, NULL, NULL),
(4, 4, 1, NULL, NULL, NULL),
(5, 5, 1, NULL, NULL, NULL),
(6, 6, 1, NULL, NULL, NULL),
(7, 7, 1, NULL, NULL, NULL),
(8, 8, 1, NULL, NULL, NULL),
(9, 9, 1, NULL, NULL, NULL),
(10, 10, 1, NULL, NULL, NULL),
(11, 12, 1, NULL, NULL, NULL),
(12, 11, 1, NULL, NULL, NULL),
(13, 13, 1, NULL, NULL, NULL),
(14, 15, 1, NULL, NULL, NULL),
(15, 16, 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `submitted_by_user_id` int(11) DEFAULT NULL,
  `title` varchar(150) NOT NULL,
  `complaint_text` text NOT NULL,
  `status` enum('open','in_review','resolved','closed') NOT NULL DEFAULT 'open',
  `resolution_text` text DEFAULT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `custom_fields`
--

CREATE TABLE `custom_fields` (
  `id` int(11) NOT NULL,
  `scope` enum('user','student','staff') NOT NULL,
  `field_key` varchar(120) NOT NULL,
  `label_text` varchar(200) NOT NULL,
  `field_type` enum('text','number','date','select','textarea') NOT NULL DEFAULT 'text',
  `options_text` text DEFAULT NULL,
  `is_required` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `custom_field_values`
--

CREATE TABLE `custom_field_values` (
  `id` int(11) NOT NULL,
  `custom_field_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `staff_profile_id` int(11) DEFAULT NULL,
  `value_text` longtext NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `id` int(11) NOT NULL,
  `exam_group_id` int(11) NOT NULL,
  `academic_year_id` int(11) DEFAULT NULL,
  `class_section_id` int(11) DEFAULT NULL,
  `exam_name` varchar(120) NOT NULL,
  `scheduled_date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `is_locked` tinyint(4) NOT NULL DEFAULT 0,
  `created_by_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `total_marks` int(10) UNSIGNED DEFAULT NULL COMMENT 'Default total marks for this exam (can vary per subject)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`id`, `exam_group_id`, `academic_year_id`, `class_section_id`, `exam_name`, `scheduled_date`, `start_time`, `end_time`, `is_locked`, `created_by_user_id`, `created_at`, `updated_at`, `total_marks`) VALUES
(1, 2, NULL, 1, 'Monthly Test of March', '2026-03-30', '10:29:00', '11:29:00', 0, 4, '2026-03-28 22:29:32', NULL, NULL),
(2, 2, NULL, 2, 'Monthly Test of March', '2026-03-31', '11:31:00', '00:31:00', 0, 4, '2026-03-30 11:38:05', NULL, 50);

-- --------------------------------------------------------

--
-- Table structure for table `exam_groups`
--

CREATE TABLE `exam_groups` (
  `id` int(11) NOT NULL,
  `exam_type_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exam_groups`
--

INSERT INTO `exam_groups` (`id`, `exam_type_id`, `name`, `sort_order`) VALUES
(2, 1, 'Monthly', 1);

-- --------------------------------------------------------

--
-- Table structure for table `exam_rules`
--

CREATE TABLE `exam_rules` (
  `id` int(11) NOT NULL,
  `exam_group_id` int(11) NOT NULL,
  `passing_percentage` decimal(5,2) NOT NULL DEFAULT 50.00,
  `passing_description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exam_rules`
--

INSERT INTO `exam_rules` (`id`, `exam_group_id`, `passing_percentage`, `passing_description`, `created_at`) VALUES
(1, 2, 44.00, NULL, '2026-03-28 22:28:42');

-- --------------------------------------------------------

--
-- Table structure for table `exam_types`
--

CREATE TABLE `exam_types` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exam_types`
--

INSERT INTO `exam_types` (`id`, `name`, `description`) VALUES
(1, 'Test', 'Monthly or Weekly'),
(2, 'Exam', 'Quaterly');

-- --------------------------------------------------------

--
-- Table structure for table `fee_assignments`
--

CREATE TABLE `fee_assignments` (
  `id` int(11) NOT NULL,
  `fee_category_id` int(11) NOT NULL,
  `academic_year_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `class_section_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ;

--
-- Dumping data for table `fee_assignments`
--

INSERT INTO `fee_assignments` (`id`, `fee_category_id`, `academic_year_id`, `student_id`, `class_section_id`, `amount`, `description`, `created_at`) VALUES
(24, 1, NULL, 576, NULL, 3000.00, '', '2026-03-30 11:48:44'),
(25, 1, NULL, 534, NULL, 2500.00, '', '2026-03-30 12:30:39'),
(26, 1, NULL, 574, NULL, 3000.00, '', '2026-03-30 12:31:19');

-- --------------------------------------------------------

--
-- Table structure for table `fee_categories`
--

CREATE TABLE `fee_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_one_time` tinyint(4) NOT NULL DEFAULT 0,
  `is_tuition` tinyint(4) NOT NULL DEFAULT 0,
  `is_admission` tinyint(4) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fee_categories`
--

INSERT INTO `fee_categories` (`id`, `name`, `description`, `is_one_time`, `is_tuition`, `is_admission`, `sort_order`) VALUES
(1, 'Tuition Fee', 'Monthly Fee', 0, 0, 0, 0),
(2, 'Admission Fee', 'One time Only', 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `fee_collections`
--

CREATE TABLE `fee_collections` (
  `id` int(11) NOT NULL,
  `fee_invoice_id` int(11) NOT NULL,
  `collected_at` datetime NOT NULL DEFAULT current_timestamp(),
  `amount` decimal(10,2) NOT NULL,
  `method` enum('cash','card','bank') NOT NULL DEFAULT 'cash',
  `notes` varchar(255) DEFAULT NULL,
  `collected_by_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fee_collections`
--

INSERT INTO `fee_collections` (`id`, `fee_invoice_id`, `collected_at`, `amount`, `method`, `notes`, `collected_by_user_id`) VALUES
(13, 116, '2026-03-30 11:49:02', 3000.00, 'cash', '', 4);

-- --------------------------------------------------------

--
-- Table structure for table `fee_custom_fines`
--

CREATE TABLE `fee_custom_fines` (
  `id` int(11) NOT NULL,
  `fee_invoice_id` int(11) NOT NULL,
  `fine_type` varchar(120) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `added_at` datetime NOT NULL DEFAULT current_timestamp(),
  `added_by_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fee_discount_rules`
--

CREATE TABLE `fee_discount_rules` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `is_percent` tinyint(4) NOT NULL DEFAULT 1,
  `amount` decimal(10,2) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `student_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'If set, discount applies only to this student',
  `class_section_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'If set, discount applies only to students in this class/section'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fee_discount_rules`
--

INSERT INTO `fee_discount_rules` (`id`, `name`, `is_percent`, `amount`, `start_date`, `end_date`, `description`, `student_id`, `class_section_id`) VALUES
(1, 'Discount for Muntazir', 0, 500.00, '2026-03-29', '2026-03-29', '', NULL, NULL),
(2, 'Discount', 0, 500.00, '2026-03-30', '2026-03-30', 'One time Only', 534, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `fee_fine_rules`
--

CREATE TABLE `fee_fine_rules` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `daily_fine_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fee_fine_rules`
--

INSERT INTO `fee_fine_rules` (`id`, `name`, `daily_fine_amount`, `description`) VALUES
(1, 'Late Fee', 50.00, '');

-- --------------------------------------------------------

--
-- Table structure for table `fee_invoices`
--

CREATE TABLE `fee_invoices` (
  `id` int(11) NOT NULL,
  `invoice_no` varchar(30) NOT NULL,
  `student_id` int(11) NOT NULL,
  `academic_year_id` int(11) DEFAULT NULL,
  `issued_at` datetime NOT NULL DEFAULT current_timestamp(),
  `due_date` date DEFAULT NULL,
  `status` enum('open','paid','cancelled') NOT NULL DEFAULT 'open',
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_due` decimal(10,2) NOT NULL DEFAULT 0.00,
  `fine_applied` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_by_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fee_invoices`
--

INSERT INTO `fee_invoices` (`id`, `invoice_no`, `student_id`, `academic_year_id`, `issued_at`, `due_date`, `status`, `total_amount`, `total_discount`, `total_due`, `fine_applied`, `created_by_user_id`) VALUES
(116, 'INV-20260330-708404', 576, NULL, '2026-03-30 11:48:53', '2026-04-09', 'paid', 3000.00, 0.00, 3000.00, 0.00, 4),
(117, 'INV-20260330-951043', 534, NULL, '2026-03-30 12:30:57', '2026-04-09', 'open', 2500.00, 500.00, 2000.00, 0.00, 4),
(118, 'INV-20260330-401329', 574, NULL, '2026-03-30 12:31:28', '2026-04-09', 'open', 3000.00, 0.00, 3000.00, 0.00, 4);

-- --------------------------------------------------------

--
-- Table structure for table `fee_invoice_lines`
--

CREATE TABLE `fee_invoice_lines` (
  `id` int(11) NOT NULL,
  `fee_invoice_id` int(11) NOT NULL,
  `fee_category_id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `base_amount` decimal(10,2) NOT NULL,
  `discount_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `line_total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fee_invoice_lines`
--

INSERT INTO `fee_invoice_lines` (`id`, `fee_invoice_id`, `fee_category_id`, `description`, `base_amount`, `discount_amount`, `line_total`) VALUES
(119, 116, 1, 'Tuition Fee - March', 3000.00, 0.00, 3000.00),
(120, 117, 1, 'Tuition Fee - March', 2500.00, 500.00, 2000.00),
(121, 118, 1, 'Tuition Fee - March', 3000.00, 0.00, 3000.00);

-- --------------------------------------------------------

--
-- Table structure for table `fee_student_reconciliation`
--

CREATE TABLE `fee_student_reconciliation` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `academic_year_id` int(11) DEFAULT NULL,
  `total_charged` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_discounts` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_fines` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_paid` decimal(10,2) NOT NULL DEFAULT 0.00,
  `last_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `id` int(11) NOT NULL,
  `grade_letter` varchar(10) NOT NULL,
  `min_score` decimal(6,2) NOT NULL,
  `max_score` decimal(6,2) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `grades`
--

INSERT INTO `grades` (`id`, `grade_letter`, `min_score`, `max_score`, `sort_order`) VALUES
(1, 'A+', 80.00, 100.00, 1),
(2, 'A', 70.00, 79.99, 2),
(3, 'B', 60.00, 69.99, 3),
(4, 'C', 50.00, 59.99, 4),
(5, 'D', 40.00, 49.99, 5),
(6, 'F', 0.00, 39.99, 6);

-- --------------------------------------------------------

--
-- Table structure for table `guardians`
--

CREATE TABLE `guardians` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `full_name` varchar(140) NOT NULL,
  `relation` varchar(50) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inquiries`
--

CREATE TABLE `inquiries` (
  `id` int(11) NOT NULL,
  `inquiry_no` varchar(30) NOT NULL,
  `requested_first_name` varchar(80) NOT NULL,
  `requested_last_name` varchar(80) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `requested_class_id` int(11) DEFAULT NULL,
  `requested_section_id` int(11) DEFAULT NULL,
  `status` enum('new','reviewed','approved','rejected','converted') NOT NULL DEFAULT 'new',
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `reviewed_by_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `label_overrides`
--

CREATE TABLE `label_overrides` (
  `id` int(11) NOT NULL,
  `module_name` varchar(60) NOT NULL,
  `field_key` varchar(120) NOT NULL,
  `label_text` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leave_approvals`
--

CREATE TABLE `leave_approvals` (
  `id` int(11) NOT NULL,
  `leave_request_id` int(11) NOT NULL,
  `approved_by_user_id` int(11) DEFAULT NULL,
  `decision` enum('approved','rejected') NOT NULL,
  `decision_note` varchar(255) DEFAULT NULL,
  `decided_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leave_requests`
--

CREATE TABLE `leave_requests` (
  `id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `leave_type` varchar(40) NOT NULL DEFAULT 'leave',
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `note` varchar(255) DEFAULT NULL,
  `requested_by_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `class_section_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `score` decimal(6,2) NOT NULL DEFAULT 0.00,
  `grade_id` int(11) DEFAULT NULL,
  `is_locked` tinyint(4) NOT NULL DEFAULT 0,
  `entered_by_user_id` int(11) DEFAULT NULL,
  `entered_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_by_user_id` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `total_marks` decimal(6,2) NOT NULL DEFAULT 100.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`id`, `exam_id`, `student_id`, `class_section_id`, `subject_id`, `score`, `grade_id`, `is_locked`, `entered_by_user_id`, `entered_at`, `updated_by_user_id`, `updated_at`, `total_marks`) VALUES
(55, 1, 481, 1, 2, 80.00, 1, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:01', 100.00),
(56, 1, 482, 1, 2, 20.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:01', 100.00),
(57, 1, 483, 1, 2, 15.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:01', 100.00),
(58, 1, 484, 1, 2, 21.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:01', 100.00),
(59, 1, 485, 1, 2, 22.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:01', 100.00),
(60, 1, 486, 1, 2, 23.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:01', 100.00),
(61, 1, 487, 1, 2, 24.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:02', 100.00),
(62, 1, 488, 1, 2, 25.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:02', 100.00),
(63, 1, 489, 1, 2, 26.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:02', 100.00),
(64, 1, 490, 1, 2, 12.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:02', 100.00),
(65, 1, 491, 1, 2, 10.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:02', 100.00),
(66, 1, 492, 1, 2, 15.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:02', 100.00),
(67, 1, 493, 1, 2, 13.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:02', 100.00),
(68, 1, 494, 1, 2, 11.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:02', 100.00),
(69, 1, 495, 1, 2, 25.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:02', 100.00),
(70, 1, 496, 1, 2, 30.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:02', 100.00),
(71, 1, 497, 1, 2, 28.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:02', 100.00),
(72, 1, 498, 1, 2, 29.00, 6, 0, 4, '2026-03-30 00:12:49', 4, '2026-03-30 00:19:02', 100.00),
(73, 1, 481, 1, 1, 80.00, 1, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(74, 1, 482, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(75, 1, 483, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(76, 1, 484, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(77, 1, 485, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(78, 1, 486, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(79, 1, 487, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(80, 1, 488, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(81, 1, 489, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(82, 1, 490, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(83, 1, 491, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(84, 1, 492, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(85, 1, 493, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(86, 1, 494, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(87, 1, 495, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(88, 1, 496, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(89, 1, 497, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(90, 1, 498, 1, 1, 0.00, 6, 0, 4, '2026-03-30 00:16:55', 4, '2026-03-30 00:18:39', 100.00),
(91, 1, 481, 1, 3, 80.00, 1, 0, 4, '2026-03-30 00:17:04', 4, '2026-03-30 00:18:47', 100.00),
(92, 1, 482, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:04', 4, '2026-03-30 00:18:47', 100.00),
(93, 1, 483, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:04', 4, '2026-03-30 00:18:47', 100.00),
(94, 1, 484, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:04', 4, '2026-03-30 00:18:47', 100.00),
(95, 1, 485, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:04', 4, '2026-03-30 00:18:47', 100.00),
(96, 1, 486, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:04', 4, '2026-03-30 00:18:47', 100.00),
(97, 1, 487, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:04', 4, '2026-03-30 00:18:47', 100.00),
(98, 1, 488, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:04', 4, '2026-03-30 00:18:47', 100.00),
(99, 1, 489, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:04', 4, '2026-03-30 00:18:47', 100.00),
(100, 1, 490, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:05', 4, '2026-03-30 00:18:47', 100.00),
(101, 1, 491, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:05', 4, '2026-03-30 00:18:47', 100.00),
(102, 1, 492, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:05', 4, '2026-03-30 00:18:47', 100.00),
(103, 1, 493, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:05', 4, '2026-03-30 00:18:47', 100.00),
(104, 1, 494, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:05', 4, '2026-03-30 00:18:47', 100.00),
(105, 1, 495, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:05', 4, '2026-03-30 00:18:47', 100.00),
(106, 1, 496, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:05', 4, '2026-03-30 00:18:47', 100.00),
(107, 1, 497, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:05', 4, '2026-03-30 00:18:47', 100.00),
(108, 1, 498, 1, 3, 0.00, 6, 0, 4, '2026-03-30 00:17:05', 4, '2026-03-30 00:18:47', 100.00),
(163, 2, 499, 2, 1, 25.00, 4, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(164, 2, 500, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(165, 2, 501, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(166, 2, 502, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(167, 2, 503, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(168, 2, 504, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(169, 2, 505, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(170, 2, 506, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(171, 2, 507, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(172, 2, 508, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(173, 2, 509, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(174, 2, 510, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(175, 2, 511, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(176, 2, 512, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(177, 2, 513, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(178, 2, 514, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(179, 2, 515, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(180, 2, 516, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(181, 2, 517, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(182, 2, 518, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(183, 2, 519, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(184, 2, 520, 2, 1, 0.00, 6, 0, 4, '2026-03-30 13:08:36', 4, '2026-03-30 17:14:03', 50.00),
(207, 2, 499, 2, 3, 34.00, 3, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(208, 2, 500, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(209, 2, 501, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(210, 2, 502, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(211, 2, 503, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(212, 2, 504, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(213, 2, 505, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(214, 2, 506, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(215, 2, 507, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(216, 2, 508, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(217, 2, 509, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(218, 2, 510, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(219, 2, 511, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(220, 2, 512, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(221, 2, 513, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(222, 2, 514, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(223, 2, 515, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(224, 2, 516, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(225, 2, 517, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(226, 2, 518, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(227, 2, 519, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(228, 2, 520, 2, 3, 0.00, 6, 0, 4, '2026-03-30 17:38:12', 4, '2026-03-30 17:38:12', 50.00),
(229, 2, 499, 2, 2, 49.00, 1, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(230, 2, 500, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(231, 2, 501, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(232, 2, 502, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(233, 2, 503, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(234, 2, 504, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(235, 2, 505, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(236, 2, 506, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(237, 2, 507, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(238, 2, 508, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(239, 2, 509, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(240, 2, 510, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(241, 2, 511, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(242, 2, 512, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(243, 2, 513, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(244, 2, 514, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(245, 2, 515, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(246, 2, 516, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(247, 2, 517, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(248, 2, 518, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(249, 2, 519, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00),
(250, 2, 520, 2, 2, 0.00, 6, 0, 4, '2026-03-30 17:38:22', 4, '2026-03-30 17:38:22', 50.00);

-- --------------------------------------------------------

--
-- Stand-in structure for view `pending_dues_view`
-- (See below for the actual view)
--
CREATE TABLE `pending_dues_view` (
`fee_invoice_id` int(11)
,`student_id` int(11)
,`academic_year_id` int(11)
,`pending_amount` decimal(33,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `performance_reports`
--

CREATE TABLE `performance_reports` (
  `id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `period_start` date DEFAULT NULL,
  `period_end` date DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `summary` text DEFAULT NULL,
  `created_by_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `performance_reports`
--

INSERT INTO `performance_reports` (`id`, `staff_profile_id`, `period_start`, `period_end`, `rating`, `summary`, `created_by_user_id`, `created_at`) VALUES
(1, 2, '2026-03-01', '2026-03-30', 3, 'No thing', 4, '2026-03-30 17:32:30');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL,
  `permission_key` varchar(100) NOT NULL,
  `permission_name` varchar(150) NOT NULL,
  `permission_description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `permission_key`, `permission_name`, `permission_description`) VALUES
(1, 'dashboard.view', 'Dashboard view', 'View dashboard'),
(2, 'students.view', 'Students view', 'View students'),
(3, 'students.manage', 'Students manage', 'Create/edit/delete students'),
(4, 'academic.view', 'Academic view', 'View academic module'),
(5, 'academic.manage', 'Academic manage', 'Manage subjects/exams'),
(6, 'fees.view', 'Fees view', 'View fees'),
(7, 'fees.manage', 'Fees manage', 'Collect/assign/manage fees'),
(8, 'staff.view', 'Staff view', 'View staff and HR'),
(9, 'staff.manage', 'Staff manage', 'Manage staff/attendance/leaves/payroll'),
(10, 'users.view', 'Users view', 'View users and roles'),
(11, 'users.manage', 'Users manage', 'Manage users and role capabilities'),
(12, 'reports.view', 'Reports view', 'View reports'),
(13, 'reports.export', 'Reports export', 'Export reports (CSV/print)'),
(14, 'settings.view', 'Settings view', 'View settings'),
(15, 'settings.manage', 'Settings manage', 'Backup/restore and clean data'),
(17, 'attendance.view', '', NULL),
(18, 'attendance.manage', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `description`) VALUES
(1, 'Admin', 'System administrator'),
(2, 'Teacher', 'Teacher role'),
(3, 'Student', 'Student role'),
(4, 'Parent', 'Parent/guardian role'),
(5, 'Accountant', 'Accounting & finance role');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE `role_permissions` (
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(1, 13),
(1, 14),
(1, 15),
(1, 17),
(1, 18),
(2, 2),
(2, 4),
(2, 5),
(2, 12),
(3, 12),
(4, 2),
(4, 6),
(4, 12),
(5, 6),
(5, 7),
(5, 12),
(5, 13);

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`id`, `name`) VALUES
(1, 'A'),
(2, 'B');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `key` varchar(120) NOT NULL,
  `value` longtext NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`key`, `value`, `updated_at`) VALUES
('academic_year_active', '2026', '2026-03-29 18:21:49'),
('app_timezone', 'PKT', '2026-03-29 18:21:49'),
('branding_favicon_path', '/uploads/branding/favicon_20260330172143_e6695ad6.png', '2026-03-30 17:21:43'),
('branding_logo_path', '/uploads/branding/logo_20260328222254_bdbe960c.png', '2026-03-28 22:22:54'),
('branding_school_name', 'Akhoon Zada Public School And College Bilamik', '2026-03-30 17:21:43'),
('currency', 'PKR', '2026-03-29 18:21:49'),
('date_format', 'Y-m-d', '2026-03-29 18:21:49'),
('holidays', '', '2026-03-29 18:21:49'),
('institute_address', 'Bilamik', '2026-03-29 23:24:28'),
('institute_contact', '03145525749', '2026-03-29 23:24:28'),
('institute_name', 'Akhoonzada Public School and College Bilamik', '2026-03-29 23:24:28'),
('institute_policies', '', '2026-03-29 23:24:28');

-- --------------------------------------------------------

--
-- Table structure for table `staff_attendance_records`
--

CREATE TABLE `staff_attendance_records` (
  `id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `attendance_date` date NOT NULL,
  `status` enum('present','absent','late','excused') NOT NULL DEFAULT 'present',
  `created_by_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff_attendance_records`
--

INSERT INTO `staff_attendance_records` (`id`, `staff_profile_id`, `attendance_date`, `status`, `created_by_user_id`, `created_at`) VALUES
(1, 1, '2026-03-29', 'present', 4, '2026-03-29 16:25:06'),
(2, 3, '2026-03-30', 'absent', 4, '2026-03-30 17:57:12'),
(3, 2, '2026-03-30', 'present', 4, '2026-03-30 17:57:12'),
(4, 1, '2026-03-30', 'present', 4, '2026-03-30 17:57:12');

-- --------------------------------------------------------

--
-- Table structure for table `staff_profiles`
--

CREATE TABLE `staff_profiles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `staff_code` varchar(40) DEFAULT NULL,
  `full_name` varchar(140) NOT NULL,
  `title` varchar(80) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff_profiles`
--

INSERT INTO `staff_profiles` (`id`, `user_id`, `staff_code`, `full_name`, `title`, `phone`, `address`, `created_at`) VALUES
(1, NULL, NULL, 'Mubashir Hassan', 'Teacher', '03145525749', 'SCHS', '2026-03-28 22:21:59'),
(2, NULL, NULL, 'Ahmer', 'Principal', '45', NULL, '2026-03-29 16:37:53'),
(3, NULL, NULL, 'Abdullah Khan', 'VP', '0322555555555', NULL, '2026-03-30 17:30:18');

-- --------------------------------------------------------

--
-- Table structure for table `staff_roles`
--

CREATE TABLE `staff_roles` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `staff_role_assignments`
--

CREATE TABLE `staff_role_assignments` (
  `id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `staff_role_id` int(11) NOT NULL,
  `assigned_at` datetime NOT NULL DEFAULT current_timestamp(),
  `assigned_by_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `staff_salary_details`
--

CREATE TABLE `staff_salary_details` (
  `id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `salary_month` int(11) NOT NULL,
  `salary_year` int(11) NOT NULL,
  `gross_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `deductions` decimal(10,2) NOT NULL DEFAULT 0.00,
  `net_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by_user_id` int(11) DEFAULT NULL,
  `salary_created_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff_salary_details`
--

INSERT INTO `staff_salary_details` (`id`, `staff_profile_id`, `salary_month`, `salary_year`, `gross_amount`, `deductions`, `net_amount`, `created_at`, `created_by_user_id`, `salary_created_date`) VALUES
(11, 3, 3, 2026, 20000.00, 0.00, 20000.00, '2026-03-30 17:32:59', 4, '2026-03-30');

-- --------------------------------------------------------

--
-- Table structure for table `staff_salary_payments`
--

CREATE TABLE `staff_salary_payments` (
  `id` int(11) NOT NULL,
  `staff_salary_detail_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `amount` decimal(10,2) NOT NULL,
  `paid_date` date DEFAULT NULL,
  `method` enum('cash','card','bank') NOT NULL DEFAULT 'cash',
  `note` varchar(255) DEFAULT NULL,
  `paid_by_user_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff_salary_payments`
--

INSERT INTO `staff_salary_payments` (`id`, `staff_salary_detail_id`, `created_at`, `amount`, `paid_date`, `method`, `note`, `paid_by_user_id`, `created_by`) VALUES
(10, 11, '2026-03-30 17:35:35', 30000.00, '2026-03-30', 'cash', '', NULL, 4);

-- --------------------------------------------------------

--
-- Table structure for table `staff_subject_assignments`
--

CREATE TABLE `staff_subject_assignments` (
  `id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `active_from` date DEFAULT NULL,
  `active_to` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff_subject_assignments`
--

INSERT INTO `staff_subject_assignments` (`id`, `staff_profile_id`, `subject_id`, `active_from`, `active_to`) VALUES
(1, 1, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `admission_no` varchar(30) NOT NULL,
  `first_name` varchar(80) NOT NULL,
  `last_name` varchar(80) NOT NULL,
  `gender` enum('M','F','Other') NOT NULL DEFAULT 'M',
  `dob` date DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `roll_number` varchar(50) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `photo_blob` longblob DEFAULT NULL,
  `photo_type` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `user_id`, `admission_no`, `first_name`, `last_name`, `gender`, `dob`, `phone`, `address`, `status`, `created_at`, `roll_number`, `photo`, `photo_blob`, `photo_type`) VALUES
(481, NULL, 'STU001', 'Jano', 'Kazim', 'F', '0000-00-00', '3001234567', 'Rawalpindi', 1, '2026-03-29 14:11:25', '1', NULL, NULL, NULL),
(482, NULL, 'STU002', 'Sakina', 'Ali cho', 'F', '0000-00-00', '3109876543', 'Islamabad', 1, '2026-03-29 14:11:25', '2', NULL, NULL, NULL),
(483, NULL, 'STU003', 'Madiha', 'Wajahat', 'F', '0000-00-00', '3201111111', 'Peshawar', 1, '2026-03-29 14:11:25', '3', NULL, NULL, NULL),
(484, NULL, 'STU004', 'Haidar', 'Hussain', 'M', '0000-00-00', '3311111111', 'Lahore', 1, '2026-03-29 14:11:25', '4', NULL, NULL, NULL),
(485, NULL, 'STU005', 'Ali', 'Nadi wilayat', 'M', '0000-00-00', '3401234567', 'Rawalpindi', 1, '2026-03-29 14:11:25', '5', NULL, NULL, NULL),
(486, NULL, 'STU006', 'Hasnain', 'fida Alli', 'M', '0000-00-00', '3509876543', 'Islamabad', 1, '2026-03-29 14:11:25', '6', NULL, NULL, NULL),
(487, NULL, 'STU007', 'Sharifullah', 'Baqir', 'M', '0000-00-00', '3601111111', 'Multan', 1, '2026-03-29 14:11:25', '7', NULL, NULL, NULL),
(488, NULL, 'STU008', 'muzamil', 'Rizwan', 'M', '0000-00-00', '3701234567', 'Faisalabad', 1, '2026-03-29 14:11:25', '8', NULL, NULL, NULL),
(489, NULL, 'STU009', 'muneer', 'Hussaini', 'M', '0000-00-00', '3809876543', 'Gujranwala', 1, '2026-03-29 14:11:25', '9', NULL, NULL, NULL),
(490, NULL, 'STU010', 'Ayaz', 'shair', 'M', '0000-00-00', '3901111111', 'Sialkot', 1, '2026-03-29 14:11:25', '10', NULL, NULL, NULL),
(491, NULL, 'STU011', 'Ariyan', 'Abdullan', 'M', '0000-00-00', '4004049382', 'Rawalpindi', 1, '2026-03-29 14:11:25', '11', NULL, NULL, NULL),
(492, NULL, 'STU012', 'Yasir', 'shair', 'M', '0000-00-00', '4103916947', 'Islamabad', 1, '2026-03-29 14:11:25', '12', NULL, NULL, NULL),
(493, NULL, 'STU013', 'Kammil', 'Iqbal', 'M', '0000-00-00', '4203784512', 'Peshawar', 1, '2026-03-29 14:11:25', '13', NULL, NULL, NULL),
(494, NULL, 'STU014', 'Konoin', 'mehmood', 'F', '0000-00-00', '4303652076', 'Lahore', 1, '2026-03-29 14:11:25', '14', NULL, NULL, NULL),
(495, NULL, 'STU015', 'Nargis', 'Nazir', 'F', '0000-00-00', '4403519641', 'Rawalpindi', 1, '2026-03-29 14:11:25', '15', NULL, NULL, NULL),
(496, NULL, 'STU016', 'Adib', 'Ali Naqi', 'M', '0000-00-00', '4503387205', 'Islamabad', 1, '2026-03-29 14:11:25', '16', NULL, NULL, NULL),
(497, NULL, 'STU017', 'faizan', 'N/A', 'M', '0000-00-00', '4603254770', 'Multan', 1, '2026-03-29 14:11:25', '17', NULL, NULL, NULL),
(498, NULL, 'STU018', 'muntazir', 'Ali', 'M', '0000-00-00', '4703122334', 'Faisalabad', 1, '2026-03-29 14:11:25', '18', NULL, NULL, NULL),
(499, NULL, 'STU019', 'Uliya', 'mumtaz', 'F', '0000-00-00', '4802989899', 'Gujranwala', 1, '2026-03-29 14:11:25', '1', NULL, NULL, NULL),
(500, NULL, 'STU020', 'Kaneez', 'mehmood', 'F', '0000-00-00', '4902857463', 'Sialkot', 1, '2026-03-29 14:11:25', '2', NULL, NULL, NULL),
(501, NULL, 'STU021', 'zahra', 'Zahid', 'F', '0000-00-00', '5002725028', 'Rawalpindi', 1, '2026-03-29 14:11:25', '3', NULL, NULL, NULL),
(502, NULL, 'STU022', 'Nosheer', 'Ali', 'F', '0000-00-00', '5102592593', 'Islamabad', 1, '2026-03-29 14:11:25', '4', NULL, NULL, NULL),
(503, NULL, 'STU023', 'Saima', 'Yousaf', 'F', '0000-00-00', '5202460157', 'Peshawar', 1, '2026-03-29 14:11:25', '5', NULL, NULL, NULL),
(504, NULL, 'STU024', 'Tehreen', 'Mubarle', 'F', '0000-00-00', '5302327722', 'Lahore', 1, '2026-03-29 14:11:25', '6', NULL, NULL, NULL),
(505, NULL, 'STU025', 'Shahbaz', 'Taha', 'M', '0000-00-00', '5402195286', 'Rawalpindi', 1, '2026-03-29 14:11:25', '7', NULL, NULL, NULL),
(506, NULL, 'STU026', 'Sahil', 'Ibrahim', 'M', '0000-00-00', '5502062851', 'Islamabad', 1, '2026-03-29 14:11:25', '8', NULL, NULL, NULL),
(507, NULL, 'STU027', 'Shayan', 'Nasir', 'M', '0000-00-00', '5601930415', 'Multan', 1, '2026-03-29 14:11:25', '9', NULL, NULL, NULL),
(508, NULL, 'STU028', 'Hasnain', 'Fido Phi', 'M', '0000-00-00', '5701797980', 'Faisalabad', 1, '2026-03-29 14:11:25', '10', NULL, NULL, NULL),
(509, NULL, 'STU029', 'Zamin', 'livat', 'M', '0000-00-00', '5801665545', 'Gujranwala', 1, '2026-03-29 14:11:25', '11', NULL, NULL, NULL),
(510, NULL, 'STU030', 'Kazim', 'Shujaat', 'M', '0000-00-00', '5901533109', 'Sialkot', 1, '2026-03-29 14:11:25', '12', NULL, NULL, NULL),
(511, NULL, 'STU031', 'Abhas', 'Ejaz', 'M', '0000-00-00', '6001400674', 'Rawalpindi', 1, '2026-03-29 14:11:25', '13', NULL, NULL, NULL),
(512, NULL, 'STU032', 'Ashiq', 'Piola Hussain', 'M', '0000-00-00', '6101268238', 'Islamabad', 1, '2026-03-29 14:11:25', '14', NULL, NULL, NULL),
(513, NULL, 'STU033', 'merai', 'Nasrullah', 'M', '0000-00-00', '6201135803', 'Peshawar', 1, '2026-03-29 14:11:25', '15', NULL, NULL, NULL),
(514, NULL, 'STU034', 'Faizan', 'Habib', 'M', '0000-00-00', '6301003367', 'Lahore', 1, '2026-03-29 14:11:25', '16', NULL, NULL, NULL),
(515, NULL, 'STU035', 'Yasir', 'Ejaz', 'M', '0000-00-00', '6400870932', 'Rawalpindi', 1, '2026-03-29 14:11:25', '17', NULL, NULL, NULL),
(516, NULL, 'STU036', 'irfan', 'Kozim', 'M', '0000-00-00', '6500738496', 'Islamabad', 1, '2026-03-29 14:11:25', '18', NULL, NULL, NULL),
(517, NULL, 'STU037', 'Tajular', 'Sharifullah', 'M', '0000-00-00', '6600606061', 'Multan', 1, '2026-03-29 14:11:25', '19', NULL, NULL, NULL),
(518, NULL, 'STU038', 'Muhammad', 'Nabl', 'M', '0000-00-00', '6700473626', 'Faisalabad', 1, '2026-03-29 14:11:25', '20', NULL, NULL, NULL),
(519, NULL, 'STU039', 'Shahriyar', 'Shair', 'M', '0000-00-00', '6800341190', 'Gujranwala', 1, '2026-03-29 14:11:25', '21', NULL, NULL, NULL),
(520, NULL, 'STU040', 'Faizan', 'Sikandar', 'M', '0000-00-00', '6900208755', 'Sialkot', 1, '2026-03-29 14:11:25', '22', NULL, NULL, NULL),
(521, NULL, 'STU041', 'Zameer', 'Yousuf', 'M', '0000-00-00', '7000076319', 'Rawalpindi', 1, '2026-03-29 14:11:25', '1', NULL, NULL, NULL),
(522, NULL, 'STU042', 'Shehzad', 'Shair', 'M', '0000-00-00', '7099943884', 'Islamabad', 1, '2026-03-29 14:11:25', '2', NULL, NULL, NULL),
(523, NULL, 'STU043', 'Hasnain', 'Wajahat', 'M', '0000-00-00', '7199811448', 'Peshawar', 1, '2026-03-29 14:11:25', '3', NULL, NULL, NULL),
(524, NULL, 'STU044', 'Asghar', 'Alicho', 'M', '0000-00-00', '7299679013', 'Lahore', 1, '2026-03-29 14:11:25', '4', NULL, NULL, NULL),
(525, NULL, 'STU045', 'Meraj', 'Shabbir', 'M', '0000-00-00', '7399546577', 'Rawalpindi', 1, '2026-03-29 14:11:25', '5', NULL, NULL, NULL),
(526, NULL, 'STU046', 'Hasnian', 'Ali Arif', 'M', '0000-00-00', '7499414142', 'Islamabad', 1, '2026-03-29 14:11:25', '6', NULL, NULL, NULL),
(527, NULL, 'STU047', 'Irfan', 'Mubarak', 'M', '0000-00-00', '7599281707', 'Multan', 1, '2026-03-29 14:11:25', '7', NULL, NULL, NULL),
(528, NULL, 'STU048', 'Kubra', 'Ali Muhammad', 'F', '0000-00-00', '7699149271', 'Faisalabad', 1, '2026-03-29 14:11:25', '8', NULL, NULL, NULL),
(529, NULL, 'STU049', 'Nooreen', 'Baqir', 'F', '0000-00-00', '7799016836', 'Gujranwala', 1, '2026-03-29 14:11:25', '9', NULL, NULL, NULL),
(530, NULL, 'STU050', 'Neelu', 'Nasir', 'F', '0000-00-00', '7898884400', 'Sialkot', 1, '2026-03-29 14:11:25', '10', NULL, NULL, NULL),
(531, NULL, 'STU051', 'Farhan', 'Habib', 'M', '0000-00-00', '7998751965', 'Rawalpindi', 1, '2026-03-29 14:11:25', '11', NULL, NULL, NULL),
(532, NULL, 'STU052', 'Ali', 'Murtaza', 'M', '0000-00-00', '8098619529', 'Islamabad', 1, '2026-03-29 14:11:25', '12', NULL, NULL, NULL),
(533, NULL, 'STU053', 'Haider', 'Muzaffar', 'M', '0000-00-00', '8198487094', 'Peshawar', 1, '2026-03-29 14:11:25', '13', NULL, NULL, NULL),
(534, NULL, 'STU054', 'Ayan', 'Abdullah', 'M', '0000-00-00', '8298354658', 'Lahore', 1, '2026-03-29 14:11:25', '1', NULL, NULL, NULL),
(535, NULL, 'STU055', 'shahid', 'Arif', 'M', '0000-00-00', '8398222223', 'Rawalpindi', 1, '2026-03-29 14:11:25', '2', NULL, NULL, NULL),
(536, NULL, 'STU056', 'Ali', 'musa N/A', 'M', '0000-00-00', '8498089788', 'Islamabad', 1, '2026-03-29 14:11:25', '3', NULL, NULL, NULL),
(537, NULL, 'STU057', 'shanawer', 'N/A', 'M', '0000-00-00', '8597957352', 'Multan', 1, '2026-03-29 14:11:25', '4', NULL, NULL, NULL),
(538, NULL, 'STU058', 'Hasnain', 'Ali', 'M', '0000-00-00', '8697824917', 'Faisalabad', 1, '2026-03-29 14:11:25', '5', NULL, NULL, NULL),
(539, NULL, 'STU059', 'sajahat', 'Ali', 'M', '0000-00-00', '8797692481', 'Gujranwala', 1, '2026-03-29 14:11:25', '6', NULL, NULL, NULL),
(540, NULL, 'STU060', 'muhammad', 'Ialbal', 'M', '0000-00-00', '8897560046', 'Sialkot', 1, '2026-03-29 14:11:25', '7', NULL, NULL, NULL),
(541, NULL, 'STU061', 'salih', 'mumlag', 'M', '0000-00-00', '8997427610', 'Rawalpindi', 1, '2026-03-29 14:11:25', '8', NULL, NULL, NULL),
(542, NULL, 'STU062', 'Hasnain', 'G.m', 'M', '0000-00-00', '9097295175', 'Islamabad', 1, '2026-03-29 14:11:25', '9', NULL, NULL, NULL),
(543, NULL, 'STU063', 'musa', 'Sakhawat', 'M', '0000-00-00', '9197162739', 'Peshawar', 1, '2026-03-29 14:11:25', '10', NULL, NULL, NULL),
(544, NULL, 'STU064', 'mushahid', 'manzoor', 'M', '0000-00-00', '9297030304', 'Lahore', 1, '2026-03-29 14:11:25', '11', NULL, NULL, NULL),
(545, NULL, 'STU065', 'samreen', 'mustafa', 'F', '0000-00-00', '9396897869', 'Rawalpindi', 1, '2026-03-29 14:11:25', '12', NULL, NULL, NULL),
(546, NULL, 'STU066', 'sonam', 'Bakhtawer', 'F', '0000-00-00', '9496765433', 'Islamabad', 1, '2026-03-29 14:11:25', '13', NULL, NULL, NULL),
(547, NULL, 'STU067', 'saking', 'Idbal', 'F', '0000-00-00', '9596632998', 'Multan', 1, '2026-03-29 14:11:25', '14', NULL, NULL, NULL),
(548, NULL, 'STU068', 'Kiran', 'Nisar', 'F', '0000-00-00', '9696500562', 'Faisalabad', 1, '2026-03-29 14:11:25', '15', NULL, NULL, NULL),
(549, NULL, 'STU069', 'fatime', 'Ali', 'F', '0000-00-00', '9796368127', 'Gujranwala', 1, '2026-03-29 14:11:25', '16', NULL, NULL, NULL),
(550, NULL, 'STU070', 'Hajra', 'Skindar', 'F', '0000-00-00', '9896235691', 'Sialkot', 1, '2026-03-29 14:11:25', '17', NULL, NULL, NULL),
(551, NULL, 'STU071', 'Ayan', 'zakir', 'M', '0000-00-00', '9996103256', 'Rawalpindi', 1, '2026-03-29 14:11:25', '18', NULL, NULL, NULL),
(552, NULL, 'STU072', 'riaz', 'bakhtawar', 'M', '0000-00-00', '10095970820', 'Islamabad', 1, '2026-03-29 14:11:25', '1', NULL, NULL, NULL),
(553, NULL, 'STU073', 'tajamul', 'ali', 'M', '0000-00-00', '10195838385', 'Peshawar', 1, '2026-03-29 14:11:25', '2', NULL, NULL, NULL),
(554, NULL, 'STU074', 'Nai3', 'Shaiv', 'M', '0000-00-00', '10295705950', 'Lahore', 1, '2026-03-29 14:11:25', '3', NULL, NULL, NULL),
(555, NULL, 'STU075', 'Maisam', 'Esso', 'M', '0000-00-00', '10395573514', 'Rawalpindi', 1, '2026-03-29 14:11:25', '4', NULL, NULL, NULL),
(556, NULL, 'STU076', 'Saglain', 'Tahir', 'M', '0000-00-00', '10495441079', 'Islamabad', 1, '2026-03-29 14:11:25', '5', NULL, NULL, NULL),
(557, NULL, 'STU077', 'Shalv', 'Ali', 'M', '0000-00-00', '10595308643', 'Multan', 1, '2026-03-29 14:11:25', '6', NULL, NULL, NULL),
(558, NULL, 'STU078', '1smail', 'Iboolrim', 'M', '0000-00-00', '10695176208', 'Faisalabad', 1, '2026-03-29 14:11:25', '7', NULL, NULL, NULL),
(559, NULL, 'STU079', 'munawar', 'naqi', 'M', '0000-00-00', '10795043772', 'Gujranwala', 1, '2026-03-29 14:11:25', '8', NULL, NULL, NULL),
(560, NULL, 'STU080', 'Reyann', 'Pbdullah', 'M', '0000-00-00', '10894911337', 'Sialkot', 1, '2026-03-29 14:11:25', '9', NULL, NULL, NULL),
(561, NULL, 'STU081', 'urooj', 'Shai', 'F', '0000-00-00', '10994778901', 'Rawalpindi', 1, '2026-03-29 14:11:25', '10', NULL, NULL, NULL),
(562, NULL, 'STU082', 'yasmeen', 'Ali', 'F', '0000-00-00', '11094646466', 'Islamabad', 1, '2026-03-29 14:11:25', '11', NULL, NULL, NULL),
(563, NULL, 'STU083', 'Alza', 'wajahat', 'F', '0000-00-00', '11194514031', 'Peshawar', 1, '2026-03-29 14:11:25', '12', NULL, NULL, NULL),
(564, NULL, 'STU084', 'Zainab', 'Skindov', 'F', '0000-00-00', '11294381595', 'Lahore', 1, '2026-03-29 14:11:25', '13', NULL, NULL, NULL),
(565, NULL, 'STU085', 'Hasino', 'kazim', 'F', '0000-00-00', '11394249160', 'Rawalpindi', 1, '2026-03-29 14:11:25', '14', NULL, NULL, NULL),
(566, NULL, 'STU086', 'Ahmad', 'Fida', 'M', '0000-00-00', '11494116724', 'Islamabad', 1, '2026-03-29 14:11:25', '15', NULL, NULL, NULL),
(567, NULL, 'STU087', 'abbas', 'ali cho', 'M', '0000-00-00', '11593984289', 'Multan', 1, '2026-03-29 14:11:25', '16', NULL, NULL, NULL),
(568, NULL, 'STU088', 'Kaza', 'Ali Mah', 'M', '0000-00-00', '11693851853', 'Faisalabad', 1, '2026-03-29 14:11:25', '17', NULL, NULL, NULL),
(569, NULL, 'STU089', 'Zeeshan', 'Jutail', 'M', '0000-00-00', '11793719418', 'Gujranwala', 1, '2026-03-29 14:11:25', '18', NULL, NULL, NULL),
(570, NULL, 'STU090', 'irfan', 'Muzafor', 'M', '0000-00-00', '11893586983', 'Sialkot', 1, '2026-03-29 14:11:25', '19', NULL, NULL, NULL),
(571, NULL, 'STU091', 'Islife2', 'Ahmad', 'M', '0000-00-00', '11993454547', 'Rawalpindi', 1, '2026-03-29 14:11:25', '20', NULL, NULL, NULL),
(572, NULL, 'STU092', 'xesir', 'Yousaf', 'M', '0000-00-00', '12093322112', 'Islamabad', 1, '2026-03-29 14:11:25', '21', NULL, NULL, NULL),
(573, NULL, 'STU093', 'Reza', 'Sakhawat', 'M', '0000-00-00', '12193189676', 'Peshawar', 1, '2026-03-29 14:11:25', '22', NULL, NULL, NULL),
(574, NULL, 'STU094', 'Ali', 'Ilyas', 'M', NULL, '12293057241', 'Lahore', 1, '2026-03-29 14:11:25', '23', NULL, NULL, NULL),
(575, NULL, 'STU095', 'Nidab', 'Ale Mele', 'F', '0000-00-00', '12392924805', 'Rawalpindi', 1, '2026-03-29 14:11:25', '24', NULL, NULL, NULL),
(576, NULL, 'STU096', 'Hadiqa', 'murtuza', 'F', NULL, '12492792370', 'Islamabad', 1, '2026-03-29 14:11:25', '25', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student_class_assignments`
--

CREATE TABLE `student_class_assignments` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `class_section_id` int(11) NOT NULL,
  `assigned_at` datetime NOT NULL DEFAULT current_timestamp(),
  `assigned_by_user_id` int(11) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `roll_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_class_assignments`
--

INSERT INTO `student_class_assignments` (`id`, `student_id`, `class_section_id`, `assigned_at`, `assigned_by_user_id`, `note`, `roll_number`) VALUES
(81, 481, 1, '2026-03-29 14:11:25', 4, '', 1),
(82, 482, 1, '2026-03-29 14:11:25', 4, '', 2),
(83, 483, 1, '2026-03-29 14:11:25', 4, '', 3),
(84, 484, 1, '2026-03-29 14:11:25', 4, '', 4),
(85, 485, 1, '2026-03-29 14:11:25', 4, '', 5),
(86, 486, 1, '2026-03-29 14:11:25', 4, '', 6),
(87, 487, 1, '2026-03-29 14:11:25', 4, '', 7),
(88, 488, 1, '2026-03-29 14:11:25', 4, '', 8),
(89, 489, 1, '2026-03-29 14:11:25', 4, '', 9),
(90, 490, 1, '2026-03-29 14:11:25', 4, '', 10),
(91, 491, 1, '2026-03-29 14:11:25', 4, '', 11),
(92, 492, 1, '2026-03-29 14:11:25', 4, '', 12),
(93, 493, 1, '2026-03-29 14:11:25', 4, '', 13),
(94, 494, 1, '2026-03-29 14:11:25', 4, '', 14),
(95, 495, 1, '2026-03-29 14:11:25', 4, '', 15),
(96, 496, 1, '2026-03-29 14:11:25', 4, '', 16),
(97, 497, 1, '2026-03-29 14:11:25', 4, '', 17),
(98, 498, 1, '2026-03-29 14:11:25', 4, '', 18),
(99, 499, 2, '2026-03-29 14:11:25', 4, '', 1),
(100, 500, 2, '2026-03-29 14:11:25', 4, '', 2),
(101, 501, 2, '2026-03-29 14:11:25', 4, '', 3),
(102, 502, 2, '2026-03-29 14:11:25', 4, '', 4),
(103, 503, 2, '2026-03-29 14:11:25', 4, '', 5),
(104, 504, 2, '2026-03-29 14:11:25', 4, '', 6),
(105, 505, 2, '2026-03-29 14:11:25', 4, '', 7),
(106, 506, 2, '2026-03-29 14:11:25', 4, '', 8),
(107, 507, 2, '2026-03-29 14:11:25', 4, '', 9),
(108, 508, 2, '2026-03-29 14:11:25', 4, '', 10),
(109, 509, 2, '2026-03-29 14:11:25', 4, '', 11),
(110, 510, 2, '2026-03-29 14:11:25', 4, '', 12),
(111, 511, 2, '2026-03-29 14:11:25', 4, '', 13),
(112, 512, 2, '2026-03-29 14:11:25', 4, '', 14),
(113, 513, 2, '2026-03-29 14:11:25', 4, '', 15),
(114, 514, 2, '2026-03-29 14:11:25', 4, '', 16),
(115, 515, 2, '2026-03-29 14:11:25', 4, '', 17),
(116, 516, 2, '2026-03-29 14:11:25', 4, '', 18),
(117, 517, 2, '2026-03-29 14:11:25', 4, '', 19),
(118, 518, 2, '2026-03-29 14:11:25', 4, '', 20),
(119, 519, 2, '2026-03-29 14:11:25', 4, '', 21),
(120, 520, 2, '2026-03-29 14:11:25', 4, '', 22),
(121, 521, 3, '2026-03-29 14:11:25', 4, '', 1),
(122, 522, 3, '2026-03-29 14:11:25', 4, '', 2),
(123, 523, 3, '2026-03-29 14:11:25', 4, '', 3),
(124, 524, 3, '2026-03-29 14:11:25', 4, '', 4),
(125, 525, 3, '2026-03-29 14:11:25', 4, '', 5),
(126, 526, 3, '2026-03-29 14:11:25', 4, '', 6),
(127, 527, 3, '2026-03-29 14:11:25', 4, '', 7),
(128, 528, 3, '2026-03-29 14:11:25', 4, '', 8),
(129, 529, 3, '2026-03-29 14:11:25', 4, '', 9),
(130, 530, 3, '2026-03-29 14:11:25', 4, '', 10),
(131, 531, 3, '2026-03-29 14:11:25', 4, '', 11),
(132, 532, 3, '2026-03-29 14:11:25', 4, '', 12),
(133, 533, 3, '2026-03-29 14:11:25', 4, '', 13),
(134, 534, 4, '2026-03-29 14:11:25', 4, '', 1),
(135, 535, 4, '2026-03-29 14:11:25', 4, '', 2),
(136, 536, 4, '2026-03-29 14:11:25', 4, '', 3),
(137, 537, 4, '2026-03-29 14:11:25', 4, '', 4),
(138, 538, 4, '2026-03-29 14:11:25', 4, '', 5),
(139, 539, 4, '2026-03-29 14:11:25', 4, '', 6),
(140, 540, 4, '2026-03-29 14:11:25', 4, '', 7),
(141, 541, 4, '2026-03-29 14:11:25', 4, '', 8),
(142, 542, 4, '2026-03-29 14:11:25', 4, '', 9),
(143, 543, 4, '2026-03-29 14:11:25', 4, '', 10),
(144, 544, 4, '2026-03-29 14:11:25', 4, '', 11),
(145, 545, 4, '2026-03-29 14:11:25', 4, '', 12),
(146, 546, 4, '2026-03-29 14:11:25', 4, '', 13),
(147, 547, 4, '2026-03-29 14:11:25', 4, '', 14),
(148, 548, 4, '2026-03-29 14:11:25', 4, '', 15),
(149, 549, 4, '2026-03-29 14:11:25', 4, '', 16),
(150, 550, 4, '2026-03-29 14:11:25', 4, '', 17),
(151, 551, 4, '2026-03-29 14:11:25', 4, '', 18),
(152, 552, 5, '2026-03-29 14:11:25', 4, '', 1),
(153, 553, 5, '2026-03-29 14:11:25', 4, '', 2),
(154, 554, 5, '2026-03-29 14:11:25', 4, '', 3),
(155, 555, 5, '2026-03-29 14:11:25', 4, '', 4),
(156, 556, 5, '2026-03-29 14:11:25', 4, '', 5),
(157, 557, 5, '2026-03-29 14:11:25', 4, '', 6),
(158, 558, 5, '2026-03-29 14:11:25', 4, '', 7),
(159, 559, 5, '2026-03-29 14:11:25', 4, '', 8),
(160, 560, 5, '2026-03-29 14:11:25', 4, '', 9),
(161, 561, 5, '2026-03-29 14:11:25', 4, '', 10),
(162, 562, 5, '2026-03-29 14:11:25', 4, '', 11),
(163, 563, 5, '2026-03-29 14:11:25', 4, '', 12),
(164, 564, 5, '2026-03-29 14:11:25', 4, '', 13),
(165, 565, 5, '2026-03-29 14:11:25', 4, '', 14),
(166, 566, 5, '2026-03-29 14:11:25', 4, '', 15),
(167, 567, 5, '2026-03-29 14:11:25', 4, '', 16),
(168, 568, 5, '2026-03-29 14:11:25', 4, '', 17),
(169, 569, 5, '2026-03-29 14:11:25', 4, '', 18),
(170, 570, 5, '2026-03-29 14:11:25', 4, '', 19),
(171, 571, 5, '2026-03-29 14:11:25', 4, '', 20),
(172, 572, 5, '2026-03-29 14:11:25', 4, '', 21),
(173, 573, 5, '2026-03-29 14:11:25', 4, '', 22),
(174, 574, 5, '2026-03-29 14:11:25', 4, '', 23),
(175, 575, 5, '2026-03-29 14:11:25', 4, '', 24),
(176, 576, 5, '2026-03-29 14:11:25', 4, '', 25);

-- --------------------------------------------------------

--
-- Table structure for table `student_guardians`
--

CREATE TABLE `student_guardians` (
  `student_id` int(11) NOT NULL,
  `guardian_id` int(11) NOT NULL,
  `is_primary` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student_promotions`
--

CREATE TABLE `student_promotions` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `from_class_section_id` int(11) NOT NULL,
  `to_class_section_id` int(11) NOT NULL,
  `promoted_at` datetime NOT NULL DEFAULT current_timestamp(),
  `promoted_by_user_id` int(11) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `subject_code` varchar(30) DEFAULT NULL,
  `subject_name` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `subject_code`, `subject_name`) VALUES
(1, 'Nur Eng', 'English Nursery'),
(2, 'Nur Urdu', 'Urdu Nursery'),
(3, 'NurMth', 'Math Nursery');

-- --------------------------------------------------------

--
-- Table structure for table `timetable_entries`
--

CREATE TABLE `timetable_entries` (
  `id` int(11) NOT NULL,
  `class_section_id` int(11) NOT NULL,
  `day_of_week` tinyint(4) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `subject_id` int(11) NOT NULL,
  `room` varchar(60) DEFAULT NULL,
  `created_by_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `timetable_entries`
--

INSERT INTO `timetable_entries` (`id`, `class_section_id`, `day_of_week`, `start_time`, `end_time`, `subject_id`, `room`, `created_by_user_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '09:00:00', '09:30:00', 1, '', 4, '2026-03-30 17:17:26', NULL),
(2, 1, 1, '09:30:00', '10:00:00', 3, '', 4, '2026-03-30 17:18:10', NULL),
(3, 1, 1, '10:00:00', '11:00:00', 2, '', 4, '2026-03-30 17:18:58', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `role_id`, `status`, `created_at`, `updated_at`) VALUES
(4, 'admin', 'admin@example.com', '$2y$10$RUPolnSuKwzKTXR5Fd8eYuokMYolloRIOs5Lr1h04bL3VoGh3gBE.', 1, 1, '2026-03-28 17:45:42', NULL),
(5, 'Mubashir', 'mubashirbaltistani1@gmail.com', '$2y$10$ywm60abAx4OQNpILFiJ/fue2QY510ex/35vFPXW/kiDneTTPfJ3F2', 5, 1, '2026-03-28 17:49:27', NULL);

-- --------------------------------------------------------

--
-- Structure for view `pending_dues_view`
--
DROP TABLE IF EXISTS `pending_dues_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `pending_dues_view`  AS SELECT `fi`.`id` AS `fee_invoice_id`, `fi`.`student_id` AS `student_id`, `fi`.`academic_year_id` AS `academic_year_id`, `fi`.`total_due`- ifnull(sum(`fc`.`amount`),0) AS `pending_amount` FROM (`fee_invoices` `fi` left join `fee_collections` `fc` on(`fc`.`fee_invoice_id` = `fi`.`id`)) GROUP BY `fi`.`id`, `fi`.`student_id`, `fi`.`academic_year_id`, `fi`.`total_due` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic_years`
--
ALTER TABLE `academic_years`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `academic_year_label` (`academic_year_label`);

--
-- Indexes for table `attendance_records`
--
ALTER TABLE `attendance_records`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_attendance` (`student_id`,`class_section_id`,`subject_id`,`attendance_date`),
  ADD KEY `fk_att_cs` (`class_section_id`),
  ADD KEY `fk_att_subject` (`subject_id`),
  ADD KEY `fk_att_by` (`created_by_user_id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `class_sections`
--
ALTER TABLE `class_sections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_class_sections` (`class_id`,`section_id`,`academic_year_id`),
  ADD KEY `fk_class_sections_section` (`section_id`),
  ADD KEY `fk_class_sections_year` (`academic_year_id`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_comp_student` (`student_id`),
  ADD KEY `fk_comp_by` (`submitted_by_user_id`);

--
-- Indexes for table `custom_fields`
--
ALTER TABLE `custom_fields`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_custom_field` (`scope`,`field_key`);

--
-- Indexes for table `custom_field_values`
--
ALTER TABLE `custom_field_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_cfv_field` (`custom_field_id`),
  ADD KEY `fk_cfv_user` (`user_id`),
  ADD KEY `fk_cfv_student` (`student_id`),
  ADD KEY `fk_cfv_staff` (`staff_profile_id`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_exams_group` (`exam_group_id`),
  ADD KEY `fk_exams_year` (`academic_year_id`),
  ADD KEY `fk_exams_cs` (`class_section_id`),
  ADD KEY `fk_exams_by` (`created_by_user_id`);

--
-- Indexes for table `exam_groups`
--
ALTER TABLE `exam_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_exam_group` (`exam_type_id`,`name`);

--
-- Indexes for table `exam_rules`
--
ALTER TABLE `exam_rules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_exam_rules` (`exam_group_id`);

--
-- Indexes for table `exam_types`
--
ALTER TABLE `exam_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `fee_assignments`
--
ALTER TABLE `fee_assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_fa_category` (`fee_category_id`),
  ADD KEY `fk_fa_year` (`academic_year_id`),
  ADD KEY `fk_fa_student` (`student_id`),
  ADD KEY `fk_fa_cs` (`class_section_id`);

--
-- Indexes for table `fee_categories`
--
ALTER TABLE `fee_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `fee_collections`
--
ALTER TABLE `fee_collections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_fc_invoice` (`fee_invoice_id`),
  ADD KEY `fk_fc_by` (`collected_by_user_id`);

--
-- Indexes for table `fee_custom_fines`
--
ALTER TABLE `fee_custom_fines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_fcf_invoice` (`fee_invoice_id`),
  ADD KEY `fk_fcf_by` (`added_by_user_id`);

--
-- Indexes for table `fee_discount_rules`
--
ALTER TABLE `fee_discount_rules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `fee_fine_rules`
--
ALTER TABLE `fee_fine_rules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `fee_invoices`
--
ALTER TABLE `fee_invoices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoice_no` (`invoice_no`),
  ADD KEY `fk_fi_student` (`student_id`),
  ADD KEY `fk_fi_year` (`academic_year_id`),
  ADD KEY `fk_fi_by` (`created_by_user_id`);

--
-- Indexes for table `fee_invoice_lines`
--
ALTER TABLE `fee_invoice_lines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_fil_invoice` (`fee_invoice_id`),
  ADD KEY `fk_fil_category` (`fee_category_id`);

--
-- Indexes for table `fee_student_reconciliation`
--
ALTER TABLE `fee_student_reconciliation`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_student_year` (`student_id`,`academic_year_id`),
  ADD KEY `fk_fsr_year` (`academic_year_id`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `grade_letter` (`grade_letter`);

--
-- Indexes for table `guardians`
--
ALTER TABLE `guardians`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `inquiries`
--
ALTER TABLE `inquiries`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `inquiry_no` (`inquiry_no`),
  ADD KEY `fk_inq_class` (`requested_class_id`),
  ADD KEY `fk_inq_section` (`requested_section_id`),
  ADD KEY `fk_inq_by` (`reviewed_by_user_id`);

--
-- Indexes for table `label_overrides`
--
ALTER TABLE `label_overrides`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_label_overrides` (`module_name`,`field_key`);

--
-- Indexes for table `leave_approvals`
--
ALTER TABLE `leave_approvals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_la_lr` (`leave_request_id`),
  ADD KEY `fk_la_by` (`approved_by_user_id`);

--
-- Indexes for table `leave_requests`
--
ALTER TABLE `leave_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_lr_staff` (`staff_profile_id`),
  ADD KEY `fk_lr_by` (`requested_by_user_id`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_marks` (`exam_id`,`student_id`,`subject_id`),
  ADD KEY `fk_marks_student` (`student_id`),
  ADD KEY `fk_marks_cs` (`class_section_id`),
  ADD KEY `fk_marks_subject` (`subject_id`),
  ADD KEY `fk_marks_grade` (`grade_id`),
  ADD KEY `fk_marks_by` (`entered_by_user_id`);

--
-- Indexes for table `performance_reports`
--
ALTER TABLE `performance_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pr_staff` (`staff_profile_id`),
  ADD KEY `fk_pr_by` (`created_by_user_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permission_key` (`permission_key`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`role_id`,`permission_id`),
  ADD KEY `fk_role_permissions_permission` (`permission_id`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `staff_attendance_records`
--
ALTER TABLE `staff_attendance_records`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_s_att` (`staff_profile_id`,`attendance_date`),
  ADD KEY `fk_sar_by` (`created_by_user_id`);

--
-- Indexes for table `staff_profiles`
--
ALTER TABLE `staff_profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `staff_code` (`staff_code`);

--
-- Indexes for table `staff_roles`
--
ALTER TABLE `staff_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `staff_role_assignments`
--
ALTER TABLE `staff_role_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_sra` (`staff_profile_id`,`staff_role_id`),
  ADD KEY `fk_sra_role` (`staff_role_id`),
  ADD KEY `fk_sra_by` (`assigned_by_user_id`);

--
-- Indexes for table `staff_salary_details`
--
ALTER TABLE `staff_salary_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_staff_month` (`staff_profile_id`,`salary_month`,`salary_year`),
  ADD KEY `fk_sd_by` (`created_by_user_id`);

--
-- Indexes for table `staff_salary_payments`
--
ALTER TABLE `staff_salary_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_ssp_detail` (`staff_salary_detail_id`),
  ADD KEY `fk_ssp_by` (`paid_by_user_id`);

--
-- Indexes for table `staff_subject_assignments`
--
ALTER TABLE `staff_subject_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_ssa` (`staff_profile_id`,`subject_id`),
  ADD KEY `fk_ssa_subject` (`subject_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admission_no` (`admission_no`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `student_class_assignments`
--
ALTER TABLE `student_class_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_roll_class` (`class_section_id`,`roll_number`),
  ADD KEY `fk_sca_student` (`student_id`),
  ADD KEY `fk_sca_by` (`assigned_by_user_id`);

--
-- Indexes for table `student_guardians`
--
ALTER TABLE `student_guardians`
  ADD PRIMARY KEY (`student_id`,`guardian_id`),
  ADD KEY `fk_sg_guardian` (`guardian_id`);

--
-- Indexes for table `student_promotions`
--
ALTER TABLE `student_promotions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_sp_student` (`student_id`),
  ADD KEY `fk_sp_from` (`from_class_section_id`),
  ADD KEY `fk_sp_to` (`to_class_section_id`),
  ADD KEY `fk_sp_by` (`promoted_by_user_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_subject_name` (`subject_name`),
  ADD UNIQUE KEY `uq_subject_code` (`subject_code`);

--
-- Indexes for table `timetable_entries`
--
ALTER TABLE `timetable_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_tte_cs` (`class_section_id`),
  ADD KEY `fk_tte_subject` (`subject_id`),
  ADD KEY `fk_tte_by` (`created_by_user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fk_users_role` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academic_years`
--
ALTER TABLE `academic_years`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `attendance_records`
--
ALTER TABLE `attendance_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `class_sections`
--
ALTER TABLE `class_sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `custom_fields`
--
ALTER TABLE `custom_fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `custom_field_values`
--
ALTER TABLE `custom_field_values`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `exam_groups`
--
ALTER TABLE `exam_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `exam_rules`
--
ALTER TABLE `exam_rules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `exam_types`
--
ALTER TABLE `exam_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fee_assignments`
--
ALTER TABLE `fee_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fee_categories`
--
ALTER TABLE `fee_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fee_collections`
--
ALTER TABLE `fee_collections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `fee_custom_fines`
--
ALTER TABLE `fee_custom_fines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `fee_discount_rules`
--
ALTER TABLE `fee_discount_rules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fee_fine_rules`
--
ALTER TABLE `fee_fine_rules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fee_invoices`
--
ALTER TABLE `fee_invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;

--
-- AUTO_INCREMENT for table `fee_invoice_lines`
--
ALTER TABLE `fee_invoice_lines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT for table `fee_student_reconciliation`
--
ALTER TABLE `fee_student_reconciliation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `guardians`
--
ALTER TABLE `guardians`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inquiries`
--
ALTER TABLE `inquiries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `label_overrides`
--
ALTER TABLE `label_overrides`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_approvals`
--
ALTER TABLE `leave_approvals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_requests`
--
ALTER TABLE `leave_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=251;

--
-- AUTO_INCREMENT for table `performance_reports`
--
ALTER TABLE `performance_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `staff_attendance_records`
--
ALTER TABLE `staff_attendance_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `staff_profiles`
--
ALTER TABLE `staff_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `staff_roles`
--
ALTER TABLE `staff_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff_role_assignments`
--
ALTER TABLE `staff_role_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff_salary_details`
--
ALTER TABLE `staff_salary_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `staff_salary_payments`
--
ALTER TABLE `staff_salary_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `staff_subject_assignments`
--
ALTER TABLE `staff_subject_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=577;

--
-- AUTO_INCREMENT for table `student_class_assignments`
--
ALTER TABLE `student_class_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=177;

--
-- AUTO_INCREMENT for table `student_promotions`
--
ALTER TABLE `student_promotions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `timetable_entries`
--
ALTER TABLE `timetable_entries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance_records`
--
ALTER TABLE `attendance_records`
  ADD CONSTRAINT `fk_att_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_att_cs` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`),
  ADD CONSTRAINT `fk_att_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_att_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `class_sections`
--
ALTER TABLE `class_sections`
  ADD CONSTRAINT `fk_class_sections_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`),
  ADD CONSTRAINT `fk_class_sections_section` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`),
  ADD CONSTRAINT `fk_class_sections_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `complaints`
--
ALTER TABLE `complaints`
  ADD CONSTRAINT `fk_comp_by` FOREIGN KEY (`submitted_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_comp_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `custom_field_values`
--
ALTER TABLE `custom_field_values`
  ADD CONSTRAINT `fk_cfv_field` FOREIGN KEY (`custom_field_id`) REFERENCES `custom_fields` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cfv_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cfv_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cfv_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `exams`
--
ALTER TABLE `exams`
  ADD CONSTRAINT `fk_exams_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_exams_cs` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_exams_group` FOREIGN KEY (`exam_group_id`) REFERENCES `exam_groups` (`id`),
  ADD CONSTRAINT `fk_exams_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `exam_groups`
--
ALTER TABLE `exam_groups`
  ADD CONSTRAINT `fk_exam_groups_type` FOREIGN KEY (`exam_type_id`) REFERENCES `exam_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `exam_rules`
--
ALTER TABLE `exam_rules`
  ADD CONSTRAINT `fk_exam_rules_group` FOREIGN KEY (`exam_group_id`) REFERENCES `exam_groups` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fee_assignments`
--
ALTER TABLE `fee_assignments`
  ADD CONSTRAINT `fk_fa_category` FOREIGN KEY (`fee_category_id`) REFERENCES `fee_categories` (`id`),
  ADD CONSTRAINT `fk_fa_cs` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fa_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fa_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `fee_collections`
--
ALTER TABLE `fee_collections`
  ADD CONSTRAINT `fk_fc_by` FOREIGN KEY (`collected_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_fc_invoice` FOREIGN KEY (`fee_invoice_id`) REFERENCES `fee_invoices` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fee_custom_fines`
--
ALTER TABLE `fee_custom_fines`
  ADD CONSTRAINT `fk_fcf_by` FOREIGN KEY (`added_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_fcf_invoice` FOREIGN KEY (`fee_invoice_id`) REFERENCES `fee_invoices` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fee_invoices`
--
ALTER TABLE `fee_invoices`
  ADD CONSTRAINT `fk_fi_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_fi_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fi_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `fee_invoice_lines`
--
ALTER TABLE `fee_invoice_lines`
  ADD CONSTRAINT `fk_fil_category` FOREIGN KEY (`fee_category_id`) REFERENCES `fee_categories` (`id`),
  ADD CONSTRAINT `fk_fil_invoice` FOREIGN KEY (`fee_invoice_id`) REFERENCES `fee_invoices` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fee_student_reconciliation`
--
ALTER TABLE `fee_student_reconciliation`
  ADD CONSTRAINT `fk_fsr_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fsr_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `guardians`
--
ALTER TABLE `guardians`
  ADD CONSTRAINT `fk_guardians_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `inquiries`
--
ALTER TABLE `inquiries`
  ADD CONSTRAINT `fk_inq_by` FOREIGN KEY (`reviewed_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_inq_class` FOREIGN KEY (`requested_class_id`) REFERENCES `classes` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_inq_section` FOREIGN KEY (`requested_section_id`) REFERENCES `sections` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `leave_approvals`
--
ALTER TABLE `leave_approvals`
  ADD CONSTRAINT `fk_la_by` FOREIGN KEY (`approved_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_la_lr` FOREIGN KEY (`leave_request_id`) REFERENCES `leave_requests` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `leave_requests`
--
ALTER TABLE `leave_requests`
  ADD CONSTRAINT `fk_lr_by` FOREIGN KEY (`requested_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_lr_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `marks`
--
ALTER TABLE `marks`
  ADD CONSTRAINT `fk_marks_by` FOREIGN KEY (`entered_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_marks_cs` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`),
  ADD CONSTRAINT `fk_marks_exam` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_marks_grade` FOREIGN KEY (`grade_id`) REFERENCES `grades` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_marks_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_marks_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`);

--
-- Constraints for table `performance_reports`
--
ALTER TABLE `performance_reports`
  ADD CONSTRAINT `fk_pr_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_pr_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD CONSTRAINT `fk_role_permissions_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `staff_attendance_records`
--
ALTER TABLE `staff_attendance_records`
  ADD CONSTRAINT `fk_sar_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_sar_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `staff_profiles`
--
ALTER TABLE `staff_profiles`
  ADD CONSTRAINT `fk_staff_profiles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `staff_role_assignments`
--
ALTER TABLE `staff_role_assignments`
  ADD CONSTRAINT `fk_sra_by` FOREIGN KEY (`assigned_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_sra_role` FOREIGN KEY (`staff_role_id`) REFERENCES `staff_roles` (`id`),
  ADD CONSTRAINT `fk_sra_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `staff_salary_details`
--
ALTER TABLE `staff_salary_details`
  ADD CONSTRAINT `fk_sd_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_sd_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `staff_salary_payments`
--
ALTER TABLE `staff_salary_payments`
  ADD CONSTRAINT `fk_ssp_by` FOREIGN KEY (`paid_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_ssp_detail` FOREIGN KEY (`staff_salary_detail_id`) REFERENCES `staff_salary_details` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `staff_subject_assignments`
--
ALTER TABLE `staff_subject_assignments`
  ADD CONSTRAINT `fk_ssa_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_ssa_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `fk_students_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `student_class_assignments`
--
ALTER TABLE `student_class_assignments`
  ADD CONSTRAINT `fk_sca_by` FOREIGN KEY (`assigned_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_sca_cs` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`),
  ADD CONSTRAINT `fk_sca_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_guardians`
--
ALTER TABLE `student_guardians`
  ADD CONSTRAINT `fk_sg_guardian` FOREIGN KEY (`guardian_id`) REFERENCES `guardians` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sg_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_promotions`
--
ALTER TABLE `student_promotions`
  ADD CONSTRAINT `fk_sp_by` FOREIGN KEY (`promoted_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_sp_from` FOREIGN KEY (`from_class_section_id`) REFERENCES `class_sections` (`id`),
  ADD CONSTRAINT `fk_sp_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sp_to` FOREIGN KEY (`to_class_section_id`) REFERENCES `class_sections` (`id`);

--
-- Constraints for table `timetable_entries`
--
ALTER TABLE `timetable_entries`
  ADD CONSTRAINT `fk_tte_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_tte_cs` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_tte_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
