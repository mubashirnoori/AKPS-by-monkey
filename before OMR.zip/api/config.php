<?php
declare(strict_types=1);

/**
 * SMS Mobile API - Configuration
 * ---------------------------------
 * This API reuses the database credentials from your main application's
 * config/config.php (the same file index.php loads). You normally do NOT need
 * to change anything here.
 *
 * To override, either:
 *   1. Edit the values below, or
 *   2. Set environment variables: DB_HOST, DB_USER, DB_PASS, DB_NAME, SMS_API_SECRET
 */

$existing = [];
$parentConfigFile = __DIR__ . '/../config/config.php';
if (is_file($parentConfigFile)) {
    $loaded = require $parentConfigFile;
    if (is_array($loaded)) {
        $existing = $loaded;
    }
}

$db = $existing['db'] ?? [];

return [
    'db' => [
        'host'    => getenv('DB_HOST') ?: ($db['host'] ?? '127.0.0.1'),
        'user'    => getenv('DB_USER') ?: ($db['user'] ?? ''),
        'pass'    => getenv('DB_PASS') ?: ($db['pass'] ?? ''),
        'name'    => getenv('DB_NAME') ?: ($db['name'] ?? ''),
        'charset' => $db['charset'] ?? 'utf8mb4',
    ],
    'app' => [
        'name'     => $existing['app']['name'] ?? 'School Management System',
        'timezone' => $existing['app']['timezone'] ?? 'Asia/Karachi',
    ],
    // IMPORTANT: change this to a long random string (e.g. 40+ random characters).
    'api_secret'   => getenv('SMS_API_SECRET') ?: 'kdsfjioewjfkdsfjiewffe65s4f53ds4f4f5d4f8r54f5468we7fds5fdsf454f',
    'token_ttl'    => 7 * 24 * 3600, // seconds (7 days)
    'debug'        => false,
];
