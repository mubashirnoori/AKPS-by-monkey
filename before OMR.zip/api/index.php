<?php
declare(strict_types=1);

/**
 * SMS Mobile REST API
 * ===================
 * Self-contained API that reads/writes the existing School Management System
 * database directly (PDO + prepared statements). No composer, no framework.
 *
 * Deployment: upload this `api/` folder into your website root (the folder that
 * contains index.php — or inside public/ if that is your document root).
 *
 * Auth: HMAC-signed tokens. password_hash() in the users table is verified
 * against the same credentials the web portal accepts.
 */

error_reporting(E_ALL);
ini_set('display_errors', '0');

$config = require __DIR__ . '/config.php';
date_default_timezone_set((string)($config['app']['timezone'] ?? 'Asia/Karachi'));

/* ---------------------------------- CORS --------------------------------- */
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

/* ------------------------------- JSON helpers ---------------------------- */
function json_out($data, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function fail(string $message, int $status = 400): void
{
    json_out(['error' => $message], $status);
}

function body(): array
{
    $raw = file_get_contents('php://input');
    if ($raw !== false && $raw !== '') {
        $json = json_decode($raw, true);
        if (is_array($json)) {
            return $json;
        }
    }
    return $_POST ?: [];
}

/* ---------------------------------- DB ----------------------------------- */
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        global $config;
        $db = $config['db'];
        if ($db['user'] === '' || $db['name'] === '') {
            fail('API database is not configured. See api/config.php', 500);
        }
        $dsn = 'mysql:host=' . $db['host'] . ';dbname=' . $db['name'] . ';charset=' . $db['charset'];
        $pdo = new PDO($dsn, $db['user'], $db['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }
    return $pdo;
}

function q(string $sql, array $params = []): array
{
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function q1(string $sql, array $params = []): ?array
{
    $rows = q($sql, $params);
    return $rows[0] ?? null;
}

function qv(string $sql, array $params = [], $default = null)
{
    $row = q1($sql, $params);
    if ($row === null) {
        return $default;
    }
    return reset($row);
}

function qx(string $sql, array $params = []): bool
{
    $stmt = db()->prepare($sql);
    return $stmt->execute($params);
}

function qInsert(string $sql, array $params = []): int
{
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return (int)db()->lastInsertId();
}

function tableExists(string $table): bool
{
    try {
        $row = q1('SHOW TABLES LIKE ?', [$table]);
        return $row !== null;
    } catch (Throwable $e) {
        return false;
    }
}

/* ---------------------- SMS gateway (Android relay) ----------------------- */
/* Mirrors app/core/helpers.php's queue_sms()/issue_otp()/verify_otp() so this
 * self-contained API doesn't need to require the main app's core files. See
 * db/migrate_sms_gateway.sql and docs/SMS_GATEWAY.md. */

function smsSettings(): array
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $cache = [];
    if (tableExists('settings')) {
        foreach (q('SELECT `key`, `value` FROM settings') as $row) {
            if (strpos((string)$row['key'], 'sms_') === 0) {
                $cache[$row['key']] = (string)$row['value'];
            }
        }
    }
    return $cache;
}

function smsEnabled(): bool
{
    return (smsSettings()['sms_enabled'] ?? '0') === '1';
}

function normalizePkMobile(?string $raw): ?string
{
    if ($raw === null || trim($raw) === '') {
        return null;
    }
    $digits = preg_replace('/\D+/', '', $raw) ?? '';
    if (strpos($digits, '0092') === 0) {
        $digits = substr($digits, 2);
    }
    if (strpos($digits, '92') === 0 && strlen($digits) === 12) {
        return '+' . $digits;
    }
    if (strpos($digits, '0') === 0 && strlen($digits) === 11) {
        return '+92' . substr($digits, 1);
    }
    if (strlen($digits) === 10 && strpos($digits, '3') === 0) {
        return '+92' . $digits;
    }
    return null;
}

function queueSms(?string $to, string $message, string $purpose = 'general'): bool
{
    if (!smsEnabled() || !tableExists('sms_outbox')) {
        return false;
    }
    $number = normalizePkMobile($to);
    if ($number === null) {
        return false;
    }
    try {
        qx('INSERT INTO sms_outbox (to_number, message, purpose, created_at) VALUES (?, ?, ?, NOW())', [$number, mb_substr($message, 0, 320), $purpose]);
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

function resolveUserMobile(int $userId): ?string
{
    $row = q1("SELECT phone FROM students WHERE user_id = ? AND phone IS NOT NULL AND phone <> '' LIMIT 1", [$userId])
        ?? q1("SELECT phone FROM guardians WHERE user_id = ? AND phone IS NOT NULL AND phone <> '' LIMIT 1", [$userId])
        ?? q1("SELECT phone FROM staff_profiles WHERE user_id = ? AND phone IS NOT NULL AND phone <> '' LIMIT 1", [$userId]);
    return $row['phone'] ?? null;
}

function issueOtp(int $userId, string $purpose = 'password_reset', int $ttlSeconds = 600): string
{
    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    qx('DELETE FROM otp_codes WHERE user_id = ? AND purpose = ? AND used_at IS NULL', [$userId, $purpose]);
    qx(
        'INSERT INTO otp_codes (user_id, purpose, code_hash, expires_at) VALUES (?, ?, ?, ?)',
        [$userId, $purpose, hash('sha256', $code), date('Y-m-d H:i:s', time() + $ttlSeconds)]
    );
    return $code;
}

function verifyOtp(string $identifier, string $code, string $purpose = 'password_reset'): ?int
{
    $user = q1('SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1', [$identifier, $identifier]);
    if (!$user) {
        return null;
    }
    $row = q1(
        'SELECT id, code_hash, attempts FROM otp_codes
         WHERE user_id = ? AND purpose = ? AND used_at IS NULL AND expires_at > NOW()
         ORDER BY id DESC LIMIT 1',
        [(int)$user['id'], $purpose]
    );
    if (!$row || (int)$row['attempts'] >= 5) {
        return null;
    }
    if (!hash_equals((string)$row['code_hash'], hash('sha256', $code))) {
        qx('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?', [(int)$row['id']]);
        return null;
    }
    qx('UPDATE otp_codes SET used_at = NOW() WHERE id = ?', [(int)$row['id']]);
    return (int)$user['id'];
}

/* --------------------------------- Tokens --------------------------------- */
function b64url_encode(string $data): string
{
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function b64url_decode(string $data): string
{
    $b64 = strtr($data, '-_', '+/');
    $pad = strlen($b64) % 4;
    if ($pad > 0) {
        $b64 .= str_repeat('=', 4 - $pad);
    }
    return base64_decode($b64, true) ?: '';
}

function issueToken(int $uid, string $role): string
{
    global $config;
    $payload = [
        'uid' => $uid,
        'role' => $role,
        'exp' => time() + (int)$config['token_ttl'],
    ];
    $json = json_encode($payload);
    $body64 = b64url_encode($json);
    $sig = hash_hmac('sha256', $body64, (string)$config['api_secret']);
    return $body64 . '.' . $sig;
}

/** @return array|null */
function decodeToken(string $token)
{
    global $config;
    $parts = explode('.', $token);
    if (count($parts) !== 2) {
        return null;
    }
    [$body64, $sig] = $parts;
    $expect = hash_hmac('sha256', $body64, (string)$config['api_secret']);
    if (!hash_equals($expect, $sig)) {
        return null;
    }
    $payload = json_decode(b64url_decode($body64), true);
    if (!is_array($payload) || empty($payload['uid']) || (int)$payload['exp'] < time()) {
        return null;
    }
    return $payload;
}

/* ------------------------------ Auth helpers ------------------------------ */
function currentUser(): ?array
{
    static $user = false;
    if ($user !== false) {
        return $user ?: null;
    }
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if ($header === '' && isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        $header = (string)$_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    }
    if (stripos($header, 'Bearer ') !== 0) {
        $user = null;
        return null;
    }
    $token = substr($header, 7);
    $payload = decodeToken($token);
    if ($payload === null) {
        $user = null;
        return null;
    }
    $row = q1('SELECT u.*, r.name AS role_name FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ? LIMIT 1', [(int)$payload['uid']]);
    if ($row === null || (int)($row['status'] ?? 0) !== 1) {
        $user = null;
        return null;
    }
    $user = $row;
    return $user;
}

function requireAuth(): array
{
    $u = currentUser();
    if ($u === null) {
        fail('Authentication required', 401);
    }
    return $u;
}

function requireRole(array $roles): array
{
    $u = requireAuth();
    $role = normalizeRole((string)$u['role_name']);
    if (!in_array($role, $roles, true)) {
        fail('Forbidden', 403);
    }
    return $u;
}

/**
 * Fine-grained permission check, mirroring the web app's RBAC::hasPermission().
 * Reads the same `permissions` / `role_permissions` tables, so granting or
 * revoking a permission for a role in the web admin panel takes effect here
 * too — no separate config to keep in sync.
 *
 * @param string|array<string> $permissionKey Single key, or an array (OR — any one grants access).
 */
function hasPermission(?array $u, $permissionKey): bool
{
    if (is_array($permissionKey)) {
        foreach ($permissionKey as $key) {
            if (hasPermission($u, $key)) {
                return true;
            }
        }
        return false;
    }
    if ($u === null) {
        return false;
    }
    $roleId = (int)($u['role_id'] ?? 0);
    if ($roleId <= 0) {
        return false;
    }

    static $cache = [];
    $cacheKey = $roleId . ':' . $permissionKey;
    if (array_key_exists($cacheKey, $cache)) {
        return $cache[$cacheKey];
    }

    $row = q1(
        'SELECT 1 FROM permissions p
         JOIN role_permissions rp ON rp.permission_id = p.id
         WHERE rp.role_id = ? AND p.permission_key = ? LIMIT 1',
        [$roleId, $permissionKey]
    );
    return $cache[$cacheKey] = ($row !== null);
}

/** @param string|array<string> $permissionKey */
function requirePermission($permissionKey): array
{
    $u = requireAuth();
    if (!hasPermission($u, $permissionKey)) {
        fail('Forbidden', 403);
    }
    return $u;
}

/**
 * Mirrors the web app's log_activity() helper so mobile-originated actions
 * show up in the same Activity Log the admin already reviews. Never throws —
 * a logging failure must not break the request it's logging.
 */
function logActivity(string $action, string $description): void
{
    try {
        $u = currentUser();
        qx(
            'INSERT INTO activity_log (user_id, username, role_name, action, description, ip_address) VALUES (?, ?, ?, ?, ?, ?)',
            [
                $u['id'] ?? null,
                $u['username'] ?? null,
                $u['role_name'] ?? null,
                $action,
                $description . ' (mobile app)',
                $_SERVER['REMOTE_ADDR'] ?? null,
            ]
        );
    } catch (Throwable $e) {
        // ignore — logging must never break the request it's logging
    }
}

function normalizeRole(string $role): string
{
    $role = strtolower(trim($role));
    $map = ['principal' => 'admin', 'admin' => 'admin', 'accountant' => 'accountant', 'teacher' => 'teacher', 'parent' => 'parent', 'student' => 'student'];
    return $map[$role] ?? 'admin';
}

/** Resolve the record id linked to a user via the users.user_id convention. */
function linkedId(string $table, int $userId): int
{
    try {
        $row = q1("SELECT id FROM {$table} WHERE user_id = ? LIMIT 1", [$userId]);
        return $row ? (int)$row['id'] : 0;
    } catch (Throwable $e) {
        return 0;
    }
}

/** All permission_key values granted to a role, for the login/me response. */
function rolePermissionKeys(int $roleId): array
{
    if ($roleId <= 0) {
        return [];
    }
    try {
        $rows = q(
            'SELECT p.permission_key FROM permissions p
             JOIN role_permissions rp ON rp.permission_id = p.id
             WHERE rp.role_id = ?',
            [$roleId]
        );
        return array_map(static fn($r) => (string)$r['permission_key'], $rows);
    } catch (Throwable $e) {
        return [];
    }
}

function userPayload(array $u): array
{
    $role = normalizeRole((string)$u['role_name']);
    $studentId = 0;
    $staffId = 0;
    $name = (string)$u['username'];

    if ($role === 'student') {
        $studentId = linkedId('students', (int)$u['id']);
        $row = $studentId > 0 ? q1('SELECT first_name, last_name FROM students WHERE id = ?', [$studentId]) : null;
        if ($row) {
            $name = trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? ''));
        }
    } elseif ($role === 'teacher') {
        $staffId = linkedId('staff_profiles', (int)$u['id']);
        $row = $staffId > 0 ? q1('SELECT full_name FROM staff_profiles WHERE id = ?', [$staffId]) : null;
        if ($row && !empty($row['full_name'])) {
            $name = (string)$row['full_name'];
        }
    } elseif ($role === 'parent') {
        $guardianId = linkedId('guardians', (int)$u['id']);
        $row = $guardianId > 0 ? q1('SELECT full_name FROM guardians WHERE id = ?', [$guardianId]) : null;
        if ($row && !empty($row['full_name'])) {
            $name = (string)$row['full_name'];
        }
    }

    return [
        'id' => (int)$u['id'],
        'username' => (string)$u['username'],
        'role' => $role,
        'name' => $name,
        'email' => $u['email'] ?? null,
        'student_id' => $studentId > 0 ? $studentId : null,
        'staff_id' => $staffId > 0 ? $staffId : null,
        'permissions' => rolePermissionKeys((int)($u['role_id'] ?? 0)),
    ];
}

/* ------------------------------ Data builders ----------------------------- */
function classSectionOf(int $studentId): array
{
    try {
        $row = q1(
            'SELECT cs.id AS class_section_id, c.name AS class_name, s.name AS section_name
             FROM student_class_assignments sca
             JOIN class_sections cs ON cs.id = sca.class_section_id
             JOIN classes c ON c.id = cs.class_id
             JOIN sections s ON s.id = cs.section_id
             WHERE sca.student_id = ?
             ORDER BY sca.assigned_at DESC, sca.id DESC
             LIMIT 1',
            [$studentId]
        );
        if (!$row) {
            return ['class_section_id' => 0, 'class_name' => '', 'section' => ''];
        }
        return [
            'class_section_id' => (int)$row['class_section_id'],
            'class_name' => (string)$row['class_name'],
            'section' => (string)$row['section_name'],
        ];
    } catch (Throwable $e) {
        return ['class_section_id' => 0, 'class_name' => '', 'section' => ''];
    }
}

function guardianOf(int $studentId): array
{
    try {
        $row = q1(
            'SELECT g.full_name, g.relation, g.phone
             FROM student_guardians sg
             JOIN guardians g ON g.id = sg.guardian_id
             WHERE sg.student_id = ?
             ORDER BY sg.id ASC
             LIMIT 1',
            [$studentId]
        );
        if (!$row) {
            return ['name' => '', 'relation' => '', 'phone' => ''];
        }
        return [
            'name' => (string)($row['full_name'] ?? ''),
            'relation' => (string)($row['relation'] ?? ''),
            'phone' => (string)($row['phone'] ?? ''),
        ];
    } catch (Throwable $e) {
        return ['name' => '', 'relation' => '', 'phone' => ''];
    }
}

function mapGender($g): string
{
    $g = strtoupper((string)$g);
    return $g === 'M' ? 'Male' : ($g === 'F' ? 'Female' : 'Other');
}

function studentPayload(array $s): array
{
    $cs = classSectionOf((int)$s['id']);
    $guardian = guardianOf((int)$s['id']);
    return [
        'id' => (int)$s['id'],
        'admission_no' => (string)($s['admission_no'] ?? ''),
        'first_name' => (string)($s['first_name'] ?? ''),
        'last_name' => (string)($s['last_name'] ?? ''),
        'full_name' => trim(($s['first_name'] ?? '') . ' ' . ($s['last_name'] ?? '')),
        'father_name' => (string)($s['father_name'] ?? ''),
        'cnic_no' => (string)($s['cnic_no'] ?? ''),
        'board_registration_no' => (string)($s['board_registration_no'] ?? ''),
        'roll_number' => $s['roll_number'] !== null ? (int)$s['roll_number'] : null,
        'gender' => mapGender($s['gender'] ?? 'M'),
        'dob' => $s['dob'] ?? null,
        'phone' => (string)($s['phone'] ?? ''),
        'email' => null,
        'class_name' => $cs['class_name'],
        'section' => $cs['section'],
        'status' => (int)($s['status'] ?? 1) === 1 ? 'Active' : 'Inactive',
        'guardian' => $guardian,
        'transport' => false,
    ];
}

function studentQuery(): string
{
    return 'SELECT s.*, c.name AS class_name, sec.name AS section_name
            FROM students s
            LEFT JOIN student_class_assignments sca
              ON sca.id = (SELECT sca2.id FROM student_class_assignments sca2
                           WHERE sca2.student_id = s.id
                           ORDER BY sca2.assigned_at DESC, sca2.id DESC LIMIT 1)
            LEFT JOIN class_sections cs ON cs.id = sca.class_section_id
            LEFT JOIN classes c ON c.id = cs.class_id
            LEFT JOIN sections sec ON sec.id = cs.section_id';
}

function normalizeAttendanceStatus($status): string
{
    $s = strtoupper(trim((string)$status));
    if ($s === 'P') return 'Present';
    if ($s === 'A') return 'Absent';
    if ($s === 'L') return 'Late';
    return $status ?: 'Present';
}

function attendanceSummary(int $studentId): array
{
    $rows = q('SELECT status FROM attendance_records WHERE student_id = ?', [$studentId]);
    $present = $absent = $late = 0;
    foreach ($rows as $r) {
        $st = normalizeAttendanceStatus($r['status'] ?? '');
        if ($st === 'Present') $present++;
        elseif ($st === 'Absent') $absent++;
        elseif ($st === 'Late') $late++;
    }
    $total = $present + $absent + $late;
    return [
        'total' => $total,
        'present' => $present,
        'absent' => $absent,
        'late' => $late,
        'percentage' => $total > 0 ? (int)round((($present + $late) / $total) * 100) : 0,
    ];
}

function gradeForPercentage(float $pct): array
{
    try {
        $grade = q1(
            'SELECT grade_letter, min_score FROM grades WHERE min_score <= ? ORDER BY min_score DESC LIMIT 1',
            [$pct]
        );
        if ($grade && !empty($grade['grade_letter'])) {
            return ['grade' => (string)$grade['grade_letter']];
        }
    } catch (Throwable $e) {
        // ignore - fall through to defaults
    }
    return ['grade' => $pct >= 50 ? 'C' : 'F'];
}

function studentMarks(int $studentId): array
{
    $rows = q(
        'SELECT e.id AS exam_id, e.exam_name, m.score, COALESCE(m.total_marks, 100) AS total_marks,
                su.subject_name, g.grade_letter
         FROM marks m
         JOIN exams e ON e.id = m.exam_id
         JOIN subjects su ON su.id = m.subject_id
         LEFT JOIN grades g ON g.id = m.grade_id
         WHERE m.student_id = ?
         ORDER BY e.id, su.subject_name',
        [$studentId]
    );

    $byExam = [];
    foreach ($rows as $r) {
        $examId = (int)$r['exam_id'];
        if (!isset($byExam[$examId])) {
            $byExam[$examId] = ['exam_id' => $examId, 'exam_name' => (string)$r['exam_name'], 'subjects' => []];
        }
        $byExam[$examId]['subjects'][] = [
            'subject' => (string)$r['subject_name'],
            'marks_obtained' => (float)$r['score'],
            'total_marks' => (float)$r['total_marks'],
            'grade' => (string)($r['grade_letter'] ?? ''),
        ];
    }

    $out = [];
    foreach ($byExam as $exam) {
        $obtained = 0.0;
        $max = 0.0;
        foreach ($exam['subjects'] as $sub) {
            $obtained += $sub['marks_obtained'];
            $max += $sub['total_marks'];
        }
        $pct = $max > 0 ? round(($obtained / $max) * 100, 1) : 0;
        $out[] = [
            'exam_id' => $exam['exam_id'],
            'exam_name' => $exam['exam_name'],
            'exam_type' => '',
            'percentage' => (int)$pct,
            'grade' => gradeForPercentage((float)$pct)['grade'],
            'subjects' => $exam['subjects'],
        ];
    }
    return $out;
}

function studentFees(int $studentId): array
{
    $invoices = q(
        'SELECT fi.*,
                COALESCE((SELECT SUM(fc.amount) FROM fee_collections fc WHERE fc.fee_invoice_id = fi.id), 0) AS collected
         FROM fee_invoices fi
         WHERE fi.student_id = ?
         ORDER BY fi.due_date DESC, fi.id DESC',
        [$studentId]
    );

    $totalBilled = $totalPaid = $totalDue = 0;
    $out = [];
    foreach ($invoices as $fi) {
        $total = (float)$fi['total_due'];
        $collected = (float)$fi['collected'];
        $balance = max(0.0, $total - $collected);
        $status = $balance <= 0.01 ? 'Paid' : ($collected > 0 ? 'Partial' : 'Unpaid');

        $totalBilled += $total;
        $totalPaid += $collected;
        $totalDue += $balance;

        $lines = q(
            'SELECT fil.*, fc.name AS category_name
             FROM fee_invoice_lines fil
             LEFT JOIN fee_categories fc ON fc.id = fil.fee_category_id
             WHERE fil.fee_invoice_id = ?',
            [(int)$fi['id']]
        );
        $payments = q('SELECT id, amount, method, collected_at FROM fee_collections WHERE fee_invoice_id = ? ORDER BY collected_at', [(int)$fi['id']]);

        $firstLine = $lines[0] ?? null;
        $month = null;
        if ($firstLine && !empty($firstLine['billing_month']) && !empty($firstLine['billing_year'])) {
            $month = date('F', mktime(0, 0, 0, (int)$firstLine['billing_month'], 1)) . ' ' . (int)$firstLine['billing_year'];
        }

        $out[] = [
            'id' => (int)$fi['id'],
            'invoice_no' => (string)($fi['invoice_no'] ?? 'INV-' . $fi['id']),
            'student_id' => (int)$fi['student_id'],
            'category' => $firstLine['category_name'] ?? 'Tuition Fee',
            'description' => trim((string)($firstLine['description'] ?? $fi['invoice_no'] ?? '')),
            'month' => $month,
            'amount' => (float)$fi['total_amount'],
            'fine' => (float)($fi['fine_applied'] ?? 0),
            'discount' => (float)($fi['total_discount'] ?? 0),
            'total' => $total,
            'paid_amount' => $collected,
            'balance' => round($balance, 2),
            'status' => $status,
            'due_date' => $fi['due_date'] ?? null,
            'created_at' => $fi['created_at'] ?? null,
            'payments' => array_map(static function ($p) {
                return [
                    'id' => (int)$p['id'],
                    'amount' => (float)$p['amount'],
                    'method' => (string)($p['method'] ?? ''),
                    'date' => (string)($p['collected_at'] ?? ''),
                ];
            }, $payments),
        ];
    }

    return [
        'summary' => [
            'totalBilled' => round($totalBilled, 2),
            'totalPaid' => round($totalPaid, 2),
            'totalDue' => round($totalDue, 2),
            'unpaidCount' => count(array_filter($out, static fn($i) => $i['balance'] > 0)),
        ],
        'invoices' => $out,
    ];
}

const DAY_NAMES = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

function studentTimetable(int $classSectionId): array
{
    if (!tableExists('timetable_entries')) {
        return ['timetable' => [], 'byDay' => []];
    }
    try {
        $rows = q(
            'SELECT te.*, su.subject_name,
                    COALESCE(sp.full_name, te.teacher_name) AS teacher_name
             FROM timetable_entries te
             LEFT JOIN subjects su ON su.id = te.subject_id
             LEFT JOIN staff_profiles sp ON sp.id = te.teacher_id
             WHERE te.class_section_id = ?
             ORDER BY te.day_of_week, te.start_time',
            [$classSectionId]
        );
    } catch (Throwable $e) {
        return ['timetable' => [], 'byDay' => []];
    }

    $list = [];
    $byDay = [];
    foreach ($rows as $r) {
        $dayIdx = max(0, (int)($r['day_of_week'] ?? 1) - 1);
        $day = DAY_NAMES[$dayIdx] ?? 'Monday';
        $entry = [
            'id' => (int)$r['id'],
            'class_section_id' => (int)$classSectionId,
            'class_name' => '',
            'section' => '',
            'day' => $day,
            'period' => (int)($r['period'] ?? 0),
            'time' => (string)($r['start_time'] ?? ''),
            'subject' => (string)($r['subject_name'] ?? ''),
            'teacher' => (string)($r['teacher_name'] ?? ''),
        ];
        $list[] = $entry;
        $byDay[$day][] = $entry;
    }
    foreach (DAY_NAMES as $d) {
        if (!isset($byDay[$d])) {
            $byDay[$d] = [];
        }
    }
    return ['timetable' => $list, 'byDay' => $byDay];
}

function notices(): array
{
    if (!tableExists('sms_notices')) {
        return [];
    }
    try {
        $rows = q('SELECT id, title, body, created_at FROM sms_notices ORDER BY created_at DESC LIMIT 10');
        return array_map(static function ($n) {
            return [
                'id' => (int)$n['id'],
                'title' => (string)$n['title'],
                'body' => (string)($n['body'] ?? ''),
                'date' => (string)($n['created_at'] ?? ''),
            ];
        }, $rows);
    } catch (Throwable $e) {
        return [];
    }
}

function schoolName(): string
{
    global $config;
    try {
        $row = q1("SELECT `value` FROM settings WHERE `key` IN ('school_name','site_name','branding_school_name') ORDER BY `key` LIMIT 1");
        if ($row && !empty($row['value'])) {
            return (string)$row['value'];
        }
    } catch (Throwable $e) {
    }
    return (string)($config['app']['name'] ?? 'Institute');
}

/* ------------------------------ Route helpers ----------------------------- */
function routeSegments(): array
{
    // Preferred: PATH_INFO, when the web server/rewrite config populates it
    // (e.g. "RewriteRule ^(.*)$ index.php/$1 [L]").
    $path = trim((string)($_SERVER['PATH_INFO'] ?? ''), '/');

    // Fallback 1: an explicit ?route= query param
    // (e.g. "RewriteRule ^(.*)$ index.php?route=$1 [QSA,L]").
    if ($path === '') {
        $path = trim((string)($_GET['route'] ?? ''), '/');
    }

    // Fallback 2 (host-independent): derive the route straight from
    // REQUEST_URI relative to this script's own folder. REQUEST_URI is
    // always set by the web server, unlike PATH_INFO — whose availability
    // depends on the specific Apache/PHP-FPM/CGI rewrite config and is
    // inconsistent on shared hosting (this was the actual bug: neither
    // PATH_INFO nor ?route= was being populated on this host, so every
    // request silently fell through to the "no route" branch below).
    if ($path === '') {
        $uri = (string)parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
        $base = rtrim(str_replace('\\', '/', (string)dirname((string)($_SERVER['SCRIPT_NAME'] ?? ''))), '/');
        if ($base !== '' && $base !== '/' && strpos($uri, $base) === 0) {
            $uri = substr($uri, strlen($base));
        }
        $path = trim($uri, '/');
    }

    if ($path === '') {
        return [];
    }
    return array_values(array_filter(explode('/', $path), static fn($s) => $s !== ''));
}

/* --------------------------------- Router -------------------------------- */
$segments = routeSegments();
$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));

if (empty($segments)) {
    json_out(['name' => schoolName(), 'version' => '1.0.0', 'endpoints' => '/auth/login, /dashboard, /students ...']);
}

$resource = array_shift($segments);
$id = $segments[0] ?? null;

/* ----------------------------- AUTH endpoints ----------------------------- */
if ($resource === 'auth') {
    $action = $id ?? '';

    if ($method === 'POST' && $action === 'login') {
        $b = body();
        $username = trim((string)($b['username'] ?? ''));
        $password = (string)($b['password'] ?? '');
        if ($username === '' || $password === '') {
            fail('Username and password are required', 422);
        }
        $u = q1(
            'SELECT u.*, r.name AS role_name FROM users u JOIN roles r ON r.id = u.role_id WHERE u.username = ? LIMIT 1',
            [$username]
        );
        if ($u === null || !password_verify($password, (string)$u['password_hash'])) {
            fail('Invalid username or password', 401);
        }
        if ((int)($u['status'] ?? 1) !== 1) {
            fail('Account is disabled', 403);
        }
        try {
            qx('UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?', [(int)$u['id']]);
        } catch (Throwable $e) {
        }
        json_out([
            'token' => issueToken((int)$u['id'], (string)$u['role_name']),
            'user' => userPayload($u),
        ]);
    }

    if ($method === 'POST' && $action === 'forgot-password') {
        $b = body();
        $identifier = trim((string)($b['identifier'] ?? ''));
        if ($identifier !== '') {
            $u = q1('SELECT id, username, email FROM users WHERE username = ? OR email = ? LIMIT 1', [$identifier, $identifier]);
            if ($u && !empty($u['email'])) {
                $token = bin2hex(random_bytes(32));
                $tokenHash = hash('sha256', $token);
                $expiresAt = date('Y-m-d H:i:s', time() + 1800);
                try {
                    qx('DELETE FROM password_resets WHERE user_id = ? AND used_at IS NULL', [(int)$u['id']]);
                    qx('INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?, ?, ?)', [(int)$u['id'], $tokenHash, $expiresAt]);
                    error_log('[SMS API] password reset for ' . $u['username'] . ' token=' . $token);
                } catch (Throwable $e) {
                }
            }
            if ($u) {
                $mobile = resolveUserMobile((int)$u['id']);
                if ($mobile !== null && smsEnabled()) {
                    $code = issueOtp((int)$u['id'], 'password_reset', 600);
                    queueSms(
                        $mobile,
                        'Your password reset code is ' . $code . '. It expires in 10 minutes. '
                            . 'If you did not request this, ignore this message.',
                        'otp'
                    );
                }
            }
        }
        json_out(['message' => 'If an account exists, a reset link and/or SMS code has been sent.']);
    }

    if ($method === 'POST' && $action === 'verify-otp') {
        $b = body();
        $identifier = trim((string)($b['identifier'] ?? ''));
        $code = trim((string)($b['code'] ?? ''));
        $new = (string)($b['new_password'] ?? '');
        $confirm = (string)($b['confirm_password'] ?? '');
        if ($identifier === '' || $code === '') {
            fail('identifier and code are required', 422);
        }
        if (strlen($new) < 6) {
            fail('New password must be at least 6 characters', 422);
        }
        if ($new !== $confirm) {
            fail('Passwords do not match', 422);
        }
        $userId = verifyOtp($identifier, $code, 'password_reset');
        if ($userId === null) {
            fail('That code is invalid or has expired', 400);
        }
        qx('UPDATE users SET password_hash = ?, failed_attempts = 0, locked_until = NULL WHERE id = ?', [password_hash($new, PASSWORD_BCRYPT), $userId]);
        json_out(['message' => 'Password updated.']);
    }

    if ($method === 'POST' && $action === 'reset-password') {
        $b = body();
        $token = trim((string)($b['token'] ?? ''));
        $new = (string)($b['new_password'] ?? '');
        $confirm = (string)($b['confirm_password'] ?? '');
        if (strlen($new) < 6) {
            fail('New password must be at least 6 characters', 422);
        }
        if ($new !== $confirm) {
            fail('Passwords do not match', 422);
        }
        $row = q1(
            'SELECT pr.user_id FROM password_resets pr WHERE pr.token_hash = ? AND pr.used_at IS NULL AND pr.expires_at > NOW() LIMIT 1',
            [hash('sha256', $token)]
        );
        if (!$row) {
            fail('Invalid or expired reset token', 400);
        }
        qx('UPDATE users SET password_hash = ?, failed_attempts = 0, locked_until = NULL WHERE id = ?', [password_hash($new, PASSWORD_BCRYPT), (int)$row['user_id']]);
        qx('UPDATE password_resets SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL', [(int)$row['user_id']]);
        json_out(['message' => 'Password updated.']);
    }

    if ($method === 'GET' && $action === 'me') {
        $u = requireAuth();
        json_out(['user' => userPayload($u)]);
    }

    if ($method === 'POST' && $action === 'change-password') {
        $u = requireAuth();
        $b = body();
        $current = (string)($b['current_password'] ?? '');
        $new = (string)($b['new_password'] ?? '');
        $confirm = (string)($b['confirm_password'] ?? '');
        if (!password_verify($current, (string)$u['password_hash'])) {
            fail('Current password is incorrect', 422);
        }
        if (strlen($new) < 6) {
            fail('New password must be at least 6 characters', 422);
        }
        if ($new !== $confirm) {
            fail('Passwords do not match', 422);
        }
        qx('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($new, PASSWORD_BCRYPT), (int)$u['id']]);
        json_out(['message' => 'Password updated successfully']);
    }

    fail('Unknown auth action', 404);
}

/* ------------------------------- /dashboard ------------------------------- */
if ($resource === 'dashboard') {
    requireAuth();
    $u = currentUser();
    $role = normalizeRole((string)$u['role_name']);

    if ($role === 'student' || $role === 'parent') {
        $studentId = 0;
        if ($role === 'student') {
            $studentId = linkedId('students', (int)$u['id']);
        } else {
            $guardianId = linkedId('guardians', (int)$u['id']);
            $row = $guardianId > 0 ? q1('SELECT student_id FROM student_guardians WHERE guardian_id = ? ORDER BY id LIMIT 1', [$guardianId]) : null;
            $studentId = $row ? (int)$row['student_id'] : 0;
        }
        if ($studentId <= 0) {
            fail('No student linked to this account', 404);
        }
        $s = q1('SELECT * FROM students WHERE id = ?', [$studentId]);
        $marks = studentMarks($studentId);
        $fees = studentFees($studentId);
        json_out([
            'student' => studentPayload($s ?? ['id' => $studentId]),
            'attendance' => attendanceSummary($studentId),
            'lastExam' => $marks[0] ?? null,
            'feeDue' => $fees['summary']['totalDue'],
            'notices' => notices(),
        ]);
    }

    if ($role === 'teacher') {
        $staffId = linkedId('staff_profiles', (int)$u['id']);
        $staff = $staffId > 0 ? q1('SELECT full_name, title FROM staff_profiles WHERE id = ?', [$staffId]) : null;
        $myClasses = teacherClasses($staffId);
        json_out([
            'teacher' => [
                'name' => (string)($staff['full_name'] ?? $u['username']),
                'designation' => (string)($staff['title'] ?? 'Teacher'),
                'subject' => implode(', ', array_slice(array_unique(array_column($myClasses, 'subject')) , 0, 1)),
            ],
            'myClasses' => $myClasses,
            'notices' => notices(),
        ]);
    }

    // admin / accountant
    $stats = [
        'totalStudents' => 0, 'activeStudents' => 0, 'totalStaff' => 0,
        'monthlyCollected' => 0, 'yearlyCollected' => 0, 'pendingDues' => 0, 'pendingInvoices' => 0,
        'yearlyExpenses' => 0, 'netBalance' => 0,
        'classes' => 0, 'attendanceToday' => null,
    ];
    try { $stats['totalStudents'] = (int)qv('SELECT COUNT(*) AS c FROM students', [], 0); } catch (Throwable $e) {}
    try { $stats['activeStudents'] = (int)qv('SELECT COUNT(*) AS c FROM students WHERE IFNULL(status, 1) = 1', [], 0); } catch (Throwable $e) {}
    try { $stats['totalStaff'] = (int)qv('SELECT COUNT(*) AS c FROM staff_profiles', [], 0); } catch (Throwable $e) {}
    try { $stats['classes'] = (int)qv('SELECT COUNT(*) AS c FROM class_sections', [], 0); } catch (Throwable $e) {}
    try {
        $stats['monthlyCollected'] = (float)qv(
            "SELECT COALESCE(SUM(amount),0) AS s FROM fee_collections WHERE DATE_FORMAT(collected_at, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m')", [], 0);
    } catch (Throwable $e) {}
    try {
        $stats['yearlyCollected'] = (float)qv(
            "SELECT COALESCE(SUM(amount),0) AS s FROM fee_collections WHERE YEAR(collected_at) = YEAR(NOW())", [], 0);
    } catch (Throwable $e) {}
    try {
        $stats['yearlyExpenses'] = (float)qv(
            "SELECT COALESCE(SUM(amount),0) AS s FROM expenses WHERE YEAR(expense_date) = YEAR(NOW())", [], 0);
    } catch (Throwable $e) {}
    $stats['netBalance'] = round((float)$stats['yearlyCollected'] - (float)$stats['yearlyExpenses'], 2);
    try { $stats['pendingDues'] = (float)qv('SELECT COALESCE(SUM(pending_amount),0) AS s FROM pending_dues_view', [], 0); } catch (Throwable $e) {}
    try { $stats['pendingInvoices'] = (int)qv("SELECT COUNT(*) AS c FROM fee_invoices WHERE status = 'open'", [], 0); } catch (Throwable $e) {}

    json_out(['stats' => $stats, 'notices' => notices()]);
}

/* ------------------------------- /settings -------------------------------- */
if ($resource === 'settings') {
    json_out(['school_name' => schoolName(), 'label_overrides' => (object)[]]);
}

/* -------------------------------- /notices -------------------------------- */
if ($resource === 'notices') {
    requireAuth();
    json_out(['notices' => notices()]);
}

/* -------------------------------- /classes -------------------------------- */
if ($resource === 'classes') {
    requireAuth();
    $rows = q(
        'SELECT cs.id, c.name AS class_name, s.name AS section
         FROM class_sections cs
         JOIN classes c ON c.id = cs.class_id
         JOIN sections s ON s.id = cs.section_id
         ORDER BY c.name, s.name'
    );
    $out = [];
    foreach ($rows as $r) {
        $count = 0;
        try {
            $count = (int)qv(
                'SELECT COUNT(*) AS c FROM student_class_assignments sca
                 WHERE sca.class_section_id = ?
                   AND sca.id = (SELECT MAX(sca2.id) FROM student_class_assignments sca2 WHERE sca2.student_id = sca.student_id)',
                [(int)$r['id']],
                0
            );
        } catch (Throwable $e) {
        }
        $out[] = [
            'id' => (int)$r['id'],
            'class_name' => (string)$r['class_name'],
            'section' => (string)$r['section'],
            'studentCount' => $count,
        ];
    }
    json_out(['classes' => $out]);
}

/* ---------------------------- /admin/attendance ---------------------------- */
// Lets an admin/accountant view and mark attendance for ANY class section,
// unlike the teacher's /teacher/class/:id/attendance which is restricted to
// classes that teacher actually teaches.
if ($resource === 'admin' && ($segments[0] ?? null) === 'attendance') {
    requirePermission('students.view');

    $classSectionId = (int)($_GET['class_section_id'] ?? 0);
    $date = trim((string)($_GET['date'] ?? date('Y-m-d')));

    if ($method === 'GET') {
        if ($classSectionId <= 0) {
            json_out(['date' => $date, 'rows' => []]);
        }
        $students = q(
            'SELECT s.* FROM students s
             JOIN student_class_assignments sca
               ON sca.id = (SELECT sca2.id FROM student_class_assignments sca2
                            WHERE sca2.student_id = s.id
                            ORDER BY sca2.assigned_at DESC, sca2.id DESC LIMIT 1)
             WHERE sca.class_section_id = ? AND IFNULL(s.status, 1) = 1
             ORDER BY s.first_name, s.last_name',
            [$classSectionId]
        );
        $rows = [];
        foreach ($students as $s) {
            $rec = q1(
                'SELECT status FROM attendance_records WHERE student_id = ? AND attendance_date = ? LIMIT 1',
                [(int)$s['id'], $date]
            );
            $rows[] = [
                'student_id' => (int)$s['id'],
                'name' => trim(($s['first_name'] ?? '') . ' ' . ($s['last_name'] ?? '')),
                'admission_no' => (string)($s['admission_no'] ?? ''),
                'status' => normalizeAttendanceStatus($rec['status'] ?? 'Present'),
            ];
        }
        json_out(['date' => $date, 'class_section_id' => $classSectionId, 'rows' => $rows]);
    }

    if ($method === 'POST') {
        requirePermission('students.manage');
        $b = body();
        $classSectionId = (int)($b['class_section_id'] ?? 0);
        $date = trim((string)($b['date'] ?? ''));
        $rows = $b['rows'] ?? [];
        if ($classSectionId <= 0 || $date === '' || !is_array($rows)) {
            fail('class_section_id, date and rows are required', 422);
        }
        foreach ($rows as $r) {
            $sid = (int)($r['student_id'] ?? 0);
            $status = normalizeAttendanceStatus((string)($r['status'] ?? 'Present'));
            if ($sid <= 0) continue;
            $existing = q1(
                'SELECT id FROM attendance_records WHERE student_id = ? AND attendance_date = ? LIMIT 1',
                [$sid, $date]
            );
            if ($existing) {
                qx('UPDATE attendance_records SET status = ? WHERE id = ?', [$status, (int)$existing['id']]);
            } else {
                qx(
                    'INSERT INTO attendance_records (student_id, class_section_id, attendance_date, status)
                     VALUES (?, ?, ?, ?)',
                    [$sid, $classSectionId, $date, $status]
                );
            }
        }
        logActivity('attendance.mark', "Marked attendance for class $classSectionId on $date");
        json_out(['ok' => true]);
    }
}

/* --------------------------------- /exams --------------------------------- */
if ($resource === 'exams') {
    requireAuth();
    try {
        $rows = q('SELECT id, exam_name FROM exams ORDER BY id');
    } catch (Throwable $e) {
        $rows = [];
    }
    json_out(['exams' => array_map(static function ($e) {
        return ['id' => (int)$e['id'], 'name' => (string)$e['exam_name']];
    }, $rows)]);
}

/* -------------------------------- /students ------------------------------- */
if ($resource === 'students') {
    $u = requireRole(['admin', 'accountant', 'teacher', 'student', 'parent']);

    if ($id === null) {
        if ($method === 'GET') {
            requireRole(['admin', 'accountant', 'teacher']);
            $sql = studentQuery() . ' WHERE 1=1';
            $params = [];
            if (!empty($_GET['class_section_id'])) {
                $sql .= ' AND cs.id = ?';
                $params[] = (int)$_GET['class_section_id'];
            }
            if (!empty($_GET['class_id'])) {
                $sql .= ' AND c.id = ?';
                $params[] = (int)$_GET['class_id'];
            }
            if (!empty($_GET['search'])) {
                $sql .= ' AND (s.first_name LIKE ? OR s.last_name LIKE ? OR s.admission_no LIKE ?)';
                $like = '%' . $_GET['search'] . '%';
                $params[] = $like;
                $params[] = $like;
                $params[] = $like;
            }
            $sql .= ' ORDER BY s.first_name, s.last_name LIMIT 500';
            $rows = q($sql, $params);
            json_out(['students' => array_map('studentPayload', $rows)]);
        }

        if ($method === 'POST') {
            requireRole(['admin', 'accountant']);
            $b = body();
            $firstName = trim((string)($b['first_name'] ?? ''));
            $lastName = trim((string)($b['last_name'] ?? ''));
            $classSectionId = (int)($b['class_section_id'] ?? 0);
            if ($firstName === '' || $lastName === '' || $classSectionId <= 0) {
                fail('first_name, last_name and class_section_id are required', 422);
            }
            $admissionNo = trim((string)($b['admission_no'] ?? ''));
            if ($admissionNo === '') {
                $admissionNo = 'STU-' . strtoupper(bin2hex(random_bytes(3)));
            }
            $gender = in_array($b['gender'] ?? '', ['M', 'F', 'Other'], true) ? $b['gender'] : 'M';

            $studentId = qInsert(
                'INSERT INTO students (admission_no, first_name, last_name, father_name, cnic_no, board_registration_no, roll_number, gender, dob, phone, address, status, created_at)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())',
                [
                    $admissionNo, $firstName, $lastName, (string)($b['father_name'] ?? ''),
                    (string)($b['cnic_no'] ?? ''), (string)($b['board_registration_no'] ?? ''),
                    ($b['roll_number'] ?? '') !== '' ? (int)$b['roll_number'] : null,
                    $gender, $b['dob'] ?? null, (string)($b['phone'] ?? ''), (string)($b['address'] ?? ''),
                ]
            );
            qx(
                'INSERT INTO student_class_assignments (student_id, class_section_id, assigned_at) VALUES (?, ?, NOW())',
                [$studentId, $classSectionId]
            );

            $guardianName = trim((string)($b['guardian_name'] ?? ''));
            if ($guardianName !== '') {
                $guardianId = qInsert(
                    'INSERT INTO guardians (full_name, relation, phone, created_at) VALUES (?, ?, ?, NOW())',
                    [$guardianName, (string)($b['guardian_relation'] ?? ''), (string)($b['guardian_phone'] ?? '')]
                );
                qx(
                    'INSERT INTO student_guardians (student_id, guardian_id, is_primary, created_at) VALUES (?, ?, 1, NOW())',
                    [$studentId, $guardianId]
                );
            }

            $s = q1('SELECT * FROM students WHERE id = ?', [$studentId]);
            json_out(['student' => studentPayload($s)], 201);
        }

        fail('Method not allowed', 405);
    }

    // /students/:id and sub-resources
    $studentId = (int)$id;
    $sub = $segments[0] ?? null;
    $studentRow = q1('SELECT * FROM students WHERE id = ?', [$studentId]);
    if ($studentRow === null) {
        fail('Student not found', 404);
    }

    // Permission: students/parents can only access their own linked student.
    $isAdminish = in_array(normalizeRole((string)$u['role_name']), ['admin', 'accountant', 'teacher'], true);
    if (!$isAdminish) {
        $allowed = false;
        if (normalizeRole((string)$u['role_name']) === 'student') {
            $allowed = linkedId('students', (int)$u['id']) === $studentId;
        } else {
            $guardianId = linkedId('guardians', (int)$u['id']);
            $row = $guardianId > 0 ? q1('SELECT 1 FROM student_guardians WHERE guardian_id = ? AND student_id = ? LIMIT 1', [$guardianId, $studentId]) : null;
            $allowed = $row !== null;
        }
        if (!$allowed) {
            fail('Forbidden', 403);
        }
    }

    if ($sub === null && $method === 'GET') {
        json_out(['student' => studentPayload($studentRow)]);
    } elseif ($sub === 'attendance') {
        $rows = q('SELECT id, attendance_date, status FROM attendance_records WHERE student_id = ? ORDER BY attendance_date DESC LIMIT 60', [$studentId]);
        json_out([
            'summary' => attendanceSummary($studentId),
            'records' => array_map(static function ($r) {
                return [
                    'id' => (int)$r['id'],
                    'student_id' => (int)($r['student_id'] ?? 0),
                    'date' => (string)$r['attendance_date'],
                    'status' => normalizeAttendanceStatus($r['status']),
                ];
            }, $rows),
        ]);
    } elseif ($sub === 'marks') {
        json_out(['exams' => studentMarks($studentId)]);
    } elseif ($sub === 'fees') {
        json_out(studentFees($studentId));
    } elseif ($sub === 'timetable') {
        $cs = classSectionOf($studentId);
        json_out(studentTimetable((int)$cs['class_section_id']));
    } else {
        fail('Not found', 404);
    }
}

/* -------------------------------- /my/ward -------------------------------- */
if ($resource === 'my' && $id === 'ward') {
    $u = requireRole(['parent']);
    $guardianId = linkedId('guardians', (int)$u['id']);
    if ($guardianId <= 0) {
        fail('No ward linked to this account', 404);
    }
    $row = q1('SELECT student_id FROM student_guardians WHERE guardian_id = ? ORDER BY id LIMIT 1', [$guardianId]);
    if (!$row) {
        fail('No ward linked to this account', 404);
    }
    $sid = (int)$row['student_id'];
    $s = q1('SELECT * FROM students WHERE id = ?', [$sid]);
    json_out([
        'ward' => studentPayload($s),
        'attendance' => attendanceSummary($sid),
        'exams' => studentMarks($sid),
        'fees' => studentFees($sid)['summary'],
    ]);
}

/* ------------------------------- /admin/* -------------------------------- */
if ($resource === 'admin') {
    $section = $id ?? '';
    requireRole(['admin', 'accountant']);

    if ($section === 'staff') {
        try {
            $rows = q('SELECT * FROM staff_profiles ORDER BY full_name');
        } catch (Throwable $e) {
            $rows = [];
        }
        json_out(['staff' => array_map(static function ($s) {
            return [
                'id' => (int)$s['id'],
                'name' => (string)($s['full_name'] ?? ''),
                'designation' => (string)($s['title'] ?? ''),
                'phone' => (string)($s['phone'] ?? ''),
                'email' => null,
                'subject' => '',
                'join_date' => $s['created_at'] ?? null,
                'salary' => (float)($s['basic_salary'] ?? 0),
            ];
        }, $rows)]);
    }

    if ($section === 'collections') {
        $totalCollected = $monthCollected = 0;
        try {
            $totalCollected = (float)qv('SELECT COALESCE(SUM(amount),0) AS s FROM fee_collections', [], 0);
        } catch (Throwable $e) {}
        try {
            $monthCollected = (float)qv(
                "SELECT COALESCE(SUM(amount),0) AS s FROM fee_collections WHERE DATE_FORMAT(collected_at, '%Y-%m') = DATE_FORMAT(NOW(), '%Y-%m')", [], 0);
        } catch (Throwable $e) {}

        $breakdown = [];
        try {
            $rows = q(
                'SELECT COALESCE(fc.name, \'Other\') AS cat, SUM(fcol.amount) AS total
                 FROM fee_collections fcol
                 JOIN fee_invoices fi ON fi.id = fcol.fee_invoice_id
                 LEFT JOIN fee_invoice_lines fil ON fil.fee_invoice_id = fi.id
                 LEFT JOIN fee_categories fc ON fc.id = fil.fee_category_id
                 GROUP BY cat'
            );
            foreach ($rows as $r) {
                $breakdown[(string)$r['cat']] = (float)$r['total'];
            }
        } catch (Throwable $e) {}

        $pending = [];
        try {
            $rows = q(
                'SELECT fi.*, s.first_name, s.last_name, s.admission_no,
                        COALESCE((SELECT SUM(fc.amount) FROM fee_collections fc WHERE fc.fee_invoice_id = fi.id),0) AS collected
                 FROM fee_invoices fi
                 JOIN students s ON s.id = fi.student_id
                 WHERE fi.status = \'open\'
                 ORDER BY fi.due_date
                 LIMIT 50'
            );
            foreach ($rows as $fi) {
                $balance = (float)$fi['total_due'] - (float)$fi['collected'];
                if ($balance <= 0) continue;
                $pending[] = [
                    'id' => (int)$fi['id'],
                    'invoice_no' => (string)$fi['invoice_no'],
                    'student_name' => trim(($fi['first_name'] ?? '') . ' ' . ($fi['last_name'] ?? '')),
                    'description' => (string)($fi['invoice_no'] ?? ''),
                    'month' => null,
                    'amount' => (float)$fi['total_amount'],
                    'fine' => (float)($fi['fine_applied'] ?? 0),
                    'discount' => (float)($fi['total_discount'] ?? 0),
                    'total' => (float)$fi['total_due'],
                    'paid_amount' => (float)$fi['collected'],
                    'balance' => round($balance, 2),
                    'status' => $balance > 0 ? 'Unpaid' : 'Paid',
                    'due_date' => $fi['due_date'] ?? null,
                    'created_at' => $fi['created_at'] ?? null,
                    'payments' => [],
                ];
            }
        } catch (Throwable $e) {}

        json_out([
            'totalCollected' => $totalCollected,
            'monthCollected' => $monthCollected,
            'categoryBreakdown' => $breakdown,
            'pending' => $pending,
        ]);
    }

    fail('Unknown admin endpoint', 404);
}

/* -------------------------------- /teacher/* ------------------------------ */
function teacherClasses(int $staffProfileId): array
{
    if ($staffProfileId <= 0) {
        return [];
    }
    $out = [];
    try {
        $classRows = [];
        if (tableExists('timetable_entries')) {
            // Access is granted strictly by "this teacher has a timetable
            // entry for this class_section" (te.teacher_id = ?). We
            // deliberately do NOT also grant every class_section that happens
            // to teach one of this teacher's assigned subjects
            // (staff_subject_assignments): subjects are modeled per class,
            // not per section, so once a class is split into sections (e.g.
            // 9-A / 9-B) that subject-based match would grant this teacher
            // every section teaching that subject school-wide, not just their
            // own. Verified against current data: every teacher's real
            // sections already show up via teacher_id, so this doesn't take
            // away anyone's legitimate access today.
            $classRows = q(
                'SELECT DISTINCT te.class_section_id FROM timetable_entries te WHERE te.teacher_id = ?',
                [$staffProfileId]
            );
        }

        $seen = [];
        foreach ($classRows as $r) {
            $csId = (int)$r['class_section_id'];
            if (isset($seen[$csId])) continue;
            $seen[$csId] = true;
            $info = q1(
                'SELECT cs.id, c.name AS class_name, s.name AS section, su.subject_name
                 FROM class_sections cs
                 JOIN classes c ON c.id = cs.class_id
                 JOIN sections s ON s.id = cs.section_id
                 LEFT JOIN (
                     SELECT te.class_section_id, MAX(te.subject_id) AS subject_id
                     FROM timetable_entries te WHERE te.class_section_id = ?
                 ) te ON te.class_section_id = cs.id
                 LEFT JOIN subjects su ON su.id = te.subject_id
                 WHERE cs.id = ?',
                [$csId, $csId]
            );
            if (!$info) continue;
            $count = 0;
            try {
                $count = (int)qv(
                    'SELECT COUNT(*) AS c FROM student_class_assignments sca
                     WHERE sca.class_section_id = ?
                       AND sca.id = (SELECT MAX(sca2.id) FROM student_class_assignments sca2 WHERE sca2.student_id = sca.student_id)',
                    [$csId], 0);
            } catch (Throwable $e) {}
            $out[] = [
                'id' => $csId,
                'class_name' => (string)$info['class_name'],
                'section' => (string)$info['section'],
                'subject' => (string)($info['subject_name'] ?? ''),
                'studentCount' => $count,
            ];
        }
    } catch (Throwable $e) {
    }
    return $out;
}

if ($resource === 'teacher') {
    $u = requireRole(['teacher']);
    $staffId = linkedId('staff_profiles', (int)$u['id']);
    $section = $id ?? '';

    if ($section === 'classes') {
        json_out(['myClasses' => teacherClasses($staffId)]);
    }

    // /teacher/class/:classSectionId/...
    if ($section === 'class') {
        $classSectionId = (int)($segments[0] ?? 0);
        $sub = $segments[1] ?? null;
        if ($classSectionId <= 0) {
            fail('class_section_id required', 422);
        }
        $allowedIds = array_column(teacherClasses($staffId), 'id');
        if (!in_array($classSectionId, $allowedIds, true)) {
            fail('Forbidden: not your class', 403);
        }

        $students = q(
            'SELECT s.* FROM students s
             JOIN student_class_assignments sca
               ON sca.id = (SELECT sca2.id FROM student_class_assignments sca2
                            WHERE sca2.student_id = s.id
                            ORDER BY sca2.assigned_at DESC, sca2.id DESC LIMIT 1)
             WHERE sca.class_section_id = ? AND IFNULL(s.status, 1) = 1
             ORDER BY s.admission_no',
            [$classSectionId]
        );

        if ($sub === 'students' && $method === 'GET') {
            json_out(['students' => array_map('studentPayload', $students)]);
        }

        if ($sub === 'attendance' && $method === 'GET') {
            $date = trim((string)($_GET['date'] ?? date('Y-m-d')));
            $rows = [];
            foreach ($students as $s) {
                $rec = q1(
                    'SELECT status FROM attendance_records WHERE student_id = ? AND attendance_date = ? LIMIT 1',
                    [(int)$s['id'], $date]
                );
                $rows[] = [
                    'student_id' => (int)$s['id'],
                    'name' => trim(($s['first_name'] ?? '') . ' ' . ($s['last_name'] ?? '')),
                    'roll_number' => null,
                    'status' => normalizeAttendanceStatus($rec['status'] ?? 'Present'),
                ];
            }
            json_out(['date' => $date, 'rows' => $rows]);
        }

        if ($sub === 'marks' && $method === 'GET') {
            $examId = (int)($_GET['exam_id'] ?? 0);
            $subjects = [];
            try {
                $subjectRows = q(
                    'SELECT DISTINCT su.id, su.subject_name
                     FROM timetable_entries te
                     JOIN subjects su ON su.id = te.subject_id
                     WHERE te.class_section_id = ?
                     ORDER BY su.subject_name',
                    [$classSectionId]
                );
                $subjects = array_map(static fn($r) => (string)$r['subject_name'], $subjectRows);
            } catch (Throwable $e) {
            }
            if (empty($subjects)) {
                try {
                    $subjects = array_map(static fn($r) => (string)$r['subject_name'], q('SELECT subject_name FROM subjects ORDER BY subject_name'));
                } catch (Throwable $e) {
                }
            }
            $rows = [];
            foreach ($students as $s) {
                $marks = [];
                foreach ($subjects as $subName) {
                    $existing = null;
                    if ($examId > 0) {
                        $existing = q1(
                            'SELECT m.score, m.total_marks FROM marks m
                             JOIN subjects su ON su.id = m.subject_id
                             WHERE m.student_id = ? AND m.exam_id = ? AND su.subject_name = ?
                             LIMIT 1',
                            [(int)$s['id'], $examId, $subName]
                        );
                    }
                    $marks[] = [
                        'subject' => $subName,
                        'marks_obtained' => $existing ? (float)$existing['score'] : null,
                    ];
                }
                $rows[] = [
                    'student_id' => (int)$s['id'],
                    'name' => trim(($s['first_name'] ?? '') . ' ' . ($s['last_name'] ?? '')),
                    'roll_number' => null,
                    'marks' => $marks,
                ];
            }
            json_out(['exam_id' => $examId, 'subjects' => $subjects, 'rows' => $rows]);
        }
    }

    if ($section === 'attendance' && $method === 'POST') {
        $b = body();
        $date = trim((string)($b['date'] ?? ''));
        $rows = $b['rows'] ?? [];
        if ($date === '' || !is_array($rows)) {
            fail('date and rows are required', 422);
        }
        $allowedIds = array_column(teacherClasses($staffId), 'id');
        // Resolve every student's class up front and reject the whole request if any
        // of them fall outside this teacher's own classes, rather than silently
        // applying the legitimate rows and dropping the rest without the teacher
        // noticing.
        $csByStudent = [];
        foreach ($rows as $r) {
            $sid = (int)($r['student_id'] ?? 0);
            if ($sid <= 0) continue;
            $cs = classSectionOf($sid);
            $csId = (int)($cs['class_section_id'] ?? 0);
            if ($csId <= 0 || !in_array($csId, $allowedIds, true)) {
                fail('Forbidden: not your class', 403);
            }
            $csByStudent[$sid] = $csId;
        }
        foreach ($rows as $r) {
            $sid = (int)($r['student_id'] ?? 0);
            $status = normalizeAttendanceStatus((string)($r['status'] ?? 'Present'));
            if ($sid <= 0) continue;
            $existing = q1(
                'SELECT id FROM attendance_records WHERE student_id = ? AND attendance_date = ? LIMIT 1',
                [$sid, $date]
            );
            if ($existing) {
                qx('UPDATE attendance_records SET status = ? WHERE id = ?', [$status, (int)$existing['id']]);
            } else {
                qx(
                    'INSERT INTO attendance_records (student_id, class_section_id, attendance_date, status)
                     VALUES (?, ?, ?, ?)',
                    [$sid, $csByStudent[$sid], $date, $status]
                );
            }
        }
        json_out(['ok' => true]);
    }

    if ($section === 'marks' && $method === 'POST') {
        $b = body();
        $examId = (int)($b['exam_id'] ?? 0);
        $subjectName = trim((string)($b['subject'] ?? ''));
        $rows = $b['rows'] ?? [];
        if ($examId <= 0 || $subjectName === '' || !is_array($rows)) {
            fail('exam_id, subject and rows are required', 422);
        }
        $allowedIds = array_column(teacherClasses($staffId), 'id');
        $examRow = q1('SELECT class_section_id FROM exams WHERE id = ?', [$examId]);
        $examClassSectionId = $examRow ? (int)($examRow['class_section_id'] ?? 0) : 0;
        if ($examClassSectionId <= 0 || !in_array($examClassSectionId, $allowedIds, true)) {
            fail('Forbidden: not your class', 403);
        }
        // Resolve the subject scoped to this exam's own class, not a bare global
        // name lookup — subject names are not guaranteed unique across classes.
        // Same scoping used by SubjectModel::optionsForClassSection().
        $subject = q1(
            'SELECT su.id FROM subjects su
             JOIN class_sections cs ON cs.id = ?
             WHERE su.subject_name = ? AND su.class_id = cs.class_id
             LIMIT 1',
            [$examClassSectionId, $subjectName]
        );
        if (!$subject) {
            fail('Unknown subject: ' . $subjectName, 422);
        }
        $subjectId = (int)$subject['id'];
        foreach ($rows as $r) {
            $sid = (int)($r['student_id'] ?? 0);
            $score = $r['marks_obtained'] ?? null;
            if ($sid <= 0 || $score === null || $score === '') continue;
            $cs = classSectionOf($sid);
            if ((int)($cs['class_section_id'] ?? 0) !== $examClassSectionId) {
                fail('Forbidden: not your class', 403);
            }
            $score = max(0.0, min(100.0, (float)$score));
            $existing = q1(
                'SELECT id FROM marks WHERE student_id = ? AND exam_id = ? AND subject_id = ? LIMIT 1',
                [$sid, $examId, $subjectId]
            );
            if ($existing) {
                qx('UPDATE marks SET score = ? WHERE id = ?', [$score, (int)$existing['id']]);
            } else {
                $gradeId = null;
                try {
                    $grade = q1('SELECT id FROM grades WHERE min_score <= ? ORDER BY min_score DESC LIMIT 1', [$score]);
                    $gradeId = $grade ? (int)$grade['id'] : null;
                } catch (Throwable $e) {
                }
                qx(
                    'INSERT INTO marks (student_id, exam_id, subject_id, score, total_marks, grade_id)
                     VALUES (?, ?, ?, ?, 100, ?)',
                    [$sid, $examId, $subjectId, $score, $gradeId]
                );
            }
        }
        json_out(['ok' => true]);
    }

    /* -------------------------------- /expenses -------------------------------- */
function expenseCategories(): array
{
    $rows = q('SELECT id, name FROM expense_categories ORDER BY name');
    return array_map(static fn($r) => ['id' => (int)$r['id'], 'name' => (string)$r['name']], $rows);
}

function expensePayload(array $r): array
{
    return [
        'id' => (int)$r['id'],
        'category_id' => (int)$r['expense_category_id'],
        'category_name' => (string)($r['category_name'] ?? ''),
        'description' => (string)($r['description'] ?? ''),
        'amount' => (float)$r['amount'],
        'expense_date' => (string)$r['expense_date'],
        'created_at' => (string)($r['created_at'] ?? ''),
    ];
}

if ($resource === 'expenses') {
    // /expenses/categories[/:id[/delete]]
    if ($id === 'categories') {
        $catId = isset($segments[1]) ? (int)$segments[1] : null;
        $catAction = $segments[2] ?? null;

        if ($catId === null && $method === 'GET') {
            requirePermission('expenses.view');
            json_out(['categories' => expenseCategories()]);
        }

        if ($catId === null && $method === 'POST') {
            requirePermission('expenses.manage');
            $name = trim((string)(body()['name'] ?? ''));
            if ($name === '') {
                fail('name is required', 422);
            }
            qx('INSERT INTO expense_categories (name) VALUES (?) ON DUPLICATE KEY UPDATE name = name', [$name]);
            $row = q1('SELECT id, name FROM expense_categories WHERE name = ?', [$name]);
            logActivity('expenses.category_create', 'Added expense category "' . $name . '"');
            json_out(['category' => ['id' => (int)$row['id'], 'name' => (string)$row['name']]], 201);
        }

        if ($catId !== null && $catAction === 'delete' && $method === 'POST') {
            requirePermission('expenses.manage');
            try {
                qx('DELETE FROM expense_categories WHERE id = ?', [$catId]);
            } catch (Throwable $e) {
                // FK constraint — category still referenced by an expense.
                fail('Cannot delete — this category is used by one or more expenses.', 409);
            }
            logActivity('expenses.category_delete', 'Deleted expense category #' . $catId);
            json_out(['ok' => true]);
        }

        if ($catId !== null && $catAction === null && $method === 'POST') {
            requirePermission('expenses.manage');
            $name = trim((string)(body()['name'] ?? ''));
            if ($name === '') {
                fail('name is required', 422);
            }
            qx('UPDATE expense_categories SET name = ? WHERE id = ?', [$name, $catId]);
            logActivity('expenses.category_rename', 'Renamed expense category #' . $catId . ' to "' . $name . '"');
            json_out(['ok' => true]);
        }

        fail('Not found', 404);
    }

    // /expenses/:id/delete
    if ($id !== null && ($segments[1] ?? null) === 'delete' && $method === 'POST') {
        requirePermission('expenses.manage');
        $expId = (int)$id;
        qx('DELETE FROM expenses WHERE id = ?', [$expId]);
        logActivity('expenses.delete', 'Deleted expense #' . $expId);
        json_out(['ok' => true]);
    }

    // /expenses/:id  (update)
    if ($id !== null && $method === 'POST') {
        requirePermission('expenses.manage');
        $expId = (int)$id;
        $b = body();
        $catId = (int)($b['expense_category_id'] ?? 0);
        $description = trim((string)($b['description'] ?? ''));
        $amount = (float)($b['amount'] ?? 0);
        $expenseDate = trim((string)($b['expense_date'] ?? date('Y-m-d')));
        if ($catId <= 0 || $amount <= 0) {
            fail('Category and a valid amount are required', 422);
        }
        qx(
            'UPDATE expenses SET expense_category_id = ?, description = ?, amount = ?, expense_date = ? WHERE id = ?',
            [$catId, $description, $amount, $expenseDate, $expId]
        );
        logActivity('expenses.update', 'Updated expense #' . $expId . ' to Rs ' . number_format($amount, 2));
        $row = q1(
            'SELECT e.*, ec.name AS category_name FROM expenses e JOIN expense_categories ec ON ec.id = e.expense_category_id WHERE e.id = ?',
            [$expId]
        );
        json_out(['expense' => expensePayload($row)]);
    }

    // /expenses  (list / create)
    if ($id === null) {
        if ($method === 'GET') {
            requirePermission('expenses.view');
            $month = (int)($_GET['month'] ?? date('n'));
            $year = (int)($_GET['year'] ?? date('Y'));
            $categoryId = (int)($_GET['category_id'] ?? 0);
            $search = trim((string)($_GET['q'] ?? ''));

            $sql = 'SELECT e.*, ec.name AS category_name
                    FROM expenses e JOIN expense_categories ec ON ec.id = e.expense_category_id
                    WHERE MONTH(e.expense_date) = ? AND YEAR(e.expense_date) = ?';
            $params = [$month, $year];
            if ($categoryId > 0) {
                $sql .= ' AND e.expense_category_id = ?';
                $params[] = $categoryId;
            }
            if ($search !== '') {
                $sql .= ' AND e.description LIKE ?';
                $params[] = '%' . $search . '%';
            }
            $sql .= ' ORDER BY e.expense_date DESC, e.id DESC LIMIT 300';
            $rows = q($sql, $params);

            $total = (float)qv(
                'SELECT COALESCE(SUM(amount),0) AS s FROM expenses WHERE MONTH(expense_date) = ? AND YEAR(expense_date) = ?',
                [$month, $year], 0
            );

            json_out([
                'expenses' => array_map('expensePayload', $rows),
                'categories' => expenseCategories(),
                'total' => $total,
                'month' => $month,
                'year' => $year,
            ]);
        }

        if ($method === 'POST') {
            requirePermission('expenses.manage');
            $b = body();
            $catId = (int)($b['expense_category_id'] ?? 0);
            $description = trim((string)($b['description'] ?? ''));
            $amount = (float)($b['amount'] ?? 0);
            $expenseDate = trim((string)($b['expense_date'] ?? date('Y-m-d')));
            if ($catId <= 0 || $amount <= 0) {
                fail('Category and a valid amount are required', 422);
            }
            $u = requireAuth();
            $newId = qInsert(
                'INSERT INTO expenses (expense_category_id, description, amount, expense_date, added_by_user_id, created_at)
                 VALUES (?, ?, ?, ?, ?, NOW())',
                [$catId, $description, $amount, $expenseDate, $u['id']]
            );
            logActivity('expenses.create', 'Recorded expense of Rs ' . number_format($amount, 2) . ($description !== '' ? (' — ' . $description) : ''));
            $row = q1(
                'SELECT e.*, ec.name AS category_name FROM expenses e JOIN expense_categories ec ON ec.id = e.expense_category_id WHERE e.id = ?',
                [$newId]
            );
            json_out(['expense' => expensePayload($row)], 201);
        }

        fail('Method not allowed', 405);
    }

    fail('Not found', 404);
}

fail('Unknown teacher endpoint', 404);
}

fail('Not found', 404);