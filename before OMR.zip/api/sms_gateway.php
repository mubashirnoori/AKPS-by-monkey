<?php
declare(strict_types=1);

/**
 * SMS Gateway relay endpoint — multi-device
 * ============================================================================
 * What talks to this: any phone/app running the relay poller (Admin's own,
 * or a personal one per staff member — see Settings > SMS Gateway Devices).
 * NOT a user login — each device authenticates with its own token instead of
 * a school user account, because the phone isn't a person logging in.
 *
 * GET  /api/sms_gateway.php?action=pending
 *      -> up to 20 queued messages *addressed to this device*, atomically
 *         marked 'sending' so a second poll (or a slow/duplicate request)
 *         won't also pick them up.
 *      Response: {"messages":[{"id":1,"to":"+923145525749","message":"...","purpose":"otp"}, ...]}
 *
 *      Routing: a message queued with a specific sender_staff_id only goes
 *      to that staff member's own device. Everything else (system messages
 *      like OTP/fee reminders, or a staff member's announcement when they
 *      don't have a personal device configured) goes to whichever device is
 *      marked "default" in Settings > SMS Gateway Devices — so nothing gets
 *      stuck unsent just because one staff member's phone is off.
 *
 *      Pacing: each device is only handed one new message every
 *      `sms_send_interval_seconds` (Settings > Notifications, default 60s,
 *      i.e. one message/minute) — polling faster than that just gets
 *      {"id":0} back with the queued message left untouched for next time.
 *
 *      Rate caps: on top of the interval, each device is also hard-capped
 *      at `sms_limit_per_15min` / `sms_limit_per_hour` / `sms_limit_per_day`
 *      messages in a rolling window (Settings > Notifications, defaulted to
 *      Zong's own stated block thresholds: 150/250/750). Whichever window
 *      is closest to full determines when the device becomes eligible
 *      again — this is what keeps a long sustained burst (e.g. a big
 *      announcement spread out at one/minute) from quietly running past
 *      the daily cap even though it respects the per-message interval.
 *      Counted via sms_gateway_dispatch_log, not sms_outbox (whose
 *      status/updated_at get overwritten by later acks/retries).
 *      See db/migrate_sms_send_throttle.sql and db/migrate_sms_rate_limits.sql.
 *
 * POST /api/sms_gateway.php   Content-Type: application/json
 *      {"action":"ack","id":1,"status":"sent"}
 *      {"action":"ack","id":1,"status":"failed","error":"no signal"}
 *      -> failed messages go back to 'pending' for retry, up to 3 attempts,
 *         then are left as 'failed' for good.
 *
 * Auth: header  X-Gateway-Token: <token>   (or ?token=<token> if your poller
 * can't set headers). Matched against sms_gateway_devices.token — each
 * device has its own, generated/managed under Settings > SMS Gateway Devices.
 * ============================================================================
 */

error_reporting(E_ALL);
ini_set('display_errors', '0');

$config = require __DIR__ . '/config.php';
date_default_timezone_set((string)($config['app']['timezone'] ?? 'Asia/Karachi'));

header('Content-Type: application/json; charset=utf-8');

function json_out($data, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function fail(string $message, int $status = 400): void
{
    json_out(['error' => $message], $status);
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        global $config;
        $d = $config['db'];
        if ($d['user'] === '' || $d['name'] === '') {
            fail('API database is not configured. See api/config.php', 500);
        }
        $dsn = 'mysql:host=' . $d['host'] . ';dbname=' . $d['name'] . ';charset=' . $d['charset'];
        $pdo = new PDO($dsn, $d['user'], $d['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);

        // Align MySQL's own clock (NOW(), CURRENT_TIMESTAMP — used for last_seen_at,
        // created_at/updated_at, sent_at below) with the app's configured timezone,
        // same as app/core/Database.php does for the main app's connection. Without
        // this, this standalone script's timestamps reflect the database server's
        // own system timezone (commonly UTC) instead of Asia/Karachi — which is
        // exactly why "Last polled" on Settings > SMS Gateway Devices could show a
        // time hours in the past even right after a device just polled successfully.
        try {
            $tz = (string)($config['app']['timezone'] ?? 'Asia/Karachi');
            $offset = (new DateTime('now', new DateTimeZone($tz)))->format('P');
            $pdo->exec("SET time_zone = '" . $offset . "'");
        } catch (Throwable $e) {
            // Non-fatal — worst case timestamps fall back to the DB server's own timezone.
        }
    }
    return $pdo;
}

function setting(string $key, string $default = ''): string
{
    $stmt = db()->prepare('SELECT `value` FROM settings WHERE `key` = ? LIMIT 1');
    $stmt->execute([$key]);
    $row = $stmt->fetch();
    return $row ? (string)$row['value'] : $default;
}

/**
 * Checks one rolling window (e.g. "last 15 minutes") against its cap for a
 * device, using sms_gateway_dispatch_log rather than sms_outbox — a message
 * row's own status/updated_at get overwritten by later acks/retries, so
 * sms_outbox can't reliably answer "how many did this device actually get
 * handed in the last N minutes". A cap of 0 means "no limit" (disabled).
 *
 * Returns [exceeded: bool, waitSeconds: int]. When exceeded, waitSeconds is
 * how long until the oldest dispatch inside the window ages back out of it
 * — i.e. the earliest moment this window would allow one more message.
 */
function checkRateWindow(PDO $pdo, int $deviceId, int $windowSeconds, int $cap): array
{
    if ($cap <= 0) {
        return [false, 0];
    }

    $countStmt = $pdo->prepare(
        'SELECT COUNT(*) FROM sms_gateway_dispatch_log
         WHERE device_id = ? AND dispatched_at >= (NOW() - INTERVAL ? SECOND)'
    );
    $countStmt->execute([$deviceId, $windowSeconds]);
    $count = (int)$countStmt->fetchColumn();

    if ($count < $cap) {
        return [false, 0];
    }

    $oldestStmt = $pdo->prepare(
        'SELECT MIN(dispatched_at) FROM sms_gateway_dispatch_log
         WHERE device_id = ? AND dispatched_at >= (NOW() - INTERVAL ? SECOND)'
    );
    $oldestStmt->execute([$deviceId, $windowSeconds]);
    $oldest = $oldestStmt->fetchColumn();
    if (!$oldest) {
        // Shouldn't happen (count >= cap > 0 implies at least one row), but
        // fail safe rather than dividing by a null timestamp.
        return [true, $windowSeconds];
    }

    $elapsed = (new DateTime('now'))->getTimestamp() - (new DateTime((string)$oldest))->getTimestamp();
    $wait = $windowSeconds - $elapsed;
    return [true, max(1, $wait)];
}

/* --------------------------------- Auth ----------------------------------- */
$token = $_SERVER['HTTP_X_GATEWAY_TOKEN'] ?? ($_GET['token'] ?? '');
if ($token === '') {
    fail('Unauthorized', 401);
}

$deviceStmt = db()->prepare(
    'SELECT id, staff_profile_id, is_default, status FROM sms_gateway_devices WHERE token = ? LIMIT 1'
);
$deviceStmt->execute([(string)$token]);
$device = $deviceStmt->fetch();
if (!$device) {
    fail('Unauthorized', 401);
}
if ($device['status'] !== 'active') {
    fail('This device has been disabled in Settings > SMS Gateway Devices', 403);
}
if (setting('sms_enabled') !== '1') {
    fail('SMS gateway is disabled in Settings', 403);
}

$deviceId = (int)$device['id'];
$deviceStaffId = $device['staff_profile_id'] !== null ? (int)$device['staff_profile_id'] : null;
$deviceIsDefault = (int)$device['is_default'] === 1;

db()->prepare('UPDATE sms_gateway_devices SET last_seen_at = NOW() WHERE id = ?')->execute([$deviceId]);

$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
$raw = file_get_contents('php://input');
$body = [];
if ($raw !== false && $raw !== '') {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        $body = $decoded;
    }
}
$action = (string)($_GET['action'] ?? $body['action'] ?? '');

/* ------------------------------ GET /pending ------------------------------ */
if ($method === 'GET' && $action === 'pending') {
    $single = (($_GET['single'] ?? '') === '1');

    // Minimum gap (seconds) enforced between dispatches *per device*, so a
    // burst of queued messages (e.g. a class-wide announcement) trickles out
    // instead of firing back-to-back — which is what gets a personal SIM
    // flagged/blocked by the carrier's spam filter. Configurable under
    // Settings > Notifications; '0' explicitly turns pacing off, anything
    // else is floored at 2s so a mistyped "1" doesn't defeat the point.
    $intervalSeconds = (int) setting('sms_send_interval_seconds', '60');
    if ($intervalSeconds < 0) {
        $intervalSeconds = 0;
    } elseif ($intervalSeconds > 0 && $intervalSeconds < 2) {
        $intervalSeconds = 2;
    }

    // Hard rolling-window caps on top of the interval — defaulted to Zong's
    // own stated block thresholds. A cap of 0 disables that particular
    // window. These matter even with sensible pacing: one message/minute
    // sustained for a full day is 1,440 messages, which blows past a
    // 750/day cap despite never sending in a "burst".
    $cap15Min = max(0, (int) setting('sms_limit_per_15min', '150'));
    $capHour = max(0, (int) setting('sms_limit_per_hour', '250'));
    $capDay = max(0, (int) setting('sms_limit_per_day', '750'));

    // With pacing on, the server is the only thing that can actually
    // guarantee the gap — a batch client that grabbed 20 messages in one
    // poll would just loop through and send them all at once, defeating the
    // whole point. So while pacing is active, cap every poll (single or
    // batch) to one message; batches of up to 20 only come back if pacing
    // is explicitly disabled (interval = 0).
    $limit = ($single || $intervalSeconds > 0) ? 1 : 20;

    $pdo = db();
    $pdo->beginTransaction();
    try {
        // Reclaim rows any device claimed (status set to 'sending') more than 10
        // minutes ago and never acknowledged — e.g. the relay app was killed by
        // Android battery optimization, lost signal, or crashed mid-send. Without
        // this they'd sit stuck in 'sending' forever: not pending, not failed,
        // just silently never retried. Same 3-attempt cap as an explicit "failed"
        // ack, so a message that keeps getting claimed and dropped still gives up
        // eventually instead of looping forever.
        $pdo->prepare(
            "UPDATE sms_outbox
             SET status = CASE WHEN attempts >= 3 THEN 'failed' ELSE 'pending' END,
                 last_error = CASE WHEN attempts >= 3 THEN 'Claimed by a device but never acknowledged (gave up after 3 attempts)' ELSE last_error END
             WHERE status = 'sending' AND updated_at < (NOW() - INTERVAL 10 MINUTE)"
        )->execute();

        // Lock this device's own row for the duration of the transaction so two
        // overlapping polls from the same phone (e.g. a slow request still in
        // flight when the next poll fires) can't both decide the gap has
        // elapsed and both claim a message.
        $lockStmt = $pdo->prepare('SELECT last_dispatched_at FROM sms_gateway_devices WHERE id = ? FOR UPDATE');
        $lockStmt->execute([$deviceId]);
        $lastDispatchedAt = $lockStmt->fetchColumn();

        $throttled = false;
        $waitSeconds = 0;
        if ($intervalSeconds > 0 && $lastDispatchedAt) {
            $elapsed = (new DateTime('now'))->getTimestamp() - (new DateTime((string)$lastDispatchedAt))->getTimestamp();
            if ($elapsed < $intervalSeconds) {
                $throttled = true;
                $waitSeconds = $intervalSeconds - $elapsed;
            }
        }

        // Interval passed — now check the rolling-window caps. Check all
        // three (don't stop at the first exceeded one) and wait for the
        // longest of them, since the device isn't eligible again until
        // *every* window has room.
        if (!$throttled) {
            foreach ([[900, $cap15Min], [3600, $capHour], [86400, $capDay]] as [$windowSeconds, $cap]) {
                [$exceeded, $wait] = checkRateWindow($pdo, $deviceId, $windowSeconds, $cap);
                if ($exceeded) {
                    $throttled = true;
                    $waitSeconds = max($waitSeconds, $wait);
                }
            }
        }

        if ($throttled) {
            // Not this device's turn yet — hand back nothing without touching
            // sms_outbox at all, so the messages stay 'pending' for the next
            // poll (or another device, if one is eligible) to pick up.
            $stmt = null;
        } elseif ($deviceIsDefault) {
            // Default device: pick up anything not claimed by a *different*,
            // currently-active personal device — i.e. no sender at all, or a
            // sender whose own device is missing/disabled right now.
            $stmt = $pdo->prepare(
                "SELECT id, to_number, message, purpose FROM sms_outbox
                 WHERE status = 'pending'
                   AND (
                        sender_staff_id IS NULL
                        OR sender_staff_id NOT IN (
                            SELECT staff_profile_id FROM sms_gateway_devices
                            WHERE staff_profile_id IS NOT NULL AND status = 'active'
                        )
                   )
                 ORDER BY id ASC LIMIT $limit FOR UPDATE"
            );
            $stmt->execute();
        } elseif ($deviceStaffId !== null) {
            // Personal device: only messages sent under that same staff member.
            $stmt = $pdo->prepare(
                "SELECT id, to_number, message, purpose FROM sms_outbox
                 WHERE status = 'pending' AND sender_staff_id = ?
                 ORDER BY id ASC LIMIT $limit FOR UPDATE"
            );
            $stmt->execute([$deviceStaffId]);
        } else {
            // Non-default device with no staff assigned yet — intentionally idle.
            $stmt = null;
        }

        $rows = $stmt ? $stmt->fetchAll() : [];

        if ($rows) {
            $ids = array_map(static fn($r) => (int)$r['id'], $rows);
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $upd = $pdo->prepare("UPDATE sms_outbox SET status = 'sending', attempts = attempts + 1 WHERE id IN ($placeholders)");
            $upd->execute($ids);

            // Start this device's cooldown clock from the moment of dispatch
            // (not the ack) — the phone is expected to send immediately after
            // receiving this response, so this is close enough to "actual send
            // time" without waiting on a second round trip.
            $pdo->prepare('UPDATE sms_gateway_devices SET last_dispatched_at = NOW() WHERE id = ?')->execute([$deviceId]);

            // One dispatch-log row per message claimed, feeding the rolling
            // window counts above. Deliberately separate from sms_outbox —
            // that table's status/updated_at get overwritten by later
            // acks/retries and can't answer "how many in the last N minutes".
            $logStmt = $pdo->prepare('INSERT INTO sms_gateway_dispatch_log (device_id, dispatched_at) VALUES (?, NOW())');
            foreach ($rows as $r) {
                $logStmt->execute([$deviceId]);
            }

            // Opportunistic cleanup so this table never grows unbounded — cheap
            // indexed range delete, safe to run on every poll that dispatches.
            $pdo->prepare('DELETE FROM sms_gateway_dispatch_log WHERE dispatched_at < (NOW() - INTERVAL 25 HOUR)')->execute();
        }
        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        fail('Could not fetch queue', 500);
    }

    // Flat single-object shape for automation tools (MacroDroid, Tasker, etc.)
    // that can't easily loop over a JSON array. id=0 means "nothing queued
    // right now" — either the outbox is genuinely empty, or (if wait_seconds
    // is present and > 0) this device is still inside its pacing cooldown
    // and has something waiting, just not yet. Existing pollers that only
    // check "id > 0" keep working unchanged; wait_seconds is purely extra
    // info for anything that wants to poll smarter later.
    if ($single) {
        $row = $rows[0] ?? null;
        json_out($row ? [
            'id' => (int)$row['id'],
            'to' => (string)$row['to_number'],
            'message' => (string)$row['message'],
            'purpose' => (string)$row['purpose'],
        ] : ['id' => 0, 'wait_seconds' => $waitSeconds]);
    }

    json_out([
        'messages' => array_map(static fn($r) => [
            'id' => (int)$r['id'],
            'to' => (string)$r['to_number'],
            'message' => (string)$r['message'],
            'purpose' => (string)$r['purpose'],
        ], $rows),
    ]);
}

/* --------------------------------- POST /ack ------------------------------- */
if ($method === 'POST' && $action === 'ack') {
    $id = (int)($body['id'] ?? 0);
    $status = (string)($body['status'] ?? '');
    if ($id <= 0 || !in_array($status, ['sent', 'failed'], true)) {
        fail('id and status ("sent" or "failed") are required', 422);
    }

    if ($status === 'sent') {
        $stmt = db()->prepare("UPDATE sms_outbox SET status = 'sent', sent_at = NOW() WHERE id = ?");
        $stmt->execute([$id]);
    } else {
        $err = mb_substr((string)($body['error'] ?? ''), 0, 255);
        $stmt = db()->prepare(
            "UPDATE sms_outbox
             SET status = CASE WHEN attempts >= 3 THEN 'failed' ELSE 'pending' END, last_error = ?
             WHERE id = ?"
        );
        $stmt->execute([$err, $id]);
    }

    json_out(['ok' => true]);
}

/* -------------------------------- Health check ----------------------------- */
if ($method === 'GET' && $action === '') {
    json_out(['name' => 'SMS Gateway relay', 'status' => 'ok', 'device_id' => $deviceId]);
}

fail('Unknown action', 404);