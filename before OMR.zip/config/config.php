<?php
declare(strict_types=1);

/**
 * SECURITY: db.pass below should be rotated and moved out of this file — see
 * docs/CODE_REVIEW.md §2. This file is committed alongside app code (zips,
 * backups, git history all carry it), so anyone with a copy of the project has
 * this password today. To move it out:
 *   1. Rotate the DB password on the server / hosting control panel.
 *   2. Set an environment variable DB_PASS (most hosts: cPanel > Setup Node.js/PHP
 *      App > environment variables, or an .env loaded by your webserver config).
 *   3. Leave the fallback below as '' (or delete it) once the env var is set —
 *      getenv() will pick it up automatically, no other code changes needed.
 */
return [
    'app' => [
        'name' => 'School Management System',
        'base_url' => 'https://school.akhoonzadaholdings.com/public',
        'timezone' => 'Asia/Karachi',
        'session_name' => 'SMSSESSID',
        'session_inactivity_seconds' => 1800,
        // Production: keep this false. It only controls whether raw PHP errors are
        // ever shown in the browser (see public/index.php) — true should only be
        // used temporarily on a local/dev copy, never on the live site.
        'debug' => true,
    ],
    'db' => [
        'host' => getenv('DB_HOST') ?: '127.0.0.1',
        'user' => getenv('DB_USER') ?: 'u897128490_sms',
        'pass' => getenv('DB_PASS') ?: 'Bilamik@2018',
        'name' => getenv('DB_NAME') ?: 'u897128490_school_sms',
        // 'port' => 3306,
        'charset' => 'utf8mb4',
    ],
    'mail' => [
        'from_email' => 'mubashirbaltistani1@gmail.com',
        'from_name' => 'Akhoon Zada Public School And College Bilamik',
    ],
];
