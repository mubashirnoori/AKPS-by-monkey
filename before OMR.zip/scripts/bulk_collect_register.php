<?php
declare(strict_types=1);

/**
 * Bulk-collect fee invoices from a paper fee register CSV.
 *
 * WHAT THIS DOES
 * ---------------
 * You keep a physical/Excel "register" of what was actually collected from
 * each student, month by month (roll number, student name, month, amount,
 * remarks like Half / 25% off). This script reads that register and, for
 * every row it can match with confidence, records the payment in the
 * software exactly the way the "Collect Payment" screen would -- same
 * FeeService::recordPayment() call, same per-month line allocation, same
 * invoice status updates -- and attributes it to whichever staff member is
 * assigned as fee collector for that class (Staff -> Fee Collectors).
 *
 * Anything it isn't sure about (name doesn't match the roll number, no open
 * line for that month, amount doesn't fit, no collector assigned to the
 * class, etc.) is left completely untouched and written to a review file
 * instead -- nothing is guessed.
 *
 * USAGE (on the server, from the project root)
 * ----------------------------------------------
 *   php scripts/bulk_collect_register.php --file=register.csv
 *       Dry run. Prints/writes what WOULD happen. No database writes.
 *
 *   php scripts/bulk_collect_register.php --file=register.csv --commit
 *       Actually records the payments.
 *
 * Optional flags:
 *   --collected-by=USER_ID   Attribute every payment to this user instead of
 *                            the class's assigned fee collector (only use
 *                            this if you WANT to override attribution).
 *   --method=cash|card|bank  Payment method to record (default: cash).
 *
 * CSV FORMAT (header row required, exactly these columns, in any order):
 *   class, section, serial_no, student_name, month, amount, remarks
 *   - class:  e.g. Nursery, Prep, 1st, 2nd, 3rd ... 8th
 *   - section: e.g. A
 *   - serial_no: the student's roll number IN THAT CLASS/SECTION
 *   - student_name: as written in the register (used only to double check
 *     the roll number resolves to the right child -- never used to look the
 *     student up on its own)
 *   - month: "Mon YYYY", e.g. "Apr 2026"
 *   - amount: the amount actually collected for that month (already
 *     reflecting Half / 25% off / whatever was really paid)
 *   - remarks: free text, informational only (Half, 25% off, ...)
 *
 * OUTPUT
 * ------
 * Writes two files next to the input CSV:
 *   <input>.collected.csv  - rows that were (or would be) recorded
 *   <input>.review.csv     - rows left alone, with the reason why
 * And prints a summary, including totals per collecting teacher.
 */

require __DIR__ . '/../app/core/Database.php';
require __DIR__ . '/../app/services/FeeService.php';

// ---------------------------------------------------------------------
// CLI args
// ---------------------------------------------------------------------
$options = getopt('', ['file:', 'commit', 'collected-by:', 'method:']);
if (empty($options['file'])) {
    fwrite(STDERR, "Usage: php bulk_collect_register.php --file=register.csv [--commit] [--collected-by=USER_ID] [--method=cash]\n");
    exit(1);
}
$csvPath = $options['file'];
$commit = array_key_exists('commit', $options);
$method = $options['method'] ?? 'cash';
$overrideCollector = isset($options['collected-by']) ? (int)$options['collected-by'] : null;
if (!in_array($method, ['cash', 'card', 'bank'], true)) {
    fwrite(STDERR, "Invalid --method: $method (must be cash, card or bank)\n");
    exit(1);
}
if (!is_file($csvPath)) {
    fwrite(STDERR, "File not found: $csvPath\n");
    exit(1);
}

// ---------------------------------------------------------------------
// Static lookup tables
// ---------------------------------------------------------------------

// The register spells classes the "everyday" way; the DB spells the two
// numeric-named classes differently. Extend this if other class names ever
// mismatch between the register and the system.
$CLASS_ALIASES = [
    '1st' => 'One Class',
    '2nd' => 'Class Two',
];

$MONTH_NAMES = [
    'Jan' => 'January', 'Feb' => 'February', 'Mar' => 'March', 'Apr' => 'April',
    'May' => 'May', 'Jun' => 'June', 'Jul' => 'July', 'Aug' => 'August',
    'Sep' => 'September', 'Oct' => 'October', 'Nov' => 'November', 'Dec' => 'December',
];

// Only these months are processed. Everything else in the CSV is left in
// the review file untouched, as requested ("just do till july").
$ALLOWED_MONTHS = ['Mar 2026', 'Apr 2026', 'May 2026', 'Jun 2026', 'Jul 2026'];

function normalizeName(string $s): string
{
    $s = strtolower($s);
    $s = preg_replace('/[^a-z0-9\s]/', ' ', $s);
    $s = preg_replace('/\s+/', ' ', $s);
    return trim($s);
}

/**
 * Loose match: every significant word typed in the register must appear
 * (allowing small typos) somewhere in the student's system name (first +
 * last, and father's name as a bonus check). This is deliberately
 * conservative -- ambiguous cases fall through to "no match".
 */
function namesLikelyMatch(string $registerName, string $firstLast, ?string $fatherName): bool
{
    $reg = normalizeName($registerName);
    $sys = normalizeName($firstLast);
    $father = $fatherName ? normalizeName($fatherName) : '';

    if ($reg === '' || $sys === '') {
        return false;
    }
    if ($reg === $sys) {
        return true;
    }

    $regWords = array_filter(explode(' ', $reg));
    $sysWords = array_filter(explode(' ', $sys . ' ' . $father));

    $matched = 0;
    foreach ($regWords as $rw) {
        foreach ($sysWords as $sw) {
            similar_text($rw, $sw, $pct);
            if ($rw === $sw || $pct >= 80) {
                $matched++;
                break;
            }
        }
    }
    // Require at least 60% of the words typed in the register to be found.
    return count($regWords) > 0 && ($matched / count($regWords)) >= 0.6;
}

// ---------------------------------------------------------------------
// Load reference data
// ---------------------------------------------------------------------

$classSections = []; // "class|section" (lowercased) => class_section_id
$rows = Database::fetchAll(
    "SELECT cs.id, c.name AS class_name, s.name AS section_name
     FROM class_sections cs
     JOIN classes c ON c.id = cs.class_id
     JOIN sections s ON s.id = cs.section_id"
);
foreach ($rows as $r) {
    $key = strtolower($r['class_name']) . '|' . strtolower($r['section_name']);
    $classSections[$key][] = (int)$r['id'];
}

// class_section_id => collecting user_id (Staff > Fee Collectors assignment)
$collectorByClassSection = [];
$rows = Database::fetchAll(
    "SELECT sfc.class_section_id, sp.user_id, sp.full_name
     FROM staff_fee_classes sfc
     JOIN staff_profiles sp ON sp.id = sfc.staff_profile_id
     WHERE sp.user_id IS NOT NULL"
);
foreach ($rows as $r) {
    $collectorByClassSection[(int)$r['class_section_id']] = [
        'user_id' => (int)$r['user_id'],
        'name' => $r['full_name'],
    ];
}

// (class_section_id, roll_number) => student_id  (+ duplicate detection)
$studentByRoll = [];
$rows = Database::fetchAll(
    "SELECT sca.class_section_id, sca.roll_number, sca.student_id
     FROM student_class_assignments sca
     WHERE sca.roll_number IS NOT NULL"
);
foreach ($rows as $r) {
    $key = (int)$r['class_section_id'] . '|' . (int)$r['roll_number'];
    $studentByRoll[$key][] = (int)$r['student_id'];
}

// student_id => [first_name,last_name,father_name,status]
$students = [];
$rows = Database::fetchAll("SELECT id, first_name, last_name, father_name, status FROM students");
foreach ($rows as $r) {
    $students[(int)$r['id']] = $r;
}

// ---------------------------------------------------------------------
// Process the CSV
// ---------------------------------------------------------------------

$fh = fopen($csvPath, 'r');
$header = fgetcsv($fh);
$header = array_map('trim', $header);
$colIndex = array_flip($header);
foreach (['class', 'section', 'serial_no', 'student_name', 'month', 'amount', 'remarks'] as $need) {
    if (!isset($colIndex[$need])) {
        fwrite(STDERR, "CSV is missing required column: $need\n");
        exit(1);
    }
}

$collectedReport = [];
$reviewReport = [];
$teacherTotals = []; // name => sum
$grandTotal = 0.0;
$lineNo = 1;

while (($row = fgetcsv($fh)) !== false) {
    $lineNo++;
    if (count($row) < count($header)) {
        continue; // blank/short line
    }
    $class = trim($row[$colIndex['class']]);
    $section = trim($row[$colIndex['section']]);
    $serial = trim($row[$colIndex['serial_no']]);
    $studentName = trim($row[$colIndex['student_name']]);
    $month = trim($row[$colIndex['month']]);
    $amount = (float)$row[$colIndex['amount']];
    $remarks = trim((string)$row[$colIndex['remarks']]);

    $base = compact('class', 'section', 'serial', 'studentName', 'month', 'amount', 'remarks');

    if (!in_array($month, $ALLOWED_MONTHS, true)) {
        // Deliberately out of scope for this run (Aug 2026 onward etc.) --
        // not an error, just "do manually later" per instructions.
        $reviewReport[] = $base + ['reason' => 'Outside Mar-Jul 2026 scope for this run'];
        continue;
    }

    // Resolve class/section -> class_section_id
    $lookupClass = $CLASS_ALIASES[$class] ?? $class;
    $key = strtolower($lookupClass) . '|' . strtolower($section);
    if (!isset($classSections[$key]) || count($classSections[$key]) !== 1) {
        $reviewReport[] = $base + ['reason' => 'Class/section not found (or ambiguous) in system: ' . $class . ' ' . $section];
        continue;
    }
    $classSectionId = $classSections[$key][0];

    // Resolve roll number -> student
    $rollKey = $classSectionId . '|' . $serial;
    if (!isset($studentByRoll[$rollKey])) {
        $reviewReport[] = $base + ['reason' => "No student with roll #$serial in $class $section"];
        continue;
    }
    if (count($studentByRoll[$rollKey]) > 1) {
        $reviewReport[] = $base + ['reason' => "Ambiguous: multiple students share roll #$serial in $class $section"];
        continue;
    }
    $studentId = $studentByRoll[$rollKey][0];
    $student = $students[$studentId] ?? null;
    if (!$student) {
        $reviewReport[] = $base + ['reason' => 'Student record missing'];
        continue;
    }

    // Verify name against roll number before touching any money.
    $fullName = trim($student['first_name'] . ' ' . $student['last_name']);
    if (!namesLikelyMatch($studentName, $fullName, $student['father_name'])) {
        $reviewReport[] = $base + ['reason' => "Name mismatch: register says \"$studentName\", system roll #$serial is \"$fullName\""];
        continue;
    }

    // Locate the matching, untouched invoice line for this month.
    [$monthAbbr, $year] = array_pad(explode(' ', $month), 2, null);
    $fullMonthName = $MONTH_NAMES[$monthAbbr] ?? null;
    if (!$fullMonthName) {
        $reviewReport[] = $base + ['reason' => "Unrecognized month: $month"];
        continue;
    }
    $description = 'Tuition Fee - ' . $fullMonthName;

    $lineRows = Database::fetchAll(
        "SELECT fil.id AS line_id, fil.line_total, fi.id AS invoice_id, fi.status,
                COALESCE((SELECT SUM(fcl.amount) FROM fee_collection_lines fcl WHERE fcl.fee_invoice_line_id = fil.id), 0) AS paid
         FROM fee_invoice_lines fil
         JOIN fee_invoices fi ON fi.id = fil.fee_invoice_id
         WHERE fi.student_id = ? AND fil.description = ?",
        'is',
        [$studentId, $description]
    );

    if (count($lineRows) === 0) {
        $reviewReport[] = $base + ['reason' => "No \"$description\" invoice line found for this student"];
        continue;
    }
    if (count($lineRows) > 1) {
        $reviewReport[] = $base + ['reason' => "Multiple \"$description\" invoice lines found for this student -- ambiguous"];
        continue;
    }
    $line = $lineRows[0];

    if ($line['status'] === 'cancelled') {
        $reviewReport[] = $base + ['reason' => 'Invoice is cancelled'];
        continue;
    }

    $lineTotal = (float)$line['line_total'];
    $alreadyPaid = (float)$line['paid'];
    $pending = round($lineTotal - $alreadyPaid, 2);

    if ($pending <= 0.001) {
        $reviewReport[] = $base + ['reason' => 'Already fully collected for this month in the system -- no action needed'];
        continue;
    }
    if ($alreadyPaid > 0.001) {
        // Some payment already exists against this month that doesn't add
        // up to "untouched" -- don't guess, let a human reconcile it.
        $reviewReport[] = $base + ['reason' => "Partial payment already on file for this month (Rs $alreadyPaid of Rs $lineTotal) -- needs manual reconciliation"];
        continue;
    }
    if (round($amount, 2) > $pending + 0.01) {
        $reviewReport[] = $base + ['reason' => "Register amount (Rs $amount) exceeds this month's fee (Rs $lineTotal)"];
        continue;
    }
    if ($amount <= 0) {
        $reviewReport[] = $base + ['reason' => 'Zero/invalid amount in register'];
        continue;
    }

    // Resolve the collecting teacher for this class.
    if ($overrideCollector !== null) {
        $collectorUserId = $overrideCollector;
        $collectorName = '(override)';
    } else {
        $collector = $collectorByClassSection[$classSectionId] ?? null;
        if (!$collector) {
            $reviewReport[] = $base + ['reason' => "No fee collector assigned to $class $section (Staff > Fee Collectors) -- can't attribute this payment"];
            continue;
        }
        $collectorUserId = $collector['user_id'];
        $collectorName = $collector['name'];
    }

    // Everything checks out.
    $notes = 'Bulk import from paper fee register (' . $month . ($remarks !== '' ? ', ' . $remarks : '') . ')';

    if ($commit) {
        try {
            FeeService::recordPayment(
                (int)$line['invoice_id'],
                $amount,
                $method,
                $notes,
                $collectorUserId,
                [(int)$line['line_id']],
                null
            );
        } catch (Throwable $e) {
            $reviewReport[] = $base + ['reason' => 'FAILED while recording: ' . $e->getMessage()];
            continue;
        }
    }

    $collectedReport[] = $base + [
        'student_id' => $studentId,
        'invoice_id' => $line['invoice_id'],
        'line_id' => $line['line_id'],
        'collector' => $collectorName,
        'collector_user_id' => $collectorUserId,
    ];
    $teacherTotals[$collectorName] = ($teacherTotals[$collectorName] ?? 0) + $amount;
    $grandTotal += $amount;
}
fclose($fh);

// ---------------------------------------------------------------------
// Write reports
// ---------------------------------------------------------------------

$collectedPath = preg_replace('/\.csv$/i', '', $csvPath) . '.collected.csv';
$reviewPath = preg_replace('/\.csv$/i', '', $csvPath) . '.review.csv';

$out = fopen($collectedPath, 'w');
fputcsv($out, ['class', 'section', 'serial_no', 'student_name', 'month', 'amount', 'remarks', 'student_id', 'invoice_id', 'line_id', 'collector', 'collector_user_id']);
foreach ($collectedReport as $r) {
    fputcsv($out, [$r['class'], $r['section'], $r['serial'], $r['studentName'], $r['month'], $r['amount'], $r['remarks'], $r['student_id'], $r['invoice_id'], $r['line_id'], $r['collector'], $r['collector_user_id']]);
}
fclose($out);

$out = fopen($reviewPath, 'w');
fputcsv($out, ['class', 'section', 'serial_no', 'student_name', 'month', 'amount', 'remarks', 'reason']);
foreach ($reviewReport as $r) {
    fputcsv($out, [$r['class'], $r['section'], $r['serial'], $r['studentName'], $r['month'], $r['amount'], $r['remarks'], $r['reason']]);
}
fclose($out);

// ---------------------------------------------------------------------
// Summary
// ---------------------------------------------------------------------

echo ($commit ? "COMMITTED" : "DRY RUN (no changes made -- rerun with --commit to apply)") . "\n";
echo "Rows " . ($commit ? "collected" : "that would be collected") . ": " . count($collectedReport) . "  (total Rs " . number_format($grandTotal, 2) . ")\n";
echo "Rows left for manual review: " . count($reviewReport) . "\n\n";
echo "By collecting teacher:\n";
foreach ($teacherTotals as $name => $sum) {
    echo "  - $name: Rs " . number_format($sum, 2) . "\n";
}
echo "\nDetailed reports written to:\n  $collectedPath\n  $reviewPath\n";
