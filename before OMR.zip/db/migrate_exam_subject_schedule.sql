-- Adds per-subject date/time scheduling to exams, so a single exam
-- (e.g. "First Term Exam Nursery") can list a different date, start/end
-- time, and total marks for each subject — what the Date Sheet page prints.
--
-- NOTE: This is optional. app/models/ExamSubjectScheduleModel.php will
-- create this table automatically the first time the Date Sheet page is
-- used, so you only need to run this manually if you prefer to migrate
-- ahead of time or your DB user lacks CREATE TABLE privileges at runtime.

CREATE TABLE IF NOT EXISTS exam_subject_schedule (
  id INT AUTO_INCREMENT PRIMARY KEY,
  exam_id INT NOT NULL,
  subject_id INT NOT NULL,
  scheduled_date DATE NULL,
  start_time TIME NULL,
  end_time TIME NULL,
  total_marks INT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NULL,
  UNIQUE KEY uq_exam_subject (exam_id, subject_id),
  CONSTRAINT fk_ess_exam FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE,
  CONSTRAINT fk_ess_subject FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
