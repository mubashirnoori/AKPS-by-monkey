-- Migration: SMS send throttling (space out messages so a relay phone's SIM
-- doesn't get flagged/blocked by the carrier's spam filter for sending too
-- many messages back-to-back).
--
-- Problem this fixes: queue_sms() (app/core/helpers.php) is called once per
-- recipient, so a class-wide announcement can drop 100+ rows into
-- sms_outbox within the same second. The relay phone's MacroDroid macro
-- polls action=pending&single=1 in a tight loop and previously had nothing
-- stopping it from sending all of them one after another with no gap.
-- Carriers (Zong included) treat that burst pattern from an ordinary
-- consumer SIM as spam/flood behaviour and can block the SIM from sending
-- SMS at all — which matches "even manual sends fail now" being reported.
--
-- What this adds:
--   1. `sms_gateway_devices.last_dispatched_at` — timestamp of the last
--      message *handed out* to that device (set the moment a message is
--      claimed, in api/sms_gateway.php). Lets the gateway enforce a minimum
--      gap between dispatches, per device, independent of how fast or slow
--      the polling loop on the phone itself runs.
--   2. `settings.sms_send_interval_seconds` — admin-configurable minimum
--      number of seconds between dispatches per device. Editable under
--      Settings > Notifications without touching code. Defaults to 8
--      seconds, which is a reasonably safe starting point for a personal
--      SIM; raise it if the number gets flagged again, lower it (not below
--      2, enforced in code) once you're confident it's stable.
--
-- This does NOT and cannot un-block a SIM the carrier has already flagged —
-- that block lives on Zong's network, not in this database. See the chat
-- reply for what to do about the number that's blocked right now.
--
-- Safe to run multiple times (idempotent). Not applied automatically — run
-- this against your live database before the throttle takes effect.

SET @col_exists = (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sms_gateway_devices' AND COLUMN_NAME = 'last_dispatched_at'
);
SET @sql = IF(@col_exists = 0,
  'ALTER TABLE sms_gateway_devices ADD COLUMN last_dispatched_at DATETIME NULL DEFAULT NULL AFTER last_seen_at',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

INSERT INTO settings (`key`, `value`, updated_at) VALUES
  ('sms_send_interval_seconds', '8', NOW())
ON DUPLICATE KEY UPDATE `key` = `key`; -- no-op if already set — never overwrites a value you've already changed
