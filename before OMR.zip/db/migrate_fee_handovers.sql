-- =========================================================================
-- Fee handover ledger (teachers/principal collect fees -> hand cash over to
-- Admin/Principal). Lets the app show, per teacher: total collected, total
-- confirmed handed-over, and the net balance they're still holding.
--
-- Design note: a handover starts as 'pending' when the teacher submits it,
-- and only counts toward "handed over" once the receiving Admin/Principal
-- confirms it actually arrived. This two-step flow exists so the ledger
-- reflects money that was actually verified received, not just claimed --
-- a teacher can't zero out their own balance by self-reporting a handover
-- that never happened.
--
-- Safe to run multiple times (idempotent). Run this against your existing
-- database -- it is NOT applied automatically since you're not doing a
-- fresh install.
-- =========================================================================

CREATE TABLE IF NOT EXISTS fee_handovers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  staff_profile_id INT NOT NULL,          -- the teacher/principal handing money over
  handed_over_by_user_id INT NOT NULL,    -- their own login (who submitted this record)
  amount DECIMAL(12,2) NOT NULL,
  handed_over_to_user_id INT NOT NULL,    -- the Admin/Principal receiving it
  note VARCHAR(255) NULL,
  status ENUM('pending','confirmed','rejected') NOT NULL DEFAULT 'pending',
  confirmed_by_user_id INT NULL,
  confirmed_at DATETIME NULL,
  rejection_reason VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_fh_staff FOREIGN KEY (staff_profile_id) REFERENCES staff_profiles(id) ON DELETE CASCADE,
  CONSTRAINT fk_fh_by FOREIGN KEY (handed_over_by_user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_fh_to FOREIGN KEY (handed_over_to_user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_fh_confirmed_by FOREIGN KEY (confirmed_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
  KEY idx_fh_staff (staff_profile_id),
  KEY idx_fh_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Permissions -------------------------------------------------------------
INSERT INTO permissions (permission_key, permission_name, permission_description) VALUES
  ('fees.handover_submit','Fee handover submit','Submit a record of cash handed over to Admin/Principal, and view own collection/handover ledger'),
  ('fees.handover_confirm','Fee handover confirm','Confirm or reject a submitted fee handover, and view every teacher''s collection ledger')
ON DUPLICATE KEY UPDATE permission_key = permission_key;

-- Teacher and Principal can submit handovers of what they personally collected.
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.permission_key = 'fees.handover_submit'
WHERE r.name IN ('Teacher','Principal')
ON DUPLICATE KEY UPDATE role_id = role_id;

-- Admin and Principal can confirm/reject handovers and see the full ledger.
-- Admin is granted explicitly here (not implied) because Admin's permission
-- rows were fixed at your original install, before this permission existed --
-- new permission keys added later are never automatically backfilled onto
-- existing roles, Admin included.
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.permission_key = 'fees.handover_confirm'
WHERE r.name IN ('Admin','Principal')
ON DUPLICATE KEY UPDATE role_id = role_id;
