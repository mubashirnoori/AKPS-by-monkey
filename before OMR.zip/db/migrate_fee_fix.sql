-- ============================================================
-- Fee Module Fix Migration
-- Run this on your existing database to apply all fixes.
-- Safe to run multiple times (uses IF NOT EXISTS / IF EXISTS).
-- ============================================================

-- 1. Add missing columns to fee_categories (if they don't exist yet)
ALTER TABLE fee_categories
  ADD COLUMN IF NOT EXISTS is_one_time  TINYINT NOT NULL DEFAULT 0 COMMENT '1 = one-time fee (e.g. admission)',
  ADD COLUMN IF NOT EXISTS is_admission TINYINT NOT NULL DEFAULT 0 COMMENT '1 = admission fee type',
  ADD COLUMN IF NOT EXISTS is_tuition   TINYINT NOT NULL DEFAULT 0 COMMENT '1 = monthly tuition fee',
  ADD COLUMN IF NOT EXISTS sort_order   INT     NOT NULL DEFAULT 0;

-- 2. Add amount column to fee_assignments (if it doesn't exist yet)
--    (The column exists in the schema but may be missing if DB was created from an old schema)
ALTER TABLE fee_assignments
  ADD COLUMN IF NOT EXISTS amount DECIMAL(10,2) NOT NULL DEFAULT 0.00;

-- Done.
SELECT 'Migration complete. Fee module columns applied.' AS status;
