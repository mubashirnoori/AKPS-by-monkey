-- Migration: add 'academic.bulk_export' permission
--
-- Purpose: separate the Academic module's bulk export actions (bulk ZIP of
-- report cards, bulk XLS/CSV of results) from 'academic.manage'. Teachers
-- need 'academic.manage' for day-to-day marks entry, but bulk-exporting
-- every student's report card/results across the whole school should be
-- Admin/Principal-only, not something every Teacher can reach.
--
-- Safe to run multiple times (idempotent). Run this against your existing
-- database — it is NOT applied automatically since you're not doing a
-- fresh install.

INSERT INTO permissions (permission_key, permission_name, permission_description) VALUES
  ('academic.bulk_export','Academic bulk export','Bulk-export report cards / results (ZIP, XLS, CSV) across the school')
ON DUPLICATE KEY UPDATE permission_key = permission_key;

-- Grant to Admin only. Teacher, Student, and Parent are intentionally left
-- out — Teachers keep 'academic.manage' for marks entry but no longer get
-- bulk export through it. To let a "Principal" or other role use bulk
-- export, grant 'academic.bulk_export' to that role from
-- Users & Roles -> Roles & Permissions (no further SQL/code changes needed).
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.permission_key = 'academic.bulk_export'
WHERE r.name = 'Admin'
ON DUPLICATE KEY UPDATE role_id = role_id;
