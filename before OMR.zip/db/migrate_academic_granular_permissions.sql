-- Migration: separate, finer-grained permissions for two Academic sub-pages
-- that previously shared the single broad 'academic.manage' permission —
-- so a role (e.g. Teacher) can be given Marks Entry without also getting
-- Report Cards, or vice versa.
--
--   academic.marks_entry  -> Academic > Marks Entry
--   academic.report_cards -> Academic > Report Cards
--
-- Every role that currently holds 'academic.manage' is granted BOTH new
-- permissions too, so nobody's access silently narrows when this runs —
-- 'academic.manage' still grants everything it did before (the controllers
-- accept EITHER the broad key OR the specific one). To actually restrict a
-- role to just one of the two, go to Users > Roles & Permissions afterwards
-- and uncheck 'academic.manage' + whichever of the two you don't want,
-- leaving only the one you do.
--
-- Safe to run multiple times. Run this against your existing database.

INSERT INTO permissions (permission_key, permission_name, permission_description) VALUES
  ('academic.marks_entry','Marks Entry','Enter and edit exam marks for assigned classes/subjects'),
  ('academic.report_cards','Report Cards','View and generate student report cards / certificates')
ON DUPLICATE KEY UPDATE permission_key = permission_key;

INSERT INTO role_permissions (role_id, permission_id)
SELECT rp.role_id, p.id
FROM role_permissions rp
JOIN permissions existing ON existing.id = rp.permission_id AND existing.permission_key = 'academic.manage'
JOIN permissions p ON p.permission_key IN ('academic.marks_entry','academic.report_cards')
ON DUPLICATE KEY UPDATE role_id = role_id;
