-- ================================================================
-- Full Fix Migration — run this in phpMyAdmin
-- Safe to run on a fresh or existing database (uses IF NOT EXISTS)
-- ================================================================

-- ----------------------------------------------------------------
-- 1. fee_categories: add columns used by FeeCategoryModel
-- ----------------------------------------------------------------
ALTER TABLE fee_categories
  ADD COLUMN IF NOT EXISTS is_one_time  TINYINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS is_admission TINYINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS is_tuition   TINYINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS sort_order   INT     NOT NULL DEFAULT 0;

-- ----------------------------------------------------------------
-- 2. fee_assignments: add amount column (was missing from INSERT)
-- ----------------------------------------------------------------
ALTER TABLE fee_assignments
  ADD COLUMN IF NOT EXISTS amount DECIMAL(10,2) NOT NULL DEFAULT 0.00;

-- ----------------------------------------------------------------
-- 3. staff_salary_details: add salary_created_date column
-- ----------------------------------------------------------------
ALTER TABLE staff_salary_details
  ADD COLUMN IF NOT EXISTS salary_created_date DATE NULL;

-- ----------------------------------------------------------------
-- 4. staff_salary_payments: rename columns to match the model
--    Schema has:  paid_at (DATETIME), paid_by_user_id (INT)
--    Model uses:  created_at (DATETIME), paid_date (DATE), created_by (INT)
-- ----------------------------------------------------------------

-- Add paid_date if missing
ALTER TABLE staff_salary_payments
  ADD COLUMN IF NOT EXISTS paid_date DATE NULL;

-- Add created_by if missing  
ALTER TABLE staff_salary_payments
  ADD COLUMN IF NOT EXISTS created_by INT NULL;

-- Populate paid_date from paid_at where not set
UPDATE staff_salary_payments
  SET paid_date = DATE(paid_at)
  WHERE paid_date IS NULL AND paid_at IS NOT NULL;

-- Populate created_by from paid_by_user_id where not set
UPDATE staff_salary_payments
  SET created_by = paid_by_user_id
  WHERE created_by IS NULL AND paid_by_user_id IS NOT NULL;

-- Rename paid_at -> created_at if the column is still named paid_at
-- (Only runs if paid_at exists; MySQL ALTER CHANGE is safe to run)
-- Note: if you already ran a previous migration, this may show a warning - that's fine.
ALTER TABLE staff_salary_payments
  CHANGE COLUMN IF EXISTS paid_at created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- ----------------------------------------------------------------
-- 5. Clear any zero-amount fee assignments (leftover from old bug)
-- ----------------------------------------------------------------
DELETE FROM fee_assignments WHERE amount = 0 OR amount IS NULL;

-- ----------------------------------------------------------------
-- Confirm
-- ----------------------------------------------------------------
SELECT 'Migration complete — all fixes applied.' AS status;
