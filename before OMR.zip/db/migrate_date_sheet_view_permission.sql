-- Adds a view-only Date Sheet permission, so Student/Parent roles can see their
-- class's exam date sheet without being able to edit it. Safe to run more than once.
INSERT INTO permissions (permission_key, permission_name, permission_description)
SELECT 'academic.date_sheet_view', 'Date Sheet (view only)', 'See the exam date sheet for own class (read-only, student/parent portal)'
WHERE NOT EXISTS (SELECT 1 FROM permissions WHERE permission_key = 'academic.date_sheet_view');
