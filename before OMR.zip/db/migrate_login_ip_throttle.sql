-- Per-IP login throttle, separate from the existing per-account lockout
-- (users.failed_attempts / locked_until). Without this, an attacker could try
-- many different usernames from a single IP with no limit at all.
--
-- NOTE: optional to run by hand — Auth.php creates this table automatically
-- the first time someone attempts to log in, provided your DB user has
-- CREATE TABLE privileges. Run this manually if it doesn't.

CREATE TABLE IF NOT EXISTS login_ip_throttle (
  ip_address VARCHAR(45) NOT NULL PRIMARY KEY,
  attempts INT NOT NULL DEFAULT 0,
  window_started_at DATETIME NOT NULL,
  locked_until DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
