-- =========================================================================
-- Direct SMS (Portal > Send SMS) — lets a teacher/principal text a specific
-- student/parent (only in classes they teach or collect fees for), any
-- staff member, or a whole class (same class scoping) — separate from the
-- admin-only broadcast Announcements feature.
--
-- Adds one permission, `sms.direct_send`, granted by default to Admin,
-- Teacher and Principal. Grant/revoke it for any other role afterwards
-- from Users & Roles > Roles & Permissions, same as any other permission.
--
-- No new tables — this reuses the existing sms_outbox / sms_gateway_devices
-- infrastructure via the same queue_sms() helper the Announcements and Fee
-- Overdue Reminder features already call.
--
-- Safe to run multiple times (idempotent). Not applied automatically — run
-- this against your live database before using the new feature.
-- =========================================================================

INSERT INTO permissions (permission_key, permission_name, permission_description) VALUES
  ('sms.direct_send', 'Send Direct SMS', 'Send a direct SMS to a specific student/parent, a specific staff member, or a whole class')
ON DUPLICATE KEY UPDATE permission_key = permission_key;

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.permission_key = 'sms.direct_send'
WHERE r.name IN ('Admin', 'Teacher', 'Principal')
ON DUPLICATE KEY UPDATE role_id = role_id;
