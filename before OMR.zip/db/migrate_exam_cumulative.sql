-- =========================
-- Combined/cumulative exams — e.g. "Final Term" = First Term + Final Term marks (v14)
-- =========================
-- Lets one exam (typically the last one of the year) be configured to add its
-- own marks on top of an earlier exam's marks, per subject, before pass/fail
-- and class/school position are worked out. Stores the *base* exam name (the
-- part before any " — Class Section" tag multi-class exam creation adds), so
-- one selection works whether the source exam was created for a single class
-- or several at once — see ExamModel::resolveCumulativeSourceExamId().
--
-- This also ships as a self-healing column (ExamModel::ensureCumulativeColumn()
-- runs it automatically the next time an exam is read/saved), so running this
-- file by hand is optional — it's here for anyone who prefers to migrate the
-- database directly rather than waiting for the app to do it on first use.
--
-- Safe to re-run.
ALTER TABLE exams
  ADD COLUMN IF NOT EXISTS cumulative_source_exam_name VARCHAR(150) NULL;
