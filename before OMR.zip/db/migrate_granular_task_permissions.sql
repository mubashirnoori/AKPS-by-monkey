-- =========================================================================
-- Migration: task-level permissions across every module.
--
-- Until now, most pages shared one broad "module.manage" permission — e.g.
-- 'students.manage' covered creating, editing, deactivating, importing,
-- bulk-assigning class, complaints, promotions, etc. all at once, so you
-- could never give someone ONLY "add students" without also giving them
-- delete/import/complaints/etc.
--
-- This migration adds one specific permission per distinct task, so each
-- can be checked/unchecked independently in Users & Roles > Roles &
-- Permissions. The broad "module.manage" permission still works exactly as
-- before (the code accepts EITHER the broad key OR the specific one) — so
-- nobody's access changes automatically when this runs. Every specific
-- permission below is backfilled onto whichever roles already hold its
-- parent broad permission, so existing roles keep exactly the access they
-- have today; the new checkboxes just make it possible to narrow a role
-- down to individual tasks going forward.
--
-- Also wires up two permissions that already existed in the database but
-- weren't actually checked by any code yet:
--   'class_teachers.manage'            -> Academic > Assign Class Teacher
--   'fee_collection_assignments.manage' -> Staff > Fee Collectors
-- (Assigning a class teacher remains Admin-only regardless of this
-- checkbox — that page has a separate hard-coded Admin-only gate that this
-- migration does not touch.)
--
-- Safe to run multiple times (idempotent). Run this against your existing
-- database — it is NOT applied automatically since you're not doing a
-- fresh install.
-- =========================================================================

INSERT INTO permissions (permission_key, permission_name, permission_description) VALUES
  -- Academic (parent: academic.manage)
  ('academic.subjects_manage','Subjects','Create, edit, delete and merge subjects'),
  ('academic.teacher_assignments','Teacher Assignments','Assign teachers to subjects/classes'),
  ('academic.timetable','Timetable','Create and edit the class timetable'),
  ('academic.exam_types','Exam Types','Manage exam types'),
  ('academic.exam_groups','Exam Groups','Manage exam groups and pass criteria'),
  ('academic.exams','Exams','Create and manage exams, including publishing/unpublishing results'),
  ('academic.grade_settings','Grade Settings','Configure grading scales'),
  ('academic.date_sheet','Date Sheet','Create and edit the exam date sheet'),
  ('academic.school_topper','Whole-School Topper','View/manage the whole-school topper list'),
  ('academic.id_cards','ID Cards','Generate student ID cards'),
  ('academic.classes','Classes','Create, edit and delete classes'),
  ('academic.sections','Sections','Create, edit and delete sections'),
  ('academic.class_sections','Class-Sections','Create, edit and delete class-section combinations'),
  ('academic.courses','Courses','Manage courses, course assignments and course resources'),

  -- Fees (parent: fees.manage)
  ('fees.categories','Fee Categories','Create, edit and delete fee categories'),
  ('fees.assignments','Fee Assignments','Assign fee structures to classes'),
  ('fees.generate_invoices','Generate Invoices','Bulk-generate fee invoices'),
  ('fees.apply_one_time_fee','Apply One-Time Fee','Apply a one-off fee/charge to a student'),
  ('fees.invoices','Invoices','View and manage the invoices list'),
  ('fees.invoices_export_csv','Export Invoices CSV','Export the invoices list to CSV'),
  ('fees.invoice_update','Edit Invoice','Edit an existing invoice'),
  ('fees.invoice_delete','Delete Invoice','Delete an invoice'),
  ('fees.collection_delete','Delete Fee Collection','Delete a recorded fee payment'),
  ('fees.collect','Collect Fees','Record a fee payment against an invoice'),
  ('fees.settings','Fee Settings','Configure fee module settings'),
  ('fees.bulk_exports','Fee Bulk Exports','Bulk-export invoices (ZIP/XLS/CSV)'),

  -- Staff (parent: staff.manage)
  ('staff.profiles','Staff Profiles','Create, edit and delete staff profiles'),
  ('staff.set_salary','Set Basic Salary','Set a staff member''s basic salary'),
  ('staff.attendance_take','Take Staff Attendance','Mark daily staff attendance'),
  ('staff.leaves','Staff Leaves','View staff leave requests'),
  ('staff.leave_decision','Approve/Reject Staff Leave','Approve or reject a staff leave request'),
  ('staff.performance','Staff Performance','View/manage staff performance records'),
  ('staff.payroll','Payroll','Manage staff payroll and payments'),

  -- Students (parent: students.manage / students.view)
  ('students.create','Add Student','Create a new student / admission'),
  ('students.update','Edit Student','Edit an existing student''s details'),
  ('students.deactivate','Deactivate Student','Deactivate/delete a single student'),
  ('students.bulk_deactivate','Bulk Deactivate Students','Deactivate multiple students at once'),
  ('students.bulk_assign_class','Bulk Assign Class','Bulk-assign students to a class/section'),
  ('students.import','Import Students','Bulk-import students via CSV'),
  ('students.guardians_manage','Manage Guardians','Add/remove a student''s guardians'),
  ('students.promotions','Student Promotions','Promote students to the next class'),
  ('students.inquiries','Admission Inquiries','Manage admission inquiries'),
  ('students.complaints','Student Complaints','View and resolve student complaints'),
  ('students.assessment_settings','Assessment Settings','Configure student assessment settings'),
  ('students.custom_fields','Student Custom Fields','Manage custom fields for the student form'),
  ('students.photo_upload','Upload Student Photo','Upload/replace a student''s photo'),
  ('students.export_csv','Export Students CSV','Export the student list to CSV'),

  -- Users & Roles (parent: users.manage)
  ('users.accounts_manage','User Accounts','Create, edit and manage user accounts'),
  ('users.bulk_generate','Bulk Generate Logins','Bulk-generate login accounts'),
  ('users.permissions_update','Roles & Permissions','Create roles and assign permissions'),
  ('users.custom_fields','User Custom Fields','Manage custom fields for user profiles'),

  -- Settings (parent: settings.manage)
  ('settings.global','Global Settings','Edit global app settings'),
  ('settings.academic_years','Academic Years','Manage academic years'),
  ('settings.institute','Institute Details','Edit institute name/address/contact'),
  ('settings.branding','Branding','Edit logo/branding'),
  ('settings.notifications_update','Notification Settings','Configure notification channels'),
  ('settings.smtp_test','SMTP Test','Send a test email via SMTP'),
  ('settings.sms_test','SMS Test','Send a test SMS'),
  ('settings.labels','Field Labels','Edit custom field labels'),
  ('settings.clean_data','Clean Data','Run data-cleanup tools'),
  ('settings.backup_restore','Backup & Restore','Download backups and restore data'),

  -- Expenses (parent: expenses.manage)
  ('expenses.create','Record Expense','Record a new expense'),
  ('expenses.update','Edit Expense','Edit an existing expense'),
  ('expenses.delete','Delete Expense','Delete an expense'),
  ('expenses.category_create','Add Expense Category','Create an expense category'),
  ('expenses.category_rename','Rename Expense Category','Rename an expense category'),
  ('expenses.category_delete','Delete Expense Category','Delete an expense category'),

  -- Notifications (parent: notifications.announce)
  ('notifications.announcement_delete','Delete Announcement','Delete a sent announcement')
ON DUPLICATE KEY UPDATE permission_key = permission_key;

-- Backfill: grant every new specific permission to whichever roles already
-- hold its parent broad permission, so nobody's access narrows.
INSERT INTO role_permissions (role_id, permission_id)
SELECT rp.role_id, p.id
FROM role_permissions rp
JOIN permissions parent ON parent.id = rp.permission_id
JOIN permissions p ON p.permission_key IN (
  'academic.subjects_manage','academic.teacher_assignments','academic.timetable',
  'academic.exam_types','academic.exam_groups','academic.exams','academic.grade_settings',
  'academic.date_sheet','academic.school_topper','academic.id_cards','academic.classes',
  'academic.sections','academic.class_sections','academic.courses'
)
WHERE parent.permission_key = 'academic.manage'
  AND NOT EXISTS (
    SELECT 1 FROM role_permissions x WHERE x.role_id = rp.role_id AND x.permission_id = p.id
  );

INSERT INTO role_permissions (role_id, permission_id)
SELECT rp.role_id, p.id
FROM role_permissions rp
JOIN permissions parent ON parent.id = rp.permission_id
JOIN permissions p ON p.permission_key IN (
  'fees.categories','fees.assignments','fees.generate_invoices','fees.apply_one_time_fee',
  'fees.invoices','fees.invoices_export_csv','fees.invoice_update','fees.invoice_delete',
  'fees.collection_delete','fees.collect','fees.settings','fees.bulk_exports'
)
WHERE parent.permission_key = 'fees.manage'
  AND NOT EXISTS (
    SELECT 1 FROM role_permissions x WHERE x.role_id = rp.role_id AND x.permission_id = p.id
  );

INSERT INTO role_permissions (role_id, permission_id)
SELECT rp.role_id, p.id
FROM role_permissions rp
JOIN permissions parent ON parent.id = rp.permission_id
JOIN permissions p ON p.permission_key IN (
  'staff.profiles','staff.set_salary','staff.attendance_take','staff.leaves',
  'staff.leave_decision','staff.performance','staff.payroll'
)
WHERE parent.permission_key = 'staff.manage'
  AND NOT EXISTS (
    SELECT 1 FROM role_permissions x WHERE x.role_id = rp.role_id AND x.permission_id = p.id
  );

INSERT INTO role_permissions (role_id, permission_id)
SELECT rp.role_id, p.id
FROM role_permissions rp
JOIN permissions parent ON parent.id = rp.permission_id
JOIN permissions p ON p.permission_key IN (
  'students.create','students.update','students.deactivate','students.bulk_deactivate',
  'students.bulk_assign_class','students.import','students.guardians_manage',
  'students.promotions','students.inquiries','students.complaints',
  'students.assessment_settings','students.custom_fields','students.photo_upload'
)
WHERE parent.permission_key = 'students.manage'
  AND NOT EXISTS (
    SELECT 1 FROM role_permissions x WHERE x.role_id = rp.role_id AND x.permission_id = p.id
  );

INSERT INTO role_permissions (role_id, permission_id)
SELECT rp.role_id, p.id
FROM role_permissions rp
JOIN permissions parent ON parent.id = rp.permission_id
JOIN permissions p ON p.permission_key = 'students.export_csv'
WHERE parent.permission_key = 'students.view'
  AND NOT EXISTS (
    SELECT 1 FROM role_permissions x WHERE x.role_id = rp.role_id AND x.permission_id = p.id
  );

INSERT INTO role_permissions (role_id, permission_id)
SELECT rp.role_id, p.id
FROM role_permissions rp
JOIN permissions parent ON parent.id = rp.permission_id
JOIN permissions p ON p.permission_key IN (
  'users.accounts_manage','users.bulk_generate','users.permissions_update','users.custom_fields'
)
WHERE parent.permission_key = 'users.manage'
  AND NOT EXISTS (
    SELECT 1 FROM role_permissions x WHERE x.role_id = rp.role_id AND x.permission_id = p.id
  );

INSERT INTO role_permissions (role_id, permission_id)
SELECT rp.role_id, p.id
FROM role_permissions rp
JOIN permissions parent ON parent.id = rp.permission_id
JOIN permissions p ON p.permission_key IN (
  'settings.global','settings.academic_years','settings.institute','settings.branding',
  'settings.notifications_update','settings.smtp_test','settings.sms_test','settings.labels',
  'settings.clean_data','settings.backup_restore'
)
WHERE parent.permission_key = 'settings.manage'
  AND NOT EXISTS (
    SELECT 1 FROM role_permissions x WHERE x.role_id = rp.role_id AND x.permission_id = p.id
  );

INSERT INTO role_permissions (role_id, permission_id)
SELECT rp.role_id, p.id
FROM role_permissions rp
JOIN permissions parent ON parent.id = rp.permission_id
JOIN permissions p ON p.permission_key IN (
  'expenses.create','expenses.update','expenses.delete','expenses.category_create',
  'expenses.category_rename','expenses.category_delete'
)
WHERE parent.permission_key = 'expenses.manage'
  AND NOT EXISTS (
    SELECT 1 FROM role_permissions x WHERE x.role_id = rp.role_id AND x.permission_id = p.id
  );

INSERT INTO role_permissions (role_id, permission_id)
SELECT rp.role_id, p.id
FROM role_permissions rp
JOIN permissions parent ON parent.id = rp.permission_id
JOIN permissions p ON p.permission_key = 'notifications.announcement_delete'
WHERE parent.permission_key = 'notifications.announce'
  AND NOT EXISTS (
    SELECT 1 FROM role_permissions x WHERE x.role_id = rp.role_id AND x.permission_id = p.id
  );
