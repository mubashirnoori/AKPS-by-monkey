-- =========================================================================
-- Fee overdue SMS reminders (manual "Send Reminders Now" button in Fees).
--
-- This does NOT apply any fine. It only lets staff send a warning SMS to
-- the student and all linked guardians for every open, unpaid, past-due
-- invoice. Automatic fines remain switched off (FeeService::applyAutomaticFineIfOverdue
-- is still an intentional no-op) -- this is separate and additive.
--
-- fee_reminder_log: one row per invoice per time a reminder batch actually
-- queued messages for it. Used only to stop the same invoice being texted
-- twice if staff click "Send Reminders Now" more than once on the same day.
--
-- sms_outbox: the app's PHP code (app/core/helpers.php, api/sms_gateway.php)
-- has always assumed this table exists, but it isn't in the database export
-- reviewed for this project. Since you said the SMS gateway is already
-- working today, it likely already exists on the live server and this is
-- just a stale export -- CREATE TABLE IF NOT EXISTS makes this migration
-- safe to run either way (no-ops if it's already there, creates it
-- matching the exact columns the existing code already reads/writes if it
-- isn't).
--
-- Safe to run multiple times (idempotent). Not applied automatically --
-- run this against your live database before using the new feature.
-- =========================================================================

CREATE TABLE IF NOT EXISTS sms_outbox (
  id INT AUTO_INCREMENT PRIMARY KEY,
  to_number VARCHAR(20) NOT NULL,
  message VARCHAR(640) NOT NULL,
  purpose VARCHAR(40) NOT NULL DEFAULT 'general',
  status ENUM('pending','sending','sent','failed') NOT NULL DEFAULT 'pending',
  attempts INT NOT NULL DEFAULT 0,
  last_error VARCHAR(255) DEFAULT NULL,
  sent_at DATETIME DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_sms_outbox_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS fee_reminder_log (
  id INT AUTO_INCREMENT PRIMARY KEY,
  fee_invoice_id INT NOT NULL,
  sent_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  sent_by_user_id INT DEFAULT NULL,
  recipients_count INT NOT NULL DEFAULT 0,
  CONSTRAINT fk_fee_reminder_log_invoice FOREIGN KEY (fee_invoice_id)
    REFERENCES fee_invoices(id) ON DELETE CASCADE,
  INDEX idx_fee_reminder_log_invoice_date (fee_invoice_id, sent_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
