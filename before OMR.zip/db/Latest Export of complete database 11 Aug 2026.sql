-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 11, 2026 at 12:10 PM
-- Server version: 11.8.8-MariaDB-log
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u897128490_school_sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic_years`
--

CREATE TABLE `academic_years` (
  `id` int(11) NOT NULL,
  `academic_year_label` varchar(20) NOT NULL,
  `session_name` varchar(50) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `academic_years`
--

INSERT INTO `academic_years` (`id`, `academic_year_label`, `session_name`, `start_date`, `end_date`, `is_active`, `created_at`) VALUES
(1, '2026-2027', '2026', '2026-03-02', '2026-12-30', 1, '2026-03-30 18:02:13'),
(2, '2027-2028', '2027', '2027-03-01', '2027-12-31', 1, '2026-07-27 11:41:59'),
(3, '2025-2026', '2026', NULL, NULL, 1, '2026-08-05 12:10:50');

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `role_name` varchar(50) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`id`, `user_id`, `username`, `role_name`, `action`, `description`, `ip_address`, `created_at`) VALUES
(1, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-25 18:12:36'),
(2, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-25 18:12:57'),
(3, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-25 18:13:03'),
(4, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-25 18:13:31'),
(5, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-25 18:13:36'),
(6, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-25 18:41:03'),
(7, 233, 'abdullah.khan', 'Principal', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-25 18:41:11'),
(8, 233, 'abdullah.khan', 'Principal', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-25 18:42:34'),
(9, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-25 18:42:38'),
(10, 7, 'Hussaini', 'Teacher', 'academic.attendance_take', 'Took attendance for 5th A on 2026-07-25 (13 student(s))', '58.65.217.235', '2026-07-25 18:42:55'),
(11, 7, 'Hussaini', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-25 18:43:01'),
(12, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-25 18:43:07'),
(13, 4, 'admin', 'Admin', 'activity_log.export', 'Exported the activity log to CSV (12 rows)', '58.65.217.235', '2026-07-25 18:44:15'),
(14, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:105:4d23:f4f0:d6ff:fefe:9345', '2026-07-26 04:21:03'),
(15, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 05:41:44'),
(16, 4, 'admin', 'Admin', 'academic.class_updated', 'Class updated', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 05:43:01'),
(17, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 06:25:13'),
(18, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '118.107.131.179', '2026-07-26 07:58:58'),
(19, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 08:00:19'),
(20, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 08:00:53'),
(21, 20, 'Hassanad', 'Admin', 'auth.login', 'Logged in', '118.107.131.179', '2026-07-26 08:12:29'),
(22, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 08:24:35'),
(23, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '118.107.135.167', '2026-07-26 08:25:11'),
(24, 4, 'admin', 'Admin', 'settings.notifications_update', 'Updated mail/SMS notification settings', '58.65.217.235', '2026-07-26 08:27:01'),
(25, NULL, NULL, NULL, 'auth.password_reset_request', 'Requested a password reset for \"admin2\"', '58.65.217.235', '2026-07-26 08:27:39'),
(26, NULL, NULL, NULL, 'auth.password_reset_request', 'Requested a password reset for \"admin2\"', '58.65.217.235', '2026-07-26 08:31:57'),
(27, 4, 'admin', 'Admin', 'users.update', 'Updated user account \"admin2\"', '58.65.217.235', '2026-07-26 08:32:49'),
(28, NULL, NULL, NULL, 'auth.password_reset_request', 'Requested a password reset for \"admin2\"', '58.65.217.235', '2026-07-26 08:33:05'),
(29, 20, 'Hassanad', 'Admin', 'auth.login', 'Logged in', '118.107.135.167', '2026-07-26 08:34:35'),
(30, 20, 'Hassanad', 'Admin', 'auth.login', 'Logged in', '118.107.135.167', '2026-07-26 08:35:39'),
(31, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 08:44:00'),
(32, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 08:44:06'),
(33, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 08:44:10'),
(34, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 08:45:01'),
(35, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 08:45:06'),
(36, 15, 'nusrat', 'Student', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 08:45:17'),
(37, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 09:02:38'),
(38, 4, 'admin', 'Admin', 'settings.notifications_update', 'Updated mail/SMS notification settings', '58.65.217.235', '2026-07-26 09:04:48'),
(39, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 09:04:58'),
(40, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 09:05:16'),
(41, NULL, NULL, NULL, 'auth.password_reset_request', 'Requested a password reset for \"admin2\"', '58.65.217.235', '2026-07-26 09:05:46'),
(42, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"mehboob.ali.meer\"', '118.107.135.136', '2026-07-26 09:11:58'),
(43, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"mehboob.ali.meer\"', '118.107.135.136', '2026-07-26 09:12:08'),
(44, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"mehboob.ali.meer\"', '118.107.135.136', '2026-07-26 09:12:14'),
(45, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"mehboob.ali.meer\"', '118.107.135.136', '2026-07-26 09:12:18'),
(46, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"mehboob.ali.meer\"', '118.107.135.136', '2026-07-26 09:12:25'),
(47, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"G.abbas\"', '118.107.131.34', '2026-07-26 09:17:24'),
(48, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '118.107.131.34', '2026-07-26 09:17:27'),
(49, 15, 'nusrat', 'Student', 'auth.login_failed', 'Failed login attempt for username \"G.abbas\"', '118.107.131.34', '2026-07-26 09:18:01'),
(50, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 09:26:59'),
(51, 21, 'G.Abbas', 'Teacher', 'auth.login', 'Logged in', '118.107.131.34', '2026-07-26 09:28:07'),
(52, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 09:33:46'),
(53, 21, 'G.Abbas', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.131.34', '2026-07-26 09:33:57'),
(54, 4, 'admin', 'Admin', 'staff.update', 'Updated staff profile \"Fida Hussain\" (#11)', '58.65.217.235', '2026-07-26 09:34:11'),
(55, 4, 'admin', 'Admin', 'staff.update', 'Updated staff profile \"Mehboob Ali Meer\" (#17)', '58.65.217.235', '2026-07-26 09:34:19'),
(56, 240, 'wazir.nasrullah', 'Teacher', 'auth.login', 'Logged in', '118.107.132.201', '2026-07-26 09:41:18'),
(57, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"\"', '118.107.132.201', '2026-07-26 09:41:19'),
(58, 240, 'wazir.nasrullah', 'Teacher', 'auth.login', 'Logged in', '118.107.132.201', '2026-07-26 09:41:27'),
(59, 4, 'admin', 'Admin', 'staff.update', 'Updated staff profile \"Mehboob Ali Meer\" (#17)', '58.65.217.235', '2026-07-26 09:41:55'),
(60, 4, 'admin', 'Admin', 'staff.update', 'Updated staff profile \"WAZIR NASRULLAH\" (#19)', '58.65.217.235', '2026-07-26 09:42:10'),
(61, 4, 'admin', 'Admin', 'staff.update', 'Updated staff profile \"Ghulam Abbas\" (#8)', '58.65.217.235', '2026-07-26 09:42:24'),
(62, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 09:42:39'),
(63, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 09:42:43'),
(64, 7, 'Hussaini', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 09:43:11'),
(65, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 09:43:18'),
(66, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 09:43:26'),
(67, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 09:43:37'),
(68, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 09:43:44'),
(69, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 09:56:49'),
(70, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 09:57:53'),
(71, 7, 'Hussaini', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 09:59:06'),
(72, 21, 'G.Abbas', 'Teacher', 'auth.login', 'Logged in', '118.107.131.34', '2026-07-26 09:59:19'),
(73, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"\"', '118.107.131.34', '2026-07-26 09:59:25'),
(74, 21, 'G.Abbas', 'Teacher', 'auth.login', 'Logged in', '118.107.131.34', '2026-07-26 09:59:30'),
(75, 21, 'G.Abbas', 'Teacher', 'auth.login', 'Logged in', '118.107.131.34', '2026-07-26 09:59:34'),
(76, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"mehboob.ali.meer\"', '118.107.135.136', '2026-07-26 09:59:39'),
(77, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 09:59:44'),
(78, 4, 'admin', 'Admin', 'settings.notifications_update', 'Updated mail/SMS notification settings', '58.65.217.235', '2026-07-26 10:00:17'),
(79, 4, 'admin', 'Admin', 'settings.smtp_test', 'Sent a test email to mubashirbaltistani@gmail.com', '58.65.217.235', '2026-07-26 10:00:36'),
(80, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 10:00:56'),
(81, NULL, NULL, NULL, 'auth.password_reset_request', 'Requested a password reset for \"admin2\"', '58.65.217.235', '2026-07-26 10:01:11'),
(82, NULL, NULL, NULL, 'auth.password_reset_request', 'Requested a password reset for \"admin2\"', '58.65.217.235', '2026-07-26 10:01:56'),
(83, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"mehboob.ali.meer\"', '118.107.135.136', '2026-07-26 10:03:40'),
(84, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 10:03:45'),
(85, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"mehboob.ali.meer\"', '118.107.135.136', '2026-07-26 10:04:07'),
(86, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 10:04:46'),
(87, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"mehboob.ali.meer\"', '58.65.217.235', '2026-07-26 10:04:57'),
(88, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 10:05:42'),
(89, 4, 'admin', 'Admin', 'users.update', 'Updated user account \"mehboob.ali.meer\"', '58.65.217.235', '2026-07-26 10:08:06'),
(90, 238, 'mehboob.ali.meer', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 10:13:51'),
(91, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 10:20:29'),
(92, NULL, NULL, NULL, 'auth.password_reset_request', 'Requested a password reset for \"admin2\"', '58.65.217.235', '2026-07-26 10:20:41'),
(93, 238, 'mehboob.ali.meer', 'Teacher', 'auth.password_reset', 'Reset password for \"admin2\" via emailed link', '58.65.217.235', '2026-07-26 10:21:07'),
(94, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 10:21:39'),
(95, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 10:22:03'),
(96, 4, 'admin', 'Admin', 'staff.update', 'Updated staff profile \"Qasim Naseem\" (#18)', '58.65.217.235', '2026-07-26 10:22:33'),
(97, 4, 'admin', 'Admin', 'users.update', 'Updated user account \"qasim.naseem\"', '58.65.217.235', '2026-07-26 10:25:25'),
(98, 4, 'admin', 'Admin', 'users.update', 'Updated user account \"mehboob.ali.meer\"', '58.65.217.235', '2026-07-26 10:25:51'),
(99, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"mehboob.ali.meer\"', '118.107.135.136', '2026-07-26 10:26:44'),
(100, 4, 'admin', 'Admin', 'users.update', 'Updated user account \"Hussaini\"', '58.65.217.235', '2026-07-26 10:30:38'),
(101, 4, 'admin', 'Admin', 'users.update', 'Updated user account \"wazir.nasrullah\"', '58.65.217.235', '2026-07-26 10:31:00'),
(102, 4, 'admin', 'Admin', 'users.update', 'Updated user account \"admin\"', '58.65.217.235', '2026-07-26 10:32:49'),
(103, 4, 'admin', 'Admin', 'staff.update', 'Updated staff profile \"Mehboob Ali Meer\" (#17)', '58.65.217.235', '2026-07-26 10:34:15'),
(104, 4, 'admin', 'Admin', 'staff.update', 'Updated staff profile \"Qasim Naseem\" (#18)', '58.65.217.235', '2026-07-26 10:34:32'),
(105, 4, 'admin', 'Admin', 'staff.update', 'Updated staff profile \"WAZIR NASRULLAH\" (#19)', '58.65.217.235', '2026-07-26 10:34:54'),
(106, 4, 'admin', 'Admin', 'users.update', 'Updated user account \"Hassan\"', '58.65.217.235', '2026-07-26 10:42:41'),
(107, 240, 'wazir.nasrullah', 'Teacher', 'auth.login', 'Logged in', '118.107.132.142', '2026-07-26 11:03:44'),
(108, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 11:21:06'),
(109, 4, 'admin', 'Admin', 'staff.update', 'Updated staff profile \"Muhammad Hassan\" (#7)', '58.65.217.235', '2026-07-26 11:21:24'),
(110, 20, 'Hassanad', 'Admin', 'auth.login', 'Logged in', '118.107.135.236', '2026-07-26 11:23:03'),
(111, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '118.107.135.236', '2026-07-26 11:29:42'),
(112, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 12:49:40'),
(113, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #492', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:03:16'),
(114, 4, 'admin', 'Admin', 'fees.invoice_update', 'Edited fee invoice #508 (status: open)', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:04:25'),
(115, 4, 'admin', 'Admin', 'fees.invoice_update', 'Edited fee invoice #506 (status: open)', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:04:59'),
(116, 4, 'admin', 'Admin', 'fees.invoice_update', 'Edited fee invoice #505 (status: open)', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:05:29'),
(117, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #509', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:05:38'),
(118, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #508', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:05:39'),
(119, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #507', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:05:41'),
(120, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #506', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:05:43'),
(121, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #505', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:05:45'),
(122, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #504', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:05:48'),
(123, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #503', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:05:51'),
(124, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #502', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:05:53'),
(125, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #501', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:05:57'),
(126, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #500', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:05:59'),
(127, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #499', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:06:01'),
(128, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #498', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:06:03'),
(129, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #497', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:06:05'),
(130, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #496', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:06:07'),
(131, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #495', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:06:09'),
(132, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #494', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:06:11'),
(133, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #493', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:06:13'),
(134, 4, 'admin', 'Admin', 'academic.class_updated', 'Class updated', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:06:48'),
(135, 4, 'admin', 'Admin', 'academic.section_created', 'Section created', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:07:07'),
(136, 4, 'admin', 'Admin', 'academic.section_created', 'Section created', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:07:14'),
(137, 4, 'admin', 'Admin', 'academic.class_section_created', 'Class section created', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:07:51'),
(138, 4, 'admin', 'Admin', 'academic.class_section_deleted', 'Class section deleted', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:08:01'),
(139, 4, 'admin', 'Admin', 'academic.class_updated', 'Class updated', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:09:05'),
(140, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:10:10'),
(141, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Admin2\"', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:23:17'),
(142, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:23:27'),
(143, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:23:35'),
(144, 235, 'tanveer', 'Teacher', 'auth.login', 'Logged in', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:23:48'),
(145, 235, 'tanveer', 'Teacher', 'auth.logout', 'Logged out', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:24:35'),
(146, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:24:38'),
(147, 4, 'admin', 'Admin', 'academic.class_teacher_updated', 'Class teacher updated', '2402:ad80:108:91c8:585d:2bff:fec3:8583', '2026-07-26 13:25:39'),
(148, 238, 'mehboob.ali.meer', 'Teacher', 'auth.login', 'Logged in', '118.107.135.201', '2026-07-26 14:31:47'),
(149, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '118.107.132.210', '2026-07-26 14:44:40'),
(150, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '118.107.132.210', '2026-07-26 14:47:25'),
(151, 20, 'Hassanad', 'Admin', 'auth.login', 'Logged in', '118.107.132.210', '2026-07-26 14:47:28'),
(152, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 14:54:43'),
(153, 20, 'Hassanad', 'Admin', 'fees.invoice_update', 'Edited fee invoice #430 (status: open)', '118.107.132.210', '2026-07-26 14:54:55'),
(154, 4, 'admin', 'Admin', 'users.update', 'Updated user account \"sabir.hussain\"', '58.65.217.235', '2026-07-26 14:55:27'),
(155, 20, 'Hassanad', 'Admin', 'fees.collect', 'Collected Rs 3,000.00 via cash for invoice #430', '118.107.132.210', '2026-07-26 14:55:52'),
(156, 4, 'admin', 'Admin', 'staff.update', 'Updated staff profile \"Sabir Hussain\" (#10)', '58.65.217.235', '2026-07-26 14:55:54'),
(157, 20, 'Hassanad', 'Admin', 'auth.logout', 'Logged out', '118.107.132.210', '2026-07-26 14:56:28'),
(158, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '118.107.132.210', '2026-07-26 14:56:32'),
(159, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 15:06:56'),
(160, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 15:07:11'),
(161, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '2404:8300:12:b15f::1', '2026-07-26 15:31:01'),
(162, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 16:57:05'),
(163, NULL, NULL, NULL, 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 18:44:58'),
(164, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 18:47:54'),
(165, 261, 'admin2', 'Admin', 'users.update', 'Updated user account \"tanveer\"', '58.65.217.235', '2026-07-26 18:48:30'),
(166, 261, 'admin2', 'Admin', 'staff.update', 'Updated staff profile \"Tanveer\" (#12)', '58.65.217.235', '2026-07-26 18:48:52'),
(167, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 18:53:07'),
(168, 235, 'tanveer', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 18:53:19'),
(169, 235, 'tanveer', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 18:54:05'),
(170, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 18:54:08'),
(171, 261, 'admin2', 'Admin', 'academic.teacher_assigned', 'Teacher assigned', '58.65.217.235', '2026-07-26 18:55:11'),
(172, 261, 'admin2', 'Admin', 'academic.teacher_assigned', 'Teacher assigned', '58.65.217.235', '2026-07-26 18:55:32'),
(173, 261, 'admin2', 'Admin', 'academic.teacher_assigned', 'Teacher assigned', '58.65.217.235', '2026-07-26 18:55:48'),
(174, 261, 'admin2', 'Admin', 'academic.teacher_assigned', 'Teacher assigned', '58.65.217.235', '2026-07-26 18:56:03'),
(175, 261, 'admin2', 'Admin', 'academic.teacher_assigned', 'Teacher assigned', '58.65.217.235', '2026-07-26 18:56:22'),
(176, 261, 'admin2', 'Admin', 'academic.teacher_assigned', 'Teacher assigned', '58.65.217.235', '2026-07-26 18:56:42'),
(177, 261, 'admin2', 'Admin', 'academic.teacher_assigned', 'Teacher assigned', '58.65.217.235', '2026-07-26 18:56:54'),
(178, 261, 'admin2', 'Admin', 'academic.teacher_assigned', 'Teacher assigned', '58.65.217.235', '2026-07-26 18:57:21'),
(179, 261, 'admin2', 'Admin', 'academic.class_teacher_updated', 'Class teacher updated', '58.65.217.235', '2026-07-26 18:57:57'),
(180, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 18:58:41'),
(181, 235, 'tanveer', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 18:58:57'),
(182, 235, 'tanveer', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 18:59:52'),
(183, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-26 20:13:34'),
(184, 261, 'admin2', 'Admin', 'fees.apply_one_time_fee', 'Applied fee category #4 to class section #1 — created 6, appended 11, skipped 0', '58.65.217.235', '2026-07-26 20:26:39'),
(185, 261, 'admin2', 'Admin', 'fees.apply_one_time_fee', 'Applied fee category #4 to class section #2 — created 3, appended 13, skipped 0', '58.65.217.235', '2026-07-26 20:28:42'),
(186, 261, 'admin2', 'Admin', 'fees.apply_one_time_fee', 'Applied fee category #4 to class section #3 — created 6, appended 11, skipped 0', '58.65.217.235', '2026-07-26 20:28:51'),
(187, 261, 'admin2', 'Admin', 'fees.apply_one_time_fee', 'Applied fee category #4 to class section #4 — created 1, appended 11, skipped 0', '58.65.217.235', '2026-07-26 20:29:02'),
(188, 261, 'admin2', 'Admin', 'fees.apply_one_time_fee', 'Applied fee category #4 to class section #5 — created 5, appended 17, skipped 0', '58.65.217.235', '2026-07-26 20:29:14'),
(189, 261, 'admin2', 'Admin', 'fees.apply_one_time_fee', 'Applied fee category #4 to class section #6 — created 6, appended 21, skipped 0', '58.65.217.235', '2026-07-26 20:29:33'),
(190, 261, 'admin2', 'Admin', 'fees.apply_one_time_fee', 'Applied fee category #4 to class section #7 — created 1, appended 12, skipped 0', '58.65.217.235', '2026-07-26 20:29:43'),
(191, 261, 'admin2', 'Admin', 'fees.apply_one_time_fee', 'Applied fee category #4 to class section #8 — created 3, appended 11, skipped 0', '58.65.217.235', '2026-07-26 20:29:56'),
(192, 261, 'admin2', 'Admin', 'fees.apply_one_time_fee', 'Applied fee category #4 to class section #9 — created 5, appended 18, skipped 0', '58.65.217.235', '2026-07-26 20:30:06'),
(193, 261, 'admin2', 'Admin', 'fees.apply_one_time_fee', 'Applied fee category #4 to class section #10 — created 3, appended 10, skipped 0', '58.65.217.235', '2026-07-26 20:30:23'),
(194, 261, 'admin2', 'Admin', 'fees.apply_one_time_fee', 'Applied fee category #4 to class section #10 — created 0, appended 0, skipped 13', '58.65.217.235', '2026-07-26 20:30:32'),
(195, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-26 20:34:00'),
(196, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-27 04:18:53'),
(197, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-27 05:02:22'),
(198, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-27 05:32:10'),
(199, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-27 05:32:27'),
(200, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-27 05:32:46'),
(201, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-27 05:32:49'),
(202, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-27 05:33:07'),
(203, 233, 'abdullah.khan', 'Principal', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-27 05:33:11'),
(204, 233, 'abdullah.khan', 'Principal', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-27 05:34:27'),
(205, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-27 05:34:30'),
(206, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '2402:e000:65a:6a9e:a8c4:f194:5afb:34de', '2026-07-27 08:28:09'),
(207, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-27 10:07:04'),
(208, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-27 10:07:22'),
(209, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-27 10:07:28'),
(210, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-27 10:49:54'),
(211, 233, 'abdullah.khan', 'Principal', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-27 10:49:57'),
(212, 233, 'abdullah.khan', 'Principal', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-27 10:50:20'),
(213, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-27 10:50:24'),
(214, 15, 'nusrat', 'Student', 'portal.leave_apply', 'Applied for Sick leave (2026-07-31 to 2026-08-01)', '103.189.232.252', '2026-07-27 10:50:58'),
(215, 15, 'nusrat', 'Student', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-27 10:51:03'),
(216, 233, 'abdullah.khan', 'Principal', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-27 10:51:06'),
(217, 233, 'abdullah.khan', 'Principal', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-27 10:51:59'),
(218, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-27 10:59:53'),
(219, 261, 'admin2', 'Admin', 'staff.update', 'Updated staff profile \"Abdullah Khan\" (#9)', '103.189.232.252', '2026-07-27 11:00:21'),
(220, 261, 'admin2', 'Admin', 'users.update', 'Updated user account \"abdullah.khan\"', '103.189.232.252', '2026-07-27 11:00:59'),
(221, 261, 'admin2', 'Admin', 'users.role_create', 'Created role \"Office Boy\"', '103.189.232.252', '2026-07-27 11:06:44'),
(222, 261, 'admin2', 'Admin', 'users.update', 'Updated user account \"kazim\"', '103.189.232.252', '2026-07-27 11:19:53'),
(223, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"\"', '103.137.26.172', '2026-07-27 12:57:03'),
(224, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-27 14:15:43'),
(225, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-27 14:19:07'),
(226, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-27 14:19:12'),
(227, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-27 17:20:19'),
(228, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-27 17:29:20'),
(229, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-27 17:29:25'),
(230, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-27 17:32:38'),
(231, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-27 17:32:43'),
(232, 15, 'nusrat', 'Student', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-27 17:33:46'),
(233, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-27 17:33:52'),
(234, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-07-27 17:39:39'),
(235, 261, 'admin2', 'Admin', 'academic.class_teacher_updated', 'Class teacher updated', '58.65.217.235', '2026-07-27 17:43:36'),
(236, 261, 'admin2', 'Admin', 'fees.apply_one_time_fee', 'Applied fee category #4 to class section #2 — created 0, appended 0, skipped 16', '58.65.217.235', '2026-07-27 17:48:21'),
(237, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-27 19:43:22'),
(238, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 04:23:14'),
(239, 261, 'admin2', 'Admin', 'fees.collect', 'Collected Rs 380.00 via cash for invoice #302', '103.189.232.252', '2026-07-28 04:24:17'),
(240, 261, 'admin2', 'Admin', 'fees.collect', 'Collected Rs 400.00 via cash for invoice #549', '103.189.232.252', '2026-07-28 04:32:45'),
(241, 261, 'admin2', 'Admin', 'fees.collect_undo', 'Removed payment #176 from invoice #549', '103.189.232.252', '2026-07-28 04:33:03'),
(242, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-28 04:33:21'),
(243, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 04:33:24'),
(244, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 380.00 via cash for invoice #511', '103.189.232.252', '2026-07-28 04:33:44'),
(245, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-28 04:59:25'),
(246, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 04:59:31'),
(247, 261, 'admin2', 'Admin', 'users.create', 'Created user account \"mudassir\"', '103.189.232.252', '2026-07-28 05:00:42'),
(248, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 05:01:32'),
(249, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 05:15:05'),
(250, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-28 05:15:29'),
(251, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 05:16:04'),
(252, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-28 05:18:24'),
(253, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 05:20:52'),
(254, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"mudassir\"', '2404:8300:13:7d60::1', '2026-07-28 06:39:48'),
(255, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"mudassir\"', '2404:8300:13:7d60::1', '2026-07-28 06:40:26'),
(256, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '2402:e000:64e:a03a:f163:f655:833a:4a00', '2026-07-28 08:43:34'),
(257, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.137.26.34', '2026-07-28 08:50:37'),
(258, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"mudassir\"', '2404:8300:13:7d60::1', '2026-07-28 10:23:27'),
(259, 262, 'mudassir', 'Admin', 'auth.login', 'Logged in', '2404:8300:13:7d60::1', '2026-07-28 10:24:29'),
(260, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 10:37:13'),
(261, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 10:41:11'),
(262, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-28 10:53:57'),
(263, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 10:53:59'),
(264, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-28 11:02:13'),
(265, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 11:02:16'),
(266, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-28 11:14:05'),
(267, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 11:14:08'),
(268, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-28 11:29:57'),
(269, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 11:29:59'),
(270, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 11:37:28'),
(271, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '118.107.142.242', '2026-07-28 11:38:18'),
(272, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '118.107.142.242', '2026-07-28 11:38:39'),
(273, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-28 11:42:32'),
(274, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 380.00 via cash for invoice #513', '118.107.142.242', '2026-07-28 11:43:26'),
(275, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 12:11:28'),
(276, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-28 12:14:41'),
(277, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Hassan\"', '103.189.232.252', '2026-07-28 12:14:55'),
(278, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Hassan\"', '103.189.232.252', '2026-07-28 12:15:19'),
(279, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 12:15:49'),
(280, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 12:17:27'),
(281, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 12:18:28'),
(282, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 12:23:50'),
(283, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-28 12:29:00'),
(284, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 12:32:27'),
(285, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 12:35:00'),
(286, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-28 12:38:47'),
(287, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Mudassir\"', '2404:8300:13:7d60::1', '2026-07-28 14:26:18'),
(288, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Mudassir\"', '2404:8300:13:7d60::1', '2026-07-28 14:27:04'),
(289, 262, 'mudassir', 'Admin', 'auth.login', 'Logged in', '2404:8300:13:7d60::1', '2026-07-28 14:27:42'),
(290, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-28 14:28:22'),
(291, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-28 14:30:21'),
(292, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-28 14:30:25'),
(293, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '2404:8300:10:33f1::1', '2026-07-28 14:30:28'),
(294, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '223.123.90.193', '2026-07-28 14:31:19'),
(295, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '223.123.90.193', '2026-07-28 14:31:31'),
(296, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '223.123.90.193', '2026-07-28 14:41:29'),
(297, 4, 'admin', 'Admin', 'fees.collect', 'Collected Rs 400.00 via cash for invoice #549', '223.123.90.193', '2026-07-28 14:45:29'),
(298, 4, 'admin', 'Admin', 'fees.collect_undo', 'Removed payment #179 from invoice #549', '223.123.90.193', '2026-07-28 14:45:40'),
(299, 4, 'admin', 'Admin', 'fees.collect', 'Collected Rs 400.00 via cash for invoice #549', '223.123.90.193', '2026-07-28 14:45:47'),
(300, 4, 'admin', 'Admin', 'fees.collect_undo', 'Removed payment #180 from invoice #549', '223.123.90.193', '2026-07-28 14:45:51'),
(301, 4, 'admin', 'Admin', 'fees.collect', 'Collected Rs 400.00 via cash for invoice #549', '223.123.90.193', '2026-07-28 14:46:09'),
(302, 4, 'admin', 'Admin', 'fees.collect_undo', 'Removed payment #181 from invoice #549', '223.123.90.193', '2026-07-28 14:46:43'),
(303, 238, 'mehboob.ali.meer', 'Teacher', 'auth.login', 'Logged in', '118.107.135.198', '2026-07-28 14:51:54'),
(304, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Hussani\"', '118.107.132.165', '2026-07-28 14:58:01'),
(305, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Hussani\"', '118.107.132.165', '2026-07-28 14:58:22'),
(306, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Hussani\"', '118.107.132.165', '2026-07-28 14:58:37'),
(307, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Hussani\"', '118.107.132.165', '2026-07-28 14:58:58'),
(308, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Hussani\"', '118.107.132.165', '2026-07-28 14:59:24'),
(309, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Hussani\"', '118.107.132.165', '2026-07-28 15:00:51'),
(310, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Hussani\"', '118.107.132.165', '2026-07-28 15:01:21'),
(311, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.132.165', '2026-07-28 15:02:56'),
(312, 7, 'Hussaini', 'Teacher', 'fees.collect', 'Collected Rs 400.00 via cash for invoice #542', '118.107.132.165', '2026-07-28 15:10:27'),
(313, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.132.165', '2026-07-28 15:17:51'),
(314, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.132.165', '2026-07-28 15:18:09'),
(315, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.132.165', '2026-07-28 15:20:56'),
(316, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.132.165', '2026-07-28 15:21:10'),
(317, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Hassan\"', '118.107.131.202', '2026-07-28 15:25:27'),
(318, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '118.107.131.202', '2026-07-28 15:26:28'),
(319, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 380.00 via cash for invoice #436', '118.107.131.202', '2026-07-28 15:39:26'),
(320, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 500.00 via cash for invoice #431', '118.107.131.202', '2026-07-28 15:44:22'),
(321, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-28 16:29:55'),
(322, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-28 16:33:56'),
(323, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-28 18:54:03'),
(324, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-28 22:23:17'),
(325, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-28 22:24:07'),
(326, 20, 'Hassanad', 'Admin', 'auth.login', 'Logged in', '103.137.26.142', '2026-07-29 02:25:49'),
(327, 20, 'Hassanad', 'Admin', 'academic.teacher_assigned', 'Teacher assigned', '103.137.26.142', '2026-07-29 02:31:00'),
(328, 20, 'Hassanad', 'Admin', 'academic.teacher_assigned', 'Teacher assigned', '103.137.26.142', '2026-07-29 02:31:31'),
(329, 238, 'mehboob.ali.meer', 'Teacher', 'auth.login', 'Logged in', '118.107.135.198', '2026-07-29 02:57:42'),
(330, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:1fd:fc49:10e9:ebff:fe5e:d5fb', '2026-07-29 03:26:43'),
(331, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 04:26:53'),
(332, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"\"', '103.189.232.252', '2026-07-29 04:26:53'),
(333, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"\"', '103.189.232.252', '2026-07-29 04:26:57'),
(334, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 04:27:01'),
(335, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-29 04:27:13'),
(336, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 04:39:35'),
(337, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 04:47:30'),
(338, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 05:15:19'),
(339, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 06:05:45'),
(340, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 06:09:16'),
(341, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 06:10:16'),
(342, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 07:20:33'),
(343, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 07:38:52'),
(344, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 07:54:29'),
(345, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 08:00:48'),
(346, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 08:02:05'),
(347, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 08:03:50'),
(348, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 08:08:59'),
(349, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 08:18:08'),
(350, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 09:08:37'),
(351, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 09:09:15'),
(352, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 09:11:21'),
(353, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-29 09:12:01'),
(354, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 09:23:37'),
(355, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 09:45:43'),
(356, 20, 'Hassanad', 'Admin', 'auth.login', 'Logged in', '118.107.131.111', '2026-07-29 10:19:54'),
(357, 20, 'Hassanad', 'Admin', 'auth.logout', 'Logged out', '118.107.131.111', '2026-07-29 10:21:40'),
(358, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '118.107.131.111', '2026-07-29 10:22:00'),
(359, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 10:42:39'),
(360, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '2404:8300:12:4d6d::1', '2026-07-29 11:04:06'),
(361, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '118.107.131.15', '2026-07-29 11:14:37'),
(362, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Mudassir\"', '2404:8300:13:7d60::1', '2026-07-29 11:22:06'),
(363, 262, 'mudassir', 'Admin', 'auth.login', 'Logged in', '2404:8300:13:7d60::1', '2026-07-29 11:22:26'),
(364, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-29 11:27:00'),
(365, 262, 'mudassir', 'Admin', 'auth.login', 'Logged in', '2404:8300:13:7d60::1', '2026-07-29 11:38:38'),
(366, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-29 14:31:05'),
(367, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '118.107.135.255', '2026-07-29 15:48:45'),
(368, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-29 15:50:27'),
(369, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 880.00 via cash for invoice #431', '118.107.135.255', '2026-07-29 15:50:46'),
(370, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 1,380.00 via cash for invoice #435', '118.107.135.255', '2026-07-29 15:52:43'),
(371, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 380.00 via cash for invoice #438', '118.107.135.255', '2026-07-29 15:54:34'),
(372, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 2,380.00 via cash for invoice #439', '118.107.135.255', '2026-07-29 15:55:16'),
(373, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 2,380.00 via cash for invoice #442', '118.107.135.255', '2026-07-29 15:56:02'),
(374, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 380.00 via cash for invoice #440', '118.107.135.255', '2026-07-29 15:56:55'),
(375, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 380.00 via cash for invoice #514', '118.107.135.255', '2026-07-29 15:58:00'),
(376, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-29 16:34:19'),
(377, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-29 16:34:50'),
(378, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-29 16:56:20'),
(379, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-29 16:56:35'),
(380, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-29 16:57:36'),
(381, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-29 17:34:45'),
(382, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-29 17:47:30'),
(383, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-30 04:58:16'),
(384, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Hussani\"', '118.107.135.22', '2026-07-30 06:02:19'),
(385, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Hussani\"', '118.107.135.22', '2026-07-30 06:02:40'),
(386, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Hussani\"', '118.107.135.22', '2026-07-30 06:02:51'),
(387, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Hussani\"', '118.107.135.22', '2026-07-30 06:03:42'),
(388, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.135.22', '2026-07-30 06:04:06'),
(389, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.135.22', '2026-07-30 06:07:32'),
(390, 21, 'G.Abbas', 'Teacher', 'auth.login', 'Logged in', '118.107.131.97', '2026-07-30 06:36:14'),
(391, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-30 06:39:13'),
(392, 261, 'admin2', 'Admin', 'settings.notifications_update', 'Updated mail/SMS notification settings', '103.189.232.252', '2026-07-30 06:41:12'),
(393, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-30 06:41:16'),
(394, NULL, NULL, NULL, 'auth.password_reset_request', 'Requested a password reset for \"admin2\"', '103.189.232.252', '2026-07-30 06:41:27'),
(395, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-30 06:42:30'),
(396, 261, 'admin2', 'Admin', 'settings.notifications_update', 'Updated mail/SMS notification settings', '103.189.232.252', '2026-07-30 06:42:52'),
(397, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-30 06:42:57'),
(398, NULL, NULL, NULL, 'auth.password_reset_request', 'Requested a password reset for \"admin2\"', '103.189.232.252', '2026-07-30 06:43:06'),
(399, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-30 06:43:50'),
(400, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-30 06:43:50'),
(401, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-30 06:44:42'),
(402, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Admin2\"', '2402:ad80:f5:d105:1:0:9957:760d', '2026-07-30 06:45:56'),
(403, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '2402:ad80:f5:d105:1:0:9957:760d', '2026-07-30 06:46:34'),
(404, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-30 07:08:36'),
(405, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"mehboob.ali.meer\"', '118.107.135.49', '2026-07-30 07:43:57'),
(406, 238, 'mehboob.ali.meer', 'Teacher', 'auth.login', 'Logged in', '118.107.135.49', '2026-07-30 07:44:37'),
(407, 238, 'mehboob.ali.meer', 'Teacher', 'auth.logout', 'Logged out', '118.107.135.49', '2026-07-30 07:47:06'),
(408, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-30 08:47:35'),
(409, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-30 08:48:35'),
(410, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-30 08:48:41'),
(411, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"\"', '103.137.26.70', '2026-07-30 11:01:01'),
(412, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 14:17:28'),
(413, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 14:18:58'),
(414, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 16:37:35'),
(415, 4, 'admin', 'Admin', 'students.update', 'Updated student \"Maryam Batool\" (#808)', '58.65.217.235', '2026-07-30 17:12:14'),
(416, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.131.78', '2026-07-30 17:27:59'),
(417, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.131.78', '2026-07-30 17:35:52'),
(418, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.131.78', '2026-07-30 17:42:37'),
(419, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 17:42:39'),
(420, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.131.78', '2026-07-30 17:43:07'),
(421, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.131.78', '2026-07-30 17:47:20'),
(422, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.131.78', '2026-07-30 17:53:20'),
(423, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.131.78', '2026-07-30 17:58:53'),
(424, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.131.78', '2026-07-30 18:02:53'),
(425, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.131.78', '2026-07-30 18:02:58'),
(426, 4, 'admin', 'Admin', 'academic.write', 'Exam created.', '58.65.217.235', '2026-07-30 18:11:51'),
(427, 4, 'admin', 'Admin', 'academic.date_sheet_saved', 'Date sheet saved', '58.65.217.235', '2026-07-30 18:12:44'),
(428, 4, 'admin', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-07-30 18:13:12'),
(429, 4, 'admin', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-07-30 18:13:22'),
(430, 4, 'admin', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-07-30 18:13:33'),
(431, 4, 'admin', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-07-30 18:13:47'),
(432, 4, 'admin', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-07-30 18:13:57'),
(433, 4, 'admin', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-07-30 18:14:11'),
(434, 4, 'admin', 'Admin', 'academic.write', 'Results published — students and parents can now see them.', '58.65.217.235', '2026-07-30 18:14:36');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `role_name`, `action`, `description`, `ip_address`, `created_at`) VALUES
(435, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-30 18:14:45'),
(436, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 18:14:49'),
(437, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 18:34:27'),
(438, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.131.13', '2026-07-30 18:39:50'),
(439, 261, 'admin2', 'Admin', 'students.update', 'Updated student \"Ishrat Abdullah\" (#760)', '58.65.217.235', '2026-07-30 18:41:27'),
(440, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-30 18:41:43'),
(441, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 18:41:52'),
(442, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-30 18:41:58'),
(443, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 18:42:02'),
(444, 7, 'Hussaini', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-30 18:42:30'),
(445, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 18:42:35'),
(446, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-30 18:43:03'),
(447, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 19:06:52'),
(448, 15, 'nusrat', 'Student', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-30 19:07:13'),
(449, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 19:07:21'),
(450, 261, 'admin2', 'Admin', 'academic.write', 'Results hidden from students and parents again.', '58.65.217.235', '2026-07-30 19:07:59'),
(451, 261, 'admin2', 'Admin', 'academic.write', 'Results published — students and parents can now see them.', '58.65.217.235', '2026-07-30 19:08:05'),
(452, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-30 19:08:16'),
(453, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 19:08:24'),
(454, 15, 'nusrat', 'Student', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-30 19:09:00'),
(455, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 19:09:11'),
(456, 261, 'admin2', 'Admin', 'academic.write', 'Exam deleted', '58.65.217.235', '2026-07-30 19:10:33'),
(457, 261, 'admin2', 'Admin', 'academic.write', 'Exam created.', '58.65.217.235', '2026-07-30 19:10:59'),
(458, 261, 'admin2', 'Admin', 'academic.write', 'Results published — students and parents can now see them.', '58.65.217.235', '2026-07-30 19:11:20'),
(459, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.131.13', '2026-07-30 19:11:26'),
(460, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-30 19:11:26'),
(461, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 19:11:32'),
(462, 15, 'nusrat', 'Student', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-30 19:11:46'),
(463, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 19:11:50'),
(464, 261, 'admin2', 'Admin', 'academic.write', 'Results hidden from students and parents again.', '58.65.217.235', '2026-07-30 19:12:15'),
(465, 261, 'admin2', 'Admin', 'academic.date_sheet_saved', 'Date sheet saved', '58.65.217.235', '2026-07-30 19:13:07'),
(466, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-07-30 19:13:28'),
(467, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-07-30 19:13:36'),
(468, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-07-30 19:13:45'),
(469, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-07-30 19:13:52'),
(470, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-07-30 19:14:04'),
(471, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-07-30 19:14:11'),
(472, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-30 19:16:39'),
(473, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 19:16:44'),
(474, 15, 'nusrat', 'Student', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-30 19:17:02'),
(475, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 19:17:08'),
(476, 261, 'admin2', 'Admin', 'academic.write', 'Results published — students and parents can now see them.', '58.65.217.235', '2026-07-30 19:17:21'),
(477, 7, 'Hussaini', 'Teacher', 'fees.collect', 'Collected Rs 1,590.00 via cash for invoice #332', '118.107.131.13', '2026-07-30 19:17:23'),
(478, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-30 19:17:27'),
(479, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-30 19:17:32'),
(480, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-31 03:05:02'),
(481, 15, 'nusrat', 'Student', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-31 03:07:03'),
(482, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-31 03:17:40'),
(483, 15, 'nusrat', 'Student', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-31 03:19:15'),
(484, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-31 03:19:20'),
(485, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-07-31 03:19:37'),
(486, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-31 03:19:41'),
(487, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-31 03:19:46'),
(488, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.131.85', '2026-07-31 03:37:35'),
(489, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.131.85', '2026-07-31 03:40:04'),
(490, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.131.85', '2026-07-31 03:44:24'),
(491, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 04:32:37'),
(492, 15, 'nusrat', 'Student', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 04:33:07'),
(493, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 04:33:11'),
(494, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '118.107.131.176', '2026-07-31 04:41:04'),
(495, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 1,880.00 via cash for invoice #510', '118.107.131.176', '2026-07-31 04:42:09'),
(496, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 1,000.00 via cash for invoice #436', '118.107.131.176', '2026-07-31 04:43:49'),
(497, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 3,380.00 via cash for invoice #437', '118.107.131.176', '2026-07-31 04:45:17'),
(498, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 1,000.00 via cash for invoice #437', '118.107.131.176', '2026-07-31 04:45:45'),
(499, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 3,000.00 via cash for invoice #438', '118.107.131.176', '2026-07-31 04:46:26'),
(500, 6, 'Hassan', 'Teacher', 'fees.collect', 'Collected Rs 380.00 via cash for invoice #516', '118.107.131.176', '2026-07-31 04:47:20'),
(501, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 05:35:13'),
(502, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 05:46:29'),
(503, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 05:46:36'),
(504, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 05:47:05'),
(505, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 05:47:10'),
(506, 7, 'Hussaini', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 05:47:19'),
(507, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 05:47:22'),
(508, 261, 'admin2', 'Admin', 'users.permissions_update', 'Updated permissions for role \"Teacher\" (2 permission(s) granted)', '103.189.232.252', '2026-07-31 05:48:10'),
(509, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 05:48:13'),
(510, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 05:48:16'),
(511, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 05:48:58'),
(512, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 05:49:02'),
(513, 261, 'admin2', 'Admin', 'users.permissions_update', 'Updated permissions for role \"Teacher\" (3 permission(s) granted)', '103.189.232.252', '2026-07-31 05:49:17'),
(514, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 05:49:23'),
(515, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 05:53:08'),
(516, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 05:58:05'),
(517, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 05:58:10'),
(518, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"\"', '103.189.232.252', '2026-07-31 05:58:10'),
(519, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 05:58:16'),
(520, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 06:00:25'),
(521, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 06:00:31'),
(522, 15, 'nusrat', 'Student', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 06:06:47'),
(523, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 06:06:51'),
(524, 261, 'admin2', 'Admin', 'students.update', 'Updated student \"Irfan Ali Mubarak\" (#651)', '103.189.232.252', '2026-07-31 06:08:42'),
(525, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 06:34:12'),
(526, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 06:34:14'),
(527, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 06:34:37'),
(528, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 06:34:39'),
(529, 233, 'abdullah.khan', 'Principal', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 06:52:46'),
(530, 233, 'abdullah.khan', 'Principal', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 06:55:10'),
(531, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 07:43:51'),
(532, 4, 'admin', 'Admin', 'users.permissions_update', 'Updated permissions for role \"Teacher\" (5 permission(s) granted)', '103.189.232.252', '2026-07-31 07:45:57'),
(533, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 07:46:01'),
(534, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 07:46:12'),
(535, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 07:47:02'),
(536, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 08:38:33'),
(537, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 08:56:31'),
(538, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 08:56:34'),
(539, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 08:58:34'),
(540, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 08:58:38'),
(541, 261, 'admin2', 'Admin', 'users.update', 'Updated user account \"Muez\"', '103.189.232.252', '2026-07-31 09:00:14'),
(542, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 09:00:18'),
(543, 28, 'Muez', 'Student', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 09:00:27'),
(544, 28, 'Muez', 'Student', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 09:00:27'),
(545, 28, 'Muez', 'Student', 'portal.leave_apply', 'Applied for Sick leave (2026-08-02 to 2026-08-04)', '103.189.232.252', '2026-07-31 09:01:08'),
(546, 28, 'Muez', 'Student', 'portal.leave_apply', 'Applied for Sick leave (2026-09-14 to 2026-09-17)', '103.189.232.252', '2026-07-31 09:01:38'),
(547, 28, 'Muez', 'Student', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 09:01:42'),
(548, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 09:01:46'),
(549, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 09:02:08'),
(550, 28, 'Muez', 'Student', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 09:02:12'),
(551, 28, 'Muez', 'Student', 'portal.leave_apply', 'Applied for Sick leave (2026-08-11 to 2026-08-12)', '103.189.232.252', '2026-07-31 09:02:27'),
(552, 28, 'Muez', 'Student', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 09:02:30'),
(553, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 09:02:34'),
(554, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-07-31 09:09:52'),
(555, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.135.112', '2026-07-31 09:24:31'),
(556, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 09:31:22'),
(557, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '103.189.232.252', '2026-07-31 09:33:31'),
(558, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '103.189.232.252', '2026-07-31 09:42:44'),
(559, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '103.189.232.252', '2026-07-31 09:42:52'),
(560, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-07-31 11:40:17'),
(561, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '103.189.232.252', '2026-07-31 11:45:35'),
(562, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '103.189.232.252', '2026-07-31 11:45:44'),
(563, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '103.189.232.252', '2026-07-31 11:46:19'),
(564, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '103.189.232.252', '2026-07-31 11:46:45'),
(565, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '103.189.232.252', '2026-07-31 11:48:02'),
(566, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '103.189.232.252', '2026-07-31 11:48:31'),
(567, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '103.189.232.252', '2026-07-31 11:49:15'),
(568, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.132.230', '2026-07-31 15:25:28'),
(569, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-31 16:21:04'),
(570, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-07-31 16:23:50'),
(571, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-07-31 18:17:20'),
(572, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-01 05:19:36'),
(573, 4, 'admin', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 05:21:38'),
(574, 4, 'admin', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 05:22:32'),
(575, 4, 'admin', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 05:23:17'),
(576, 4, 'admin', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 05:24:06'),
(577, 4, 'admin', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 05:25:02'),
(578, 4, 'admin', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 05:25:27'),
(579, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.142.138', '2026-08-01 06:31:53'),
(580, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-01 07:13:08'),
(581, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:20:58'),
(582, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:21:34'),
(583, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:21:57'),
(584, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:22:47'),
(585, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:27:06'),
(586, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:27:33'),
(587, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:28:12'),
(588, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:28:28'),
(589, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:28:43'),
(590, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:29:02'),
(591, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:29:25'),
(592, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:35:59'),
(593, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:36:16'),
(594, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:36:29'),
(595, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:36:45'),
(596, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:36:59'),
(597, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:37:12'),
(598, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 07:37:54'),
(599, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-01 08:24:53'),
(600, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:25:46'),
(601, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:26:15'),
(602, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:26:33'),
(603, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:26:56'),
(604, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:27:12'),
(605, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:27:22'),
(606, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:27:41'),
(607, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:27:56'),
(608, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:28:17'),
(609, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:28:34'),
(610, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:28:57'),
(611, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:29:10'),
(612, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:37:03'),
(613, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:37:21'),
(614, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:37:40'),
(615, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:37:58'),
(616, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:38:09'),
(617, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:38:24'),
(618, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:38:42'),
(619, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:38:57'),
(620, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:39:13'),
(621, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:39:24'),
(622, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:39:37'),
(623, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:39:53'),
(624, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:40:04'),
(625, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:40:12'),
(626, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:40:22'),
(627, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:40:29'),
(628, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:40:49'),
(629, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:40:59'),
(630, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:41:27'),
(631, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:41:43'),
(632, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:41:54'),
(633, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:42:03'),
(634, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:42:12'),
(635, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:42:27'),
(636, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:42:36'),
(637, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:42:51'),
(638, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:43:01'),
(639, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:43:19'),
(640, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:43:32'),
(641, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:43:50'),
(642, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:44:06'),
(643, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:44:18'),
(644, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:44:33'),
(645, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:44:47'),
(646, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:44:59'),
(647, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:45:18'),
(648, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:45:36'),
(649, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:45:51'),
(650, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:46:02'),
(651, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:46:08'),
(652, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 08:46:35'),
(653, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-01 09:03:49'),
(654, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry added', '58.65.217.235', '2026-08-01 09:07:56'),
(655, 261, 'admin2', 'Admin', 'academic.timetable_entry_deleted', 'Timetable entry deleted', '58.65.217.235', '2026-08-01 09:08:01'),
(656, 261, 'admin2', 'Admin', 'academic.teacher_unassigned', 'Teacher unassigned', '58.65.217.235', '2026-08-01 09:16:17'),
(657, 261, 'admin2', 'Admin', 'academic.teacher_assigned', 'Teacher assigned', '58.65.217.235', '2026-08-01 09:16:35'),
(658, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:17:11'),
(659, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:17:18'),
(660, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:17:25'),
(661, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:17:32'),
(662, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:17:38'),
(663, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:17:44'),
(664, 261, 'admin2', 'Admin', 'academic.timetable_entry_deleted', 'Timetable entry deleted', '58.65.217.235', '2026-08-01 09:18:28'),
(665, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:18:52'),
(666, 261, 'admin2', 'Admin', 'academic.timetable_entry_deleted', 'Timetable entry deleted', '58.65.217.235', '2026-08-01 09:19:57'),
(667, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:24:18'),
(668, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:24:49'),
(669, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:25:53'),
(670, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:26:25'),
(671, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:26:40'),
(672, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:26:48'),
(673, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:26:55'),
(674, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:27:01'),
(675, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:27:12'),
(676, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:27:52'),
(677, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:27:59'),
(678, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:28:05'),
(679, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:28:11'),
(680, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:28:17'),
(681, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:28:23'),
(682, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:28:40'),
(683, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:29:16'),
(684, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:29:41'),
(685, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:30:02'),
(686, 261, 'admin2', 'Admin', 'academic.write', 'Timetable entry updated', '58.65.217.235', '2026-08-01 09:30:07'),
(687, 261, 'admin2', 'Admin', 'academic.subject_created', 'Subject created', '58.65.217.235', '2026-08-01 09:32:35'),
(688, 261, 'admin2', 'Admin', 'academic.subject_created', 'Subject created', '58.65.217.235', '2026-08-01 09:33:16'),
(689, 261, 'admin2', 'Admin', 'academic.subject_created', 'Subject created', '58.65.217.235', '2026-08-01 09:34:15'),
(690, 261, 'admin2', 'Admin', 'academic.subject_created', 'Subject created', '58.65.217.235', '2026-08-01 09:35:14'),
(691, 261, 'admin2', 'Admin', 'academic.subject_updated', 'Subject updated', '58.65.217.235', '2026-08-01 09:35:25'),
(692, 261, 'admin2', 'Admin', 'academic.subject_created', 'Subject created', '58.65.217.235', '2026-08-01 09:35:48'),
(693, 261, 'admin2', 'Admin', 'academic.subject_created', 'Subject created', '58.65.217.235', '2026-08-01 09:36:54'),
(694, 261, 'admin2', 'Admin', 'academic.subject_created', 'Subject created', '58.65.217.235', '2026-08-01 09:38:26'),
(695, 261, 'admin2', 'Admin', 'academic.subject_created', 'Subject created', '58.65.217.235', '2026-08-01 09:40:16'),
(696, 261, 'admin2', 'Admin', 'academic.subject_created', 'Subject created', '58.65.217.235', '2026-08-01 09:40:55'),
(697, 261, 'admin2', 'Admin', 'academic.subject_created', 'Subject created', '58.65.217.235', '2026-08-01 09:46:41'),
(698, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-01 11:56:56'),
(699, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-01 12:04:52'),
(700, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-08-01 12:09:35'),
(701, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.137.26.134', '2026-08-01 12:32:14'),
(702, 20, 'Hassanad', 'Admin', 'auth.login', 'Logged in', '103.137.26.134', '2026-08-01 12:33:52'),
(703, 261, 'admin2', 'Admin', 'academic.exam_group_created', 'Exam group created', '58.65.217.235', '2026-08-01 12:37:09'),
(704, 261, 'admin2', 'Admin', 'academic.write', 'Exam created.', '58.65.217.235', '2026-08-01 12:38:13'),
(705, 261, 'admin2', 'Admin', 'academic.exam_updated', 'Exam updated', '58.65.217.235', '2026-08-01 12:38:29'),
(706, 261, 'admin2', 'Admin', 'academic.date_sheet_saved', 'Date sheet saved', '58.65.217.235', '2026-08-01 12:39:17'),
(707, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-08-01 12:39:53'),
(708, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-08-01 12:40:02'),
(709, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-08-01 12:40:36'),
(710, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-08-01 12:40:46'),
(711, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-08-01 12:40:56'),
(712, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-08-01 12:41:08'),
(713, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-08-01 12:41:36'),
(714, 261, 'admin2', 'Admin', 'students.update', 'Updated student \"Tajwar Shareef\" (#643)', '58.65.217.235', '2026-08-01 12:58:30'),
(715, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-08-01 12:59:01'),
(716, 261, 'admin2', 'Admin', 'students.bulk_delete', 'Bulk-deleted 1 student(s)', '58.65.217.235', '2026-08-01 13:03:34'),
(717, 261, 'admin2', 'Admin', 'students.update', 'Updated student \"Tajwar Shareef\" (#643)', '58.65.217.235', '2026-08-01 13:04:32'),
(718, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-08-01 13:07:39'),
(719, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-08-01 13:09:54'),
(720, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-08-01 13:10:34'),
(721, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-08-01 13:11:36'),
(722, 261, 'admin2', 'Admin', 'academic.marks_saved', 'Marks saved', '58.65.217.235', '2026-08-01 13:12:57'),
(723, 261, 'admin2', 'Admin', 'academic.write', 'Results published — students and parents can now see them.', '58.65.217.235', '2026-08-01 13:40:52'),
(724, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-08-01 13:40:59'),
(725, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-01 13:41:05'),
(726, 15, 'nusrat', 'Student', 'auth.logout', 'Logged out', '58.65.217.235', '2026-08-01 13:49:38'),
(727, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-01 13:49:44'),
(728, 262, 'mudassir', 'Admin', 'auth.login', 'Logged in', '2404:8300:12:b4f::1', '2026-08-01 15:08:59'),
(729, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-01 15:10:30'),
(730, 261, 'admin2', 'Admin', 'academic.course_deleted', 'Course deleted', '58.65.217.235', '2026-08-01 15:10:39'),
(731, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-01 15:41:43'),
(732, 261, 'admin2', 'Admin', 'academic.exam_updated', 'Exam updated', '58.65.217.235', '2026-08-01 15:45:54'),
(733, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-08-01 15:46:47'),
(734, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-01 15:46:53'),
(735, 15, 'nusrat', 'Student', 'auth.logout', 'Logged out', '58.65.217.235', '2026-08-01 15:51:50'),
(736, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-01 15:51:55'),
(737, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '118.107.131.230', '2026-08-01 15:59:20'),
(738, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-08-01 16:06:37'),
(739, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-01 16:06:43'),
(740, 15, 'nusrat', 'Student', 'auth.logout', 'Logged out', '58.65.217.235', '2026-08-01 16:15:27'),
(741, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-01 16:15:34'),
(742, 261, 'admin2', 'Admin', 'academic.write', 'Exam created.', '58.65.217.235', '2026-08-01 16:32:42'),
(743, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:f4:cd43:7878:69ff:fe0b:865d', '2026-08-02 03:55:44'),
(744, 262, 'mudassir', 'Admin', 'auth.login', 'Logged in', '2404:8300:12:b4f::1', '2026-08-02 05:48:22'),
(745, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-02 08:34:47'),
(746, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '58.65.217.235', '2026-08-02 08:37:47'),
(747, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-02 08:38:10'),
(748, 7, 'Hussaini', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-08-02 08:44:47'),
(749, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-02 08:44:53'),
(750, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '58.65.217.235', '2026-08-02 08:55:29'),
(751, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-02 08:57:20'),
(752, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-02 10:26:24'),
(753, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:f5:d880:b097:53ff:fec4:44af', '2026-08-02 12:41:40'),
(754, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.131.100', '2026-08-02 16:14:58'),
(755, 4, 'admin', 'Admin', 'attendance.mark', 'Marked attendance for class 1 on 2026-08-03 (mobile app)', '103.189.232.252', '2026-08-03 04:50:40'),
(756, 4, 'admin', 'Admin', 'attendance.mark', 'Marked attendance for class 1 on 2026-08-01 (mobile app)', '103.189.232.252', '2026-08-03 04:50:52'),
(757, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-03 05:46:27'),
(758, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-03 08:31:28'),
(759, 7, 'Hussaini', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-03 08:33:05'),
(760, 233, 'abdullah.khan', 'Principal', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-03 08:33:18'),
(761, 233, 'abdullah.khan', 'Principal', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-03 08:33:49'),
(762, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:1f6:1ae5:852:7aff:fe5a:6800', '2026-08-03 08:47:00'),
(763, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '2402:ad80:1f6:1ae5:852:7aff:fe5a:6800', '2026-08-03 08:47:31'),
(764, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-03 14:26:36'),
(765, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-04 03:41:18'),
(766, 4, 'admin', 'Admin', 'users.update', 'Updated user account \"sajid.ali\"', '58.65.217.235', '2026-08-04 03:42:46'),
(767, 4, 'admin', 'Admin', 'fees.invoice_delete', 'Deleted fee invoice #548', '58.65.217.235', '2026-08-04 03:44:18'),
(768, 4, 'admin', 'Admin', 'staff.update', 'Updated staff profile \"Sajid Ali\" (#13)', '58.65.217.235', '2026-08-04 03:50:19'),
(769, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-04 04:26:39'),
(770, 261, 'admin2', 'Admin', 'staff.update', 'Updated staff profile \"Abdullah Khan\" (#9)', '103.189.232.252', '2026-08-04 04:27:19'),
(771, 261, 'admin2', 'Admin', 'staff.update', 'Updated staff profile \"Fida Hussain\" (#11)', '103.189.232.252', '2026-08-04 04:27:44'),
(772, 261, 'admin2', 'Admin', 'staff.update', 'Updated staff profile \"Ghulam Abbas\" (#8)', '103.189.232.252', '2026-08-04 04:28:22'),
(773, 261, 'admin2', 'Admin', 'staff.update', 'Updated staff profile \"Mehboob Ali Meer\" (#17)', '103.189.232.252', '2026-08-04 04:28:41'),
(774, 261, 'admin2', 'Admin', 'staff.update', 'Updated staff profile \"Muhammad Hassan\" (#7)', '103.189.232.252', '2026-08-04 04:29:02'),
(775, 261, 'admin2', 'Admin', 'staff.update', 'Updated staff profile \"Qasim Naseem\" (#18)', '103.189.232.252', '2026-08-04 04:29:22'),
(776, 261, 'admin2', 'Admin', 'staff.update', 'Updated staff profile \"Sabir Hussain\" (#10)', '103.189.232.252', '2026-08-04 04:29:44'),
(777, 261, 'admin2', 'Admin', 'staff.update', 'Updated staff profile \"Tanveer\" (#12)', '103.189.232.252', '2026-08-04 04:30:06'),
(778, 261, 'admin2', 'Admin', 'staff.update', 'Updated staff profile \"WAZIR NASRULLAH\" (#19)', '103.189.232.252', '2026-08-04 04:30:27'),
(779, 261, 'admin2', 'Admin', 'staff.update', 'Updated staff profile \"Admin\" (#20)', '103.189.232.252', '2026-08-04 04:31:17'),
(780, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-04 04:32:16'),
(781, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-04 04:32:20'),
(782, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:66:ae1b:143a:1fff:fefc:20a2', '2026-08-04 08:22:48'),
(783, 28, 'Muez', 'Student', 'auth.login', 'Logged in', '2402:ad80:66:ae1b:143a:1fff:fefc:20a2', '2026-08-04 08:42:20'),
(784, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-04 10:33:28'),
(785, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-04 11:29:08'),
(786, 236, 'sajid.ali', 'Teacher', 'auth.login', 'Logged in', '2404:8300:12:bc79::1', '2026-08-05 08:31:00'),
(787, 236, 'sajid.ali', 'Teacher', 'auth.login', 'Logged in', '2404:8300:10:3684::1', '2026-08-05 10:48:34'),
(788, 236, 'sajid.ali', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:3684::1', '2026-08-05 10:51:23'),
(789, 236, 'sajid.ali', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:3684::1', '2026-08-05 10:52:20'),
(790, 236, 'sajid.ali', 'Teacher', 'auth.login', 'Logged in', '2404:8300:10:3684::1', '2026-08-05 11:07:38'),
(791, 236, 'sajid.ali', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:3684::1', '2026-08-05 11:14:12'),
(792, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.141.208', '2026-08-05 11:41:13'),
(793, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-05 11:59:25'),
(794, 4, 'admin', 'Admin', 'academic.exam_type_created', 'Exam type created', '103.189.232.252', '2026-08-05 12:00:08'),
(795, 4, 'admin', 'Admin', 'academic.exam_group_created', 'Exam group created', '103.189.232.252', '2026-08-05 12:01:34'),
(796, 4, 'admin', 'Admin', 'academic.write', 'Exam created for 2 classes.', '103.189.232.252', '2026-08-05 12:03:32'),
(797, 4, 'admin', 'Admin', 'academic.date_sheet_saved', 'Date sheet saved', '103.189.232.252', '2026-08-05 12:04:25'),
(798, 4, 'admin', 'Admin', 'academic.date_sheet_saved', 'Date sheet saved', '103.189.232.252', '2026-08-05 12:04:44'),
(799, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-05 12:05:10'),
(800, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-05 12:05:14'),
(801, 7, 'Hussaini', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-05 12:07:43'),
(802, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-05 12:07:48'),
(803, 4, 'admin', 'Admin', 'academic.exam_updated', 'Exam updated', '103.189.232.252', '2026-08-05 12:11:12'),
(804, 4, 'admin', 'Admin', 'academic.exam_updated', 'Exam updated', '103.189.232.252', '2026-08-05 12:11:23'),
(805, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-05 12:11:33'),
(806, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-05 12:11:38'),
(807, 7, 'Hussaini', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-05 12:12:02'),
(808, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-05 12:12:06'),
(809, 4, 'admin', 'Admin', 'academic.write', 'Exam deleted', '103.189.232.252', '2026-08-05 12:12:27'),
(810, 4, 'admin', 'Admin', 'academic.write', 'Exam deleted', '103.189.232.252', '2026-08-05 12:12:30'),
(811, 236, 'sajid.ali', 'Teacher', 'auth.login', 'Logged in', '2404:8300:10:3684::1', '2026-08-05 13:43:20'),
(812, 236, 'sajid.ali', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:3684::1', '2026-08-05 13:51:29'),
(813, 236, 'sajid.ali', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:3684::1', '2026-08-05 13:56:18'),
(814, 236, 'sajid.ali', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:3684::1', '2026-08-05 13:56:24'),
(815, 236, 'sajid.ali', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:3684::1', '2026-08-05 14:03:36'),
(816, 236, 'sajid.ali', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:3684::1', '2026-08-05 14:18:42'),
(817, 236, 'sajid.ali', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:3684::1', '2026-08-05 14:23:28'),
(818, 21, 'G.Abbas', 'Teacher', 'auth.login', 'Logged in', '103.137.26.39', '2026-08-05 14:32:10'),
(819, 21, 'G.Abbas', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.39', '2026-08-05 14:41:11'),
(820, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 15:04:21'),
(821, 4, 'admin', 'Admin', 'academic.write', 'Exam created for 2 classes.', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 15:29:40'),
(822, 4, 'admin', 'Admin', 'academic.date_sheet_saved', 'Date sheet saved', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 15:30:58'),
(823, 4, 'admin', 'Admin', 'academic.date_sheet_saved', 'Date sheet saved', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 15:31:11'),
(824, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 15:31:23'),
(825, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 15:31:37'),
(826, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 15:32:32'),
(827, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 15:33:03'),
(828, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 15:33:23'),
(829, 7, 'Hussaini', 'Teacher', 'auth.logout', 'Logged out', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 15:33:51'),
(830, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 15:34:03'),
(831, 4, 'admin', 'Admin', 'academic.exam_updated', 'Exam updated', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 15:35:59'),
(832, 4, 'admin', 'Admin', 'academic.exam_updated', 'Exam updated', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 15:36:08'),
(833, 4, 'admin', 'Admin', 'academic.exam_updated', 'Exam updated', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 15:36:16'),
(834, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '103.137.26.94', '2026-08-05 15:46:46'),
(835, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.94', '2026-08-05 15:51:04'),
(836, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.94', '2026-08-05 15:51:13'),
(837, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.94', '2026-08-05 15:54:38'),
(838, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.94', '2026-08-05 15:54:46'),
(839, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.94', '2026-08-05 15:59:55'),
(840, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.94', '2026-08-05 16:02:03'),
(841, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.94', '2026-08-05 16:02:08'),
(842, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.94', '2026-08-05 16:02:14'),
(843, 236, 'sajid.ali', 'Teacher', 'auth.login', 'Logged in', '2404:8300:10:e439::1', '2026-08-05 16:11:19'),
(844, 236, 'sajid.ali', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:e439::1', '2026-08-05 16:17:14'),
(845, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 16:23:29'),
(846, 4, 'admin', 'Admin', 'students.update', 'Updated student \"Tasneem Zehra\" (#759)', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 16:24:07'),
(847, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 16:37:37'),
(848, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:fd:e275:706b:abff:fee6:4db0', '2026-08-05 16:37:52'),
(849, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-05 18:43:29'),
(850, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-06 06:51:39'),
(851, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-06 07:39:52'),
(852, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-06 10:07:02'),
(853, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-06 10:07:23'),
(854, 15, 'nusrat', 'Student', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-06 10:07:30'),
(855, 15, 'nusrat', 'Student', 'portal.leave_apply', 'Applied for Sick leave (2026-08-07 to 2026-08-07)', '103.189.232.252', '2026-08-06 10:07:54'),
(856, 15, 'nusrat', 'Student', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-06 10:08:02'),
(857, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-06 10:08:13'),
(858, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-06 10:09:54'),
(859, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-06 10:09:59'),
(860, 4, 'admin', 'Admin', 'students.update', 'Updated student \"NUSRAT HASSAN\" (#793)', '103.189.232.252', '2026-08-06 10:31:24'),
(861, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-06 11:24:40'),
(862, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-06 11:47:36'),
(863, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-06 12:02:05'),
(864, 7, 'Hussaini', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-06 12:03:10'),
(865, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-06 12:03:32'),
(866, 4, 'admin', 'Admin', 'students.update', 'Updated student \"NUSRAT HASSAN\" (#793)', '103.189.232.252', '2026-08-06 12:06:19'),
(867, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-06 12:37:06'),
(868, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-06 12:54:14'),
(869, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '223.123.88.7', '2026-08-06 18:25:32'),
(870, 238, 'mehboob.ali.meer', 'Teacher', 'auth.login', 'Logged in', '118.107.135.66', '2026-08-07 03:54:10'),
(871, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-07 04:35:41'),
(872, 21, 'G.Abbas', 'Teacher', 'auth.login', 'Logged in', '103.137.26.63', '2026-08-07 06:28:24'),
(873, 21, 'G.Abbas', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.63', '2026-08-07 06:40:44'),
(874, 21, 'G.Abbas', 'Teacher', 'auth.login', 'Logged in', '103.137.26.63', '2026-08-07 06:42:31'),
(875, 21, 'G.Abbas', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.63', '2026-08-07 06:50:39'),
(876, 21, 'G.Abbas', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.63', '2026-08-07 06:54:07'),
(877, 21, 'G.Abbas', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.63', '2026-08-07 06:58:53'),
(878, 21, 'G.Abbas', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.63', '2026-08-07 07:03:30'),
(879, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-07 10:41:10'),
(880, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-07 11:42:59'),
(881, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.135.192', '2026-08-07 11:54:04'),
(882, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.137.26.65', '2026-08-07 13:52:10'),
(883, 6, 'Hassan', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.65', '2026-08-07 13:57:06');
INSERT INTO `activity_log` (`id`, `user_id`, `username`, `role_name`, `action`, `description`, `ip_address`, `created_at`) VALUES
(884, 6, 'Hassan', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.65', '2026-08-07 14:04:47'),
(885, 6, 'Hassan', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.65', '2026-08-07 14:05:04'),
(886, 6, 'Hassan', 'Teacher', 'academic.marks_saved', 'Marks saved', '103.137.26.65', '2026-08-07 14:13:06'),
(887, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-07 15:23:31'),
(888, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '118.107.141.47', '2026-08-07 16:21:26'),
(889, 6, 'Hassan', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.141.47', '2026-08-07 16:30:43'),
(890, 6, 'Hassan', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.141.47', '2026-08-07 16:31:00'),
(891, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.135.139', '2026-08-08 14:55:45'),
(892, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.135.139', '2026-08-08 15:28:09'),
(893, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.135.139', '2026-08-08 15:28:20'),
(894, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.135.139', '2026-08-08 15:28:28'),
(895, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.135.139', '2026-08-08 15:29:05'),
(896, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.135.139', '2026-08-08 15:29:10'),
(897, 7, 'Hussaini', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.135.139', '2026-08-08 15:29:23'),
(898, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:1ff:80ef:acd1:8cff:fe30:de74', '2026-08-08 15:35:34'),
(899, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.141.35', '2026-08-08 17:25:54'),
(900, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-09 10:17:40'),
(901, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '39.48.5.21', '2026-08-09 11:01:09'),
(902, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '111.119.189.37', '2026-08-09 12:06:26'),
(903, 240, 'wazir.nasrullah', 'Teacher', 'auth.login', 'Logged in', '118.107.141.174', '2026-08-09 14:01:40'),
(904, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"\"', '118.107.141.174', '2026-08-09 14:01:41'),
(905, 240, 'wazir.nasrullah', 'Teacher', 'auth.login', 'Logged in', '118.107.141.174', '2026-08-09 14:01:47'),
(906, 238, 'mehboob.ali.meer', 'Teacher', 'auth.login', 'Logged in', '118.107.142.160', '2026-08-09 14:10:39'),
(907, 238, 'mehboob.ali.meer', 'Teacher', 'auth.login', 'Logged in', '118.107.142.160', '2026-08-09 14:24:34'),
(908, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"sabir hussain\"', '118.107.131.12', '2026-08-09 15:11:25'),
(909, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-09 15:43:51'),
(910, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"sabir. hussain\"', '118.107.142.210', '2026-08-09 15:52:30'),
(911, 235, 'tanveer', 'Teacher', 'auth.login', 'Logged in', '2404:8300:10:2ec7::1', '2026-08-09 23:57:14'),
(912, 235, 'tanveer', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:2ec7::1', '2026-08-10 00:07:15'),
(913, 235, 'tanveer', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:2ec7::1', '2026-08-10 00:07:31'),
(914, 235, 'tanveer', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:2ec7::1', '2026-08-10 00:10:29'),
(915, 235, 'tanveer', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:2ec7::1', '2026-08-10 00:19:21'),
(916, 235, 'tanveer', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:2ec7::1', '2026-08-10 00:24:05'),
(917, 235, 'tanveer', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:2ec7::1', '2026-08-10 00:29:03'),
(918, 235, 'tanveer', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:2ec7::1', '2026-08-10 00:34:06'),
(919, 235, 'tanveer', 'Teacher', 'academic.marks_saved', 'Marks saved', '2404:8300:10:2ec7::1', '2026-08-10 00:43:01'),
(920, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-10 05:33:32'),
(921, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-10 08:42:32'),
(922, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-10 08:43:39'),
(923, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-10 08:43:56'),
(924, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-10 08:45:21'),
(925, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-10 10:59:33'),
(926, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-10 10:59:52'),
(927, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"\"', '103.149.240.91', '2026-08-10 14:33:32'),
(928, 233, 'abdullah.khan', 'Principal', 'auth.login', 'Logged in', '2402:ad80:f6:552a:4881:3aff:fe95:dbae', '2026-08-10 15:58:52'),
(929, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.135.150', '2026-08-10 16:43:17'),
(930, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.135.150', '2026-08-10 16:44:20'),
(931, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.135.150', '2026-08-10 16:45:11'),
(932, 7, 'Hussaini', 'Teacher', 'fees.collect', 'Collected Rs 1,700.00 via cash for invoice #357', '118.107.135.150', '2026-08-10 16:49:03'),
(933, 28, 'Muez', 'Student', 'auth.login', 'Logged in', '2402:ad80:f6:552a:4881:3aff:fe95:dbae', '2026-08-10 16:53:25'),
(934, 28, 'Muez', 'Student', 'auth.logout', 'Logged out', '2402:ad80:f6:552a:4881:3aff:fe95:dbae', '2026-08-10 16:55:15'),
(935, 233, 'abdullah.khan', 'Principal', 'auth.login', 'Logged in', '37.111.181.21', '2026-08-10 17:06:46'),
(936, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '2402:ad80:f6:552a:4881:3aff:fe95:dbae', '2026-08-10 17:10:02'),
(937, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '58.65.217.235', '2026-08-11 03:47:43'),
(938, 20, 'Hassanad', 'Admin', 'auth.login', 'Logged in', '118.107.131.227', '2026-08-11 03:50:08'),
(939, 20, 'Hassanad', 'Admin', 'staff.attendance_take', 'Recorded staff attendance for 2026-08-11 (12 staff)', '118.107.131.227', '2026-08-11 03:57:47'),
(940, 20, 'Hassanad', 'Admin', 'staff.attendance_take', 'Recorded staff attendance for 2026-08-11 (12 staff)', '118.107.131.227', '2026-08-11 03:57:54'),
(941, 21, 'G.Abbas', 'Teacher', 'auth.login', 'Logged in', '118.107.131.227', '2026-08-11 03:59:21'),
(942, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '103.137.26.9', '2026-08-11 04:02:06'),
(943, 21, 'G.Abbas', 'Teacher', 'auth.login', 'Logged in', '118.107.142.193', '2026-08-11 04:15:12'),
(944, 20, 'Hassanad', 'Admin', 'auth.logout', 'Logged out', '118.107.142.193', '2026-08-11 04:16:49'),
(945, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '118.107.142.193', '2026-08-11 04:17:00'),
(946, 21, 'G.Abbas', 'Teacher', 'academic.attendance_take', 'Took attendance for 3rd A on 2026-08-11 (22 student(s))', '118.107.142.193', '2026-08-11 04:20:05'),
(947, 21, 'G.Abbas', 'Teacher', 'academic.attendance_take', 'Took attendance for 4th A on 2026-08-11 (27 student(s))', '118.107.142.193', '2026-08-11 04:24:56'),
(948, 21, 'G.Abbas', 'Teacher', 'academic.attendance_take', 'Took attendance for 4th A on 2026-08-11 (27 student(s))', '118.107.142.193', '2026-08-11 04:30:13'),
(949, 20, 'Hassanad', 'Admin', 'auth.login', 'Logged in', '118.107.142.193', '2026-08-11 05:12:50'),
(950, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"Sabir.hussain\"', '118.107.142.193', '2026-08-11 05:19:31'),
(951, NULL, NULL, NULL, 'auth.password_reset_request', 'Requested a password reset for \"sabir.hussain\"', '118.107.142.193', '2026-08-11 05:20:01'),
(952, 20, 'Hassanad', 'Admin', 'students.bulk_delete', 'Bulk-deleted 1 student(s)', '118.107.142.193', '2026-08-11 05:20:26'),
(953, NULL, NULL, NULL, 'auth.password_reset', 'Reset password for \"sabir.hussain\" via emailed link', '118.107.142.193', '2026-08-11 05:22:22'),
(954, 20, 'Hassanad', 'Admin', 'students.update', 'Updated student \"Zameer Abbas\" (#645)', '118.107.142.193', '2026-08-11 05:22:24'),
(955, 234, 'sabir.hussain', 'Teacher', 'auth.login', 'Logged in', '118.107.142.193', '2026-08-11 05:23:14'),
(956, 21, 'G.Abbas', 'Teacher', 'auth.login', 'Logged in', '118.107.142.193', '2026-08-11 05:23:45'),
(957, 20, 'Hassanad', 'Admin', 'students.update', 'Updated student \"Hijab Ali Mohd\" (#679)', '118.107.142.193', '2026-08-11 05:26:20'),
(958, 20, 'Hassanad', 'Admin', 'students.update', 'Updated student \"Hadiqa Gh-Mutaza\" (#682)', '118.107.142.193', '2026-08-11 05:27:29'),
(959, 20, 'Hassanad', 'Admin', 'students.update', 'Updated student \"Maisam Essa Khan\" (#692)', '118.107.142.193', '2026-08-11 05:28:35'),
(960, 20, 'Hassanad', 'Admin', 'students.update', 'Updated student \"Saqlain Tahir\" (#698)', '118.107.142.193', '2026-08-11 05:29:32'),
(961, 20, 'Hassanad', 'Admin', 'students.update', 'Updated student \"Ali Mosa\" (#668)', '118.107.142.193', '2026-08-11 05:32:20'),
(962, 20, 'Hassanad', 'Admin', 'students.update', 'Updated student \"Fatima Ali\" (#657)', '118.107.142.193', '2026-08-11 05:32:57'),
(963, 234, 'sabir.hussain', 'Teacher', 'academic.attendance_take', 'Took attendance for 8th A on 2026-08-11 (13 student(s))', '118.107.142.193', '2026-08-11 05:33:28'),
(964, 234, 'sabir.hussain', 'Teacher', 'academic.attendance_take', 'Took attendance for One Class A on 2026-08-11 (17 student(s))', '118.107.142.193', '2026-08-11 05:37:10'),
(965, 234, 'sabir.hussain', 'Teacher', 'academic.attendance_take', 'Took attendance for One Class A on 2026-08-11 (17 student(s))', '118.107.142.193', '2026-08-11 05:37:34'),
(966, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 05:44:32'),
(967, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 05:59:51'),
(968, 20, 'Hassanad', 'Admin', 'auth.login', 'Logged in', '118.107.131.110', '2026-08-11 06:26:59'),
(969, 20, 'Hassanad', 'Admin', 'students.update', 'Updated student \"Wajiha Wajahat\" (#747)', '118.107.131.110', '2026-08-11 06:33:50'),
(970, 20, 'Hassanad', 'Admin', 'students.update', 'Updated student \"Naila Ali\" (#753)', '118.107.131.110', '2026-08-11 06:34:45'),
(971, 240, 'wazir.nasrullah', 'Teacher', 'auth.login', 'Logged in', '118.107.135.87', '2026-08-11 06:42:03'),
(972, 240, 'wazir.nasrullah', 'Teacher', 'auth.login', 'Logged in', '118.107.135.87', '2026-08-11 06:42:04'),
(973, 240, 'wazir.nasrullah', 'Teacher', 'auth.login', 'Logged in', '118.107.141.193', '2026-08-11 07:01:47'),
(974, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 07:06:09'),
(975, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 07:06:12'),
(976, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 07:08:16'),
(977, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 07:08:21'),
(978, 4, 'admin', 'Admin', 'users.permissions_update', 'Updated permissions for role \"Accountant\" (5 permission(s) granted)', '103.189.232.252', '2026-08-11 07:09:40'),
(979, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 07:09:43'),
(980, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 07:09:51'),
(981, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 07:14:29'),
(982, 28, 'Muez', 'Student', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 07:14:36'),
(983, 28, 'Muez', 'Student', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 07:14:48'),
(984, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 07:14:53'),
(985, 4, 'admin', 'Admin', 'academic.class_teacher_updated', 'Class teacher updated', '103.189.232.252', '2026-08-11 07:20:44'),
(986, 4, 'admin', 'Admin', 'academic.class_teacher_updated', 'Class teacher updated', '103.189.232.252', '2026-08-11 07:21:03'),
(987, 4, 'admin', 'Admin', 'academic.class_teacher_updated', 'Class teacher updated', '103.189.232.252', '2026-08-11 07:21:13'),
(988, 4, 'admin', 'Admin', 'academic.class_teacher_updated', 'Class teacher updated', '103.189.232.252', '2026-08-11 07:21:27'),
(989, 4, 'admin', 'Admin', 'academic.class_teacher_updated', 'Class teacher updated', '103.189.232.252', '2026-08-11 07:21:34'),
(990, 4, 'admin', 'Admin', 'academic.exam_group_pass_criteria_updated', 'Exam group / pass criteria updated', '103.189.232.252', '2026-08-11 07:28:52'),
(991, 4, 'admin', 'Admin', 'academic.exam_group_created', 'Exam group created', '103.189.232.252', '2026-08-11 07:29:49'),
(992, 4, 'admin', 'Admin', 'academic.write', 'Exam created for 2 classes.', '103.189.232.252', '2026-08-11 07:30:58'),
(993, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.141.58', '2026-08-11 07:34:47'),
(994, 7, 'Hussaini', 'Teacher', 'academic.attendance_take', 'Took attendance for 5th A on 2026-08-11 (13 student(s))', '118.107.141.58', '2026-08-11 07:38:09'),
(995, 7, 'Hussaini', 'Teacher', 'academic.attendance_take', 'Took attendance for 5th A on 2026-08-11 (13 student(s))', '118.107.141.58', '2026-08-11 07:38:16'),
(996, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 07:45:03'),
(997, NULL, NULL, NULL, 'auth.login_failed', 'Failed login attempt for username \"wazir.nasrullah\"', '103.189.232.252', '2026-08-11 07:45:48'),
(998, 240, 'wazir.nasrullah', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 07:46:11'),
(999, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 07:47:00'),
(1000, 261, 'admin2', 'Admin', 'students.update', 'Updated student \"Masooma Batool\" (#589)', '103.189.232.252', '2026-08-11 07:48:48'),
(1001, 261, 'admin2', 'Admin', 'students.update', 'Updated student \"Naseema Batool\" (#590)', '103.189.232.252', '2026-08-11 07:48:58'),
(1002, 261, 'admin2', 'Admin', 'students.update', 'Updated student \"Masooma Batool\" (#589)', '103.189.232.252', '2026-08-11 07:49:22'),
(1003, 261, 'admin2', 'Admin', 'students.update', 'Updated student \"Masooma Batool\" (#589)', '103.189.232.252', '2026-08-11 07:50:01'),
(1004, 261, 'admin2', 'Admin', 'students.update', 'Updated student \"Naseema Batool\" (#590)', '103.189.232.252', '2026-08-11 07:50:07'),
(1005, 240, 'wazir.nasrullah', 'Teacher', 'auth.login', 'Logged in', '118.107.135.203', '2026-08-11 07:58:22'),
(1006, 240, 'wazir.nasrullah', 'Teacher', 'academic.attendance_take', 'Took attendance for 10th Science A on 2026-08-11 (14 student(s))', '118.107.135.203', '2026-08-11 07:59:17'),
(1007, 240, 'wazir.nasrullah', 'Teacher', 'academic.attendance_take', 'Took attendance for 10th Science A on 2026-08-11 (14 student(s))', '118.107.135.203', '2026-08-11 07:59:48'),
(1008, 240, 'wazir.nasrullah', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 08:04:07'),
(1009, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 08:04:11'),
(1010, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 08:06:54'),
(1011, 240, 'wazir.nasrullah', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 08:07:01'),
(1012, 240, 'wazir.nasrullah', 'Teacher', 'academic.attendance_take', 'Took attendance for 10th Science A on 2026-08-11 (12 student(s))', '103.189.232.252', '2026-08-11 08:07:45'),
(1013, 240, 'wazir.nasrullah', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 08:07:56'),
(1014, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 08:08:00'),
(1015, 20, 'Hassanad', 'Admin', 'auth.login', 'Logged in', '103.137.26.98', '2026-08-11 08:14:54'),
(1016, 240, 'wazir.nasrullah', 'Teacher', 'auth.login', 'Logged in', '118.107.141.241', '2026-08-11 08:18:44'),
(1017, 20, 'Hassanad', 'Admin', 'auth.logout', 'Logged out', '103.137.26.98', '2026-08-11 08:21:29'),
(1018, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.137.26.98', '2026-08-11 08:21:40'),
(1019, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.137.26.98', '2026-08-11 08:24:28'),
(1020, 20, 'Hassanad', 'Admin', 'auth.login', 'Logged in', '103.137.26.98', '2026-08-11 08:24:36'),
(1021, 240, 'wazir.nasrullah', 'Teacher', 'academic.marks_saved', 'Marks saved', '118.107.141.241', '2026-08-11 08:27:53'),
(1022, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.132.177', '2026-08-11 08:33:55'),
(1023, 7, 'Hussaini', 'Teacher', 'academic.attendance_take', 'Took attendance for 5th A on 2026-08-11 (13 student(s))', '118.107.132.177', '2026-08-11 08:34:55'),
(1024, 7, 'Hussaini', 'Teacher', 'academic.attendance_take', 'Took attendance for 5th A on 2026-08-11 (13 student(s))', '118.107.132.177', '2026-08-11 08:35:18'),
(1025, 7, 'Hussaini', 'Teacher', 'academic.attendance_take', 'Took attendance for 5th A on 2026-08-11 (13 student(s))', '118.107.132.177', '2026-08-11 08:35:58'),
(1026, 7, 'Hussaini', 'Teacher', 'academic.attendance_take', 'Took attendance for 5th A on 2026-08-11 (13 student(s))', '118.107.132.177', '2026-08-11 08:36:27'),
(1027, 7, 'Hussaini', 'Teacher', 'academic.attendance_take', 'Took attendance for 5th A on 2026-08-11 (13 student(s))', '118.107.132.177', '2026-08-11 08:36:44'),
(1028, 7, 'Hussaini', 'Teacher', 'academic.attendance_take', 'Took attendance for 5th A on 2026-08-11 (13 student(s))', '118.107.132.177', '2026-08-11 08:37:55'),
(1029, 7, 'Hussaini', 'Teacher', 'academic.attendance_take', 'Took attendance for 5th A on 2026-08-11 (13 student(s))', '118.107.132.177', '2026-08-11 08:38:02'),
(1030, 20, 'Hassanad', 'Admin', 'academic.class_teacher_updated', 'Class teacher updated', '118.107.132.177', '2026-08-11 08:44:01'),
(1031, 20, 'Hassanad', 'Admin', 'academic.class_teacher_updated', 'Class teacher updated', '118.107.132.177', '2026-08-11 08:44:21'),
(1032, 20, 'Hassanad', 'Admin', 'academic.write', 'Timetable entry added', '118.107.132.177', '2026-08-11 08:49:05'),
(1033, 20, 'Hassanad', 'Admin', 'academic.write', 'Timetable entry added', '118.107.132.177', '2026-08-11 08:49:58'),
(1034, 20, 'Hassanad', 'Admin', 'academic.write', 'Timetable entry added', '118.107.132.177', '2026-08-11 08:50:39'),
(1035, 20, 'Hassanad', 'Admin', 'academic.write', 'Timetable entry added', '118.107.132.177', '2026-08-11 08:51:22'),
(1036, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 08:51:49'),
(1037, 20, 'Hassanad', 'Admin', 'academic.write', 'Timetable entry added', '118.107.132.177', '2026-08-11 08:52:11'),
(1038, 20, 'Hassanad', 'Admin', 'auth.logout', 'Logged out', '118.107.132.177', '2026-08-11 08:52:23'),
(1039, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '118.107.132.177', '2026-08-11 08:52:33'),
(1040, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '118.107.132.177', '2026-08-11 08:54:03'),
(1041, 20, 'Hassanad', 'Admin', 'auth.login', 'Logged in', '118.107.132.177', '2026-08-11 08:54:14'),
(1042, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 09:43:13'),
(1043, 20, 'Hassanad', 'Admin', 'auth.login', 'Logged in', '118.107.131.26', '2026-08-11 09:43:36'),
(1044, 4, 'admin', 'Admin', 'activity_log.export', 'Exported the activity log to CSV (1043 rows)', '103.189.232.252', '2026-08-11 09:43:58'),
(1045, 20, 'Hassanad', 'Admin', 'students.create', 'Added student \"Naila Batool\" (Admission #746)', '118.107.142.196', '2026-08-11 10:20:12'),
(1046, 20, 'Hassanad', 'Admin', 'students.update', 'Updated student \"Naila Batool\" (#809)', '118.107.142.196', '2026-08-11 10:21:26'),
(1047, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '118.107.131.97', '2026-08-11 10:30:07'),
(1048, 7, 'Hussaini', 'Teacher', 'academic.attendance_take', 'Took attendance for 10th Arts B on 2026-08-11 (6 student(s))', '118.107.131.97', '2026-08-11 10:35:03'),
(1049, 7, 'Hussaini', 'Teacher', 'academic.attendance_take', 'Took attendance for 10th Arts B on 2026-08-11 (6 student(s))', '118.107.131.97', '2026-08-11 10:35:31'),
(1050, 7, 'Hussaini', 'Teacher', 'academic.attendance_take', 'Took attendance for 10th Arts B on 2026-08-11 (6 student(s))', '118.107.131.97', '2026-08-11 10:35:39'),
(1051, 7, 'Hussaini', 'Teacher', 'academic.attendance_take', 'Took attendance for 10th Arts B on 2026-08-11 (6 student(s))', '118.107.131.97', '2026-08-11 10:36:02'),
(1052, 7, 'Hussaini', 'Teacher', 'academic.attendance_take', 'Took attendance for 10th Arts B on 2026-08-11 (6 student(s))', '118.107.131.97', '2026-08-11 10:36:14'),
(1053, 7, 'Hussaini', 'Teacher', 'academic.attendance_take', 'Took attendance for 10th Science A on 2026-08-11 (12 student(s))', '118.107.131.97', '2026-08-11 10:37:15'),
(1054, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 10:55:27'),
(1055, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 10:55:32'),
(1056, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 10:56:47'),
(1057, 233, 'abdullah.khan', 'Principal', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 10:56:51'),
(1058, 233, 'abdullah.khan', 'Principal', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 10:57:42'),
(1059, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 10:59:03'),
(1060, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 10:59:57'),
(1061, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 11:00:02'),
(1062, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 11:04:35'),
(1063, 240, 'wazir.nasrullah', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 11:04:41'),
(1064, 240, 'wazir.nasrullah', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 11:04:55'),
(1065, 261, 'admin2', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 11:04:59'),
(1066, 261, 'admin2', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 11:05:29'),
(1067, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 11:05:33'),
(1068, 7, 'Hussaini', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 11:05:49'),
(1069, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 11:05:56'),
(1070, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 11:58:59'),
(1071, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 12:02:00'),
(1072, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 12:02:03'),
(1073, 6, 'Hassan', 'Teacher', 'fees.handover_submit', 'Submitted fee handover of Rs 440.00 (#1)', '103.189.232.252', '2026-08-11 12:03:37'),
(1074, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 12:03:42'),
(1075, 233, 'abdullah.khan', 'Principal', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 12:03:45'),
(1076, 233, 'abdullah.khan', 'Principal', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 12:03:52'),
(1077, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 12:03:57'),
(1078, 4, 'admin', 'Admin', 'fees.handover_reject', 'Rejected fee handover #1', '103.189.232.252', '2026-08-11 12:05:26'),
(1079, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 12:05:42'),
(1080, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 12:05:45'),
(1081, 6, 'Hassan', 'Teacher', 'fees.handover_submit', 'Submitted fee handover of Rs 440.00 (#2)', '103.189.232.252', '2026-08-11 12:06:06'),
(1082, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 12:06:09'),
(1083, 7, 'Hussaini', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 12:06:13'),
(1084, 7, 'Hussaini', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 12:06:17'),
(1085, 4, 'admin', 'Admin', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 12:06:21'),
(1086, 4, 'admin', 'Admin', 'fees.handover_confirm', 'Confirmed fee handover #2 (Rs 440.00)', '103.189.232.252', '2026-08-11 12:06:29'),
(1087, 4, 'admin', 'Admin', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 12:06:53'),
(1088, 6, 'Hassan', 'Teacher', 'auth.login', 'Logged in', '103.189.232.252', '2026-08-11 12:06:56'),
(1089, 6, 'Hassan', 'Teacher', 'auth.logout', 'Logged out', '103.189.232.252', '2026-08-11 12:08:16');

-- --------------------------------------------------------

--
-- Table structure for table `api_tokens`
--

CREATE TABLE `api_tokens` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `api_tokens`
--

INSERT INTO `api_tokens` (`id`, `user_id`, `token`, `expires_at`, `last_used_at`, `created_at`) VALUES
(1, 4, '114b2a040c7cb5c11d451eb3ef78d99a0469fc9caaa2222d3b377363730fee0a', '2026-05-02 15:13:51', NULL, '2026-04-02 10:13:51');

-- --------------------------------------------------------

--
-- Table structure for table `attendance_records`
--

CREATE TABLE `attendance_records` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `class_section_id` int(11) NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `attendance_date` date NOT NULL,
  `status` enum('present','absent','late','excused') NOT NULL DEFAULT 'present',
  `created_by_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance_records`
--

INSERT INTO `attendance_records` (`id`, `student_id`, `class_section_id`, `subject_id`, `attendance_date`, `status`, `created_by_user_id`, `created_at`) VALUES
(68, 707, 7, NULL, '2026-07-22', 'present', 6, '2026-07-22 10:44:53'),
(69, 712, 7, NULL, '2026-07-22', 'present', 6, '2026-07-22 10:44:53'),
(70, 714, 7, NULL, '2026-07-22', 'present', 6, '2026-07-22 10:44:53'),
(71, 709, 7, NULL, '2026-07-22', 'present', 6, '2026-07-22 10:44:53'),
(72, 705, 7, NULL, '2026-07-22', 'present', 6, '2026-07-22 10:44:53'),
(73, 708, 7, NULL, '2026-07-22', 'present', 6, '2026-07-22 10:44:53'),
(74, 710, 7, NULL, '2026-07-22', 'present', 6, '2026-07-22 10:44:53'),
(75, 717, 7, NULL, '2026-07-22', 'present', 6, '2026-07-22 10:44:53'),
(76, 713, 7, NULL, '2026-07-22', 'present', 6, '2026-07-22 10:44:53'),
(77, 711, 7, NULL, '2026-07-22', 'present', 6, '2026-07-22 10:44:53'),
(78, 715, 7, NULL, '2026-07-22', 'present', 6, '2026-07-22 10:44:53'),
(79, 716, 7, NULL, '2026-07-22', 'present', 6, '2026-07-22 10:44:53'),
(80, 706, 7, NULL, '2026-07-22', 'present', 6, '2026-07-22 10:44:53'),
(81, 608, 1, NULL, '2026-07-25', 'present', 6, '2026-07-25 18:13:22'),
(82, 610, 1, NULL, '2026-07-25', 'present', 6, '2026-07-25 18:13:22'),
(83, 603, 1, NULL, '2026-07-25', 'present', 6, '2026-07-25 18:13:22'),
(84, 604, 1, NULL, '2026-07-25', 'present', 6, '2026-07-25 18:13:22'),
(85, 595, 1, NULL, '2026-07-25', 'present', 6, '2026-07-25 18:13:22'),
(86, 598, 1, NULL, '2026-07-25', 'present', 6, '2026-07-25 18:13:22'),
(87, 596, 1, NULL, '2026-07-25', 'present', 6, '2026-07-25 18:13:22'),
(88, 597, 1, NULL, '2026-07-25', 'present', 6, '2026-07-25 18:13:22'),
(89, 600, 1, NULL, '2026-07-25', 'present', 6, '2026-07-25 18:13:22'),
(90, 592, 1, NULL, '2026-07-25', 'absent', 6, '2026-07-25 18:13:22'),
(91, 606, 1, NULL, '2026-07-25', 'present', 6, '2026-07-25 18:13:22'),
(92, 591, 1, NULL, '2026-07-25', 'present', 6, '2026-07-25 18:13:22'),
(94, 599, 1, NULL, '2026-07-25', 'present', 6, '2026-07-25 18:13:22'),
(95, 609, 1, NULL, '2026-07-25', 'present', 6, '2026-07-25 18:13:22'),
(96, 605, 1, NULL, '2026-07-25', 'excused', 6, '2026-07-25 18:13:22'),
(97, 602, 1, NULL, '2026-07-25', 'present', 6, '2026-07-25 18:13:22'),
(98, 607, 1, NULL, '2026-07-25', 'present', 6, '2026-07-25 18:13:22'),
(99, 707, 7, NULL, '2026-07-25', 'present', 7, '2026-07-25 18:42:55'),
(100, 712, 7, NULL, '2026-07-25', 'present', 7, '2026-07-25 18:42:55'),
(101, 714, 7, NULL, '2026-07-25', 'present', 7, '2026-07-25 18:42:55'),
(102, 709, 7, NULL, '2026-07-25', 'present', 7, '2026-07-25 18:42:55'),
(103, 705, 7, NULL, '2026-07-25', 'absent', 7, '2026-07-25 18:42:55'),
(104, 708, 7, NULL, '2026-07-25', 'present', 7, '2026-07-25 18:42:55'),
(105, 710, 7, NULL, '2026-07-25', 'late', 7, '2026-07-25 18:42:55'),
(106, 717, 7, NULL, '2026-07-25', 'present', 7, '2026-07-25 18:42:55'),
(107, 713, 7, NULL, '2026-07-25', 'present', 7, '2026-07-25 18:42:55'),
(108, 711, 7, NULL, '2026-07-25', 'present', 7, '2026-07-25 18:42:55'),
(109, 715, 7, NULL, '2026-07-25', 'late', 7, '2026-07-25 18:42:55'),
(110, 716, 7, NULL, '2026-07-25', 'present', 7, '2026-07-25 18:42:55'),
(111, 706, 7, NULL, '2026-07-25', 'excused', 7, '2026-07-25 18:42:55'),
(112, 608, 1, NULL, '2026-08-03', 'absent', NULL, '2026-08-03 04:50:40'),
(113, 610, 1, NULL, '2026-08-03', 'present', NULL, '2026-08-03 04:50:40'),
(114, 603, 1, NULL, '2026-08-03', 'present', NULL, '2026-08-03 04:50:40'),
(115, 604, 1, NULL, '2026-08-03', 'present', NULL, '2026-08-03 04:50:40'),
(116, 595, 1, NULL, '2026-08-03', 'present', NULL, '2026-08-03 04:50:40'),
(117, 598, 1, NULL, '2026-08-03', 'present', NULL, '2026-08-03 04:50:40'),
(118, 596, 1, NULL, '2026-08-03', 'present', NULL, '2026-08-03 04:50:40'),
(119, 597, 1, NULL, '2026-08-03', 'present', NULL, '2026-08-03 04:50:40'),
(120, 600, 1, NULL, '2026-08-03', 'present', NULL, '2026-08-03 04:50:40'),
(121, 592, 1, NULL, '2026-08-03', 'present', NULL, '2026-08-03 04:50:40'),
(122, 606, 1, NULL, '2026-08-03', 'present', NULL, '2026-08-03 04:50:40'),
(123, 591, 1, NULL, '2026-08-03', 'present', NULL, '2026-08-03 04:50:40'),
(124, 599, 1, NULL, '2026-08-03', 'present', NULL, '2026-08-03 04:50:40'),
(125, 609, 1, NULL, '2026-08-03', 'present', NULL, '2026-08-03 04:50:40'),
(126, 605, 1, NULL, '2026-08-03', 'present', NULL, '2026-08-03 04:50:40'),
(127, 602, 1, NULL, '2026-08-03', 'present', NULL, '2026-08-03 04:50:40'),
(128, 607, 1, NULL, '2026-08-03', 'present', NULL, '2026-08-03 04:50:40'),
(129, 608, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(130, 610, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(131, 603, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(132, 604, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(133, 595, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(134, 598, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(135, 596, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(136, 597, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(137, 600, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(138, 592, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(139, 606, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(140, 591, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(141, 599, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(142, 609, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(143, 605, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(144, 602, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(145, 607, 1, NULL, '2026-08-01', 'present', NULL, '2026-08-03 04:50:52'),
(164, 608, 1, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:54:21'),
(165, 610, 1, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:54:21'),
(166, 603, 1, NULL, '2026-08-11', 'present', 20, '2026-08-11 03:54:21'),
(167, 604, 1, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:54:21'),
(168, 595, 1, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:54:21'),
(169, 598, 1, NULL, '2026-08-11', 'present', 20, '2026-08-11 03:54:21'),
(170, 596, 1, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:54:21'),
(171, 597, 1, NULL, '2026-08-11', 'present', 20, '2026-08-11 03:54:21'),
(172, 600, 1, NULL, '2026-08-11', 'present', 20, '2026-08-11 03:54:21'),
(173, 592, 1, NULL, '2026-08-11', 'present', 20, '2026-08-11 03:54:21'),
(174, 606, 1, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:54:21'),
(175, 591, 1, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:54:21'),
(177, 599, 1, NULL, '2026-08-11', 'present', 20, '2026-08-11 03:54:21'),
(178, 609, 1, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:54:21'),
(179, 605, 1, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:54:21'),
(180, 602, 1, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:54:21'),
(181, 607, 1, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:54:21'),
(198, 620, 2, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:56:14'),
(199, 611, 2, NULL, '2026-08-11', 'present', 20, '2026-08-11 03:56:14'),
(200, 621, 2, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:56:14'),
(201, 619, 2, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:56:14'),
(202, 618, 2, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:56:14'),
(203, 613, 2, NULL, '2026-08-11', 'present', 20, '2026-08-11 03:56:14'),
(204, 616, 2, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:56:14'),
(205, 625, 2, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:56:14'),
(206, 615, 2, NULL, '2026-08-11', 'present', 20, '2026-08-11 03:56:14'),
(207, 622, 2, NULL, '2026-08-11', 'present', 20, '2026-08-11 03:56:14'),
(208, 617, 2, NULL, '2026-08-11', 'present', 20, '2026-08-11 03:56:14'),
(209, 614, 2, NULL, '2026-08-11', 'present', 20, '2026-08-11 03:56:14'),
(210, 626, 2, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:56:14'),
(211, 623, 2, NULL, '2026-08-11', 'present', 20, '2026-08-11 03:56:14'),
(212, 643, 2, NULL, '2026-08-11', 'absent', 20, '2026-08-11 03:56:14'),
(213, 612, 2, NULL, '2026-08-11', 'present', 20, '2026-08-11 03:56:14'),
(214, 668, 5, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:20:05'),
(215, 676, 5, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:20:05'),
(216, 670, 5, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:20:05'),
(217, 667, 5, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:20:05'),
(218, 657, 5, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:20:05'),
(219, 672, 5, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:20:05'),
(220, 666, 5, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:20:05'),
(221, 660, 5, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:20:05'),
(222, 662, 5, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:20:05'),
(223, 663, 5, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:20:05'),
(224, 674, 5, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:20:05'),
(225, 659, 5, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:20:05'),
(226, 664, 5, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:20:05'),
(227, 658, 5, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:20:05'),
(228, 673, 5, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:20:05'),
(229, 665, 5, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:20:05'),
(230, 671, 5, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:20:05'),
(231, 656, 5, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:20:05'),
(232, 677, 5, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:20:05'),
(233, 669, 5, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:20:05'),
(234, 661, 5, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:20:05'),
(235, 675, 5, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:20:05'),
(263, 702, 6, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:30:13'),
(264, 695, 6, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:30:13'),
(265, 700, 6, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:30:13'),
(266, 699, 6, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:30:13'),
(267, 680, 6, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:30:13'),
(268, 682, 6, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:30:13'),
(269, 681, 6, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:30:13'),
(270, 679, 6, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:30:13'),
(271, 697, 6, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:30:13'),
(272, 690, 6, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:30:13'),
(273, 701, 6, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:30:13'),
(274, 685, 6, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:30:13'),
(275, 704, 6, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:30:13'),
(276, 691, 6, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:30:13'),
(277, 692, 6, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:30:13'),
(278, 687, 6, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:30:13'),
(279, 688, 6, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:30:13'),
(280, 703, 6, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:30:13'),
(281, 693, 6, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:30:13'),
(282, 686, 6, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:30:13'),
(283, 698, 6, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:30:13'),
(284, 683, 6, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:30:13'),
(285, 694, 6, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:30:13'),
(286, 696, 6, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:30:13'),
(287, 684, 6, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:30:13'),
(288, 678, 6, NULL, '2026-08-11', 'absent', 21, '2026-08-11 04:30:13'),
(289, 689, 6, NULL, '2026-08-11', 'present', 21, '2026-08-11 04:30:13'),
(302, 647, 4, NULL, '2026-08-11', 'absent', 20, '2026-08-11 05:16:13'),
(303, 644, 4, NULL, '2026-08-11', 'present', 20, '2026-08-11 05:16:13'),
(304, 650, 4, NULL, '2026-08-11', 'present', 20, '2026-08-11 05:16:13'),
(305, 648, 4, NULL, '2026-08-11', 'present', 20, '2026-08-11 05:16:13'),
(306, 649, 4, NULL, '2026-08-11', 'present', 20, '2026-08-11 05:16:13'),
(307, 651, 4, NULL, '2026-08-11', 'absent', 20, '2026-08-11 05:16:13'),
(308, 655, 4, NULL, '2026-08-11', 'present', 20, '2026-08-11 05:16:13'),
(309, 652, 4, NULL, '2026-08-11', 'present', 20, '2026-08-11 05:16:13'),
(310, 654, 4, NULL, '2026-08-11', 'absent', 20, '2026-08-11 05:16:13'),
(311, 653, 4, NULL, '2026-08-11', 'present', 20, '2026-08-11 05:16:13'),
(312, 646, 4, NULL, '2026-08-11', 'present', 20, '2026-08-11 05:16:13'),
(313, 645, 4, NULL, '2026-08-11', 'absent', 20, '2026-08-11 05:16:13'),
(314, 767, 10, NULL, '2026-08-11', 'absent', 234, '2026-08-11 05:33:28'),
(315, 764, 10, NULL, '2026-08-11', 'present', 234, '2026-08-11 05:33:28'),
(316, 762, 10, NULL, '2026-08-11', 'absent', 234, '2026-08-11 05:33:28'),
(317, 760, 10, NULL, '2026-08-11', 'absent', 234, '2026-08-11 05:33:28'),
(318, 761, 10, NULL, '2026-08-11', 'present', 234, '2026-08-11 05:33:28'),
(319, 765, 10, NULL, '2026-08-11', 'present', 234, '2026-08-11 05:33:28'),
(320, 766, 10, NULL, '2026-08-11', 'present', 234, '2026-08-11 05:33:28'),
(321, 756, 10, NULL, '2026-08-11', 'present', 234, '2026-08-11 05:33:28'),
(322, 757, 10, NULL, '2026-08-11', 'present', 234, '2026-08-11 05:33:28'),
(323, 755, 10, NULL, '2026-08-11', 'present', 234, '2026-08-11 05:33:28'),
(324, 763, 10, NULL, '2026-08-11', 'absent', 234, '2026-08-11 05:33:28'),
(325, 759, 10, NULL, '2026-08-11', 'absent', 234, '2026-08-11 05:33:28'),
(326, 758, 10, NULL, '2026-08-11', 'present', 234, '2026-08-11 05:33:28'),
(344, 641, 3, NULL, '2026-08-11', 'absent', 234, '2026-08-11 05:37:34'),
(345, 639, 3, NULL, '2026-08-11', 'present', 234, '2026-08-11 05:37:34'),
(346, 636, 3, NULL, '2026-08-11', 'present', 234, '2026-08-11 05:37:34'),
(347, 628, 3, NULL, '2026-08-11', 'present', 234, '2026-08-11 05:37:34'),
(348, 638, 3, NULL, '2026-08-11', 'absent', 234, '2026-08-11 05:37:34'),
(349, 630, 3, NULL, '2026-08-11', 'present', 234, '2026-08-11 05:37:34'),
(350, 627, 3, NULL, '2026-08-11', 'absent', 234, '2026-08-11 05:37:34'),
(351, 634, 3, NULL, '2026-08-11', 'absent', 234, '2026-08-11 05:37:34'),
(352, 631, 3, NULL, '2026-08-11', 'absent', 234, '2026-08-11 05:37:34'),
(353, 642, 3, NULL, '2026-08-11', 'present', 234, '2026-08-11 05:37:34'),
(354, 633, 3, NULL, '2026-08-11', 'present', 234, '2026-08-11 05:37:34'),
(355, 635, 3, NULL, '2026-08-11', 'absent', 234, '2026-08-11 05:37:34'),
(356, 640, 3, NULL, '2026-08-11', 'absent', 234, '2026-08-11 05:37:34'),
(357, 632, 3, NULL, '2026-08-11', 'present', 234, '2026-08-11 05:37:34'),
(358, 643, 3, NULL, '2026-08-11', 'absent', 234, '2026-08-11 05:37:34'),
(359, 629, 3, NULL, '2026-08-11', 'absent', 234, '2026-08-11 05:37:34'),
(360, 637, 3, NULL, '2026-08-11', 'absent', 234, '2026-08-11 05:37:34'),
(361, 734, 9, NULL, '2026-08-11', 'absent', 20, '2026-08-11 06:29:40'),
(362, 745, 9, NULL, '2026-08-11', 'present', 20, '2026-08-11 06:29:40'),
(363, 750, 9, NULL, '2026-08-11', 'absent', 20, '2026-08-11 06:29:40'),
(364, 752, 9, NULL, '2026-08-11', 'absent', 20, '2026-08-11 06:29:40'),
(365, 739, 9, NULL, '2026-08-11', 'present', 20, '2026-08-11 06:29:40'),
(366, 749, 9, NULL, '2026-08-11', 'absent', 20, '2026-08-11 06:29:40'),
(367, 737, 9, NULL, '2026-08-11', 'present', 20, '2026-08-11 06:29:40'),
(368, 735, 9, NULL, '2026-08-11', 'present', 20, '2026-08-11 06:29:40'),
(369, 732, 9, NULL, '2026-08-11', 'absent', 20, '2026-08-11 06:29:40'),
(370, 736, 9, NULL, '2026-08-11', 'present', 20, '2026-08-11 06:29:40'),
(371, 743, 9, NULL, '2026-08-11', 'present', 20, '2026-08-11 06:29:40'),
(372, 753, 9, NULL, '2026-08-11', 'present', 20, '2026-08-11 06:29:40'),
(373, 754, 9, NULL, '2026-08-11', 'present', 20, '2026-08-11 06:29:40'),
(374, 744, 9, NULL, '2026-08-11', 'present', 20, '2026-08-11 06:29:40'),
(375, 746, 9, NULL, '2026-08-11', 'absent', 20, '2026-08-11 06:29:40'),
(376, 748, 9, NULL, '2026-08-11', 'present', 20, '2026-08-11 06:29:40'),
(377, 747, 9, NULL, '2026-08-11', 'present', 20, '2026-08-11 06:29:40'),
(378, 741, 9, NULL, '2026-08-11', 'present', 20, '2026-08-11 06:29:40'),
(379, 751, 9, NULL, '2026-08-11', 'absent', 20, '2026-08-11 06:29:40'),
(380, 738, 9, NULL, '2026-08-11', 'present', 20, '2026-08-11 06:29:40'),
(381, 742, 9, NULL, '2026-08-11', 'present', 20, '2026-08-11 06:29:40'),
(382, 740, 9, NULL, '2026-08-11', 'present', 20, '2026-08-11 06:29:40'),
(383, 733, 9, NULL, '2026-08-11', 'present', 20, '2026-08-11 06:29:40'),
(430, 589, 13, NULL, '2026-08-11', 'absent', 240, '2026-08-11 07:59:48'),
(431, 590, 13, NULL, '2026-08-11', 'absent', 240, '2026-08-11 07:59:48'),
(528, 707, 7, NULL, '2026-08-11', 'present', 7, '2026-08-11 08:38:02'),
(529, 712, 7, NULL, '2026-08-11', 'present', 7, '2026-08-11 08:38:02'),
(530, 714, 7, NULL, '2026-08-11', 'present', 7, '2026-08-11 08:38:02'),
(531, 709, 7, NULL, '2026-08-11', 'present', 7, '2026-08-11 08:38:02'),
(532, 705, 7, NULL, '2026-08-11', 'present', 7, '2026-08-11 08:38:02'),
(533, 708, 7, NULL, '2026-08-11', 'present', 7, '2026-08-11 08:38:02'),
(534, 710, 7, NULL, '2026-08-11', 'present', 7, '2026-08-11 08:38:02'),
(535, 717, 7, NULL, '2026-08-11', 'present', 7, '2026-08-11 08:38:02'),
(536, 713, 7, NULL, '2026-08-11', 'present', 7, '2026-08-11 08:38:02'),
(537, 711, 7, NULL, '2026-08-11', 'present', 7, '2026-08-11 08:38:02'),
(538, 715, 7, NULL, '2026-08-11', 'present', 7, '2026-08-11 08:38:02'),
(539, 716, 7, NULL, '2026-08-11', 'present', 7, '2026-08-11 08:38:02'),
(540, 706, 7, NULL, '2026-08-11', 'present', 7, '2026-08-11 08:38:02'),
(549, 790, 15, NULL, '2026-08-11', 'present', 20, '2026-08-11 10:23:23'),
(550, 788, 15, NULL, '2026-08-11', 'present', 20, '2026-08-11 10:23:23'),
(551, 792, 15, NULL, '2026-08-11', 'absent', 20, '2026-08-11 10:23:23'),
(552, 809, 15, NULL, '2026-08-11', 'present', 20, '2026-08-11 10:23:23'),
(553, 791, 15, NULL, '2026-08-11', 'present', 20, '2026-08-11 10:23:23'),
(554, 793, 15, NULL, '2026-08-11', 'present', 20, '2026-08-11 10:23:23'),
(555, 789, 15, NULL, '2026-08-11', 'absent', 20, '2026-08-11 10:23:23'),
(556, 787, 15, NULL, '2026-08-11', 'present', 20, '2026-08-11 10:23:23'),
(557, 786, 15, NULL, '2026-08-11', 'present', 20, '2026-08-11 10:23:23'),
(582, 784, 16, NULL, '2026-08-11', 'present', 7, '2026-08-11 10:36:14'),
(583, 782, 16, NULL, '2026-08-11', 'present', 7, '2026-08-11 10:36:14'),
(584, 785, 16, NULL, '2026-08-11', 'present', 7, '2026-08-11 10:36:14'),
(585, 589, 16, NULL, '2026-08-11', 'absent', 7, '2026-08-11 10:36:14'),
(586, 780, 16, NULL, '2026-08-11', 'present', 7, '2026-08-11 10:36:14'),
(587, 590, 16, NULL, '2026-08-11', 'present', 7, '2026-08-11 10:36:14'),
(588, 774, 13, NULL, '2026-08-11', 'present', 7, '2026-08-11 10:37:15'),
(589, 776, 13, NULL, '2026-08-11', 'present', 7, '2026-08-11 10:37:15'),
(590, 779, 13, NULL, '2026-08-11', 'present', 7, '2026-08-11 10:37:15'),
(591, 772, 13, NULL, '2026-08-11', 'present', 7, '2026-08-11 10:37:15'),
(592, 770, 13, NULL, '2026-08-11', 'present', 7, '2026-08-11 10:37:15'),
(593, 769, 13, NULL, '2026-08-11', 'absent', 7, '2026-08-11 10:37:15'),
(594, 778, 13, NULL, '2026-08-11', 'present', 7, '2026-08-11 10:37:15'),
(595, 775, 13, NULL, '2026-08-11', 'present', 7, '2026-08-11 10:37:15'),
(596, 773, 13, NULL, '2026-08-11', 'absent', 7, '2026-08-11 10:37:15'),
(597, 768, 13, NULL, '2026-08-11', 'present', 7, '2026-08-11 10:37:15'),
(598, 777, 13, NULL, '2026-08-11', 'present', 7, '2026-08-11 10:37:15'),
(599, 771, 13, NULL, '2026-08-11', 'present', 7, '2026-08-11 10:37:15');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `name`) VALUES
(14, '10th Arts'),
(13, '10th Science'),
(15, '1st Year Arts'),
(17, '1st Year Science'),
(16, '2nd Year Arts'),
(5, '3rd'),
(6, '4th'),
(7, '5th'),
(8, '6th'),
(9, '7th'),
(10, '8th'),
(12, '9th Arts'),
(11, '9th Science'),
(4, 'Class Two'),
(1, 'Nursery'),
(3, 'One Class'),
(2, 'Prep');

-- --------------------------------------------------------

--
-- Table structure for table `class_sections`
--

CREATE TABLE `class_sections` (
  `id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `academic_year_id` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `class_teacher_staff_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class_sections`
--

INSERT INTO `class_sections` (`id`, `class_id`, `section_id`, `academic_year_id`, `start_date`, `end_date`, `class_teacher_staff_id`) VALUES
(1, 1, 1, NULL, '2026-03-02', '2026-12-31', 7),
(2, 2, 1, NULL, '2026-03-02', '2026-03-31', 13),
(3, 3, 1, NULL, NULL, NULL, 10),
(4, 4, 1, NULL, NULL, NULL, 12),
(5, 5, 1, NULL, NULL, NULL, 8),
(6, 6, 1, NULL, NULL, NULL, 8),
(7, 7, 1, NULL, NULL, NULL, 11),
(8, 8, 1, NULL, NULL, NULL, 12),
(9, 9, 1, NULL, NULL, NULL, 9),
(10, 10, 1, NULL, NULL, NULL, 10),
(13, 13, 1, NULL, NULL, NULL, 11),
(14, 15, 1, NULL, NULL, NULL, 10),
(15, 16, 1, NULL, NULL, NULL, 9),
(16, 14, 2, NULL, NULL, NULL, 11),
(17, 17, 1, 1, NULL, NULL, 10);

-- --------------------------------------------------------

--
-- Table structure for table `class_teachers`
--

CREATE TABLE `class_teachers` (
  `id` int(11) NOT NULL,
  `class_section_id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `assigned_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `submitted_by_user_id` int(11) DEFAULT NULL,
  `title` varchar(150) NOT NULL,
  `complaint_text` text NOT NULL,
  `status` enum('open','in_review','resolved','closed') NOT NULL DEFAULT 'open',
  `resolution_text` text DEFAULT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `course_assignments`
--

CREATE TABLE `course_assignments` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `assigned_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `course_resources`
--

CREATE TABLE `course_resources` (
  `id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `resource_type` enum('video','live_class','document','link') NOT NULL DEFAULT 'link',
  `source_type` enum('link','upload') NOT NULL DEFAULT 'link',
  `resource_url` varchar(255) DEFAULT NULL,
  `duration_seconds` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `custom_fields`
--

CREATE TABLE `custom_fields` (
  `id` int(11) NOT NULL,
  `scope` enum('user','student','staff') NOT NULL,
  `field_key` varchar(120) NOT NULL,
  `label_text` varchar(200) NOT NULL,
  `field_type` enum('text','number','date','select','textarea') NOT NULL DEFAULT 'text',
  `options_text` text DEFAULT NULL,
  `is_required` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `custom_field_values`
--

CREATE TABLE `custom_field_values` (
  `id` int(11) NOT NULL,
  `custom_field_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `staff_profile_id` int(11) DEFAULT NULL,
  `value_text` longtext NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `id` int(11) NOT NULL,
  `exam_group_id` int(11) NOT NULL,
  `academic_year_id` int(11) DEFAULT NULL,
  `class_section_id` int(11) DEFAULT NULL,
  `exam_name` varchar(120) NOT NULL,
  `scheduled_date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `is_locked` tinyint(4) NOT NULL DEFAULT 0,
  `results_published` tinyint(4) NOT NULL DEFAULT 0,
  `results_published_at` datetime DEFAULT NULL,
  `created_by_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `total_marks` int(10) UNSIGNED DEFAULT NULL COMMENT 'Default total marks for this exam (can vary per subject)',
  `cumulative_source_exam_name` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`id`, `exam_group_id`, `academic_year_id`, `class_section_id`, `exam_name`, `scheduled_date`, `start_time`, `end_time`, `is_locked`, `results_published`, `results_published_at`, `created_by_user_id`, `created_at`, `updated_at`, `total_marks`, `cumulative_source_exam_name`) VALUES
(9, 3, 1, 4, 'First Term Exam — 2nd A', '2026-07-20', '10:10:00', '11:20:00', 0, 0, NULL, 4, '2026-07-19 16:11:15', NULL, NULL, NULL),
(10, 3, 1, 5, 'First Term Exam — 3rd A', '2026-07-20', '10:10:00', '11:20:00', 0, 0, NULL, 4, '2026-07-19 16:11:15', NULL, NULL, NULL),
(11, 3, 1, 6, 'First Term Exam — 4th A', '2026-07-20', '10:10:00', '11:20:00', 0, 0, NULL, 4, '2026-07-19 16:11:15', NULL, NULL, NULL),
(12, 3, 1, 7, 'First Term Exam — 5th A', '2026-07-20', '10:10:00', '11:20:00', 0, 0, NULL, 4, '2026-07-19 16:11:15', NULL, NULL, NULL),
(13, 3, 1, 8, 'First Term Exam — 6th A', '2026-07-20', '10:10:00', '11:20:00', 0, 0, NULL, 4, '2026-07-19 16:11:15', NULL, NULL, NULL),
(14, 3, 1, 9, 'First Term Exam — 7th A', '2026-07-20', '10:10:00', '11:20:00', 0, 0, NULL, 4, '2026-07-19 16:11:15', NULL, NULL, NULL),
(15, 3, 1, 10, 'First Term Exam — 8th A', '2026-07-20', '10:10:00', '11:20:00', 0, 0, NULL, 4, '2026-07-19 16:11:15', NULL, NULL, NULL),
(16, 3, 1, 1, 'First Term Exam — Nursery A', '2026-07-20', '10:10:00', '11:20:00', 0, 0, NULL, 4, '2026-07-19 16:11:15', NULL, NULL, NULL),
(17, 3, 1, 3, 'First Term Exam — One Class A', '2026-07-20', '10:10:00', '11:20:00', 0, 0, NULL, 4, '2026-07-19 16:11:15', NULL, NULL, NULL),
(18, 3, 1, 2, 'First Term Exam — Prep A', '2026-07-20', '10:10:00', '11:20:00', 0, 0, NULL, 4, '2026-07-19 16:11:15', NULL, NULL, NULL),
(20, 3, 1, 15, 'First Term Exam', '2026-08-02', NULL, NULL, 0, 1, '2026-07-30 19:17:21', 261, '2026-07-30 19:10:59', '2026-08-01 12:38:29', 600, NULL),
(21, 4, 1, 15, 'Final Term Exam', NULL, NULL, NULL, 0, 1, '2026-08-01 13:40:52', 261, '2026-08-01 12:38:13', '2026-08-01 15:45:54', NULL, 'First Term Exam'),
(22, 4, 1, 2, 'Final Term Exam', NULL, NULL, NULL, 0, 0, NULL, 261, '2026-08-01 16:32:42', NULL, NULL, 'First Term Exam'),
(25, 5, 3, 16, 'FBISE SSC II — 10th Arts B', NULL, NULL, NULL, 0, 0, NULL, 4, '2026-08-05 15:29:40', '2026-08-05 15:36:08', NULL, NULL),
(26, 5, 3, 13, 'FBISE SSC II — 10th Science A', NULL, NULL, NULL, 0, 0, NULL, 4, '2026-08-05 15:29:40', '2026-08-05 15:36:16', NULL, NULL),
(27, 6, 3, 14, 'FBISE SSC II 2026 — 1st Year Arts A', NULL, NULL, NULL, 0, 0, NULL, 4, '2026-08-11 07:30:58', NULL, NULL, NULL),
(28, 6, 3, 17, 'FBISE SSC II 2026 — 1st Year Science A', NULL, NULL, NULL, 0, 0, NULL, 4, '2026-08-11 07:30:58', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `exam_groups`
--

CREATE TABLE `exam_groups` (
  `id` int(11) NOT NULL,
  `exam_type_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exam_groups`
--

INSERT INTO `exam_groups` (`id`, `exam_type_id`, `name`, `sort_order`) VALUES
(2, 1, 'Monthly', 1),
(3, 2, 'First Term', 1),
(4, 2, 'Final Term', 0),
(5, 3, 'SSC I Board 2026', 0),
(6, 3, 'SSC II Board 2026', 0);

-- --------------------------------------------------------

--
-- Table structure for table `exam_rules`
--

CREATE TABLE `exam_rules` (
  `id` int(11) NOT NULL,
  `exam_group_id` int(11) NOT NULL,
  `passing_percentage` decimal(5,2) NOT NULL DEFAULT 50.00,
  `passing_description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `max_failed_subjects` int(11) NOT NULL DEFAULT 1 COMMENT 'Fail if failed subjects > this (0 = must pass every subject)',
  `require_overall_pass` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 = overall % must also meet overall_passing_percentage',
  `overall_passing_percentage` decimal(5,2) DEFAULT NULL COMMENT 'NULL = use subject passing_percentage',
  `no_marks_is_fail` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 = no marks recorded => FAIL',
  `force_grade_f_on_fail` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 = set final grade F when result is FAIL'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exam_rules`
--

INSERT INTO `exam_rules` (`id`, `exam_group_id`, `passing_percentage`, `passing_description`, `created_at`, `max_failed_subjects`, `require_overall_pass`, `overall_passing_percentage`, `no_marks_is_fail`, `force_grade_f_on_fail`) VALUES
(1, 2, 44.00, NULL, '2026-03-28 22:28:42', 1, 1, NULL, 1, 1),
(2, 3, 40.00, '44% Passing Mark', '2026-07-16 18:14:16', 2, 1, 40.00, 1, 1),
(5, 4, 40.00, NULL, '2026-08-01 12:37:09', 2, 1, 40.00, 1, 1),
(6, 5, 40.00, NULL, '2026-08-05 12:01:34', 2, 1, 40.00, 1, 1),
(8, 6, 40.00, NULL, '2026-08-11 07:29:49', 2, 1, NULL, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `exam_subject_schedule`
--

CREATE TABLE `exam_subject_schedule` (
  `id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `scheduled_date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `total_marks` int(11) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `exam_subject_schedule`
--

INSERT INTO `exam_subject_schedule` (`id`, `exam_id`, `subject_id`, `scheduled_date`, `start_time`, `end_time`, `total_marks`, `sort_order`, `created_at`, `updated_at`) VALUES
(16, 16, 39, '2026-07-14', '08:00:00', '11:00:00', 50, 0, '2026-07-19 16:22:34', '2026-07-23 15:39:32'),
(17, 16, 29, '2026-07-18', '08:00:00', '11:00:00', 50, 1, '2026-07-19 16:22:34', '2026-07-23 15:39:32'),
(18, 16, 47, '2026-07-15', '08:00:00', '11:00:00', 50, 2, '2026-07-19 16:22:34', '2026-07-23 15:39:32'),
(19, 13, 50, '2026-07-15', '08:00:00', '11:00:00', 75, 0, '2026-07-22 13:01:50', '2026-07-23 15:50:51'),
(23, 18, 57, '2026-07-18', '08:00:00', '11:00:00', 50, 0, '2026-07-23 15:41:13', NULL),
(24, 18, 69, '2026-07-15', '08:00:00', '11:00:00', 50, 1, '2026-07-23 15:41:13', NULL),
(25, 18, 30, '2026-07-14', '08:00:00', '11:00:00', 50, 2, '2026-07-23 15:41:13', NULL),
(26, 17, 67, '2026-07-14', '08:00:00', '11:00:00', 50, 0, '2026-07-23 15:43:47', NULL),
(27, 17, 55, '2026-07-16', '08:00:00', '11:00:00', 50, 1, '2026-07-23 15:43:47', NULL),
(28, 17, 63, '2026-07-15', '08:00:00', '11:00:00', 50, 2, '2026-07-23 15:43:47', NULL),
(29, 17, 37, '2026-07-18', '08:00:00', '11:00:00', 50, 3, '2026-07-23 15:43:47', NULL),
(30, 17, 46, '2026-07-17', '08:00:00', '11:00:00', 50, 4, '2026-07-23 15:43:47', NULL),
(31, 9, 65, '2026-07-18', '08:00:00', '11:00:00', 50, 0, '2026-07-23 15:45:21', NULL),
(32, 9, 62, '2026-07-17', NULL, NULL, 50, 1, '2026-07-23 15:45:21', NULL),
(33, 9, 71, '2026-07-15', NULL, NULL, 50, 2, '2026-07-23 15:45:21', NULL),
(34, 9, 31, '2026-07-16', NULL, NULL, 50, 3, '2026-07-23 15:45:21', NULL),
(35, 9, 45, '2026-07-14', NULL, NULL, 50, 4, '2026-07-23 15:45:21', NULL),
(36, 10, 53, '2026-07-14', NULL, NULL, 50, 0, '2026-07-23 15:46:20', NULL),
(37, 10, 72, '2026-07-17', NULL, NULL, 50, 1, '2026-07-23 15:46:20', NULL),
(38, 10, 52, '2026-07-18', NULL, NULL, 50, 2, '2026-07-23 15:46:20', NULL),
(39, 10, 26, '2026-07-15', NULL, NULL, 50, 3, '2026-07-23 15:46:20', NULL),
(40, 10, 49, '2026-07-16', NULL, NULL, 50, 4, '2026-07-23 15:46:20', NULL),
(41, 11, 51, '2026-07-14', NULL, NULL, 50, 0, '2026-07-23 15:47:24', NULL),
(42, 11, 27, '2026-07-13', NULL, NULL, 50, 1, '2026-07-23 15:47:24', NULL),
(43, 11, 61, '2026-07-15', NULL, NULL, 50, 2, '2026-07-23 15:47:24', NULL),
(44, 11, 56, '2026-07-17', NULL, NULL, 50, 3, '2026-07-23 15:47:24', NULL),
(45, 11, 41, '2026-07-18', NULL, NULL, 50, 4, '2026-07-23 15:47:24', NULL),
(46, 11, 68, '2026-07-16', NULL, NULL, 50, 5, '2026-07-23 15:47:24', NULL),
(47, 12, 25, '2026-07-16', NULL, NULL, 75, 0, '2026-07-23 15:49:22', NULL),
(48, 12, 33, '2026-07-17', NULL, NULL, 75, 1, '2026-07-23 15:49:22', NULL),
(49, 12, 60, '2026-07-14', NULL, NULL, 75, 2, '2026-07-23 15:49:22', NULL),
(50, 12, 64, '2026-07-18', NULL, NULL, 75, 3, '2026-07-23 15:49:22', NULL),
(51, 12, 38, '2026-07-15', NULL, NULL, 75, 4, '2026-07-23 15:49:22', NULL),
(52, 12, 43, '2026-07-13', NULL, NULL, 75, 5, '2026-07-23 15:49:22', NULL),
(54, 13, 35, '2026-07-13', NULL, NULL, 75, 1, '2026-07-23 15:50:34', '2026-07-23 15:50:51'),
(55, 13, 70, '2026-07-17', NULL, NULL, 75, 2, '2026-07-23 15:50:34', '2026-07-23 15:50:51'),
(56, 13, 66, '2026-07-18', NULL, NULL, 75, 3, '2026-07-23 15:50:34', '2026-07-23 15:50:51'),
(58, 13, 24, '2026-07-14', NULL, NULL, 75, 5, '2026-07-23 15:50:34', '2026-07-23 15:50:51'),
(59, 13, 40, '2026-07-16', NULL, NULL, 75, 6, '2026-07-23 15:50:34', '2026-07-23 15:50:51'),
(66, 14, 23, '2026-07-14', NULL, NULL, 75, 0, '2026-07-23 15:51:51', '2026-07-23 15:58:36'),
(67, 14, 34, '2026-07-15', NULL, NULL, 75, 1, '2026-07-23 15:51:51', '2026-07-23 15:58:36'),
(68, 14, 48, '2026-07-18', NULL, NULL, 75, 2, '2026-07-23 15:51:51', '2026-07-23 15:58:36'),
(69, 14, 28, '2026-07-16', NULL, NULL, 75, 3, '2026-07-23 15:51:51', '2026-07-23 15:58:36'),
(70, 14, 58, '2026-07-13', NULL, NULL, 75, 4, '2026-07-23 15:51:51', '2026-07-23 15:58:36'),
(71, 14, 54, '2026-07-17', NULL, NULL, 75, 5, '2026-07-23 15:51:51', '2026-07-23 15:58:36'),
(72, 15, 32, '2026-07-17', NULL, NULL, 75, 0, '2026-07-23 15:52:41', '2026-07-23 15:54:41'),
(73, 15, 36, '2026-07-13', NULL, NULL, 75, 1, '2026-07-23 15:52:41', '2026-07-23 15:54:41'),
(74, 15, 42, '2026-07-16', NULL, NULL, 75, 2, '2026-07-23 15:52:41', '2026-07-23 15:54:41'),
(75, 15, 59, '2026-07-18', NULL, NULL, 75, 4, '2026-07-23 15:52:41', '2026-07-23 15:54:41'),
(76, 15, 44, '2026-07-14', NULL, NULL, 75, 5, '2026-07-23 15:52:41', '2026-07-23 15:54:41'),
(80, 15, 82, '2026-07-15', NULL, NULL, 75, 3, '2026-07-23 15:54:41', NULL),
(95, 20, 113, '2026-08-01', NULL, NULL, 100, 0, '2026-07-30 19:13:07', NULL),
(96, 20, 73, '2026-08-02', NULL, NULL, 100, 1, '2026-07-30 19:13:07', NULL),
(97, 20, 90, '2026-08-03', NULL, NULL, 100, 2, '2026-07-30 19:13:07', NULL),
(98, 20, 81, '2026-08-04', NULL, NULL, 100, 3, '2026-07-30 19:13:07', NULL),
(99, 20, 94, '2026-08-05', NULL, NULL, 100, 4, '2026-07-30 19:13:07', NULL),
(100, 20, 89, '2026-08-06', NULL, NULL, 100, 5, '2026-07-30 19:13:07', NULL),
(101, 21, 73, NULL, NULL, NULL, 75, 0, '2026-08-01 12:39:17', NULL),
(102, 21, 90, NULL, NULL, NULL, 75, 1, '2026-08-01 12:39:17', NULL),
(103, 21, 116, NULL, NULL, NULL, 75, 2, '2026-08-01 12:39:17', NULL),
(104, 21, 81, NULL, NULL, NULL, 75, 3, '2026-08-01 12:39:17', NULL),
(105, 21, 94, NULL, NULL, NULL, 75, 4, '2026-08-01 12:39:17', NULL),
(106, 21, 113, NULL, NULL, NULL, 75, 5, '2026-08-01 12:39:17', NULL),
(107, 21, 89, NULL, NULL, NULL, 75, 6, '2026-08-01 12:39:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `exam_types`
--

CREATE TABLE `exam_types` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exam_types`
--

INSERT INTO `exam_types` (`id`, `name`, `description`) VALUES
(1, 'Test', 'Monthly or Weekly'),
(2, 'Exam', 'Quaterly'),
(3, 'Board Exam', 'Results of Matric and  FA,FSC');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `expense_category_id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `expense_date` date NOT NULL,
  `added_by_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expense_categories`
--

CREATE TABLE `expense_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `expense_categories`
--

INSERT INTO `expense_categories` (`id`, `name`) VALUES
(5, 'Electricity'),
(10, 'Furniture'),
(7, 'Miscellaneous'),
(1, 'Printing'),
(3, 'Repair & Maintenance'),
(2, 'Sports Materials'),
(8, 'Staff xpense'),
(4, 'Stationery'),
(6, 'Transport'),
(9, 'Utilities');

-- --------------------------------------------------------

--
-- Table structure for table `fee_assignments`
--

CREATE TABLE `fee_assignments` (
  `id` int(11) NOT NULL,
  `fee_category_id` int(11) NOT NULL,
  `academic_year_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `class_section_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `fee_assignments`
--

INSERT INTO `fee_assignments` (`id`, `fee_category_id`, `academic_year_id`, `student_id`, `class_section_id`, `amount`, `description`, `created_at`) VALUES
(42, 1, 1, NULL, 1, 1000.00, '', '2026-07-13 06:40:22'),
(43, 1, 1, NULL, 2, 1050.00, '', '2026-07-13 06:40:53'),
(44, 1, 1, NULL, 3, 1060.00, '', '2026-07-13 06:41:24'),
(45, 1, 1, NULL, 4, 1070.00, '', '2026-07-13 06:41:57'),
(46, 1, 1, NULL, 5, 1090.00, '', '2026-07-13 06:42:27'),
(47, 1, 1, NULL, 6, 1140.00, '', '2026-07-13 06:42:53'),
(48, 1, 1, NULL, 7, 1190.00, '', '2026-07-13 06:43:19'),
(49, 1, 1, NULL, 8, 1250.00, '', '2026-07-13 06:43:39'),
(50, 1, 1, NULL, 9, 1300.00, '', '2026-07-13 06:44:03'),
(51, 1, 1, NULL, 10, 1500.00, '', '2026-07-13 06:44:24'),
(54, 1, 1, NULL, 13, 2500.00, '', '2026-07-16 20:05:36'),
(55, 1, 1, NULL, 16, 2300.00, '', '2026-07-16 20:06:00'),
(57, 4, 1, NULL, 5, 380.00, 'First Term Exam Fee', '2026-07-26 20:22:43'),
(58, 4, 1, NULL, 6, 380.00, 'First Term Exam Fee', '2026-07-26 20:22:43'),
(59, 4, 1, NULL, 4, 380.00, 'First Term Exam Fee', '2026-07-26 20:22:43'),
(60, 4, 1, NULL, 1, 380.00, 'First Term Exam Fee', '2026-07-26 20:22:43'),
(61, 4, 1, NULL, 3, 380.00, 'First Term Exam Fee', '2026-07-26 20:22:43'),
(62, 4, 1, NULL, 2, 380.00, 'First Term Exam Fee', '2026-07-26 20:22:43'),
(63, 4, 1, NULL, 7, 400.00, 'First Term Exam Fee', '2026-07-26 20:23:20'),
(64, 4, 1, NULL, 8, 400.00, 'First Term Exam Fee', '2026-07-26 20:23:20'),
(65, 4, 1, NULL, 9, 400.00, 'First Term Exam Fee', '2026-07-26 20:23:20'),
(66, 4, 1, NULL, 10, 400.00, 'First Term Exam Fee', '2026-07-26 20:23:20');

-- --------------------------------------------------------

--
-- Table structure for table `fee_categories`
--

CREATE TABLE `fee_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_one_time` tinyint(4) NOT NULL DEFAULT 0,
  `is_tuition` tinyint(4) NOT NULL DEFAULT 0,
  `is_admission` tinyint(4) NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `no_discount` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fee_categories`
--

INSERT INTO `fee_categories` (`id`, `name`, `description`, `is_one_time`, `is_tuition`, `is_admission`, `sort_order`, `no_discount`) VALUES
(1, 'Tuition Fee', 'Monthly Fee', 0, 1, 0, 1200, 0),
(2, 'Admission Fee', 'One time Only', 1, 0, 0, 0, 0),
(4, 'Exam Fee', '1st and Last Term Exam Fee', 1, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `fee_collections`
--

CREATE TABLE `fee_collections` (
  `id` int(11) NOT NULL,
  `fee_invoice_id` int(11) NOT NULL,
  `collected_at` datetime NOT NULL DEFAULT current_timestamp(),
  `amount` decimal(10,2) NOT NULL,
  `method` enum('cash','card','bank') NOT NULL DEFAULT 'cash',
  `notes` varchar(255) DEFAULT NULL,
  `collected_by_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fee_collections`
--

INSERT INTO `fee_collections` (`id`, `fee_invoice_id`, `collected_at`, `amount`, `method`, `notes`, `collected_by_user_id`) VALUES
(47, 251, '2026-07-16 16:54:10', 2120.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(48, 252, '2026-07-16 16:55:08', 2120.00, 'cash', 'Paid for: Tuition Fee - April, Tuition Fee - May', 4),
(49, 256, '2026-07-16 16:57:07', 1060.00, 'cash', 'Paid for: Tuition Fee - March', 4),
(50, 257, '2026-07-16 16:57:36', 4240.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(51, 258, '2026-07-16 16:57:59', 5300.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June, Tuition Fee - July', 4),
(52, 259, '2026-07-16 16:58:36', 4240.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(53, 266, '2026-07-16 17:00:48', 2120.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(54, 268, '2026-07-16 17:04:34', 1060.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(55, 265, '2026-07-16 17:05:37', 1060.00, 'cash', 'Paid for: Tuition Fee - March', 4),
(60, 431, '2026-07-17 08:05:26', 1000.00, 'cash', 'Paid for: Tuition Fee - April, Tuition Fee - May', 4),
(61, 440, '2026-07-17 08:19:36', 3000.00, 'cash', 'Paid for: Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(62, 438, '2026-07-17 08:20:09', 1000.00, 'cash', 'Paid for: Tuition Fee - April', 4),
(63, 436, '2026-07-17 08:20:37', 3000.00, 'cash', 'Paid for: Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(64, 435, '2026-07-17 08:21:32', 2000.00, 'cash', 'Paid for: Tuition Fee - April, Tuition Fee - May', 4),
(65, 434, '2026-07-17 08:22:02', 4000.00, 'cash', 'Paid for: Tuition Fee - April, Tuition Fee - May, Tuition Fee - June, Tuition Fee - July', 4),
(66, 432, '2026-07-17 08:23:11', 1500.00, 'cash', 'Paid for: Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(67, 447, '2026-07-17 08:24:06', 5000.00, 'cash', 'Paid for: Tuition Fee - August, Tuition Fee - September, Tuition Fee - October, Tuition Fee - November, Tuition Fee - December', 4),
(68, 448, '2026-07-17 08:24:45', 2000.00, 'cash', 'Jan-Feb 2027 Received | Paid for: Tuition Fee - January, Tuition Fee - February', 4),
(69, 452, '2026-07-17 08:31:00', 2100.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(70, 455, '2026-07-17 08:31:54', 1575.00, 'cash', 'Paid for: Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(71, 457, '2026-07-17 08:32:42', 1050.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(72, 458, '2026-07-17 08:33:32', 3150.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(73, 459, '2026-07-17 08:34:04', 1575.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(74, 460, '2026-07-17 08:34:32', 4200.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(75, 461, '2026-07-17 08:34:56', 2100.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(76, 463, '2026-07-17 08:35:18', 525.00, 'cash', 'Paid for: Tuition Fee - March', 4),
(77, 464, '2026-07-17 08:35:58', 3150.00, 'cash', 'Paid for: Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(78, 381, '2026-07-17 08:37:55', 4500.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(79, 382, '2026-07-17 08:38:15', 4500.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(80, 383, '2026-07-17 08:38:40', 6000.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(81, 384, '2026-07-17 08:39:09', 6000.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(82, 386, '2026-07-17 08:39:44', 1500.00, 'cash', 'Paid for: Tuition Fee - April', 4),
(83, 387, '2026-07-17 08:40:15', 6000.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(84, 388, '2026-07-17 08:40:55', 6000.00, 'cash', 'Paid for: Tuition Fee - April, Tuition Fee - May, Tuition Fee - June, Tuition Fee - July', 4),
(85, 389, '2026-07-17 08:41:34', 6000.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(86, 392, '2026-07-17 08:42:00', 6000.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(87, 357, '2026-07-17 08:43:29', 5200.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(88, 358, '2026-07-17 08:44:07', 5200.00, 'cash', 'Paid for: Tuition Fee - April, Tuition Fee - May, Tuition Fee - June, Tuition Fee - July', 4),
(89, 465, '2026-07-17 08:45:05', 6500.00, 'cash', 'Paid for: Tuition Fee - August, Tuition Fee - September, Tuition Fee - October, Tuition Fee - November, Tuition Fee - December', 4),
(90, 466, '2026-07-17 08:45:12', 2600.00, 'cash', 'Jan-Feb 2027 Received | Paid for: Tuition Fee - January, Tuition Fee - February', 4),
(91, 359, '2026-07-17 08:47:02', 2600.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(92, 360, '2026-07-17 08:47:16', 2600.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(93, 361, '2026-07-17 08:47:47', 5200.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(94, 362, '2026-07-17 08:48:06', 2600.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(95, 364, '2026-07-17 09:02:31', 3900.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(96, 365, '2026-07-17 09:03:12', 5200.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(97, 366, '2026-07-17 09:03:37', 2600.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(98, 367, '2026-07-17 09:04:09', 5200.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(99, 372, '2026-07-17 09:05:23', 5200.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(100, 373, '2026-07-17 09:05:58', 5200.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(101, 374, '2026-07-17 09:09:20', 2600.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(102, 375, '2026-07-17 09:09:42', 6500.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June, Tuition Fee - July', 4),
(103, 376, '2026-07-17 09:10:02', 5200.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(104, 377, '2026-07-17 09:10:22', 5200.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(105, 378, '2026-07-17 09:11:33', 1950.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(106, 379, '2026-07-17 09:12:11', 5200.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(107, 468, '2026-07-17 09:13:23', 2925.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(108, 343, '2026-07-17 09:14:40', 5000.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(109, 344, '2026-07-17 09:14:44', 5000.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(110, 345, '2026-07-17 09:14:51', 5000.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(111, 346, '2026-07-17 09:14:57', 5000.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(112, 347, '2026-07-17 09:15:10', 3750.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(113, 348, '2026-07-17 09:15:54', 6250.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June, Tuition Fee - July', 4),
(114, 349, '2026-07-17 09:16:21', 5000.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(115, 350, '2026-07-17 09:16:36', 5000.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(116, 351, '2026-07-17 09:16:52', 5000.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(117, 352, '2026-07-17 09:17:05', 6250.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June, Tuition Fee - July', 4),
(118, 353, '2026-07-17 09:17:24', 3750.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(119, 355, '2026-07-17 09:18:08', 5000.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(120, 356, '2026-07-17 09:18:33', 3750.00, 'cash', 'Paid for: Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(121, 469, '2026-07-17 09:21:29', 1250.00, 'cash', 'Paid for: Tuition Fee - August', 4),
(122, 330, '2026-07-17 17:48:35', 4760.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(123, 331, '2026-07-17 17:48:52', 2380.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(124, 332, '2026-07-17 17:49:09', 4760.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(125, 333, '2026-07-17 17:49:36', 2380.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(126, 334, '2026-07-17 17:50:08', 2380.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(127, 335, '2026-07-17 17:51:18', 4760.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(128, 336, '2026-07-17 17:51:29', 5950.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June, Tuition Fee - July', 4),
(129, 338, '2026-07-17 17:51:57', 4760.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(130, 339, '2026-07-17 17:52:10', 4760.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(131, 340, '2026-07-17 17:52:24', 4760.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(132, 303, '2026-07-17 17:53:54', 4560.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(133, 304, '2026-07-17 17:54:07', 4560.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(134, 307, '2026-07-17 17:56:15', 5700.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June, Tuition Fee - July', 4),
(135, 308, '2026-07-17 17:56:32', 3420.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(136, 309, '2026-07-17 17:56:49', 2280.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(137, 310, '2026-07-17 17:57:42', 3420.00, 'cash', 'Paid for: Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(138, 312, '2026-07-17 17:59:01', 3420.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(139, 314, '2026-07-17 17:59:36', 3420.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(140, 315, '2026-07-17 18:00:01', 4560.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(141, 316, '2026-07-17 18:00:18', 4560.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(142, 317, '2026-07-17 18:01:20', 5700.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June, Tuition Fee - July', 4),
(143, 318, '2026-07-17 18:02:05', 2280.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(144, 319, '2026-07-17 18:02:27', 4560.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(145, 320, '2026-07-17 18:02:54', 4560.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(146, 322, '2026-07-17 18:04:03', 5700.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June, Tuition Fee - July', 4),
(147, 324, '2026-07-17 18:04:29', 4560.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(148, 325, '2026-07-17 18:04:48', 2280.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(149, 326, '2026-07-17 18:05:06', 2280.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(150, 327, '2026-07-17 18:05:20', 4560.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(151, 328, '2026-07-17 18:05:32', 2280.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(152, 269, '2026-07-21 16:57:56', 4280.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(153, 270, '2026-07-21 16:58:30', 2140.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(154, 271, '2026-07-21 16:59:10', 1605.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(155, 272, '2026-07-21 16:59:45', 2675.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June, Tuition Fee - July', 4),
(156, 273, '2026-07-21 17:00:23', 4280.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(157, 277, '2026-07-21 17:03:31', 3210.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(158, 278, '2026-07-21 17:03:54', 2140.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(159, 279, '2026-07-21 17:04:21', 4280.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(160, 302, '2026-07-21 17:07:14', 2180.00, 'cash', 'Paid for: Tuition Fee - April, Tuition Fee - May', 4),
(161, 300, '2026-07-21 17:08:01', 3270.00, 'cash', 'Paid for: Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(162, 299, '2026-07-21 17:08:35', 3270.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(163, 298, '2026-07-21 17:09:11', 3270.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(164, 294, '2026-07-21 17:09:41', 2180.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(165, 292, '2026-07-21 17:10:51', 4360.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(166, 290, '2026-07-21 17:11:42', 2180.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(167, 288, '2026-07-21 17:12:43', 3270.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(168, 287, '2026-07-21 17:13:34', 4360.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(169, 286, '2026-07-21 17:14:27', 5450.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June, Tuition Fee - July', 4),
(170, 285, '2026-07-21 17:15:19', 3270.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June', 4),
(171, 284, '2026-07-21 17:16:33', 3270.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May', 4),
(172, 283, '2026-07-21 17:17:00', 5450.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April, Tuition Fee - May, Tuition Fee - June, Tuition Fee - July', 4),
(173, 281, '2026-07-21 17:17:22', 2180.00, 'cash', 'Paid for: Tuition Fee - March, Tuition Fee - April', 4),
(174, 430, '2026-07-26 14:55:52', 3000.00, 'cash', '', 20),
(175, 302, '2026-07-28 04:24:17', 380.00, 'cash', NULL, 261),
(177, 511, '2026-07-28 04:33:44', 380.00, 'cash', NULL, 6),
(178, 513, '2026-07-28 11:43:26', 380.00, 'cash', NULL, 6),
(182, 542, '2026-07-28 15:10:27', 400.00, 'cash', NULL, 7),
(183, 436, '2026-07-28 15:39:26', 380.00, 'cash', NULL, 6),
(184, 431, '2026-07-28 15:44:22', 500.00, 'cash', NULL, 6),
(185, 431, '2026-07-29 15:50:46', 880.00, 'cash', NULL, 6),
(186, 435, '2026-07-29 15:52:43', 1380.00, 'cash', NULL, 6),
(187, 438, '2026-07-29 15:54:34', 380.00, 'cash', NULL, 6),
(188, 439, '2026-07-29 15:55:16', 2380.00, 'cash', NULL, 6),
(189, 442, '2026-07-29 15:56:02', 2380.00, 'cash', NULL, 6),
(190, 440, '2026-07-29 15:56:55', 380.00, 'cash', NULL, 6),
(191, 514, '2026-07-29 15:58:00', 380.00, 'cash', NULL, 6),
(192, 332, '2026-07-30 19:17:23', 1590.00, 'cash', NULL, 7),
(193, 510, '2026-07-31 04:42:09', 1880.00, 'cash', NULL, 6),
(194, 436, '2026-07-31 04:43:49', 1000.00, 'cash', NULL, 6),
(195, 437, '2026-07-31 04:45:17', 3380.00, 'cash', NULL, 6),
(196, 437, '2026-07-31 04:45:45', 1000.00, 'cash', NULL, 6),
(197, 438, '2026-07-31 04:46:26', 3000.00, 'cash', NULL, 6),
(198, 516, '2026-07-31 04:47:20', 380.00, 'cash', NULL, 6),
(199, 357, '2026-08-10 16:49:03', 1700.00, 'cash', NULL, 7);

-- --------------------------------------------------------

--
-- Table structure for table `fee_collection_allocations`
--

CREATE TABLE `fee_collection_allocations` (
  `id` int(11) NOT NULL,
  `fee_collection_id` int(11) NOT NULL,
  `fee_invoice_line_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `fee_collection_allocations`
--

INSERT INTO `fee_collection_allocations` (`id`, `fee_collection_id`, `fee_invoice_line_id`, `amount`, `created_at`) VALUES
(1, 41, 324, 1050.00, '2026-07-16 16:26:29'),
(2, 41, 325, 1050.00, '2026-07-16 16:26:29'),
(3, 41, 326, 1050.00, '2026-07-16 16:26:29'),
(4, 42, 329, 525.00, '2026-07-16 16:27:29'),
(5, 42, 330, 525.00, '2026-07-16 16:27:29'),
(6, 42, 331, 525.00, '2026-07-16 16:27:29'),
(7, 43, 334, 1050.00, '2026-07-16 16:28:03'),
(8, 43, 335, 1050.00, '2026-07-16 16:28:03'),
(9, 43, 336, 1050.00, '2026-07-16 16:28:03'),
(10, 43, 337, 1050.00, '2026-07-16 16:28:03'),
(11, 44, 339, 1050.00, '2026-07-16 16:28:30'),
(12, 44, 340, 1050.00, '2026-07-16 16:28:30'),
(13, 45, 349, 525.00, '2026-07-16 16:29:09'),
(14, 46, 355, 1050.00, '2026-07-16 16:30:05'),
(15, 46, 356, 1050.00, '2026-07-16 16:30:05'),
(16, 46, 357, 1050.00, '2026-07-16 16:30:05'),
(17, 47, 369, 1060.00, '2026-07-16 16:54:10'),
(18, 47, 370, 1060.00, '2026-07-16 16:54:10'),
(19, 48, 375, 1060.00, '2026-07-16 16:55:08'),
(20, 48, 376, 1060.00, '2026-07-16 16:55:08'),
(21, 49, 394, 1060.00, '2026-07-16 16:57:07'),
(22, 50, 399, 1060.00, '2026-07-16 16:57:36'),
(23, 50, 400, 1060.00, '2026-07-16 16:57:36'),
(24, 50, 401, 1060.00, '2026-07-16 16:57:36'),
(25, 50, 402, 1060.00, '2026-07-16 16:57:36'),
(26, 51, 404, 1060.00, '2026-07-16 16:57:59'),
(27, 51, 405, 1060.00, '2026-07-16 16:57:59'),
(28, 51, 406, 1060.00, '2026-07-16 16:57:59'),
(29, 51, 407, 1060.00, '2026-07-16 16:57:59'),
(30, 51, 408, 1060.00, '2026-07-16 16:57:59'),
(31, 52, 409, 1060.00, '2026-07-16 16:58:36'),
(32, 52, 410, 1060.00, '2026-07-16 16:58:36'),
(33, 52, 411, 1060.00, '2026-07-16 16:58:36'),
(34, 52, 412, 1060.00, '2026-07-16 16:58:36'),
(35, 53, 444, 530.00, '2026-07-16 17:00:48'),
(36, 53, 445, 530.00, '2026-07-16 17:00:48'),
(37, 53, 446, 530.00, '2026-07-16 17:00:48'),
(38, 53, 447, 530.00, '2026-07-16 17:00:48'),
(39, 54, 454, 530.00, '2026-07-16 17:04:34'),
(40, 54, 455, 530.00, '2026-07-16 17:04:34'),
(41, 55, 439, 1060.00, '2026-07-16 17:05:37'),
(42, 56, 1083, 500.00, '2026-07-16 18:40:20'),
(43, 56, 1084, 500.00, '2026-07-16 18:40:20'),
(44, 56, 1085, 500.00, '2026-07-16 18:40:20'),
(45, 57, 1079, 500.00, '2026-07-16 18:42:07'),
(46, 57, 1080, 500.00, '2026-07-16 18:42:07'),
(47, 58, 1299, 11000.00, '2026-07-17 01:51:45'),
(48, 59, 201, 1000.00, '2026-07-17 08:00:14'),
(49, 59, 202, 1000.00, '2026-07-17 08:00:14'),
(50, 60, 1316, 500.00, '2026-07-17 08:05:26'),
(51, 60, 1317, 500.00, '2026-07-17 08:05:26'),
(52, 61, 1352, 1000.00, '2026-07-17 08:19:36'),
(53, 61, 1353, 1000.00, '2026-07-17 08:19:36'),
(54, 61, 1354, 1000.00, '2026-07-17 08:19:36'),
(55, 62, 1344, 1000.00, '2026-07-17 08:20:09'),
(56, 63, 1336, 1000.00, '2026-07-17 08:20:37'),
(57, 63, 1337, 1000.00, '2026-07-17 08:20:37'),
(58, 63, 1338, 1000.00, '2026-07-17 08:20:37'),
(59, 64, 1332, 1000.00, '2026-07-17 08:21:32'),
(60, 64, 1333, 1000.00, '2026-07-17 08:21:32'),
(61, 65, 1328, 1000.00, '2026-07-17 08:22:02'),
(62, 65, 1329, 1000.00, '2026-07-17 08:22:02'),
(63, 65, 1330, 1000.00, '2026-07-17 08:22:02'),
(64, 65, 1331, 1000.00, '2026-07-17 08:22:02'),
(65, 66, 1320, 500.00, '2026-07-17 08:23:11'),
(66, 66, 1321, 500.00, '2026-07-17 08:23:11'),
(67, 66, 1322, 500.00, '2026-07-17 08:23:11'),
(68, 67, 1380, 1000.00, '2026-07-17 08:24:06'),
(69, 67, 1381, 1000.00, '2026-07-17 08:24:06'),
(70, 67, 1382, 1000.00, '2026-07-17 08:24:06'),
(71, 67, 1383, 1000.00, '2026-07-17 08:24:06'),
(72, 67, 1384, 1000.00, '2026-07-17 08:24:06'),
(73, 68, 1385, 1000.00, '2026-07-17 08:24:45'),
(74, 68, 1386, 1000.00, '2026-07-17 08:24:45'),
(75, 69, 1402, 525.00, '2026-07-17 08:31:00'),
(76, 69, 1403, 525.00, '2026-07-17 08:31:00'),
(77, 69, 1404, 525.00, '2026-07-17 08:31:00'),
(78, 69, 1405, 525.00, '2026-07-17 08:31:00'),
(79, 70, 1418, 525.00, '2026-07-17 08:31:54'),
(80, 70, 1419, 525.00, '2026-07-17 08:31:54'),
(81, 70, 1420, 525.00, '2026-07-17 08:31:54'),
(82, 71, 1427, 525.00, '2026-07-17 08:32:42'),
(83, 71, 1428, 525.00, '2026-07-17 08:32:42'),
(84, 72, 1432, 1050.00, '2026-07-17 08:33:32'),
(85, 72, 1433, 1050.00, '2026-07-17 08:33:32'),
(86, 72, 1434, 1050.00, '2026-07-17 08:33:32'),
(87, 73, 1437, 525.00, '2026-07-17 08:34:04'),
(88, 73, 1438, 525.00, '2026-07-17 08:34:04'),
(89, 73, 1439, 525.00, '2026-07-17 08:34:04'),
(90, 74, 1442, 1050.00, '2026-07-17 08:34:32'),
(91, 74, 1443, 1050.00, '2026-07-17 08:34:32'),
(92, 74, 1444, 1050.00, '2026-07-17 08:34:32'),
(93, 74, 1445, 1050.00, '2026-07-17 08:34:32'),
(94, 75, 1447, 1050.00, '2026-07-17 08:34:56'),
(95, 75, 1448, 1050.00, '2026-07-17 08:34:56'),
(96, 76, 1457, 525.00, '2026-07-17 08:35:18'),
(97, 77, 1463, 1050.00, '2026-07-17 08:35:58'),
(98, 77, 1464, 1050.00, '2026-07-17 08:35:58'),
(99, 77, 1465, 1050.00, '2026-07-17 08:35:58'),
(100, 78, 1019, 1500.00, '2026-07-17 08:37:55'),
(101, 78, 1020, 1500.00, '2026-07-17 08:37:55'),
(102, 78, 1021, 1500.00, '2026-07-17 08:37:55'),
(103, 79, 1024, 1500.00, '2026-07-17 08:38:15'),
(104, 79, 1025, 1500.00, '2026-07-17 08:38:15'),
(105, 79, 1026, 1500.00, '2026-07-17 08:38:15'),
(106, 80, 1029, 1500.00, '2026-07-17 08:38:40'),
(107, 80, 1030, 1500.00, '2026-07-17 08:38:40'),
(108, 80, 1031, 1500.00, '2026-07-17 08:38:40'),
(109, 80, 1032, 1500.00, '2026-07-17 08:38:40'),
(110, 81, 1034, 1500.00, '2026-07-17 08:39:09'),
(111, 81, 1035, 1500.00, '2026-07-17 08:39:09'),
(112, 81, 1036, 1500.00, '2026-07-17 08:39:09'),
(113, 81, 1037, 1500.00, '2026-07-17 08:39:09'),
(114, 82, 1045, 1500.00, '2026-07-17 08:39:44'),
(115, 83, 1049, 1500.00, '2026-07-17 08:40:15'),
(116, 83, 1050, 1500.00, '2026-07-17 08:40:15'),
(117, 83, 1051, 1500.00, '2026-07-17 08:40:15'),
(118, 83, 1052, 1500.00, '2026-07-17 08:40:15'),
(119, 84, 1055, 1500.00, '2026-07-17 08:40:55'),
(120, 84, 1056, 1500.00, '2026-07-17 08:40:55'),
(121, 84, 1057, 1500.00, '2026-07-17 08:40:55'),
(122, 84, 1058, 1500.00, '2026-07-17 08:40:55'),
(123, 85, 1059, 1500.00, '2026-07-17 08:41:34'),
(124, 85, 1060, 1500.00, '2026-07-17 08:41:34'),
(125, 85, 1061, 1500.00, '2026-07-17 08:41:34'),
(126, 85, 1062, 1500.00, '2026-07-17 08:41:34'),
(127, 86, 1074, 1500.00, '2026-07-17 08:42:00'),
(128, 86, 1075, 1500.00, '2026-07-17 08:42:00'),
(129, 86, 1076, 1500.00, '2026-07-17 08:42:00'),
(130, 86, 1077, 1500.00, '2026-07-17 08:42:00'),
(131, 87, 899, 1300.00, '2026-07-17 08:43:29'),
(132, 87, 900, 1300.00, '2026-07-17 08:43:29'),
(133, 87, 901, 1300.00, '2026-07-17 08:43:29'),
(134, 87, 902, 1300.00, '2026-07-17 08:43:29'),
(135, 88, 905, 1300.00, '2026-07-17 08:44:07'),
(136, 88, 906, 1300.00, '2026-07-17 08:44:07'),
(137, 88, 907, 1300.00, '2026-07-17 08:44:07'),
(138, 88, 908, 1300.00, '2026-07-17 08:44:07'),
(139, 89, 1467, 1300.00, '2026-07-17 08:45:05'),
(140, 89, 1468, 1300.00, '2026-07-17 08:45:05'),
(141, 89, 1469, 1300.00, '2026-07-17 08:45:05'),
(142, 89, 1470, 1300.00, '2026-07-17 08:45:05'),
(143, 89, 1471, 1300.00, '2026-07-17 08:45:05'),
(144, 90, 1472, 1300.00, '2026-07-17 08:45:12'),
(145, 90, 1473, 1300.00, '2026-07-17 08:45:12'),
(146, 91, 909, 1300.00, '2026-07-17 08:47:02'),
(147, 91, 910, 1300.00, '2026-07-17 08:47:02'),
(148, 92, 914, 1300.00, '2026-07-17 08:47:16'),
(149, 92, 915, 1300.00, '2026-07-17 08:47:16'),
(150, 93, 919, 1300.00, '2026-07-17 08:47:47'),
(151, 93, 920, 1300.00, '2026-07-17 08:47:47'),
(152, 93, 921, 1300.00, '2026-07-17 08:47:47'),
(153, 93, 922, 1300.00, '2026-07-17 08:47:47'),
(154, 94, 924, 1300.00, '2026-07-17 08:48:06'),
(155, 94, 925, 1300.00, '2026-07-17 08:48:06'),
(156, 95, 934, 1300.00, '2026-07-17 09:02:31'),
(157, 95, 935, 1300.00, '2026-07-17 09:02:31'),
(158, 95, 936, 1300.00, '2026-07-17 09:02:31'),
(159, 96, 939, 1300.00, '2026-07-17 09:03:12'),
(160, 96, 940, 1300.00, '2026-07-17 09:03:12'),
(161, 96, 941, 1300.00, '2026-07-17 09:03:12'),
(162, 96, 942, 1300.00, '2026-07-17 09:03:12'),
(163, 97, 944, 1300.00, '2026-07-17 09:03:37'),
(164, 97, 945, 1300.00, '2026-07-17 09:03:37'),
(165, 98, 949, 1300.00, '2026-07-17 09:04:09'),
(166, 98, 950, 1300.00, '2026-07-17 09:04:09'),
(167, 98, 951, 1300.00, '2026-07-17 09:04:09'),
(168, 98, 952, 1300.00, '2026-07-17 09:04:09'),
(169, 99, 974, 1300.00, '2026-07-17 09:05:23'),
(170, 99, 975, 1300.00, '2026-07-17 09:05:23'),
(171, 99, 976, 1300.00, '2026-07-17 09:05:23'),
(172, 99, 977, 1300.00, '2026-07-17 09:05:23'),
(173, 100, 979, 1300.00, '2026-07-17 09:05:58'),
(174, 100, 980, 1300.00, '2026-07-17 09:05:58'),
(175, 100, 981, 1300.00, '2026-07-17 09:05:58'),
(176, 100, 982, 1300.00, '2026-07-17 09:05:58'),
(177, 101, 984, 1300.00, '2026-07-17 09:09:20'),
(178, 101, 985, 1300.00, '2026-07-17 09:09:20'),
(179, 102, 989, 1300.00, '2026-07-17 09:09:42'),
(180, 102, 990, 1300.00, '2026-07-17 09:09:42'),
(181, 102, 991, 1300.00, '2026-07-17 09:09:42'),
(182, 102, 992, 1300.00, '2026-07-17 09:09:42'),
(183, 102, 993, 1300.00, '2026-07-17 09:09:42'),
(184, 103, 994, 1300.00, '2026-07-17 09:10:02'),
(185, 103, 995, 1300.00, '2026-07-17 09:10:02'),
(186, 103, 996, 1300.00, '2026-07-17 09:10:02'),
(187, 103, 997, 1300.00, '2026-07-17 09:10:02'),
(188, 104, 999, 1300.00, '2026-07-17 09:10:22'),
(189, 104, 1000, 1300.00, '2026-07-17 09:10:22'),
(190, 104, 1001, 1300.00, '2026-07-17 09:10:22'),
(191, 104, 1002, 1300.00, '2026-07-17 09:10:22'),
(192, 105, 1004, 650.00, '2026-07-17 09:11:33'),
(193, 105, 1005, 650.00, '2026-07-17 09:11:33'),
(194, 105, 1006, 650.00, '2026-07-17 09:11:33'),
(195, 106, 1009, 1300.00, '2026-07-17 09:12:11'),
(196, 106, 1010, 1300.00, '2026-07-17 09:12:11'),
(197, 106, 1011, 1300.00, '2026-07-17 09:12:11'),
(198, 106, 1012, 1300.00, '2026-07-17 09:12:11'),
(199, 107, 1475, 975.00, '2026-07-17 09:13:23'),
(200, 107, 1476, 975.00, '2026-07-17 09:13:23'),
(201, 107, 1477, 975.00, '2026-07-17 09:13:23'),
(202, 108, 829, 1250.00, '2026-07-17 09:14:40'),
(203, 108, 830, 1250.00, '2026-07-17 09:14:40'),
(204, 108, 831, 1250.00, '2026-07-17 09:14:40'),
(205, 108, 832, 1250.00, '2026-07-17 09:14:40'),
(206, 109, 834, 1250.00, '2026-07-17 09:14:44'),
(207, 109, 835, 1250.00, '2026-07-17 09:14:44'),
(208, 109, 836, 1250.00, '2026-07-17 09:14:44'),
(209, 109, 837, 1250.00, '2026-07-17 09:14:44'),
(210, 110, 839, 1250.00, '2026-07-17 09:14:51'),
(211, 110, 840, 1250.00, '2026-07-17 09:14:51'),
(212, 110, 841, 1250.00, '2026-07-17 09:14:51'),
(213, 110, 842, 1250.00, '2026-07-17 09:14:51'),
(214, 111, 844, 1250.00, '2026-07-17 09:14:57'),
(215, 111, 845, 1250.00, '2026-07-17 09:14:57'),
(216, 111, 846, 1250.00, '2026-07-17 09:14:57'),
(217, 111, 847, 1250.00, '2026-07-17 09:14:57'),
(218, 112, 849, 1250.00, '2026-07-17 09:15:10'),
(219, 112, 850, 1250.00, '2026-07-17 09:15:10'),
(220, 112, 851, 1250.00, '2026-07-17 09:15:10'),
(221, 113, 854, 1250.00, '2026-07-17 09:15:54'),
(222, 113, 855, 1250.00, '2026-07-17 09:15:54'),
(223, 113, 856, 1250.00, '2026-07-17 09:15:54'),
(224, 113, 857, 1250.00, '2026-07-17 09:15:54'),
(225, 113, 858, 1250.00, '2026-07-17 09:15:54'),
(226, 114, 859, 1250.00, '2026-07-17 09:16:21'),
(227, 114, 860, 1250.00, '2026-07-17 09:16:21'),
(228, 114, 861, 1250.00, '2026-07-17 09:16:21'),
(229, 114, 862, 1250.00, '2026-07-17 09:16:21'),
(230, 115, 864, 1250.00, '2026-07-17 09:16:36'),
(231, 115, 865, 1250.00, '2026-07-17 09:16:36'),
(232, 115, 866, 1250.00, '2026-07-17 09:16:36'),
(233, 115, 867, 1250.00, '2026-07-17 09:16:36'),
(234, 116, 869, 1250.00, '2026-07-17 09:16:52'),
(235, 116, 870, 1250.00, '2026-07-17 09:16:52'),
(236, 116, 871, 1250.00, '2026-07-17 09:16:52'),
(237, 116, 872, 1250.00, '2026-07-17 09:16:52'),
(238, 117, 874, 1250.00, '2026-07-17 09:17:05'),
(239, 117, 875, 1250.00, '2026-07-17 09:17:05'),
(240, 117, 876, 1250.00, '2026-07-17 09:17:05'),
(241, 117, 877, 1250.00, '2026-07-17 09:17:05'),
(242, 117, 878, 1250.00, '2026-07-17 09:17:05'),
(243, 118, 879, 1250.00, '2026-07-17 09:17:24'),
(244, 118, 880, 1250.00, '2026-07-17 09:17:24'),
(245, 118, 881, 1250.00, '2026-07-17 09:17:24'),
(246, 119, 889, 1250.00, '2026-07-17 09:18:08'),
(247, 119, 890, 1250.00, '2026-07-17 09:18:08'),
(248, 119, 891, 1250.00, '2026-07-17 09:18:08'),
(249, 119, 892, 1250.00, '2026-07-17 09:18:08'),
(250, 120, 895, 1250.00, '2026-07-17 09:18:33'),
(251, 120, 896, 1250.00, '2026-07-17 09:18:33'),
(252, 120, 897, 1250.00, '2026-07-17 09:18:33'),
(253, 121, 1480, 1250.00, '2026-07-17 09:21:29'),
(254, 122, 764, 1190.00, '2026-07-17 17:48:35'),
(255, 122, 765, 1190.00, '2026-07-17 17:48:35'),
(256, 122, 766, 1190.00, '2026-07-17 17:48:35'),
(257, 122, 767, 1190.00, '2026-07-17 17:48:35'),
(258, 123, 769, 1190.00, '2026-07-17 17:48:52'),
(259, 123, 770, 1190.00, '2026-07-17 17:48:52'),
(260, 124, 774, 1190.00, '2026-07-17 17:49:09'),
(261, 124, 775, 1190.00, '2026-07-17 17:49:09'),
(262, 124, 776, 1190.00, '2026-07-17 17:49:09'),
(263, 124, 777, 1190.00, '2026-07-17 17:49:09'),
(264, 125, 779, 1190.00, '2026-07-17 17:49:36'),
(265, 125, 780, 1190.00, '2026-07-17 17:49:36'),
(266, 126, 784, 595.00, '2026-07-17 17:50:08'),
(267, 126, 785, 595.00, '2026-07-17 17:50:08'),
(268, 126, 786, 595.00, '2026-07-17 17:50:08'),
(269, 126, 787, 595.00, '2026-07-17 17:50:08'),
(270, 127, 789, 1190.00, '2026-07-17 17:51:18'),
(271, 127, 790, 1190.00, '2026-07-17 17:51:18'),
(272, 127, 791, 1190.00, '2026-07-17 17:51:18'),
(273, 127, 792, 1190.00, '2026-07-17 17:51:18'),
(274, 128, 794, 1190.00, '2026-07-17 17:51:29'),
(275, 128, 795, 1190.00, '2026-07-17 17:51:29'),
(276, 128, 796, 1190.00, '2026-07-17 17:51:29'),
(277, 128, 797, 1190.00, '2026-07-17 17:51:29'),
(278, 128, 798, 1190.00, '2026-07-17 17:51:29'),
(279, 129, 804, 1190.00, '2026-07-17 17:51:57'),
(280, 129, 805, 1190.00, '2026-07-17 17:51:57'),
(281, 129, 806, 1190.00, '2026-07-17 17:51:57'),
(282, 129, 807, 1190.00, '2026-07-17 17:51:57'),
(283, 130, 809, 1190.00, '2026-07-17 17:52:10'),
(284, 130, 810, 1190.00, '2026-07-17 17:52:10'),
(285, 130, 811, 1190.00, '2026-07-17 17:52:10'),
(286, 130, 812, 1190.00, '2026-07-17 17:52:10'),
(287, 131, 814, 1190.00, '2026-07-17 17:52:24'),
(288, 131, 815, 1190.00, '2026-07-17 17:52:24'),
(289, 131, 816, 1190.00, '2026-07-17 17:52:24'),
(290, 131, 817, 1190.00, '2026-07-17 17:52:24'),
(291, 132, 629, 1140.00, '2026-07-17 17:53:54'),
(292, 132, 630, 1140.00, '2026-07-17 17:53:54'),
(293, 132, 631, 1140.00, '2026-07-17 17:53:54'),
(294, 132, 632, 1140.00, '2026-07-17 17:53:54'),
(295, 133, 634, 1140.00, '2026-07-17 17:54:07'),
(296, 133, 635, 1140.00, '2026-07-17 17:54:07'),
(297, 133, 636, 1140.00, '2026-07-17 17:54:07'),
(298, 133, 637, 1140.00, '2026-07-17 17:54:07'),
(299, 134, 649, 1140.00, '2026-07-17 17:56:15'),
(300, 134, 650, 1140.00, '2026-07-17 17:56:15'),
(301, 134, 651, 1140.00, '2026-07-17 17:56:15'),
(302, 134, 652, 1140.00, '2026-07-17 17:56:15'),
(303, 134, 653, 1140.00, '2026-07-17 17:56:15'),
(304, 135, 654, 1140.00, '2026-07-17 17:56:32'),
(305, 135, 655, 1140.00, '2026-07-17 17:56:32'),
(306, 135, 656, 1140.00, '2026-07-17 17:56:32'),
(307, 136, 659, 1140.00, '2026-07-17 17:56:49'),
(308, 136, 660, 1140.00, '2026-07-17 17:56:49'),
(309, 137, 665, 1140.00, '2026-07-17 17:57:42'),
(310, 137, 666, 1140.00, '2026-07-17 17:57:42'),
(311, 137, 667, 1140.00, '2026-07-17 17:57:42'),
(312, 138, 674, 1140.00, '2026-07-17 17:59:01'),
(313, 138, 675, 1140.00, '2026-07-17 17:59:01'),
(314, 138, 676, 1140.00, '2026-07-17 17:59:01'),
(315, 139, 684, 1140.00, '2026-07-17 17:59:36'),
(316, 139, 685, 1140.00, '2026-07-17 17:59:36'),
(317, 139, 686, 1140.00, '2026-07-17 17:59:36'),
(318, 140, 689, 1140.00, '2026-07-17 18:00:01'),
(319, 140, 690, 1140.00, '2026-07-17 18:00:01'),
(320, 140, 691, 1140.00, '2026-07-17 18:00:01'),
(321, 140, 692, 1140.00, '2026-07-17 18:00:01'),
(322, 141, 694, 1140.00, '2026-07-17 18:00:18'),
(323, 141, 695, 1140.00, '2026-07-17 18:00:18'),
(324, 141, 696, 1140.00, '2026-07-17 18:00:18'),
(325, 141, 697, 1140.00, '2026-07-17 18:00:18'),
(326, 142, 699, 1140.00, '2026-07-17 18:01:20'),
(327, 142, 700, 1140.00, '2026-07-17 18:01:20'),
(328, 142, 701, 1140.00, '2026-07-17 18:01:20'),
(329, 142, 702, 1140.00, '2026-07-17 18:01:20'),
(330, 142, 703, 1140.00, '2026-07-17 18:01:20'),
(331, 143, 704, 1140.00, '2026-07-17 18:02:05'),
(332, 143, 705, 1140.00, '2026-07-17 18:02:05'),
(333, 144, 709, 1140.00, '2026-07-17 18:02:27'),
(334, 144, 710, 1140.00, '2026-07-17 18:02:27'),
(335, 144, 711, 1140.00, '2026-07-17 18:02:27'),
(336, 144, 712, 1140.00, '2026-07-17 18:02:27'),
(337, 145, 714, 1140.00, '2026-07-17 18:02:54'),
(338, 145, 715, 1140.00, '2026-07-17 18:02:54'),
(339, 145, 716, 1140.00, '2026-07-17 18:02:54'),
(340, 145, 717, 1140.00, '2026-07-17 18:02:54'),
(341, 146, 724, 1140.00, '2026-07-17 18:04:03'),
(342, 146, 725, 1140.00, '2026-07-17 18:04:03'),
(343, 146, 726, 1140.00, '2026-07-17 18:04:03'),
(344, 146, 727, 1140.00, '2026-07-17 18:04:03'),
(345, 146, 728, 1140.00, '2026-07-17 18:04:03'),
(346, 147, 734, 1140.00, '2026-07-17 18:04:29'),
(347, 147, 735, 1140.00, '2026-07-17 18:04:29'),
(348, 147, 736, 1140.00, '2026-07-17 18:04:29'),
(349, 147, 737, 1140.00, '2026-07-17 18:04:29'),
(350, 148, 739, 1140.00, '2026-07-17 18:04:48'),
(351, 148, 740, 1140.00, '2026-07-17 18:04:48'),
(352, 149, 744, 1140.00, '2026-07-17 18:05:06'),
(353, 149, 745, 1140.00, '2026-07-17 18:05:06'),
(354, 150, 749, 1140.00, '2026-07-17 18:05:20'),
(355, 150, 750, 1140.00, '2026-07-17 18:05:20'),
(356, 150, 751, 1140.00, '2026-07-17 18:05:20'),
(357, 150, 752, 1140.00, '2026-07-17 18:05:20'),
(358, 151, 754, 1140.00, '2026-07-17 18:05:32'),
(359, 151, 755, 1140.00, '2026-07-17 18:05:32'),
(360, 152, 459, 1070.00, '2026-07-21 16:57:56'),
(361, 152, 460, 1070.00, '2026-07-21 16:57:56'),
(362, 152, 461, 1070.00, '2026-07-21 16:57:56'),
(363, 152, 462, 1070.00, '2026-07-21 16:57:56'),
(364, 153, 464, 535.00, '2026-07-21 16:58:30'),
(365, 153, 465, 535.00, '2026-07-21 16:58:30'),
(366, 153, 466, 535.00, '2026-07-21 16:58:30'),
(367, 153, 467, 535.00, '2026-07-21 16:58:30'),
(368, 154, 469, 802.50, '2026-07-21 16:59:10'),
(369, 154, 470, 802.50, '2026-07-21 16:59:10'),
(370, 155, 474, 535.00, '2026-07-21 16:59:45'),
(371, 155, 475, 535.00, '2026-07-21 16:59:45'),
(372, 155, 476, 535.00, '2026-07-21 16:59:45'),
(373, 155, 477, 535.00, '2026-07-21 16:59:45'),
(374, 155, 478, 535.00, '2026-07-21 16:59:45'),
(375, 156, 479, 1070.00, '2026-07-21 17:00:23'),
(376, 156, 480, 1070.00, '2026-07-21 17:00:23'),
(377, 156, 481, 1070.00, '2026-07-21 17:00:23'),
(378, 156, 482, 1070.00, '2026-07-21 17:00:23'),
(379, 157, 499, 1070.00, '2026-07-21 17:03:31'),
(380, 157, 500, 1070.00, '2026-07-21 17:03:31'),
(381, 157, 501, 1070.00, '2026-07-21 17:03:31'),
(382, 158, 504, 1070.00, '2026-07-21 17:03:54'),
(383, 158, 505, 1070.00, '2026-07-21 17:03:54'),
(384, 159, 509, 1070.00, '2026-07-21 17:04:21'),
(385, 159, 510, 1070.00, '2026-07-21 17:04:21'),
(386, 159, 511, 1070.00, '2026-07-21 17:04:21'),
(387, 159, 512, 1070.00, '2026-07-21 17:04:21'),
(388, 160, 625, 1090.00, '2026-07-21 17:07:14'),
(389, 160, 626, 1090.00, '2026-07-21 17:07:14'),
(390, 161, 615, 1090.00, '2026-07-21 17:08:01'),
(391, 161, 616, 1090.00, '2026-07-21 17:08:01'),
(392, 161, 617, 1090.00, '2026-07-21 17:08:01'),
(393, 162, 609, 1090.00, '2026-07-21 17:08:35'),
(394, 162, 610, 1090.00, '2026-07-21 17:08:35'),
(395, 162, 611, 1090.00, '2026-07-21 17:08:35'),
(396, 163, 604, 1090.00, '2026-07-21 17:09:11'),
(397, 163, 605, 1090.00, '2026-07-21 17:09:11'),
(398, 163, 606, 1090.00, '2026-07-21 17:09:11'),
(399, 164, 584, 1090.00, '2026-07-21 17:09:41'),
(400, 164, 585, 1090.00, '2026-07-21 17:09:41'),
(401, 165, 574, 1090.00, '2026-07-21 17:10:51'),
(402, 165, 575, 1090.00, '2026-07-21 17:10:51'),
(403, 165, 576, 1090.00, '2026-07-21 17:10:51'),
(404, 165, 577, 1090.00, '2026-07-21 17:10:51'),
(405, 166, 564, 545.00, '2026-07-21 17:11:42'),
(406, 166, 565, 545.00, '2026-07-21 17:11:42'),
(407, 166, 566, 545.00, '2026-07-21 17:11:42'),
(408, 166, 567, 545.00, '2026-07-21 17:11:42'),
(409, 167, 554, 1090.00, '2026-07-21 17:12:43'),
(410, 167, 555, 1090.00, '2026-07-21 17:12:43'),
(411, 167, 556, 1090.00, '2026-07-21 17:12:43'),
(412, 168, 549, 1090.00, '2026-07-21 17:13:34'),
(413, 168, 550, 1090.00, '2026-07-21 17:13:34'),
(414, 168, 551, 1090.00, '2026-07-21 17:13:34'),
(415, 168, 552, 1090.00, '2026-07-21 17:13:34'),
(416, 169, 544, 1090.00, '2026-07-21 17:14:27'),
(417, 169, 545, 1090.00, '2026-07-21 17:14:27'),
(418, 169, 546, 1090.00, '2026-07-21 17:14:27'),
(419, 169, 547, 1090.00, '2026-07-21 17:14:27'),
(420, 169, 548, 1090.00, '2026-07-21 17:14:27'),
(421, 170, 539, 817.50, '2026-07-21 17:15:19'),
(422, 170, 540, 817.50, '2026-07-21 17:15:19'),
(423, 170, 541, 817.50, '2026-07-21 17:15:19'),
(424, 170, 542, 817.50, '2026-07-21 17:15:19'),
(425, 171, 534, 1090.00, '2026-07-21 17:16:33'),
(426, 171, 535, 1090.00, '2026-07-21 17:16:33'),
(427, 171, 536, 1090.00, '2026-07-21 17:16:33'),
(428, 172, 529, 1090.00, '2026-07-21 17:17:00'),
(429, 172, 530, 1090.00, '2026-07-21 17:17:00'),
(430, 172, 531, 1090.00, '2026-07-21 17:17:00'),
(431, 172, 532, 1090.00, '2026-07-21 17:17:00'),
(432, 172, 533, 1090.00, '2026-07-21 17:17:00'),
(433, 173, 519, 1090.00, '2026-07-21 17:17:22'),
(434, 173, 520, 1090.00, '2026-07-21 17:17:22'),
(435, 174, 1312, 1000.00, '2026-07-26 14:55:52'),
(436, 174, 1313, 1000.00, '2026-07-26 14:55:52'),
(437, 174, 1314, 1000.00, '2026-07-26 14:55:52');

-- --------------------------------------------------------

--
-- Table structure for table `fee_collection_assignments`
--

CREATE TABLE `fee_collection_assignments` (
  `id` int(11) NOT NULL,
  `class_section_id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `assigned_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fee_collection_lines`
--

CREATE TABLE `fee_collection_lines` (
  `id` int(11) NOT NULL,
  `fee_collection_id` int(11) NOT NULL,
  `fee_invoice_line_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fee_collection_lines`
--

INSERT INTO `fee_collection_lines` (`id`, `fee_collection_id`, `fee_invoice_line_id`, `amount`) VALUES
(1, 175, 1699, 380.00),
(3, 177, 1616, 380.00),
(4, 178, 1620, 380.00),
(8, 182, 1755, 400.00),
(9, 183, 1622, 380.00),
(10, 184, 1318, 500.00),
(11, 185, 1316, 500.00),
(12, 185, 1317, 380.00),
(13, 186, 1334, 1000.00),
(14, 186, 1621, 380.00),
(15, 187, 1624, 380.00),
(16, 188, 1348, 1000.00),
(17, 188, 1349, 1000.00),
(18, 188, 1625, 380.00),
(19, 189, 1360, 500.00),
(20, 189, 1361, 500.00),
(21, 189, 1362, 500.00),
(22, 189, 1363, 500.00),
(23, 189, 1628, 380.00),
(24, 190, 1626, 380.00),
(25, 191, 1627, 380.00),
(26, 192, 774, 1190.00),
(27, 192, 775, 400.00),
(28, 193, 1613, 500.00),
(29, 193, 1614, 500.00),
(30, 193, 1615, 500.00),
(31, 193, 1618, 380.00),
(32, 194, 1336, 1000.00),
(33, 195, 1340, 1000.00),
(34, 195, 1341, 1000.00),
(35, 195, 1342, 1000.00),
(36, 195, 1623, 380.00),
(37, 196, 1343, 1000.00),
(38, 197, 1344, 1000.00),
(39, 197, 1345, 1000.00),
(40, 197, 1346, 1000.00),
(41, 198, 1631, 380.00),
(42, 199, 899, 1300.00),
(43, 199, 900, 400.00);

-- --------------------------------------------------------

--
-- Table structure for table `fee_custom_fines`
--

CREATE TABLE `fee_custom_fines` (
  `id` int(11) NOT NULL,
  `fee_invoice_id` int(11) NOT NULL,
  `fine_type` varchar(120) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `added_at` datetime NOT NULL DEFAULT current_timestamp(),
  `added_by_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fee_discount_rules`
--

CREATE TABLE `fee_discount_rules` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `is_percent` tinyint(4) NOT NULL DEFAULT 1,
  `amount` decimal(10,2) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `student_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'If set, discount applies only to this student',
  `class_section_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'If set, discount applies only to students in this class/section'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fee_fine_rules`
--

CREATE TABLE `fee_fine_rules` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `daily_fine_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fee_handovers`
--

CREATE TABLE `fee_handovers` (
  `id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `handed_over_by_user_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `handed_over_to_user_id` int(11) NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `status` enum('pending','confirmed','rejected') NOT NULL DEFAULT 'pending',
  `confirmed_by_user_id` int(11) DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `rejection_reason` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `fee_handovers`
--

INSERT INTO `fee_handovers` (`id`, `staff_profile_id`, `handed_over_by_user_id`, `amount`, `handed_over_to_user_id`, `note`, `status`, `confirmed_by_user_id`, `confirmed_at`, `rejection_reason`, `created_at`, `updated_at`) VALUES
(1, 7, 6, 440.00, 4, NULL, 'rejected', 4, '2026-08-11 12:05:26', 'Test', '2026-08-11 12:03:37', '2026-08-11 12:05:26'),
(2, 7, 6, 440.00, 4, NULL, 'confirmed', 4, '2026-08-11 12:06:29', NULL, '2026-08-11 12:06:06', '2026-08-11 12:06:29');

-- --------------------------------------------------------

--
-- Table structure for table `fee_invoices`
--

CREATE TABLE `fee_invoices` (
  `id` int(11) NOT NULL,
  `invoice_no` varchar(30) NOT NULL,
  `student_id` int(11) NOT NULL,
  `academic_year_id` int(11) DEFAULT NULL,
  `issued_at` datetime NOT NULL DEFAULT current_timestamp(),
  `due_date` date DEFAULT NULL,
  `status` enum('open','paid','cancelled') NOT NULL DEFAULT 'open',
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_due` decimal(10,2) NOT NULL DEFAULT 0.00,
  `fine_applied` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_by_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fee_invoices`
--

INSERT INTO `fee_invoices` (`id`, `invoice_no`, `student_id`, `academic_year_id`, `issued_at`, `due_date`, `status`, `total_amount`, `total_discount`, `total_due`, `fine_applied`, `created_by_user_id`) VALUES
(249, 'INV-20260716-387783', 627, 1, '2026-07-16 16:32:38', '2026-07-26', 'open', 5680.00, 0.00, 5680.00, 0.00, 4),
(250, 'INV-20260716-858231', 628, 1, '2026-07-16 16:32:38', '2026-07-26', 'open', 5680.00, 0.00, 5680.00, 0.00, 4),
(251, 'INV-20260716-642264', 629, 1, '2026-07-16 16:32:38', '2026-07-26', 'open', 5680.00, 0.00, 5680.00, 0.00, 4),
(252, 'INV-20260716-046474', 630, 1, '2026-07-16 16:32:38', '2026-07-26', 'open', 4620.00, 0.00, 4620.00, 0.00, 4),
(253, 'INV-20260716-334517', 631, 1, '2026-07-16 16:32:38', '2026-07-26', 'paid', 0.00, 0.00, 0.00, 0.00, 4),
(254, 'INV-20260716-586225', 632, 1, '2026-07-16 16:32:38', '2026-07-26', 'paid', 0.00, 0.00, 0.00, 0.00, 4),
(255, 'INV-20260716-979586', 633, 1, '2026-07-16 16:32:38', '2026-07-26', 'paid', 0.00, 0.00, 0.00, 0.00, 4),
(256, 'INV-20260716-814707', 634, 1, '2026-07-16 16:32:38', '2026-07-26', 'open', 5680.00, 0.00, 5680.00, 0.00, 4),
(257, 'INV-20260716-911302', 635, 1, '2026-07-16 16:32:38', '2026-07-26', 'open', 5680.00, 0.00, 5680.00, 0.00, 4),
(258, 'INV-20260716-210237', 636, 1, '2026-07-16 16:32:38', '2026-07-26', 'paid', 5300.00, 0.00, 5300.00, 0.00, 4),
(259, 'INV-20260716-640563', 637, 1, '2026-07-16 16:32:38', '2026-07-26', 'open', 5680.00, 0.00, 5680.00, 0.00, 4),
(261, 'INV-20260716-566089', 639, 1, '2026-07-16 16:32:38', '2026-07-26', 'open', 5680.00, 0.00, 5680.00, 0.00, 4),
(262, 'INV-20260716-527511', 640, 1, '2026-07-16 16:32:38', '2026-07-26', 'open', 5680.00, 0.00, 5680.00, 0.00, 4),
(265, 'INV-20260716-743802', 643, 1, '2026-07-16 16:32:38', '2026-07-26', 'paid', 1060.00, 0.00, 1060.00, 0.00, 4),
(266, 'INV-20260716-118108', 638, 1, '2026-07-16 17:00:25', '2026-07-26', 'open', 5680.00, 2650.00, 3030.00, 0.00, 4),
(267, 'INV-20260716-264450', 641, 1, '2026-07-16 17:03:52', '2026-07-26', 'paid', 5300.00, 5300.00, 0.00, 0.00, 4),
(268, 'INV-20260716-649046', 642, 1, '2026-07-16 17:04:18', '2026-07-26', 'open', 5680.00, 2650.00, 3030.00, 0.00, 4),
(269, 'INV-20260716-129230', 644, 1, '2026-07-16 17:10:42', '2026-07-26', 'open', 5730.00, 0.00, 5730.00, 0.00, 4),
(270, 'INV-20260716-521508', 645, 1, '2026-07-16 17:10:42', '2026-07-26', 'open', 5730.00, 2675.00, 3055.00, 0.00, 4),
(271, 'INV-20260716-519362', 646, 1, '2026-07-16 17:10:42', '2026-07-26', 'open', 5730.00, 1337.50, 4392.50, 0.00, 4),
(272, 'INV-20260716-984384', 647, 1, '2026-07-16 17:10:42', '2026-07-26', 'paid', 5350.00, 2675.00, 2675.00, 0.00, 4),
(273, 'INV-20260716-728331', 648, 1, '2026-07-16 17:10:42', '2026-07-26', 'open', 5730.00, 0.00, 5730.00, 0.00, 4),
(274, 'INV-20260716-407437', 649, 1, '2026-07-16 17:10:42', '2026-07-26', 'open', 5730.00, 0.00, 5730.00, 0.00, 4),
(275, 'INV-20260716-880377', 650, 1, '2026-07-16 17:10:42', '2026-07-26', 'open', 5730.00, 0.00, 5730.00, 0.00, 4),
(276, 'INV-20260716-221071', 651, 1, '2026-07-16 17:10:42', '2026-07-26', 'open', 5730.00, 0.00, 5730.00, 0.00, 4),
(277, 'INV-20260716-971578', 652, 1, '2026-07-16 17:10:42', '2026-07-26', 'open', 5730.00, 0.00, 5730.00, 0.00, 4),
(278, 'INV-20260716-000840', 653, 1, '2026-07-16 17:10:42', '2026-07-26', 'open', 5730.00, 0.00, 5730.00, 0.00, 4),
(279, 'INV-20260716-807591', 654, 1, '2026-07-16 17:10:43', '2026-07-26', 'open', 5730.00, 0.00, 5730.00, 0.00, 4),
(280, 'INV-20260716-981578', 655, 1, '2026-07-16 17:10:43', '2026-07-26', 'open', 5730.00, 1337.50, 4392.50, 0.00, 4),
(281, 'INV-20260716-809840', 656, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 5830.00, 0.00, 5830.00, 0.00, 4),
(282, 'INV-20260716-610960', 657, 1, '2026-07-16 17:34:45', '2026-07-26', 'paid', 5450.00, 5450.00, 0.00, 0.00, 4),
(283, 'INV-20260716-091331', 658, 1, '2026-07-16 17:34:45', '2026-07-26', 'paid', 5450.00, 0.00, 5450.00, 0.00, 4),
(284, 'INV-20260716-964335', 659, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 5830.00, 0.00, 5830.00, 0.00, 4),
(285, 'INV-20260716-647821', 660, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 5830.00, 1362.50, 4467.50, 0.00, 4),
(286, 'INV-20260716-171585', 661, 1, '2026-07-16 17:34:45', '2026-07-26', 'paid', 5450.00, 0.00, 5450.00, 0.00, 4),
(287, 'INV-20260716-572639', 662, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 5830.00, 0.00, 5830.00, 0.00, 4),
(288, 'INV-20260716-907573', 663, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 5830.00, 0.00, 5830.00, 0.00, 4),
(289, 'INV-20260716-203963', 664, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 5830.00, 0.00, 5830.00, 0.00, 4),
(290, 'INV-20260716-613764', 665, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 5830.00, 2725.00, 3105.00, 0.00, 4),
(291, 'INV-20260716-347124', 666, 1, '2026-07-16 17:34:45', '2026-07-26', 'paid', 5450.00, 5450.00, 0.00, 0.00, 4),
(292, 'INV-20260716-217001', 667, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 5830.00, 0.00, 5830.00, 0.00, 4),
(293, 'INV-20260716-477165', 668, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 5830.00, 0.00, 5830.00, 0.00, 4),
(294, 'INV-20260716-144586', 669, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 5830.00, 0.00, 5830.00, 0.00, 4),
(295, 'INV-20260716-825473', 670, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 5830.00, 0.00, 5830.00, 0.00, 4),
(296, 'INV-20260716-687030', 671, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 5830.00, 0.00, 5830.00, 0.00, 4),
(297, 'INV-20260716-028326', 672, 1, '2026-07-16 17:34:45', '2026-07-26', 'paid', 5450.00, 5450.00, 0.00, 0.00, 4),
(298, 'INV-20260716-179840', 673, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 5830.00, 0.00, 5830.00, 0.00, 4),
(299, 'INV-20260716-809843', 674, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 5830.00, 0.00, 5830.00, 0.00, 4),
(300, 'INV-20260716-896491', 675, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 4740.00, 0.00, 4740.00, 0.00, 4),
(301, 'INV-20260716-314530', 676, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 5830.00, 0.00, 5830.00, 0.00, 4),
(302, 'INV-20260716-958438', 677, 1, '2026-07-16 17:34:45', '2026-07-26', 'open', 4740.00, 0.00, 4740.00, 0.00, 4),
(303, 'INV-20260716-131985', 678, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(304, 'INV-20260716-217331', 679, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(305, 'INV-20260716-538093', 680, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(306, 'INV-20260716-402204', 681, 1, '2026-07-16 17:35:01', '2026-07-26', 'paid', 5700.00, 5700.00, 0.00, 0.00, 4),
(307, 'INV-20260716-939083', 682, 1, '2026-07-16 17:35:01', '2026-07-26', 'paid', 5700.00, 0.00, 5700.00, 0.00, 4),
(308, 'INV-20260716-930370', 683, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(309, 'INV-20260716-261601', 684, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(310, 'INV-20260716-527778', 685, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 4940.00, 0.00, 4940.00, 0.00, 4),
(311, 'INV-20260716-068733', 686, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(312, 'INV-20260716-790940', 687, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(313, 'INV-20260716-651349', 688, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(314, 'INV-20260716-925878', 689, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(315, 'INV-20260716-441520', 690, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(316, 'INV-20260716-113678', 691, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(317, 'INV-20260716-085258', 692, 1, '2026-07-16 17:35:01', '2026-07-26', 'paid', 5700.00, 0.00, 5700.00, 0.00, 4),
(318, 'INV-20260716-688042', 693, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(319, 'INV-20260716-277305', 694, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(320, 'INV-20260716-933849', 695, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(321, 'INV-20260716-697503', 696, 1, '2026-07-16 17:35:01', '2026-07-26', 'paid', 5700.00, 5700.00, 0.00, 0.00, 4),
(322, 'INV-20260716-092547', 697, 1, '2026-07-16 17:35:01', '2026-07-26', 'paid', 5700.00, 0.00, 5700.00, 0.00, 4),
(323, 'INV-20260716-386457', 698, 1, '2026-07-16 17:35:01', '2026-07-26', 'paid', 5700.00, 5700.00, 0.00, 0.00, 4),
(324, 'INV-20260716-882706', 699, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(325, 'INV-20260716-666075', 700, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(326, 'INV-20260716-903025', 701, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(327, 'INV-20260716-437282', 702, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(328, 'INV-20260716-933503', 703, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(329, 'INV-20260716-336366', 704, 1, '2026-07-16 17:35:01', '2026-07-26', 'open', 6080.00, 0.00, 6080.00, 0.00, 4),
(330, 'INV-20260716-922295', 705, 1, '2026-07-16 17:35:20', '2026-07-26', 'open', 6350.00, 0.00, 6350.00, 0.00, 4),
(331, 'INV-20260716-750285', 706, 1, '2026-07-16 17:35:20', '2026-07-26', 'open', 6350.00, 0.00, 6350.00, 0.00, 4),
(332, 'INV-20260716-579296', 707, 1, '2026-07-16 17:35:20', '2026-07-26', 'paid', 6350.00, 0.00, 6350.00, 0.00, 4),
(333, 'INV-20260716-797168', 708, 1, '2026-07-16 17:35:20', '2026-07-26', 'open', 6350.00, 0.00, 6350.00, 0.00, 4),
(334, 'INV-20260716-914517', 709, 1, '2026-07-16 17:35:20', '2026-07-26', 'open', 6350.00, 2975.00, 3375.00, 0.00, 4),
(335, 'INV-20260716-999703', 710, 1, '2026-07-16 17:35:20', '2026-07-26', 'open', 6350.00, 0.00, 6350.00, 0.00, 4),
(336, 'INV-20260716-278158', 711, 1, '2026-07-16 17:35:20', '2026-07-26', 'paid', 5950.00, 0.00, 5950.00, 0.00, 4),
(337, 'INV-20260716-058862', 712, 1, '2026-07-16 17:35:20', '2026-07-26', 'open', 6350.00, 0.00, 6350.00, 0.00, 4),
(338, 'INV-20260716-863901', 713, 1, '2026-07-16 17:35:20', '2026-07-26', 'open', 6350.00, 0.00, 6350.00, 0.00, 4),
(339, 'INV-20260716-139349', 714, 1, '2026-07-16 17:35:20', '2026-07-26', 'open', 6350.00, 0.00, 6350.00, 0.00, 4),
(340, 'INV-20260716-153148', 715, 1, '2026-07-16 17:35:20', '2026-07-26', 'open', 6350.00, 0.00, 6350.00, 0.00, 4),
(341, 'INV-20260716-051902', 716, 1, '2026-07-16 17:35:20', '2026-07-26', 'open', 6350.00, 0.00, 6350.00, 0.00, 4),
(342, 'INV-20260716-561373', 717, 1, '2026-07-16 17:35:20', '2026-07-26', 'open', 6350.00, 0.00, 6350.00, 0.00, 4),
(343, 'INV-20260716-839655', 718, 1, '2026-07-16 17:36:02', '2026-07-26', 'open', 6650.00, 0.00, 6650.00, 0.00, 4),
(344, 'INV-20260716-717907', 719, 1, '2026-07-16 17:36:02', '2026-07-26', 'open', 6650.00, 0.00, 6650.00, 0.00, 4),
(345, 'INV-20260716-586243', 720, 1, '2026-07-16 17:36:02', '2026-07-26', 'open', 6650.00, 0.00, 6650.00, 0.00, 4),
(346, 'INV-20260716-303576', 721, 1, '2026-07-16 17:36:02', '2026-07-26', 'open', 6650.00, 0.00, 6650.00, 0.00, 4),
(347, 'INV-20260716-278537', 722, 1, '2026-07-16 17:36:02', '2026-07-26', 'open', 6650.00, 0.00, 6650.00, 0.00, 4),
(348, 'INV-20260716-733529', 723, 1, '2026-07-16 17:36:02', '2026-07-26', 'paid', 6250.00, 0.00, 6250.00, 0.00, 4),
(349, 'INV-20260716-887267', 724, 1, '2026-07-16 17:36:02', '2026-07-26', 'open', 6650.00, 0.00, 6650.00, 0.00, 4),
(350, 'INV-20260716-477077', 725, 1, '2026-07-16 17:36:02', '2026-07-26', 'open', 6650.00, 0.00, 6650.00, 0.00, 4),
(351, 'INV-20260716-160574', 726, 1, '2026-07-16 17:36:02', '2026-07-26', 'open', 6650.00, 0.00, 6650.00, 0.00, 4),
(352, 'INV-20260716-135560', 727, 1, '2026-07-16 17:36:02', '2026-07-26', 'paid', 6250.00, 0.00, 6250.00, 0.00, 4),
(353, 'INV-20260716-841998', 728, 1, '2026-07-16 17:36:02', '2026-07-26', 'open', 6650.00, 0.00, 6650.00, 0.00, 4),
(354, 'INV-20260716-373971', 729, 1, '2026-07-16 17:36:02', '2026-07-26', 'paid', 6250.00, 6250.00, 0.00, 0.00, 4),
(355, 'INV-20260716-587219', 730, 1, '2026-07-16 17:36:02', '2026-07-26', 'open', 6650.00, 0.00, 6650.00, 0.00, 4),
(356, 'INV-20260716-284938', 731, 1, '2026-07-16 17:36:02', '2026-07-26', 'open', 5400.00, 0.00, 5400.00, 0.00, 4),
(357, 'INV-20260716-308789', 732, 1, '2026-07-16 17:36:21', '2026-07-26', 'paid', 6900.00, 0.00, 6900.00, 0.00, 4),
(358, 'INV-20260716-995216', 733, 1, '2026-07-16 17:36:21', '2026-07-26', 'paid', 5200.00, 0.00, 5200.00, 0.00, 4),
(359, 'INV-20260716-628218', 734, 1, '2026-07-16 17:36:21', '2026-07-26', 'open', 6900.00, 0.00, 6900.00, 0.00, 4),
(360, 'INV-20260716-742223', 735, 1, '2026-07-16 17:36:21', '2026-07-26', 'open', 6900.00, 0.00, 6900.00, 0.00, 4),
(361, 'INV-20260716-549827', 736, 1, '2026-07-16 17:36:21', '2026-07-26', 'open', 6900.00, 0.00, 6900.00, 0.00, 4),
(362, 'INV-20260716-732833', 737, 1, '2026-07-16 17:36:21', '2026-07-26', 'open', 6900.00, 0.00, 6900.00, 0.00, 4),
(364, 'INV-20260716-709305', 739, 1, '2026-07-16 17:36:22', '2026-07-26', 'open', 6900.00, 0.00, 6900.00, 0.00, 4),
(365, 'INV-20260716-777593', 740, 1, '2026-07-16 17:36:22', '2026-07-26', 'open', 6900.00, 0.00, 6900.00, 0.00, 4),
(366, 'INV-20260716-028620', 741, 1, '2026-07-16 17:36:22', '2026-07-26', 'open', 6900.00, 0.00, 6900.00, 0.00, 4),
(367, 'INV-20260716-963406', 742, 1, '2026-07-16 17:36:22', '2026-07-26', 'open', 6900.00, 0.00, 6900.00, 0.00, 4),
(368, 'INV-20260716-916345', 743, 1, '2026-07-16 17:36:22', '2026-07-26', 'paid', 6500.00, 6500.00, 0.00, 0.00, 4),
(369, 'INV-20260716-771236', 744, 1, '2026-07-16 17:36:22', '2026-07-26', 'paid', 6500.00, 6500.00, 0.00, 0.00, 4),
(370, 'INV-20260716-606678', 745, 1, '2026-07-16 17:36:22', '2026-07-26', 'paid', 6500.00, 6500.00, 0.00, 0.00, 4),
(371, 'INV-20260716-653415', 746, 1, '2026-07-16 17:36:22', '2026-07-26', 'open', 6900.00, 0.00, 6900.00, 0.00, 4),
(372, 'INV-20260716-475980', 747, 1, '2026-07-16 17:36:22', '2026-07-26', 'open', 6900.00, 0.00, 6900.00, 0.00, 4),
(373, 'INV-20260716-396025', 748, 1, '2026-07-16 17:36:22', '2026-07-26', 'open', 6900.00, 0.00, 6900.00, 0.00, 4),
(374, 'INV-20260716-436456', 749, 1, '2026-07-16 17:36:22', '2026-07-26', 'open', 6900.00, 0.00, 6900.00, 0.00, 4),
(375, 'INV-20260716-469050', 750, 1, '2026-07-16 17:36:22', '2026-07-26', 'paid', 6500.00, 0.00, 6500.00, 0.00, 4),
(376, 'INV-20260716-849001', 751, 1, '2026-07-16 17:36:22', '2026-07-26', 'open', 6900.00, 0.00, 6900.00, 0.00, 4),
(377, 'INV-20260716-326184', 752, 1, '2026-07-16 17:36:22', '2026-07-26', 'open', 6900.00, 0.00, 6900.00, 0.00, 4),
(378, 'INV-20260716-969622', 753, 1, '2026-07-16 17:36:22', '2026-07-26', 'open', 6900.00, 3250.00, 3650.00, 0.00, 4),
(379, 'INV-20260716-642684', 754, 1, '2026-07-16 17:36:22', '2026-07-26', 'open', 6900.00, 0.00, 6900.00, 0.00, 4),
(380, 'INV-20260716-901774', 755, 1, '2026-07-16 17:36:41', '2026-07-26', 'paid', 7500.00, 7500.00, 0.00, 0.00, 4),
(381, 'INV-20260716-692342', 756, 1, '2026-07-16 17:36:41', '2026-07-26', 'open', 7900.00, 0.00, 7900.00, 0.00, 4),
(382, 'INV-20260716-063547', 757, 1, '2026-07-16 17:36:41', '2026-07-26', 'open', 7900.00, 0.00, 7900.00, 0.00, 4),
(383, 'INV-20260716-622110', 758, 1, '2026-07-16 17:36:41', '2026-07-26', 'open', 7900.00, 0.00, 7900.00, 0.00, 4),
(384, 'INV-20260716-481390', 759, 1, '2026-07-16 17:36:41', '2026-07-26', 'open', 7900.00, 0.00, 7900.00, 0.00, 4),
(385, 'INV-20260716-988109', 760, 1, '2026-07-16 17:36:41', '2026-07-26', 'paid', 7500.00, 7500.00, 0.00, 0.00, 4),
(386, 'INV-20260716-123170', 761, 1, '2026-07-16 17:36:41', '2026-07-26', 'open', 6400.00, 0.00, 6400.00, 0.00, 4),
(387, 'INV-20260716-430545', 762, 1, '2026-07-16 17:36:41', '2026-07-26', 'open', 7900.00, 0.00, 7900.00, 0.00, 4),
(388, 'INV-20260716-403267', 763, 1, '2026-07-16 17:36:41', '2026-07-26', 'paid', 6000.00, 0.00, 6000.00, 0.00, 4),
(389, 'INV-20260716-632229', 764, 1, '2026-07-16 17:36:41', '2026-07-26', 'open', 7900.00, 0.00, 7900.00, 0.00, 4),
(390, 'INV-20260716-331434', 765, 1, '2026-07-16 17:36:41', '2026-07-26', 'open', 7900.00, 0.00, 7900.00, 0.00, 4),
(391, 'INV-20260716-641807', 766, 1, '2026-07-16 17:36:41', '2026-07-26', 'open', 7900.00, 0.00, 7900.00, 0.00, 4),
(392, 'INV-20260716-775476', 767, 1, '2026-07-16 17:36:41', '2026-07-26', 'open', 7900.00, 0.00, 7900.00, 0.00, 4),
(430, 'INV-20260717-069183', 591, 1, '2026-07-17 08:04:39', '2026-07-27', 'paid', 3000.00, 0.00, 3000.00, 0.00, 4),
(431, 'INV-20260717-651011', 592, 1, '2026-07-17 08:04:39', '2026-07-27', 'paid', 4380.00, 2000.00, 2380.00, 0.00, 4),
(432, 'INV-20260717-989380', 595, 1, '2026-07-17 08:04:39', '2026-07-27', 'open', 4000.00, 2000.00, 2000.00, 0.00, 4),
(433, 'INV-20260717-585333', 596, 1, '2026-07-17 08:04:39', '2026-07-27', 'paid', 4000.00, 4000.00, 0.00, 0.00, 4),
(434, 'INV-20260717-291110', 597, 1, '2026-07-17 08:04:39', '2026-07-27', 'paid', 4000.00, 0.00, 4000.00, 0.00, 4),
(435, 'INV-20260717-338359', 598, 1, '2026-07-17 08:04:39', '2026-07-27', 'open', 4380.00, 0.00, 4380.00, 0.00, 4),
(436, 'INV-20260717-724411', 599, 1, '2026-07-17 08:04:39', '2026-07-27', 'paid', 4380.00, 0.00, 4380.00, 0.00, 4),
(437, 'INV-20260717-071171', 600, 1, '2026-07-17 08:04:39', '2026-07-27', 'paid', 4380.00, 0.00, 4380.00, 0.00, 4),
(438, 'INV-20260717-218965', 602, 1, '2026-07-17 08:04:39', '2026-07-27', 'paid', 4380.00, 0.00, 4380.00, 0.00, 4),
(439, 'INV-20260717-728779', 603, 1, '2026-07-17 08:04:39', '2026-07-27', 'open', 4380.00, 0.00, 4380.00, 0.00, 4),
(440, 'INV-20260717-212465', 604, 1, '2026-07-17 08:04:39', '2026-07-27', 'open', 4380.00, 0.00, 4380.00, 0.00, 4),
(441, 'INV-20260717-688546', 605, 1, '2026-07-17 08:04:39', '2026-07-27', 'paid', 4000.00, 4000.00, 0.00, 0.00, 4),
(442, 'INV-20260717-184048', 606, 1, '2026-07-17 08:04:39', '2026-07-27', 'paid', 4380.00, 2000.00, 2380.00, 0.00, 4),
(443, 'INV-20260717-414342', 607, 1, '2026-07-17 08:04:39', '2026-07-27', 'paid', 4000.00, 4000.00, 0.00, 0.00, 4),
(444, 'INV-20260717-462264', 608, 1, '2026-07-17 08:04:39', '2026-07-27', 'open', 4380.00, 0.00, 4380.00, 0.00, 4),
(445, 'INV-20260717-270611', 609, 1, '2026-07-17 08:04:39', '2026-07-27', 'paid', 4000.00, 4000.00, 0.00, 0.00, 4),
(446, 'INV-20260717-092414', 610, 1, '2026-07-17 08:04:39', '2026-07-27', 'open', 4380.00, 0.00, 4380.00, 0.00, 4),
(447, 'INV-20260717-946812', 597, 1, '2026-07-17 08:23:57', '2026-07-27', 'paid', 5000.00, 0.00, 5000.00, 0.00, 4),
(448, 'INV-20260717-361121', 597, 1, '2026-07-17 08:24:23', '2026-07-27', 'paid', 2000.00, 0.00, 2000.00, 0.00, 4),
(449, 'INV-20260717-022723', 611, 1, '2026-07-17 08:30:28', '2026-07-27', 'open', 5630.00, 0.00, 5630.00, 0.00, 4),
(450, 'INV-20260717-357958', 612, 1, '2026-07-17 08:30:28', '2026-07-27', 'open', 5630.00, 0.00, 5630.00, 0.00, 4),
(451, 'INV-20260717-071077', 613, 1, '2026-07-17 08:30:28', '2026-07-27', 'paid', 5250.00, 5250.00, 0.00, 0.00, 4),
(452, 'INV-20260717-886421', 614, 1, '2026-07-17 08:30:28', '2026-07-27', 'open', 5630.00, 2625.00, 3005.00, 0.00, 4),
(453, 'INV-20260717-232408', 615, 1, '2026-07-17 08:30:28', '2026-07-27', 'paid', 5250.00, 5250.00, 0.00, 0.00, 4),
(454, 'INV-20260717-797397', 616, 1, '2026-07-17 08:30:28', '2026-07-27', 'paid', 5250.00, 5250.00, 0.00, 0.00, 4),
(455, 'INV-20260717-564879', 617, 1, '2026-07-17 08:30:28', '2026-07-27', 'open', 4580.00, 2100.00, 2480.00, 0.00, 4),
(456, 'INV-20260717-658465', 618, 1, '2026-07-17 08:30:28', '2026-07-27', 'open', 5630.00, 0.00, 5630.00, 0.00, 4),
(457, 'INV-20260717-734515', 619, 1, '2026-07-17 08:30:28', '2026-07-27', 'open', 5630.00, 2625.00, 3005.00, 0.00, 4),
(458, 'INV-20260717-383091', 620, 1, '2026-07-17 08:30:28', '2026-07-27', 'open', 5630.00, 0.00, 5630.00, 0.00, 4),
(459, 'INV-20260717-664135', 621, 1, '2026-07-17 08:30:28', '2026-07-27', 'open', 5630.00, 2625.00, 3005.00, 0.00, 4),
(460, 'INV-20260717-957455', 622, 1, '2026-07-17 08:30:28', '2026-07-27', 'open', 5630.00, 0.00, 5630.00, 0.00, 4),
(461, 'INV-20260717-550831', 623, 1, '2026-07-17 08:30:28', '2026-07-27', 'open', 5630.00, 0.00, 5630.00, 0.00, 4),
(463, 'INV-20260717-822136', 625, 1, '2026-07-17 08:30:28', '2026-07-27', 'open', 5630.00, 2625.00, 3005.00, 0.00, 4),
(464, 'INV-20260717-987762', 626, 1, '2026-07-17 08:30:28', '2026-07-27', 'open', 4580.00, 0.00, 4580.00, 0.00, 4),
(465, 'INV-20260717-539568', 733, 1, '2026-07-17 08:44:40', '2026-07-27', 'paid', 6500.00, 0.00, 6500.00, 0.00, 4),
(466, 'INV-20260717-559578', 733, 1, '2026-07-17 08:44:53', '2026-07-27', 'paid', 2600.00, 0.00, 2600.00, 0.00, 4),
(468, 'INV-20260717-658344', 738, 1, '2026-07-17 08:49:29', '2026-07-27', 'open', 6900.00, 1625.00, 5275.00, 0.00, 4),
(469, 'INV-20260717-512698', 723, 1, '2026-07-17 09:21:20', '2026-07-27', 'paid', 1250.00, 0.00, 1250.00, 0.00, 4),
(474, 'INV-20260721-170903', 768, 1, '2026-07-21 17:33:19', '2026-07-31', 'open', 12500.00, 0.00, 12500.00, 0.00, 4),
(475, 'INV-20260721-882608', 769, 1, '2026-07-21 17:33:19', '2026-07-31', 'open', 12500.00, 0.00, 12500.00, 0.00, 4),
(476, 'INV-20260721-463155', 770, 1, '2026-07-21 17:33:19', '2026-07-31', 'open', 12500.00, 0.00, 12500.00, 0.00, 4),
(477, 'INV-20260721-440082', 771, 1, '2026-07-21 17:33:19', '2026-07-31', 'open', 12500.00, 0.00, 12500.00, 0.00, 4),
(478, 'INV-20260721-459090', 772, 1, '2026-07-21 17:33:19', '2026-07-31', 'open', 12500.00, 0.00, 12500.00, 0.00, 4),
(479, 'INV-20260721-487275', 773, 1, '2026-07-21 17:33:19', '2026-07-31', 'open', 12500.00, 0.00, 12500.00, 0.00, 4),
(480, 'INV-20260721-221387', 774, 1, '2026-07-21 17:33:19', '2026-07-31', 'open', 12500.00, 0.00, 12500.00, 0.00, 4),
(481, 'INV-20260721-064905', 775, 1, '2026-07-21 17:33:19', '2026-07-31', 'open', 12500.00, 0.00, 12500.00, 0.00, 4),
(482, 'INV-20260721-655988', 776, 1, '2026-07-21 17:33:19', '2026-07-31', 'open', 12500.00, 0.00, 12500.00, 0.00, 4),
(483, 'INV-20260721-407651', 777, 1, '2026-07-21 17:33:19', '2026-07-31', 'open', 12500.00, 0.00, 12500.00, 0.00, 4),
(484, 'INV-20260721-646728', 778, 1, '2026-07-21 17:33:19', '2026-07-31', 'open', 12500.00, 0.00, 12500.00, 0.00, 4),
(485, 'INV-20260721-788516', 779, 1, '2026-07-21 17:33:19', '2026-07-31', 'open', 12500.00, 0.00, 12500.00, 0.00, 4),
(486, 'INV-20260721-419483', 589, 1, '2026-07-21 17:33:41', '2026-07-31', 'open', 11500.00, 0.00, 11500.00, 0.00, 4),
(487, 'INV-20260721-595806', 590, 1, '2026-07-21 17:33:41', '2026-07-31', 'open', 11500.00, 0.00, 11500.00, 0.00, 4),
(488, 'INV-20260721-405848', 780, 1, '2026-07-21 17:33:41', '2026-07-31', 'open', 11500.00, 0.00, 11500.00, 0.00, 4),
(489, 'INV-20260721-517488', 782, 1, '2026-07-21 17:33:41', '2026-07-31', 'open', 11500.00, 0.00, 11500.00, 0.00, 4),
(490, 'INV-20260721-855041', 784, 1, '2026-07-21 17:33:41', '2026-07-31', 'open', 11500.00, 0.00, 11500.00, 0.00, 4),
(491, 'INV-20260721-621716', 785, 1, '2026-07-21 17:33:41', '2026-07-31', 'open', 11500.00, 0.00, 11500.00, 0.00, 4),
(510, 'INV-20260726-138008', 595, 1, '2026-07-26 14:51:24', '2026-08-05', 'paid', 3380.00, 1500.00, 1880.00, 0.00, 20),
(511, 'INV-20260727-065714', 591, 1, '2026-07-26 20:26:39', '2026-08-06', 'paid', 380.00, 0.00, 380.00, 0.00, 261),
(512, 'INV-20260727-137006', 596, 1, '2026-07-26 20:26:39', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(513, 'INV-20260727-781554', 597, 1, '2026-07-26 20:26:39', '2026-08-06', 'paid', 380.00, 0.00, 380.00, 0.00, 261),
(514, 'INV-20260727-577864', 605, 1, '2026-07-26 20:26:39', '2026-08-06', 'paid', 380.00, 0.00, 380.00, 0.00, 261),
(515, 'INV-20260727-327262', 607, 1, '2026-07-26 20:26:39', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(516, 'INV-20260727-107065', 609, 1, '2026-07-26 20:26:39', '2026-08-06', 'paid', 380.00, 0.00, 380.00, 0.00, 261),
(517, 'INV-20260727-505848', 613, 1, '2026-07-26 20:28:42', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(518, 'INV-20260727-643860', 615, 1, '2026-07-26 20:28:42', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(519, 'INV-20260727-228827', 616, 1, '2026-07-26 20:28:42', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(520, 'INV-20260727-416620', 631, 1, '2026-07-26 20:28:51', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(521, 'INV-20260727-786305', 632, 1, '2026-07-26 20:28:51', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(522, 'INV-20260727-869641', 633, 1, '2026-07-26 20:28:51', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(523, 'INV-20260727-752147', 636, 1, '2026-07-26 20:28:51', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(524, 'INV-20260727-953183', 641, 1, '2026-07-26 20:28:51', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(525, 'INV-20260727-129716', 643, 1, '2026-07-26 20:28:51', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(526, 'INV-20260727-561737', 647, 1, '2026-07-26 20:29:02', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(527, 'INV-20260727-518968', 657, 1, '2026-07-26 20:29:14', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(528, 'INV-20260727-310329', 658, 1, '2026-07-26 20:29:14', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(529, 'INV-20260727-385609', 661, 1, '2026-07-26 20:29:14', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(530, 'INV-20260727-794239', 666, 1, '2026-07-26 20:29:14', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(531, 'INV-20260727-310120', 672, 1, '2026-07-26 20:29:14', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(532, 'INV-20260727-991846', 681, 1, '2026-07-26 20:29:33', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(533, 'INV-20260727-687940', 682, 1, '2026-07-26 20:29:33', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(534, 'INV-20260727-560577', 692, 1, '2026-07-26 20:29:33', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(535, 'INV-20260727-230992', 696, 1, '2026-07-26 20:29:33', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(536, 'INV-20260727-339333', 697, 1, '2026-07-26 20:29:33', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(537, 'INV-20260727-427575', 698, 1, '2026-07-26 20:29:33', '2026-08-06', 'open', 380.00, 0.00, 380.00, 0.00, 261),
(538, 'INV-20260727-482069', 711, 1, '2026-07-26 20:29:43', '2026-08-06', 'open', 400.00, 0.00, 400.00, 0.00, 261),
(539, 'INV-20260727-785672', 723, 1, '2026-07-26 20:29:56', '2026-08-06', 'open', 400.00, 0.00, 400.00, 0.00, 261),
(540, 'INV-20260727-990828', 727, 1, '2026-07-26 20:29:56', '2026-08-06', 'open', 400.00, 0.00, 400.00, 0.00, 261),
(541, 'INV-20260727-662062', 729, 1, '2026-07-26 20:29:56', '2026-08-06', 'open', 400.00, 0.00, 400.00, 0.00, 261),
(542, 'INV-20260727-117954', 733, 1, '2026-07-26 20:30:06', '2026-08-06', 'paid', 400.00, 0.00, 400.00, 0.00, 261),
(543, 'INV-20260727-149763', 743, 1, '2026-07-26 20:30:06', '2026-08-06', 'open', 400.00, 0.00, 400.00, 0.00, 261),
(544, 'INV-20260727-600508', 744, 1, '2026-07-26 20:30:06', '2026-08-06', 'open', 400.00, 0.00, 400.00, 0.00, 261),
(545, 'INV-20260727-501280', 745, 1, '2026-07-26 20:30:06', '2026-08-06', 'open', 400.00, 0.00, 400.00, 0.00, 261),
(546, 'INV-20260727-953204', 750, 1, '2026-07-26 20:30:06', '2026-08-06', 'open', 400.00, 0.00, 400.00, 0.00, 261),
(547, 'INV-20260727-341364', 755, 1, '2026-07-26 20:30:23', '2026-08-06', 'open', 400.00, 0.00, 400.00, 0.00, 261),
(549, 'INV-20260727-916033', 763, 1, '2026-07-26 20:30:23', '2026-08-06', 'open', 400.00, 0.00, 400.00, 0.00, 261);

-- --------------------------------------------------------

--
-- Table structure for table `fee_invoice_lines`
--

CREATE TABLE `fee_invoice_lines` (
  `id` int(11) NOT NULL,
  `fee_invoice_id` int(11) NOT NULL,
  `fee_category_id` int(11) NOT NULL,
  `billing_month` tinyint(4) DEFAULT NULL,
  `billing_year` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `base_amount` decimal(10,2) NOT NULL,
  `discount_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `line_total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fee_invoice_lines`
--

INSERT INTO `fee_invoice_lines` (`id`, `fee_invoice_id`, `fee_category_id`, `billing_month`, `billing_year`, `description`, `base_amount`, `discount_amount`, `line_total`) VALUES
(359, 249, 1, NULL, NULL, 'Tuition Fee - March', 1060.00, 0.00, 1060.00),
(360, 249, 1, NULL, NULL, 'Tuition Fee - April', 1060.00, 0.00, 1060.00),
(361, 249, 1, NULL, NULL, 'Tuition Fee - May', 1060.00, 0.00, 1060.00),
(362, 249, 1, NULL, NULL, 'Tuition Fee - June', 1060.00, 0.00, 1060.00),
(363, 249, 1, NULL, NULL, 'Tuition Fee - July', 1060.00, 0.00, 1060.00),
(364, 250, 1, NULL, NULL, 'Tuition Fee - March', 1060.00, 0.00, 1060.00),
(365, 250, 1, NULL, NULL, 'Tuition Fee - April', 1060.00, 0.00, 1060.00),
(366, 250, 1, NULL, NULL, 'Tuition Fee - May', 1060.00, 0.00, 1060.00),
(367, 250, 1, NULL, NULL, 'Tuition Fee - June', 1060.00, 0.00, 1060.00),
(368, 250, 1, NULL, NULL, 'Tuition Fee - July', 1060.00, 0.00, 1060.00),
(369, 251, 1, NULL, NULL, 'Tuition Fee - March', 1060.00, 0.00, 1060.00),
(370, 251, 1, NULL, NULL, 'Tuition Fee - April', 1060.00, 0.00, 1060.00),
(371, 251, 1, NULL, NULL, 'Tuition Fee - May', 1060.00, 0.00, 1060.00),
(372, 251, 1, NULL, NULL, 'Tuition Fee - June', 1060.00, 0.00, 1060.00),
(373, 251, 1, NULL, NULL, 'Tuition Fee - July', 1060.00, 0.00, 1060.00),
(374, 252, 1, NULL, NULL, 'Tuition Fee - March', 0.00, 0.00, 0.00),
(375, 252, 1, NULL, NULL, 'Tuition Fee - April', 1060.00, 0.00, 1060.00),
(376, 252, 1, NULL, NULL, 'Tuition Fee - May', 1060.00, 0.00, 1060.00),
(377, 252, 1, NULL, NULL, 'Tuition Fee - June', 1060.00, 0.00, 1060.00),
(378, 252, 1, NULL, NULL, 'Tuition Fee - July', 1060.00, 0.00, 1060.00),
(379, 253, 1, NULL, NULL, 'Tuition Fee - March', 0.00, 0.00, 0.00),
(380, 253, 1, NULL, NULL, 'Tuition Fee - April', 0.00, 0.00, 0.00),
(381, 253, 1, NULL, NULL, 'Tuition Fee - May', 0.00, 0.00, 0.00),
(382, 253, 1, NULL, NULL, 'Tuition Fee - June', 0.00, 0.00, 0.00),
(383, 253, 1, NULL, NULL, 'Tuition Fee - July', 0.00, 0.00, 0.00),
(384, 254, 1, NULL, NULL, 'Tuition Fee - March', 0.00, 0.00, 0.00),
(385, 254, 1, NULL, NULL, 'Tuition Fee - April', 0.00, 0.00, 0.00),
(386, 254, 1, NULL, NULL, 'Tuition Fee - May', 0.00, 0.00, 0.00),
(387, 254, 1, NULL, NULL, 'Tuition Fee - June', 0.00, 0.00, 0.00),
(388, 254, 1, NULL, NULL, 'Tuition Fee - July', 0.00, 0.00, 0.00),
(389, 255, 1, NULL, NULL, 'Tuition Fee - March', 0.00, 0.00, 0.00),
(390, 255, 1, NULL, NULL, 'Tuition Fee - April', 0.00, 0.00, 0.00),
(391, 255, 1, NULL, NULL, 'Tuition Fee - May', 0.00, 0.00, 0.00),
(392, 255, 1, NULL, NULL, 'Tuition Fee - June', 0.00, 0.00, 0.00),
(393, 255, 1, NULL, NULL, 'Tuition Fee - July', 0.00, 0.00, 0.00),
(394, 256, 1, NULL, NULL, 'Tuition Fee - March', 1060.00, 0.00, 1060.00),
(395, 256, 1, NULL, NULL, 'Tuition Fee - April', 1060.00, 0.00, 1060.00),
(396, 256, 1, NULL, NULL, 'Tuition Fee - May', 1060.00, 0.00, 1060.00),
(397, 256, 1, NULL, NULL, 'Tuition Fee - June', 1060.00, 0.00, 1060.00),
(398, 256, 1, NULL, NULL, 'Tuition Fee - July', 1060.00, 0.00, 1060.00),
(399, 257, 1, NULL, NULL, 'Tuition Fee - March', 1060.00, 0.00, 1060.00),
(400, 257, 1, NULL, NULL, 'Tuition Fee - April', 1060.00, 0.00, 1060.00),
(401, 257, 1, NULL, NULL, 'Tuition Fee - May', 1060.00, 0.00, 1060.00),
(402, 257, 1, NULL, NULL, 'Tuition Fee - June', 1060.00, 0.00, 1060.00),
(403, 257, 1, NULL, NULL, 'Tuition Fee - July', 1060.00, 0.00, 1060.00),
(404, 258, 1, NULL, NULL, 'Tuition Fee - March', 1060.00, 0.00, 1060.00),
(405, 258, 1, NULL, NULL, 'Tuition Fee - April', 1060.00, 0.00, 1060.00),
(406, 258, 1, NULL, NULL, 'Tuition Fee - May', 1060.00, 0.00, 1060.00),
(407, 258, 1, NULL, NULL, 'Tuition Fee - June', 1060.00, 0.00, 1060.00),
(408, 258, 1, NULL, NULL, 'Tuition Fee - July', 1060.00, 0.00, 1060.00),
(409, 259, 1, NULL, NULL, 'Tuition Fee - March', 1060.00, 0.00, 1060.00),
(410, 259, 1, NULL, NULL, 'Tuition Fee - April', 1060.00, 0.00, 1060.00),
(411, 259, 1, NULL, NULL, 'Tuition Fee - May', 1060.00, 0.00, 1060.00),
(412, 259, 1, NULL, NULL, 'Tuition Fee - June', 1060.00, 0.00, 1060.00),
(413, 259, 1, NULL, NULL, 'Tuition Fee - July', 1060.00, 0.00, 1060.00),
(419, 261, 1, NULL, NULL, 'Tuition Fee - March', 1060.00, 0.00, 1060.00),
(420, 261, 1, NULL, NULL, 'Tuition Fee - April', 1060.00, 0.00, 1060.00),
(421, 261, 1, NULL, NULL, 'Tuition Fee - May', 1060.00, 0.00, 1060.00),
(422, 261, 1, NULL, NULL, 'Tuition Fee - June', 1060.00, 0.00, 1060.00),
(423, 261, 1, NULL, NULL, 'Tuition Fee - July', 1060.00, 0.00, 1060.00),
(424, 262, 1, NULL, NULL, 'Tuition Fee - March', 1060.00, 0.00, 1060.00),
(425, 262, 1, NULL, NULL, 'Tuition Fee - April', 1060.00, 0.00, 1060.00),
(426, 262, 1, NULL, NULL, 'Tuition Fee - May', 1060.00, 0.00, 1060.00),
(427, 262, 1, NULL, NULL, 'Tuition Fee - June', 1060.00, 0.00, 1060.00),
(428, 262, 1, NULL, NULL, 'Tuition Fee - July', 1060.00, 0.00, 1060.00),
(439, 265, 1, NULL, NULL, 'Tuition Fee - March', 1060.00, 0.00, 1060.00),
(440, 265, 1, NULL, NULL, 'Tuition Fee - April', 0.00, 0.00, 0.00),
(441, 265, 1, NULL, NULL, 'Tuition Fee - May', 0.00, 0.00, 0.00),
(442, 265, 1, NULL, NULL, 'Tuition Fee - June', 0.00, 0.00, 0.00),
(443, 265, 1, NULL, NULL, 'Tuition Fee - July', 0.00, 0.00, 0.00),
(444, 266, 1, NULL, NULL, 'Tuition Fee - March', 1060.00, 530.00, 530.00),
(445, 266, 1, NULL, NULL, 'Tuition Fee - April', 1060.00, 530.00, 530.00),
(446, 266, 1, NULL, NULL, 'Tuition Fee - May', 1060.00, 530.00, 530.00),
(447, 266, 1, NULL, NULL, 'Tuition Fee - June', 1060.00, 530.00, 530.00),
(448, 266, 1, NULL, NULL, 'Tuition Fee - July', 1060.00, 530.00, 530.00),
(449, 267, 1, NULL, NULL, 'Tuition Fee - March', 1060.00, 1060.00, 0.00),
(450, 267, 1, NULL, NULL, 'Tuition Fee - April', 1060.00, 1060.00, 0.00),
(451, 267, 1, NULL, NULL, 'Tuition Fee - May', 1060.00, 1060.00, 0.00),
(452, 267, 1, NULL, NULL, 'Tuition Fee - June', 1060.00, 1060.00, 0.00),
(453, 267, 1, NULL, NULL, 'Tuition Fee - July', 1060.00, 1060.00, 0.00),
(454, 268, 1, NULL, NULL, 'Tuition Fee - March', 1060.00, 530.00, 530.00),
(455, 268, 1, NULL, NULL, 'Tuition Fee - April', 1060.00, 530.00, 530.00),
(456, 268, 1, NULL, NULL, 'Tuition Fee - May', 1060.00, 530.00, 530.00),
(457, 268, 1, NULL, NULL, 'Tuition Fee - June', 1060.00, 530.00, 530.00),
(458, 268, 1, NULL, NULL, 'Tuition Fee - July', 1060.00, 530.00, 530.00),
(459, 269, 1, NULL, NULL, 'Tuition Fee - March', 1070.00, 0.00, 1070.00),
(460, 269, 1, NULL, NULL, 'Tuition Fee - April', 1070.00, 0.00, 1070.00),
(461, 269, 1, NULL, NULL, 'Tuition Fee - May', 1070.00, 0.00, 1070.00),
(462, 269, 1, NULL, NULL, 'Tuition Fee - June', 1070.00, 0.00, 1070.00),
(463, 269, 1, NULL, NULL, 'Tuition Fee - July', 1070.00, 0.00, 1070.00),
(464, 270, 1, NULL, NULL, 'Tuition Fee - March', 1070.00, 535.00, 535.00),
(465, 270, 1, NULL, NULL, 'Tuition Fee - April', 1070.00, 535.00, 535.00),
(466, 270, 1, NULL, NULL, 'Tuition Fee - May', 1070.00, 535.00, 535.00),
(467, 270, 1, NULL, NULL, 'Tuition Fee - June', 1070.00, 535.00, 535.00),
(468, 270, 1, NULL, NULL, 'Tuition Fee - July', 1070.00, 535.00, 535.00),
(469, 271, 1, NULL, NULL, 'Tuition Fee - March', 1070.00, 267.50, 802.50),
(470, 271, 1, NULL, NULL, 'Tuition Fee - April', 1070.00, 267.50, 802.50),
(471, 271, 1, NULL, NULL, 'Tuition Fee - May', 1070.00, 267.50, 802.50),
(472, 271, 1, NULL, NULL, 'Tuition Fee - June', 1070.00, 267.50, 802.50),
(473, 271, 1, NULL, NULL, 'Tuition Fee - July', 1070.00, 267.50, 802.50),
(474, 272, 1, NULL, NULL, 'Tuition Fee - March', 1070.00, 535.00, 535.00),
(475, 272, 1, NULL, NULL, 'Tuition Fee - April', 1070.00, 535.00, 535.00),
(476, 272, 1, NULL, NULL, 'Tuition Fee - May', 1070.00, 535.00, 535.00),
(477, 272, 1, NULL, NULL, 'Tuition Fee - June', 1070.00, 535.00, 535.00),
(478, 272, 1, NULL, NULL, 'Tuition Fee - July', 1070.00, 535.00, 535.00),
(479, 273, 1, NULL, NULL, 'Tuition Fee - March', 1070.00, 0.00, 1070.00),
(480, 273, 1, NULL, NULL, 'Tuition Fee - April', 1070.00, 0.00, 1070.00),
(481, 273, 1, NULL, NULL, 'Tuition Fee - May', 1070.00, 0.00, 1070.00),
(482, 273, 1, NULL, NULL, 'Tuition Fee - June', 1070.00, 0.00, 1070.00),
(483, 273, 1, NULL, NULL, 'Tuition Fee - July', 1070.00, 0.00, 1070.00),
(484, 274, 1, NULL, NULL, 'Tuition Fee - March', 1070.00, 0.00, 1070.00),
(485, 274, 1, NULL, NULL, 'Tuition Fee - April', 1070.00, 0.00, 1070.00),
(486, 274, 1, NULL, NULL, 'Tuition Fee - May', 1070.00, 0.00, 1070.00),
(487, 274, 1, NULL, NULL, 'Tuition Fee - June', 1070.00, 0.00, 1070.00),
(488, 274, 1, NULL, NULL, 'Tuition Fee - July', 1070.00, 0.00, 1070.00),
(489, 275, 1, NULL, NULL, 'Tuition Fee - March', 1070.00, 0.00, 1070.00),
(490, 275, 1, NULL, NULL, 'Tuition Fee - April', 1070.00, 0.00, 1070.00),
(491, 275, 1, NULL, NULL, 'Tuition Fee - May', 1070.00, 0.00, 1070.00),
(492, 275, 1, NULL, NULL, 'Tuition Fee - June', 1070.00, 0.00, 1070.00),
(493, 275, 1, NULL, NULL, 'Tuition Fee - July', 1070.00, 0.00, 1070.00),
(494, 276, 1, NULL, NULL, 'Tuition Fee - March', 1070.00, 0.00, 1070.00),
(495, 276, 1, NULL, NULL, 'Tuition Fee - April', 1070.00, 0.00, 1070.00),
(496, 276, 1, NULL, NULL, 'Tuition Fee - May', 1070.00, 0.00, 1070.00),
(497, 276, 1, NULL, NULL, 'Tuition Fee - June', 1070.00, 0.00, 1070.00),
(498, 276, 1, NULL, NULL, 'Tuition Fee - July', 1070.00, 0.00, 1070.00),
(499, 277, 1, NULL, NULL, 'Tuition Fee - March', 1070.00, 0.00, 1070.00),
(500, 277, 1, NULL, NULL, 'Tuition Fee - April', 1070.00, 0.00, 1070.00),
(501, 277, 1, NULL, NULL, 'Tuition Fee - May', 1070.00, 0.00, 1070.00),
(502, 277, 1, NULL, NULL, 'Tuition Fee - June', 1070.00, 0.00, 1070.00),
(503, 277, 1, NULL, NULL, 'Tuition Fee - July', 1070.00, 0.00, 1070.00),
(504, 278, 1, NULL, NULL, 'Tuition Fee - March', 1070.00, 0.00, 1070.00),
(505, 278, 1, NULL, NULL, 'Tuition Fee - April', 1070.00, 0.00, 1070.00),
(506, 278, 1, NULL, NULL, 'Tuition Fee - May', 1070.00, 0.00, 1070.00),
(507, 278, 1, NULL, NULL, 'Tuition Fee - June', 1070.00, 0.00, 1070.00),
(508, 278, 1, NULL, NULL, 'Tuition Fee - July', 1070.00, 0.00, 1070.00),
(509, 279, 1, NULL, NULL, 'Tuition Fee - March', 1070.00, 0.00, 1070.00),
(510, 279, 1, NULL, NULL, 'Tuition Fee - April', 1070.00, 0.00, 1070.00),
(511, 279, 1, NULL, NULL, 'Tuition Fee - May', 1070.00, 0.00, 1070.00),
(512, 279, 1, NULL, NULL, 'Tuition Fee - June', 1070.00, 0.00, 1070.00),
(513, 279, 1, NULL, NULL, 'Tuition Fee - July', 1070.00, 0.00, 1070.00),
(514, 280, 1, NULL, NULL, 'Tuition Fee - March', 1070.00, 267.50, 802.50),
(515, 280, 1, NULL, NULL, 'Tuition Fee - April', 1070.00, 267.50, 802.50),
(516, 280, 1, NULL, NULL, 'Tuition Fee - May', 1070.00, 267.50, 802.50),
(517, 280, 1, NULL, NULL, 'Tuition Fee - June', 1070.00, 267.50, 802.50),
(518, 280, 1, NULL, NULL, 'Tuition Fee - July', 1070.00, 267.50, 802.50),
(519, 281, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 0.00, 1090.00),
(520, 281, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(521, 281, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(522, 281, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(523, 281, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(524, 282, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 1090.00, 0.00),
(525, 282, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 1090.00, 0.00),
(526, 282, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 1090.00, 0.00),
(527, 282, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 1090.00, 0.00),
(528, 282, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 1090.00, 0.00),
(529, 283, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 0.00, 1090.00),
(530, 283, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(531, 283, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(532, 283, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(533, 283, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(534, 284, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 0.00, 1090.00),
(535, 284, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(536, 284, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(537, 284, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(538, 284, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(539, 285, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 272.50, 817.50),
(540, 285, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 272.50, 817.50),
(541, 285, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 272.50, 817.50),
(542, 285, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 272.50, 817.50),
(543, 285, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 272.50, 817.50),
(544, 286, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 0.00, 1090.00),
(545, 286, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(546, 286, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(547, 286, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(548, 286, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(549, 287, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 0.00, 1090.00),
(550, 287, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(551, 287, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(552, 287, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(553, 287, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(554, 288, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 0.00, 1090.00),
(555, 288, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(556, 288, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(557, 288, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(558, 288, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(559, 289, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 0.00, 1090.00),
(560, 289, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(561, 289, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(562, 289, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(563, 289, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(564, 290, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 545.00, 545.00),
(565, 290, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 545.00, 545.00),
(566, 290, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 545.00, 545.00),
(567, 290, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 545.00, 545.00),
(568, 290, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 545.00, 545.00),
(569, 291, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 1090.00, 0.00),
(570, 291, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 1090.00, 0.00),
(571, 291, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 1090.00, 0.00),
(572, 291, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 1090.00, 0.00),
(573, 291, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 1090.00, 0.00),
(574, 292, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 0.00, 1090.00),
(575, 292, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(576, 292, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(577, 292, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(578, 292, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(579, 293, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 0.00, 1090.00),
(580, 293, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(581, 293, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(582, 293, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(583, 293, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(584, 294, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 0.00, 1090.00),
(585, 294, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(586, 294, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(587, 294, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(588, 294, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(589, 295, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 0.00, 1090.00),
(590, 295, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(591, 295, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(592, 295, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(593, 295, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(594, 296, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 0.00, 1090.00),
(595, 296, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(596, 296, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(597, 296, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(598, 296, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(599, 297, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 1090.00, 0.00),
(600, 297, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 1090.00, 0.00),
(601, 297, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 1090.00, 0.00),
(602, 297, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 1090.00, 0.00),
(603, 297, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 1090.00, 0.00),
(604, 298, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 0.00, 1090.00),
(605, 298, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(606, 298, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(607, 298, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(608, 298, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(609, 299, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 0.00, 1090.00),
(610, 299, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(611, 299, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(612, 299, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(613, 299, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(614, 300, 1, NULL, NULL, 'Tuition Fee - March', 0.00, 0.00, 0.00),
(615, 300, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(616, 300, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(617, 300, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(618, 300, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(619, 301, 1, NULL, NULL, 'Tuition Fee - March', 1090.00, 0.00, 1090.00),
(620, 301, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(621, 301, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(622, 301, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(623, 301, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(624, 302, 1, NULL, NULL, 'Tuition Fee - March', 0.00, 0.00, 0.00),
(625, 302, 1, NULL, NULL, 'Tuition Fee - April', 1090.00, 0.00, 1090.00),
(626, 302, 1, NULL, NULL, 'Tuition Fee - May', 1090.00, 0.00, 1090.00),
(627, 302, 1, NULL, NULL, 'Tuition Fee - June', 1090.00, 0.00, 1090.00),
(628, 302, 1, NULL, NULL, 'Tuition Fee - July', 1090.00, 0.00, 1090.00),
(629, 303, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(630, 303, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(631, 303, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(632, 303, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(633, 303, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(634, 304, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(635, 304, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(636, 304, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(637, 304, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(638, 304, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(639, 305, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(640, 305, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(641, 305, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(642, 305, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(643, 305, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(644, 306, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 1140.00, 0.00),
(645, 306, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 1140.00, 0.00),
(646, 306, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 1140.00, 0.00),
(647, 306, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 1140.00, 0.00),
(648, 306, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 1140.00, 0.00),
(649, 307, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(650, 307, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(651, 307, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(652, 307, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(653, 307, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(654, 308, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(655, 308, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(656, 308, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(657, 308, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(658, 308, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(659, 309, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(660, 309, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(661, 309, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(662, 309, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(663, 309, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(664, 310, 1, NULL, NULL, 'Tuition Fee - March', 0.00, 0.00, 0.00),
(665, 310, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(666, 310, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(667, 310, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(668, 310, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(669, 311, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(670, 311, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(671, 311, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(672, 311, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(673, 311, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(674, 312, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(675, 312, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(676, 312, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(677, 312, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(678, 312, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(679, 313, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(680, 313, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(681, 313, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(682, 313, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(683, 313, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(684, 314, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(685, 314, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(686, 314, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(687, 314, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(688, 314, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(689, 315, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(690, 315, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(691, 315, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(692, 315, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(693, 315, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(694, 316, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(695, 316, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(696, 316, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(697, 316, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(698, 316, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(699, 317, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(700, 317, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(701, 317, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(702, 317, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(703, 317, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(704, 318, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(705, 318, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(706, 318, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(707, 318, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(708, 318, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(709, 319, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(710, 319, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(711, 319, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(712, 319, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(713, 319, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(714, 320, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(715, 320, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(716, 320, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(717, 320, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(718, 320, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(719, 321, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 1140.00, 0.00),
(720, 321, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 1140.00, 0.00),
(721, 321, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 1140.00, 0.00),
(722, 321, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 1140.00, 0.00),
(723, 321, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 1140.00, 0.00),
(724, 322, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(725, 322, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(726, 322, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(727, 322, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(728, 322, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(729, 323, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 1140.00, 0.00),
(730, 323, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 1140.00, 0.00),
(731, 323, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 1140.00, 0.00),
(732, 323, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 1140.00, 0.00),
(733, 323, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 1140.00, 0.00),
(734, 324, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(735, 324, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(736, 324, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(737, 324, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(738, 324, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(739, 325, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(740, 325, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(741, 325, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(742, 325, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(743, 325, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(744, 326, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(745, 326, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(746, 326, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(747, 326, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(748, 326, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(749, 327, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(750, 327, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(751, 327, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(752, 327, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(753, 327, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(754, 328, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(755, 328, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(756, 328, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(757, 328, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(758, 328, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(759, 329, 1, NULL, NULL, 'Tuition Fee - March', 1140.00, 0.00, 1140.00),
(760, 329, 1, NULL, NULL, 'Tuition Fee - April', 1140.00, 0.00, 1140.00),
(761, 329, 1, NULL, NULL, 'Tuition Fee - May', 1140.00, 0.00, 1140.00),
(762, 329, 1, NULL, NULL, 'Tuition Fee - June', 1140.00, 0.00, 1140.00),
(763, 329, 1, NULL, NULL, 'Tuition Fee - July', 1140.00, 0.00, 1140.00),
(764, 330, 1, NULL, NULL, 'Tuition Fee - March', 1190.00, 0.00, 1190.00),
(765, 330, 1, NULL, NULL, 'Tuition Fee - April', 1190.00, 0.00, 1190.00),
(766, 330, 1, NULL, NULL, 'Tuition Fee - May', 1190.00, 0.00, 1190.00),
(767, 330, 1, NULL, NULL, 'Tuition Fee - June', 1190.00, 0.00, 1190.00),
(768, 330, 1, NULL, NULL, 'Tuition Fee - July', 1190.00, 0.00, 1190.00),
(769, 331, 1, NULL, NULL, 'Tuition Fee - March', 1190.00, 0.00, 1190.00),
(770, 331, 1, NULL, NULL, 'Tuition Fee - April', 1190.00, 0.00, 1190.00),
(771, 331, 1, NULL, NULL, 'Tuition Fee - May', 1190.00, 0.00, 1190.00),
(772, 331, 1, NULL, NULL, 'Tuition Fee - June', 1190.00, 0.00, 1190.00),
(773, 331, 1, NULL, NULL, 'Tuition Fee - July', 1190.00, 0.00, 1190.00),
(774, 332, 1, NULL, NULL, 'Tuition Fee - March', 1190.00, 0.00, 1190.00),
(775, 332, 1, NULL, NULL, 'Tuition Fee - April', 1190.00, 0.00, 1190.00),
(776, 332, 1, NULL, NULL, 'Tuition Fee - May', 1190.00, 0.00, 1190.00),
(777, 332, 1, NULL, NULL, 'Tuition Fee - June', 1190.00, 0.00, 1190.00),
(778, 332, 1, NULL, NULL, 'Tuition Fee - July', 1190.00, 0.00, 1190.00),
(779, 333, 1, NULL, NULL, 'Tuition Fee - March', 1190.00, 0.00, 1190.00),
(780, 333, 1, NULL, NULL, 'Tuition Fee - April', 1190.00, 0.00, 1190.00),
(781, 333, 1, NULL, NULL, 'Tuition Fee - May', 1190.00, 0.00, 1190.00),
(782, 333, 1, NULL, NULL, 'Tuition Fee - June', 1190.00, 0.00, 1190.00),
(783, 333, 1, NULL, NULL, 'Tuition Fee - July', 1190.00, 0.00, 1190.00),
(784, 334, 1, NULL, NULL, 'Tuition Fee - March', 1190.00, 595.00, 595.00),
(785, 334, 1, NULL, NULL, 'Tuition Fee - April', 1190.00, 595.00, 595.00),
(786, 334, 1, NULL, NULL, 'Tuition Fee - May', 1190.00, 595.00, 595.00),
(787, 334, 1, NULL, NULL, 'Tuition Fee - June', 1190.00, 595.00, 595.00),
(788, 334, 1, NULL, NULL, 'Tuition Fee - July', 1190.00, 595.00, 595.00),
(789, 335, 1, NULL, NULL, 'Tuition Fee - March', 1190.00, 0.00, 1190.00),
(790, 335, 1, NULL, NULL, 'Tuition Fee - April', 1190.00, 0.00, 1190.00),
(791, 335, 1, NULL, NULL, 'Tuition Fee - May', 1190.00, 0.00, 1190.00),
(792, 335, 1, NULL, NULL, 'Tuition Fee - June', 1190.00, 0.00, 1190.00),
(793, 335, 1, NULL, NULL, 'Tuition Fee - July', 1190.00, 0.00, 1190.00),
(794, 336, 1, NULL, NULL, 'Tuition Fee - March', 1190.00, 0.00, 1190.00),
(795, 336, 1, NULL, NULL, 'Tuition Fee - April', 1190.00, 0.00, 1190.00),
(796, 336, 1, NULL, NULL, 'Tuition Fee - May', 1190.00, 0.00, 1190.00),
(797, 336, 1, NULL, NULL, 'Tuition Fee - June', 1190.00, 0.00, 1190.00),
(798, 336, 1, NULL, NULL, 'Tuition Fee - July', 1190.00, 0.00, 1190.00),
(799, 337, 1, NULL, NULL, 'Tuition Fee - March', 1190.00, 0.00, 1190.00),
(800, 337, 1, NULL, NULL, 'Tuition Fee - April', 1190.00, 0.00, 1190.00),
(801, 337, 1, NULL, NULL, 'Tuition Fee - May', 1190.00, 0.00, 1190.00),
(802, 337, 1, NULL, NULL, 'Tuition Fee - June', 1190.00, 0.00, 1190.00),
(803, 337, 1, NULL, NULL, 'Tuition Fee - July', 1190.00, 0.00, 1190.00),
(804, 338, 1, NULL, NULL, 'Tuition Fee - March', 1190.00, 0.00, 1190.00),
(805, 338, 1, NULL, NULL, 'Tuition Fee - April', 1190.00, 0.00, 1190.00),
(806, 338, 1, NULL, NULL, 'Tuition Fee - May', 1190.00, 0.00, 1190.00),
(807, 338, 1, NULL, NULL, 'Tuition Fee - June', 1190.00, 0.00, 1190.00),
(808, 338, 1, NULL, NULL, 'Tuition Fee - July', 1190.00, 0.00, 1190.00),
(809, 339, 1, NULL, NULL, 'Tuition Fee - March', 1190.00, 0.00, 1190.00),
(810, 339, 1, NULL, NULL, 'Tuition Fee - April', 1190.00, 0.00, 1190.00),
(811, 339, 1, NULL, NULL, 'Tuition Fee - May', 1190.00, 0.00, 1190.00),
(812, 339, 1, NULL, NULL, 'Tuition Fee - June', 1190.00, 0.00, 1190.00),
(813, 339, 1, NULL, NULL, 'Tuition Fee - July', 1190.00, 0.00, 1190.00),
(814, 340, 1, NULL, NULL, 'Tuition Fee - March', 1190.00, 0.00, 1190.00),
(815, 340, 1, NULL, NULL, 'Tuition Fee - April', 1190.00, 0.00, 1190.00),
(816, 340, 1, NULL, NULL, 'Tuition Fee - May', 1190.00, 0.00, 1190.00),
(817, 340, 1, NULL, NULL, 'Tuition Fee - June', 1190.00, 0.00, 1190.00),
(818, 340, 1, NULL, NULL, 'Tuition Fee - July', 1190.00, 0.00, 1190.00),
(819, 341, 1, NULL, NULL, 'Tuition Fee - March', 1190.00, 0.00, 1190.00),
(820, 341, 1, NULL, NULL, 'Tuition Fee - April', 1190.00, 0.00, 1190.00),
(821, 341, 1, NULL, NULL, 'Tuition Fee - May', 1190.00, 0.00, 1190.00),
(822, 341, 1, NULL, NULL, 'Tuition Fee - June', 1190.00, 0.00, 1190.00),
(823, 341, 1, NULL, NULL, 'Tuition Fee - July', 1190.00, 0.00, 1190.00),
(824, 342, 1, NULL, NULL, 'Tuition Fee - March', 1190.00, 0.00, 1190.00),
(825, 342, 1, NULL, NULL, 'Tuition Fee - April', 1190.00, 0.00, 1190.00),
(826, 342, 1, NULL, NULL, 'Tuition Fee - May', 1190.00, 0.00, 1190.00),
(827, 342, 1, NULL, NULL, 'Tuition Fee - June', 1190.00, 0.00, 1190.00),
(828, 342, 1, NULL, NULL, 'Tuition Fee - July', 1190.00, 0.00, 1190.00),
(829, 343, 1, NULL, NULL, 'Tuition Fee - March', 1250.00, 0.00, 1250.00),
(830, 343, 1, NULL, NULL, 'Tuition Fee - April', 1250.00, 0.00, 1250.00),
(831, 343, 1, NULL, NULL, 'Tuition Fee - May', 1250.00, 0.00, 1250.00),
(832, 343, 1, NULL, NULL, 'Tuition Fee - June', 1250.00, 0.00, 1250.00),
(833, 343, 1, NULL, NULL, 'Tuition Fee - July', 1250.00, 0.00, 1250.00),
(834, 344, 1, NULL, NULL, 'Tuition Fee - March', 1250.00, 0.00, 1250.00),
(835, 344, 1, NULL, NULL, 'Tuition Fee - April', 1250.00, 0.00, 1250.00),
(836, 344, 1, NULL, NULL, 'Tuition Fee - May', 1250.00, 0.00, 1250.00),
(837, 344, 1, NULL, NULL, 'Tuition Fee - June', 1250.00, 0.00, 1250.00),
(838, 344, 1, NULL, NULL, 'Tuition Fee - July', 1250.00, 0.00, 1250.00),
(839, 345, 1, NULL, NULL, 'Tuition Fee - March', 1250.00, 0.00, 1250.00),
(840, 345, 1, NULL, NULL, 'Tuition Fee - April', 1250.00, 0.00, 1250.00),
(841, 345, 1, NULL, NULL, 'Tuition Fee - May', 1250.00, 0.00, 1250.00),
(842, 345, 1, NULL, NULL, 'Tuition Fee - June', 1250.00, 0.00, 1250.00),
(843, 345, 1, NULL, NULL, 'Tuition Fee - July', 1250.00, 0.00, 1250.00),
(844, 346, 1, NULL, NULL, 'Tuition Fee - March', 1250.00, 0.00, 1250.00),
(845, 346, 1, NULL, NULL, 'Tuition Fee - April', 1250.00, 0.00, 1250.00),
(846, 346, 1, NULL, NULL, 'Tuition Fee - May', 1250.00, 0.00, 1250.00),
(847, 346, 1, NULL, NULL, 'Tuition Fee - June', 1250.00, 0.00, 1250.00),
(848, 346, 1, NULL, NULL, 'Tuition Fee - July', 1250.00, 0.00, 1250.00),
(849, 347, 1, NULL, NULL, 'Tuition Fee - March', 1250.00, 0.00, 1250.00),
(850, 347, 1, NULL, NULL, 'Tuition Fee - April', 1250.00, 0.00, 1250.00),
(851, 347, 1, NULL, NULL, 'Tuition Fee - May', 1250.00, 0.00, 1250.00),
(852, 347, 1, NULL, NULL, 'Tuition Fee - June', 1250.00, 0.00, 1250.00),
(853, 347, 1, NULL, NULL, 'Tuition Fee - July', 1250.00, 0.00, 1250.00),
(854, 348, 1, NULL, NULL, 'Tuition Fee - March', 1250.00, 0.00, 1250.00),
(855, 348, 1, NULL, NULL, 'Tuition Fee - April', 1250.00, 0.00, 1250.00),
(856, 348, 1, NULL, NULL, 'Tuition Fee - May', 1250.00, 0.00, 1250.00),
(857, 348, 1, NULL, NULL, 'Tuition Fee - June', 1250.00, 0.00, 1250.00),
(858, 348, 1, NULL, NULL, 'Tuition Fee - July', 1250.00, 0.00, 1250.00),
(859, 349, 1, NULL, NULL, 'Tuition Fee - March', 1250.00, 0.00, 1250.00),
(860, 349, 1, NULL, NULL, 'Tuition Fee - April', 1250.00, 0.00, 1250.00),
(861, 349, 1, NULL, NULL, 'Tuition Fee - May', 1250.00, 0.00, 1250.00),
(862, 349, 1, NULL, NULL, 'Tuition Fee - June', 1250.00, 0.00, 1250.00),
(863, 349, 1, NULL, NULL, 'Tuition Fee - July', 1250.00, 0.00, 1250.00),
(864, 350, 1, NULL, NULL, 'Tuition Fee - March', 1250.00, 0.00, 1250.00),
(865, 350, 1, NULL, NULL, 'Tuition Fee - April', 1250.00, 0.00, 1250.00),
(866, 350, 1, NULL, NULL, 'Tuition Fee - May', 1250.00, 0.00, 1250.00),
(867, 350, 1, NULL, NULL, 'Tuition Fee - June', 1250.00, 0.00, 1250.00),
(868, 350, 1, NULL, NULL, 'Tuition Fee - July', 1250.00, 0.00, 1250.00),
(869, 351, 1, NULL, NULL, 'Tuition Fee - March', 1250.00, 0.00, 1250.00),
(870, 351, 1, NULL, NULL, 'Tuition Fee - April', 1250.00, 0.00, 1250.00),
(871, 351, 1, NULL, NULL, 'Tuition Fee - May', 1250.00, 0.00, 1250.00),
(872, 351, 1, NULL, NULL, 'Tuition Fee - June', 1250.00, 0.00, 1250.00),
(873, 351, 1, NULL, NULL, 'Tuition Fee - July', 1250.00, 0.00, 1250.00),
(874, 352, 1, NULL, NULL, 'Tuition Fee - March', 1250.00, 0.00, 1250.00),
(875, 352, 1, NULL, NULL, 'Tuition Fee - April', 1250.00, 0.00, 1250.00),
(876, 352, 1, NULL, NULL, 'Tuition Fee - May', 1250.00, 0.00, 1250.00),
(877, 352, 1, NULL, NULL, 'Tuition Fee - June', 1250.00, 0.00, 1250.00),
(878, 352, 1, NULL, NULL, 'Tuition Fee - July', 1250.00, 0.00, 1250.00),
(879, 353, 1, NULL, NULL, 'Tuition Fee - March', 1250.00, 0.00, 1250.00),
(880, 353, 1, NULL, NULL, 'Tuition Fee - April', 1250.00, 0.00, 1250.00),
(881, 353, 1, NULL, NULL, 'Tuition Fee - May', 1250.00, 0.00, 1250.00),
(882, 353, 1, NULL, NULL, 'Tuition Fee - June', 1250.00, 0.00, 1250.00),
(883, 353, 1, NULL, NULL, 'Tuition Fee - July', 1250.00, 0.00, 1250.00),
(884, 354, 1, NULL, NULL, 'Tuition Fee - March', 1250.00, 1250.00, 0.00),
(885, 354, 1, NULL, NULL, 'Tuition Fee - April', 1250.00, 1250.00, 0.00),
(886, 354, 1, NULL, NULL, 'Tuition Fee - May', 1250.00, 1250.00, 0.00),
(887, 354, 1, NULL, NULL, 'Tuition Fee - June', 1250.00, 1250.00, 0.00),
(888, 354, 1, NULL, NULL, 'Tuition Fee - July', 1250.00, 1250.00, 0.00),
(889, 355, 1, NULL, NULL, 'Tuition Fee - March', 1250.00, 0.00, 1250.00),
(890, 355, 1, NULL, NULL, 'Tuition Fee - April', 1250.00, 0.00, 1250.00),
(891, 355, 1, NULL, NULL, 'Tuition Fee - May', 1250.00, 0.00, 1250.00),
(892, 355, 1, NULL, NULL, 'Tuition Fee - June', 1250.00, 0.00, 1250.00),
(893, 355, 1, NULL, NULL, 'Tuition Fee - July', 1250.00, 0.00, 1250.00),
(894, 356, 1, NULL, NULL, 'Tuition Fee - March', 0.00, 0.00, 0.00),
(895, 356, 1, NULL, NULL, 'Tuition Fee - April', 1250.00, 0.00, 1250.00),
(896, 356, 1, NULL, NULL, 'Tuition Fee - May', 1250.00, 0.00, 1250.00),
(897, 356, 1, NULL, NULL, 'Tuition Fee - June', 1250.00, 0.00, 1250.00),
(898, 356, 1, NULL, NULL, 'Tuition Fee - July', 1250.00, 0.00, 1250.00),
(899, 357, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(900, 357, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(901, 357, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(902, 357, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(903, 357, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(904, 358, 1, NULL, NULL, 'Tuition Fee - March', 0.00, 0.00, 0.00),
(905, 358, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(906, 358, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(907, 358, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(908, 358, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(909, 359, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(910, 359, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(911, 359, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(912, 359, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(913, 359, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(914, 360, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(915, 360, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(916, 360, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(917, 360, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(918, 360, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(919, 361, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(920, 361, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(921, 361, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(922, 361, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(923, 361, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(924, 362, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(925, 362, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(926, 362, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(927, 362, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(928, 362, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(934, 364, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(935, 364, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(936, 364, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(937, 364, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(938, 364, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(939, 365, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(940, 365, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(941, 365, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(942, 365, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(943, 365, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(944, 366, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(945, 366, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(946, 366, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(947, 366, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(948, 366, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(949, 367, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(950, 367, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(951, 367, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(952, 367, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(953, 367, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(954, 368, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 1300.00, 0.00),
(955, 368, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 1300.00, 0.00),
(956, 368, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 1300.00, 0.00),
(957, 368, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 1300.00, 0.00),
(958, 368, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 1300.00, 0.00),
(959, 369, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 1300.00, 0.00),
(960, 369, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 1300.00, 0.00),
(961, 369, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 1300.00, 0.00),
(962, 369, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 1300.00, 0.00),
(963, 369, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 1300.00, 0.00),
(964, 370, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 1300.00, 0.00),
(965, 370, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 1300.00, 0.00),
(966, 370, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 1300.00, 0.00),
(967, 370, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 1300.00, 0.00),
(968, 370, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 1300.00, 0.00),
(969, 371, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(970, 371, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(971, 371, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(972, 371, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(973, 371, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(974, 372, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(975, 372, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(976, 372, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(977, 372, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(978, 372, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(979, 373, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(980, 373, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(981, 373, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(982, 373, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(983, 373, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(984, 374, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(985, 374, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(986, 374, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(987, 374, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(988, 374, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(989, 375, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(990, 375, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(991, 375, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(992, 375, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(993, 375, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(994, 376, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(995, 376, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(996, 376, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(997, 376, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(998, 376, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(999, 377, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(1000, 377, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(1001, 377, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(1002, 377, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(1003, 377, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(1004, 378, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 650.00, 650.00),
(1005, 378, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 650.00, 650.00),
(1006, 378, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 650.00, 650.00),
(1007, 378, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 650.00, 650.00),
(1008, 378, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 650.00, 650.00),
(1009, 379, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 0.00, 1300.00),
(1010, 379, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 0.00, 1300.00),
(1011, 379, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 0.00, 1300.00),
(1012, 379, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 0.00, 1300.00),
(1013, 379, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 0.00, 1300.00),
(1014, 380, 1, NULL, NULL, 'Tuition Fee - March', 1500.00, 1500.00, 0.00),
(1015, 380, 1, NULL, NULL, 'Tuition Fee - April', 1500.00, 1500.00, 0.00),
(1016, 380, 1, NULL, NULL, 'Tuition Fee - May', 1500.00, 1500.00, 0.00),
(1017, 380, 1, NULL, NULL, 'Tuition Fee - June', 1500.00, 1500.00, 0.00),
(1018, 380, 1, NULL, NULL, 'Tuition Fee - July', 1500.00, 1500.00, 0.00),
(1019, 381, 1, NULL, NULL, 'Tuition Fee - March', 1500.00, 0.00, 1500.00),
(1020, 381, 1, NULL, NULL, 'Tuition Fee - April', 1500.00, 0.00, 1500.00),
(1021, 381, 1, NULL, NULL, 'Tuition Fee - May', 1500.00, 0.00, 1500.00),
(1022, 381, 1, NULL, NULL, 'Tuition Fee - June', 1500.00, 0.00, 1500.00),
(1023, 381, 1, NULL, NULL, 'Tuition Fee - July', 1500.00, 0.00, 1500.00),
(1024, 382, 1, NULL, NULL, 'Tuition Fee - March', 1500.00, 0.00, 1500.00),
(1025, 382, 1, NULL, NULL, 'Tuition Fee - April', 1500.00, 0.00, 1500.00),
(1026, 382, 1, NULL, NULL, 'Tuition Fee - May', 1500.00, 0.00, 1500.00),
(1027, 382, 1, NULL, NULL, 'Tuition Fee - June', 1500.00, 0.00, 1500.00),
(1028, 382, 1, NULL, NULL, 'Tuition Fee - July', 1500.00, 0.00, 1500.00),
(1029, 383, 1, NULL, NULL, 'Tuition Fee - March', 1500.00, 0.00, 1500.00),
(1030, 383, 1, NULL, NULL, 'Tuition Fee - April', 1500.00, 0.00, 1500.00),
(1031, 383, 1, NULL, NULL, 'Tuition Fee - May', 1500.00, 0.00, 1500.00),
(1032, 383, 1, NULL, NULL, 'Tuition Fee - June', 1500.00, 0.00, 1500.00),
(1033, 383, 1, NULL, NULL, 'Tuition Fee - July', 1500.00, 0.00, 1500.00),
(1034, 384, 1, NULL, NULL, 'Tuition Fee - March', 1500.00, 0.00, 1500.00),
(1035, 384, 1, NULL, NULL, 'Tuition Fee - April', 1500.00, 0.00, 1500.00),
(1036, 384, 1, NULL, NULL, 'Tuition Fee - May', 1500.00, 0.00, 1500.00),
(1037, 384, 1, NULL, NULL, 'Tuition Fee - June', 1500.00, 0.00, 1500.00),
(1038, 384, 1, NULL, NULL, 'Tuition Fee - July', 1500.00, 0.00, 1500.00),
(1039, 385, 1, NULL, NULL, 'Tuition Fee - March', 1500.00, 1500.00, 0.00),
(1040, 385, 1, NULL, NULL, 'Tuition Fee - April', 1500.00, 1500.00, 0.00),
(1041, 385, 1, NULL, NULL, 'Tuition Fee - May', 1500.00, 1500.00, 0.00),
(1042, 385, 1, NULL, NULL, 'Tuition Fee - June', 1500.00, 1500.00, 0.00),
(1043, 385, 1, NULL, NULL, 'Tuition Fee - July', 1500.00, 1500.00, 0.00),
(1044, 386, 1, NULL, NULL, 'Tuition Fee - March', 0.00, 0.00, 0.00),
(1045, 386, 1, NULL, NULL, 'Tuition Fee - April', 1500.00, 0.00, 1500.00),
(1046, 386, 1, NULL, NULL, 'Tuition Fee - May', 1500.00, 0.00, 1500.00),
(1047, 386, 1, NULL, NULL, 'Tuition Fee - June', 1500.00, 0.00, 1500.00),
(1048, 386, 1, NULL, NULL, 'Tuition Fee - July', 1500.00, 0.00, 1500.00),
(1049, 387, 1, NULL, NULL, 'Tuition Fee - March', 1500.00, 0.00, 1500.00),
(1050, 387, 1, NULL, NULL, 'Tuition Fee - April', 1500.00, 0.00, 1500.00),
(1051, 387, 1, NULL, NULL, 'Tuition Fee - May', 1500.00, 0.00, 1500.00),
(1052, 387, 1, NULL, NULL, 'Tuition Fee - June', 1500.00, 0.00, 1500.00),
(1053, 387, 1, NULL, NULL, 'Tuition Fee - July', 1500.00, 0.00, 1500.00),
(1054, 388, 1, NULL, NULL, 'Tuition Fee - March', 0.00, 0.00, 0.00),
(1055, 388, 1, NULL, NULL, 'Tuition Fee - April', 1500.00, 0.00, 1500.00),
(1056, 388, 1, NULL, NULL, 'Tuition Fee - May', 1500.00, 0.00, 1500.00),
(1057, 388, 1, NULL, NULL, 'Tuition Fee - June', 1500.00, 0.00, 1500.00),
(1058, 388, 1, NULL, NULL, 'Tuition Fee - July', 1500.00, 0.00, 1500.00),
(1059, 389, 1, NULL, NULL, 'Tuition Fee - March', 1500.00, 0.00, 1500.00),
(1060, 389, 1, NULL, NULL, 'Tuition Fee - April', 1500.00, 0.00, 1500.00),
(1061, 389, 1, NULL, NULL, 'Tuition Fee - May', 1500.00, 0.00, 1500.00),
(1062, 389, 1, NULL, NULL, 'Tuition Fee - June', 1500.00, 0.00, 1500.00),
(1063, 389, 1, NULL, NULL, 'Tuition Fee - July', 1500.00, 0.00, 1500.00),
(1064, 390, 1, NULL, NULL, 'Tuition Fee - March', 1500.00, 0.00, 1500.00),
(1065, 390, 1, NULL, NULL, 'Tuition Fee - April', 1500.00, 0.00, 1500.00),
(1066, 390, 1, NULL, NULL, 'Tuition Fee - May', 1500.00, 0.00, 1500.00),
(1067, 390, 1, NULL, NULL, 'Tuition Fee - June', 1500.00, 0.00, 1500.00),
(1068, 390, 1, NULL, NULL, 'Tuition Fee - July', 1500.00, 0.00, 1500.00),
(1069, 391, 1, NULL, NULL, 'Tuition Fee - March', 1500.00, 0.00, 1500.00),
(1070, 391, 1, NULL, NULL, 'Tuition Fee - April', 1500.00, 0.00, 1500.00),
(1071, 391, 1, NULL, NULL, 'Tuition Fee - May', 1500.00, 0.00, 1500.00),
(1072, 391, 1, NULL, NULL, 'Tuition Fee - June', 1500.00, 0.00, 1500.00),
(1073, 391, 1, NULL, NULL, 'Tuition Fee - July', 1500.00, 0.00, 1500.00),
(1074, 392, 1, NULL, NULL, 'Tuition Fee - March', 1500.00, 0.00, 1500.00),
(1075, 392, 1, NULL, NULL, 'Tuition Fee - April', 1500.00, 0.00, 1500.00),
(1076, 392, 1, NULL, NULL, 'Tuition Fee - May', 1500.00, 0.00, 1500.00),
(1077, 392, 1, NULL, NULL, 'Tuition Fee - June', 1500.00, 0.00, 1500.00),
(1078, 392, 1, NULL, NULL, 'Tuition Fee - July', 1500.00, 0.00, 1500.00);
INSERT INTO `fee_invoice_lines` (`id`, `fee_invoice_id`, `fee_category_id`, `billing_month`, `billing_year`, `description`, `base_amount`, `discount_amount`, `line_total`) VALUES
(1312, 430, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 0.00, 1000.00),
(1313, 430, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 0.00, 1000.00),
(1314, 430, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 0.00, 1000.00),
(1315, 430, 1, NULL, NULL, 'Tuition Fee - July', 0.00, 0.00, 0.00),
(1316, 431, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 500.00, 500.00),
(1317, 431, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 500.00, 500.00),
(1318, 431, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 500.00, 500.00),
(1319, 431, 1, NULL, NULL, 'Tuition Fee - July', 1000.00, 500.00, 500.00),
(1320, 432, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 500.00, 500.00),
(1321, 432, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 500.00, 500.00),
(1322, 432, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 500.00, 500.00),
(1323, 432, 1, NULL, NULL, 'Tuition Fee - July', 1000.00, 500.00, 500.00),
(1324, 433, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 1000.00, 0.00),
(1325, 433, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 1000.00, 0.00),
(1326, 433, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 1000.00, 0.00),
(1327, 433, 1, NULL, NULL, 'Tuition Fee - July', 1000.00, 1000.00, 0.00),
(1328, 434, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 0.00, 1000.00),
(1329, 434, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 0.00, 1000.00),
(1330, 434, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 0.00, 1000.00),
(1331, 434, 1, NULL, NULL, 'Tuition Fee - July', 1000.00, 0.00, 1000.00),
(1332, 435, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 0.00, 1000.00),
(1333, 435, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 0.00, 1000.00),
(1334, 435, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 0.00, 1000.00),
(1335, 435, 1, NULL, NULL, 'Tuition Fee - July', 1000.00, 0.00, 1000.00),
(1336, 436, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 0.00, 1000.00),
(1337, 436, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 0.00, 1000.00),
(1338, 436, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 0.00, 1000.00),
(1339, 436, 1, NULL, NULL, 'Tuition Fee - July', 1000.00, 0.00, 1000.00),
(1340, 437, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 0.00, 1000.00),
(1341, 437, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 0.00, 1000.00),
(1342, 437, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 0.00, 1000.00),
(1343, 437, 1, NULL, NULL, 'Tuition Fee - July', 1000.00, 0.00, 1000.00),
(1344, 438, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 0.00, 1000.00),
(1345, 438, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 0.00, 1000.00),
(1346, 438, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 0.00, 1000.00),
(1347, 438, 1, NULL, NULL, 'Tuition Fee - July', 1000.00, 0.00, 1000.00),
(1348, 439, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 0.00, 1000.00),
(1349, 439, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 0.00, 1000.00),
(1350, 439, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 0.00, 1000.00),
(1351, 439, 1, NULL, NULL, 'Tuition Fee - July', 1000.00, 0.00, 1000.00),
(1352, 440, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 0.00, 1000.00),
(1353, 440, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 0.00, 1000.00),
(1354, 440, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 0.00, 1000.00),
(1355, 440, 1, NULL, NULL, 'Tuition Fee - July', 1000.00, 0.00, 1000.00),
(1356, 441, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 1000.00, 0.00),
(1357, 441, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 1000.00, 0.00),
(1358, 441, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 1000.00, 0.00),
(1359, 441, 1, NULL, NULL, 'Tuition Fee - July', 1000.00, 1000.00, 0.00),
(1360, 442, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 500.00, 500.00),
(1361, 442, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 500.00, 500.00),
(1362, 442, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 500.00, 500.00),
(1363, 442, 1, NULL, NULL, 'Tuition Fee - July', 1000.00, 500.00, 500.00),
(1364, 443, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 1000.00, 0.00),
(1365, 443, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 1000.00, 0.00),
(1366, 443, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 1000.00, 0.00),
(1367, 443, 1, NULL, NULL, 'Tuition Fee - July', 1000.00, 1000.00, 0.00),
(1368, 444, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 0.00, 1000.00),
(1369, 444, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 0.00, 1000.00),
(1370, 444, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 0.00, 1000.00),
(1371, 444, 1, NULL, NULL, 'Tuition Fee - July', 1000.00, 0.00, 1000.00),
(1372, 445, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 1000.00, 0.00),
(1373, 445, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 1000.00, 0.00),
(1374, 445, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 1000.00, 0.00),
(1375, 445, 1, NULL, NULL, 'Tuition Fee - July', 1000.00, 1000.00, 0.00),
(1376, 446, 1, NULL, NULL, 'Tuition Fee - April', 1000.00, 0.00, 1000.00),
(1377, 446, 1, NULL, NULL, 'Tuition Fee - May', 1000.00, 0.00, 1000.00),
(1378, 446, 1, NULL, NULL, 'Tuition Fee - June', 1000.00, 0.00, 1000.00),
(1379, 446, 1, NULL, NULL, 'Tuition Fee - July', 1000.00, 0.00, 1000.00),
(1380, 447, 1, NULL, NULL, 'Tuition Fee - August', 1000.00, 0.00, 1000.00),
(1381, 447, 1, NULL, NULL, 'Tuition Fee - September', 1000.00, 0.00, 1000.00),
(1382, 447, 1, NULL, NULL, 'Tuition Fee - October', 1000.00, 0.00, 1000.00),
(1383, 447, 1, NULL, NULL, 'Tuition Fee - November', 1000.00, 0.00, 1000.00),
(1384, 447, 1, NULL, NULL, 'Tuition Fee - December', 1000.00, 0.00, 1000.00),
(1385, 448, 1, NULL, NULL, 'Tuition Fee - January', 1000.00, 0.00, 1000.00),
(1386, 448, 1, NULL, NULL, 'Tuition Fee - February', 1000.00, 0.00, 1000.00),
(1387, 449, 1, NULL, NULL, 'Tuition Fee - March', 1050.00, 0.00, 1050.00),
(1388, 449, 1, NULL, NULL, 'Tuition Fee - April', 1050.00, 0.00, 1050.00),
(1389, 449, 1, NULL, NULL, 'Tuition Fee - May', 1050.00, 0.00, 1050.00),
(1390, 449, 1, NULL, NULL, 'Tuition Fee - June', 1050.00, 0.00, 1050.00),
(1391, 449, 1, NULL, NULL, 'Tuition Fee - July', 1050.00, 0.00, 1050.00),
(1392, 450, 1, NULL, NULL, 'Tuition Fee - March', 1050.00, 0.00, 1050.00),
(1393, 450, 1, NULL, NULL, 'Tuition Fee - April', 1050.00, 0.00, 1050.00),
(1394, 450, 1, NULL, NULL, 'Tuition Fee - May', 1050.00, 0.00, 1050.00),
(1395, 450, 1, NULL, NULL, 'Tuition Fee - June', 1050.00, 0.00, 1050.00),
(1396, 450, 1, NULL, NULL, 'Tuition Fee - July', 1050.00, 0.00, 1050.00),
(1397, 451, 1, NULL, NULL, 'Tuition Fee - March', 1050.00, 1050.00, 0.00),
(1398, 451, 1, NULL, NULL, 'Tuition Fee - April', 1050.00, 1050.00, 0.00),
(1399, 451, 1, NULL, NULL, 'Tuition Fee - May', 1050.00, 1050.00, 0.00),
(1400, 451, 1, NULL, NULL, 'Tuition Fee - June', 1050.00, 1050.00, 0.00),
(1401, 451, 1, NULL, NULL, 'Tuition Fee - July', 1050.00, 1050.00, 0.00),
(1402, 452, 1, NULL, NULL, 'Tuition Fee - March', 1050.00, 525.00, 525.00),
(1403, 452, 1, NULL, NULL, 'Tuition Fee - April', 1050.00, 525.00, 525.00),
(1404, 452, 1, NULL, NULL, 'Tuition Fee - May', 1050.00, 525.00, 525.00),
(1405, 452, 1, NULL, NULL, 'Tuition Fee - June', 1050.00, 525.00, 525.00),
(1406, 452, 1, NULL, NULL, 'Tuition Fee - July', 1050.00, 525.00, 525.00),
(1407, 453, 1, NULL, NULL, 'Tuition Fee - March', 1050.00, 1050.00, 0.00),
(1408, 453, 1, NULL, NULL, 'Tuition Fee - April', 1050.00, 1050.00, 0.00),
(1409, 453, 1, NULL, NULL, 'Tuition Fee - May', 1050.00, 1050.00, 0.00),
(1410, 453, 1, NULL, NULL, 'Tuition Fee - June', 1050.00, 1050.00, 0.00),
(1411, 453, 1, NULL, NULL, 'Tuition Fee - July', 1050.00, 1050.00, 0.00),
(1412, 454, 1, NULL, NULL, 'Tuition Fee - March', 1050.00, 1050.00, 0.00),
(1413, 454, 1, NULL, NULL, 'Tuition Fee - April', 1050.00, 1050.00, 0.00),
(1414, 454, 1, NULL, NULL, 'Tuition Fee - May', 1050.00, 1050.00, 0.00),
(1415, 454, 1, NULL, NULL, 'Tuition Fee - June', 1050.00, 1050.00, 0.00),
(1416, 454, 1, NULL, NULL, 'Tuition Fee - July', 1050.00, 1050.00, 0.00),
(1417, 455, 1, NULL, NULL, 'Tuition Fee - March', 0.00, 0.00, 0.00),
(1418, 455, 1, NULL, NULL, 'Tuition Fee - April', 1050.00, 525.00, 525.00),
(1419, 455, 1, NULL, NULL, 'Tuition Fee - May', 1050.00, 525.00, 525.00),
(1420, 455, 1, NULL, NULL, 'Tuition Fee - June', 1050.00, 525.00, 525.00),
(1421, 455, 1, NULL, NULL, 'Tuition Fee - July', 1050.00, 525.00, 525.00),
(1422, 456, 1, NULL, NULL, 'Tuition Fee - March', 1050.00, 0.00, 1050.00),
(1423, 456, 1, NULL, NULL, 'Tuition Fee - April', 1050.00, 0.00, 1050.00),
(1424, 456, 1, NULL, NULL, 'Tuition Fee - May', 1050.00, 0.00, 1050.00),
(1425, 456, 1, NULL, NULL, 'Tuition Fee - June', 1050.00, 0.00, 1050.00),
(1426, 456, 1, NULL, NULL, 'Tuition Fee - July', 1050.00, 0.00, 1050.00),
(1427, 457, 1, NULL, NULL, 'Tuition Fee - March', 1050.00, 525.00, 525.00),
(1428, 457, 1, NULL, NULL, 'Tuition Fee - April', 1050.00, 525.00, 525.00),
(1429, 457, 1, NULL, NULL, 'Tuition Fee - May', 1050.00, 525.00, 525.00),
(1430, 457, 1, NULL, NULL, 'Tuition Fee - June', 1050.00, 525.00, 525.00),
(1431, 457, 1, NULL, NULL, 'Tuition Fee - July', 1050.00, 525.00, 525.00),
(1432, 458, 1, NULL, NULL, 'Tuition Fee - March', 1050.00, 0.00, 1050.00),
(1433, 458, 1, NULL, NULL, 'Tuition Fee - April', 1050.00, 0.00, 1050.00),
(1434, 458, 1, NULL, NULL, 'Tuition Fee - May', 1050.00, 0.00, 1050.00),
(1435, 458, 1, NULL, NULL, 'Tuition Fee - June', 1050.00, 0.00, 1050.00),
(1436, 458, 1, NULL, NULL, 'Tuition Fee - July', 1050.00, 0.00, 1050.00),
(1437, 459, 1, NULL, NULL, 'Tuition Fee - March', 1050.00, 525.00, 525.00),
(1438, 459, 1, NULL, NULL, 'Tuition Fee - April', 1050.00, 525.00, 525.00),
(1439, 459, 1, NULL, NULL, 'Tuition Fee - May', 1050.00, 525.00, 525.00),
(1440, 459, 1, NULL, NULL, 'Tuition Fee - June', 1050.00, 525.00, 525.00),
(1441, 459, 1, NULL, NULL, 'Tuition Fee - July', 1050.00, 525.00, 525.00),
(1442, 460, 1, NULL, NULL, 'Tuition Fee - March', 1050.00, 0.00, 1050.00),
(1443, 460, 1, NULL, NULL, 'Tuition Fee - April', 1050.00, 0.00, 1050.00),
(1444, 460, 1, NULL, NULL, 'Tuition Fee - May', 1050.00, 0.00, 1050.00),
(1445, 460, 1, NULL, NULL, 'Tuition Fee - June', 1050.00, 0.00, 1050.00),
(1446, 460, 1, NULL, NULL, 'Tuition Fee - July', 1050.00, 0.00, 1050.00),
(1447, 461, 1, NULL, NULL, 'Tuition Fee - March', 1050.00, 0.00, 1050.00),
(1448, 461, 1, NULL, NULL, 'Tuition Fee - April', 1050.00, 0.00, 1050.00),
(1449, 461, 1, NULL, NULL, 'Tuition Fee - May', 1050.00, 0.00, 1050.00),
(1450, 461, 1, NULL, NULL, 'Tuition Fee - June', 1050.00, 0.00, 1050.00),
(1451, 461, 1, NULL, NULL, 'Tuition Fee - July', 1050.00, 0.00, 1050.00),
(1457, 463, 1, NULL, NULL, 'Tuition Fee - March', 1050.00, 525.00, 525.00),
(1458, 463, 1, NULL, NULL, 'Tuition Fee - April', 1050.00, 525.00, 525.00),
(1459, 463, 1, NULL, NULL, 'Tuition Fee - May', 1050.00, 525.00, 525.00),
(1460, 463, 1, NULL, NULL, 'Tuition Fee - June', 1050.00, 525.00, 525.00),
(1461, 463, 1, NULL, NULL, 'Tuition Fee - July', 1050.00, 525.00, 525.00),
(1462, 464, 1, NULL, NULL, 'Tuition Fee - March', 0.00, 0.00, 0.00),
(1463, 464, 1, NULL, NULL, 'Tuition Fee - April', 1050.00, 0.00, 1050.00),
(1464, 464, 1, NULL, NULL, 'Tuition Fee - May', 1050.00, 0.00, 1050.00),
(1465, 464, 1, NULL, NULL, 'Tuition Fee - June', 1050.00, 0.00, 1050.00),
(1466, 464, 1, NULL, NULL, 'Tuition Fee - July', 1050.00, 0.00, 1050.00),
(1467, 465, 1, NULL, NULL, 'Tuition Fee - August', 1300.00, 0.00, 1300.00),
(1468, 465, 1, NULL, NULL, 'Tuition Fee - September', 1300.00, 0.00, 1300.00),
(1469, 465, 1, NULL, NULL, 'Tuition Fee - October', 1300.00, 0.00, 1300.00),
(1470, 465, 1, NULL, NULL, 'Tuition Fee - November', 1300.00, 0.00, 1300.00),
(1471, 465, 1, NULL, NULL, 'Tuition Fee - December', 1300.00, 0.00, 1300.00),
(1472, 466, 1, NULL, NULL, 'Tuition Fee - January', 1300.00, 0.00, 1300.00),
(1473, 466, 1, NULL, NULL, 'Tuition Fee - February', 1300.00, 0.00, 1300.00),
(1475, 468, 1, NULL, NULL, 'Tuition Fee - March', 1300.00, 325.00, 975.00),
(1476, 468, 1, NULL, NULL, 'Tuition Fee - April', 1300.00, 325.00, 975.00),
(1477, 468, 1, NULL, NULL, 'Tuition Fee - May', 1300.00, 325.00, 975.00),
(1478, 468, 1, NULL, NULL, 'Tuition Fee - June', 1300.00, 325.00, 975.00),
(1479, 468, 1, NULL, NULL, 'Tuition Fee - July', 1300.00, 325.00, 975.00),
(1480, 469, 1, NULL, NULL, 'Tuition Fee - August', 1250.00, 0.00, 1250.00),
(1488, 474, 1, 3, 2026, 'Tuition Fee - March', 2500.00, 0.00, 2500.00),
(1489, 474, 1, 4, 2026, 'Tuition Fee - April', 2500.00, 0.00, 2500.00),
(1490, 474, 1, 5, 2026, 'Tuition Fee - May', 2500.00, 0.00, 2500.00),
(1491, 474, 1, 6, 2026, 'Tuition Fee - June', 2500.00, 0.00, 2500.00),
(1492, 474, 1, 7, 2026, 'Tuition Fee - July', 2500.00, 0.00, 2500.00),
(1493, 475, 1, 3, 2026, 'Tuition Fee - March', 2500.00, 0.00, 2500.00),
(1494, 475, 1, 4, 2026, 'Tuition Fee - April', 2500.00, 0.00, 2500.00),
(1495, 475, 1, 5, 2026, 'Tuition Fee - May', 2500.00, 0.00, 2500.00),
(1496, 475, 1, 6, 2026, 'Tuition Fee - June', 2500.00, 0.00, 2500.00),
(1497, 475, 1, 7, 2026, 'Tuition Fee - July', 2500.00, 0.00, 2500.00),
(1498, 476, 1, 3, 2026, 'Tuition Fee - March', 2500.00, 0.00, 2500.00),
(1499, 476, 1, 4, 2026, 'Tuition Fee - April', 2500.00, 0.00, 2500.00),
(1500, 476, 1, 5, 2026, 'Tuition Fee - May', 2500.00, 0.00, 2500.00),
(1501, 476, 1, 6, 2026, 'Tuition Fee - June', 2500.00, 0.00, 2500.00),
(1502, 476, 1, 7, 2026, 'Tuition Fee - July', 2500.00, 0.00, 2500.00),
(1503, 477, 1, 3, 2026, 'Tuition Fee - March', 2500.00, 0.00, 2500.00),
(1504, 477, 1, 4, 2026, 'Tuition Fee - April', 2500.00, 0.00, 2500.00),
(1505, 477, 1, 5, 2026, 'Tuition Fee - May', 2500.00, 0.00, 2500.00),
(1506, 477, 1, 6, 2026, 'Tuition Fee - June', 2500.00, 0.00, 2500.00),
(1507, 477, 1, 7, 2026, 'Tuition Fee - July', 2500.00, 0.00, 2500.00),
(1508, 478, 1, 3, 2026, 'Tuition Fee - March', 2500.00, 0.00, 2500.00),
(1509, 478, 1, 4, 2026, 'Tuition Fee - April', 2500.00, 0.00, 2500.00),
(1510, 478, 1, 5, 2026, 'Tuition Fee - May', 2500.00, 0.00, 2500.00),
(1511, 478, 1, 6, 2026, 'Tuition Fee - June', 2500.00, 0.00, 2500.00),
(1512, 478, 1, 7, 2026, 'Tuition Fee - July', 2500.00, 0.00, 2500.00),
(1513, 479, 1, 3, 2026, 'Tuition Fee - March', 2500.00, 0.00, 2500.00),
(1514, 479, 1, 4, 2026, 'Tuition Fee - April', 2500.00, 0.00, 2500.00),
(1515, 479, 1, 5, 2026, 'Tuition Fee - May', 2500.00, 0.00, 2500.00),
(1516, 479, 1, 6, 2026, 'Tuition Fee - June', 2500.00, 0.00, 2500.00),
(1517, 479, 1, 7, 2026, 'Tuition Fee - July', 2500.00, 0.00, 2500.00),
(1518, 480, 1, 3, 2026, 'Tuition Fee - March', 2500.00, 0.00, 2500.00),
(1519, 480, 1, 4, 2026, 'Tuition Fee - April', 2500.00, 0.00, 2500.00),
(1520, 480, 1, 5, 2026, 'Tuition Fee - May', 2500.00, 0.00, 2500.00),
(1521, 480, 1, 6, 2026, 'Tuition Fee - June', 2500.00, 0.00, 2500.00),
(1522, 480, 1, 7, 2026, 'Tuition Fee - July', 2500.00, 0.00, 2500.00),
(1523, 481, 1, 3, 2026, 'Tuition Fee - March', 2500.00, 0.00, 2500.00),
(1524, 481, 1, 4, 2026, 'Tuition Fee - April', 2500.00, 0.00, 2500.00),
(1525, 481, 1, 5, 2026, 'Tuition Fee - May', 2500.00, 0.00, 2500.00),
(1526, 481, 1, 6, 2026, 'Tuition Fee - June', 2500.00, 0.00, 2500.00),
(1527, 481, 1, 7, 2026, 'Tuition Fee - July', 2500.00, 0.00, 2500.00),
(1528, 482, 1, 3, 2026, 'Tuition Fee - March', 2500.00, 0.00, 2500.00),
(1529, 482, 1, 4, 2026, 'Tuition Fee - April', 2500.00, 0.00, 2500.00),
(1530, 482, 1, 5, 2026, 'Tuition Fee - May', 2500.00, 0.00, 2500.00),
(1531, 482, 1, 6, 2026, 'Tuition Fee - June', 2500.00, 0.00, 2500.00),
(1532, 482, 1, 7, 2026, 'Tuition Fee - July', 2500.00, 0.00, 2500.00),
(1533, 483, 1, 3, 2026, 'Tuition Fee - March', 2500.00, 0.00, 2500.00),
(1534, 483, 1, 4, 2026, 'Tuition Fee - April', 2500.00, 0.00, 2500.00),
(1535, 483, 1, 5, 2026, 'Tuition Fee - May', 2500.00, 0.00, 2500.00),
(1536, 483, 1, 6, 2026, 'Tuition Fee - June', 2500.00, 0.00, 2500.00),
(1537, 483, 1, 7, 2026, 'Tuition Fee - July', 2500.00, 0.00, 2500.00),
(1538, 484, 1, 3, 2026, 'Tuition Fee - March', 2500.00, 0.00, 2500.00),
(1539, 484, 1, 4, 2026, 'Tuition Fee - April', 2500.00, 0.00, 2500.00),
(1540, 484, 1, 5, 2026, 'Tuition Fee - May', 2500.00, 0.00, 2500.00),
(1541, 484, 1, 6, 2026, 'Tuition Fee - June', 2500.00, 0.00, 2500.00),
(1542, 484, 1, 7, 2026, 'Tuition Fee - July', 2500.00, 0.00, 2500.00),
(1543, 485, 1, 3, 2026, 'Tuition Fee - March', 2500.00, 0.00, 2500.00),
(1544, 485, 1, 4, 2026, 'Tuition Fee - April', 2500.00, 0.00, 2500.00),
(1545, 485, 1, 5, 2026, 'Tuition Fee - May', 2500.00, 0.00, 2500.00),
(1546, 485, 1, 6, 2026, 'Tuition Fee - June', 2500.00, 0.00, 2500.00),
(1547, 485, 1, 7, 2026, 'Tuition Fee - July', 2500.00, 0.00, 2500.00),
(1548, 486, 1, 3, 2026, 'Tuition Fee - March', 2300.00, 0.00, 2300.00),
(1549, 486, 1, 4, 2026, 'Tuition Fee - April', 2300.00, 0.00, 2300.00),
(1550, 486, 1, 5, 2026, 'Tuition Fee - May', 2300.00, 0.00, 2300.00),
(1551, 486, 1, 6, 2026, 'Tuition Fee - June', 2300.00, 0.00, 2300.00),
(1552, 486, 1, 7, 2026, 'Tuition Fee - July', 2300.00, 0.00, 2300.00),
(1553, 487, 1, 3, 2026, 'Tuition Fee - March', 2300.00, 0.00, 2300.00),
(1554, 487, 1, 4, 2026, 'Tuition Fee - April', 2300.00, 0.00, 2300.00),
(1555, 487, 1, 5, 2026, 'Tuition Fee - May', 2300.00, 0.00, 2300.00),
(1556, 487, 1, 6, 2026, 'Tuition Fee - June', 2300.00, 0.00, 2300.00),
(1557, 487, 1, 7, 2026, 'Tuition Fee - July', 2300.00, 0.00, 2300.00),
(1558, 488, 1, 3, 2026, 'Tuition Fee - March', 2300.00, 0.00, 2300.00),
(1559, 488, 1, 4, 2026, 'Tuition Fee - April', 2300.00, 0.00, 2300.00),
(1560, 488, 1, 5, 2026, 'Tuition Fee - May', 2300.00, 0.00, 2300.00),
(1561, 488, 1, 6, 2026, 'Tuition Fee - June', 2300.00, 0.00, 2300.00),
(1562, 488, 1, 7, 2026, 'Tuition Fee - July', 2300.00, 0.00, 2300.00),
(1563, 489, 1, 3, 2026, 'Tuition Fee - March', 2300.00, 0.00, 2300.00),
(1564, 489, 1, 4, 2026, 'Tuition Fee - April', 2300.00, 0.00, 2300.00),
(1565, 489, 1, 5, 2026, 'Tuition Fee - May', 2300.00, 0.00, 2300.00),
(1566, 489, 1, 6, 2026, 'Tuition Fee - June', 2300.00, 0.00, 2300.00),
(1567, 489, 1, 7, 2026, 'Tuition Fee - July', 2300.00, 0.00, 2300.00),
(1568, 490, 1, 3, 2026, 'Tuition Fee - March', 2300.00, 0.00, 2300.00),
(1569, 490, 1, 4, 2026, 'Tuition Fee - April', 2300.00, 0.00, 2300.00),
(1570, 490, 1, 5, 2026, 'Tuition Fee - May', 2300.00, 0.00, 2300.00),
(1571, 490, 1, 6, 2026, 'Tuition Fee - June', 2300.00, 0.00, 2300.00),
(1572, 490, 1, 7, 2026, 'Tuition Fee - July', 2300.00, 0.00, 2300.00),
(1573, 491, 1, 3, 2026, 'Tuition Fee - March', 2300.00, 0.00, 2300.00),
(1574, 491, 1, 4, 2026, 'Tuition Fee - April', 2300.00, 0.00, 2300.00),
(1575, 491, 1, 5, 2026, 'Tuition Fee - May', 2300.00, 0.00, 2300.00),
(1576, 491, 1, 6, 2026, 'Tuition Fee - June', 2300.00, 0.00, 2300.00),
(1577, 491, 1, 7, 2026, 'Tuition Fee - July', 2300.00, 0.00, 2300.00),
(1613, 510, 1, 4, 2026, 'Tuition Fee - April', 1000.00, 500.00, 500.00),
(1614, 510, 1, 5, 2026, 'Tuition Fee - May', 1000.00, 500.00, 500.00),
(1615, 510, 1, 6, 2026, 'Tuition Fee - June', 1000.00, 500.00, 500.00),
(1616, 511, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1617, 431, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1618, 510, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1619, 512, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1620, 513, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1621, 435, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1622, 436, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1623, 437, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1624, 438, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1625, 439, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1626, 440, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1627, 514, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1628, 442, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1629, 515, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1630, 444, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1631, 516, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1632, 446, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1633, 449, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1634, 450, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1635, 517, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1636, 452, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1637, 518, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1638, 519, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1639, 455, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1640, 456, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1641, 457, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1642, 458, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1643, 459, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1644, 460, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1645, 461, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1647, 463, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1648, 464, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1649, 249, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1650, 250, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1651, 251, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1652, 252, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1653, 520, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1654, 521, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1655, 522, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1656, 256, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1657, 257, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1658, 523, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1659, 259, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1660, 266, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1661, 261, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1662, 262, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1663, 524, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1664, 268, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1665, 525, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1666, 269, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1667, 270, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1668, 271, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1669, 526, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1670, 273, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1671, 274, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1672, 275, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1673, 276, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1674, 277, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1675, 278, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1676, 279, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1677, 280, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1678, 281, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1679, 527, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1680, 528, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1681, 284, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1682, 285, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1683, 529, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1684, 287, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1685, 288, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1686, 289, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1687, 290, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1688, 530, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1689, 292, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1690, 293, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1691, 294, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1692, 295, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1693, 296, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1694, 531, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1695, 298, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1696, 299, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1697, 300, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1698, 301, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1699, 302, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1700, 303, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1701, 304, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1702, 305, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1703, 532, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1704, 533, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1705, 308, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1706, 309, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1707, 310, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1708, 311, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1709, 312, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1710, 313, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1711, 314, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1712, 315, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1713, 316, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1714, 534, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1715, 318, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1716, 319, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1717, 320, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1718, 535, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1719, 536, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1720, 537, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1721, 324, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1722, 325, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1723, 326, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1724, 327, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1725, 328, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1726, 329, 4, NULL, NULL, 'Exam Fee', 380.00, 0.00, 380.00),
(1727, 330, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1728, 331, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1729, 332, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1730, 333, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1731, 334, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1732, 335, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1733, 538, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1734, 337, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1735, 338, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1736, 339, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1737, 340, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1738, 341, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1739, 342, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1740, 343, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1741, 344, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1742, 345, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1743, 346, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1744, 347, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1745, 539, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1746, 349, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1747, 350, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1748, 351, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1749, 540, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1750, 353, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1751, 541, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1752, 355, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1753, 356, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1754, 357, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1755, 542, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1756, 359, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1757, 360, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1758, 361, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1759, 362, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1760, 468, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1761, 364, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1762, 365, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1763, 366, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1764, 367, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1765, 543, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1766, 544, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1767, 545, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1768, 371, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1769, 372, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1770, 373, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1771, 374, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1772, 546, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1773, 376, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1774, 377, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1775, 378, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1776, 379, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1777, 547, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1778, 381, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1779, 382, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1780, 383, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1781, 384, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1783, 386, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1784, 387, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1785, 549, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1786, 389, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1787, 390, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1788, 391, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00),
(1789, 392, 4, NULL, NULL, 'Exam Fee', 400.00, 0.00, 400.00);

-- --------------------------------------------------------

--
-- Table structure for table `fee_student_reconciliation`
--

CREATE TABLE `fee_student_reconciliation` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `academic_year_id` int(11) DEFAULT NULL,
  `total_charged` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_discounts` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_fines` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_paid` decimal(10,2) NOT NULL DEFAULT 0.00,
  `last_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `id` int(11) NOT NULL,
  `grade_letter` varchar(10) NOT NULL,
  `min_score` decimal(6,2) NOT NULL,
  `max_score` decimal(6,2) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `grades`
--

INSERT INTO `grades` (`id`, `grade_letter`, `min_score`, `max_score`, `sort_order`) VALUES
(1, 'A+', 80.00, 100.00, 1),
(2, 'A', 70.00, 79.99, 2),
(3, 'B', 60.00, 69.99, 3),
(4, 'C', 50.00, 59.99, 4),
(5, 'D', 40.00, 49.99, 5),
(6, 'F', 0.00, 39.99, 6);

-- --------------------------------------------------------

--
-- Table structure for table `guardians`
--

CREATE TABLE `guardians` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `full_name` varchar(140) NOT NULL,
  `relation` varchar(50) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `guardians`
--

INSERT INTO `guardians` (`id`, `user_id`, `full_name`, `relation`, `phone`, `email`, `address`, `created_at`) VALUES
(1, 241, 'Muhammad', 'Father', '03555758660', NULL, '', '2026-07-03 07:10:37'),
(2, 242, 'Mubarak Ali', 'Father', '03555265110', NULL, 'Bilamik', '2026-07-03 07:12:15'),
(3, 243, 'Ali', 'Father', '03555461710', NULL, 'Thaliya', '2026-07-03 07:13:37'),
(4, 244, 'Fida Hussain', 'Father', '03554464864', NULL, 'Bilamik', '2026-07-03 07:15:17'),
(5, 245, 'Rustam', 'Father', '03551488490', NULL, 'Bilamik', '2026-07-03 07:16:34'),
(6, 246, 'Ghulam Abbas', 'Father', '03555131475', NULL, 'Changpapa', '2026-07-03 07:17:56'),
(7, 247, 'Muhammad Ishaq', 'Father', '03554976891', NULL, 'Changpapa', '2026-07-03 07:19:26'),
(8, 248, 'Muhammad', 'Father', '03552310832', NULL, '', '2026-07-03 07:20:55'),
(9, 249, 'Sher Muhammad', 'Father', '03555354136', NULL, 'Changpapa', '2026-07-03 07:22:18'),
(10, 250, 'ALI KHAN', 'Father', '03554174067', NULL, 'Skurbochan', '2026-07-03 07:23:42'),
(11, 251, 'Muhammad', 'Father', '03419265854', NULL, 'Skurbochan', '2026-07-03 07:25:56'),
(12, 252, 'Fida Hussain', 'Father', '03555437214', NULL, 'Bilamik', '2026-07-03 07:27:36'),
(13, 253, 'Muhammad Hussain', 'Father', '03555460721', NULL, 'Youlbroq', '2026-07-03 07:29:01'),
(14, 254, 'Muhammad Hassan', 'Father', '03555417448', NULL, '', '2026-07-03 07:31:23'),
(15, 255, 'Shair Muhammad', 'Father', NULL, NULL, '', '2026-07-13 05:51:07'),
(16, 256, 'Wazir Nazir', 'Father', NULL, NULL, '', '2026-07-13 05:52:32'),
(17, 257, 'Mubashir Hassan', 'Brother', '03145525749', 'mubashirbaltistani1@gmail.com', 'SCHS (Shifa Society) Main BOLVD Opposite Fazaia Colony Islamabad Express way Rawalpindi', '2026-07-17 11:48:19'),
(18, 258, 'MUHAMMAD TUFAIL', 'Father', NULL, NULL, '', '2026-07-19 04:33:35'),
(19, 259, 'Parent of Muez Ali Ali Cho', 'Father', NULL, NULL, '', '2026-07-19 04:34:50'),
(20, 260, 'Zahid Ali', 'Brother', NULL, NULL, '', '2026-07-19 07:37:25'),
(21, NULL, 'HASSAN', 'Father', NULL, NULL, '', '2026-08-06 10:31:24');

-- --------------------------------------------------------

--
-- Table structure for table `inquiries`
--

CREATE TABLE `inquiries` (
  `id` int(11) NOT NULL,
  `inquiry_no` varchar(30) NOT NULL,
  `requested_first_name` varchar(80) NOT NULL,
  `requested_last_name` varchar(80) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `requested_class_id` int(11) DEFAULT NULL,
  `requested_section_id` int(11) DEFAULT NULL,
  `status` enum('new','reviewed','approved','rejected','converted') NOT NULL DEFAULT 'new',
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `reviewed_by_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `label_overrides`
--

CREATE TABLE `label_overrides` (
  `id` int(11) NOT NULL,
  `module_name` varchar(60) NOT NULL,
  `field_key` varchar(120) NOT NULL,
  `label_text` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `label_overrides`
--

INSERT INTO `label_overrides` (`id`, `module_name`, `field_key`, `label_text`) VALUES
(1, 'students', 'father_name', 'Father\'s Name');

-- --------------------------------------------------------

--
-- Table structure for table `leave_approvals`
--

CREATE TABLE `leave_approvals` (
  `id` int(11) NOT NULL,
  `leave_request_id` int(11) NOT NULL,
  `approved_by_user_id` int(11) DEFAULT NULL,
  `decision` enum('approved','rejected') NOT NULL,
  `decision_note` varchar(255) DEFAULT NULL,
  `decided_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `leave_approvals`
--

INSERT INTO `leave_approvals` (`id`, `leave_request_id`, `approved_by_user_id`, `decision`, `decision_note`, `decided_at`) VALUES
(1, 1, 4, 'approved', 'leave granted', '2026-06-27 08:58:45'),
(2, 4, 4, 'approved', 'Ok', '2026-07-19 04:53:50'),
(3, 6, 4, 'approved', 'Ok', '2026-07-24 15:54:28'),
(4, 2, 233, 'rejected', 'No', '2026-07-25 12:37:15'),
(5, 7, 261, 'rejected', 'No', '2026-07-27 17:26:50'),
(6, 10, 6, 'approved', 'Ok', '2026-07-31 09:09:18');

-- --------------------------------------------------------

--
-- Table structure for table `leave_requests`
--

CREATE TABLE `leave_requests` (
  `id` int(11) NOT NULL,
  `staff_profile_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `applicant_type` enum('staff','student') NOT NULL DEFAULT 'staff',
  `leave_type` varchar(40) NOT NULL DEFAULT 'leave',
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `note` varchar(255) DEFAULT NULL,
  `requested_by_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `leave_requests`
--

INSERT INTO `leave_requests` (`id`, `staff_profile_id`, `student_id`, `applicant_type`, `leave_type`, `from_date`, `to_date`, `status`, `note`, `requested_by_user_id`, `created_at`) VALUES
(1, 8, NULL, 'staff', 'sick', '2026-06-28', '2026-06-29', 'approved', '', 4, '2026-06-27 08:58:03'),
(2, 7, NULL, 'staff', 'Sick', '2026-07-18', '2026-07-19', 'rejected', '', 4, '2026-07-17 17:25:59'),
(3, 11, NULL, 'staff', 'Sick', '2026-07-20', '2026-07-21', 'pending', '', 4, '2026-07-18 16:58:37'),
(4, 11, NULL, 'staff', 'Sick', '2026-07-20', '2026-07-21', 'approved', '', 7, '2026-07-18 17:24:27'),
(5, NULL, 793, 'student', 'work', '2026-07-28', '2026-07-30', 'pending', '', 15, '2026-07-18 17:29:25'),
(6, NULL, 793, 'student', 'Sick', '2026-07-17', '2026-07-18', 'approved', '', 15, '2026-07-19 04:09:58'),
(7, NULL, 793, 'student', 'Sick', '2026-07-31', '2026-08-01', 'rejected', '', 15, '2026-07-27 10:50:58'),
(8, NULL, 597, 'student', 'Sick', '2026-08-02', '2026-08-04', 'pending', '', 28, '2026-07-31 09:01:08'),
(9, NULL, 597, 'student', 'Sick', '2026-09-14', '2026-09-17', 'pending', '', 28, '2026-07-31 09:01:38'),
(10, NULL, 597, 'student', 'Sick', '2026-08-11', '2026-08-12', 'approved', '', 28, '2026-07-31 09:02:27'),
(11, NULL, 793, 'student', 'Sick', '2026-08-07', '2026-08-07', 'pending', '', 15, '2026-08-06 10:07:54');

-- --------------------------------------------------------

--
-- Table structure for table `login_ip_throttle`
--

CREATE TABLE `login_ip_throttle` (
  `ip_address` varchar(45) NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `window_started_at` datetime NOT NULL,
  `locked_until` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `login_ip_throttle`
--

INSERT INTO `login_ip_throttle` (`ip_address`, `attempts`, `window_started_at`, `locked_until`) VALUES
('118.107.131.12', 1, '2026-08-09 20:11:25', NULL),
('118.107.142.210', 1, '2026-08-09 20:52:30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `class_section_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `score` decimal(6,2) NOT NULL DEFAULT 0.00,
  `grade_id` int(11) DEFAULT NULL,
  `is_locked` tinyint(4) NOT NULL DEFAULT 0,
  `entered_by_user_id` int(11) DEFAULT NULL,
  `entered_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_by_user_id` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `total_marks` decimal(6,2) NOT NULL DEFAULT 100.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`id`, `exam_id`, `student_id`, `class_section_id`, `subject_id`, `score`, `grade_id`, `is_locked`, `entered_by_user_id`, `entered_at`, `updated_by_user_id`, `updated_at`, `total_marks`) VALUES
(467, 16, 591, 1, 29, 36.00, 2, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(468, 16, 592, 1, 29, 44.00, 1, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(469, 16, 595, 1, 29, 47.00, 1, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(470, 16, 596, 1, 29, 46.00, 1, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(471, 16, 597, 1, 29, 40.00, 1, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(472, 16, 598, 1, 29, 34.00, 3, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(473, 16, 599, 1, 29, 49.00, 1, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(474, 16, 600, 1, 29, 24.00, 5, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(475, 16, 602, 1, 29, 36.00, 2, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(476, 16, 603, 1, 29, 27.00, 4, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(477, 16, 604, 1, 29, 49.00, 1, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(478, 16, 605, 1, 29, 38.00, 2, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(479, 16, 606, 1, 29, 38.00, 2, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(480, 16, 607, 1, 29, 48.00, 1, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(481, 16, 608, 1, 29, 32.00, 3, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(482, 16, 609, 1, 29, 30.00, 3, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(483, 16, 610, 1, 29, 38.00, 2, 0, 6, '2026-07-19 19:19:56', 6, '2026-08-07 14:13:06', 50.00),
(484, 16, 591, 1, 39, 15.00, 6, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(485, 16, 592, 1, 39, 31.00, 3, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(486, 16, 595, 1, 39, 36.00, 2, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(487, 16, 596, 1, 39, 35.00, 2, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(488, 16, 597, 1, 39, 15.00, 6, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(489, 16, 598, 1, 39, 19.00, 6, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(490, 16, 599, 1, 39, 21.00, 5, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(491, 16, 600, 1, 39, 24.00, 5, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(492, 16, 602, 1, 39, 27.00, 4, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(493, 16, 603, 1, 39, 29.00, 4, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(494, 16, 604, 1, 39, 41.00, 1, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(495, 16, 605, 1, 39, 45.00, 1, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(496, 16, 606, 1, 39, 24.00, 5, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(497, 16, 607, 1, 39, 26.00, 4, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(498, 16, 608, 1, 39, 29.00, 4, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(499, 16, 609, 1, 39, 21.00, 5, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(500, 16, 610, 1, 39, 34.00, 3, 0, 4, '2026-07-19 19:21:48', 4, '2026-07-19 19:26:46', 50.00),
(501, 16, 591, 1, 47, 36.00, 2, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(502, 16, 592, 1, 47, 47.00, 1, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(503, 16, 595, 1, 47, 49.00, 1, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(504, 16, 596, 1, 47, 49.00, 1, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(505, 16, 597, 1, 47, 28.00, 4, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(506, 16, 598, 1, 47, 41.00, 1, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(507, 16, 599, 1, 47, 49.00, 1, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(508, 16, 600, 1, 47, 21.00, 5, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(509, 16, 602, 1, 47, 34.00, 3, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(510, 16, 603, 1, 47, 34.00, 3, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(511, 16, 604, 1, 47, 38.00, 2, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(512, 16, 605, 1, 47, 28.00, 4, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(513, 16, 606, 1, 47, 45.00, 1, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(514, 16, 607, 1, 47, 39.00, 2, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(515, 16, 608, 1, 47, 38.00, 2, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(516, 16, 609, 1, 47, 46.00, 1, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(517, 16, 610, 1, 47, 24.00, 5, 0, 4, '2026-07-19 19:22:21', 7, '2026-08-08 15:29:23', 50.00),
(552, 13, 718, 8, 50, 55.00, 2, 0, 21, '2026-07-26 09:33:57', 21, '2026-07-26 09:33:57', 75.00),
(553, 13, 719, 8, 50, 40.00, 4, 0, 21, '2026-07-26 09:33:57', 21, '2026-07-26 09:33:57', 75.00),
(554, 13, 720, 8, 50, 30.00, 5, 0, 21, '2026-07-26 09:33:57', 21, '2026-07-26 09:33:57', 75.00),
(555, 13, 721, 8, 50, 39.00, 4, 0, 21, '2026-07-26 09:33:57', 21, '2026-07-26 09:33:57', 75.00),
(556, 13, 722, 8, 50, 61.00, 1, 0, 21, '2026-07-26 09:33:57', 21, '2026-07-26 09:33:57', 75.00),
(557, 13, 723, 8, 50, 38.00, 4, 0, 21, '2026-07-26 09:33:57', 21, '2026-07-26 09:33:57', 75.00),
(558, 13, 724, 8, 50, 49.00, 3, 0, 21, '2026-07-26 09:33:57', 21, '2026-07-26 09:33:57', 75.00),
(559, 13, 725, 8, 50, 66.00, 1, 0, 21, '2026-07-26 09:33:57', 21, '2026-07-26 09:33:57', 75.00),
(560, 13, 726, 8, 50, 41.00, 4, 0, 21, '2026-07-26 09:33:57', 21, '2026-07-26 09:33:57', 75.00),
(561, 13, 727, 8, 50, 51.00, 3, 0, 21, '2026-07-26 09:33:57', 21, '2026-07-26 09:33:57', 75.00),
(562, 13, 728, 8, 50, 39.00, 4, 0, 21, '2026-07-26 09:33:57', 21, '2026-07-26 09:33:57', 75.00),
(563, 13, 729, 8, 50, 37.00, 5, 0, 21, '2026-07-26 09:33:57', 21, '2026-07-26 09:33:57', 75.00),
(564, 13, 730, 8, 50, 54.00, 2, 0, 21, '2026-07-26 09:33:57', 21, '2026-07-26 09:33:57', 75.00),
(565, 13, 731, 8, 50, 61.00, 1, 0, 21, '2026-07-26 09:33:57', 21, '2026-07-26 09:33:57', 75.00),
(566, 12, 705, 7, 43, 35.00, 5, 0, 7, '2026-07-28 15:17:51', 7, '2026-07-30 06:07:32', 75.00),
(567, 12, 706, 7, 43, 64.00, 1, 0, 7, '2026-07-28 15:17:51', 7, '2026-07-30 06:07:32', 75.00),
(568, 12, 707, 7, 43, 36.00, 5, 0, 7, '2026-07-28 15:17:51', 7, '2026-07-30 06:07:32', 75.00),
(569, 12, 708, 7, 43, 56.00, 2, 0, 7, '2026-07-28 15:17:51', 7, '2026-07-30 06:07:32', 75.00),
(570, 12, 709, 7, 43, 24.00, 6, 0, 7, '2026-07-28 15:17:51', 7, '2026-07-30 06:07:32', 75.00),
(571, 12, 710, 7, 43, 69.00, 1, 0, 7, '2026-07-28 15:17:51', 7, '2026-07-30 06:07:32', 75.00),
(572, 12, 711, 7, 43, 67.00, 1, 0, 7, '2026-07-28 15:17:51', 7, '2026-07-30 06:07:32', 75.00),
(573, 12, 712, 7, 43, 27.00, 6, 0, 7, '2026-07-28 15:17:51', 7, '2026-07-30 06:07:32', 75.00),
(574, 12, 713, 7, 43, 35.00, 5, 0, 7, '2026-07-28 15:17:51', 7, '2026-07-30 06:07:32', 75.00),
(575, 12, 714, 7, 43, 18.00, 6, 0, 7, '2026-07-28 15:17:51', 7, '2026-07-30 06:07:32', 75.00),
(576, 12, 715, 7, 43, 12.00, 6, 0, 7, '2026-07-28 15:17:51', 7, '2026-07-30 06:07:32', 75.00),
(577, 12, 716, 7, 43, 25.00, 6, 0, 7, '2026-07-28 15:17:51', 7, '2026-07-30 06:07:32', 75.00),
(578, 12, 717, 7, 43, 25.00, 6, 0, 7, '2026-07-28 15:17:51', 7, '2026-07-30 06:07:32', 75.00),
(592, 14, 732, 9, 48, 59.00, 2, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(593, 14, 733, 9, 48, 51.00, 3, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(594, 14, 734, 9, 48, 35.00, 5, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(595, 14, 735, 9, 48, 34.00, 5, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(596, 14, 736, 9, 48, 31.00, 5, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(597, 14, 737, 9, 48, 36.00, 5, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(598, 14, 738, 9, 48, 32.00, 5, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(599, 14, 739, 9, 48, 43.00, 4, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(600, 14, 740, 9, 48, 32.00, 5, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(601, 14, 741, 9, 48, 40.00, 4, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(602, 14, 742, 9, 48, 34.00, 5, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(603, 14, 743, 9, 48, 40.00, 4, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(604, 14, 744, 9, 48, 34.00, 5, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(605, 14, 745, 9, 48, 68.00, 1, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(606, 14, 746, 9, 48, 43.00, 4, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(607, 14, 747, 9, 48, 48.00, 3, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(608, 14, 748, 9, 48, 42.00, 4, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(609, 14, 749, 9, 48, 38.00, 4, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(610, 14, 750, 9, 48, 58.00, 2, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(611, 14, 751, 9, 48, 61.00, 1, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(612, 14, 752, 9, 48, 37.00, 5, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(613, 14, 753, 9, 48, 44.00, 4, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(614, 14, 754, 9, 48, 48.00, 3, 0, 7, '2026-07-28 15:20:56', 7, '2026-07-30 17:35:52', 75.00),
(674, 9, 644, 4, 45, 49.00, 1, 0, 7, '2026-07-30 17:42:37', 7, '2026-07-30 17:43:07', 50.00),
(675, 9, 645, 4, 45, 27.00, 4, 0, 7, '2026-07-30 17:42:37', 7, '2026-07-30 17:43:07', 50.00),
(676, 9, 646, 4, 45, 25.00, 4, 0, 7, '2026-07-30 17:42:37', 7, '2026-07-30 17:43:07', 50.00),
(677, 9, 647, 4, 45, 23.00, 5, 0, 7, '2026-07-30 17:42:37', 7, '2026-07-30 17:43:07', 50.00),
(678, 9, 648, 4, 45, 27.00, 4, 0, 7, '2026-07-30 17:42:37', 7, '2026-07-30 17:43:07', 50.00),
(679, 9, 649, 4, 45, 15.00, 6, 0, 7, '2026-07-30 17:42:37', 7, '2026-07-30 17:43:07', 50.00),
(680, 9, 650, 4, 45, 14.00, 6, 0, 7, '2026-07-30 17:42:37', 7, '2026-07-30 17:43:07', 50.00),
(681, 9, 651, 4, 45, 17.00, 6, 0, 7, '2026-07-30 17:42:37', 7, '2026-07-30 17:43:07', 50.00),
(682, 9, 652, 4, 45, 14.00, 6, 0, 7, '2026-07-30 17:42:37', 7, '2026-07-30 17:43:07', 50.00),
(683, 9, 653, 4, 45, 25.00, 4, 0, 7, '2026-07-30 17:42:37', 7, '2026-07-30 17:43:07', 50.00),
(684, 9, 654, 4, 45, 37.00, 2, 0, 7, '2026-07-30 17:42:37', 7, '2026-07-30 17:43:07', 50.00),
(685, 9, 655, 4, 45, 36.00, 2, 0, 7, '2026-07-30 17:42:37', 7, '2026-07-30 17:43:07', 50.00),
(698, 17, 627, 3, 46, 28.00, 4, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(699, 17, 628, 3, 46, 24.00, 5, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(700, 17, 629, 3, 46, 28.00, 4, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(701, 17, 630, 3, 46, 41.00, 1, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(702, 17, 631, 3, 46, 33.00, 3, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(703, 17, 632, 3, 46, 24.00, 5, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(704, 17, 633, 3, 46, 10.00, 6, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(705, 17, 634, 3, 46, 36.00, 2, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(706, 17, 635, 3, 46, 22.00, 5, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(707, 17, 636, 3, 46, 35.00, 2, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(708, 17, 637, 3, 46, 28.00, 4, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(709, 17, 638, 3, 46, 35.00, 2, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(710, 17, 639, 3, 46, 26.00, 4, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(711, 17, 640, 3, 46, 45.00, 1, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(712, 17, 641, 3, 46, 18.00, 6, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(713, 17, 642, 3, 46, 18.00, 6, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(714, 17, 643, 3, 46, 0.00, 6, 0, 7, '2026-07-30 17:47:20', 7, '2026-07-31 03:40:04', 50.00),
(732, 10, 656, 5, 49, 22.00, 5, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(733, 10, 657, 5, 49, 21.00, 5, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(734, 10, 658, 5, 49, 34.00, 3, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(735, 10, 659, 5, 49, 25.00, 4, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(736, 10, 660, 5, 49, 32.00, 3, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(737, 10, 661, 5, 49, 14.00, 6, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(738, 10, 662, 5, 49, 26.00, 4, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(739, 10, 663, 5, 49, 23.00, 5, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(740, 10, 664, 5, 49, 29.00, 4, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(741, 10, 665, 5, 49, 24.00, 5, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(742, 10, 666, 5, 49, 18.00, 6, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(743, 10, 667, 5, 49, 8.00, 6, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(744, 10, 668, 5, 49, 20.00, 5, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(745, 10, 669, 5, 49, 11.00, 6, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(746, 10, 670, 5, 49, 10.00, 6, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(747, 10, 671, 5, 49, 8.00, 6, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(748, 10, 672, 5, 49, 14.00, 6, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(749, 10, 673, 5, 49, 7.00, 6, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(750, 10, 674, 5, 49, 21.00, 5, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(751, 10, 675, 5, 49, 23.00, 5, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(752, 10, 676, 5, 49, 33.00, 3, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(753, 10, 677, 5, 49, 24.00, 5, 0, 7, '2026-07-30 17:58:53', 7, '2026-07-30 17:58:53', 50.00),
(754, 15, 755, 10, 44, 49.00, 3, 0, 7, '2026-07-30 18:02:53', 7, '2026-07-30 18:02:58', 75.00),
(755, 15, 756, 10, 44, 33.00, 5, 0, 7, '2026-07-30 18:02:53', 7, '2026-07-30 18:02:58', 75.00),
(756, 15, 757, 10, 44, 51.00, 3, 0, 7, '2026-07-30 18:02:53', 7, '2026-07-30 18:02:58', 75.00),
(757, 15, 758, 10, 44, 49.00, 3, 0, 7, '2026-07-30 18:02:53', 7, '2026-07-30 18:02:58', 75.00),
(758, 15, 759, 10, 44, 58.00, 2, 0, 7, '2026-07-30 18:02:53', 7, '2026-07-30 18:02:58', 75.00),
(759, 15, 760, 10, 44, 0.00, 6, 0, 7, '2026-07-30 18:02:53', 7, '2026-07-30 18:02:58', 75.00),
(760, 15, 761, 10, 44, 69.00, 1, 0, 7, '2026-07-30 18:02:53', 7, '2026-07-30 18:02:58', 75.00),
(761, 15, 762, 10, 44, 37.00, 5, 0, 7, '2026-07-30 18:02:53', 7, '2026-07-30 18:02:58', 75.00),
(762, 15, 763, 10, 44, 50.00, 3, 0, 7, '2026-07-30 18:02:53', 7, '2026-07-30 18:02:58', 75.00),
(763, 15, 764, 10, 44, 66.00, 1, 0, 7, '2026-07-30 18:02:53', 7, '2026-07-30 18:02:58', 75.00),
(764, 15, 765, 10, 44, 43.00, 4, 0, 7, '2026-07-30 18:02:53', 7, '2026-07-30 18:02:58', 75.00),
(765, 15, 766, 10, 44, 49.00, 3, 0, 7, '2026-07-30 18:02:53', 7, '2026-07-30 18:02:58', 75.00),
(766, 15, 767, 10, 44, 37.00, 5, 0, 7, '2026-07-30 18:02:53', 7, '2026-07-30 18:02:58', 75.00),
(839, 20, 787, 15, 113, 0.00, 6, 0, 261, '2026-07-30 19:13:28', 261, '2026-07-31 03:19:37', 100.00),
(840, 20, 788, 15, 113, 0.00, 6, 0, 261, '2026-07-30 19:13:28', 261, '2026-07-31 03:19:37', 100.00),
(841, 20, 789, 15, 113, 0.00, 6, 0, 261, '2026-07-30 19:13:28', 261, '2026-07-31 03:19:37', 100.00),
(842, 20, 790, 15, 113, 0.00, 6, 0, 261, '2026-07-30 19:13:28', 261, '2026-07-31 03:19:37', 100.00),
(843, 20, 791, 15, 113, 0.00, 6, 0, 261, '2026-07-30 19:13:28', 261, '2026-07-31 03:19:37', 100.00),
(844, 20, 792, 15, 113, 0.00, 6, 0, 261, '2026-07-30 19:13:28', 261, '2026-07-31 03:19:37', 100.00),
(845, 20, 793, 15, 113, 50.00, 4, 0, 261, '2026-07-30 19:13:28', 261, '2026-07-31 03:19:37', 100.00),
(846, 20, 787, 15, 73, 0.00, 6, 0, 261, '2026-07-30 19:13:36', 261, '2026-07-30 19:13:36', 100.00),
(847, 20, 788, 15, 73, 0.00, 6, 0, 261, '2026-07-30 19:13:36', 261, '2026-07-30 19:13:36', 100.00),
(848, 20, 789, 15, 73, 0.00, 6, 0, 261, '2026-07-30 19:13:36', 261, '2026-07-30 19:13:36', 100.00),
(849, 20, 790, 15, 73, 0.00, 6, 0, 261, '2026-07-30 19:13:36', 261, '2026-07-30 19:13:36', 100.00),
(850, 20, 791, 15, 73, 0.00, 6, 0, 261, '2026-07-30 19:13:36', 261, '2026-07-30 19:13:36', 100.00),
(851, 20, 792, 15, 73, 0.00, 6, 0, 261, '2026-07-30 19:13:36', 261, '2026-07-30 19:13:36', 100.00),
(852, 20, 793, 15, 73, 40.00, 5, 0, 261, '2026-07-30 19:13:36', 261, '2026-07-30 19:13:36', 100.00),
(853, 20, 787, 15, 90, 0.00, 6, 0, 261, '2026-07-30 19:13:45', 261, '2026-07-30 19:13:45', 100.00),
(854, 20, 788, 15, 90, 0.00, 6, 0, 261, '2026-07-30 19:13:45', 261, '2026-07-30 19:13:45', 100.00),
(855, 20, 789, 15, 90, 0.00, 6, 0, 261, '2026-07-30 19:13:45', 261, '2026-07-30 19:13:45', 100.00),
(856, 20, 790, 15, 90, 0.00, 6, 0, 261, '2026-07-30 19:13:45', 261, '2026-07-30 19:13:45', 100.00),
(857, 20, 791, 15, 90, 0.00, 6, 0, 261, '2026-07-30 19:13:45', 261, '2026-07-30 19:13:45', 100.00),
(858, 20, 792, 15, 90, 0.00, 6, 0, 261, '2026-07-30 19:13:45', 261, '2026-07-30 19:13:45', 100.00),
(859, 20, 793, 15, 90, 38.50, 6, 0, 261, '2026-07-30 19:13:45', 261, '2026-07-30 19:13:45', 100.00),
(860, 20, 787, 15, 81, 0.00, 6, 0, 261, '2026-07-30 19:13:52', 261, '2026-07-30 19:13:52', 100.00),
(861, 20, 788, 15, 81, 0.00, 6, 0, 261, '2026-07-30 19:13:52', 261, '2026-07-30 19:13:52', 100.00),
(862, 20, 789, 15, 81, 0.00, 6, 0, 261, '2026-07-30 19:13:52', 261, '2026-07-30 19:13:52', 100.00),
(863, 20, 790, 15, 81, 0.00, 6, 0, 261, '2026-07-30 19:13:52', 261, '2026-07-30 19:13:52', 100.00),
(864, 20, 791, 15, 81, 0.00, 6, 0, 261, '2026-07-30 19:13:52', 261, '2026-07-30 19:13:52', 100.00),
(865, 20, 792, 15, 81, 0.00, 6, 0, 261, '2026-07-30 19:13:52', 261, '2026-07-30 19:13:52', 100.00),
(866, 20, 793, 15, 81, 40.00, 5, 0, 261, '2026-07-30 19:13:52', 261, '2026-07-30 19:13:52', 100.00),
(867, 20, 787, 15, 94, 0.00, 6, 0, 261, '2026-07-30 19:14:04', 261, '2026-07-30 19:14:04', 100.00),
(868, 20, 788, 15, 94, 0.00, 6, 0, 261, '2026-07-30 19:14:04', 261, '2026-07-30 19:14:04', 100.00),
(869, 20, 789, 15, 94, 0.00, 6, 0, 261, '2026-07-30 19:14:04', 261, '2026-07-30 19:14:04', 100.00),
(870, 20, 790, 15, 94, 0.00, 6, 0, 261, '2026-07-30 19:14:04', 261, '2026-07-30 19:14:04', 100.00),
(871, 20, 791, 15, 94, 0.00, 6, 0, 261, '2026-07-30 19:14:04', 261, '2026-07-30 19:14:04', 100.00),
(872, 20, 792, 15, 94, 0.00, 6, 0, 261, '2026-07-30 19:14:04', 261, '2026-07-30 19:14:04', 100.00),
(873, 20, 793, 15, 94, 42.00, 5, 0, 261, '2026-07-30 19:14:04', 261, '2026-07-30 19:14:04', 100.00),
(874, 20, 787, 15, 89, 0.00, 6, 0, 261, '2026-07-30 19:14:11', 261, '2026-07-30 19:14:11', 100.00),
(875, 20, 788, 15, 89, 0.00, 6, 0, 261, '2026-07-30 19:14:11', 261, '2026-07-30 19:14:11', 100.00),
(876, 20, 789, 15, 89, 0.00, 6, 0, 261, '2026-07-30 19:14:11', 261, '2026-07-30 19:14:11', 100.00),
(877, 20, 790, 15, 89, 0.00, 6, 0, 261, '2026-07-30 19:14:11', 261, '2026-07-30 19:14:11', 100.00),
(878, 20, 791, 15, 89, 0.00, 6, 0, 261, '2026-07-30 19:14:11', 261, '2026-07-30 19:14:11', 100.00),
(879, 20, 792, 15, 89, 0.00, 6, 0, 261, '2026-07-30 19:14:11', 261, '2026-07-30 19:14:11', 100.00),
(880, 20, 793, 15, 89, 52.00, 4, 0, 261, '2026-07-30 19:14:11', 261, '2026-07-30 19:14:11', 100.00),
(905, 18, 611, 2, 57, 41.00, 1, 0, 261, '2026-08-01 12:09:35', 261, '2026-08-01 12:59:01', 50.00),
(906, 18, 612, 2, 57, 45.00, 1, 0, 261, '2026-08-01 12:09:35', 261, '2026-08-01 12:59:01', 50.00),
(907, 18, 613, 2, 57, 43.00, 1, 0, 261, '2026-08-01 12:09:35', 261, '2026-08-01 12:59:01', 50.00),
(908, 18, 614, 2, 57, 50.00, 1, 0, 261, '2026-08-01 12:09:35', 261, '2026-08-01 12:59:01', 50.00),
(909, 18, 615, 2, 57, 49.00, 1, 0, 261, '2026-08-01 12:09:35', 261, '2026-08-01 12:59:01', 50.00),
(910, 18, 616, 2, 57, 36.00, 2, 0, 261, '2026-08-01 12:09:35', 261, '2026-08-01 12:59:01', 50.00),
(911, 18, 617, 2, 57, 48.00, 1, 0, 261, '2026-08-01 12:09:35', 261, '2026-08-01 12:59:01', 50.00),
(912, 18, 618, 2, 57, 43.00, 1, 0, 261, '2026-08-01 12:09:35', 261, '2026-08-01 12:59:01', 50.00),
(913, 18, 619, 2, 57, 49.00, 1, 0, 261, '2026-08-01 12:09:35', 261, '2026-08-01 12:59:01', 50.00),
(914, 18, 620, 2, 57, 45.00, 1, 0, 261, '2026-08-01 12:09:35', 261, '2026-08-01 12:59:01', 50.00),
(915, 18, 621, 2, 57, 32.00, 3, 0, 261, '2026-08-01 12:09:35', 261, '2026-08-01 12:59:01', 50.00),
(916, 18, 622, 2, 57, 48.00, 1, 0, 261, '2026-08-01 12:09:35', 261, '2026-08-01 12:59:01', 50.00),
(917, 18, 623, 2, 57, 32.00, 3, 0, 261, '2026-08-01 12:09:35', 261, '2026-08-01 12:59:01', 50.00),
(919, 18, 625, 2, 57, 36.00, 2, 0, 261, '2026-08-01 12:09:35', 261, '2026-08-01 12:59:01', 50.00),
(920, 18, 626, 2, 57, 48.00, 1, 0, 261, '2026-08-01 12:09:35', 261, '2026-08-01 12:59:01', 50.00),
(921, 21, 787, 15, 73, 0.00, 6, 0, 261, '2026-08-01 12:39:53', 261, '2026-08-01 12:39:53', 75.00),
(922, 21, 788, 15, 73, 0.00, 6, 0, 261, '2026-08-01 12:39:53', 261, '2026-08-01 12:39:53', 75.00),
(923, 21, 789, 15, 73, 0.00, 6, 0, 261, '2026-08-01 12:39:53', 261, '2026-08-01 12:39:53', 75.00),
(924, 21, 790, 15, 73, 0.00, 6, 0, 261, '2026-08-01 12:39:53', 261, '2026-08-01 12:39:53', 75.00),
(925, 21, 791, 15, 73, 0.00, 6, 0, 261, '2026-08-01 12:39:53', 261, '2026-08-01 12:39:53', 75.00),
(926, 21, 792, 15, 73, 0.00, 6, 0, 261, '2026-08-01 12:39:53', 261, '2026-08-01 12:39:53', 75.00),
(927, 21, 793, 15, 73, 65.00, 1, 0, 261, '2026-08-01 12:39:53', 261, '2026-08-01 12:39:53', 75.00),
(928, 21, 787, 15, 90, 0.00, 6, 0, 261, '2026-08-01 12:40:02', 261, '2026-08-01 12:40:02', 75.00),
(929, 21, 788, 15, 90, 0.00, 6, 0, 261, '2026-08-01 12:40:02', 261, '2026-08-01 12:40:02', 75.00),
(930, 21, 789, 15, 90, 0.00, 6, 0, 261, '2026-08-01 12:40:02', 261, '2026-08-01 12:40:02', 75.00),
(931, 21, 790, 15, 90, 0.00, 6, 0, 261, '2026-08-01 12:40:02', 261, '2026-08-01 12:40:02', 75.00),
(932, 21, 791, 15, 90, 0.00, 6, 0, 261, '2026-08-01 12:40:02', 261, '2026-08-01 12:40:02', 75.00),
(933, 21, 792, 15, 90, 0.00, 6, 0, 261, '2026-08-01 12:40:02', 261, '2026-08-01 12:40:02', 75.00),
(934, 21, 793, 15, 90, 63.00, 1, 0, 261, '2026-08-01 12:40:02', 261, '2026-08-01 12:40:02', 75.00),
(935, 21, 787, 15, 116, 0.00, 6, 0, 261, '2026-08-01 12:40:36', 261, '2026-08-01 12:40:36', 75.00),
(936, 21, 788, 15, 116, 0.00, 6, 0, 261, '2026-08-01 12:40:36', 261, '2026-08-01 12:40:36', 75.00),
(937, 21, 789, 15, 116, 0.00, 6, 0, 261, '2026-08-01 12:40:36', 261, '2026-08-01 12:40:36', 75.00),
(938, 21, 790, 15, 116, 0.00, 6, 0, 261, '2026-08-01 12:40:36', 261, '2026-08-01 12:40:36', 75.00),
(939, 21, 791, 15, 116, 0.00, 6, 0, 261, '2026-08-01 12:40:36', 261, '2026-08-01 12:40:36', 75.00),
(940, 21, 792, 15, 116, 0.00, 6, 0, 261, '2026-08-01 12:40:36', 261, '2026-08-01 12:40:36', 75.00),
(941, 21, 793, 15, 116, 56.00, 2, 0, 261, '2026-08-01 12:40:36', 261, '2026-08-01 12:40:36', 75.00),
(942, 21, 787, 15, 81, 0.00, 6, 0, 261, '2026-08-01 12:40:46', 261, '2026-08-01 12:40:46', 75.00),
(943, 21, 788, 15, 81, 0.00, 6, 0, 261, '2026-08-01 12:40:46', 261, '2026-08-01 12:40:46', 75.00),
(944, 21, 789, 15, 81, 0.00, 6, 0, 261, '2026-08-01 12:40:46', 261, '2026-08-01 12:40:46', 75.00),
(945, 21, 790, 15, 81, 0.00, 6, 0, 261, '2026-08-01 12:40:46', 261, '2026-08-01 12:40:46', 75.00),
(946, 21, 791, 15, 81, 0.00, 6, 0, 261, '2026-08-01 12:40:46', 261, '2026-08-01 12:40:46', 75.00),
(947, 21, 792, 15, 81, 0.00, 6, 0, 261, '2026-08-01 12:40:46', 261, '2026-08-01 12:40:46', 75.00),
(948, 21, 793, 15, 81, 54.00, 2, 0, 261, '2026-08-01 12:40:46', 261, '2026-08-01 12:40:46', 75.00),
(949, 21, 787, 15, 94, 0.00, 6, 0, 261, '2026-08-01 12:40:56', 261, '2026-08-01 12:40:56', 75.00),
(950, 21, 788, 15, 94, 0.00, 6, 0, 261, '2026-08-01 12:40:56', 261, '2026-08-01 12:40:56', 75.00),
(951, 21, 789, 15, 94, 0.00, 6, 0, 261, '2026-08-01 12:40:56', 261, '2026-08-01 12:40:56', 75.00),
(952, 21, 790, 15, 94, 0.00, 6, 0, 261, '2026-08-01 12:40:56', 261, '2026-08-01 12:40:56', 75.00),
(953, 21, 791, 15, 94, 0.00, 6, 0, 261, '2026-08-01 12:40:56', 261, '2026-08-01 12:40:56', 75.00),
(954, 21, 792, 15, 94, 0.00, 6, 0, 261, '2026-08-01 12:40:56', 261, '2026-08-01 12:40:56', 75.00),
(955, 21, 793, 15, 94, 56.00, 2, 0, 261, '2026-08-01 12:40:56', 261, '2026-08-01 12:40:56', 75.00),
(956, 21, 787, 15, 113, 0.00, 6, 0, 261, '2026-08-01 12:41:08', 261, '2026-08-01 12:41:08', 75.00),
(957, 21, 788, 15, 113, 0.00, 6, 0, 261, '2026-08-01 12:41:08', 261, '2026-08-01 12:41:08', 75.00),
(958, 21, 789, 15, 113, 0.00, 6, 0, 261, '2026-08-01 12:41:08', 261, '2026-08-01 12:41:08', 75.00),
(959, 21, 790, 15, 113, 0.00, 6, 0, 261, '2026-08-01 12:41:08', 261, '2026-08-01 12:41:08', 75.00),
(960, 21, 791, 15, 113, 0.00, 6, 0, 261, '2026-08-01 12:41:08', 261, '2026-08-01 12:41:08', 75.00),
(961, 21, 792, 15, 113, 0.00, 6, 0, 261, '2026-08-01 12:41:08', 261, '2026-08-01 12:41:08', 75.00),
(962, 21, 793, 15, 113, 62.00, 1, 0, 261, '2026-08-01 12:41:08', 261, '2026-08-01 12:41:08', 75.00),
(963, 21, 787, 15, 89, 0.00, 6, 0, 261, '2026-08-01 12:41:36', 261, '2026-08-01 12:41:36', 75.00),
(964, 21, 788, 15, 89, 0.00, 6, 0, 261, '2026-08-01 12:41:36', 261, '2026-08-01 12:41:36', 75.00),
(965, 21, 789, 15, 89, 0.00, 6, 0, 261, '2026-08-01 12:41:36', 261, '2026-08-01 12:41:36', 75.00),
(966, 21, 790, 15, 89, 0.00, 6, 0, 261, '2026-08-01 12:41:36', 261, '2026-08-01 12:41:36', 75.00),
(967, 21, 791, 15, 89, 0.00, 6, 0, 261, '2026-08-01 12:41:36', 261, '2026-08-01 12:41:36', 75.00),
(968, 21, 792, 15, 89, 0.00, 6, 0, 261, '2026-08-01 12:41:36', 261, '2026-08-01 12:41:36', 75.00),
(969, 21, 793, 15, 89, 62.00, 1, 0, 261, '2026-08-01 12:41:36', 261, '2026-08-01 12:41:36', 75.00),
(986, 18, 643, 2, 57, 49.00, 1, 0, 261, '2026-08-01 12:59:01', 261, '2026-08-01 12:59:01', 50.00),
(987, 18, 611, 2, 69, 37.00, 2, 0, 261, '2026-08-01 13:07:39', 261, '2026-08-01 13:07:39', 50.00),
(988, 18, 612, 2, 69, 41.00, 1, 0, 261, '2026-08-01 13:07:39', 261, '2026-08-01 13:07:39', 50.00),
(989, 18, 613, 2, 69, 42.00, 1, 0, 261, '2026-08-01 13:07:39', 261, '2026-08-01 13:07:39', 50.00),
(990, 18, 614, 2, 69, 50.00, 1, 0, 261, '2026-08-01 13:07:39', 261, '2026-08-01 13:07:39', 50.00),
(991, 18, 615, 2, 69, 48.00, 1, 0, 261, '2026-08-01 13:07:39', 261, '2026-08-01 13:07:39', 50.00),
(992, 18, 616, 2, 69, 35.00, 2, 0, 261, '2026-08-01 13:07:39', 261, '2026-08-01 13:07:39', 50.00),
(993, 18, 617, 2, 69, 32.00, 3, 0, 261, '2026-08-01 13:07:39', 261, '2026-08-01 13:07:39', 50.00),
(994, 18, 618, 2, 69, 34.00, 3, 0, 261, '2026-08-01 13:07:39', 261, '2026-08-01 13:07:39', 50.00),
(995, 18, 619, 2, 69, 42.00, 1, 0, 261, '2026-08-01 13:07:39', 261, '2026-08-01 13:07:39', 50.00),
(996, 18, 620, 2, 69, 32.00, 3, 0, 261, '2026-08-01 13:07:39', 261, '2026-08-01 13:07:39', 50.00),
(997, 18, 621, 2, 69, 31.00, 3, 0, 261, '2026-08-01 13:07:39', 261, '2026-08-01 13:07:39', 50.00),
(998, 18, 622, 2, 69, 49.00, 1, 0, 261, '2026-08-01 13:07:39', 261, '2026-08-01 13:07:39', 50.00),
(999, 18, 623, 2, 69, 35.00, 2, 0, 261, '2026-08-01 13:07:39', 261, '2026-08-01 13:07:39', 50.00),
(1000, 18, 643, 2, 69, 50.00, 1, 0, 261, '2026-08-01 13:07:39', 261, '2026-08-01 13:07:39', 50.00),
(1001, 18, 625, 2, 69, 40.00, 1, 0, 261, '2026-08-01 13:07:39', 261, '2026-08-01 13:07:39', 50.00),
(1002, 18, 626, 2, 69, 34.00, 3, 0, 261, '2026-08-01 13:07:39', 261, '2026-08-01 13:07:39', 50.00),
(1003, 18, 611, 2, 30, 20.00, 5, 0, 261, '2026-08-01 13:09:54', 6, '2026-08-07 16:31:00', 50.00),
(1004, 18, 612, 2, 30, 24.00, 5, 0, 261, '2026-08-01 13:09:54', 6, '2026-08-07 16:31:00', 50.00),
(1005, 18, 613, 2, 30, 24.00, 5, 0, 261, '2026-08-01 13:09:54', 6, '2026-08-07 16:31:00', 50.00),
(1006, 18, 614, 2, 30, 46.00, 1, 0, 261, '2026-08-01 13:09:54', 6, '2026-08-07 16:31:00', 50.00),
(1007, 18, 615, 2, 30, 32.00, 3, 0, 261, '2026-08-01 13:09:54', 6, '2026-08-07 16:31:00', 50.00),
(1008, 18, 616, 2, 30, 38.00, 2, 0, 261, '2026-08-01 13:09:54', 6, '2026-08-07 16:31:00', 50.00),
(1009, 18, 617, 2, 30, 23.00, 5, 0, 261, '2026-08-01 13:09:54', 6, '2026-08-07 16:31:00', 50.00),
(1010, 18, 618, 2, 30, 20.00, 5, 0, 261, '2026-08-01 13:09:54', 6, '2026-08-07 16:31:00', 50.00),
(1011, 18, 619, 2, 30, 36.00, 2, 0, 261, '2026-08-01 13:09:54', 6, '2026-08-07 16:31:00', 50.00),
(1012, 18, 620, 2, 30, 9.00, 6, 0, 261, '2026-08-01 13:09:54', 6, '2026-08-07 16:31:00', 50.00),
(1013, 18, 621, 2, 30, 20.00, 5, 0, 261, '2026-08-01 13:09:54', 6, '2026-08-07 16:31:00', 50.00),
(1014, 18, 622, 2, 30, 39.00, 2, 0, 261, '2026-08-01 13:09:54', 6, '2026-08-07 16:31:00', 50.00),
(1015, 18, 623, 2, 30, 14.00, 6, 0, 261, '2026-08-01 13:09:54', 6, '2026-08-07 16:31:00', 50.00),
(1016, 18, 643, 2, 30, 20.00, 5, 0, 261, '2026-08-01 13:09:54', 6, '2026-08-07 16:31:00', 50.00),
(1017, 18, 625, 2, 30, 20.00, 5, 0, 261, '2026-08-01 13:09:54', 6, '2026-08-07 16:31:00', 50.00),
(1018, 18, 626, 2, 30, 21.00, 5, 0, 261, '2026-08-01 13:09:54', 6, '2026-08-07 16:31:00', 50.00),
(1067, 15, 755, 10, 59, 44.00, 4, 0, 236, '2026-08-05 10:51:23', 236, '2026-08-05 10:52:20', 75.00),
(1068, 15, 756, 10, 59, 37.00, 5, 0, 236, '2026-08-05 10:51:23', 236, '2026-08-05 10:52:20', 75.00),
(1069, 15, 757, 10, 59, 55.00, 2, 0, 236, '2026-08-05 10:51:23', 236, '2026-08-05 10:52:20', 75.00),
(1070, 15, 758, 10, 59, 53.00, 2, 0, 236, '2026-08-05 10:51:23', 236, '2026-08-05 10:52:20', 75.00),
(1071, 15, 759, 10, 59, 56.00, 2, 0, 236, '2026-08-05 10:51:23', 236, '2026-08-05 10:52:20', 75.00),
(1072, 15, 761, 10, 59, 72.00, 1, 0, 236, '2026-08-05 10:51:23', 236, '2026-08-05 10:52:20', 75.00),
(1073, 15, 762, 10, 59, 50.00, 3, 0, 236, '2026-08-05 10:51:23', 236, '2026-08-05 10:52:20', 75.00),
(1074, 15, 763, 10, 59, 54.00, 2, 0, 236, '2026-08-05 10:51:23', 236, '2026-08-05 10:52:20', 75.00),
(1075, 15, 764, 10, 59, 69.00, 1, 0, 236, '2026-08-05 10:51:23', 236, '2026-08-05 10:52:20', 75.00),
(1076, 15, 765, 10, 59, 40.00, 4, 0, 236, '2026-08-05 10:51:23', 236, '2026-08-05 10:52:20', 75.00),
(1077, 15, 766, 10, 59, 55.00, 2, 0, 236, '2026-08-05 10:51:23', 236, '2026-08-05 10:52:20', 75.00),
(1078, 15, 767, 10, 59, 53.00, 2, 0, 236, '2026-08-05 10:51:23', 236, '2026-08-05 10:52:20', 75.00),
(1091, 14, 732, 9, 58, 62.00, 1, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1092, 14, 733, 9, 58, 52.00, 3, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1093, 14, 734, 9, 58, 30.00, 5, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1094, 14, 735, 9, 58, 24.00, 6, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1095, 14, 736, 9, 58, 36.00, 5, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1096, 14, 737, 9, 58, 32.00, 5, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1097, 14, 738, 9, 58, 30.00, 5, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1098, 14, 739, 9, 58, 36.00, 5, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1099, 14, 740, 9, 58, 33.00, 5, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1100, 14, 741, 9, 58, 48.00, 3, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1101, 14, 742, 9, 58, 21.00, 6, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1102, 14, 743, 9, 58, 21.00, 6, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1103, 14, 744, 9, 58, 23.00, 6, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1104, 14, 745, 9, 58, 66.00, 1, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1105, 14, 746, 9, 58, 22.00, 6, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1106, 14, 747, 9, 58, 30.00, 5, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1107, 14, 748, 9, 58, 18.00, 6, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1108, 14, 749, 9, 58, 19.00, 6, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1109, 14, 750, 9, 58, 51.00, 3, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1110, 14, 751, 9, 58, 67.00, 1, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1111, 14, 752, 9, 58, 22.00, 6, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1112, 14, 753, 9, 58, 31.00, 5, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1113, 14, 754, 9, 58, 55.00, 2, 0, 236, '2026-08-05 11:14:12', 236, '2026-08-05 11:14:12', 75.00),
(1114, 12, 705, 7, 60, 60.00, 1, 0, 236, '2026-08-05 13:51:29', 236, '2026-08-05 13:51:29', 75.00),
(1115, 12, 706, 7, 60, 72.00, 1, 0, 236, '2026-08-05 13:51:29', 236, '2026-08-05 13:51:29', 75.00),
(1116, 12, 707, 7, 60, 63.00, 1, 0, 236, '2026-08-05 13:51:29', 236, '2026-08-05 13:51:29', 75.00),
(1117, 12, 708, 7, 60, 66.00, 1, 0, 236, '2026-08-05 13:51:29', 236, '2026-08-05 13:51:29', 75.00),
(1118, 12, 709, 7, 60, 57.00, 2, 0, 236, '2026-08-05 13:51:29', 236, '2026-08-05 13:51:29', 75.00),
(1119, 12, 710, 7, 60, 62.00, 1, 0, 236, '2026-08-05 13:51:29', 236, '2026-08-05 13:51:29', 75.00),
(1120, 12, 711, 7, 60, 70.00, 1, 0, 236, '2026-08-05 13:51:29', 236, '2026-08-05 13:51:29', 75.00),
(1121, 12, 712, 7, 60, 57.00, 2, 0, 236, '2026-08-05 13:51:29', 236, '2026-08-05 13:51:29', 75.00),
(1122, 12, 713, 7, 60, 59.00, 2, 0, 236, '2026-08-05 13:51:29', 236, '2026-08-05 13:51:29', 75.00),
(1123, 12, 714, 7, 60, 21.00, 6, 0, 236, '2026-08-05 13:51:29', 236, '2026-08-05 13:51:29', 75.00),
(1124, 12, 715, 7, 60, 19.00, 6, 0, 236, '2026-08-05 13:51:29', 236, '2026-08-05 13:51:29', 75.00),
(1125, 12, 716, 7, 60, 64.00, 1, 0, 236, '2026-08-05 13:51:29', 236, '2026-08-05 13:51:29', 75.00),
(1126, 12, 717, 7, 60, 52.00, 3, 0, 236, '2026-08-05 13:51:29', 236, '2026-08-05 13:51:29', 75.00),
(1127, 12, 705, 7, 64, 58.00, 2, 0, 236, '2026-08-05 13:56:18', 236, '2026-08-05 13:56:24', 75.00),
(1128, 12, 706, 7, 64, 70.00, 1, 0, 236, '2026-08-05 13:56:18', 236, '2026-08-05 13:56:24', 75.00),
(1129, 12, 707, 7, 64, 46.00, 3, 0, 236, '2026-08-05 13:56:18', 236, '2026-08-05 13:56:24', 75.00),
(1130, 12, 708, 7, 64, 66.00, 1, 0, 236, '2026-08-05 13:56:18', 236, '2026-08-05 13:56:24', 75.00),
(1131, 12, 709, 7, 64, 31.00, 5, 0, 236, '2026-08-05 13:56:18', 236, '2026-08-05 13:56:24', 75.00),
(1132, 12, 710, 7, 64, 73.00, 1, 0, 236, '2026-08-05 13:56:18', 236, '2026-08-05 13:56:24', 75.00),
(1133, 12, 711, 7, 64, 70.00, 1, 0, 236, '2026-08-05 13:56:18', 236, '2026-08-05 13:56:24', 75.00),
(1134, 12, 712, 7, 64, 50.00, 3, 0, 236, '2026-08-05 13:56:18', 236, '2026-08-05 13:56:24', 75.00),
(1135, 12, 713, 7, 64, 31.00, 5, 0, 236, '2026-08-05 13:56:18', 236, '2026-08-05 13:56:24', 75.00),
(1136, 12, 714, 7, 64, 34.00, 5, 0, 236, '2026-08-05 13:56:18', 236, '2026-08-05 13:56:24', 75.00),
(1137, 12, 715, 7, 64, 23.00, 6, 0, 236, '2026-08-05 13:56:18', 236, '2026-08-05 13:56:24', 75.00),
(1138, 12, 716, 7, 64, 48.00, 3, 0, 236, '2026-08-05 13:56:18', 236, '2026-08-05 13:56:24', 75.00),
(1139, 12, 717, 7, 64, 36.00, 5, 0, 236, '2026-08-05 13:56:18', 236, '2026-08-05 13:56:24', 75.00),
(1153, 9, 644, 4, 62, 48.00, 1, 0, 236, '2026-08-05 14:03:36', 236, '2026-08-05 14:03:36', 50.00),
(1154, 9, 645, 4, 62, 30.00, 3, 0, 236, '2026-08-05 14:03:36', 236, '2026-08-05 14:03:36', 50.00),
(1155, 9, 646, 4, 62, 36.00, 2, 0, 236, '2026-08-05 14:03:36', 236, '2026-08-05 14:03:36', 50.00),
(1156, 9, 647, 4, 62, 26.00, 4, 0, 236, '2026-08-05 14:03:36', 236, '2026-08-05 14:03:36', 50.00),
(1157, 9, 648, 4, 62, 21.00, 5, 0, 236, '2026-08-05 14:03:36', 236, '2026-08-05 14:03:36', 50.00),
(1158, 9, 649, 4, 62, 23.00, 5, 0, 236, '2026-08-05 14:03:36', 236, '2026-08-05 14:03:36', 50.00),
(1159, 9, 650, 4, 62, 23.00, 5, 0, 236, '2026-08-05 14:03:36', 236, '2026-08-05 14:03:36', 50.00),
(1160, 9, 651, 4, 62, 20.00, 5, 0, 236, '2026-08-05 14:03:36', 236, '2026-08-05 14:03:36', 50.00),
(1161, 9, 652, 4, 62, 20.00, 5, 0, 236, '2026-08-05 14:03:36', 236, '2026-08-05 14:03:36', 50.00),
(1162, 9, 653, 4, 62, 28.00, 4, 0, 236, '2026-08-05 14:03:36', 236, '2026-08-05 14:03:36', 50.00),
(1163, 9, 654, 4, 62, 31.00, 3, 0, 236, '2026-08-05 14:03:36', 236, '2026-08-05 14:03:36', 50.00),
(1164, 9, 655, 4, 62, 34.00, 3, 0, 236, '2026-08-05 14:03:36', 236, '2026-08-05 14:03:36', 50.00),
(1165, 17, 627, 3, 63, 35.00, 2, 0, 236, '2026-08-05 14:18:42', 236, '2026-08-05 14:18:42', 50.00),
(1166, 17, 628, 3, 63, 30.00, 3, 0, 236, '2026-08-05 14:18:42', 236, '2026-08-05 14:18:42', 50.00),
(1167, 17, 629, 3, 63, 27.00, 4, 0, 236, '2026-08-05 14:18:42', 236, '2026-08-05 14:18:42', 50.00),
(1168, 17, 630, 3, 63, 33.00, 3, 0, 236, '2026-08-05 14:18:42', 236, '2026-08-05 14:18:42', 50.00),
(1169, 17, 631, 3, 63, 21.00, 5, 0, 236, '2026-08-05 14:18:42', 236, '2026-08-05 14:18:42', 50.00),
(1170, 17, 632, 3, 63, 31.00, 3, 0, 236, '2026-08-05 14:18:42', 236, '2026-08-05 14:18:42', 50.00),
(1171, 17, 633, 3, 63, 22.00, 5, 0, 236, '2026-08-05 14:18:42', 236, '2026-08-05 14:18:42', 50.00),
(1172, 17, 634, 3, 63, 35.00, 2, 0, 236, '2026-08-05 14:18:42', 236, '2026-08-05 14:18:42', 50.00),
(1173, 17, 635, 3, 63, 28.00, 4, 0, 236, '2026-08-05 14:18:42', 236, '2026-08-05 14:18:42', 50.00),
(1174, 17, 636, 3, 63, 25.00, 4, 0, 236, '2026-08-05 14:18:42', 236, '2026-08-05 14:18:42', 50.00),
(1175, 17, 637, 3, 63, 32.00, 3, 0, 236, '2026-08-05 14:18:42', 236, '2026-08-05 14:18:42', 50.00),
(1176, 17, 638, 3, 63, 27.00, 4, 0, 236, '2026-08-05 14:18:42', 236, '2026-08-05 14:18:42', 50.00),
(1177, 17, 639, 3, 63, 20.00, 5, 0, 236, '2026-08-05 14:18:42', 236, '2026-08-05 14:18:42', 50.00),
(1178, 17, 640, 3, 63, 49.00, 1, 0, 236, '2026-08-05 14:18:42', 236, '2026-08-05 14:18:42', 50.00),
(1179, 17, 641, 3, 63, 26.00, 4, 0, 236, '2026-08-05 14:18:42', 236, '2026-08-05 14:18:42', 50.00),
(1180, 17, 642, 3, 63, 25.00, 4, 0, 236, '2026-08-05 14:18:42', 236, '2026-08-05 14:18:42', 50.00),
(1181, 22, 611, 2, 57, 41.00, 5, 0, 236, '2026-08-05 14:23:28', 236, '2026-08-05 14:23:28', 100.00),
(1182, 22, 612, 2, 57, 45.00, 5, 0, 236, '2026-08-05 14:23:28', 236, '2026-08-05 14:23:28', 100.00),
(1183, 22, 613, 2, 57, 43.00, 5, 0, 236, '2026-08-05 14:23:28', 236, '2026-08-05 14:23:28', 100.00),
(1184, 22, 614, 2, 57, 50.00, 4, 0, 236, '2026-08-05 14:23:28', 236, '2026-08-05 14:23:28', 100.00),
(1185, 22, 615, 2, 57, 49.00, 5, 0, 236, '2026-08-05 14:23:28', 236, '2026-08-05 14:23:28', 100.00),
(1186, 22, 616, 2, 57, 36.00, 6, 0, 236, '2026-08-05 14:23:28', 236, '2026-08-05 14:23:28', 100.00),
(1187, 22, 617, 2, 57, 48.00, 5, 0, 236, '2026-08-05 14:23:28', 236, '2026-08-05 14:23:28', 100.00),
(1188, 22, 618, 2, 57, 43.00, 5, 0, 236, '2026-08-05 14:23:28', 236, '2026-08-05 14:23:28', 100.00),
(1189, 22, 619, 2, 57, 49.00, 5, 0, 236, '2026-08-05 14:23:28', 236, '2026-08-05 14:23:28', 100.00),
(1190, 22, 620, 2, 57, 45.00, 5, 0, 236, '2026-08-05 14:23:28', 236, '2026-08-05 14:23:28', 100.00),
(1191, 22, 621, 2, 57, 32.00, 6, 0, 236, '2026-08-05 14:23:28', 236, '2026-08-05 14:23:28', 100.00),
(1192, 22, 622, 2, 57, 48.00, 5, 0, 236, '2026-08-05 14:23:28', 236, '2026-08-05 14:23:28', 100.00),
(1193, 22, 623, 2, 57, 32.00, 6, 0, 236, '2026-08-05 14:23:28', 236, '2026-08-05 14:23:28', 100.00),
(1194, 22, 643, 2, 57, 49.00, 5, 0, 236, '2026-08-05 14:23:28', 236, '2026-08-05 14:23:28', 100.00),
(1195, 22, 625, 2, 57, 36.00, 6, 0, 236, '2026-08-05 14:23:28', 236, '2026-08-05 14:23:28', 100.00),
(1196, 22, 626, 2, 57, 48.00, 5, 0, 236, '2026-08-05 14:23:28', 236, '2026-08-05 14:23:28', 100.00),
(1197, 11, 678, 6, 56, 36.00, 2, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1198, 11, 679, 6, 56, 44.00, 1, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1199, 11, 680, 6, 56, 20.00, 5, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1200, 11, 681, 6, 56, 20.00, 5, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1201, 11, 682, 6, 56, 27.00, 4, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1202, 11, 683, 6, 56, 48.00, 1, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1203, 11, 684, 6, 56, 25.00, 4, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1204, 11, 685, 6, 56, 35.00, 2, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1205, 11, 686, 6, 56, 28.00, 4, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1206, 11, 687, 6, 56, 25.00, 4, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1207, 11, 688, 6, 56, 10.00, 6, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1208, 11, 689, 6, 56, 47.00, 1, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1209, 11, 690, 6, 56, 8.00, 6, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1210, 11, 691, 6, 56, 25.00, 4, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1211, 11, 692, 6, 56, 32.00, 3, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1212, 11, 693, 6, 56, 14.00, 6, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1213, 11, 694, 6, 56, 29.00, 4, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1214, 11, 695, 6, 56, 41.00, 1, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1215, 11, 696, 6, 56, 20.00, 5, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1216, 11, 697, 6, 56, 35.00, 2, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1217, 11, 698, 6, 56, 22.00, 5, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1218, 11, 699, 6, 56, 21.00, 5, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1219, 11, 700, 6, 56, 20.00, 5, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1220, 11, 701, 6, 56, 20.00, 5, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1221, 11, 702, 6, 56, 43.00, 1, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1222, 11, 703, 6, 56, 20.00, 5, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1223, 11, 704, 6, 56, 11.00, 6, 0, 21, '2026-08-05 14:41:11', 21, '2026-08-05 14:41:11', 50.00),
(1224, 25, 780, 16, 91, 46.00, 3, 0, 7, '2026-08-05 15:32:32', 7, '2026-08-05 15:32:32', 75.00),
(1225, 25, 590, 16, 91, 0.00, 6, 0, 7, '2026-08-05 15:32:32', 7, '2026-08-05 15:32:32', 75.00),
(1226, 25, 782, 16, 91, 0.00, 6, 0, 7, '2026-08-05 15:32:32', 7, '2026-08-05 15:32:32', 75.00),
(1227, 25, 589, 16, 91, 0.00, 6, 0, 7, '2026-08-05 15:32:32', 7, '2026-08-05 15:32:32', 75.00),
(1228, 25, 784, 16, 91, 0.00, 6, 0, 7, '2026-08-05 15:32:32', 7, '2026-08-05 15:32:32', 75.00),
(1229, 25, 785, 16, 91, 0.00, 6, 0, 7, '2026-08-05 15:32:32', 7, '2026-08-05 15:32:32', 75.00),
(1230, 25, 780, 16, 88, 52.00, 3, 0, 7, '2026-08-05 15:33:03', 7, '2026-08-05 16:02:14', 75.00),
(1231, 25, 590, 16, 88, 43.00, 4, 0, 7, '2026-08-05 15:33:03', 7, '2026-08-05 16:02:14', 75.00),
(1232, 25, 782, 16, 88, 55.00, 2, 0, 7, '2026-08-05 15:33:03', 7, '2026-08-05 16:02:14', 75.00),
(1233, 25, 589, 16, 88, 48.00, 3, 0, 7, '2026-08-05 15:33:03', 7, '2026-08-05 16:02:14', 75.00),
(1234, 25, 784, 16, 88, 50.00, 3, 0, 7, '2026-08-05 15:33:03', 7, '2026-08-05 16:02:14', 75.00),
(1235, 25, 785, 16, 88, 47.00, 3, 0, 7, '2026-08-05 15:33:03', 7, '2026-08-05 16:02:14', 75.00),
(1236, 26, 768, 13, 87, 53.00, 2, 0, 7, '2026-08-05 15:33:23', 7, '2026-08-05 15:54:46', 75.00),
(1237, 26, 769, 13, 87, 48.00, 3, 0, 7, '2026-08-05 15:33:23', 7, '2026-08-05 15:54:46', 75.00),
(1238, 26, 770, 13, 87, 54.00, 2, 0, 7, '2026-08-05 15:33:23', 7, '2026-08-05 15:54:46', 75.00),
(1239, 26, 771, 13, 87, 66.00, 1, 0, 7, '2026-08-05 15:33:23', 7, '2026-08-05 15:54:46', 75.00),
(1240, 26, 772, 13, 87, 50.00, 3, 0, 7, '2026-08-05 15:33:23', 7, '2026-08-05 15:54:46', 75.00),
(1241, 26, 773, 13, 87, 49.00, 3, 0, 7, '2026-08-05 15:33:23', 7, '2026-08-05 15:54:46', 75.00),
(1242, 26, 774, 13, 87, 46.00, 3, 0, 7, '2026-08-05 15:33:23', 7, '2026-08-05 15:54:46', 75.00),
(1243, 26, 775, 13, 87, 45.00, 3, 0, 7, '2026-08-05 15:33:23', 7, '2026-08-05 15:54:46', 75.00),
(1244, 26, 776, 13, 87, 47.00, 3, 0, 7, '2026-08-05 15:33:23', 7, '2026-08-05 15:54:46', 75.00),
(1245, 26, 777, 13, 87, 53.00, 2, 0, 7, '2026-08-05 15:33:23', 7, '2026-08-05 15:54:46', 75.00),
(1246, 26, 778, 13, 87, 43.00, 4, 0, 7, '2026-08-05 15:33:23', 7, '2026-08-05 15:54:46', 75.00),
(1247, 26, 779, 13, 87, 55.00, 2, 0, 7, '2026-08-05 15:33:23', 7, '2026-08-05 15:54:46', 75.00),
(1308, 11, 678, 6, 61, 15.00, 6, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1309, 11, 679, 6, 61, 50.00, 1, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1310, 11, 680, 6, 61, 40.00, 1, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1311, 11, 681, 6, 61, 30.00, 3, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1312, 11, 682, 6, 61, 23.00, 5, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1313, 11, 683, 6, 61, 50.00, 1, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1314, 11, 684, 6, 61, 42.00, 1, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1315, 11, 685, 6, 61, 47.00, 1, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1316, 11, 686, 6, 61, 44.00, 1, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1317, 11, 687, 6, 61, 22.00, 5, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1318, 11, 688, 6, 61, 20.00, 5, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1319, 11, 689, 6, 61, 50.00, 1, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1320, 11, 690, 6, 61, 20.00, 5, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1321, 11, 691, 6, 61, 36.00, 2, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1322, 11, 692, 6, 61, 20.00, 5, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1323, 11, 693, 6, 61, 25.00, 4, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1324, 11, 694, 6, 61, 28.00, 4, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1325, 11, 695, 6, 61, 48.00, 1, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1326, 11, 696, 6, 61, 31.00, 3, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1327, 11, 697, 6, 61, 43.00, 1, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1328, 11, 698, 6, 61, 40.00, 1, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1329, 11, 699, 6, 61, 20.00, 5, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1330, 11, 700, 6, 61, 46.00, 1, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1331, 11, 701, 6, 61, 32.00, 3, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1332, 11, 702, 6, 61, 50.00, 1, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1333, 11, 703, 6, 61, 40.00, 1, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1334, 11, 704, 6, 61, 23.00, 5, 0, 236, '2026-08-05 16:17:14', 236, '2026-08-05 16:17:14', 50.00),
(1335, 14, 732, 9, 54, 57.00, 2, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1336, 14, 733, 9, 54, 49.00, 3, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1337, 14, 734, 9, 54, 40.00, 4, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1338, 14, 735, 9, 54, 38.00, 4, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1339, 14, 736, 9, 54, 36.00, 5, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1340, 14, 737, 9, 54, 47.00, 3, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1341, 14, 738, 9, 54, 39.00, 4, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1342, 14, 739, 9, 54, 32.00, 5, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1343, 14, 740, 9, 54, 36.00, 5, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1344, 14, 741, 9, 54, 34.00, 5, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1345, 14, 742, 9, 54, 22.00, 6, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1346, 14, 743, 9, 54, 36.00, 5, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1347, 14, 744, 9, 54, 32.00, 5, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1348, 14, 745, 9, 54, 63.00, 1, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1349, 14, 746, 9, 54, 35.00, 5, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1350, 14, 747, 9, 54, 43.00, 4, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1351, 14, 748, 9, 54, 30.00, 5, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1352, 14, 749, 9, 54, 31.00, 5, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1353, 14, 750, 9, 54, 59.00, 2, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1354, 14, 751, 9, 54, 61.00, 1, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1355, 14, 752, 9, 54, 30.00, 5, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1356, 14, 753, 9, 54, 36.00, 5, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1357, 14, 754, 9, 54, 49.00, 3, 0, 21, '2026-08-07 06:40:44', 21, '2026-08-07 06:40:44', 75.00),
(1358, 11, 678, 6, 51, 36.00, 2, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1359, 11, 679, 6, 51, 44.00, 1, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1360, 11, 680, 6, 51, 20.00, 5, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1361, 11, 681, 6, 51, 20.00, 5, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1362, 11, 682, 6, 51, 27.00, 4, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1363, 11, 683, 6, 51, 48.00, 1, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1364, 11, 684, 6, 51, 25.00, 4, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1365, 11, 685, 6, 51, 35.00, 2, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00);
INSERT INTO `marks` (`id`, `exam_id`, `student_id`, `class_section_id`, `subject_id`, `score`, `grade_id`, `is_locked`, `entered_by_user_id`, `entered_at`, `updated_by_user_id`, `updated_at`, `total_marks`) VALUES
(1366, 11, 686, 6, 51, 28.00, 4, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1367, 11, 687, 6, 51, 25.00, 4, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1368, 11, 688, 6, 51, 10.00, 6, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1369, 11, 689, 6, 51, 47.00, 1, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1370, 11, 690, 6, 51, 8.00, 6, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1371, 11, 691, 6, 51, 25.00, 4, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1372, 11, 692, 6, 51, 32.00, 3, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1373, 11, 693, 6, 51, 14.00, 6, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1374, 11, 694, 6, 51, 29.00, 4, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1375, 11, 695, 6, 51, 41.00, 1, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1376, 11, 696, 6, 51, 20.00, 5, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1377, 11, 697, 6, 51, 35.00, 2, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1378, 11, 698, 6, 51, 22.00, 5, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1379, 11, 699, 6, 51, 21.00, 5, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1380, 11, 700, 6, 51, 20.00, 5, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1381, 11, 701, 6, 51, 20.00, 5, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1382, 11, 702, 6, 51, 43.00, 1, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1383, 11, 703, 6, 51, 20.00, 5, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1384, 11, 704, 6, 51, 11.00, 6, 0, 21, '2026-08-07 06:50:39', 21, '2026-08-07 06:50:39', 50.00),
(1385, 17, 627, 3, 55, 20.00, 5, 0, 21, '2026-08-07 06:54:07', 21, '2026-08-07 06:54:07', 50.00),
(1386, 17, 628, 3, 55, 14.00, 6, 0, 21, '2026-08-07 06:54:07', 21, '2026-08-07 06:54:07', 50.00),
(1387, 17, 629, 3, 55, 22.00, 5, 0, 21, '2026-08-07 06:54:07', 21, '2026-08-07 06:54:07', 50.00),
(1388, 17, 630, 3, 55, 28.00, 4, 0, 21, '2026-08-07 06:54:07', 21, '2026-08-07 06:54:07', 50.00),
(1389, 17, 631, 3, 55, 20.00, 5, 0, 21, '2026-08-07 06:54:07', 21, '2026-08-07 06:54:07', 50.00),
(1390, 17, 632, 3, 55, 20.00, 5, 0, 21, '2026-08-07 06:54:07', 21, '2026-08-07 06:54:07', 50.00),
(1391, 17, 633, 3, 55, 20.00, 5, 0, 21, '2026-08-07 06:54:07', 21, '2026-08-07 06:54:07', 50.00),
(1392, 17, 634, 3, 55, 23.00, 5, 0, 21, '2026-08-07 06:54:07', 21, '2026-08-07 06:54:07', 50.00),
(1393, 17, 635, 3, 55, 20.00, 5, 0, 21, '2026-08-07 06:54:07', 21, '2026-08-07 06:54:07', 50.00),
(1394, 17, 636, 3, 55, 20.00, 5, 0, 21, '2026-08-07 06:54:07', 21, '2026-08-07 06:54:07', 50.00),
(1395, 17, 637, 3, 55, 20.00, 5, 0, 21, '2026-08-07 06:54:07', 21, '2026-08-07 06:54:07', 50.00),
(1396, 17, 638, 3, 55, 25.00, 4, 0, 21, '2026-08-07 06:54:07', 21, '2026-08-07 06:54:07', 50.00),
(1397, 17, 639, 3, 55, 20.00, 5, 0, 21, '2026-08-07 06:54:07', 21, '2026-08-07 06:54:07', 50.00),
(1398, 17, 640, 3, 55, 42.00, 1, 0, 21, '2026-08-07 06:54:07', 21, '2026-08-07 06:54:07', 50.00),
(1399, 17, 641, 3, 55, 26.00, 4, 0, 21, '2026-08-07 06:54:07', 21, '2026-08-07 06:54:07', 50.00),
(1400, 17, 642, 3, 55, 22.00, 5, 0, 21, '2026-08-07 06:54:07', 21, '2026-08-07 06:54:07', 50.00),
(1401, 10, 656, 5, 52, 31.00, 3, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1402, 10, 657, 5, 52, 25.00, 4, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1403, 10, 658, 5, 52, 49.00, 1, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1404, 10, 659, 5, 52, 45.00, 1, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1405, 10, 660, 5, 52, 45.00, 1, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1406, 10, 661, 5, 52, 27.00, 4, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1407, 10, 662, 5, 52, 38.00, 2, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1408, 10, 663, 5, 52, 40.00, 1, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1409, 10, 664, 5, 52, 43.00, 1, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1410, 10, 665, 5, 52, 19.00, 6, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1411, 10, 666, 5, 52, 28.00, 4, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1412, 10, 667, 5, 52, 20.00, 5, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1413, 10, 668, 5, 52, 20.00, 5, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1414, 10, 669, 5, 52, 13.00, 6, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1415, 10, 670, 5, 52, 20.00, 5, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1416, 10, 671, 5, 52, 22.00, 5, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1417, 10, 672, 5, 52, 20.00, 5, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1418, 10, 673, 5, 52, 10.00, 6, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1419, 10, 674, 5, 52, 20.00, 5, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1420, 10, 675, 5, 52, 32.00, 3, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1421, 10, 676, 5, 52, 41.00, 1, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1422, 10, 677, 5, 52, 31.00, 3, 0, 21, '2026-08-07 06:58:53', 21, '2026-08-07 06:58:53', 50.00),
(1423, 10, 656, 5, 53, 27.00, 4, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1424, 10, 657, 5, 53, 24.00, 5, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1425, 10, 658, 5, 53, 43.00, 1, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1426, 10, 659, 5, 53, 38.00, 2, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1427, 10, 660, 5, 53, 40.00, 1, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1428, 10, 661, 5, 53, 20.00, 5, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1429, 10, 662, 5, 53, 36.00, 2, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1430, 10, 663, 5, 53, 27.00, 4, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1431, 10, 664, 5, 53, 34.00, 3, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1432, 10, 665, 5, 53, 23.00, 5, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1433, 10, 666, 5, 53, 25.00, 4, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1434, 10, 667, 5, 53, 12.00, 6, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1435, 10, 668, 5, 53, 21.00, 5, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1436, 10, 669, 5, 53, 11.00, 6, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1437, 10, 670, 5, 53, 20.00, 5, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1438, 10, 671, 5, 53, 9.00, 6, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1439, 10, 672, 5, 53, 20.00, 5, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1440, 10, 673, 5, 53, 20.00, 5, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1441, 10, 674, 5, 53, 20.00, 5, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1442, 10, 675, 5, 53, 28.00, 4, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1443, 10, 676, 5, 53, 37.00, 2, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1444, 10, 677, 5, 53, 20.00, 5, 0, 21, '2026-08-07 07:03:30', 21, '2026-08-07 07:03:30', 50.00),
(1445, 15, 755, 10, 32, 39.00, 4, 0, 6, '2026-08-07 13:57:06', 6, '2026-08-07 13:57:06', 75.00),
(1446, 15, 756, 10, 32, 31.00, 5, 0, 6, '2026-08-07 13:57:06', 6, '2026-08-07 13:57:06', 75.00),
(1447, 15, 757, 10, 32, 46.00, 3, 0, 6, '2026-08-07 13:57:06', 6, '2026-08-07 13:57:06', 75.00),
(1448, 15, 758, 10, 32, 38.00, 4, 0, 6, '2026-08-07 13:57:06', 6, '2026-08-07 13:57:06', 75.00),
(1449, 15, 759, 10, 32, 55.00, 2, 0, 6, '2026-08-07 13:57:06', 6, '2026-08-07 13:57:06', 75.00),
(1450, 15, 761, 10, 32, 56.00, 2, 0, 6, '2026-08-07 13:57:06', 6, '2026-08-07 13:57:06', 75.00),
(1451, 15, 762, 10, 32, 39.00, 4, 0, 6, '2026-08-07 13:57:06', 6, '2026-08-07 13:57:06', 75.00),
(1452, 15, 763, 10, 32, 41.00, 4, 0, 6, '2026-08-07 13:57:06', 6, '2026-08-07 13:57:06', 75.00),
(1453, 15, 764, 10, 32, 53.00, 2, 0, 6, '2026-08-07 13:57:06', 6, '2026-08-07 13:57:06', 75.00),
(1454, 15, 765, 10, 32, 33.00, 5, 0, 6, '2026-08-07 13:57:06', 6, '2026-08-07 13:57:06', 75.00),
(1455, 15, 766, 10, 32, 47.00, 3, 0, 6, '2026-08-07 13:57:06', 6, '2026-08-07 13:57:06', 75.00),
(1456, 15, 767, 10, 32, 42.00, 4, 0, 6, '2026-08-07 13:57:06', 6, '2026-08-07 13:57:06', 75.00),
(1457, 9, 644, 4, 31, 47.00, 1, 0, 6, '2026-08-07 14:04:47', 6, '2026-08-07 14:05:04', 50.00),
(1458, 9, 645, 4, 31, 32.00, 3, 0, 6, '2026-08-07 14:04:47', 6, '2026-08-07 14:05:04', 50.00),
(1459, 9, 646, 4, 31, 39.00, 2, 0, 6, '2026-08-07 14:04:47', 6, '2026-08-07 14:05:04', 50.00),
(1460, 9, 647, 4, 31, 34.00, 3, 0, 6, '2026-08-07 14:04:47', 6, '2026-08-07 14:05:04', 50.00),
(1461, 9, 648, 4, 31, 20.00, 5, 0, 6, '2026-08-07 14:04:47', 6, '2026-08-07 14:05:04', 50.00),
(1462, 9, 649, 4, 31, 21.00, 5, 0, 6, '2026-08-07 14:04:47', 6, '2026-08-07 14:05:04', 50.00),
(1463, 9, 650, 4, 31, 42.00, 1, 0, 6, '2026-08-07 14:04:47', 6, '2026-08-07 14:05:04', 50.00),
(1464, 9, 651, 4, 31, 14.00, 6, 0, 6, '2026-08-07 14:04:47', 6, '2026-08-07 14:05:04', 50.00),
(1465, 9, 652, 4, 31, 32.00, 3, 0, 6, '2026-08-07 14:04:47', 6, '2026-08-07 14:05:04', 50.00),
(1466, 9, 653, 4, 31, 20.00, 5, 0, 6, '2026-08-07 14:04:47', 6, '2026-08-07 14:05:04', 50.00),
(1467, 9, 654, 4, 31, 28.00, 4, 0, 6, '2026-08-07 14:04:47', 6, '2026-08-07 14:05:04', 50.00),
(1468, 9, 655, 4, 31, 34.00, 3, 0, 6, '2026-08-07 14:04:47', 6, '2026-08-07 14:05:04', 50.00),
(1632, 9, 644, 4, 65, 46.00, 1, 0, 235, '2026-08-10 00:07:15', 235, '2026-08-10 00:10:28', 50.00),
(1633, 9, 645, 4, 65, 20.00, 5, 0, 235, '2026-08-10 00:07:15', 235, '2026-08-10 00:10:28', 50.00),
(1634, 9, 646, 4, 65, 20.00, 5, 0, 235, '2026-08-10 00:07:15', 235, '2026-08-10 00:10:28', 50.00),
(1635, 9, 647, 4, 65, 9.00, 6, 0, 235, '2026-08-10 00:07:15', 235, '2026-08-10 00:10:28', 50.00),
(1636, 9, 648, 4, 65, 20.00, 5, 0, 235, '2026-08-10 00:07:15', 235, '2026-08-10 00:10:28', 50.00),
(1637, 9, 649, 4, 65, 20.00, 5, 0, 235, '2026-08-10 00:07:15', 235, '2026-08-10 00:10:28', 50.00),
(1638, 9, 650, 4, 65, 20.00, 5, 0, 235, '2026-08-10 00:07:15', 235, '2026-08-10 00:10:29', 50.00),
(1639, 9, 651, 4, 65, 20.00, 5, 0, 235, '2026-08-10 00:07:15', 235, '2026-08-10 00:10:29', 50.00),
(1640, 9, 652, 4, 65, 20.00, 5, 0, 235, '2026-08-10 00:07:15', 235, '2026-08-10 00:10:29', 50.00),
(1641, 9, 653, 4, 65, 17.00, 6, 0, 235, '2026-08-10 00:07:15', 235, '2026-08-10 00:10:29', 50.00),
(1642, 9, 654, 4, 65, 29.00, 4, 0, 235, '2026-08-10 00:07:15', 235, '2026-08-10 00:10:29', 50.00),
(1643, 9, 655, 4, 65, 27.00, 4, 0, 235, '2026-08-10 00:07:15', 235, '2026-08-10 00:10:29', 50.00),
(1668, 17, 627, 3, 67, 20.00, 5, 0, 235, '2026-08-10 00:19:21', 235, '2026-08-10 00:19:21', 50.00),
(1669, 17, 628, 3, 67, 20.00, 5, 0, 235, '2026-08-10 00:19:21', 235, '2026-08-10 00:19:21', 50.00),
(1670, 17, 629, 3, 67, 20.00, 5, 0, 235, '2026-08-10 00:19:21', 235, '2026-08-10 00:19:21', 50.00),
(1671, 17, 630, 3, 67, 29.00, 4, 0, 235, '2026-08-10 00:19:21', 235, '2026-08-10 00:19:21', 50.00),
(1672, 17, 631, 3, 67, 20.00, 5, 0, 235, '2026-08-10 00:19:21', 235, '2026-08-10 00:19:21', 50.00),
(1673, 17, 632, 3, 67, 20.00, 5, 0, 235, '2026-08-10 00:19:21', 235, '2026-08-10 00:19:21', 50.00),
(1674, 17, 633, 3, 67, 25.00, 4, 0, 235, '2026-08-10 00:19:21', 235, '2026-08-10 00:19:21', 50.00),
(1675, 17, 634, 3, 67, 25.00, 4, 0, 235, '2026-08-10 00:19:21', 235, '2026-08-10 00:19:21', 50.00),
(1676, 17, 635, 3, 67, 22.00, 5, 0, 235, '2026-08-10 00:19:21', 235, '2026-08-10 00:19:21', 50.00),
(1677, 17, 636, 3, 67, 31.00, 3, 0, 235, '2026-08-10 00:19:21', 235, '2026-08-10 00:19:21', 50.00),
(1678, 17, 637, 3, 67, 32.00, 3, 0, 235, '2026-08-10 00:19:21', 235, '2026-08-10 00:19:21', 50.00),
(1679, 17, 638, 3, 67, 34.00, 3, 0, 235, '2026-08-10 00:19:21', 235, '2026-08-10 00:19:21', 50.00),
(1680, 17, 639, 3, 67, 27.00, 4, 0, 235, '2026-08-10 00:19:21', 235, '2026-08-10 00:19:21', 50.00),
(1681, 17, 640, 3, 67, 36.00, 2, 0, 235, '2026-08-10 00:19:21', 235, '2026-08-10 00:19:21', 50.00),
(1682, 17, 641, 3, 67, 31.00, 3, 0, 235, '2026-08-10 00:19:21', 235, '2026-08-10 00:19:21', 50.00),
(1683, 17, 642, 3, 67, 20.00, 5, 0, 235, '2026-08-10 00:19:21', 235, '2026-08-10 00:19:21', 50.00),
(1684, 22, 611, 2, 69, 37.00, 6, 0, 235, '2026-08-10 00:24:05', 235, '2026-08-10 00:24:05', 100.00),
(1685, 22, 612, 2, 69, 41.00, 5, 0, 235, '2026-08-10 00:24:05', 235, '2026-08-10 00:24:05', 100.00),
(1686, 22, 613, 2, 69, 42.00, 5, 0, 235, '2026-08-10 00:24:05', 235, '2026-08-10 00:24:05', 100.00),
(1687, 22, 614, 2, 69, 50.00, 4, 0, 235, '2026-08-10 00:24:05', 235, '2026-08-10 00:24:05', 100.00),
(1688, 22, 615, 2, 69, 48.00, 5, 0, 235, '2026-08-10 00:24:05', 235, '2026-08-10 00:24:05', 100.00),
(1689, 22, 616, 2, 69, 35.00, 6, 0, 235, '2026-08-10 00:24:05', 235, '2026-08-10 00:24:05', 100.00),
(1690, 22, 617, 2, 69, 32.00, 6, 0, 235, '2026-08-10 00:24:05', 235, '2026-08-10 00:24:05', 100.00),
(1691, 22, 618, 2, 69, 40.00, 5, 0, 235, '2026-08-10 00:24:05', 235, '2026-08-10 00:24:05', 100.00),
(1692, 22, 619, 2, 69, 42.00, 5, 0, 235, '2026-08-10 00:24:05', 235, '2026-08-10 00:24:05', 100.00),
(1693, 22, 620, 2, 69, 32.00, 6, 0, 235, '2026-08-10 00:24:05', 235, '2026-08-10 00:24:05', 100.00),
(1694, 22, 621, 2, 69, 31.00, 6, 0, 235, '2026-08-10 00:24:05', 235, '2026-08-10 00:24:05', 100.00),
(1695, 22, 622, 2, 69, 49.00, 5, 0, 235, '2026-08-10 00:24:05', 235, '2026-08-10 00:24:05', 100.00),
(1696, 22, 623, 2, 69, 35.00, 6, 0, 235, '2026-08-10 00:24:05', 235, '2026-08-10 00:24:05', 100.00),
(1697, 22, 643, 2, 69, 50.00, 4, 0, 235, '2026-08-10 00:24:05', 235, '2026-08-10 00:24:05', 100.00),
(1698, 22, 625, 2, 69, 40.00, 5, 0, 235, '2026-08-10 00:24:05', 235, '2026-08-10 00:24:05', 100.00),
(1699, 22, 626, 2, 69, 34.00, 6, 0, 235, '2026-08-10 00:24:05', 235, '2026-08-10 00:24:05', 100.00),
(1700, 13, 718, 8, 70, 54.00, 2, 0, 235, '2026-08-10 00:29:03', 235, '2026-08-10 00:29:03', 75.00),
(1701, 13, 719, 8, 70, 55.00, 2, 0, 235, '2026-08-10 00:29:03', 235, '2026-08-10 00:29:03', 75.00),
(1702, 13, 720, 8, 70, 53.00, 2, 0, 235, '2026-08-10 00:29:03', 235, '2026-08-10 00:29:03', 75.00),
(1703, 13, 721, 8, 70, 58.00, 2, 0, 235, '2026-08-10 00:29:03', 235, '2026-08-10 00:29:03', 75.00),
(1704, 13, 722, 8, 70, 50.00, 3, 0, 235, '2026-08-10 00:29:03', 235, '2026-08-10 00:29:03', 75.00),
(1705, 13, 723, 8, 70, 38.00, 4, 0, 235, '2026-08-10 00:29:03', 235, '2026-08-10 00:29:03', 75.00),
(1706, 13, 724, 8, 70, 52.00, 3, 0, 235, '2026-08-10 00:29:03', 235, '2026-08-10 00:29:03', 75.00),
(1707, 13, 725, 8, 70, 55.00, 2, 0, 235, '2026-08-10 00:29:03', 235, '2026-08-10 00:29:03', 75.00),
(1708, 13, 726, 8, 70, 33.00, 5, 0, 235, '2026-08-10 00:29:03', 235, '2026-08-10 00:29:03', 75.00),
(1709, 13, 727, 8, 70, 58.00, 2, 0, 235, '2026-08-10 00:29:03', 235, '2026-08-10 00:29:03', 75.00),
(1710, 13, 728, 8, 70, 30.00, 5, 0, 235, '2026-08-10 00:29:03', 235, '2026-08-10 00:29:03', 75.00),
(1711, 13, 729, 8, 70, 46.00, 3, 0, 235, '2026-08-10 00:29:03', 235, '2026-08-10 00:29:03', 75.00),
(1712, 13, 730, 8, 70, 50.00, 3, 0, 235, '2026-08-10 00:29:03', 235, '2026-08-10 00:29:03', 75.00),
(1713, 13, 731, 8, 70, 55.00, 2, 0, 235, '2026-08-10 00:29:03', 235, '2026-08-10 00:29:03', 75.00),
(1714, 11, 678, 6, 68, 31.00, 3, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1715, 11, 679, 6, 68, 47.00, 1, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1716, 11, 680, 6, 68, 23.00, 5, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1717, 11, 681, 6, 68, 20.00, 5, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1718, 11, 682, 6, 68, 21.00, 5, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1719, 11, 683, 6, 68, 46.00, 1, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1720, 11, 684, 6, 68, 30.00, 3, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1721, 11, 685, 6, 68, 32.00, 3, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1722, 11, 686, 6, 68, 20.00, 5, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1723, 11, 687, 6, 68, 20.00, 5, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1724, 11, 688, 6, 68, 17.00, 6, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1725, 11, 689, 6, 68, 46.00, 1, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1726, 11, 690, 6, 68, 17.00, 6, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1727, 11, 691, 6, 68, 26.00, 4, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1728, 11, 692, 6, 68, 20.00, 5, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1729, 11, 693, 6, 68, 17.00, 6, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1730, 11, 694, 6, 68, 26.00, 4, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1731, 11, 695, 6, 68, 36.00, 2, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1732, 11, 696, 6, 68, 17.00, 6, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1733, 11, 697, 6, 68, 29.00, 4, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1734, 11, 698, 6, 68, 20.00, 5, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1735, 11, 699, 6, 68, 20.00, 5, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1736, 11, 700, 6, 68, 30.00, 3, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1737, 11, 701, 6, 68, 20.00, 5, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1738, 11, 702, 6, 68, 46.00, 1, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1739, 11, 703, 6, 68, 20.00, 5, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1740, 11, 704, 6, 68, 17.00, 6, 0, 235, '2026-08-10 00:34:06', 235, '2026-08-10 00:34:06', 50.00),
(1741, 10, 656, 5, 72, 25.00, 4, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1742, 10, 657, 5, 72, 20.00, 5, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1743, 10, 658, 5, 72, 45.00, 1, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1744, 10, 659, 5, 72, 24.00, 5, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1745, 10, 660, 5, 72, 30.00, 3, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1746, 10, 661, 5, 72, 20.00, 5, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1747, 10, 662, 5, 72, 21.00, 5, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1748, 10, 663, 5, 72, 30.00, 3, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1749, 10, 664, 5, 72, 41.00, 1, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1750, 10, 665, 5, 72, 25.00, 4, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1751, 10, 666, 5, 72, 20.00, 5, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1752, 10, 667, 5, 72, 17.00, 6, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1753, 10, 668, 5, 72, 12.00, 6, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1754, 10, 669, 5, 72, 17.00, 6, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1755, 10, 670, 5, 72, 17.00, 6, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1756, 10, 671, 5, 72, 17.00, 6, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1757, 10, 672, 5, 72, 17.00, 6, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1758, 10, 673, 5, 72, 17.00, 6, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1759, 10, 674, 5, 72, 17.00, 6, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1760, 10, 675, 5, 72, 25.00, 4, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1761, 10, 676, 5, 72, 41.00, 1, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1762, 10, 677, 5, 72, 17.00, 6, 0, 235, '2026-08-10 00:43:01', 235, '2026-08-10 00:43:01', 50.00),
(1763, 26, 768, 13, 76, 36.00, 3, 0, 240, '2026-08-11 08:27:53', 240, '2026-08-11 08:27:53', 60.00),
(1764, 26, 769, 13, 76, 42.00, 2, 0, 240, '2026-08-11 08:27:53', 240, '2026-08-11 08:27:53', 60.00),
(1765, 26, 770, 13, 76, 45.00, 2, 0, 240, '2026-08-11 08:27:53', 240, '2026-08-11 08:27:53', 60.00),
(1766, 26, 771, 13, 76, 40.00, 3, 0, 240, '2026-08-11 08:27:53', 240, '2026-08-11 08:27:53', 60.00),
(1767, 26, 772, 13, 76, 41.00, 3, 0, 240, '2026-08-11 08:27:53', 240, '2026-08-11 08:27:53', 60.00),
(1768, 26, 773, 13, 76, 33.00, 4, 0, 240, '2026-08-11 08:27:53', 240, '2026-08-11 08:27:53', 60.00),
(1769, 26, 774, 13, 76, 40.00, 3, 0, 240, '2026-08-11 08:27:53', 240, '2026-08-11 08:27:53', 60.00),
(1770, 26, 775, 13, 76, 35.00, 4, 0, 240, '2026-08-11 08:27:53', 240, '2026-08-11 08:27:53', 60.00),
(1771, 26, 776, 13, 76, 39.00, 3, 0, 240, '2026-08-11 08:27:53', 240, '2026-08-11 08:27:53', 60.00),
(1772, 26, 777, 13, 76, 39.00, 3, 0, 240, '2026-08-11 08:27:53', 240, '2026-08-11 08:27:53', 60.00),
(1773, 26, 778, 13, 76, 40.00, 3, 0, 240, '2026-08-11 08:27:53', 240, '2026-08-11 08:27:53', 60.00),
(1774, 26, 779, 13, 76, 38.00, 3, 0, 240, '2026-08-11 08:27:53', 240, '2026-08-11 08:27:53', 60.00);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(60) NOT NULL,
  `title` varchar(150) NOT NULL,
  `message` varchar(500) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `type`, `title`, `message`, `link`, `is_read`, `created_at`) VALUES
(1, 4, 'leave_request', 'New student leave request', 'nusrat requested Sick leave from 2026-08-07 to 2026-08-07.', 'https://school.akhoonzadaholdings.com/public/index.php?route=students%2Fleaves', 1, '2026-08-06 10:07:54'),
(2, 20, 'leave_request', 'New student leave request', 'nusrat requested Sick leave from 2026-08-07 to 2026-08-07.', 'https://school.akhoonzadaholdings.com/public/index.php?route=students%2Fleaves', 1, '2026-08-06 10:07:54'),
(3, 261, 'leave_request', 'New student leave request', 'nusrat requested Sick leave from 2026-08-07 to 2026-08-07.', 'https://school.akhoonzadaholdings.com/public/index.php?route=students%2Fleaves', 0, '2026-08-06 10:07:54'),
(4, 262, 'leave_request', 'New student leave request', 'nusrat requested Sick leave from 2026-08-07 to 2026-08-07.', 'https://school.akhoonzadaholdings.com/public/index.php?route=students%2Fleaves', 0, '2026-08-06 10:07:54'),
(5, 6, 'leave_request', 'New student leave request', 'nusrat requested Sick leave from 2026-08-07 to 2026-08-07.', 'https://school.akhoonzadaholdings.com/public/index.php?route=students%2Fleaves', 1, '2026-08-06 10:07:54'),
(6, 7, 'leave_request', 'New student leave request', 'nusrat requested Sick leave from 2026-08-07 to 2026-08-07.', 'https://school.akhoonzadaholdings.com/public/index.php?route=students%2Fleaves', 1, '2026-08-06 10:07:54'),
(7, 21, 'leave_request', 'New student leave request', 'nusrat requested Sick leave from 2026-08-07 to 2026-08-07.', 'https://school.akhoonzadaholdings.com/public/index.php?route=students%2Fleaves', 0, '2026-08-06 10:07:54'),
(8, 234, 'leave_request', 'New student leave request', 'nusrat requested Sick leave from 2026-08-07 to 2026-08-07.', 'https://school.akhoonzadaholdings.com/public/index.php?route=students%2Fleaves', 0, '2026-08-06 10:07:54'),
(9, 235, 'leave_request', 'New student leave request', 'nusrat requested Sick leave from 2026-08-07 to 2026-08-07.', 'https://school.akhoonzadaholdings.com/public/index.php?route=students%2Fleaves', 0, '2026-08-06 10:07:54'),
(10, 236, 'leave_request', 'New student leave request', 'nusrat requested Sick leave from 2026-08-07 to 2026-08-07.', 'https://school.akhoonzadaholdings.com/public/index.php?route=students%2Fleaves', 0, '2026-08-06 10:07:54'),
(11, 238, 'leave_request', 'New student leave request', 'nusrat requested Sick leave from 2026-08-07 to 2026-08-07.', 'https://school.akhoonzadaholdings.com/public/index.php?route=students%2Fleaves', 1, '2026-08-06 10:07:54'),
(12, 239, 'leave_request', 'New student leave request', 'nusrat requested Sick leave from 2026-08-07 to 2026-08-07.', 'https://school.akhoonzadaholdings.com/public/index.php?route=students%2Fleaves', 0, '2026-08-06 10:07:54'),
(13, 240, 'leave_request', 'New student leave request', 'nusrat requested Sick leave from 2026-08-07 to 2026-08-07.', 'https://school.akhoonzadaholdings.com/public/index.php?route=students%2Fleaves', 1, '2026-08-06 10:07:54'),
(14, 233, 'leave_request', 'New student leave request', 'nusrat requested Sick leave from 2026-08-07 to 2026-08-07.', 'https://school.akhoonzadaholdings.com/public/index.php?route=students%2Fleaves', 0, '2026-08-06 10:07:54'),
(15, 4, 'fee_handover', 'Fee handover awaiting confirmation', 'Hassan says they handed you Rs 440.00 in collected fees.', 'https://school.akhoonzadaholdings.com/public/index.php?route=fees%2FteacherLedger', 1, '2026-08-11 12:03:37'),
(16, 6, 'fee_handover', 'Fee handover rejected', 'Your handover of Rs 440.00 was rejected. Reason: Test', 'https://school.akhoonzadaholdings.com/public/index.php?route=portal%2FmyFeeLedger', 1, '2026-08-11 12:05:26'),
(17, 4, 'fee_handover', 'Fee handover awaiting confirmation', 'Hassan says they handed you Rs 440.00 in collected fees.', 'https://school.akhoonzadaholdings.com/public/index.php?route=fees%2FteacherLedger', 0, '2026-08-11 12:06:06'),
(18, 6, 'fee_handover', 'Fee handover confirmed', 'Your handover of Rs 440.00 was confirmed received.', 'https://school.akhoonzadaholdings.com/public/index.php?route=portal%2FmyFeeLedger', 1, '2026-08-11 12:06:29');

-- --------------------------------------------------------

--
-- Table structure for table `online_courses`
--

CREATE TABLE `online_courses` (
  `id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `resource_url` varchar(255) DEFAULT NULL,
  `created_by_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token_hash` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `user_id`, `token_hash`, `expires_at`, `used_at`, `created_at`) VALUES
(7, 261, 'e92de66534f0dba4987874a8e73815df0a0a980108872091d997201d06171e80', '2026-07-26 15:50:37', '2026-07-26 10:21:07', '2026-07-26 10:20:37'),
(9, 261, '324e9bb2e9ce56ac9dbf5a3074bffee114bf9d1adb764a8bb297f83d017c985c', '2026-07-30 12:13:04', NULL, '2026-07-30 06:43:04'),
(10, 234, '7949a8b76a7e440fd2ab3926c766c3c6f506ba7e17ca24495cb66bed2f9d8829', '2026-08-11 10:49:59', '2026-08-11 05:22:22', '2026-08-11 05:19:59');

-- --------------------------------------------------------

--
-- Stand-in structure for view `pending_dues_view`
-- (See below for the actual view)
--
CREATE TABLE `pending_dues_view` (
`fee_invoice_id` int(11)
,`student_id` int(11)
,`academic_year_id` int(11)
,`pending_amount` decimal(33,2)
);

-- --------------------------------------------------------

--
-- Table structure for table `performance_reports`
--

CREATE TABLE `performance_reports` (
  `id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `period_start` date DEFAULT NULL,
  `period_end` date DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `summary` text DEFAULT NULL,
  `created_by_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `performance_reports`
--

INSERT INTO `performance_reports` (`id`, `staff_profile_id`, `period_start`, `period_end`, `rating`, `summary`, `created_by_user_id`, `created_at`) VALUES
(2, 7, '2026-06-01', '2026-06-30', 4, 'time and focus', 4, '2026-07-17 17:28:17'),
(3, 11, '2026-06-01', '2026-06-30', 4, 'Time and focus', 4, '2026-07-18 16:59:25');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL,
  `permission_key` varchar(100) NOT NULL,
  `permission_name` varchar(150) NOT NULL,
  `permission_description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `permission_key`, `permission_name`, `permission_description`) VALUES
(1, 'dashboard.view', 'Dashboard view', 'View dashboard'),
(2, 'students.view', 'Students view', 'View students'),
(3, 'students.manage', 'Students manage', 'Create/edit/delete students'),
(4, 'academic.view', 'Academic view', 'View academic module'),
(5, 'academic.manage', 'Academic manage', 'Manage subjects/exams'),
(6, 'fees.view', 'Fees view', 'View fees'),
(7, 'fees.manage', 'Fees manage', 'Collect/assign/manage fees'),
(8, 'staff.view', 'Staff view', 'View staff and HR'),
(9, 'staff.manage', 'Staff manage', 'Manage staff/attendance/leaves/payroll'),
(10, 'users.view', 'Users view', 'View users and roles'),
(11, 'users.manage', 'Users manage', 'Manage users and role capabilities'),
(12, 'reports.view', 'Reports view', 'View reports'),
(13, 'reports.export', 'Reports export', 'Export reports (CSV/print)'),
(14, 'settings.view', 'Settings view', 'View settings'),
(15, 'settings.manage', 'Settings manage', 'Backup/restore and clean data'),
(17, 'attendance.view', '', NULL),
(18, 'attendance.manage', '', NULL),
(19, 'portal.access', 'Portal access', 'Access the self-service portal (own data only)'),
(53, 'expenses.view', 'Expenses view', 'View other school expenses'),
(54, 'expenses.manage', 'Expenses manage', 'Record and manage other school expenses'),
(55, 'class_teachers.manage', 'Assign class teachers', NULL),
(56, 'fee_collection_assignments.manage', 'Assign fee-collection classes to staff', NULL),
(60, 'activity_log.view', 'Activity log view', 'View the staff activity log'),
(78, 'academic.bulk_export', 'Academic bulk export', 'Bulk-export report cards / results (ZIP, XLS, CSV) across the school'),
(79, 'students.leave_approve', 'Student leave approve (short, own class)', 'Approve/reject a student leave request of 2 days or fewer, for their own class only'),
(82, 'fees.handover_submit', 'Fee handover submit', 'Submit a record of cash handed over to Admin/Principal, and view own collection/handover ledger'),
(83, 'fees.handover_confirm', 'Fee handover confirm', 'Confirm or reject a submitted fee handover, and view every teacher\'s collection ledger');

-- --------------------------------------------------------

--
-- Table structure for table `resource_progress`
--

CREATE TABLE `resource_progress` (
  `id` int(11) NOT NULL,
  `course_resource_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `progress_percent` decimal(5,2) NOT NULL DEFAULT 0.00,
  `last_position_seconds` int(11) NOT NULL DEFAULT 0,
  `completed_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `description`) VALUES
(1, 'Admin', 'System administrator'),
(2, 'Teacher', 'Teacher role'),
(3, 'Student', 'Student role'),
(4, 'Parent', 'Parent/guardian role'),
(5, 'Accountant', 'Accounting & finance role'),
(7, 'Examiner', NULL),
(18, 'Principal', 'Principal AKPS'),
(24, 'Office Boy', 'Sweeper');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE `role_permissions` (
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(1, 1),
(1, 2),
(18, 2),
(1, 3),
(18, 3),
(1, 4),
(2, 4),
(18, 4),
(1, 5),
(2, 5),
(18, 5),
(1, 6),
(5, 6),
(1, 7),
(5, 7),
(1, 8),
(18, 8),
(1, 9),
(18, 9),
(1, 10),
(1, 11),
(1, 12),
(1, 13),
(1, 14),
(1, 15),
(1, 17),
(2, 17),
(18, 17),
(1, 18),
(2, 18),
(18, 18),
(1, 19),
(2, 19),
(3, 19),
(4, 19),
(5, 19),
(18, 19),
(1, 53),
(5, 53),
(1, 54),
(5, 54),
(1, 55),
(18, 55),
(1, 56),
(1, 60),
(1, 78),
(1, 79),
(2, 79),
(1, 82),
(2, 82),
(18, 82),
(1, 83),
(18, 83);

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`id`, `name`) VALUES
(1, 'A'),
(3, 'Arts'),
(2, 'B'),
(4, 'Science');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `key` varchar(120) NOT NULL,
  `value` longtext NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`key`, `value`, `updated_at`) VALUES
('academic_year_active', '2026', '2026-03-29 18:21:49'),
('app_timezone', 'PKT', '2026-03-29 18:21:49'),
('branding_favicon_path', '/uploads/branding/favicon_20260806171522_5688a519.png', '2026-08-06 12:15:22'),
('branding_logo_path', '/uploads/branding/logo_20260806171522_940e21ee.png', '2026-08-06 12:15:22'),
('branding_school_name', 'Akhoon Zada Public School And College Bilamik', '2026-08-06 12:15:22'),
('currency', 'PKR', '2026-03-29 18:21:49'),
('date_format', 'Y-m-d', '2026-03-29 18:21:49'),
('holidays', '', '2026-03-29 18:21:49'),
('institute_address', 'Bilamik', '2026-03-29 23:24:28'),
('institute_contact', '03145525749', '2026-03-29 23:24:28'),
('institute_name', 'Akhoonzada Public School and College Bilamik', '2026-03-29 23:24:28'),
('institute_policies', '', '2026-03-29 23:24:28'),
('mail_from_email', 'admin@akhoonzadaholdings.com', '2026-07-30 06:42:52'),
('mail_from_name', 'Akhoonzada Public School and College Bilamik', '2026-07-30 06:42:52'),
('sms_api_endpoint', '', '2026-07-30 06:42:52'),
('sms_api_key', '', '2026-07-30 06:42:52'),
('sms_api_secret', '', '2026-07-30 06:42:52'),
('sms_enabled', '0', '2026-07-30 06:42:52'),
('sms_provider', 'Zong', '2026-07-30 06:42:52'),
('sms_sender_id', '', '2026-07-30 06:42:52'),
('smtp_auth', '1', '2026-07-30 06:42:52'),
('smtp_enabled', '1', '2026-07-30 06:42:52'),
('smtp_encryption', 'ssl', '2026-07-30 06:42:52'),
('smtp_host', 'smtp.hostinger.com', '2026-07-30 06:42:52'),
('smtp_password', 'Bilamik@2018', '2026-07-30 06:41:12'),
('smtp_port', '465', '2026-07-30 06:42:52'),
('smtp_username', 'admin@akhoonzadaholdings.com', '2026-07-30 06:42:52'),
('smtp_verify_cert', '1', '2026-07-30 06:42:52');

-- --------------------------------------------------------

--
-- Table structure for table `staff_attendance_records`
--

CREATE TABLE `staff_attendance_records` (
  `id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `attendance_date` date NOT NULL,
  `status` enum('present','absent','late','excused') NOT NULL DEFAULT 'present',
  `created_by_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff_attendance_records`
--

INSERT INTO `staff_attendance_records` (`id`, `staff_profile_id`, `attendance_date`, `status`, `created_by_user_id`, `created_at`) VALUES
(15, 9, '2026-07-17', 'present', 4, '2026-07-17 16:48:36'),
(16, 11, '2026-07-17', 'present', 4, '2026-07-17 16:48:36'),
(17, 8, '2026-07-17', 'present', 4, '2026-07-17 16:48:36'),
(18, 7, '2026-07-17', 'present', 4, '2026-07-17 16:48:36'),
(19, 10, '2026-07-17', 'present', 4, '2026-07-17 16:48:36'),
(20, 13, '2026-07-17', 'present', 4, '2026-07-17 16:48:36'),
(21, 12, '2026-07-17', 'present', 4, '2026-07-17 16:48:36'),
(22, 9, '2026-07-18', 'present', 4, '2026-07-18 16:57:50'),
(23, 11, '2026-07-18', 'absent', 4, '2026-07-18 16:57:50'),
(24, 8, '2026-07-18', 'present', 4, '2026-07-18 16:57:50'),
(25, 7, '2026-07-18', 'present', 4, '2026-07-18 16:57:50'),
(26, 10, '2026-07-18', 'present', 4, '2026-07-18 16:57:50'),
(27, 13, '2026-07-18', 'present', 4, '2026-07-18 16:57:50'),
(28, 12, '2026-07-18', 'present', 4, '2026-07-18 16:57:50'),
(36, 9, '2026-07-15', 'present', 4, '2026-07-18 16:58:13'),
(37, 11, '2026-07-15', 'late', 4, '2026-07-18 16:58:13'),
(38, 8, '2026-07-15', 'present', 4, '2026-07-18 16:58:13'),
(39, 7, '2026-07-15', 'late', 4, '2026-07-18 16:58:13'),
(40, 10, '2026-07-15', 'present', 4, '2026-07-18 16:58:13'),
(41, 13, '2026-07-15', 'present', 4, '2026-07-18 16:58:13'),
(42, 12, '2026-07-15', 'present', 4, '2026-07-18 16:58:13'),
(43, 9, '2026-08-11', 'excused', 20, '2026-08-11 03:57:47'),
(44, 20, '2026-08-11', 'present', 20, '2026-08-11 03:57:47'),
(45, 11, '2026-08-11', 'present', 20, '2026-08-11 03:57:47'),
(46, 8, '2026-08-11', 'present', 20, '2026-08-11 03:57:47'),
(47, 16, '2026-08-11', 'present', 20, '2026-08-11 03:57:47'),
(48, 17, '2026-08-11', 'present', 20, '2026-08-11 03:57:47'),
(49, 7, '2026-08-11', 'present', 20, '2026-08-11 03:57:47'),
(50, 18, '2026-08-11', 'present', 20, '2026-08-11 03:57:47'),
(51, 10, '2026-08-11', 'present', 20, '2026-08-11 03:57:47'),
(52, 13, '2026-08-11', 'excused', 20, '2026-08-11 03:57:47'),
(53, 12, '2026-08-11', 'present', 20, '2026-08-11 03:57:47'),
(54, 19, '2026-08-11', 'present', 20, '2026-08-11 03:57:47');

-- --------------------------------------------------------

--
-- Table structure for table `staff_fee_classes`
--

CREATE TABLE `staff_fee_classes` (
  `id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `class_section_id` int(11) NOT NULL,
  `assigned_by_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Dumping data for table `staff_fee_classes`
--

INSERT INTO `staff_fee_classes` (`id`, `staff_profile_id`, `class_section_id`, `assigned_by_user_id`, `created_at`) VALUES
(6, 10, 3, 4, '2026-07-23 09:24:58'),
(7, 10, 10, 4, '2026-07-23 09:25:07'),
(8, 13, 2, 4, '2026-07-23 09:25:27'),
(9, 11, 7, 4, '2026-07-23 09:26:24'),
(10, 11, 9, 4, '2026-07-23 09:26:27'),
(11, 7, 1, 4, '2026-07-23 09:26:48'),
(12, 8, 5, 4, '2026-07-23 09:27:09'),
(13, 8, 8, 4, '2026-07-23 09:27:14'),
(14, 12, 4, 4, '2026-07-23 09:27:30'),
(15, 12, 6, 4, '2026-07-23 09:28:02');

-- --------------------------------------------------------

--
-- Table structure for table `staff_profiles`
--

CREATE TABLE `staff_profiles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `staff_code` varchar(40) DEFAULT NULL,
  `full_name` varchar(140) NOT NULL,
  `title` varchar(80) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `base_salary` decimal(12,2) DEFAULT NULL,
  `basic_salary` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff_profiles`
--

INSERT INTO `staff_profiles` (`id`, `user_id`, `staff_code`, `full_name`, `title`, `phone`, `address`, `base_salary`, `basic_salary`, `created_at`) VALUES
(7, 6, NULL, 'Muhammad Hassan', 'Vice principal', '03555417105', 'Dangjing Bilamik', NULL, 0.00, '2026-05-23 04:01:28'),
(8, 21, NULL, 'Ghulam Abbas', 'General teacher', '03554184895', 'Bilamik center', NULL, 0.00, '2026-05-23 04:02:56'),
(9, 233, NULL, 'Abdullah Khan', 'Principal', '03555100828', 'Changpapa Bilamik', NULL, 0.00, '2026-05-23 04:04:35'),
(10, 234, NULL, 'Sabir Hussain', 'General teacher', '03555037836', 'Skurbochan Bansa', NULL, 0.00, '2026-05-23 04:05:36'),
(11, 7, NULL, 'Fida Hussain', 'General teacher', '03554186078', 'Samarfo Bilamik', NULL, 0.00, '2026-05-23 04:06:45'),
(12, 235, NULL, 'Tanveer', 'ECD teacher', '355 5908537', 'Changpapa', NULL, 0.00, '2026-07-17 07:16:26'),
(13, 236, NULL, 'Sajid Ali', 'Biology teacher', '923554316614', 'Bilamik center', NULL, 0.00, '2026-07-17 07:18:31'),
(16, 237, NULL, 'Kazim', 'Staff Boy', NULL, 'Skilo', NULL, 0.00, '2026-07-21 17:28:36'),
(17, 238, NULL, 'Mehboob Ali Meer', 'Teacher', '+923554206037', 'Smarfo', NULL, 0.00, '2026-07-21 17:52:08'),
(18, 239, NULL, 'Qasim Naseem', 'Teacher', '+92 355 5893937', 'Bensa', NULL, 0.00, '2026-07-21 17:52:41'),
(19, 240, NULL, 'WAZIR NASRULLAH', 'Teacher', '+92 355 5713214', 'Smarfo', NULL, 0.00, '2026-07-21 17:53:10'),
(20, 261, NULL, 'Admin', 'Admin', '03145525749', 'Bensa Bilamik', NULL, 0.00, '2026-07-25 07:14:55');

-- --------------------------------------------------------

--
-- Table structure for table `staff_roles`
--

CREATE TABLE `staff_roles` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `staff_role_assignments`
--

CREATE TABLE `staff_role_assignments` (
  `id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `staff_role_id` int(11) NOT NULL,
  `assigned_at` datetime NOT NULL DEFAULT current_timestamp(),
  `assigned_by_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `staff_salary_details`
--

CREATE TABLE `staff_salary_details` (
  `id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `salary_month` int(11) NOT NULL,
  `salary_year` int(11) NOT NULL,
  `gross_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `deductions` decimal(10,2) NOT NULL DEFAULT 0.00,
  `net_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by_user_id` int(11) DEFAULT NULL,
  `salary_created_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff_salary_details`
--

INSERT INTO `staff_salary_details` (`id`, `staff_profile_id`, `salary_month`, `salary_year`, `gross_amount`, `deductions`, `net_amount`, `created_at`, `created_by_user_id`, `salary_created_date`) VALUES
(18, 9, 4, 2026, 24000.00, 0.00, 24000.00, '2026-07-21 13:41:18', 4, '2026-04-01'),
(19, 11, 4, 2026, 12000.00, 0.00, 12000.00, '2026-07-21 13:42:00', 4, '2026-04-01'),
(20, 8, 4, 2026, 16000.00, 0.00, 16000.00, '2026-07-21 13:42:39', 4, '2026-04-01'),
(21, 7, 4, 2026, 19500.00, 0.00, 19500.00, '2026-07-21 13:44:04', 4, '2026-04-01'),
(22, 10, 4, 2026, 18000.00, 0.00, 18000.00, '2026-07-21 13:44:39', 4, '2026-04-01'),
(23, 13, 4, 2026, 14000.00, 0.00, 14000.00, '2026-07-21 13:45:04', 4, '2026-04-01'),
(32, 9, 5, 2026, 24000.00, 0.00, 24000.00, '2026-07-21 14:02:06', 4, '2026-05-01'),
(33, 11, 5, 2026, 12000.00, 0.00, 12000.00, '2026-07-21 14:02:25', 4, '2026-05-01'),
(34, 8, 5, 2026, 16000.00, 0.00, 16000.00, '2026-07-21 14:02:39', 4, '2026-05-01'),
(35, 7, 5, 2026, 19500.00, 0.00, 19500.00, '2026-07-21 14:02:54', 4, '2026-05-01'),
(36, 10, 5, 2026, 24000.00, 0.00, 24000.00, '2026-07-21 14:03:07', 4, '2026-05-01'),
(37, 13, 5, 2026, 17000.00, 0.00, 17000.00, '2026-07-21 14:03:20', 4, '2026-05-01'),
(39, 9, 6, 2026, 24000.00, 0.00, 24000.00, '2026-07-21 14:04:27', 4, '2026-06-01'),
(40, 11, 6, 2026, 12000.00, 0.00, 12000.00, '2026-07-21 14:04:40', 4, '2026-06-01'),
(41, 8, 6, 2026, 16000.00, 0.00, 16000.00, '2026-07-21 14:04:58', 4, '2026-06-01'),
(42, 7, 6, 2026, 19500.00, 0.00, 19500.00, '2026-07-21 14:05:17', 4, '2026-06-01'),
(43, 10, 6, 2026, 24000.00, 0.00, 24000.00, '2026-07-21 14:05:32', 4, '2026-06-01'),
(44, 13, 6, 2026, 22000.00, 0.00, 22000.00, '2026-07-21 14:05:44', 4, '2026-06-01'),
(49, 9, 3, 2026, 24000.00, 0.00, 24000.00, '2026-07-21 17:21:13', 4, '2026-03-21'),
(50, 11, 3, 2026, 12000.00, 0.00, 12000.00, '2026-07-21 17:21:33', 4, '2026-03-01'),
(51, 8, 3, 2026, 16000.00, 0.00, 16000.00, '2026-07-21 17:21:49', 4, '2026-03-21'),
(52, 12, 3, 2026, 7000.00, 0.00, 7000.00, '2026-07-21 17:22:13', 4, '2026-03-01'),
(53, 7, 3, 2026, 19500.00, 0.00, 19500.00, '2026-07-21 17:22:37', 4, '2026-03-01'),
(54, 10, 3, 2026, 18000.00, 0.00, 18000.00, '2026-07-21 17:22:57', 4, '2026-03-01'),
(55, 13, 3, 2026, 14000.00, 0.00, 14000.00, '2026-07-21 17:23:16', 4, '2026-03-01'),
(56, 12, 4, 2026, 7000.00, 0.00, 7000.00, '2026-07-21 17:24:17', 4, '2026-04-01'),
(57, 12, 5, 2026, 7000.00, 0.00, 7000.00, '2026-07-21 17:25:15', 4, '2026-05-01'),
(58, 12, 6, 2026, 7000.00, 0.00, 7000.00, '2026-07-21 17:26:24', 4, '2026-06-01'),
(60, 16, 3, 2026, 3500.00, 0.00, 3500.00, '2026-07-21 17:29:19', 4, '2026-03-01'),
(61, 16, 4, 2026, 3500.00, 0.00, 3500.00, '2026-07-21 17:29:39', 4, '2026-04-01'),
(62, 16, 5, 2026, 3500.00, 0.00, 3500.00, '2026-07-21 17:30:05', 4, '2026-05-01'),
(63, 16, 6, 2026, 3500.00, 0.00, 3500.00, '2026-07-21 17:30:27', 4, '2026-06-01'),
(64, 19, 3, 2026, 7100.00, 0.00, 7100.00, '2026-07-23 14:25:15', 4, '2026-07-23'),
(65, 18, 3, 2026, 9000.00, 0.00, 9000.00, '2026-07-23 14:26:11', 4, '2026-03-01'),
(66, 18, 4, 2026, 9000.00, 0.00, 9000.00, '2026-07-23 14:28:22', 4, '2026-04-01'),
(68, 18, 6, 2026, 6000.00, 0.00, 6000.00, '2026-07-23 14:29:59', 4, '2026-05-01'),
(69, 18, 5, 2026, 9000.00, 0.00, 9000.00, '2026-07-23 14:31:26', 4, '2026-06-01'),
(70, 17, 3, 2026, 12000.00, 0.00, 12000.00, '2026-07-23 14:35:39', 4, '2026-03-01'),
(71, 17, 4, 2026, 12000.00, 0.00, 12000.00, '2026-07-23 14:36:03', 4, '2026-04-01'),
(72, 17, 5, 2026, 9000.00, 0.00, 9000.00, '2026-07-23 14:36:27', 4, '2026-05-01'),
(73, 17, 6, 2026, 9000.00, 0.00, 9000.00, '2026-07-23 14:36:41', 4, '2026-07-23'),
(74, 19, 4, 2026, 7100.00, 0.00, 7100.00, '2026-07-23 14:38:26', 4, '2026-04-01'),
(75, 19, 5, 2026, 7100.00, 0.00, 7100.00, '2026-07-23 14:38:59', 4, '2026-05-01'),
(76, 19, 6, 2026, 7100.00, 0.00, 7100.00, '2026-07-23 14:39:30', 4, '2026-06-01');

-- --------------------------------------------------------

--
-- Table structure for table `staff_salary_payments`
--

CREATE TABLE `staff_salary_payments` (
  `id` int(11) NOT NULL,
  `staff_salary_detail_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `amount` decimal(10,2) NOT NULL,
  `paid_date` date DEFAULT NULL,
  `method` enum('cash','card','bank') NOT NULL DEFAULT 'cash',
  `note` varchar(255) DEFAULT NULL,
  `paid_by_user_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff_salary_payments`
--

INSERT INTO `staff_salary_payments` (`id`, `staff_salary_detail_id`, `created_at`, `amount`, `paid_date`, `method`, `note`, `paid_by_user_id`, `created_by`) VALUES
(17, 18, '2026-07-21 13:41:21', 24000.00, '2026-07-21', 'cash', '', NULL, 4),
(18, 19, '2026-07-21 13:42:07', 12000.00, '2026-07-21', 'cash', '', NULL, 4),
(19, 20, '2026-07-21 13:42:58', 16000.00, '2026-07-21', 'cash', '', NULL, 4),
(20, 21, '2026-07-21 13:44:10', 19500.00, '2026-07-21', 'cash', '', NULL, 4),
(21, 22, '2026-07-21 13:46:40', 18000.00, '2026-07-21', 'cash', '', NULL, 4),
(22, 23, '2026-07-21 13:46:43', 14000.00, '2026-07-21', 'cash', '', NULL, 4),
(31, 32, '2026-07-21 14:02:08', 24000.00, '2026-07-21', 'cash', '', NULL, 4),
(32, 34, '2026-07-21 14:03:41', 16000.00, '2026-07-21', 'cash', '', NULL, 4),
(33, 35, '2026-07-21 14:03:43', 19500.00, '2026-07-21', 'cash', '', NULL, 4),
(34, 36, '2026-07-21 14:03:45', 18000.00, '2026-07-21', 'cash', '', NULL, 4),
(35, 37, '2026-07-21 14:03:49', 14000.00, '2026-07-21', 'cash', '', NULL, 4),
(37, 33, '2026-07-21 14:03:55', 12000.00, '2026-07-21', 'cash', '', NULL, 4),
(39, 44, '2026-07-21 14:06:16', 14000.00, '2026-07-21', 'cash', '', NULL, 4),
(40, 43, '2026-07-21 14:06:18', 18000.00, '2026-07-21', 'cash', '', NULL, 4),
(41, 42, '2026-07-21 14:06:20', 19500.00, '2026-07-21', 'cash', '', NULL, 4),
(42, 41, '2026-07-21 14:06:23', 16000.00, '2026-07-21', 'cash', '', NULL, 4),
(43, 40, '2026-07-21 14:06:25', 12000.00, '2026-07-21', 'cash', '', NULL, 4),
(44, 39, '2026-07-21 14:06:27', 24000.00, '2026-07-21', 'cash', '', NULL, 4),
(46, 49, '2026-07-21 17:21:17', 24000.00, '2026-07-21', 'cash', '', NULL, 4),
(47, 50, '2026-07-21 17:23:25', 12000.00, '2026-07-21', 'cash', '', NULL, 4),
(48, 51, '2026-07-21 17:23:30', 16000.00, '2026-07-21', 'cash', '', NULL, 4),
(49, 52, '2026-07-21 17:23:34', 7000.00, '2026-07-21', 'cash', '', NULL, 4),
(50, 55, '2026-07-21 17:23:37', 14000.00, '2026-07-21', 'cash', '', NULL, 4),
(51, 54, '2026-07-21 17:23:40', 18000.00, '2026-07-21', 'cash', '', NULL, 4),
(52, 53, '2026-07-21 17:23:42', 19500.00, '2026-07-21', 'cash', '', NULL, 4),
(53, 56, '2026-07-21 17:24:25', 7000.00, '2026-07-21', 'cash', '', NULL, 4),
(54, 57, '2026-07-21 17:26:01', 7000.00, '2026-07-21', 'cash', '', NULL, 4),
(55, 58, '2026-07-21 17:26:28', 7000.00, '2026-07-21', 'cash', '', NULL, 4),
(56, 60, '2026-07-23 14:26:20', 3500.00, '2026-07-23', 'cash', '', NULL, 4),
(57, 65, '2026-07-23 14:26:25', 9000.00, '2026-07-23', 'cash', '', NULL, 4),
(58, 64, '2026-07-23 14:26:42', 7100.00, '2026-07-23', 'cash', '', NULL, 4),
(59, 62, '2026-07-23 14:29:17', 3500.00, '2026-07-23', 'cash', '', NULL, 4),
(61, 63, '2026-07-23 14:29:32', 3500.00, '2026-07-23', 'cash', '', NULL, 4),
(62, 68, '2026-07-23 14:30:27', 6000.00, '2026-07-23', 'cash', '', NULL, 4),
(63, 69, '2026-07-23 14:31:33', 9000.00, '2026-07-23', 'cash', '', NULL, 4),
(64, 73, '2026-07-23 14:36:47', 9000.00, '2026-07-23', 'cash', '', NULL, 4),
(65, 72, '2026-07-23 14:36:57', 9000.00, '2026-07-23', 'cash', '', NULL, 4),
(66, 61, '2026-07-23 14:37:07', 3500.00, '2026-07-23', 'cash', '', NULL, 4),
(67, 71, '2026-07-23 14:37:14', 12000.00, '2026-07-23', 'cash', '', NULL, 4),
(68, 66, '2026-07-23 14:37:18', 9000.00, '2026-07-23', 'cash', '', NULL, 4),
(69, 70, '2026-07-23 14:37:30', 12000.00, '2026-07-23', 'cash', '', NULL, 4),
(70, 74, '2026-07-23 14:38:31', 7100.00, '2026-07-23', 'cash', '', NULL, 4),
(71, 75, '2026-07-23 14:39:05', 7100.00, '2026-07-23', 'cash', '', NULL, 4),
(72, 76, '2026-07-23 14:39:36', 7100.00, '2026-07-23', 'cash', '', NULL, 4),
(73, 36, '2026-07-23 14:57:14', 6000.00, '2026-07-23', 'cash', '', NULL, 4),
(74, 43, '2026-07-23 15:09:25', 6000.00, '2026-07-23', 'cash', '', NULL, 4),
(75, 37, '2026-07-24 10:53:03', 3000.00, '2026-07-24', 'cash', '', NULL, 4),
(76, 44, '2026-07-24 10:54:15', 8000.00, '2026-07-24', 'cash', '', NULL, 4);

-- --------------------------------------------------------

--
-- Table structure for table `staff_subject_assignments`
--

CREATE TABLE `staff_subject_assignments` (
  `id` int(11) NOT NULL,
  `staff_profile_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `active_from` date DEFAULT NULL,
  `active_to` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff_subject_assignments`
--

INSERT INTO `staff_subject_assignments` (`id`, `staff_profile_id`, `subject_id`, `active_from`, `active_to`) VALUES
(10, 9, 25, NULL, NULL),
(11, 9, 26, NULL, NULL),
(12, 9, 27, NULL, NULL),
(13, 9, 28, NULL, NULL),
(14, 7, 29, NULL, NULL),
(15, 7, 30, NULL, NULL),
(16, 7, 31, NULL, NULL),
(17, 7, 32, NULL, NULL),
(18, 7, 33, NULL, NULL),
(19, 7, 34, NULL, NULL),
(20, 7, 35, NULL, NULL),
(21, 10, 36, NULL, NULL),
(22, 10, 37, NULL, NULL),
(23, 10, 38, NULL, NULL),
(24, 10, 39, NULL, NULL),
(25, 10, 40, NULL, NULL),
(26, 10, 41, NULL, NULL),
(27, 10, 42, NULL, NULL),
(28, 11, 43, NULL, NULL),
(29, 11, 44, NULL, NULL),
(30, 11, 45, NULL, NULL),
(31, 11, 46, NULL, NULL),
(32, 11, 47, NULL, NULL),
(33, 11, 48, NULL, NULL),
(34, 11, 49, NULL, NULL),
(35, 8, 50, NULL, NULL),
(36, 8, 51, NULL, NULL),
(37, 8, 52, NULL, NULL),
(38, 8, 53, NULL, NULL),
(39, 8, 54, NULL, NULL),
(40, 8, 55, NULL, NULL),
(41, 8, 56, NULL, NULL),
(42, 13, 57, NULL, NULL),
(43, 13, 58, NULL, NULL),
(44, 13, 59, NULL, NULL),
(45, 13, 60, NULL, NULL),
(46, 13, 61, NULL, NULL),
(47, 13, 62, NULL, NULL),
(48, 13, 63, NULL, NULL),
(49, 13, 64, NULL, NULL),
(58, 9, 24, NULL, NULL),
(59, 9, 23, NULL, NULL),
(60, 18, 75, NULL, NULL),
(61, 19, 76, NULL, NULL),
(63, 19, 77, NULL, NULL),
(64, 17, 78, NULL, NULL),
(65, 17, 79, NULL, NULL),
(66, 17, 80, NULL, NULL),
(67, 19, 81, NULL, NULL),
(68, 13, 92, NULL, NULL),
(69, 13, 93, NULL, NULL),
(70, 10, 84, NULL, NULL),
(71, 10, 85, NULL, NULL),
(72, 9, 74, NULL, NULL),
(73, 9, 73, NULL, NULL),
(74, 7, 95, NULL, NULL),
(75, 7, 96, NULL, NULL),
(85, 10, 83, NULL, NULL),
(87, 18, 94, NULL, NULL),
(88, 18, 82, NULL, NULL),
(91, 7, 112, NULL, NULL),
(92, 7, 113, NULL, NULL),
(93, 11, 91, NULL, NULL),
(94, 11, 90, NULL, NULL),
(95, 11, 89, NULL, NULL),
(96, 12, 65, NULL, NULL),
(97, 12, 66, NULL, NULL),
(98, 12, 67, NULL, NULL),
(99, 12, 68, NULL, NULL),
(100, 12, 69, NULL, NULL),
(101, 12, 70, NULL, NULL),
(102, 12, 71, NULL, NULL),
(105, 11, 88, NULL, NULL),
(106, 11, 87, NULL, NULL),
(107, 12, 72, NULL, NULL),
(121, 13, 69, NULL, NULL),
(138, 7, 120, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `admission_no` varchar(30) NOT NULL,
  `first_name` varchar(80) NOT NULL,
  `last_name` varchar(80) NOT NULL,
  `father_name` varchar(120) DEFAULT NULL,
  `board_registration_no` varchar(60) DEFAULT NULL,
  `cnic_no` varchar(25) DEFAULT NULL,
  `gender` enum('M','F','Other') NOT NULL DEFAULT 'M',
  `dob` date DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `fee_discount_percent` decimal(12,2) NOT NULL DEFAULT 0.00,
  `fee_discount_is_percent` tinyint(4) NOT NULL DEFAULT 1,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `roll_number` varchar(50) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `photo_blob` longblob DEFAULT NULL,
  `photo_type` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `user_id`, `admission_no`, `first_name`, `last_name`, `father_name`, `board_registration_no`, `cnic_no`, `gender`, `dob`, `phone`, `address`, `fee_discount_percent`, `fee_discount_is_percent`, `status`, `created_at`, `roll_number`, `photo`, `photo_blob`, `photo_type`) VALUES
(589, 22, '645', 'Masooma', 'Batool', 'Muhammad Iqbal', '', '71501-3847662-6', 'F', '2010-03-02', '03555275043', '', 0.00, 1, 1, '2026-07-03 07:29:01', '13', NULL, NULL, NULL),
(590, 23, '692', 'Naseema', 'Batool', 'Muhammad Hassan', '', '72302-0337899-0', 'F', '2010-01-01', '03555417448', '', 0.00, 1, 1, '2026-07-03 07:31:23', '14', NULL, NULL, NULL),
(591, 24, 'STUshehriyar', 'Shahriyar', 'Shair Muhammad', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 05:51:07', '1', NULL, NULL, NULL),
(592, 25, 'STUNoureen', 'Noureen', 'Nazir', 'Wazir Nazir', '', NULL, 'M', NULL, '', '', 50.00, 1, 1, '2026-07-13 05:52:32', '2', NULL, NULL, NULL),
(595, 26, 'STU003', 'Mehwish', 'Hussain', 'Nisar Hussain', '', NULL, 'M', NULL, '', '', 50.00, 1, 1, '2026-07-13 06:22:51', '3', NULL, NULL, NULL),
(596, 27, 'STU004', 'Mohd Essa', 'Nisar Husain', 'Nisar Husain', '', NULL, 'M', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '4', NULL, NULL, NULL),
(597, 28, 'STU005', 'Muez', 'Ali Ali Cho', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '5', NULL, NULL, NULL),
(598, 29, 'STU006', 'Mohd', 'Ali Mr Abbas', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '6', NULL, NULL, NULL),
(599, 30, 'STU007', 'Shayan', 'Ali Zahid Hussain', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '7', NULL, NULL, NULL),
(600, 31, 'STU008', 'Muhammad', 'Gh-Abbas', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '8', NULL, NULL, NULL),
(602, 33, 'STU010', 'W.', 'Muzammil Sharifullah', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '10', NULL, NULL, NULL),
(603, 34, 'STU011', 'M.', 'Amir Arif Hussain', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '11', NULL, NULL, NULL),
(604, 35, 'STU012', 'M.', 'Hasnain F. Hussain', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '12', NULL, NULL, NULL),
(605, 36, 'STU013', 'Tathir', 'Murtaza', 'Murtaza', '', NULL, 'M', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '13', NULL, NULL, NULL),
(606, 37, 'STU014', 'Saeed', 'Mumtaz', 'Mumtaz', '', NULL, 'M', NULL, '', '', 50.00, 1, 1, '2026-07-13 06:22:51', '14', NULL, NULL, NULL),
(607, 38, 'STU015', 'Zulqarnain', 'Shabbir', 'Shabbir', '', NULL, 'M', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '15', NULL, NULL, NULL),
(608, 39, 'STU016', 'Ali', 'Naqi', 'Wilayat', '', NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '16', NULL, NULL, NULL),
(609, 40, 'STU017', 'Shazaib', 'Shujaat', 'Shujaat', '', NULL, 'M', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '17', NULL, NULL, NULL),
(610, 41, 'STU018', 'Kiyan', 'Shujaat', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '18', NULL, NULL, NULL),
(611, 42, 'STU019', 'Aryan', 'Abdullah', 'Abdullah', '', NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '1', NULL, NULL, NULL),
(612, 43, 'STU020', 'Yasir', 'Shair', 'Shair', '', NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '2', NULL, NULL, NULL),
(613, 44, 'STU021', 'Hasnain', 'Fida Ali', 'Fida Ali', '', NULL, 'M', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '3', NULL, NULL, NULL),
(614, 45, 'STU022', 'Sakina', 'Ali', 'Ali Cho', '', NULL, 'F', NULL, '', '', 50.00, 1, 1, '2026-07-13 06:22:51', '4', NULL, NULL, NULL),
(615, 46, 'STU023', 'Madiha', 'Wajahat', 'Wajahat', '', NULL, 'M', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '5', NULL, NULL, NULL),
(616, 47, 'STU024', 'Jano', 'Kazim', 'Kazim', '', NULL, 'M', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '6', NULL, NULL, NULL),
(617, 48, 'STU025', 'Safeer', 'Mashroof', 'Mashroof', '', NULL, 'M', NULL, '', '', 50.00, 1, 1, '2026-07-13 06:22:51', '7', NULL, NULL, NULL),
(618, 49, 'STU026', 'Haidar', 'Fida Hussain', 'Fida Hussain', '', NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '8', NULL, NULL, NULL),
(619, 50, 'STU027', 'Faizan', 'Bakhtawar', 'Bakhtawar', '', NULL, 'M', NULL, '', '', 50.00, 1, 1, '2026-07-13 06:22:51', '9', NULL, NULL, NULL),
(620, 51, 'STU028', 'Adib', 'Ali Naqi', 'Ali Naqi', '', NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '10', NULL, NULL, NULL),
(621, 52, 'STU029', 'Ayaz', 'Shair', 'Shair', '', NULL, 'M', NULL, '', '', 50.00, 1, 1, '2026-07-13 06:22:51', '11', NULL, NULL, NULL),
(622, 53, 'STU030', 'Muntazir', 'Ali', 'Ali', '', NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '12', NULL, NULL, NULL),
(623, 54, 'STU031', 'Sharifullah', 'Baqir', 'Baqir', '', NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '13', NULL, NULL, NULL),
(625, 56, 'STU033', 'Kamil', 'Iqbal', 'Iqbal', '', NULL, 'M', NULL, '', '', 50.00, 1, 1, '2026-07-13 06:22:51', '15', NULL, NULL, NULL),
(626, 57, 'STU034', 'Shafqat', 'Ali', 'M. Ali', '', NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '16', NULL, NULL, NULL),
(627, 58, 'STU035', 'Oliya', 'Mumtaz', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '1', NULL, NULL, NULL),
(628, 59, 'STU036', 'Kaneez', 'Mahmood', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '2', NULL, NULL, NULL),
(629, 60, 'STU037', 'Zahara', 'Zahid', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '3', NULL, NULL, NULL),
(630, 61, 'STU038', 'Khadija', 'Nazir', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '4', NULL, NULL, NULL),
(631, 62, 'STU039', 'Saima', 'Yousuf', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '5', NULL, NULL, NULL),
(632, 63, 'STU040', 'Tahareen', 'Mubarak', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '6', NULL, NULL, NULL),
(633, 64, 'STU041', 'Sherbaz', 'Taha Milk', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '7', NULL, NULL, NULL),
(634, 65, 'STU042', 'Sahil', 'Ibrahim', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '8', NULL, NULL, NULL),
(635, 66, 'STU043', 'Shyaan', 'Nasir', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '9', NULL, NULL, NULL),
(636, 67, 'STU044', 'Hassinain', 'Fida Ali', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '10', NULL, NULL, NULL),
(637, 68, 'STU045', 'Zamein', 'Laqat Ali', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '11', NULL, NULL, NULL),
(638, 69, 'STU046', 'Kazim', 'Shujaat', 'Shujaat', '', NULL, 'M', NULL, '', '', 50.00, 1, 1, '2026-07-13 06:22:51', '12', NULL, NULL, NULL),
(639, 70, 'STU047', 'Ashiq', 'Fida Hussain', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '13', NULL, NULL, NULL),
(640, 71, 'STU048', 'Sirtaj', 'Nusrullah', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '14', NULL, NULL, NULL),
(641, 72, 'STU049', 'Arfaan', 'Kazim', 'Kazim', '', NULL, 'M', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '15', NULL, NULL, NULL),
(642, 73, 'STU050', 'Shahriyar', 'Sher-M', '', '', NULL, 'M', NULL, '', '', 50.00, 1, 1, '2026-07-13 06:22:51', '16', NULL, NULL, NULL),
(643, 74, 'STU051', 'Tajwar', 'Shareef', 'Shareef', '', '', 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '17', NULL, NULL, NULL),
(644, 75, 'STU052', 'Asghar', 'Ali Ali Cho', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '1', NULL, NULL, NULL),
(645, 76, 'STU053', 'Zameer', 'Abbas', 'Yousuf', '', '', 'M', NULL, '', '', 50.00, 1, 1, '2026-07-13 06:22:51', '2', NULL, NULL, NULL),
(646, 77, 'STU054', 'Shahzad', 'Ali', 'Shair Mohd', '', NULL, 'M', NULL, '', '', 25.00, 1, 1, '2026-07-13 06:22:51', '3', NULL, NULL, NULL),
(647, 78, 'STU055', 'Ali', 'Ahmed', 'Gh-Mumtaza', '', NULL, 'M', NULL, '', '', 50.00, 1, 1, '2026-07-13 06:22:51', '4', NULL, NULL, NULL),
(648, 79, 'STU056', 'Hasnain', 'Arif', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '5', NULL, NULL, NULL),
(649, 80, 'STU057', 'Hasnain', 'Wajahat', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '6', NULL, NULL, NULL),
(650, 81, 'STU058', 'Haidar', 'Ali Muzafar', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '7', NULL, NULL, NULL),
(651, 82, 'STU059', 'Irfan', 'Ali Mubarak', '', '', '', 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '8', NULL, NULL, NULL),
(652, 83, 'STU060', 'Mairaj', 'Shabbir', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '9', NULL, NULL, NULL),
(653, 84, 'STU061', 'Novreen', 'Baqir', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '10', NULL, NULL, NULL),
(654, 85, 'STU062', 'Niha', 'Nasir', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '11', NULL, NULL, NULL),
(655, 86, 'STU063', 'Kubra', 'Ali', 'Ali Mohd', '', NULL, 'M', NULL, '', '', 25.00, 1, 1, '2026-07-13 06:22:51', '12', NULL, NULL, NULL),
(656, 87, 'STU064', 'Sonam', 'Bakhtawar', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '1', NULL, NULL, NULL),
(657, 88, 'STU065', 'Fatima', 'Ali', 'Ali Khan', '', '', 'F', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '2', NULL, NULL, NULL),
(658, 89, 'STU066', 'Samreen', 'Mustafa', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '3', NULL, NULL, NULL),
(659, 90, 'STU067', 'Sakina', 'Iqbal', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '4', NULL, NULL, NULL),
(660, 91, 'STU068', 'Kiran', 'Nisar', 'Nisar', '', NULL, 'F', NULL, '', '', 25.00, 1, 1, '2026-07-13 06:22:51', '5', NULL, NULL, NULL),
(661, 92, 'STU069', 'Zainab', 'Sikandar', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '6', NULL, NULL, NULL),
(662, 93, 'STU070', 'Mosa', 'Sakhawat', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '7', NULL, NULL, NULL),
(663, 94, 'STU071', 'Muhammad', 'Iqbal', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '8', NULL, NULL, NULL),
(664, 95, 'STU072', 'Salih', 'Mumtaz', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '9', NULL, NULL, NULL),
(665, 96, 'STU073', 'Shanawar', 'Ali Naqi', 'Ali Naqi', '', NULL, 'M', NULL, '', '', 50.00, 1, 1, '2026-07-13 06:22:51', '10', NULL, NULL, NULL),
(666, 97, 'STU074', 'Hasnain', 'Gh-Mohd', 'Gh-Mohd', '', NULL, 'M', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '11', NULL, NULL, NULL),
(667, 98, 'STU075', 'Farhan', 'Zahid', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '12', NULL, NULL, NULL),
(668, 99, 'STU076', 'Ali', 'Mosa', 'Shafa Ali', '', '', 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '13', NULL, NULL, NULL),
(669, 100, 'STU077', 'Yasir', 'Yousaf', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '14', NULL, NULL, NULL),
(670, 101, 'STU078', 'Ayan', 'Zakir', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '15', NULL, NULL, NULL),
(671, 102, 'STU079', 'Shujaat', 'Ali', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '16', NULL, NULL, NULL),
(672, 103, 'STU080', 'Hasnain', 'Ali', 'Ali', '', NULL, 'M', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '17', NULL, NULL, NULL),
(673, 104, 'STU081', 'Shahid', 'Arif', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '18', NULL, NULL, NULL),
(674, 105, 'STU082', 'Mushahid', 'Manzoor', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '19', NULL, NULL, NULL),
(675, 106, 'STU083', 'Zameer', 'Mashroob', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '20', NULL, NULL, NULL),
(676, 107, 'STU084', 'Ayan', 'Abdullah', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '21', NULL, NULL, NULL),
(677, 108, 'STU085', 'Yasir', 'Arif', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '22', NULL, NULL, NULL),
(678, 109, 'STU086', 'Yasmeen', 'Ali Khan', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '1', NULL, NULL, NULL),
(679, 110, 'STU087', 'Hijab', 'Ali Mohd', 'Ali Muhammad', '', '', 'F', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '2', NULL, NULL, NULL),
(680, 111, 'STU088', 'Aliza', 'Wajahat', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '3', NULL, NULL, NULL),
(681, 112, 'STU089', 'Hasina', 'Kazim', 'Kazim', '', NULL, 'F', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '4', NULL, NULL, NULL),
(682, 113, 'STU090', 'Hadiqa', 'Gh-Mutaza', 'Ghulam Murtaza', '', '', 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '5', NULL, NULL, NULL),
(683, 114, 'STU091', 'Sana', 'Baqir', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '6', NULL, NULL, NULL),
(684, 115, 'STU092', 'Urooj', 'Shair', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '7', NULL, NULL, NULL),
(685, 116, 'STU093', 'Maryam', 'M-Kazim', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '8', NULL, NULL, NULL),
(686, 117, 'STU094', 'Riyan', 'Abdullah', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '9', NULL, NULL, NULL),
(687, 118, 'STU095', 'Niaz', 'Shair', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '10', NULL, NULL, NULL),
(688, 119, 'STU096', 'Rahat', 'Nawaz Khan', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '11', NULL, NULL, NULL),
(689, 120, 'STU097', 'Zeeshan', 'Tufail', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '12', NULL, NULL, NULL),
(690, 121, 'STU098', 'Irfan', 'Muzafar', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '13', NULL, NULL, NULL),
(691, 122, 'STU099', 'Munawar', 'Naqi', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '14', NULL, NULL, NULL),
(692, 123, 'STU100', 'Maisam', 'Essa Khan', 'ESA Khan', '', '', 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '15', NULL, NULL, NULL),
(693, 124, 'STU101', 'Riaz', 'Bakhtawar', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '16', NULL, NULL, NULL),
(694, 125, 'STU102', 'Shair', 'Ali Ali Khan', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '17', NULL, NULL, NULL),
(695, 126, 'STU103', 'Ahmed', 'Fida Ali', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '18', NULL, NULL, NULL),
(696, 127, 'STU104', 'Tajamul', 'Ali', 'Ali', '', NULL, 'M', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '19', NULL, NULL, NULL),
(697, 128, 'STU105', 'Irfan', 'Mirza Hassan', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '20', NULL, NULL, NULL),
(698, 129, 'STU106', 'Saqlain', 'Tahir', 'Tahir', '', '', 'M', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '21', NULL, NULL, NULL),
(699, 130, 'STU107', 'Ali', 'Raza Sakhawat', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '22', NULL, NULL, NULL),
(700, 131, 'STU108', 'Ali', 'Ilyas', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '23', NULL, NULL, NULL),
(701, 132, 'STU109', 'Ismail', 'Ibrahim', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '24', NULL, NULL, NULL),
(702, 133, 'STU110', 'Abbas', 'Ali Cho', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '25', NULL, NULL, NULL),
(703, 134, 'STU111', 'Raza', 'Ali Mohd', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '26', NULL, NULL, NULL),
(704, 135, 'STU112', 'Mohd', 'Ali Ali', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '27', NULL, NULL, NULL),
(705, 136, 'STU113', 'Irfan', 'Ali Farman Ali', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '1', NULL, NULL, NULL),
(706, 137, 'STU114', 'Zaighum', 'Ali', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '2', NULL, NULL, NULL),
(707, 138, 'STU115', 'Ali', 'Naqvi Sakhawat', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '3', NULL, NULL, NULL),
(708, 139, 'STU116', 'Mohd', 'Riaz Gh Mehdi', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '4', NULL, NULL, NULL),
(709, 140, 'STU117', 'Hasnain', 'Mubarak', 'Mubarak', '', NULL, 'M', NULL, '', '', 50.00, 1, 1, '2026-07-13 06:22:51', '5', NULL, NULL, NULL),
(710, 141, 'STU118', 'Mosa', 'Ali Nisar', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '6', NULL, NULL, NULL),
(711, 142, 'STU119', 'Sammar', 'Gh-Mustafa', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '7', NULL, NULL, NULL),
(712, 143, 'STU120', 'Ali', 'Raza Sakawat', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '8', NULL, NULL, NULL),
(713, 144, 'STU121', 'Rasham', 'Nabi', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '9', NULL, NULL, NULL),
(714, 145, 'STU122', 'Anila', 'Wajahat', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '10', NULL, NULL, NULL),
(715, 146, 'STU123', 'Sania', 'Mubarak', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '11', NULL, NULL, NULL),
(716, 147, 'STU124', 'Tanveer', 'Shabbir', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '12', NULL, NULL, NULL),
(717, 148, 'STU125', 'Muzammil', 'Taha', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '13', NULL, NULL, NULL),
(718, 149, 'STU126', 'Nasreen', 'Yousaf', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '1', NULL, NULL, NULL),
(719, 150, 'STU127', 'Nasreen', 'Ali Naqi', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '2', NULL, NULL, NULL),
(720, 151, 'STU128', 'Hasina', 'Mubarak', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '3', NULL, NULL, NULL),
(721, 152, 'STU129', 'Junaid', 'Essa Khan', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '4', NULL, NULL, NULL),
(722, 153, 'STU130', 'Rafiq', 'Shair', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '5', NULL, NULL, NULL),
(723, 154, 'STU131', 'Shanawar', 'Jabbar', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '6', NULL, NULL, NULL),
(724, 155, 'STU132', 'Maisam', 'Ali Khan', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '7', NULL, NULL, NULL),
(725, 156, 'STU133', 'Mushahid', 'M. Baqir', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '8', NULL, NULL, NULL),
(726, 157, 'STU134', 'Ibrahim', 'Gh-Mohd', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '9', NULL, NULL, NULL),
(727, 158, 'STU135', 'Zeeshan', 'Gh-Mehdi', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '10', NULL, NULL, NULL),
(728, 159, 'STU136', 'Asif', 'Ali Hussain', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '11', NULL, NULL, NULL),
(729, 160, 'STU137', 'Naila', 'Hassan', 'Hassan', '', NULL, 'F', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '12', NULL, NULL, NULL),
(730, 161, 'STU138', 'M.', 'Hussain Arif', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '13', NULL, NULL, NULL),
(731, 162, 'STU139', 'M.', 'Sameer Mashroob', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '14', NULL, NULL, NULL),
(732, 163, 'STU140', 'Imran', 'Mehdi', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '1', NULL, NULL, NULL),
(733, 164, 'STU141', 'Zulqarnain', 'M. Khan', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '2', NULL, NULL, NULL),
(734, 165, 'STU142', 'Abbas', 'Ali Mohd', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '3', NULL, NULL, NULL),
(735, 166, 'STU143', 'Imran', 'Baqir', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '4', NULL, NULL, NULL),
(736, 167, 'STU144', 'Mehdi', 'Hassan Nisar Hussain', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '5', NULL, NULL, NULL),
(737, 168, 'STU145', 'Fayaz', 'Ilyas', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '6', NULL, NULL, NULL),
(738, 169, 'STU146', 'Zain', 'Ali', 'Fida Ali', '', NULL, 'M', NULL, '', '', 25.00, 1, 1, '2026-07-13 06:22:51', '7', NULL, NULL, NULL),
(739, 170, 'STU147', 'Asadullah', 'M. Ali', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '8', NULL, NULL, NULL),
(740, 171, 'STU148', 'Zubair', 'Ibrahim', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '9', NULL, NULL, NULL),
(741, 172, 'STU149', 'Yasir', 'Abbas Shabbir', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '10', NULL, NULL, NULL),
(742, 173, 'STU150', 'Zeeshan', 'Ali Yasin Ali', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '11', NULL, NULL, NULL),
(743, 174, 'STU151', 'Muzammil', 'Ali', 'Ali', '', NULL, 'M', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '12', NULL, NULL, NULL),
(744, 175, 'STU152', 'Shair', 'Mohd', 'Mohd Kazim', '', NULL, 'M', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '13', NULL, NULL, NULL),
(745, 176, 'STU153', 'Ali', 'Hassan', 'Yousaf', '', NULL, 'M', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '14', NULL, NULL, NULL),
(746, 177, 'STU154', 'Shamshad', 'M. Ali', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '15', NULL, NULL, NULL),
(747, 178, 'STU155', 'Wajiha', 'Wajahat', 'Wajahat', '', '', 'F', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '16', NULL, NULL, NULL),
(748, 179, 'STU156', 'Sughra', 'Gh Nabi', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '17', NULL, NULL, NULL),
(749, 180, 'STU157', 'Eram', 'Shair', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '18', NULL, NULL, NULL),
(750, 181, 'STU158', 'Alviya', 'Gh Murtaza', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '19', NULL, NULL, NULL),
(751, 182, 'STU159', 'Yasmeen', 'Nisar', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '20', NULL, NULL, NULL),
(752, 183, 'STU160', 'Anila', 'Gh-Ali', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '21', NULL, NULL, NULL),
(753, 184, 'STU161', 'Naila', 'Ali', 'Fida Ali', '', '', 'F', NULL, '', '', 50.00, 1, 1, '2026-07-13 06:22:51', '22', NULL, NULL, NULL),
(754, 185, 'STU162', 'Shahnam', 'Ali Khan', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '23', NULL, NULL, NULL),
(755, 186, 'STU163', 'Sara', 'Batool', 'Haji Qasim', '', NULL, 'M', NULL, '', '', 100.00, 1, 1, '2026-07-13 06:22:51', '1', NULL, NULL, NULL),
(756, 187, 'STU164', 'Sadia', 'Fida Ali', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '2', NULL, NULL, NULL),
(757, 188, 'STU165', 'Sania', 'Fida Ali', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '3', NULL, NULL, NULL),
(758, 189, 'STU166', 'Zahra', 'Nabi', NULL, NULL, NULL, 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '4', NULL, NULL, NULL),
(759, 18, 'STU167', 'Tasneem', 'Zehra', 'Yousaf Ali', '', '', 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '5', NULL, NULL, NULL),
(760, 190, 'STU168', 'Ishrat', 'Abdullah', 'Abdullah', '', '', 'M', NULL, '', '', 100.00, 1, 0, '2026-07-13 06:22:51', '6', NULL, NULL, NULL),
(761, 191, 'STU169', 'Israr', 'Nisar', 'Nisar', '', '', 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '7', NULL, NULL, NULL),
(762, 192, 'STU170', 'Hasnain', 'Gh-Mahamad', 'Gh-Mahamad', '', '', 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '8', NULL, NULL, NULL),
(763, 193, 'STU171', 'Suheil', 'Shair Ali', 'Shair Ali', '', '', 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '9', NULL, NULL, NULL),
(764, 194, 'STU172', 'Amir', 'Mubarak', 'Mubarak', '', '', 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '10', NULL, NULL, NULL),
(765, 195, 'STU173', 'Kamran', 'Shabbir', 'Shabbir', '', '', 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '11', NULL, NULL, NULL),
(766, 196, 'STU174', 'Mubarak', 'Fida Hussain', 'Fida Hussain', '', '', 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '12', NULL, NULL, NULL),
(767, 197, 'STU175', 'Amir', 'Hassan', 'Hassan', '', '', 'M', NULL, '', '', 0.00, 1, 1, '2026-07-13 06:22:51', '13', NULL, NULL, NULL),
(768, 198, 'STU176', 'Suriya', 'Batool', 'Ghulam Abbas', '', '71104-0358795-4', 'F', '2011-05-02', '03554508644', '', 0.00, 1, 1, '2026-07-16 09:48:10', '1', NULL, NULL, NULL),
(769, 199, 'STU177', 'Marzia', 'Batool', 'Ali Khan', '', '71104-0417492-2', 'F', '2010-02-03', '03555417289', '', 0.00, 1, 1, '2026-07-16 09:48:10', '2', NULL, NULL, NULL),
(770, 200, 'STU178', 'Kaneez', 'Zahra', 'Muhammad', '', '72302-0343443-0', 'F', '2012-11-15', '03554182701', '', 0.00, 1, 1, '2026-07-16 09:48:10', '3', NULL, NULL, NULL),
(771, 201, 'STU179', 'Zubida', 'Batool', 'Mubarak Ali', '', '72302-0348101-6', 'F', '2013-03-13', '03555265110', '', 0.00, 1, 1, '2026-07-16 09:48:10', '4', NULL, NULL, NULL),
(772, 202, 'STU180', 'Batool', 'Fatima', 'Muhammad', '', '72302-0342601-6', 'F', '2011-04-07', '03555194630', '', 0.00, 1, 1, '2026-07-16 09:48:10', '5', NULL, NULL, NULL),
(773, 203, 'STU181', 'Sughra', 'Batool', 'Muhammad Ishaq', '', '72302-0344725-4', 'F', '2012-05-01', '03555652163', '', 0.00, 1, 1, '2026-07-16 09:48:10', '6', NULL, NULL, NULL),
(774, 204, 'STU182', 'Abida', 'Batool', 'Rustam Ali', '', '71104-0628421-4', 'F', '2010-01-08', '03554188490', '', 0.00, 1, 1, '2026-07-16 09:48:10', '7', NULL, NULL, NULL),
(775, 205, 'STU183', 'Shamsia', 'Batool', 'Fida Hussain', '', '72302-0341974-8', 'F', '2012-04-07', '03555384132', '', 0.00, 1, 1, '2026-07-16 09:48:10', '8', NULL, NULL, NULL),
(776, 206, 'STU184', 'Asifa', 'Batool', 'Shair Muhammad', '', '71104-8832408-0', 'F', '2010-05-03', '03555354136', '', 0.00, 1, 1, '2026-07-16 09:48:10', '9', NULL, NULL, NULL),
(777, 207, 'STU185', 'Tahira', 'Fida Hussain', 'Fida Hussain', '', '72302-0345449-6', 'F', '2010-01-08', '03555437214', '', 0.00, 1, 1, '2026-07-16 09:48:10', '10', NULL, NULL, NULL),
(778, 208, 'STU186', 'Rashida', 'Batool', 'Muhammad', '', '72302-0364738-2', 'F', '2011-05-14', '03555037836', '', 0.00, 1, 1, '2026-07-16 09:48:10', '11', NULL, NULL, NULL),
(779, 209, 'STU187', 'Aziza', 'Batool', 'Ali', '', '72302-0338262-8', 'F', '2011-03-03', '03554285494', '', 0.00, 1, 1, '2026-07-16 09:48:10', '12', NULL, NULL, NULL),
(780, 210, 'STU188', 'Nahida', 'Rustam', 'Rustam', '', '71104-8622379-4', 'F', '2010-10-05', '03554296346', '', 0.00, 1, 1, '2026-07-16 09:48:10', '13', NULL, NULL, NULL),
(782, 211, 'STU190', 'Khurshida', 'Batool', 'Muhammad Zaman', '', '72302-0338837-2', 'F', '2012-04-03', '03555080798', '', 0.00, 1, 1, '2026-07-16 09:48:10', '15', NULL, NULL, NULL),
(784, 212, 'STU192', 'Khadija', 'Batool', 'Muhammad Hussain', '', '71104-6826441-2', 'F', '2010-01-01', '03555460721', '', 0.00, 1, 1, '2026-07-16 09:48:10', '17', NULL, NULL, NULL),
(785, 213, 'STU193', 'Maryam', 'Mehdi', 'Ghulam Mehdi', '', '72302-0352813-2', 'F', '2010-02-04', '03554477035', '', 0.00, 1, 1, '2026-07-16 09:48:10', '18', NULL, NULL, NULL),
(786, 214, '2560550035', 'SUMIRA', 'BANO', 'SHABAN', '', '', 'M', '2009-08-20', '03554401469', '', 0.00, 1, 0, '2026-07-16 09:48:10', '1', NULL, NULL, NULL),
(787, 215, '2360560053', 'SHAKEELA', 'IBRAHIM', 'IBRAHIM', '', '', 'F', '2008-03-25', '03554528143', '', 0.00, 1, 1, '2026-07-16 09:48:10', '2', NULL, NULL, NULL),
(788, 216, '2360560052', 'HAKEEMA', 'KHANUM', 'GHULAM SHAIR', '', '', 'F', '2006-05-04', '03555654730', '', 0.00, 1, 1, '2026-07-16 09:48:10', '3', NULL, NULL, NULL),
(789, 217, '2560560053', 'SAKINA', 'BI', 'ALI KHAN', '', '', 'F', '2008-02-02', '03554174067', '', 0.00, 1, 1, '2026-07-16 09:48:10', '4', NULL, NULL, NULL),
(790, 218, '2460560005', 'ABIDA', 'BATOOL', 'MUZAFFAR ALI', '', '', 'F', '2009-11-12', '03555764144', '', 0.00, 1, 1, '2026-07-16 09:48:10', '5', NULL, NULL, NULL),
(791, 219, '2560560098', 'NARGIS', 'IBRAHIM', 'IBRAHIM', '', '', 'F', '2008-01-10', '03554162145', '', 0.00, 1, 1, '2026-07-16 09:48:10', '6', NULL, NULL, NULL),
(792, 220, '2560560060', 'LOBA', 'Tufail', 'MUHAMMAD TUFAIL', '', '', 'F', '2007-01-01', '03555757071', '', 0.00, 1, 1, '2026-07-16 09:48:10', '7', NULL, NULL, NULL),
(793, 15, '2569280045', 'NUSRAT', 'HASSAN', 'HASSAN', '2569280045', '', 'F', '2008-08-25', '03554371724', '', 100.00, 1, 1, '2026-07-16 09:48:10', '8', NULL, NULL, NULL),
(795, 221, 'STU194', 'Batool', 'Ghulaam', 'Ghulam Nabi', '', '', 'F', NULL, '', '', 0.00, 1, 1, '2026-07-21 17:39:25', '1', NULL, NULL, NULL),
(796, 222, 'STU195', 'Jannat', 'Batool', 'Bahadur Ali', '', '', 'F', NULL, '', '', 0.00, 1, 1, '2026-07-21 17:40:22', '2', NULL, NULL, NULL),
(797, 223, 'STU196', 'Saira', 'Batool', 'Nasir Ali', '', '', 'F', NULL, '', '', 0.00, 1, 1, '2026-07-21 17:41:09', '3', NULL, NULL, NULL),
(798, 224, 'STU197', 'Najma', 'Abdullah', 'Abdullah', '', '', 'F', NULL, '', '', 0.00, 1, 1, '2026-07-21 17:41:58', '4', NULL, NULL, NULL),
(799, 225, 'STU198', 'Hamida', 'Batool', 'Qasim', '', '', 'F', NULL, '', '', 0.00, 1, 1, '2026-07-21 17:42:56', '5', NULL, NULL, NULL),
(800, 226, 'STU199', 'Aliya', 'Batool', 'Hassan', '', '', 'F', NULL, '', '', 0.00, 1, 1, '2026-07-21 17:43:44', '6', NULL, NULL, NULL),
(801, 227, 'STU200', 'Arifa', 'Batool', 'Hassan', '', '', 'F', NULL, '', '', 0.00, 1, 1, '2026-07-21 17:44:31', '7', NULL, NULL, NULL),
(804, 228, 'STU201', 'Nusrat', 'Batool', 'Ghulam Hassan', '', '', 'F', NULL, '', '', 0.00, 1, 1, '2026-07-21 17:47:22', '8', NULL, NULL, NULL),
(805, 229, 'STU202', 'Rashma', 'Batool', 'Ejaz Hussain', '', '', 'F', NULL, '', '', 0.00, 1, 1, '2026-07-21 17:48:22', '1', NULL, NULL, NULL),
(806, 230, 'STU203', 'Maryam', 'Batool', 'Muhammad Ali', '', '', 'F', NULL, '', '', 0.00, 1, 1, '2026-07-21 17:49:09', '2', NULL, NULL, NULL),
(807, 231, 'STU204', 'Saira', 'Batool', 'Ghulam Abbas', '', '', 'F', NULL, '', '', 0.00, 1, 1, '2026-07-21 17:49:42', '3', NULL, NULL, NULL),
(808, 232, 'STU205', 'Maryam', 'Batool', 'Ali cho', '', '', 'F', NULL, '', '', 0.00, 1, 1, '2026-07-21 17:50:23', '4', NULL, NULL, NULL),
(809, NULL, '746', 'Naila', 'Batool', 'Shabbir Hussain', '', '', 'F', NULL, '', 'Thaliya Bilamik', 0.00, 1, 1, '2026-08-11 10:20:12', '0', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student_class_assignments`
--

CREATE TABLE `student_class_assignments` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `class_section_id` int(11) NOT NULL,
  `assigned_at` datetime NOT NULL DEFAULT current_timestamp(),
  `assigned_by_user_id` int(11) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `roll_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_class_assignments`
--

INSERT INTO `student_class_assignments` (`id`, `student_id`, `class_section_id`, `assigned_at`, `assigned_by_user_id`, `note`, `roll_number`) VALUES
(189, 589, 13, '2026-07-03 07:29:01', 4, '', NULL),
(190, 590, 13, '2026-07-03 07:31:23', 4, '', NULL),
(191, 590, 16, '2026-07-03 07:33:38', 4, '', NULL),
(192, 589, 16, '2026-07-03 07:33:47', 4, '', NULL),
(194, 591, 1, '2026-07-13 05:51:07', 4, '', 1),
(195, 592, 1, '2026-07-13 05:52:32', 4, '', 2),
(198, 595, 1, '2026-07-13 06:22:51', 4, '', 3),
(199, 596, 1, '2026-07-13 06:22:51', 4, '', 4),
(200, 597, 1, '2026-07-13 06:22:51', 4, '', 5),
(201, 598, 1, '2026-07-13 06:22:51', 4, '', 6),
(202, 599, 1, '2026-07-13 06:22:51', 4, '', 7),
(203, 600, 1, '2026-07-13 06:22:51', 4, '', 8),
(205, 602, 1, '2026-07-13 06:22:51', 4, '', 10),
(206, 603, 1, '2026-07-13 06:22:51', 4, '', 11),
(207, 604, 1, '2026-07-13 06:22:51', 4, '', 12),
(208, 605, 1, '2026-07-13 06:22:51', 4, '', 13),
(209, 606, 1, '2026-07-13 06:22:51', 4, '', 14),
(210, 607, 1, '2026-07-13 06:22:51', 4, '', 15),
(211, 608, 1, '2026-07-13 06:22:51', 4, '', 16),
(212, 609, 1, '2026-07-13 06:22:51', 4, '', 17),
(213, 610, 1, '2026-07-13 06:22:51', 4, '', 18),
(214, 611, 2, '2026-07-13 06:22:51', 4, '', 1),
(215, 612, 2, '2026-07-13 06:22:51', 4, '', 2),
(216, 613, 2, '2026-07-13 06:22:51', 4, '', 3),
(217, 614, 2, '2026-07-13 06:22:51', 4, '', 4),
(218, 615, 2, '2026-07-13 06:22:51', 4, '', 5),
(219, 616, 2, '2026-07-13 06:22:51', 4, '', 6),
(220, 617, 2, '2026-07-13 06:22:51', 4, '', 7),
(221, 618, 2, '2026-07-13 06:22:51', 4, '', 8),
(222, 619, 2, '2026-07-13 06:22:51', 4, '', 9),
(223, 620, 2, '2026-07-13 06:22:51', 4, '', 10),
(224, 621, 2, '2026-07-13 06:22:51', 4, '', 11),
(225, 622, 2, '2026-07-13 06:22:51', 4, '', 12),
(226, 623, 2, '2026-07-13 06:22:51', 4, '', 13),
(228, 625, 2, '2026-07-13 06:22:51', 4, '', 15),
(229, 626, 2, '2026-07-13 06:22:51', 4, '', 16),
(230, 627, 3, '2026-07-13 06:22:51', 4, '', 1),
(231, 628, 3, '2026-07-13 06:22:51', 4, '', 2),
(232, 629, 3, '2026-07-13 06:22:51', 4, '', 3),
(233, 630, 3, '2026-07-13 06:22:51', 4, '', 4),
(234, 631, 3, '2026-07-13 06:22:51', 4, '', 5),
(235, 632, 3, '2026-07-13 06:22:51', 4, '', 6),
(236, 633, 3, '2026-07-13 06:22:51', 4, '', 7),
(237, 634, 3, '2026-07-13 06:22:51', 4, '', 8),
(238, 635, 3, '2026-07-13 06:22:51', 4, '', 9),
(239, 636, 3, '2026-07-13 06:22:51', 4, '', 10),
(240, 637, 3, '2026-07-13 06:22:51', 4, '', 11),
(241, 638, 3, '2026-07-13 06:22:51', 4, '', 12),
(242, 639, 3, '2026-07-13 06:22:51', 4, '', 13),
(243, 640, 3, '2026-07-13 06:22:51', 4, '', 14),
(244, 641, 3, '2026-07-13 06:22:51', 4, '', 15),
(245, 642, 3, '2026-07-13 06:22:51', 4, '', 16),
(246, 643, 3, '2026-07-13 06:22:51', 4, '', NULL),
(247, 644, 4, '2026-07-13 06:22:51', 4, '', 1),
(248, 645, 4, '2026-07-13 06:22:51', 4, '', 2),
(249, 646, 4, '2026-07-13 06:22:51', 4, '', 3),
(250, 647, 4, '2026-07-13 06:22:51', 4, '', 4),
(251, 648, 4, '2026-07-13 06:22:51', 4, '', 5),
(252, 649, 4, '2026-07-13 06:22:51', 4, '', 6),
(253, 650, 4, '2026-07-13 06:22:51', 4, '', 7),
(254, 651, 4, '2026-07-13 06:22:51', 4, '', 8),
(255, 652, 4, '2026-07-13 06:22:51', 4, '', 9),
(256, 653, 4, '2026-07-13 06:22:51', 4, '', 10),
(257, 654, 4, '2026-07-13 06:22:51', 4, '', 11),
(258, 655, 4, '2026-07-13 06:22:51', 4, '', 12),
(259, 656, 5, '2026-07-13 06:22:51', 4, '', 1),
(260, 657, 5, '2026-07-13 06:22:51', 4, '', 2),
(261, 658, 5, '2026-07-13 06:22:51', 4, '', 3),
(262, 659, 5, '2026-07-13 06:22:51', 4, '', 4),
(263, 660, 5, '2026-07-13 06:22:51', 4, '', 5),
(264, 661, 5, '2026-07-13 06:22:51', 4, '', 6),
(265, 662, 5, '2026-07-13 06:22:51', 4, '', 7),
(266, 663, 5, '2026-07-13 06:22:51', 4, '', 8),
(267, 664, 5, '2026-07-13 06:22:51', 4, '', 9),
(268, 665, 5, '2026-07-13 06:22:51', 4, '', 10),
(269, 666, 5, '2026-07-13 06:22:51', 4, '', 11),
(270, 667, 5, '2026-07-13 06:22:51', 4, '', 12),
(271, 668, 5, '2026-07-13 06:22:51', 4, '', 13),
(272, 669, 5, '2026-07-13 06:22:51', 4, '', 14),
(273, 670, 5, '2026-07-13 06:22:51', 4, '', 15),
(274, 671, 5, '2026-07-13 06:22:51', 4, '', 16),
(275, 672, 5, '2026-07-13 06:22:51', 4, '', 17),
(276, 673, 5, '2026-07-13 06:22:51', 4, '', 18),
(277, 674, 5, '2026-07-13 06:22:51', 4, '', 19),
(278, 675, 5, '2026-07-13 06:22:51', 4, '', 20),
(279, 676, 5, '2026-07-13 06:22:51', 4, '', 21),
(280, 677, 5, '2026-07-13 06:22:51', 4, '', 22),
(281, 678, 6, '2026-07-13 06:22:51', 4, '', 1),
(282, 679, 6, '2026-07-13 06:22:51', 4, '', 2),
(283, 680, 6, '2026-07-13 06:22:51', 4, '', 3),
(284, 681, 6, '2026-07-13 06:22:51', 4, '', 4),
(285, 682, 6, '2026-07-13 06:22:51', 4, '', 5),
(286, 683, 6, '2026-07-13 06:22:51', 4, '', 6),
(287, 684, 6, '2026-07-13 06:22:51', 4, '', 7),
(288, 685, 6, '2026-07-13 06:22:51', 4, '', 8),
(289, 686, 6, '2026-07-13 06:22:51', 4, '', 9),
(290, 687, 6, '2026-07-13 06:22:51', 4, '', 10),
(291, 688, 6, '2026-07-13 06:22:51', 4, '', 11),
(292, 689, 6, '2026-07-13 06:22:51', 4, '', 12),
(293, 690, 6, '2026-07-13 06:22:51', 4, '', 13),
(294, 691, 6, '2026-07-13 06:22:51', 4, '', 14),
(295, 692, 6, '2026-07-13 06:22:51', 4, '', 15),
(296, 693, 6, '2026-07-13 06:22:51', 4, '', 16),
(297, 694, 6, '2026-07-13 06:22:51', 4, '', 17),
(298, 695, 6, '2026-07-13 06:22:51', 4, '', 18),
(299, 696, 6, '2026-07-13 06:22:51', 4, '', 19),
(300, 697, 6, '2026-07-13 06:22:51', 4, '', 20),
(301, 698, 6, '2026-07-13 06:22:51', 4, '', 21),
(302, 699, 6, '2026-07-13 06:22:51', 4, '', 22),
(303, 700, 6, '2026-07-13 06:22:51', 4, '', 23),
(304, 701, 6, '2026-07-13 06:22:51', 4, '', 24),
(305, 702, 6, '2026-07-13 06:22:51', 4, '', 25),
(306, 703, 6, '2026-07-13 06:22:51', 4, '', 26),
(307, 704, 6, '2026-07-13 06:22:51', 4, '', 27),
(308, 705, 7, '2026-07-13 06:22:51', 4, '', 1),
(309, 706, 7, '2026-07-13 06:22:51', 4, '', 2),
(310, 707, 7, '2026-07-13 06:22:51', 4, '', 3),
(311, 708, 7, '2026-07-13 06:22:51', 4, '', 4),
(312, 709, 7, '2026-07-13 06:22:51', 4, '', 5),
(313, 710, 7, '2026-07-13 06:22:51', 4, '', 6),
(314, 711, 7, '2026-07-13 06:22:51', 4, '', 7),
(315, 712, 7, '2026-07-13 06:22:51', 4, '', 8),
(316, 713, 7, '2026-07-13 06:22:51', 4, '', 9),
(317, 714, 7, '2026-07-13 06:22:51', 4, '', 10),
(318, 715, 7, '2026-07-13 06:22:51', 4, '', 11),
(319, 716, 7, '2026-07-13 06:22:51', 4, '', 12),
(320, 717, 7, '2026-07-13 06:22:51', 4, '', 13),
(321, 718, 8, '2026-07-13 06:22:51', 4, '', 1),
(322, 719, 8, '2026-07-13 06:22:51', 4, '', 2),
(323, 720, 8, '2026-07-13 06:22:51', 4, '', 3),
(324, 721, 8, '2026-07-13 06:22:51', 4, '', 4),
(325, 722, 8, '2026-07-13 06:22:51', 4, '', 5),
(326, 723, 8, '2026-07-13 06:22:51', 4, '', 6),
(327, 724, 8, '2026-07-13 06:22:51', 4, '', 7),
(328, 725, 8, '2026-07-13 06:22:51', 4, '', 8),
(329, 726, 8, '2026-07-13 06:22:51', 4, '', 9),
(330, 727, 8, '2026-07-13 06:22:51', 4, '', 10),
(331, 728, 8, '2026-07-13 06:22:51', 4, '', 11),
(332, 729, 8, '2026-07-13 06:22:51', 4, '', 12),
(333, 730, 8, '2026-07-13 06:22:51', 4, '', 13),
(334, 731, 8, '2026-07-13 06:22:51', 4, '', 14),
(335, 732, 9, '2026-07-13 06:22:51', 4, '', 1),
(336, 733, 9, '2026-07-13 06:22:51', 4, '', 2),
(337, 734, 9, '2026-07-13 06:22:51', 4, '', 3),
(338, 735, 9, '2026-07-13 06:22:51', 4, '', 4),
(339, 736, 9, '2026-07-13 06:22:51', 4, '', 5),
(340, 737, 9, '2026-07-13 06:22:51', 4, '', 6),
(341, 738, 9, '2026-07-13 06:22:51', 4, '', 7),
(342, 739, 9, '2026-07-13 06:22:51', 4, '', 8),
(343, 740, 9, '2026-07-13 06:22:51', 4, '', 9),
(344, 741, 9, '2026-07-13 06:22:51', 4, '', 10),
(345, 742, 9, '2026-07-13 06:22:51', 4, '', 11),
(346, 743, 9, '2026-07-13 06:22:51', 4, '', 12),
(347, 744, 9, '2026-07-13 06:22:51', 4, '', 13),
(348, 745, 9, '2026-07-13 06:22:51', 4, '', 14),
(349, 746, 9, '2026-07-13 06:22:51', 4, '', 15),
(350, 747, 9, '2026-07-13 06:22:51', 4, '', 16),
(351, 748, 9, '2026-07-13 06:22:51', 4, '', 17),
(352, 749, 9, '2026-07-13 06:22:51', 4, '', 18),
(353, 750, 9, '2026-07-13 06:22:51', 4, '', 19),
(354, 751, 9, '2026-07-13 06:22:51', 4, '', 20),
(355, 752, 9, '2026-07-13 06:22:51', 4, '', 21),
(356, 753, 9, '2026-07-13 06:22:51', 4, '', 22),
(357, 754, 9, '2026-07-13 06:22:51', 4, '', 23),
(358, 755, 10, '2026-07-13 06:22:51', 4, '', 1),
(359, 756, 10, '2026-07-13 06:22:51', 4, '', 2),
(360, 757, 10, '2026-07-13 06:22:51', 4, '', 3),
(361, 758, 10, '2026-07-13 06:22:51', 4, '', 4),
(362, 759, 10, '2026-07-13 06:22:51', 4, '', 5),
(363, 760, 10, '2026-07-13 06:22:51', 4, '', NULL),
(364, 761, 10, '2026-07-13 06:22:51', 4, '', 7),
(365, 762, 10, '2026-07-13 06:22:51', 4, '', 8),
(366, 763, 10, '2026-07-13 06:22:51', 4, '', 9),
(367, 764, 10, '2026-07-13 06:22:51', 4, '', 10),
(368, 765, 10, '2026-07-13 06:22:51', 4, '', 11),
(369, 766, 10, '2026-07-13 06:22:51', 4, '', 12),
(370, 767, 10, '2026-07-13 06:22:51', 4, '', 13),
(371, 793, 15, '2026-07-16 09:53:29', 4, '', 8),
(372, 792, 15, '2026-07-16 09:55:50', 4, '', 7),
(373, 791, 15, '2026-07-16 09:56:54', 4, '', 6),
(374, 790, 15, '2026-07-16 09:57:24', 4, '', 5),
(375, 789, 15, '2026-07-16 09:57:51', 4, '', NULL),
(376, 789, 14, '2026-07-16 09:59:26', 4, '', NULL),
(377, 789, 15, '2026-07-16 09:59:33', 4, '', 4),
(378, 788, 15, '2026-07-16 10:00:53', 4, '', 3),
(379, 787, 15, '2026-07-16 10:01:36', 4, '', 2),
(380, 786, 15, '2026-07-16 10:02:16', 4, '', NULL),
(381, 785, 16, '2026-07-16 18:48:30', 4, '', 18),
(382, 784, 16, '2026-07-16 18:49:32', 4, '', 17),
(383, 782, 16, '2026-07-16 18:57:32', 4, '', 15),
(389, 780, 16, '2026-07-16 19:03:10', 4, '', 13),
(391, 779, 13, '2026-07-16 19:16:57', 4, '', 12),
(392, 778, 13, '2026-07-16 19:46:32', 4, '', 11),
(393, 777, 13, '2026-07-16 19:53:19', 4, '', 10),
(394, 776, 13, '2026-07-16 19:54:11', 4, '', 9),
(395, 775, 13, '2026-07-16 19:54:49', 4, '', 8),
(396, 774, 13, '2026-07-16 19:55:38', 4, '', 7),
(397, 773, 13, '2026-07-16 19:56:31', 4, '', 6),
(398, 772, 13, '2026-07-16 19:57:15', 4, '', 5),
(399, 771, 13, '2026-07-16 19:58:45', 4, '', 4),
(400, 770, 13, '2026-07-16 20:01:10', 4, '', 3),
(401, 769, 13, '2026-07-16 20:01:55', 4, '', 2),
(402, 768, 13, '2026-07-16 20:02:43', 4, '', 1),
(405, 795, 17, '2026-07-21 17:39:25', 4, '', 1),
(406, 796, 17, '2026-07-21 17:40:22', 4, '', 2),
(407, 797, 17, '2026-07-21 17:41:09', 4, '', 3),
(408, 798, 17, '2026-07-21 17:41:58', 4, '', 4),
(409, 799, 17, '2026-07-21 17:42:56', 4, '', 5),
(410, 800, 17, '2026-07-21 17:43:44', 4, '', 6),
(411, 801, 17, '2026-07-21 17:44:31', 4, '', 7),
(412, 804, 17, '2026-07-21 17:47:22', 4, '', 8),
(413, 805, 14, '2026-07-21 17:48:22', 4, '', 1),
(414, 806, 14, '2026-07-21 17:49:09', 4, '', 2),
(415, 807, 14, '2026-07-21 17:49:42', 4, '', 3),
(416, 808, 14, '2026-07-21 17:50:23', 4, '', 4),
(417, 643, 2, '2026-08-01 12:58:30', 261, '', 14),
(418, 590, 13, '2026-08-11 07:48:58', 261, '', NULL),
(419, 589, 13, '2026-08-11 07:49:22', 261, '', NULL),
(420, 589, 16, '2026-08-11 07:50:01', 261, '', 16),
(421, 590, 16, '2026-08-11 07:50:07', 261, '', 14),
(422, 809, 15, '2026-08-11 10:20:12', 20, '', 9);

-- --------------------------------------------------------

--
-- Table structure for table `student_guardians`
--

CREATE TABLE `student_guardians` (
  `student_id` int(11) NOT NULL,
  `guardian_id` int(11) NOT NULL,
  `is_primary` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_guardians`
--

INSERT INTO `student_guardians` (`student_id`, `guardian_id`, `is_primary`, `created_at`) VALUES
(589, 13, 1, '2026-07-03 07:29:01'),
(590, 14, 1, '2026-07-03 07:31:23'),
(591, 15, 0, '2026-07-13 05:51:07'),
(592, 16, 0, '2026-07-13 05:52:32'),
(597, 19, 1, '2026-07-19 04:34:50'),
(759, 20, 0, '2026-07-19 07:37:25'),
(789, 10, 0, '2026-07-16 09:58:54'),
(792, 18, 1, '2026-07-19 04:33:35'),
(793, 17, 0, '2026-07-17 11:48:19'),
(793, 21, 0, '2026-08-06 10:31:24');

-- --------------------------------------------------------

--
-- Table structure for table `student_promotions`
--

CREATE TABLE `student_promotions` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `from_class_section_id` int(11) NOT NULL,
  `to_class_section_id` int(11) NOT NULL,
  `promoted_at` datetime NOT NULL DEFAULT current_timestamp(),
  `promoted_by_user_id` int(11) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `subject_code` varchar(30) DEFAULT NULL,
  `subject_name` varchar(120) NOT NULL,
  `class_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `subject_code`, `subject_name`, `class_id`) VALUES
(23, 'Eng - 7th', 'English', 9),
(24, 'Sci - 6th', 'Science', 8),
(25, 'Eng - 5th', 'English', 7),
(26, 'Mth - 3rd', 'Mathematics', 5),
(27, 'Isl - 4th', 'Islamiat', 6),
(28, 'Math - 7th', 'Mathematics', 9),
(29, 'Math - Nursery', 'Mathematics', 1),
(30, 'Urdu - Prep', 'Urdu', 2),
(31, 'Math - 2nd', 'Mathematics', 4),
(32, 'Eng - 8th', 'English', 10),
(33, 'Isl - 5th', 'Islamiat', 7),
(34, 'Geo - 7th', 'Geography', 9),
(35, 'Geo - 6th', 'Geography', 8),
(36, 'Geo - 8th', 'Geography', 10),
(37, 'Math - 1st', 'Mathematics', 3),
(38, 'Sci - 5th', 'Science', 7),
(39, 'Eng - Nur', 'English', 1),
(40, 'Urdu - 6th', 'Urdu', 8),
(41, 'Sci - 4th', 'Science', 6),
(42, 'Isl - 8th', 'Islamiat', 10),
(43, 'Urdu - 5th', 'Urdu', 7),
(44, 'Urdu - 8th', 'Urdu', 10),
(45, 'Urdu - 2nd', 'Urdu', 4),
(46, 'Urdu - 1st', 'Urdu', 3),
(47, 'Urdu - Nur', 'Urdu', 1),
(48, 'Isl - 7th', 'Islamiat', 9),
(49, 'Urdu - 3rd', 'Urdu', 5),
(50, 'Eng - 6th', 'English', 8),
(51, 'Eng - 4th', 'English', 6),
(52, 'Isl - 3rd', 'Islamiat', 5),
(53, 'Eng - 3rd', 'English', 5),
(54, 'Urdu - 7th', 'Urdu', 9),
(55, 'G.K - 1st', 'General Knowledge', 3),
(56, 'S.st - 4th', 'Social Studies', 6),
(57, 'Eng - Prep', 'English', 2),
(58, 'Sci - 7th', 'Science', 9),
(59, 'Sci - 8th', 'Science', 10),
(60, 'Math - 5th', 'Mathematics', 7),
(61, 'Math - 4th', 'Mathematics', 6),
(62, 'G.K - 2nd', 'General Knowledge', 4),
(63, 'Isl - 1st', 'Islamiat', 3),
(64, 'S.st - 5th', 'Social Studies', 7),
(65, 'Eng - 2nd', 'English', 4),
(66, 'Math - 6th', 'Mathematics', 8),
(67, 'Eng - 1st', 'English', 3),
(68, 'Urdu - 4th', 'Urdu', 6),
(69, 'Math - Prep', 'Mathematics', 2),
(70, 'Isl - 6th', 'Islamiat', 8),
(71, 'Isl - 2nd', 'Islamiat', 4),
(72, 'G.K - 3rd', 'General Knowledge', 5),
(73, 'CIVICS-2nd Year Arts', 'Civics', 16),
(74, 'CIVICS-1st Year Arts', 'Civics', 15),
(75, 'Math-10th Science', 'Mathematics', 13),
(76, 'Phy-10th Science', 'Physics', 13),
(77, 'Phy-1st Year Science', 'Physics', 17),
(78, 'Che-10th Science', 'Chemistry', 13),
(79, 'Che-1st Year Science', 'Chemistry', 17),
(80, 'Math-10th Arts', 'Mathematics', 14),
(81, 'Eng Grammar-2nd Year Arts', 'English Grammar', 16),
(82, 'Math - 8th', 'Mathematics', 10),
(83, 'Isl comp-1st Year Arts', 'Islamiat comp', 15),
(84, 'Isl comp-10th Arts', 'Islamiat comp', 14),
(85, 'Isl comp-10th Science', 'Islamiat comp', 13),
(86, 'Isl comp-1st Year Science', 'Islamiat comp', 17),
(87, 'Urdu-10th Science', 'Urdu', 13),
(88, 'Urdu-10th Arts', 'Urdu', 14),
(89, 'urdu-2nd Year Arts', 'Urdu', 16),
(90, 'Edu-2nd Year Arts', 'EDUCTION', 16),
(91, 'Isl Opt-10th Arts', 'Islamiat', 14),
(92, 'Bio-10th Science', 'Biology', 13),
(93, 'Bio-1st Year Science', 'Biology', 17),
(94, 'Pak-2nd Year Arts', 'Pak Studies', 16),
(95, 'Eng-10th Science', 'English', 13),
(96, 'Urdu-1st Year Science', 'Urdu', 17),
(112, '1st year-Soc', 'Sociology', 15),
(113, '2nd year-Soc', 'Sociology', 16),
(114, 'Eng - Ist Year Science', 'English', 17),
(115, 'Eng - Ist Year Arts', 'English', 15),
(116, 'Eng - 2nd Year Arts', 'English', 16),
(117, 'Pak-10th Arts', 'Pak Studies', 14),
(118, 'Pak-10th Science', 'Pak Studies', 13),
(119, 'Urdu-1st Year Arts', 'Urdu', 15),
(120, 'Eng - 10th Arts', 'English', 14),
(121, 'Civics - 10th Arts', 'Civics', 14),
(122, 'Edu - 1st Year Arts', 'Education', 15),
(123, 'G.Science', 'General Science', 14);

-- --------------------------------------------------------

--
-- Table structure for table `timetable_entries`
--

CREATE TABLE `timetable_entries` (
  `id` int(11) NOT NULL,
  `class_section_id` int(11) NOT NULL,
  `day_of_week` tinyint(4) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `room` varchar(60) DEFAULT NULL,
  `created_by_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `timetable_entries`
--

INSERT INTO `timetable_entries` (`id`, `class_section_id`, `day_of_week`, `start_time`, `end_time`, `subject_id`, `teacher_id`, `room`, `created_by_user_id`, `created_at`, `updated_at`) VALUES
(5, 2, 1, '08:30:00', '09:00:00', 57, 13, NULL, 4, '2026-06-10 07:43:55', '2026-08-01 09:24:18'),
(6, 2, 1, '10:30:00', '11:00:00', 69, 12, NULL, 4, '2026-06-10 07:44:49', '2026-08-01 09:25:53'),
(7, 2, 1, '09:30:00', '10:00:00', 30, 7, NULL, 4, '2026-06-10 07:45:14', '2026-08-01 09:24:49'),
(9, 9, 1, '09:30:00', '10:00:00', 23, 9, NULL, 4, '2026-07-19 05:34:40', NULL),
(10, 9, 2, '09:30:00', '10:00:00', 23, 9, NULL, 4, '2026-07-19 05:34:40', NULL),
(11, 9, 3, '09:30:00', '10:00:00', 23, 9, NULL, 4, '2026-07-19 05:34:40', NULL),
(12, 9, 4, '09:30:00', '10:00:00', 23, 9, NULL, 4, '2026-07-19 05:34:40', NULL),
(13, 9, 5, '09:30:00', '10:00:00', 23, 9, NULL, 4, '2026-07-19 05:34:40', NULL),
(14, 9, 6, '09:30:00', '10:00:00', 23, 9, NULL, 4, '2026-07-19 05:34:40', NULL),
(15, 8, 1, '10:00:00', '10:30:00', 24, 9, NULL, 4, '2026-07-19 05:34:40', NULL),
(16, 8, 2, '10:00:00', '10:30:00', 24, 9, NULL, 4, '2026-07-19 05:34:40', NULL),
(17, 8, 3, '10:00:00', '10:30:00', 24, 9, NULL, 4, '2026-07-19 05:34:40', NULL),
(18, 8, 4, '10:00:00', '10:30:00', 24, 9, NULL, 4, '2026-07-19 05:34:40', NULL),
(19, 8, 5, '10:00:00', '10:30:00', 24, 9, NULL, 4, '2026-07-19 05:34:40', NULL),
(20, 8, 6, '10:00:00', '10:30:00', 24, 9, NULL, 4, '2026-07-19 05:34:40', NULL),
(21, 7, 1, '10:30:00', '11:00:00', 25, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(22, 7, 2, '10:30:00', '11:00:00', 25, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(23, 7, 3, '10:30:00', '11:00:00', 25, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(24, 7, 4, '10:30:00', '11:00:00', 25, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(25, 7, 5, '10:30:00', '11:00:00', 25, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(26, 7, 6, '10:30:00', '11:00:00', 25, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(27, 5, 1, '11:00:00', '11:30:00', 26, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(28, 5, 2, '11:00:00', '11:30:00', 26, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(29, 5, 3, '11:00:00', '11:30:00', 26, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(30, 5, 4, '11:00:00', '11:30:00', 26, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(31, 5, 5, '11:00:00', '11:30:00', 26, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(32, 5, 6, '11:00:00', '11:30:00', 26, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(33, 6, 1, '11:30:00', '12:00:00', 27, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(34, 6, 2, '11:30:00', '12:00:00', 27, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(35, 6, 3, '11:30:00', '12:00:00', 27, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(36, 6, 4, '11:30:00', '12:00:00', 27, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(37, 6, 5, '11:30:00', '12:00:00', 27, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(38, 6, 6, '11:30:00', '12:00:00', 27, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(39, 9, 1, '12:40:00', '13:10:00', 28, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(40, 9, 2, '12:40:00', '13:10:00', 28, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(41, 9, 3, '12:40:00', '13:10:00', 28, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(42, 9, 4, '12:40:00', '13:10:00', 28, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(43, 9, 5, '12:40:00', '13:10:00', 28, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(44, 9, 6, '12:40:00', '13:10:00', 28, 9, NULL, 4, '2026-07-19 05:46:15', NULL),
(45, 1, 1, '09:00:00', '09:30:00', 29, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(46, 1, 2, '09:00:00', '09:30:00', 29, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(47, 1, 3, '09:00:00', '09:30:00', 29, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(48, 1, 4, '09:00:00', '09:30:00', 29, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(49, 1, 5, '09:00:00', '09:30:00', 29, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(50, 1, 6, '09:00:00', '09:30:00', 29, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(51, 2, 2, '09:30:00', '10:00:00', 30, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(52, 2, 3, '09:30:00', '10:00:00', 30, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(53, 2, 4, '09:30:00', '10:00:00', 30, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(54, 2, 5, '09:30:00', '10:00:00', 30, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(55, 2, 6, '09:30:00', '10:00:00', 30, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(56, 4, 1, '10:00:00', '10:30:00', 31, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(57, 4, 2, '10:00:00', '10:30:00', 31, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(58, 4, 3, '10:00:00', '10:30:00', 31, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(59, 4, 4, '10:00:00', '10:30:00', 31, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(60, 4, 5, '10:00:00', '10:30:00', 31, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(61, 4, 6, '10:00:00', '10:30:00', 31, 7, NULL, 4, '2026-07-19 05:46:15', NULL),
(62, 10, 1, '10:30:00', '11:00:00', 32, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(63, 10, 2, '10:30:00', '11:00:00', 32, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(64, 10, 3, '10:30:00', '11:00:00', 32, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(65, 10, 4, '10:30:00', '11:00:00', 32, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(66, 10, 5, '10:30:00', '11:00:00', 32, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(67, 10, 6, '10:30:00', '11:00:00', 32, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(68, 7, 1, '11:00:00', '11:30:00', 33, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(69, 7, 2, '11:00:00', '11:30:00', 33, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(70, 7, 3, '11:00:00', '11:30:00', 33, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(71, 7, 4, '11:00:00', '11:30:00', 33, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(72, 7, 5, '11:00:00', '11:30:00', 33, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(73, 7, 6, '11:00:00', '11:30:00', 33, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(74, 9, 1, '11:30:00', '12:00:00', 34, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(75, 9, 2, '11:30:00', '12:00:00', 34, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(76, 9, 3, '11:30:00', '12:00:00', 34, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(77, 9, 4, '11:30:00', '12:00:00', 34, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(78, 9, 5, '11:30:00', '12:00:00', 34, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(79, 9, 6, '11:30:00', '12:00:00', 34, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(80, 8, 1, '12:40:00', '13:10:00', 35, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(81, 8, 2, '12:40:00', '13:10:00', 35, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(82, 8, 3, '12:40:00', '13:10:00', 35, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(83, 8, 4, '12:40:00', '13:10:00', 35, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(84, 8, 5, '12:40:00', '13:10:00', 35, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(85, 8, 6, '12:40:00', '13:10:00', 35, 7, NULL, 4, '2026-07-19 05:46:16', NULL),
(86, 10, 1, '08:30:00', '09:00:00', 36, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(87, 10, 2, '08:30:00', '09:00:00', 36, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(88, 10, 3, '08:30:00', '09:00:00', 36, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(89, 10, 4, '08:30:00', '09:00:00', 36, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(90, 10, 5, '08:30:00', '09:00:00', 36, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(91, 10, 6, '08:30:00', '09:00:00', 36, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(92, 3, 1, '09:00:00', '09:30:00', 37, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(93, 3, 2, '09:00:00', '09:30:00', 37, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(94, 3, 3, '09:00:00', '09:30:00', 37, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(95, 3, 4, '09:00:00', '09:30:00', 37, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(96, 3, 5, '09:00:00', '09:30:00', 37, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(97, 3, 6, '09:00:00', '09:30:00', 37, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(98, 7, 1, '09:30:00', '10:00:00', 38, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(99, 7, 2, '09:30:00', '10:00:00', 38, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(100, 7, 3, '09:30:00', '10:00:00', 38, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(101, 7, 4, '09:30:00', '10:00:00', 38, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(102, 7, 5, '09:30:00', '10:00:00', 38, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(103, 7, 6, '09:30:00', '10:00:00', 38, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(104, 1, 1, '10:00:00', '10:30:00', 39, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(105, 1, 2, '10:00:00', '10:30:00', 39, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(106, 1, 3, '10:00:00', '10:30:00', 39, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(107, 1, 4, '10:00:00', '10:30:00', 39, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(108, 1, 5, '10:00:00', '10:30:00', 39, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(109, 1, 6, '10:00:00', '10:30:00', 39, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(110, 8, 1, '10:30:00', '11:00:00', 40, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(111, 8, 2, '10:30:00', '11:00:00', 40, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(112, 8, 3, '10:30:00', '11:00:00', 40, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(113, 8, 4, '10:30:00', '11:00:00', 40, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(114, 8, 5, '10:30:00', '11:00:00', 40, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(115, 8, 6, '10:30:00', '11:00:00', 40, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(116, 6, 1, '11:00:00', '11:30:00', 41, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(117, 6, 2, '11:00:00', '11:30:00', 41, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(118, 6, 3, '11:00:00', '11:30:00', 41, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(119, 6, 4, '11:00:00', '11:30:00', 41, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(120, 6, 5, '11:00:00', '11:30:00', 41, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(121, 6, 6, '11:00:00', '11:30:00', 41, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(122, 10, 1, '12:40:00', '13:10:00', 42, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(123, 10, 2, '12:40:00', '13:10:00', 42, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(124, 10, 3, '12:40:00', '13:10:00', 42, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(125, 10, 4, '12:40:00', '13:10:00', 42, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(126, 10, 5, '12:40:00', '13:10:00', 42, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(127, 10, 6, '12:40:00', '13:10:00', 42, 10, NULL, 4, '2026-07-19 05:46:16', NULL),
(128, 7, 1, '08:30:00', '09:00:00', 43, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(129, 7, 2, '08:30:00', '09:00:00', 43, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(130, 7, 3, '08:30:00', '09:00:00', 43, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(131, 7, 4, '08:30:00', '09:00:00', 43, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(132, 7, 5, '08:30:00', '09:00:00', 43, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(133, 7, 6, '08:30:00', '09:00:00', 43, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(134, 10, 1, '09:00:00', '09:30:00', 44, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(135, 10, 2, '09:00:00', '09:30:00', 44, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(136, 10, 3, '09:00:00', '09:30:00', 44, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(137, 10, 4, '09:00:00', '09:30:00', 44, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(138, 10, 5, '09:00:00', '09:30:00', 44, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(139, 10, 6, '09:00:00', '09:30:00', 44, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(140, 4, 1, '09:30:00', '10:00:00', 45, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(141, 4, 2, '09:30:00', '10:00:00', 45, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(142, 4, 3, '09:30:00', '10:00:00', 45, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(143, 4, 4, '09:30:00', '10:00:00', 45, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(144, 4, 5, '09:30:00', '10:00:00', 45, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(145, 4, 6, '09:30:00', '10:00:00', 45, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(146, 3, 1, '10:00:00', '10:30:00', 46, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(147, 3, 2, '10:00:00', '10:30:00', 46, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(148, 3, 3, '10:00:00', '10:30:00', 46, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(149, 3, 4, '10:00:00', '10:30:00', 46, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(150, 3, 5, '10:00:00', '10:30:00', 46, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(151, 3, 6, '10:00:00', '10:30:00', 46, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(152, 1, 1, '10:30:00', '11:00:00', 47, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(153, 1, 2, '10:30:00', '11:00:00', 47, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(154, 1, 3, '10:30:00', '11:00:00', 47, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(155, 1, 4, '10:30:00', '11:00:00', 47, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(156, 1, 5, '10:30:00', '11:00:00', 47, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(157, 1, 6, '10:30:00', '11:00:00', 47, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(158, 9, 1, '11:00:00', '11:30:00', 48, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(159, 9, 2, '11:00:00', '11:30:00', 48, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(160, 9, 3, '11:00:00', '11:30:00', 48, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(161, 9, 4, '11:00:00', '11:30:00', 48, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(162, 9, 5, '11:00:00', '11:30:00', 48, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(163, 9, 6, '11:00:00', '11:30:00', 48, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(164, 5, 1, '11:30:00', '12:00:00', 49, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(165, 5, 2, '11:30:00', '12:00:00', 49, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(166, 5, 3, '11:30:00', '12:00:00', 49, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(167, 5, 4, '11:30:00', '12:00:00', 49, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(168, 5, 5, '11:30:00', '12:00:00', 49, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(169, 5, 6, '11:30:00', '12:00:00', 49, 11, NULL, 4, '2026-07-19 05:46:16', NULL),
(170, 8, 1, '08:30:00', '09:00:00', 50, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(171, 8, 2, '08:30:00', '09:00:00', 50, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(172, 8, 3, '08:30:00', '09:00:00', 50, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(173, 8, 4, '08:30:00', '09:00:00', 50, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(174, 8, 5, '08:30:00', '09:00:00', 50, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(175, 8, 6, '08:30:00', '09:00:00', 50, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(176, 6, 1, '09:00:00', '09:30:00', 51, 8, NULL, 4, '2026-07-19 05:46:16', '2026-07-27 17:39:39'),
(177, 6, 2, '09:00:00', '09:30:00', 51, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(178, 6, 3, '09:00:00', '09:30:00', 51, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(179, 6, 4, '09:00:00', '09:30:00', 51, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(180, 6, 5, '09:00:00', '09:30:00', 51, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(181, 6, 6, '09:00:00', '09:30:00', 51, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(182, 5, 1, '09:30:00', '10:00:00', 52, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(183, 5, 2, '09:30:00', '10:00:00', 52, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(184, 5, 3, '09:30:00', '10:00:00', 52, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(185, 5, 4, '09:30:00', '10:00:00', 52, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(186, 5, 5, '09:30:00', '10:00:00', 52, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(187, 5, 6, '09:30:00', '10:00:00', 52, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(188, 5, 1, '10:00:00', '10:30:00', 53, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(189, 5, 2, '10:00:00', '10:30:00', 53, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(190, 5, 3, '10:00:00', '10:30:00', 53, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(191, 5, 4, '10:00:00', '10:30:00', 53, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(192, 5, 5, '10:00:00', '10:30:00', 53, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(193, 5, 6, '10:00:00', '10:30:00', 53, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(194, 9, 1, '10:30:00', '11:00:00', 54, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(195, 9, 2, '10:30:00', '11:00:00', 54, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(196, 9, 3, '10:30:00', '11:00:00', 54, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(197, 9, 4, '10:30:00', '11:00:00', 54, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(198, 9, 5, '10:30:00', '11:00:00', 54, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(199, 9, 6, '10:30:00', '11:00:00', 54, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(200, 3, 1, '11:00:00', '11:30:00', 55, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(201, 3, 2, '11:00:00', '11:30:00', 55, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(202, 3, 3, '11:00:00', '11:30:00', 55, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(203, 3, 4, '11:00:00', '11:30:00', 55, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(204, 3, 5, '11:00:00', '11:30:00', 55, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(205, 3, 6, '11:00:00', '11:30:00', 55, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(206, 6, 1, '12:40:00', '13:10:00', 56, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(207, 6, 2, '12:40:00', '13:10:00', 56, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(208, 6, 3, '12:40:00', '13:10:00', 56, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(209, 6, 4, '12:40:00', '13:10:00', 56, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(210, 6, 5, '12:40:00', '13:10:00', 56, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(211, 6, 6, '12:40:00', '13:10:00', 56, 8, NULL, 4, '2026-07-19 05:46:16', NULL),
(212, 2, 2, '08:30:00', '09:00:00', 57, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(213, 2, 3, '08:30:00', '09:00:00', 57, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(214, 2, 4, '08:30:00', '09:00:00', 57, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(215, 2, 5, '08:30:00', '09:00:00', 57, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(216, 2, 6, '08:30:00', '09:00:00', 57, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(217, 9, 1, '09:00:00', '09:30:00', 58, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(218, 9, 2, '09:00:00', '09:30:00', 58, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(219, 9, 3, '09:00:00', '09:30:00', 58, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(220, 9, 4, '09:00:00', '09:30:00', 58, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(221, 9, 5, '09:00:00', '09:30:00', 58, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(222, 9, 6, '09:00:00', '09:30:00', 58, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(223, 10, 1, '09:30:00', '10:00:00', 59, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(224, 10, 2, '09:30:00', '10:00:00', 59, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(225, 10, 3, '09:30:00', '10:00:00', 59, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(226, 10, 4, '09:30:00', '10:00:00', 59, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(227, 10, 5, '09:30:00', '10:00:00', 59, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(228, 10, 6, '09:30:00', '10:00:00', 59, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(229, 7, 1, '10:00:00', '10:30:00', 60, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(230, 7, 2, '10:00:00', '10:30:00', 60, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(231, 7, 3, '10:00:00', '10:30:00', 60, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(232, 7, 4, '10:00:00', '10:30:00', 60, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(233, 7, 5, '10:00:00', '10:30:00', 60, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(234, 7, 6, '10:00:00', '10:30:00', 60, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(235, 6, 1, '10:30:00', '11:00:00', 61, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(236, 6, 2, '10:30:00', '11:00:00', 61, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(237, 6, 3, '10:30:00', '11:00:00', 61, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(238, 6, 4, '10:30:00', '11:00:00', 61, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(239, 6, 5, '10:30:00', '11:00:00', 61, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(240, 6, 6, '10:30:00', '11:00:00', 61, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(241, 4, 1, '11:00:00', '11:30:00', 62, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(242, 4, 2, '11:00:00', '11:30:00', 62, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(243, 4, 3, '11:00:00', '11:30:00', 62, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(244, 4, 4, '11:00:00', '11:30:00', 62, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(245, 4, 5, '11:00:00', '11:30:00', 62, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(246, 4, 6, '11:00:00', '11:30:00', 62, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(247, 3, 1, '11:30:00', '12:00:00', 63, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(248, 3, 2, '11:30:00', '12:00:00', 63, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(249, 3, 3, '11:30:00', '12:00:00', 63, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(250, 3, 4, '11:30:00', '12:00:00', 63, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(251, 3, 5, '11:30:00', '12:00:00', 63, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(252, 3, 6, '11:30:00', '12:00:00', 63, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(253, 7, 1, '12:40:00', '13:10:00', 64, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(254, 7, 2, '12:40:00', '13:10:00', 64, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(255, 7, 3, '12:40:00', '13:10:00', 64, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(256, 7, 4, '12:40:00', '13:10:00', 64, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(257, 7, 5, '12:40:00', '13:10:00', 64, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(258, 7, 6, '12:40:00', '13:10:00', 64, 13, NULL, 4, '2026-07-19 05:46:16', NULL),
(259, 4, 1, '08:30:00', '09:00:00', 65, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:29:16'),
(260, 4, 2, '08:30:00', '09:00:00', 65, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(261, 4, 3, '08:30:00', '09:00:00', 65, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(262, 4, 4, '08:30:00', '09:00:00', 65, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(263, 4, 5, '08:30:00', '09:00:00', 65, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(264, 4, 6, '08:30:00', '09:00:00', 65, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(265, 8, 1, '09:00:00', '09:30:00', 66, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:30:02'),
(266, 8, 2, '09:00:00', '09:30:00', 66, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(267, 8, 3, '09:00:00', '09:30:00', 66, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(268, 8, 4, '09:00:00', '09:30:00', 66, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(269, 8, 5, '09:00:00', '09:30:00', 66, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(270, 8, 6, '09:00:00', '09:30:00', 66, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(271, 3, 1, '09:30:00', '10:00:00', 67, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:27:52'),
(272, 3, 2, '09:30:00', '10:00:00', 67, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:27:59'),
(273, 3, 3, '09:30:00', '10:00:00', 67, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:28:05'),
(274, 3, 4, '09:30:00', '10:00:00', 67, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:28:11'),
(275, 3, 5, '09:30:00', '10:00:00', 67, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:28:17'),
(276, 3, 6, '09:30:00', '10:00:00', 67, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:28:23'),
(277, 6, 1, '10:00:00', '10:30:00', 68, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:29:41'),
(278, 6, 2, '10:00:00', '10:30:00', 68, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(279, 6, 3, '10:00:00', '10:30:00', 68, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(280, 6, 4, '10:00:00', '10:30:00', 68, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(281, 6, 5, '10:00:00', '10:30:00', 68, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(282, 6, 6, '10:00:00', '10:30:00', 68, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(284, 2, 2, '10:30:00', '11:00:00', 69, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:26:25'),
(285, 2, 3, '10:30:00', '11:00:00', 69, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:26:40'),
(286, 2, 4, '10:30:00', '11:00:00', 69, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:26:48'),
(287, 2, 5, '10:30:00', '11:00:00', 69, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:26:55'),
(288, 2, 6, '10:30:00', '11:00:00', 69, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:27:12'),
(289, 8, 1, '11:00:00', '11:30:00', 70, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:30:07'),
(290, 8, 2, '11:00:00', '11:30:00', 70, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(291, 8, 3, '11:00:00', '11:30:00', 70, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(292, 8, 4, '11:00:00', '11:30:00', 70, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(293, 8, 5, '11:00:00', '11:30:00', 70, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(294, 8, 6, '11:00:00', '11:30:00', 70, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(295, 4, 1, '11:30:00', '12:00:00', 71, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:28:40'),
(296, 4, 2, '11:30:00', '12:00:00', 71, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(297, 4, 3, '11:30:00', '12:00:00', 71, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(298, 4, 4, '11:30:00', '12:00:00', 71, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(299, 4, 5, '11:30:00', '12:00:00', 71, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(300, 4, 6, '11:30:00', '12:00:00', 71, NULL, NULL, 4, '2026-07-19 05:46:16', NULL),
(301, 5, 1, '12:40:00', '13:10:00', 72, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:17:11'),
(302, 5, 2, '12:40:00', '13:10:00', 72, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:17:18'),
(303, 5, 3, '12:40:00', '13:10:00', 72, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:17:25'),
(304, 5, 4, '12:40:00', '13:10:00', 72, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:17:32'),
(305, 5, 5, '12:40:00', '13:10:00', 72, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:17:38'),
(306, 5, 6, '12:40:00', '13:10:00', 72, 12, NULL, 4, '2026-07-19 05:46:16', '2026-08-01 09:17:44'),
(308, 17, 1, '14:00:00', '14:30:00', 96, 7, NULL, 20, '2026-08-11 08:49:05', NULL),
(309, 14, 1, '14:30:00', '15:00:00', 112, 7, NULL, 20, '2026-08-11 08:49:58', NULL),
(310, 15, 1, '15:00:00', '15:30:00', 113, 7, NULL, 20, '2026-08-11 08:50:39', NULL),
(311, 13, 1, '15:30:00', '16:00:00', 95, 7, NULL, 20, '2026-08-11 08:51:22', NULL),
(312, 16, 1, '15:30:00', '16:00:00', 120, 7, NULL, 20, '2026-08-11 08:52:11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `failed_attempts` int(11) NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `role_id`, `status`, `created_at`, `updated_at`, `failed_attempts`, `locked_until`) VALUES
(4, 'admin', 'mubashirbaltistani1@gmail.com', '$2y$10$QVUvRzbhWInnC8Imbq8YQ.KBFFRGks52c0CwtGEhsyYT6hdorGAWS', 1, 1, '2026-03-28 17:45:42', NULL, 0, NULL),
(6, 'Hassan', 'hassansadiq669@gmail.com', '$2y$10$jJvemqa5/.Sk1SD.9651yOhdUkdz78no6aT4AHvRmyLYD7RdSjqaO', 2, 1, '2026-03-31 06:10:42', NULL, 0, NULL),
(7, 'Hussaini', 'hmeer7019@gmail.com', '$2y$10$JcVo6wdajLTkLzGN5xtSauFus48jBdomqJ3JYnTlJV0UsOKfzB0ey', 2, 1, '2026-03-31 07:45:26', NULL, 0, NULL),
(15, 'nusrat', NULL, '$2y$10$zrfHWWxxXsiGjkpIrE9/IO6UJdmB2bp2YNp8LtzrnWo6zhBAMggky', 3, 1, '2026-07-18 17:25:37', NULL, 0, NULL),
(18, 'tasneem', NULL, '$2y$10$N/rTriUgd13HRhJ5y6kuf.qKAsy/0jGTWpK5ifgVjZK6pPDq5jkpK', 3, 1, '2026-07-19 07:39:04', NULL, 0, NULL),
(20, 'Hassanad', NULL, '$2y$10$uhWDKVCOxd4hFLYLMESm.OW51k4fHhrc9D88NbQLq.cSmFefLa4dq', 1, 1, '2026-07-21 14:28:15', NULL, 0, NULL),
(21, 'G.Abbas', NULL, '$2y$10$TuksPkIbFu1CSySA7kVDpukQSqUZ6Gpix/mSe5t3bTf5W.PxZNN7q', 2, 1, '2026-07-21 15:08:18', NULL, 0, NULL),
(22, '645', NULL, '$2y$10$fQRQNGiB4V6/HCtfnpzVCu77ExkvVEAhavmKHEDZXYT/Grlj6TxiG', 3, 1, '2026-07-23 10:05:10', NULL, 0, NULL),
(23, '692', NULL, '$2y$10$1Wb/QanrYx4EsJ3hl4JjRO9CFrxw5sOLv6EdXLlQvFCBrm0hzAtFa', 3, 1, '2026-07-23 10:05:10', NULL, 0, NULL),
(24, 'stushehriyar', NULL, '$2y$10$3WQD1QwFzUWVVU1G/SX.peJHtx4qKAKIhLHH3CNtTWyw8PF7SZyXu', 3, 1, '2026-07-23 10:05:10', NULL, 0, NULL),
(25, 'stunoureen', NULL, '$2y$10$3Bshj1A5EMeDVSF8at37tOCGQVFVGvFzIDPvbavYaYpeVn0wBrHtu', 3, 1, '2026-07-23 10:05:10', NULL, 0, NULL),
(26, 'stu003', NULL, '$2y$10$nKfxmz6n0zW5zmAIY0JlKeZA1lrsQA4hZdG7JDVM0w72fsDS9u90G', 3, 1, '2026-07-23 10:05:10', NULL, 0, NULL),
(27, 'stu004', NULL, '$2y$10$n9MJsOO/LRJvmNeN6FPt0.pkUciwk2KWmyUyuKcOQRF/FStVpH1GC', 3, 1, '2026-07-23 10:05:10', NULL, 0, NULL),
(28, 'Muez', NULL, '$2y$10$dTTkQS2gGDuIClW2vj/JTe3N5Ip3v8SHx0Zpx8iCrPnItyjqcSHxa', 3, 1, '2026-07-23 10:05:10', NULL, 0, NULL),
(29, 'stu006', NULL, '$2y$10$whjD/2sjkv2fVfnNqyJPnuydFstjX2aTmWRgvud0y2qvH2d8pFbPa', 3, 1, '2026-07-23 10:05:10', NULL, 0, NULL),
(30, 'stu007', NULL, '$2y$10$OAGTRHalrCHHjJudSsD6B.KwVi.RBu1U5IW79wG8KJX4/z1akjrmK', 3, 1, '2026-07-23 10:05:10', NULL, 0, NULL),
(31, 'stu008', NULL, '$2y$10$qE1w18XyBfjEzm9qvVzU8e2quSJaGCBcAoG9VR7hEpH/6nRFZHQue', 3, 1, '2026-07-23 10:05:10', NULL, 0, NULL),
(32, 'stu009', NULL, '$2y$10$27ia7vFuOai9Z7KOn.UDKOwDFBjOm0.b6arMEA1yylShvMazndluq', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(33, 'stu010', NULL, '$2y$10$39MwgDU54DlWyEjuSh/DZuShz.Y8lyVZ27kuiSlTEi0SHkK7wq3DW', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(34, 'stu011', NULL, '$2y$10$GvR9lbvLSnDk6Ey0etBG2uR.mhoKm/xYj4AGTQxIL8Qufe8aa0dMq', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(35, 'stu012', NULL, '$2y$10$ouZ6uUoo5MomKhuCSArsg.b9P7Zlt9SGUixDWkEvIZJbBjSYqiFoe', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(36, 'stu013', NULL, '$2y$10$M4kHtZSVTKSCC396FKp.teIqfqJ0qa/CSgYmdkqhUMLkjBLSlA/vi', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(37, 'stu014', NULL, '$2y$10$wrKgFiCskSEsbJLfRkMyPOlgVNH8W5DbDI1MlWw03E3QVFHFJiT/W', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(38, 'stu015', NULL, '$2y$10$YzDnMvsJ22l8FiuGbPnyM.vhUB6Hl7PDts8ald42q/hnokp.Zrj9W', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(39, 'stu016', NULL, '$2y$10$HkjvdiI.qV8XWRo68WJOgOthVgNqQD44pOkGKm7MZWRipd/FJF9De', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(40, 'stu017', NULL, '$2y$10$IsOLTwrlOeWkIqD.R7WABeOBlehH.FQXOPk8K.WosHo/FBG3vZZgm', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(41, 'stu018', NULL, '$2y$10$U0xA8NIb3w.Dr9j74BIiPuL2Ylwy82J2fjO9xTyhKcHrdMtWrTweS', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(42, 'stu019', NULL, '$2y$10$P.M00usNBTHiAS.yaeSNGuihSmBm5PO30fwLUf4iAu8LDyoH15VD2', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(43, 'stu020', NULL, '$2y$10$axhnkaAzeS7FtmDKVs6EgehkPL8FtsNKzPr/z6pmX4vdBrUh4wA/e', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(44, 'stu021', NULL, '$2y$10$57PGTIJ9HhtsaYrsPUV7j.wpy22ZYiM3ODY.Aq93VuBmph/D25gDq', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(45, 'stu022', NULL, '$2y$10$RUKdAfSzZJWI78TCPy8ogOe.NZBjmDP.rDiL4nuaohS4mYIfTyrmi', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(46, 'stu023', NULL, '$2y$10$axZeRhT0S0P/vz42fiGzrOkXm4qh1M5pQfJy4gmDJFbFeBXXLyIXu', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(47, 'stu024', NULL, '$2y$10$3RRSE3Cw6psmKKuNhNA2g.Ah86wLhrIvAXEGrYt5pysC450fwGCOO', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(48, 'stu025', NULL, '$2y$10$5nFd.GbgJ9jvKH7mUheBUuHDqWP1Ghj4FD3dJ419KzBPzOgr02eGq', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(49, 'stu026', NULL, '$2y$10$NSbuEPoGuqay.ewbb./sIOrhvtZTPOrVgwNYslI9lCmJqNa.LV.CW', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(50, 'stu027', NULL, '$2y$10$CUFs5N5E4ZAyOT8HO2wMCuFCDMtnGLL6f1WOVR2K9W1pKI.sjJ4EG', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(51, 'stu028', NULL, '$2y$10$4z6aPNFsxrLa8SkC9s3gz.ja5dfDs4yEb/RUDTAlbaoxSYB.NmoEC', 3, 1, '2026-07-23 10:05:11', NULL, 0, NULL),
(52, 'stu029', NULL, '$2y$10$JxVoowqmB3ywVnMU9wPwBOVgpwFN6TJa8zvFgrkLZC4hZAlEX2eyS', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(53, 'stu030', NULL, '$2y$10$H4NCXSd8AsF2wJf6DwRKp.EU02wnTgSkwYbWAB1LrOlWrtDB64sQ.', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(54, 'stu031', NULL, '$2y$10$vpMXapyZa.ygj1MzhxAiLecZnpdneek.ApX1QL9KzOYSbe5eIw/vu', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(55, 'stu032', NULL, '$2y$10$8y20nSYdjuFxTZZ/lgZhd.Aa.aZeaxgDQTGQuPhloOaHMacKnzTMa', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(56, 'stu033', NULL, '$2y$10$PMeEGOAxoQoI5ZbE1Vqg3eJdJty7WyZ8ATvMFmreTasuS11fEpN.G', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(57, 'stu034', NULL, '$2y$10$5ggiTP7EQSRIZT2NgazRXOrbRHgRqrW.yhdYdqCWOFrzKysyepi..', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(58, 'stu035', NULL, '$2y$10$n0z7RAjqaLnU5tjJCKY6M.ldxGolPOvwppNiWZDjuvCkvLD5c6muC', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(59, 'stu036', NULL, '$2y$10$w6MFgypRAUDknaQ93ZtqB.ektTD69fb18R0franARfV/CIX4/x.US', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(60, 'stu037', NULL, '$2y$10$aE6PJkFFGpSR673SZYtIdOQiVr5kqNINs2iWaGCO3q/vRgoc08M1m', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(61, 'stu038', NULL, '$2y$10$9pnyG5g4u.75r/z3BE/ar.BgB9D7W5/o4xlRUeodBCl.Bn1OxYbW2', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(62, 'stu039', NULL, '$2y$10$YDJp1EYZSwvgI3uKSiv8b.6waYgNKiZw3vALaQIaxNxi7rmIxdy2O', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(63, 'stu040', NULL, '$2y$10$rCsZnHhOWEXnqsfSPg5WM.Ch1qUfSZh.1PkdYtcwaV.6/KqIM9l7C', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(64, 'stu041', NULL, '$2y$10$WzxVjmJ3Ist5eRNznHteuOoIzXsVTGy6EBnfEbJcQcdzkqN7B1T5y', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(65, 'stu042', NULL, '$2y$10$bG8iDqeim62Jv.kM6Y7zxOovdZWcCH.V6sqT1eS082/nFLIszODXa', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(66, 'stu043', NULL, '$2y$10$pc8W50hfW1CaPLYNEM3XQegfB4l1HCQIlPwdkDP60/KBbojA3ltxO', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(67, 'stu044', NULL, '$2y$10$ZX8kq3ZgJF5oHswSpMZzrOMKTMdP6fLa2hi6K6bSNvQ.RpX32Qree', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(68, 'stu045', NULL, '$2y$10$d/blOURcl.yA2gtyUv8G7uUZNxuFFfx.3u8h5lGKBm0Qt6y36eUAu', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(69, 'stu046', NULL, '$2y$10$qyeVrS.OOFKXqni8sq/v9OILPG4rGbyyw1wp2mb7IHeOEV44SqA.a', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(70, 'stu047', NULL, '$2y$10$/Z28QV6WkbHYjgR9JFdU6.2/z1DBztGiC3DwKrwQ3vuh2qO.M5Go.', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(71, 'sirtajnasrullah', NULL, '$2y$10$tpJ32Z3sfxbtkQE8BJY7J.Syqf8sgSh5Ti/IufzI5M/D.91dg3g0C', 3, 1, '2026-07-23 10:05:12', NULL, 0, NULL),
(72, 'stu049', NULL, '$2y$10$qqaOJ0RR8LbYTSQ8sAkazuO1jkMaV3LBHd12eV6CjiEbztTssDDbK', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(73, 'stu050', NULL, '$2y$10$mr0BRKIFebci7YzoqLfHKOt5qtnh3esVSDzQlvLvgWNR3IHyTnADC', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(74, 'stu051', NULL, '$2y$10$1ktze/E79xVmpEGz/nz45e7JNH9BCSG22dG/aLdzgMCHW/jVW7kGi', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(75, 'stu052', NULL, '$2y$10$VrIsluPD54YwerowD5DDaOHWv6rg3TpslBN8WC8HToRuRdJJr1u.O', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(76, 'stu053', NULL, '$2y$10$qJI1SEWrmcCw8.Tne/cZRuWjPc3BzbI09646hyY8sbMYu6gkMIy8y', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(77, 'stu054', NULL, '$2y$10$XA2ANIrtAwt2kuP.Ual9T.zX76lXDbv31u12czf7LpOmbhJdISBX2', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(78, 'stu055', NULL, '$2y$10$q8.2WOYkzSrF.EqBbhzqeOgTGxsuhTuI1acN7Abu45k1EWaEKr7ze', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(79, 'stu056', NULL, '$2y$10$yT.P74SKYKvHxRqlsvBplud5GcUyQhvQ5OLSq/GL8KZ8umOiKlPGS', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(80, 'stu057', NULL, '$2y$10$9sFH1Ou/7KYAuT2BHVbTbONbhpb1Krjtyin7vyx3MSk96z/mqcnO6', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(81, 'stu058', NULL, '$2y$10$uX1GvKUEQ2tFV/GEdt27KuBRcwywYpffrNg468A8e.SBrUeND8b4O', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(82, 'stu059', NULL, '$2y$10$ljVBo46Q5CjeQSMCYa3R7uaS0wV/OKHDIZaPo4iaCsf4uJquqJnau', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(83, 'stu060', NULL, '$2y$10$F6mnGX50XCActlzk8577Q..EcQS9VlRKq2tBOxP3yt9DmHo9q5UJ.', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(84, 'stu061', NULL, '$2y$10$m84Dnxf1Y9ZKFdjdW7zP4OVl3spJdDZm4Xl.WA7Y4bC9tL6jWWVJS', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(85, 'stu062', NULL, '$2y$10$01qxv2htZSRzErCQorPafO4m/Lc0xY8erC9eS7.FN6ho.nVEBvzp6', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(86, 'stu063', NULL, '$2y$10$DznpEwmGBifazt4yJmt2SOlVlgCq9qH5ak8SD6g5rQBIjkR2kk8rK', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(87, 'stu064', NULL, '$2y$10$uP5drwfKT0xGce/9SflLO.mmo3b8OWsMSxLLH.rei/aJ5bCMEzLs2', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(88, 'stu065', NULL, '$2y$10$XBxpztx/P4Js5JCPMgO99uLvCEDMMaEERZou1WjOHSRogh6B.OP9e', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(89, 'stu066', NULL, '$2y$10$TV9LD0HtMGS0PT7gOX4Ymu6pbA8nd4lTRBe7k2FeQ.TBZZME9lsuu', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(90, 'stu067', NULL, '$2y$10$9Wd5aAco/Hrd/daBFeIEROwouEpaVs..0nQaD6z2IHTMLGxGFaJ3C', 3, 1, '2026-07-23 10:05:13', NULL, 0, NULL),
(91, 'stu068', NULL, '$2y$10$I37OkYkZT8NF2BxVnrQtaejPlriHH5ENuQlWeODiNI.l8uOg3PIvO', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(92, 'stu069', NULL, '$2y$10$6EwFuIb1/dIq4K9dgyBeoOGVSXQ57boEY/kz4Lbh86JQEHssEQomq', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(93, 'stu070', NULL, '$2y$10$N6JU2AwCBgNPCsUXVysp0OoVVpKl9kZryPorJcF21gDhyACxwxkeS', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(94, 'stu071', NULL, '$2y$10$hJxOFAWF0lB5vvwUJr8RseYNPXfPJ8Aa/S3DYznTh5pbrkRWs2y0y', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(95, 'stu072', NULL, '$2y$10$2JAVSq5iPh3XXOkGAMlb3OJ6Bml/WkNCHhv1fk2ZylT6iRbcJlg1W', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(96, 'stu073', NULL, '$2y$10$Qby8qGIXabm406LWhTEZ7eNuikpv0.7M1e764wXvc2UjZcHcR2vMW', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(97, 'stu074', NULL, '$2y$10$DQr.Byr5FNn6f/bEU9BWuOrM13.497XFP2nO/4YcWBZOeycGyyXcm', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(98, 'stu075', NULL, '$2y$10$8rTbjPIJPAgozpdFp7lzkezoNrS4dBf4Zec839jfNXJra.eiOukey', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(99, 'stu076', NULL, '$2y$10$vPb3yDXDBZhWzChiDQjqvud0xMwBxgJymEcCODa8kKCvX6mY7WUMe', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(100, 'stu077', NULL, '$2y$10$IDdEKHTlBrdpx1XOIvvrbOonNMAriVX2D.jRKK5.NU8g3Gl6IEdvO', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(101, 'stu078', NULL, '$2y$10$BuKKKpzNq5NigrQecdsvwuhjDqEnOuLMXD2XmrTUq.cn6/kAZvpha', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(102, 'stu079', NULL, '$2y$10$Runpte4y3Cp5Ywx9Cb62PevmuU.unL8G0Sr8rzfmqUKYUNjMjiCFe', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(103, 'stu080', NULL, '$2y$10$4suNa9Ymn3n9/sSEnkHcxu47eHKgKy6GInGuhcOeSmXnoL2hjWeTe', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(104, 'stu081', NULL, '$2y$10$sf08fhs9mLg750nIHoyVdez2eQs3sy9J/sV2IEoFvdary4N.6DFRm', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(105, 'stu082', NULL, '$2y$10$LmaBI0BeCfWfaWT.POGKbunWsy9JBKUHTJCRjf6GvA/G7m3/LYA1K', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(106, 'stu083', NULL, '$2y$10$jHKTDN2/EhmIb/gYaBvwaubCr8JYPzG3byy0pnwPKUwCVMRdw7B9W', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(107, 'stu084', NULL, '$2y$10$619t0wdPuWgX2lGbULnnke5WXCCPpQOqnbMba1JXVwpnKKYuQXMPS', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(108, 'stu085', NULL, '$2y$10$FuLSHS3ay31JU2vzTI0sgO9FIP38i7Qy94TnEFi8IA/6uKC0IbcpO', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(109, 'stu086', NULL, '$2y$10$mDsNQgiuI.C7Rq/.DBNyW.4DI6Y773TUOMSrpC08BjlTIO.c5yIVm', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(110, 'stu087', NULL, '$2y$10$YFOEB876b2L.j4z8S/U8oOf7tE/pmcFp7iq9/MgGzxAch8LIFt7JO', 3, 1, '2026-07-23 10:05:14', NULL, 0, NULL),
(111, 'stu088', NULL, '$2y$10$zriypsf8EAZdnL56OGnJ7.l7HSZYzzvi0XW5wVd4m6JemptQCDnFC', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(112, 'stu089', NULL, '$2y$10$QaT5yxsyHc9NfgPOauFtfOPjBLvOd7LeBHMGzPA73Kzer1kRgshCi', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(113, 'stu090', NULL, '$2y$10$T1azadEDVxOn3tfDEeRIQ.wPjKcVVenCVSw/TLDtH1zRW7zVVOcVG', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(114, 'stu091', NULL, '$2y$10$f13./qBXcoBizMKN60yyi.deQj3.RohwlccgGhmr/rYNXeEih1kAG', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(115, 'stu092', NULL, '$2y$10$O5jalCG57bwTYVdlIFl2oOd38c.SR0l8RGmm8qjNdoftPoW4ZZAuW', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(116, 'stu093', NULL, '$2y$10$TQfu1nrWD8Nk9TBllSbx5uk.3v.S2CamGQnggOjbnOTbd.Tmylwme', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(117, 'stu094', NULL, '$2y$10$F5j6U/WjhFOTJsxNXovqzOjI4J58K/16RYXIfXzB.0XgNcnz7hUH2', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(118, 'stu095', NULL, '$2y$10$XxKbS4tJv/GgiUu7a7FQwei8kuoLGbmepEL2omd7ojnD2sBqWXQVa', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(119, 'stu096', NULL, '$2y$10$sQD1NLE6S8xSCf4Wcu6LleWnFi48g9/lZthrCmlW/0EoT6TkoO.QK', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(120, 'stu097', NULL, '$2y$10$7s.3TnV1HwPL.g311EEjtOOEH4ZZRUMTZ4A99eHKdwN2HyIQCje8.', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(121, 'stu098', NULL, '$2y$10$G2OZB29d6A7qpFciBdxaLOFIGhgNFVZhsMuquZL6zJ89r5s8KpzG6', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(122, 'stu099', NULL, '$2y$10$69MxxQ3SzwgAgW1RnfEXoO/lxAwp4X9bvIzfe4zM4JnUnR2rjlwX.', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(123, 'stu100', NULL, '$2y$10$.XvozXyuvUeI5gFsNYf//eFggcKixeFBSrBLQeQPC7M9PqZ9kKRoG', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(124, 'stu101', NULL, '$2y$10$P.E28Zl8nOuDCUH7Z7FdtO1SMZ1o3dHluf7hdzyE9sN1JfyBizQlS', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(125, 'stu102', NULL, '$2y$10$o8JZu7CfZzFEocmKzswYe.Vme9VI/MNftBe9JbtmlSHTShmHqitRm', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(126, 'stu103', NULL, '$2y$10$5cNaHFR1uZVY42vQ/HGJxueD3WqVUZK3eSc6IZECdGc56N3fi6L0K', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(127, 'stu104', NULL, '$2y$10$H2ND45oS43dpBStLLY57w.j75uybQ8TOGbM9sJFltm98RJTkp.Zgq', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(128, 'stu105', NULL, '$2y$10$qKSQwwKLUvaEuF/hAv2M0.o4lSPud0COzICcUr6AWo9EtXNUFJcY6', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(129, 'stu106', NULL, '$2y$10$8YcWEiXRyInQ8FApz3Wg9uAg4zWlW5x8csNIqTuxaeTQSp9QqKUvK', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(130, 'stu107', NULL, '$2y$10$EanW0u9Abn6PqlZ.77a.BO5.9IKlAQBkz10uTttA28SP7r1qBFH7i', 3, 1, '2026-07-23 10:05:15', NULL, 0, NULL),
(131, 'stu108', NULL, '$2y$10$d4q76RaddN6QaLYHOHyiQuR8RQ64ntkLAsOnaZXkvHJURe2izwCKy', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(132, 'stu109', NULL, '$2y$10$OwWl/MeOhrBYz0ynaWtLxOZawTQ3Y5O12nFKMcESUXDkVb7TlpNqu', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(133, 'stu110', NULL, '$2y$10$nijpjFCF/d492uTgfi9yWemk5zw.hZQYJjzbX6JoEMywP9GxXy3du', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(134, 'stu111', NULL, '$2y$10$SNpNzw.tp5ys8mufokeAM.VNc8pHqn5S9neYkYYFtuXrC0stJ/l4.', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(135, 'stu112', NULL, '$2y$10$3Wc6brBnrTOr6YfuwldjQuSRleDUxs3WxV93g2fZBEn.nILRFBUBq', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(136, 'stu113', NULL, '$2y$10$ZnVlZHY/zMEgoByMdB9CDOYgXrg1UKPO2p5w4421QSdNpUuQaus02', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(137, 'stu114', NULL, '$2y$10$gQoioklhRB75zVhOtYBuXu2uIw/mDx46tlJ8m4usF/7rGO7C1/G0q', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(138, 'stu115', NULL, '$2y$10$eo3ZpfjGv3bFmvyaVw47Hu9SqR6gpALsFdIXpjvdrjzGJ9n9F4Dp6', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(139, 'stu116', NULL, '$2y$10$L8tFzpQigIWE4a.tKArzTeg6tOfNw/efNGmldPkimdJ.rzowniQo.', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(140, 'stu117', NULL, '$2y$10$WEAUwQT1lfzTwvzQQmDjQ.0rhj0IkBuCI2fVfBTNZ7r6cFs5kBVKK', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(141, 'stu118', NULL, '$2y$10$0dc1cS6gOy9JRh1IK5kPKu5s/7WJH06HDeOs5AGFJyICEXgJadWIi', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(142, 'stu119', NULL, '$2y$10$XkGztXIyCyicg9g527abVus7W8ZAQHuCgL4fVuwZVI0WjusBwd.7.', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(143, 'stu120', NULL, '$2y$10$mIttB8d5OikCChWups2bAezu/.qqmV33tS8/kewi9m.fn/ySTCidm', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(144, 'stu121', NULL, '$2y$10$0RzwtDnMMGT7U6jkvOAASuZz7dcMpL4v6ZSyQG6cGpwakmHDSqQui', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(145, 'stu122', NULL, '$2y$10$QusNWQm5hvr8.HK5KwK7QOYB9uYBUsRCYiA.f96iKmf9NP6GjLQVW', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(146, 'stu123', NULL, '$2y$10$pJBeSfcvTn6XT.hjsz3TdeZab9Riw6lL/Gvl.DQNElSXl/Gj/s3ue', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(147, 'stu124', NULL, '$2y$10$VsxyoEb7fkeB.20hUlwrbeS4tU.ywKLk.W7kw2RTUduDtbHYUR65W', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(148, 'stu125', NULL, '$2y$10$eqVZfv.m2/CiJF.mLoMgTezBSXAHceuI.0XIdcPRfHwMrnOcj023C', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(149, 'stu126', NULL, '$2y$10$.B35hLHvebwIUG..0h9zv.PbqsfgdIH8cvUNogONd.mjDnEIqJypC', 3, 1, '2026-07-23 10:05:16', NULL, 0, NULL),
(150, 'stu127', NULL, '$2y$10$C4EbsTztUcf8ssQs27i6ce11Ja6EvuO8t91G5uulus/twkCYwMAPW', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(151, 'stu128', NULL, '$2y$10$O//M0mCYFhDnlAfPfnMWtO.12cUMz5SMkHTsCGvsQOKC0aNzzblb6', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(152, 'stu129', NULL, '$2y$10$Z20ZkfEB6izekn7P4Aoa3.7lJlJrtM60hlZZQU/s2kWQd7heUqCEy', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(153, 'stu130', NULL, '$2y$10$7.1hLpQNKy4NyEe3ZSnplORwubXkmPVHq09.gPU1oN6..8.8bQwKW', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(154, 'stu131', NULL, '$2y$10$Hif.aC0gvRKRnVfp55/O/upapYh2VDZjk1sdpsvmkqgmbqtiTPR36', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(155, 'stu132', NULL, '$2y$10$JaslLgaXM3XiO9sMxBSlp.X2sZKSUgyh0MCI61mAXhD.0kVGPu2uK', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(156, 'stu133', NULL, '$2y$10$HiqVjX0U9BscERB.Zy1JTeguHRL.vSAJwpM6xYuoNOtcqypGbalvm', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(157, 'stu134', NULL, '$2y$10$1BcylB9JNsaBYOI/pLOu.uRgcCa9u.KKhzmtjQUcoJHdHKzv6mn8m', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(158, 'stu135', NULL, '$2y$10$x/KbXTvYS7adtena5Ug.0Om3cqKLGWtfzF5fMv7ZUXpv2E3JP9DgW', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(159, 'stu136', NULL, '$2y$10$GdF6eOFvym3ALQQCyKJTq.c0Zh3GDmGikyUBbuiRkltCm1X1yvYWC', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(160, 'stu137', NULL, '$2y$10$DWYDWbZYfmanzYlg09eO1unyuEExcURerHTishNYyo6q2uvMD17Xe', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(161, 'stu138', NULL, '$2y$10$JHNIiGBYUikKviQh1pHYtuv48BuLSOR1kncBPTIVffz9DWF2exbgC', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(162, 'stu139', NULL, '$2y$10$KOa3MOKCCW8jUcCa7q4DiOaPkTGZKDgw0ZPD.ICRmSIuU6nauqd8i', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(163, 'stu140', NULL, '$2y$10$6PfBzDi6VlyiUNExNP9nSOa3om8lKXR5Knyj7KUEfyX.JW/0KFNCK', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(164, 'stu141', NULL, '$2y$10$7Y61Sny9UArPXh0qDNnhdu1iiZz7krzlE95VDHQCkc8LvXlKEe0Cq', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(165, 'stu142', NULL, '$2y$10$1BIIQ0SBsRwVECdoWjAgA.jm9/Gs8UjsRy98VX93LMuwv6NR1Ryq2', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(166, 'stu143', NULL, '$2y$10$QpdFDCMqxnmpBObnnT2.lO1lj90vUbWLdDjl8PFJ7fQMRAtPmHyQC', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(167, 'stu144', NULL, '$2y$10$SOWI5tHQfyOrkGfl3kgSp.UJXrHlxi03U85TvgymenMuvyriLjqeS', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(168, 'stu145', NULL, '$2y$10$mpYLQFajd4r8eUE6W/iX1.BgEb.5BIOCjQMuH5TGmfeB/V3F8AZ1m', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(169, 'stu146', NULL, '$2y$10$aZzLAUDjmfJra3zXQ1rcUunTqEKyLZTjUR8g2O7xz.ZsFL9mIjta.', 3, 1, '2026-07-23 10:05:17', NULL, 0, NULL),
(170, 'stu147', NULL, '$2y$10$xRXx2HmmW9s8lbI/auGABO.bOhAM/daeLdUZy1W32zaNTQF724Tk2', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(171, 'stu148', NULL, '$2y$10$Xw3d5wy0DU4qjd0/CExX3.H7DQ1aPcYQm7tKcL6B0YIo3v7ecUbNC', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(172, 'stu149', NULL, '$2y$10$IA7LREjeP5wH42NBUVtwR.6jqYl9aJjxXOym6Vsiuzgfug1SM8rU.', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(173, 'stu150', NULL, '$2y$10$p81rLasoexBLyEpeAwPxU.x8x4yiAelKDT2xwpfRqCBK/RIJK0gWi', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(174, 'stu151', NULL, '$2y$10$o0L0UYCekSY8Y8/uah1VmOL2q/ZGTA.2Nljy3NUJXPDtBTXFed9na', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(175, 'stu152', NULL, '$2y$10$8jIpx9Uj6AaKDny0RPzL2u4ZmgQ2T5xsK1IOcY.FPO6kqXv/XNoU.', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(176, 'stu153', NULL, '$2y$10$nglwmPurb4pT36ZgVaYgWui.qYZbmzR9bSW7SRjaZ22HkMsHyN3KG', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(177, 'stu154', NULL, '$2y$10$h9SmnIL1K..fZS6r4ZBgS.U32BWq5G/UfjXQldprymuyg2dyw2ASG', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(178, 'stu155', NULL, '$2y$10$zYRxvWovQ0FF64aT5S6cV.OZaD.VwluYunIk68w2VaxXqxZY/qxFq', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(179, 'stu156', NULL, '$2y$10$YDKcPJFUHkdo6pQUVDR5UOEgvJK0I7S20bEeDOBjnBHB5Dso7tVUu', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(180, 'stu157', NULL, '$2y$10$LA00ARpFQSNdOmdkxqZLZOFQWk2hq9CwE5eckhYFOWwNfq6C6190u', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(181, 'stu158', NULL, '$2y$10$I/F2j2cTzMRZ5DpArzvP9uccwt80fwWEwum7SkKs4DIl2vRDjwsqS', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(182, 'stu159', NULL, '$2y$10$0gqBFNX3hB8U1NP6pIMYu.VhaCRFo2xG8Y.M3MUEyPPCE.QyImasO', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(183, 'stu160', NULL, '$2y$10$kpfjzrryh/6DjO.Jc1VMWO1Q4UjANdiF0VJMZBN2UtUP2EjzhPOWC', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(184, 'stu161', NULL, '$2y$10$iHdFIXlwdNZEDCy1a2dOu.ucCRuk7tXfyIeY.lPfRulUZDLINi2Fq', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(185, 'stu162', NULL, '$2y$10$OGzgiv9LIICqqzQ.7ATXMOGFX6A7k1.y3a47fs.C9Hl3.oAOH06Hi', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(186, 'stu163', NULL, '$2y$10$VYTJTvrAW.78xbe.SAIV7OfeSiRUAjJubA/NfeTSmkhIw1tpnSXRK', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(187, 'stu164', NULL, '$2y$10$ILYzbxQ/268UH4.3MN4r9ujdNb.rgn6OKpZMcSgPt49Oe7QWLfznW', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(188, 'stu165', NULL, '$2y$10$j9aPOXGu0nBfxayA5PiKruYMsMq1XTYrpj/xJQKzqU2oaAxfpZACG', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(189, 'stu166', NULL, '$2y$10$aQ5cwqSLIFCRTvvR.yixLO9UE6NW48.cFRM1U/fLG93nzSpZIOjWy', 3, 1, '2026-07-23 10:05:18', NULL, 0, NULL),
(190, 'stu168', NULL, '$2y$10$yK2kKiZnqlbzqZQzsjYHRekEd496yM8JRuyE4J4QOa8V98tbqCnlS', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(191, 'stu169', NULL, '$2y$10$SwvZ0SXprK3GJg.YtuuSP.38W3ENlf0q0ONWSNrd.Bzji13emhUna', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(192, 'stu170', NULL, '$2y$10$SmBJjQ4r2pn7sn0HiTrpJeMswq2NqzzgCUl3qpDsB.7FEqjl2e6E2', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(193, 'stu171', NULL, '$2y$10$lhKDKtQF/6HmIyJYmPYZC.AE3B0dsy.A0P4AG07Ti/V6DNXIyjzIC', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(194, 'stu172', NULL, '$2y$10$Ro/nxYmNVQ4No1iYvfCvKeJIh7Ck26usNNdTQE0N0PycxDxg.4HrK', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(195, 'stu173', NULL, '$2y$10$rHae/WreKqfTkc0FN4GZCemyNt4.8kU22r72mBVjO6pxnoh6656T6', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(196, 'stu174', NULL, '$2y$10$huuDYKp70Qn45WhsrzxW8eYL9/oCiqwwGOYxj0ybDUYTNd.CXaOZ2', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(197, 'stu175', NULL, '$2y$10$kgAi9/ycvBZkUsN5mEx6yuu7DvlSAa9X86BNUDa1ZZslQz5jwDPPi', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(198, 'stu176', NULL, '$2y$10$5Dtss0yBoW4amunDwXUizuiIWS6vNxxsfbq.Po54avNipGVUYRycC', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(199, 'stu177', NULL, '$2y$10$ihXYWMFQ253a2T6AhjfP8efen8z5UT8V9hWKZSGF13IbJYPmGntg2', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(200, 'stu178', NULL, '$2y$10$pddVuIJtxV3/SPMzHWqBT.3/0tqGMSG/em13zCck7JBL44gi5oB8G', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(201, 'stu179', NULL, '$2y$10$BRj2hV/YRV8gc6nWSTIBROlckJwRpaGzjuc.JWQvtqgRKqkylYoq.', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(202, 'stu180', NULL, '$2y$10$euNqMNmdTCR2cbYiUrCIuu5VJOq54W7jHoZNvQnG.9AJBB680dt32', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(203, 'stu181', NULL, '$2y$10$SmKtv1mVmmdmBl7/0nygtOsVhFDsn7Lmrqp8oQrB0PdOTkJaRbShm', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(204, 'stu182', NULL, '$2y$10$U4oVe.rUASFPLPB26uM3s.Zc.W99wvzLGj8klS0NiiFjLxh8boCX2', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(205, 'Shamsia', NULL, '$2y$10$IcYy9O9pUd.Lg9bRz6lOoOvEVN1UD1cQ6nFckO6sjWoKtkLmYe1Z.', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(206, 'stu184', NULL, '$2y$10$qXABw0xosJiS9Pa2rHf4K.rDxDSr1EcGvczAHsqkvAdJJOV7XwLbC', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(207, 'stu185', NULL, '$2y$10$.4xQF0MsDxPtUbsVpeF1VeXxceF6iPKjqhY3LNBQnAkhdUhmnBtke', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(208, 'stu186', NULL, '$2y$10$RqBCbhhjHHqfNw/VyKTF0O1uBIGx.NT8KAHb2R6FuaRc9xsmatKTq', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(209, 'stu187', NULL, '$2y$10$/W/Jx6eG5niGmWMrkj4/Fu1Lt2YYCeUWuANCarQhDF822DsAXS51e', 3, 1, '2026-07-23 10:05:19', NULL, 0, NULL),
(210, 'stu188', NULL, '$2y$10$79t5O7RUwrdjLaabjZz2O.jfZhjp8x9bZ4V8By8OHtauBz.l0uVOO', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(211, 'stu190', NULL, '$2y$10$nA1F7cYi5OIOxQwfyOfeKuvO1a5bT71XLcjZLRtwt7OhOcSV.OJH.', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(212, 'stu192', NULL, '$2y$10$5XQPPYx.E2dbt05ajQ1gU.tist9iOv1ZD4rP8gQMaYtmQ88em77Cq', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(213, 'stu193', NULL, '$2y$10$0uIgEKjbJJLxmaN0C9oiVeXezIZTI79gGAdYfj0u7WCFQ4KhsyZnm', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(214, '2560550035', NULL, '$2y$10$vzUDwkPpJI9Qj0BBgYiuzePiw08TzixPwfKU2tdhW3zrP9pkUgFNm', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(215, '2360560053', NULL, '$2y$10$y0Y4gAnpk3hJXwHg28Tvf.ifHQhXIaTL3ovI02GuYMXGS3FjY/mly', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(216, '2360560052', NULL, '$2y$10$NkO8.vIr79JhMk7GgAVdouZJMmb1LmPc3nOg2YY6rM8lY5LtlLnGK', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(217, '2560560053', NULL, '$2y$10$kKKUi0dK88iNHt63ygPfaeNSfW6TMZD4XFvFOvszHOjw8F.M/o6XG', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(218, '2460560005', NULL, '$2y$10$5y9pckFSryB9gVS7JbDKbOhudGF6Jq8hnCo4QvgEqKSC2lmB9sC7q', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(219, '2560560098', NULL, '$2y$10$.7hIkjymOjlsyRzWPuB1mu3s7uaGOgvcSMHz9PDbP9y.8NqKii8a2', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(220, '2560560060', NULL, '$2y$10$gigwyO8Hm2pnyCP0C20kFeUgxzLuT63.rTmO8ipUNFmLeAp/NAJsO', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(221, 'stu194', NULL, '$2y$10$Pzyuzy4o84OyVuKKJl/L5.rBiwRgULCpPy9DkkpdG9O1er63DLQgK', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(222, 'stu195', NULL, '$2y$10$nbld044ojfIxBW1Pn4Cbnu1JMsPlxtwuzX7Vqp4uyEarCXJnwTb2u', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(223, 'stu196', NULL, '$2y$10$S6tvDpqnWqmTSuUoyIW3MuKv.ARO9JYvhyacsUpLsVOnqXs2Xfuf.', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(224, 'stu197', NULL, '$2y$10$0G6oAaV2SpRJ3E7Wng6gIuDdV6xlzhznhOCT7DvmayGbglAFNbsl2', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(225, 'stu198', NULL, '$2y$10$Iv73kwIghxmoAGnRrQ.lwuA5RwruFyi3XST2gdSD57miKxCN5IOLe', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(226, 'stu199', NULL, '$2y$10$G.I1sdVJlvqftAUPZK767OMWBN7lRKHaupK50PC3.s7pFQv/ZU6W.', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(227, 'stu200', NULL, '$2y$10$HE05prt7hzOROvYuJdPtA.9kDNJta02AvOJn3vIWLaFdiq6LOyvIy', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(228, 'stu201', NULL, '$2y$10$Kdm51EQlfvW48jM5SnTOL.UHZjKkZZOOp4eWKnCt/Peps6kPcXLbG', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(229, 'stu202', NULL, '$2y$10$Rcnj9u5xj0PXy8dp5qbLVu1/1NyXQHY794bpN4LwoPS07PTg7uHuO', 3, 1, '2026-07-23 10:05:20', NULL, 0, NULL),
(230, 'stu203', NULL, '$2y$10$0OBMMRvDyCa/mc089TLs.u19c1ryr2GhQ8RoLLXu2MhVkuVmN4Aje', 3, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(231, 'stu204', NULL, '$2y$10$IRDpXVT8yKtLnlzbVDmJEeTQL0vlRspHAXeXCYdNIqVtCCYWHquXq', 3, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(232, 'stu205', NULL, '$2y$10$elm..YngOPAL.bQ6f4/1b.LL/52nkMzZvG97k2GDXWT6gq4I6QFce', 3, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(233, 'abdullah.khan', 'abdulkhansukar081@gmail.com', '$2y$10$SjVi.v4FyOs97YVB3EUzTOHuSBY/Ixf9rv9aL4MBsswmLUdq0w3Ue', 18, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(234, 'sabir.hussain', 'sabirhussain500a@gmail.com', '$2y$10$HLjzL.Ga8AR7oC0yYeEkAOqhGa.1FcIO/klTHGqwU2vRgzepgtAnG', 2, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(235, 'tanveer', 'www.tanveerhussain@gmail.com', '$2y$10$JNGPNctV7j5H4xTfYwtSMu/OvacklA5v02i/FdatUIoXc/zbdgtZC', 2, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(236, 'sajid.ali', 'sajidalisajidi497@gmail.com', '$2y$10$z5xkJFilT5Hw.S29z19vVeIqbOHzDlB/j1oyoNytYt1oGHTNr5pGW', 2, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(237, 'kazim', NULL, '$2y$10$i0PNkU9RJAKtMChmuDiyw.3kZphL9yz9ZMfdaEDK3b3A8lFUYgSVa', 24, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(238, 'mehboob.ali.meer', 'mehboobalimeer009@gmail.com', '$2y$10$ZAEqCo97YdcicabkILHgzO0YB.GlA4iLqTM1CHBgtSh7TMDTtCpDm', 2, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(239, 'qasim.naseem', 'qasimaliuok@gmail.com', '$2y$10$ZRooehH.eWCHDvd0ytToj.h4wG1ZACPddQep97p3yGeFN9EYET0se', 2, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(240, 'wazir.nasrullah', 'marajwazir3@gmail.com', '$2y$10$eZDDO5XuPb/Ol4.sVIdrF.2ntXsvT.Fyxxd9EJdyBzO7lqKq0x4Vy', 2, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(241, '03555758660', NULL, '$2y$10$R1d0FpeJm3PKM682QhTJMeFVMwfZQwwfOcTaeex3TRlKV1EfRWmoe', 4, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(242, '03555265110', NULL, '$2y$10$atY1ZyERjzakUTVmOWSbOOPn0Fdd4QrVFpJGR6GIJS2Ox6g4BHL9O', 4, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(243, '03555461710', NULL, '$2y$10$xzr9pOJSB01FxdoZSCm2C.l7MlyPAKWHgVrhftGnEFEXMaq6qolD2', 4, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(244, '03554464864', NULL, '$2y$10$1yZpM7a0eBkTVgkrlHS5Ye4ss89T6BKznmMXlTRP7h09KqPEwR7ru', 4, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(245, '03551488490', NULL, '$2y$10$m4xMdC0cy6vENnDjUg3KFuSuO1L/TvtEhal/0PQ/52G2uM4/7bize', 4, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(246, '03555131475', NULL, '$2y$10$whE5Zpn/m/mZyIVr0o2c3uy/cUyqf8NqDUl8A7iXnQqyxQ.xUXQR6', 4, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(247, '03554976891', NULL, '$2y$10$2pqPoNP2ZHwMjPQdx8RY8.LArpvBfHs1yCHxIZ9ivpX/sfvkrp11u', 4, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(248, '03552310832', NULL, '$2y$10$zzeBqcxZPYgjPukXGzHgEuCnKioZCJ5hifRE1KKQ4lKnksxbWb8Zq', 4, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(249, '03555354136', NULL, '$2y$10$TY7OS6R3mYzFrY43wMF3H.ganCRA0lFIch3Uuguoun5KFcqNBSU3K', 4, 1, '2026-07-23 10:05:21', NULL, 0, NULL),
(250, '03554174067', NULL, '$2y$10$DN.gpvRCQN0lfF5Bmh4IO.ZWsfi5S3KbRuCtPPJ3HZeF9HNvYGws2', 4, 1, '2026-07-23 10:05:22', NULL, 0, NULL),
(251, '03419265854', NULL, '$2y$10$mFBmyAmYhMcxANGVdQh.DOmMN5i9DEnQ3SDSX1hlp.0tF.kXX9NYu', 4, 1, '2026-07-23 10:05:22', NULL, 0, NULL),
(252, '03555437214', NULL, '$2y$10$fMQxnjjK3mKgiufryBgIwOb924Uz0T5nrA.WHZYD5twISXJRMamCe', 4, 1, '2026-07-23 10:05:22', NULL, 0, NULL),
(253, '03555460721', NULL, '$2y$10$5eu0Ft37iQ5dWSZ9JMjesuhautILkpaR9WEvtbZQVXCyGeyc1n7KK', 4, 1, '2026-07-23 10:05:22', NULL, 0, NULL),
(254, '03555417448', NULL, '$2y$10$PDAOmCPErSKpK91ui315Iu/E6oaCZhA0JJ6GArWQD6Kekznza8Eh6', 4, 1, '2026-07-23 10:05:22', NULL, 0, NULL),
(255, 'shair.muhammad', NULL, '$2y$10$7MGK10b0Pr0UsLe5leJytevKqICNz3XFB09EYK2dzOO0T9cVJ2R2.', 4, 1, '2026-07-23 10:05:22', NULL, 0, NULL),
(256, 'wazir.nazir', NULL, '$2y$10$0S4LOOcINM4ZxTFwcQO1w.v3HeCmtNJkz0cQmnU4S/T/jwlK6AY.6', 4, 1, '2026-07-23 10:05:22', NULL, 0, NULL),
(257, '03145525749', NULL, '$2y$10$uE0xMkODMlHVeK0ZDfX03u0F/YTW/WytUyBLlzm6b2.PuZpkFt5Yi', 4, 1, '2026-07-23 10:05:22', NULL, 0, NULL),
(258, 'muhammad.tufail', NULL, '$2y$10$HlNLX0fz8cZfkGt9MRta6.ZOcrRVj6IfwtjPhmqdMcFkStCn9ymMK', 4, 1, '2026-07-23 10:05:22', NULL, 0, NULL),
(259, 'parent.of.muez.ali.ali.cho', NULL, '$2y$10$x/xz1yozqmmjQ9PqNbLDpeJb0DP4PRPDshEyibez8fjU8ANxC2NtC', 4, 1, '2026-07-23 10:05:22', NULL, 0, NULL),
(260, 'zahid.ali', NULL, '$2y$10$Q8.0ntrS983YyE68KnzOheBSx2jgtKa3uRSnTmWFTQ97rPi2F7FIG', 4, 1, '2026-07-23 10:05:22', NULL, 0, NULL),
(261, 'admin2', 'mubashirbaltistani@gmail.com', '$2y$10$2ItvB3var.D6YE2aqSmYEOQ21DcZUbJfLm253KB6c978F5jIkmg.G', 1, 1, '2026-07-25 07:14:55', NULL, 0, NULL),
(262, 'mudassir', NULL, '$2y$10$sUu49CfwTGCkA1gwjPSnCu3x0bGXPfE5.T2ZQXUinaEt1JxEttt5a', 1, 1, '2026-07-28 05:00:42', NULL, 0, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic_years`
--
ALTER TABLE `academic_years`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `academic_year_label` (`academic_year_label`);

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_activity_log_user` (`user_id`),
  ADD KEY `idx_activity_log_created` (`created_at`);

--
-- Indexes for table `api_tokens`
--
ALTER TABLE `api_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_token` (`token`),
  ADD KEY `ix_user_id` (`user_id`);

--
-- Indexes for table `attendance_records`
--
ALTER TABLE `attendance_records`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_attendance` (`student_id`,`class_section_id`,`subject_id`,`attendance_date`),
  ADD KEY `fk_att_cs` (`class_section_id`),
  ADD KEY `fk_att_subject` (`subject_id`),
  ADD KEY `fk_att_by` (`created_by_user_id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `class_sections`
--
ALTER TABLE `class_sections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_class_sections` (`class_id`,`section_id`,`academic_year_id`),
  ADD KEY `fk_class_sections_section` (`section_id`),
  ADD KEY `fk_class_sections_year` (`academic_year_id`);

--
-- Indexes for table `class_teachers`
--
ALTER TABLE `class_teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_class_teacher` (`class_section_id`,`staff_profile_id`),
  ADD KEY `fk_class_teachers_staff` (`staff_profile_id`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_comp_student` (`student_id`),
  ADD KEY `fk_comp_by` (`submitted_by_user_id`);

--
-- Indexes for table `course_assignments`
--
ALTER TABLE `course_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_course_student` (`course_id`,`student_id`),
  ADD KEY `fk_ca_student` (`student_id`);

--
-- Indexes for table `course_resources`
--
ALTER TABLE `course_resources`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_cr_course` (`course_id`);

--
-- Indexes for table `custom_fields`
--
ALTER TABLE `custom_fields`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_custom_field` (`scope`,`field_key`);

--
-- Indexes for table `custom_field_values`
--
ALTER TABLE `custom_field_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_cfv_field` (`custom_field_id`),
  ADD KEY `fk_cfv_user` (`user_id`),
  ADD KEY `fk_cfv_student` (`student_id`),
  ADD KEY `fk_cfv_staff` (`staff_profile_id`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_exams_group` (`exam_group_id`),
  ADD KEY `fk_exams_year` (`academic_year_id`),
  ADD KEY `fk_exams_cs` (`class_section_id`),
  ADD KEY `fk_exams_by` (`created_by_user_id`);

--
-- Indexes for table `exam_groups`
--
ALTER TABLE `exam_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_exam_group` (`exam_type_id`,`name`);

--
-- Indexes for table `exam_rules`
--
ALTER TABLE `exam_rules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_exam_rules` (`exam_group_id`);

--
-- Indexes for table `exam_subject_schedule`
--
ALTER TABLE `exam_subject_schedule`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_exam_subject` (`exam_id`,`subject_id`),
  ADD KEY `fk_ess_subject` (`subject_id`);

--
-- Indexes for table `exam_types`
--
ALTER TABLE `exam_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_exp_category` (`expense_category_id`),
  ADD KEY `fk_exp_by` (`added_by_user_id`);

--
-- Indexes for table `expense_categories`
--
ALTER TABLE `expense_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `fee_assignments`
--
ALTER TABLE `fee_assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_fa_category` (`fee_category_id`),
  ADD KEY `fk_fa_year` (`academic_year_id`),
  ADD KEY `fk_fa_student` (`student_id`),
  ADD KEY `fk_fa_cs` (`class_section_id`);

--
-- Indexes for table `fee_categories`
--
ALTER TABLE `fee_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `fee_collections`
--
ALTER TABLE `fee_collections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_fc_invoice` (`fee_invoice_id`),
  ADD KEY `fk_fc_by` (`collected_by_user_id`);

--
-- Indexes for table `fee_collection_allocations`
--
ALTER TABLE `fee_collection_allocations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_fca_collection` (`fee_collection_id`),
  ADD KEY `idx_fca_line` (`fee_invoice_line_id`);

--
-- Indexes for table `fee_collection_assignments`
--
ALTER TABLE `fee_collection_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_fee_collect_assign` (`class_section_id`,`staff_profile_id`),
  ADD KEY `fk_fee_collect_staff` (`staff_profile_id`);

--
-- Indexes for table `fee_collection_lines`
--
ALTER TABLE `fee_collection_lines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_fee_collection_id` (`fee_collection_id`),
  ADD KEY `idx_fee_invoice_line_id` (`fee_invoice_line_id`);

--
-- Indexes for table `fee_custom_fines`
--
ALTER TABLE `fee_custom_fines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_fcf_invoice` (`fee_invoice_id`),
  ADD KEY `fk_fcf_by` (`added_by_user_id`);

--
-- Indexes for table `fee_discount_rules`
--
ALTER TABLE `fee_discount_rules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `fee_fine_rules`
--
ALTER TABLE `fee_fine_rules`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `fee_handovers`
--
ALTER TABLE `fee_handovers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_fh_by` (`handed_over_by_user_id`),
  ADD KEY `fk_fh_to` (`handed_over_to_user_id`),
  ADD KEY `fk_fh_confirmed_by` (`confirmed_by_user_id`),
  ADD KEY `idx_fh_staff` (`staff_profile_id`),
  ADD KEY `idx_fh_status` (`status`);

--
-- Indexes for table `fee_invoices`
--
ALTER TABLE `fee_invoices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoice_no` (`invoice_no`),
  ADD KEY `fk_fi_student` (`student_id`),
  ADD KEY `fk_fi_year` (`academic_year_id`),
  ADD KEY `fk_fi_by` (`created_by_user_id`);

--
-- Indexes for table `fee_invoice_lines`
--
ALTER TABLE `fee_invoice_lines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_fil_invoice` (`fee_invoice_id`),
  ADD KEY `fk_fil_category` (`fee_category_id`),
  ADD KEY `idx_fil_billing` (`fee_category_id`,`billing_month`,`billing_year`);

--
-- Indexes for table `fee_student_reconciliation`
--
ALTER TABLE `fee_student_reconciliation`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_student_year` (`student_id`,`academic_year_id`),
  ADD KEY `fk_fsr_year` (`academic_year_id`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `grade_letter` (`grade_letter`);

--
-- Indexes for table `guardians`
--
ALTER TABLE `guardians`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `inquiries`
--
ALTER TABLE `inquiries`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `inquiry_no` (`inquiry_no`),
  ADD KEY `fk_inq_class` (`requested_class_id`),
  ADD KEY `fk_inq_section` (`requested_section_id`),
  ADD KEY `fk_inq_by` (`reviewed_by_user_id`);

--
-- Indexes for table `label_overrides`
--
ALTER TABLE `label_overrides`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_label_overrides` (`module_name`,`field_key`);

--
-- Indexes for table `leave_approvals`
--
ALTER TABLE `leave_approvals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_la_lr` (`leave_request_id`),
  ADD KEY `fk_la_by` (`approved_by_user_id`);

--
-- Indexes for table `leave_requests`
--
ALTER TABLE `leave_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_lr_staff` (`staff_profile_id`),
  ADD KEY `fk_lr_by` (`requested_by_user_id`),
  ADD KEY `idx_lr_student` (`student_id`),
  ADD KEY `idx_lr_applicant_type` (`applicant_type`);

--
-- Indexes for table `login_ip_throttle`
--
ALTER TABLE `login_ip_throttle`
  ADD PRIMARY KEY (`ip_address`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_marks` (`exam_id`,`student_id`,`subject_id`),
  ADD KEY `fk_marks_student` (`student_id`),
  ADD KEY `fk_marks_cs` (`class_section_id`),
  ADD KEY `fk_marks_subject` (`subject_id`),
  ADD KEY `fk_marks_grade` (`grade_id`),
  ADD KEY `fk_marks_by` (`entered_by_user_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_notifications_user_unread` (`user_id`,`is_read`,`created_at`);

--
-- Indexes for table `online_courses`
--
ALTER TABLE `online_courses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_oc_created_by` (`created_by_user_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_password_resets_token` (`token_hash`),
  ADD KEY `idx_password_resets_user` (`user_id`);

--
-- Indexes for table `performance_reports`
--
ALTER TABLE `performance_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pr_staff` (`staff_profile_id`),
  ADD KEY `fk_pr_by` (`created_by_user_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permission_key` (`permission_key`);

--
-- Indexes for table `resource_progress`
--
ALTER TABLE `resource_progress`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_rp_resource_student` (`course_resource_id`,`student_id`),
  ADD KEY `fk_rp_student` (`student_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`role_id`,`permission_id`),
  ADD KEY `fk_role_permissions_permission` (`permission_id`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `staff_attendance_records`
--
ALTER TABLE `staff_attendance_records`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_s_att` (`staff_profile_id`,`attendance_date`),
  ADD KEY `fk_sar_by` (`created_by_user_id`);

--
-- Indexes for table `staff_fee_classes`
--
ALTER TABLE `staff_fee_classes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_sfc` (`staff_profile_id`,`class_section_id`),
  ADD KEY `fk_sfc_class_section` (`class_section_id`),
  ADD KEY `fk_sfc_by` (`assigned_by_user_id`);

--
-- Indexes for table `staff_profiles`
--
ALTER TABLE `staff_profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `staff_code` (`staff_code`);

--
-- Indexes for table `staff_roles`
--
ALTER TABLE `staff_roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `staff_role_assignments`
--
ALTER TABLE `staff_role_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_sra` (`staff_profile_id`,`staff_role_id`),
  ADD KEY `fk_sra_role` (`staff_role_id`),
  ADD KEY `fk_sra_by` (`assigned_by_user_id`);

--
-- Indexes for table `staff_salary_details`
--
ALTER TABLE `staff_salary_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_staff_month` (`staff_profile_id`,`salary_month`,`salary_year`),
  ADD KEY `fk_sd_by` (`created_by_user_id`);

--
-- Indexes for table `staff_salary_payments`
--
ALTER TABLE `staff_salary_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_ssp_detail` (`staff_salary_detail_id`),
  ADD KEY `fk_ssp_by` (`paid_by_user_id`);

--
-- Indexes for table `staff_subject_assignments`
--
ALTER TABLE `staff_subject_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_ssa` (`staff_profile_id`,`subject_id`),
  ADD KEY `fk_ssa_subject` (`subject_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admission_no` (`admission_no`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `student_class_assignments`
--
ALTER TABLE `student_class_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_roll_class` (`class_section_id`,`roll_number`),
  ADD KEY `fk_sca_student` (`student_id`),
  ADD KEY `fk_sca_by` (`assigned_by_user_id`);

--
-- Indexes for table `student_guardians`
--
ALTER TABLE `student_guardians`
  ADD PRIMARY KEY (`student_id`,`guardian_id`),
  ADD KEY `fk_sg_guardian` (`guardian_id`);

--
-- Indexes for table `student_promotions`
--
ALTER TABLE `student_promotions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_sp_student` (`student_id`),
  ADD KEY `fk_sp_from` (`from_class_section_id`),
  ADD KEY `fk_sp_to` (`to_class_section_id`),
  ADD KEY `fk_sp_by` (`promoted_by_user_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_subject_code` (`subject_code`),
  ADD UNIQUE KEY `uq_subject_class_name` (`class_id`,`subject_name`);

--
-- Indexes for table `timetable_entries`
--
ALTER TABLE `timetable_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_tte_cs` (`class_section_id`),
  ADD KEY `fk_tte_subject` (`subject_id`),
  ADD KEY `fk_tte_by` (`created_by_user_id`),
  ADD KEY `fk_timetable_teacher` (`teacher_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fk_users_role` (`role_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academic_years`
--
ALTER TABLE `academic_years`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1090;

--
-- AUTO_INCREMENT for table `api_tokens`
--
ALTER TABLE `api_tokens`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `attendance_records`
--
ALTER TABLE `attendance_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=600;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `class_sections`
--
ALTER TABLE `class_sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `class_teachers`
--
ALTER TABLE `class_teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `course_assignments`
--
ALTER TABLE `course_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `course_resources`
--
ALTER TABLE `course_resources`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `custom_fields`
--
ALTER TABLE `custom_fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `custom_field_values`
--
ALTER TABLE `custom_field_values`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `exam_groups`
--
ALTER TABLE `exam_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `exam_rules`
--
ALTER TABLE `exam_rules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `exam_subject_schedule`
--
ALTER TABLE `exam_subject_schedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT for table `exam_types`
--
ALTER TABLE `exam_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `expense_categories`
--
ALTER TABLE `expense_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `fee_assignments`
--
ALTER TABLE `fee_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `fee_categories`
--
ALTER TABLE `fee_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `fee_collections`
--
ALTER TABLE `fee_collections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=200;

--
-- AUTO_INCREMENT for table `fee_collection_allocations`
--
ALTER TABLE `fee_collection_allocations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=438;

--
-- AUTO_INCREMENT for table `fee_collection_assignments`
--
ALTER TABLE `fee_collection_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fee_collection_lines`
--
ALTER TABLE `fee_collection_lines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `fee_custom_fines`
--
ALTER TABLE `fee_custom_fines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `fee_discount_rules`
--
ALTER TABLE `fee_discount_rules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `fee_fine_rules`
--
ALTER TABLE `fee_fine_rules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `fee_handovers`
--
ALTER TABLE `fee_handovers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fee_invoices`
--
ALTER TABLE `fee_invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=550;

--
-- AUTO_INCREMENT for table `fee_invoice_lines`
--
ALTER TABLE `fee_invoice_lines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1790;

--
-- AUTO_INCREMENT for table `fee_student_reconciliation`
--
ALTER TABLE `fee_student_reconciliation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `guardians`
--
ALTER TABLE `guardians`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `inquiries`
--
ALTER TABLE `inquiries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `label_overrides`
--
ALTER TABLE `label_overrides`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `leave_approvals`
--
ALTER TABLE `leave_approvals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `leave_requests`
--
ALTER TABLE `leave_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1775;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `online_courses`
--
ALTER TABLE `online_courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `performance_reports`
--
ALTER TABLE `performance_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT for table `resource_progress`
--
ALTER TABLE `resource_progress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `staff_attendance_records`
--
ALTER TABLE `staff_attendance_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `staff_fee_classes`
--
ALTER TABLE `staff_fee_classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `staff_profiles`
--
ALTER TABLE `staff_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `staff_roles`
--
ALTER TABLE `staff_roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff_role_assignments`
--
ALTER TABLE `staff_role_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff_salary_details`
--
ALTER TABLE `staff_salary_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `staff_salary_payments`
--
ALTER TABLE `staff_salary_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `staff_subject_assignments`
--
ALTER TABLE `staff_subject_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=810;

--
-- AUTO_INCREMENT for table `student_class_assignments`
--
ALTER TABLE `student_class_assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=423;

--
-- AUTO_INCREMENT for table `student_promotions`
--
ALTER TABLE `student_promotions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT for table `timetable_entries`
--
ALTER TABLE `timetable_entries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=313;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=263;

-- --------------------------------------------------------

--
-- Structure for view `pending_dues_view`
--
DROP TABLE IF EXISTS `pending_dues_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`u897128490_sms`@`127.0.0.1` SQL SECURITY DEFINER VIEW `pending_dues_view`  AS SELECT `fi`.`id` AS `fee_invoice_id`, `fi`.`student_id` AS `student_id`, `fi`.`academic_year_id` AS `academic_year_id`, `fi`.`total_due`- ifnull(sum(`fc`.`amount`),0) AS `pending_amount` FROM (`fee_invoices` `fi` left join `fee_collections` `fc` on(`fc`.`fee_invoice_id` = `fi`.`id`)) GROUP BY `fi`.`id`, `fi`.`student_id`, `fi`.`academic_year_id`, `fi`.`total_due` ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD CONSTRAINT `fk_activity_log_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `attendance_records`
--
ALTER TABLE `attendance_records`
  ADD CONSTRAINT `fk_att_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_att_cs` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`),
  ADD CONSTRAINT `fk_att_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_att_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `class_sections`
--
ALTER TABLE `class_sections`
  ADD CONSTRAINT `fk_class_sections_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`),
  ADD CONSTRAINT `fk_class_sections_section` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`),
  ADD CONSTRAINT `fk_class_sections_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `class_teachers`
--
ALTER TABLE `class_teachers`
  ADD CONSTRAINT `fk_class_teachers_section` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_class_teachers_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `complaints`
--
ALTER TABLE `complaints`
  ADD CONSTRAINT `fk_comp_by` FOREIGN KEY (`submitted_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_comp_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `course_assignments`
--
ALTER TABLE `course_assignments`
  ADD CONSTRAINT `fk_ca_course` FOREIGN KEY (`course_id`) REFERENCES `online_courses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_ca_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `course_resources`
--
ALTER TABLE `course_resources`
  ADD CONSTRAINT `fk_cr_course` FOREIGN KEY (`course_id`) REFERENCES `online_courses` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `custom_field_values`
--
ALTER TABLE `custom_field_values`
  ADD CONSTRAINT `fk_cfv_field` FOREIGN KEY (`custom_field_id`) REFERENCES `custom_fields` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cfv_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cfv_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cfv_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `exams`
--
ALTER TABLE `exams`
  ADD CONSTRAINT `fk_exams_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_exams_cs` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_exams_group` FOREIGN KEY (`exam_group_id`) REFERENCES `exam_groups` (`id`),
  ADD CONSTRAINT `fk_exams_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `exam_groups`
--
ALTER TABLE `exam_groups`
  ADD CONSTRAINT `fk_exam_groups_type` FOREIGN KEY (`exam_type_id`) REFERENCES `exam_types` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `exam_rules`
--
ALTER TABLE `exam_rules`
  ADD CONSTRAINT `fk_exam_rules_group` FOREIGN KEY (`exam_group_id`) REFERENCES `exam_groups` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `exam_subject_schedule`
--
ALTER TABLE `exam_subject_schedule`
  ADD CONSTRAINT `fk_ess_exam` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_ess_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `expenses`
--
ALTER TABLE `expenses`
  ADD CONSTRAINT `fk_exp_by` FOREIGN KEY (`added_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_exp_category` FOREIGN KEY (`expense_category_id`) REFERENCES `expense_categories` (`id`);

--
-- Constraints for table `fee_assignments`
--
ALTER TABLE `fee_assignments`
  ADD CONSTRAINT `fk_fa_category` FOREIGN KEY (`fee_category_id`) REFERENCES `fee_categories` (`id`),
  ADD CONSTRAINT `fk_fa_cs` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fa_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fa_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `fee_collections`
--
ALTER TABLE `fee_collections`
  ADD CONSTRAINT `fk_fc_by` FOREIGN KEY (`collected_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_fc_invoice` FOREIGN KEY (`fee_invoice_id`) REFERENCES `fee_invoices` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fee_collection_assignments`
--
ALTER TABLE `fee_collection_assignments`
  ADD CONSTRAINT `fk_fee_collect_section` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fee_collect_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fee_custom_fines`
--
ALTER TABLE `fee_custom_fines`
  ADD CONSTRAINT `fk_fcf_by` FOREIGN KEY (`added_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_fcf_invoice` FOREIGN KEY (`fee_invoice_id`) REFERENCES `fee_invoices` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fee_handovers`
--
ALTER TABLE `fee_handovers`
  ADD CONSTRAINT `fk_fh_by` FOREIGN KEY (`handed_over_by_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fh_confirmed_by` FOREIGN KEY (`confirmed_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_fh_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fh_to` FOREIGN KEY (`handed_over_to_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fee_invoices`
--
ALTER TABLE `fee_invoices`
  ADD CONSTRAINT `fk_fi_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_fi_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fi_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `fee_invoice_lines`
--
ALTER TABLE `fee_invoice_lines`
  ADD CONSTRAINT `fk_fil_category` FOREIGN KEY (`fee_category_id`) REFERENCES `fee_categories` (`id`),
  ADD CONSTRAINT `fk_fil_invoice` FOREIGN KEY (`fee_invoice_id`) REFERENCES `fee_invoices` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fee_student_reconciliation`
--
ALTER TABLE `fee_student_reconciliation`
  ADD CONSTRAINT `fk_fsr_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_fsr_year` FOREIGN KEY (`academic_year_id`) REFERENCES `academic_years` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `guardians`
--
ALTER TABLE `guardians`
  ADD CONSTRAINT `fk_guardians_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `inquiries`
--
ALTER TABLE `inquiries`
  ADD CONSTRAINT `fk_inq_by` FOREIGN KEY (`reviewed_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_inq_class` FOREIGN KEY (`requested_class_id`) REFERENCES `classes` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_inq_section` FOREIGN KEY (`requested_section_id`) REFERENCES `sections` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `leave_approvals`
--
ALTER TABLE `leave_approvals`
  ADD CONSTRAINT `fk_la_by` FOREIGN KEY (`approved_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_la_lr` FOREIGN KEY (`leave_request_id`) REFERENCES `leave_requests` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `leave_requests`
--
ALTER TABLE `leave_requests`
  ADD CONSTRAINT `fk_lr_by` FOREIGN KEY (`requested_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_lr_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `marks`
--
ALTER TABLE `marks`
  ADD CONSTRAINT `fk_marks_by` FOREIGN KEY (`entered_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_marks_cs` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`),
  ADD CONSTRAINT `fk_marks_exam` FOREIGN KEY (`exam_id`) REFERENCES `exams` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_marks_grade` FOREIGN KEY (`grade_id`) REFERENCES `grades` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_marks_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_marks_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`);

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `online_courses`
--
ALTER TABLE `online_courses`
  ADD CONSTRAINT `fk_oc_created_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `fk_password_resets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `performance_reports`
--
ALTER TABLE `performance_reports`
  ADD CONSTRAINT `fk_pr_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_pr_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `resource_progress`
--
ALTER TABLE `resource_progress`
  ADD CONSTRAINT `fk_rp_resource` FOREIGN KEY (`course_resource_id`) REFERENCES `course_resources` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_rp_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD CONSTRAINT `fk_role_permissions_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `staff_attendance_records`
--
ALTER TABLE `staff_attendance_records`
  ADD CONSTRAINT `fk_sar_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_sar_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `staff_fee_classes`
--
ALTER TABLE `staff_fee_classes`
  ADD CONSTRAINT `fk_sfc_by` FOREIGN KEY (`assigned_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_sfc_class_section` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sfc_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `staff_profiles`
--
ALTER TABLE `staff_profiles`
  ADD CONSTRAINT `fk_staff_profiles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `staff_role_assignments`
--
ALTER TABLE `staff_role_assignments`
  ADD CONSTRAINT `fk_sra_by` FOREIGN KEY (`assigned_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_sra_role` FOREIGN KEY (`staff_role_id`) REFERENCES `staff_roles` (`id`),
  ADD CONSTRAINT `fk_sra_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `staff_salary_details`
--
ALTER TABLE `staff_salary_details`
  ADD CONSTRAINT `fk_sd_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_sd_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `staff_salary_payments`
--
ALTER TABLE `staff_salary_payments`
  ADD CONSTRAINT `fk_ssp_by` FOREIGN KEY (`paid_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_ssp_detail` FOREIGN KEY (`staff_salary_detail_id`) REFERENCES `staff_salary_details` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `staff_subject_assignments`
--
ALTER TABLE `staff_subject_assignments`
  ADD CONSTRAINT `fk_ssa_staff` FOREIGN KEY (`staff_profile_id`) REFERENCES `staff_profiles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_ssa_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `fk_students_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `student_class_assignments`
--
ALTER TABLE `student_class_assignments`
  ADD CONSTRAINT `fk_sca_by` FOREIGN KEY (`assigned_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_sca_cs` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`),
  ADD CONSTRAINT `fk_sca_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_guardians`
--
ALTER TABLE `student_guardians`
  ADD CONSTRAINT `fk_sg_guardian` FOREIGN KEY (`guardian_id`) REFERENCES `guardians` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sg_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `student_promotions`
--
ALTER TABLE `student_promotions`
  ADD CONSTRAINT `fk_sp_by` FOREIGN KEY (`promoted_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_sp_from` FOREIGN KEY (`from_class_section_id`) REFERENCES `class_sections` (`id`),
  ADD CONSTRAINT `fk_sp_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sp_to` FOREIGN KEY (`to_class_section_id`) REFERENCES `class_sections` (`id`);

--
-- Constraints for table `timetable_entries`
--
ALTER TABLE `timetable_entries`
  ADD CONSTRAINT `fk_timetable_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `staff_profiles` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_tte_by` FOREIGN KEY (`created_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_tte_cs` FOREIGN KEY (`class_section_id`) REFERENCES `class_sections` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_tte_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
