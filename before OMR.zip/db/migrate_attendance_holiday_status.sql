-- Migration: adds a 'holiday' attendance status, for local/national holidays,
-- so a day off can be recorded as "Holiday" instead of teachers either
-- leaving it blank or (incorrectly) marking every student/staff "Absent".
--
-- Holiday days are excluded from attendance-rate calculations in the
-- reports (see ReportsController / AttendanceModel / StaffAttendanceModel)
-- so they no longer count against anyone's attendance percentage.
--
-- Safe to run multiple times. Run this against your existing database.

ALTER TABLE attendance_records
  MODIFY COLUMN status ENUM('present','absent','late','excused','holiday') NOT NULL DEFAULT 'present';

ALTER TABLE staff_attendance_records
  MODIFY COLUMN status ENUM('present','absent','late','excused','holiday') NOT NULL DEFAULT 'present';
