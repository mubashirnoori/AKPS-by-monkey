-- =========================================================================
-- Fixes duplicate student attendance rows on "whole day" saves (portal
-- Take Attendance, and the admin screen's "Whole day" option) -- both save
-- with subject_id = NULL.
--
-- Root cause: attendance_records has UNIQUE KEY uq_attendance
-- (student_id, class_section_id, subject_id, attendance_date), and the save
-- logic relies on "INSERT ... ON DUPLICATE KEY UPDATE" to update an existing
-- day's record instead of creating a new one. But MySQL/MariaDB treats every
-- NULL in a unique index as distinct from every other NULL -- so it never
-- actually enforced uniqueness for subject_id IS NULL rows. Every re-save of
-- a whole-day attendance record silently INSERTed a new duplicate row
-- instead of updating the existing one, which is why students show up
-- multiple times with possibly different statuses.
--
-- Fix: add a generated column that normalizes NULL to 0 for uniqueness
-- purposes only (subject_id itself is untouched -- still NULL for
-- whole-day records), and key the UNIQUE constraint off that instead.
--
-- Safe to run multiple times (idempotent) EXCEPT the dedupe DELETE and the
-- ADD COLUMN / index swap, which physically change existing rows/schema --
-- back up your database before running this on production.
-- =========================================================================

-- Step 1: remove existing duplicates first, keeping the most recently saved
-- row (highest id) for each real (student, class, subject, date) combo --
-- otherwise Step 3's new unique index will fail to create.
DELETE ar1 FROM attendance_records ar1
INNER JOIN attendance_records ar2
  ON ar1.student_id = ar2.student_id
 AND ar1.class_section_id = ar2.class_section_id
 AND IFNULL(ar1.subject_id, 0) = IFNULL(ar2.subject_id, 0)
 AND ar1.attendance_date = ar2.attendance_date
 AND ar1.id < ar2.id;

-- Step 2: generated column that normalizes NULL subject_id to 0. STORED so
-- it can be indexed; kept in sync automatically by MySQL on every insert/update.
ALTER TABLE attendance_records
  ADD COLUMN subject_id_norm INT GENERATED ALWAYS AS (IFNULL(subject_id, 0)) STORED AFTER subject_id;

-- Step 3: swap the unique key to use the normalized column, so NULL
-- (whole-day) rows are finally treated as duplicates of each other too.
ALTER TABLE attendance_records
  DROP INDEX uq_attendance,
  ADD UNIQUE KEY uq_attendance (student_id, class_section_id, subject_id_norm, attendance_date);
