-- =========================================================================
-- SMS History (Portal > SMS History).
--
-- Lets staff see a log of every SMS that went through sms_outbox — who it
-- was sent to, the message, its status (pending/sending/sent/failed), and
-- who sent it (or "System" for OTPs / automated fee reminders).
--
-- Two permissions:
--   sms.history_view   — see the log. Granted to Admin, Teacher and
--                         Principal by default (same roles as sms.direct_send).
--                         A non-Admin viewer only sees messages they
--                         personally sent — never the whole school's outbox.
--   sms.history_manage — delete entries from the log. Granted to Admin
--                         ONLY. Teachers/Principals with sms.history_view
--                         can look but never see a delete button, and the
--                         controller re-checks this server-side regardless
--                         of what the browser sends.
--
-- No new tables — reads the existing sms_outbox.
--
-- Safe to run multiple times (idempotent). Not applied automatically —
-- run this against your live database before using the new page.
-- =========================================================================

INSERT INTO permissions (permission_key, permission_name, permission_description) VALUES
  ('sms.history_view', 'View SMS History', 'See the log of SMS messages sent through the system'),
  ('sms.history_manage', 'Manage SMS History', 'Delete entries from the SMS history log')
ON DUPLICATE KEY UPDATE permission_key = permission_key;

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.permission_key = 'sms.history_view'
WHERE r.name IN ('Admin', 'Teacher', 'Principal')
ON DUPLICATE KEY UPDATE role_id = role_id;

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.permission_key = 'sms.history_manage'
WHERE r.name = 'Admin'
ON DUPLICATE KEY UPDATE role_id = role_id;
