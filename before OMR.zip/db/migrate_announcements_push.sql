-- Migration: Announcements (bell + push notification) feature.
--
-- Adds:
--   1. `announcements`    — a record of each broadcast an admin/staff member sent
--                           (who they targeted, what it said) — for the "Sent
--                           Announcements" history list.
--   2. `device_tokens`    — one row per installed copy of the Android app, so a
--                           push notification can be sent to it via Firebase
--                           Cloud Messaging (FCM). Registered by the Android app
--                           calling POST /api/index.php?route=devices/register
--                           after it obtains its own FCM token.
--   3. `notifications.announcement_id` — links a bell notification back to the
--                           announcement that created it (nullable; existing
--                           event-driven notifications, e.g. leave approvals,
--                           are unaffected and keep this NULL).
--   4. permission `notifications.announce` — who is allowed to compose/send an
--                           announcement. Granted to Admin only by default;
--                           grant it to another role from Users > Roles &
--                           Permissions the same way as any other permission.
--
-- Safe to run multiple times (idempotent). Run this against your existing
-- database — it is NOT applied automatically since you're not doing a
-- fresh install.

CREATE TABLE IF NOT EXISTS announcements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  message VARCHAR(1000) NOT NULL,
  audience VARCHAR(30) NOT NULL, -- 'everyone' | 'staff' | 'parents' | 'students' | 'class'
  class_section_id INT NULL,     -- only set when audience = 'class'
  recipient_count INT NOT NULL DEFAULT 0,
  push_sent_count INT NOT NULL DEFAULT 0,
  created_by_user_id INT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_announcements_class FOREIGN KEY (class_section_id) REFERENCES class_sections(id) ON DELETE SET NULL,
  CONSTRAINT fk_announcements_by FOREIGN KEY (created_by_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS device_tokens (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  fcm_token VARCHAR(255) NOT NULL,
  platform VARCHAR(20) NOT NULL DEFAULT 'android',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_device_token (fcm_token),
  CONSTRAINT fk_device_tokens_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_device_tokens_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Link bell notifications back to the announcement that created them (nullable — every
-- other notification type, e.g. leave approvals or fee reminders, just leaves this NULL).
SET @col_exists = (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'notifications' AND COLUMN_NAME = 'announcement_id'
);
SET @sql = IF(@col_exists = 0,
  'ALTER TABLE notifications ADD COLUMN announcement_id INT NULL AFTER user_id, ADD CONSTRAINT fk_notifications_announcement FOREIGN KEY (announcement_id) REFERENCES announcements(id) ON DELETE SET NULL',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

INSERT INTO permissions (permission_key, permission_name, permission_description) VALUES
  ('notifications.announce','Send announcements','Compose and send an announcement (bell + push) to staff, parents, students, or a specific class')
ON DUPLICATE KEY UPDATE permission_key = permission_key;

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r JOIN permissions p ON p.permission_key = 'notifications.announce'
WHERE r.name = 'Admin'
ON DUPLICATE KEY UPDATE role_id = role_id;
