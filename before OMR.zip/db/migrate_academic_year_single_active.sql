-- Fixes a data bug where more than one row in `academic_years` was marked
-- is_active = 1 at the same time (ids 1, 2, and 3 were all active).
-- The app now resolves "the current academic year" primarily by date range
-- (see AcademicYearModel::currentId()), so this flag is only a fallback —
-- but it should still only ever be true for one row at a time, since the
-- Settings > Academic Years admin page and older code paths still read it.
--
-- Safe to re-run: it always sets is_active based on which row's start_date/
-- end_date span contains today, so as years roll forward you can re-run
-- this (or just use the Settings page) to keep the flag in sync.

UPDATE academic_years SET is_active = 0;

UPDATE academic_years
SET is_active = 1
WHERE start_date IS NOT NULL
  AND end_date IS NOT NULL
  AND CURDATE() BETWEEN start_date AND end_date
ORDER BY start_date DESC
LIMIT 1;
