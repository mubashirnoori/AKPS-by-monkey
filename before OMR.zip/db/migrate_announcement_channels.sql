-- Migration: Per-channel announcement delivery (Push / SMS / Email).
--
-- Announcements already fan out to the bell icon + push (FCM). This adds:
--   1. `announcements.sms_sent_count` / `email_sent_count` — same idea as the
--      existing `push_sent_count`, so the "Recently Sent" list can show how
--      many of each channel actually went out.
--   2. Default `settings` rows for the three channel toggles shown on
--      Settings > Notifications:
--        - announce_channel_push  (default ON  — matches existing behaviour)
--        - announce_channel_sms   (default OFF — opt-in, since SMS has a
--                                   per-message cost on the relay phone/SIM)
--        - announce_channel_email (default OFF — opt-in)
--      Only inserted if not already present, so re-running this is safe and
--      won't clobber a value you've already changed in Settings.
--
-- Safe to run multiple times (idempotent). Run this against your existing
-- database — it is NOT applied automatically since you're not doing a
-- fresh install.

SET @col_exists = (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'announcements' AND COLUMN_NAME = 'sms_sent_count'
);
SET @sql = IF(@col_exists = 0,
  'ALTER TABLE announcements ADD COLUMN sms_sent_count INT NOT NULL DEFAULT 0 AFTER push_sent_count',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @col_exists = (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'announcements' AND COLUMN_NAME = 'email_sent_count'
);
SET @sql = IF(@col_exists = 0,
  'ALTER TABLE announcements ADD COLUMN email_sent_count INT NOT NULL DEFAULT 0 AFTER sms_sent_count',
  'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

INSERT INTO settings (`key`, `value`, updated_at) VALUES
  ('announce_channel_push',  '1', NOW()),
  ('announce_channel_sms',   '0', NOW()),
  ('announce_channel_email', '0', NOW())
ON DUPLICATE KEY UPDATE `key` = `key`; -- no-op if the row already exists; never overwrites an existing value
