# What changed

## 1. Timetable — day filter, Edit button, cleaner look
File: `app/views/academic/timetable.php` + `app/controllers/AcademicController.php`

- New **Day** dropdown next to the class picker. Choose "Thursday" and the
  list shows only Thursday's periods (choose "All Days" to see the full week).
- Every entry now has an **Edit** button (not just Delete) — opens a popup
  pre-filled with that period's day/time/subject/teacher/room.
- The entries list is grouped by day with colored headers and subject
  "pill" badges instead of one long flat table.

No database changes needed for this part — just replace the two files.

## 2. Exams & Date Sheet — a real per-subject schedule
Files: `app/models/ExamSubjectScheduleModel.php` (new),
`app/views/academic/date_sheet.php`, `app/views/academic/exams.php`,
`app/controllers/AcademicController.php`, `db/migrate_exam_subject_schedule.sql` (new)

**Why:** previously one "Exam" record (e.g. "First Term Exam Nursery") only
had a single date/time for the whole class, so there was no way to give
Math, English and Urdu different exam days. Marks were already tracked
per-subject — scheduling wasn't.

**What it does now:**
1. Create the exam as before (Academic → Exams) — pick the exam group,
   class/section, and a name. The date/time fields on that form are now
   just optional overall defaults; you don't need to fill them in.
2. Go to Academic → **Date Sheet**, pick the exam you just created.
   If you're an admin you'll see an editable table listing every subject
   assigned to that class, with a Date, Start Time, End Time and Total
   Marks box for each one. Fill in what you need (you can leave subjects
   blank if they're not scheduled yet) and hit **Save Date Sheet**.
3. Below that, the page renders a print-ready date sheet: school
   name/logo, exam name, class, and a table of every scheduled subject
   sorted by date with the day of the week worked out automatically —
   plus signature lines for Class Teacher / Principal. Click **Print Date
   Sheet** to print or save as PDF (the sidebar/nav are hidden automatically
   when printing).

You can come back and re-open Date Sheet for that exam any time to add
more subjects or adjust dates — it always shows what's currently saved.

## How to deploy
1. Copy these files into the matching paths in your live site, overwriting
   the existing ones:
   - `app/controllers/AcademicController.php`
   - `app/models/ExamSubjectScheduleModel.php` (new file)
   - `app/views/academic/timetable.php`
   - `app/views/academic/date_sheet.php`
   - `app/views/academic/exams.php`
2. Database: nothing to run manually — the app creates the new
   `exam_subject_schedule` table itself the first time the Date Sheet page
   is opened. If your database user doesn't have `CREATE TABLE` rights at
   runtime, run `db/migrate_exam_subject_schedule.sql` once instead.
3. Reload the site and test:
   - Academic → Timetable → try the Day filter and Edit button.
   - Academic → Exams → create/keep an exam for a class.
   - Academic → Date Sheet → pick that exam, fill in subject dates, Save,
     then Print.
